/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _ISNORMALD2_H_
#define _ISNORMALD2_H_	1

#include <spu_intrinsics.h>

/*
 * FUNCTION
 *	vector unsigned long long _isnormald2(vector double x)
 *
 * DESCRIPTION
 *      The _isnormald2 function returns a vector in which each element
 *      indicates if the corresponding element of x is normal (not zero,
 *      subnormal, +infinity, -infinity or NaN).
 *
 * RETURNS
 *      The function _isnormald2 returns an unsigned long long vector in which
 *      each element is defined as:
 *
 *        - ULLONG_MAX  if the element of x is a normal
 *        - 0 		otherwise
 *
 */
static __inline vector unsigned long long _isnormald2(vector double x)
{

#ifndef __SPU_EDP__

  vec_uint4 exp_mask = (vec_uint4) {0x7FF00000, 0x00000000, 
                                    0x7FF00000, 0x00000000};
  vec_uchar16 promote = (vec_uchar16) {0, 1, 2, 3,  0, 1, 2, 3, 
                                       8, 9,10,11,  8, 9,10,11};

  //  mask out everthing but exp
  vec_uint4 exp_high = spu_and((vec_uint4)x, exp_mask);

  // check for Inf or NaN (exponent = 0x7FF)
  vec_uint4 infnan = spu_cmpeq(exp_high, exp_mask);

  // check for Zero or Denorm (exponent = 0)
  vec_uint4 zerodenorm = spu_cmpeq(exp_high, 0);

  vec_uint4 result = spu_nor(zerodenorm, infnan);
  result = spu_shuffle(result, result, promote);
	
  return (vec_ullong2)result;

#else

  vec_ullong2 neg = (vec_ullong2)spu_splats(-1ll);

  return spu_xor(neg, spu_testsv(x, SPU_SV_POS_ZERO     | SPU_SV_NEG_ZERO     | 
                                    SPU_SV_NEG_DENORM   | SPU_SV_POS_DENORM   |
                                    SPU_SV_NEG_INFINITY | SPU_SV_POS_INFINITY |
                                    SPU_SV_NAN));

#endif /* __SPU_EDP__ */
}

#endif // _ISNORMALD2_H_
#endif /* __SPU__ */
