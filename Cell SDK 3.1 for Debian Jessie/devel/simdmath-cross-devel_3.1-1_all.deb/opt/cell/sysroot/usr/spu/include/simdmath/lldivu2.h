/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _LLDIVU2_H_
#define _LLDIVU2_H_	1

#include <spu_intrinsics.h>
#include <simdmath.h>

/*
 * FUNCTION
 *  lldivu2_t _lldivu2(vector float x)
 *
 * DESCRIPTION
 *  The lldivu2 function computes 2 simultaneous unsigned integer
 *	quotients and remainders by dividing each component of the vector dividend  
 *	by the correspoding component of the vector divisor. If the divisor
 *	is 0, then a quotient of 0 is produced.
 *
 */


static __inline lldivu2_t _lldivu2(vector unsigned long long dividend, 
                                   vector unsigned long long divisor)
{
  lldivu2_t result;
  unsigned int cnt_0, cnt_1, cmp_0, cmp_1;
  vector unsigned char swap  = (vector unsigned char) {4,5,6,7, 0,1,2,3, 12,13,14,15, 8,9,10,11};
  vector unsigned int cnt, cnt_d;
  vector unsigned int eq, gt, cmp;
  vector unsigned long long quotient;
  vector unsigned int delta, term, term_0, term_1, div_0, div_1, one_0, one_1, borrow;
  vector unsigned int mask = (vector unsigned int) {0xFFFFFFFF, 0xFFFFFFFF, 0, 0};
  vector unsigned int one  = (vector unsigned int) {0, 1, 0, 1};
  vector unsigned char borrow_shuffle = (vector unsigned char) {
						    4,5,6,7, 192,192,192,192,
						    12,13,14,15, 192,192,192,192};
  vector unsigned long long origdividend;
  vector unsigned long long dividebyzero;

  origdividend = dividend;
  quotient = spu_splats(0ull);
  cnt_d = spu_cntlz((vector unsigned int)divisor);
  cnt_d = spu_add(cnt_d, spu_and(spu_cmpeq(cnt_d, 32), spu_rlqwbyte(cnt_d, 4)));

  /* If the divisor is 0, then force the dividend to zero and the
   * divisor to 1 so the result is 0.
   */
  cmp = spu_cmpeq((vector unsigned int)divisor, 0);
  cmp = spu_and(spu_shuffle(cmp, cmp, swap), cmp);
  dividebyzero = (vector unsigned long long)cmp;
  dividend = spu_andc(dividend, (vector unsigned long long)cmp);
  divisor  = spu_or  (divisor,  (vector unsigned long long)cmp);

  div_0 = spu_and ((vector unsigned int)divisor, mask);
  div_1 = spu_andc((vector unsigned int)divisor, mask);

  gt = spu_cmpgt((vector unsigned int)divisor, (vector unsigned int)dividend);
  eq = spu_cmpeq((vector unsigned int)divisor, (vector unsigned int)dividend);
  one  = spu_andc(one, spu_or(spu_rlqwbyte(gt, 12), spu_and(spu_rlqwbyte(eq, 12), gt)));

  while (spu_extract(spu_gather(one), 0)) {

    cnt = spu_cntlz((vector unsigned int)dividend);
    cnt = spu_add(cnt, spu_and(spu_cmpeq(cnt, 32), spu_rlqwbyte(cnt, 4)));

    delta = spu_sub(cnt_d, cnt);
    cnt_0 = spu_extract(delta, 0);
    cnt_1 = spu_extract(delta, 2);
    term_0 = spu_rlqwbytebc(spu_rlqw(div_0, (int)cnt_0), (int)cnt_0);
    term_1 = spu_rlqwbytebc(spu_rlqw(div_1, (int)cnt_1), (int)cnt_1);
    
    one_0 = spu_rlqwbytebc(spu_rlqw(spu_and(one,  mask), (int)cnt_0), (int)cnt_0);
    one_1 = spu_rlqwbytebc(spu_rlqw(spu_andc(one, mask),  (int)cnt_1), (int)cnt_1);
    
    term = spu_sel(term_1, term_0, mask);

    gt = spu_cmpgt((vector unsigned int)term, (vector unsigned int)dividend);
    eq = spu_cmpeq((vector unsigned int)term, (vector unsigned int)dividend);
    cmp  = spu_or(gt, spu_and(spu_rlqwbyte(gt, 4), eq));

    /* Compensate for overshifting */
    cmp_0 = spu_extract(cmp, 0);
    cmp_1 = spu_extract(cmp, 2);

    term_0 = spu_rlmaskqw(term_0, (int)cmp_0);
    term_1 = spu_rlmaskqw(term_1, (int)cmp_1);
    term   = spu_sel(term_1, term_0, mask);
    one_0  = spu_rlmaskqw(one_0, (int)cmp_0);
    one_1  = spu_rlmaskqw(one_1, (int)cmp_1);

    borrow = spu_genb((vector unsigned int)(dividend), term);
    borrow = spu_shuffle(borrow, borrow, borrow_shuffle);
    dividend = (vector unsigned long long)spu_subx((vector unsigned int)(dividend), term, borrow);

    quotient = (vector unsigned long long)spu_add((vector unsigned int)quotient, 
						  spu_sel(one_1, one_0, mask));

    gt = spu_cmpgt((vector unsigned int)divisor, (vector unsigned int)dividend);
    eq = spu_cmpeq((vector unsigned int)divisor, (vector unsigned int)dividend);
    one  = spu_andc(one, spu_or(spu_rlqwbyte(gt, 12), spu_and(spu_rlqwbyte(eq, 12), gt)));
  }

  /* If divide by zero, the dividend is returned in the remainder */
  dividend = spu_sel(dividend, origdividend, dividebyzero);

  result.quot = quotient;
  result.rem = dividend;

  return result;
}

#endif /* _LLDIVU2_H_ */
#endif /* __SPU__ */
