/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__

#ifndef _CEILF4_FAST_H_
#define _CEILF4_FAST_H_	1

#include <spu_intrinsics.h>

/*
 * FUNCTION
 *	vector float _ceilf4_fast(vector float value)
 *
 * DESCRIPTION
 *	The _ceilf4_fast routine rounds a vector of input values "value" upwards
 *	to their nearest integer returning the result as a vector of floats. 
 *
 *	This "fast" version computes the ceiling of all floating-point values in 
 *      the 32-bit signed integer range. Values outside this range get clamped.
 *
 */
static __inline vector float _ceilf4_fast(vector float value)
{
  vector float bias;

  /* If positive, bias the input value to truncate towards
   * positive infinity, instead of zero.
   */
  bias = (vector float)spu_rlmaska((vector signed int)value, -31);
  bias = (vector float)spu_nor((vector unsigned int)bias, (vector unsigned int)bias);
  bias = (vector float)spu_and((vector unsigned int)bias, spu_splats((unsigned int)0x3F7FFFFF));

  value = spu_add(value, bias);

  /* Remove fraction bits by casting to an integer and back
   * to a floating-point value.
   */
  return(spu_convtf(spu_convts(value, 0), 0));
}

#endif /* _CEILF4_FAST_H_ */
#endif /* __SPU__ */
