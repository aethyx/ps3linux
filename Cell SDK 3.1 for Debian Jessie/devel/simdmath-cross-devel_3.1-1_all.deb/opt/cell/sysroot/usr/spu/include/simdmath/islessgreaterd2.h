/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _ISLESSGREATERD2_H_
#define _ISLESSGREATERD2_H_ 1

#include <spu_intrinsics.h>

/*
 * FUNCTION
 *      vector unsigned long long _islessgreaterd2(vector double x, 
 *                                                 vector double y)
 *
 * DESCRIPTION
 *      The _islessgreaterd2 function returns a vector in which each element
 *      indicates if the corresponding element of x is less than or greater to
 *      the corresponding element of y.  This function correctly compares 
 *      subnormal values.
 *
 *      Special Cases:
 *       - if either element is NaN, the elements are considered unequal
 *       - if both elements are infinity with the same sign, the elements are 
 *         considered equal
 *       - the values +0 and –0 are considered equal.
 *
 *     Note this function is not the same as !isequal(x,y) because that 
 *     statement will evaluate to true if x or y is NaN.
 *
 * RETURNS
 *       ULLONG_MAX (0xFFFFFFFFFFFFFFFF)  if the element of x is less than, or 
 *                                        greater than, the element of y.
 *       0          (0x0000000000000000)  otherwise
 */
static __inline vector unsigned long long _islessgreaterd2(vector double x, vector double y)
{

#ifndef __SPU_EDP__

  vec_uint4 negzero = (vec_uint4) { 0x80000000, 0x00000000, 0x80000000, 0x00000000 };
  vec_uint4 nan_mask = (vec_uint4) { 0x7FF00000, 0x00000000, 0x7FF00000, 0x00000000 };
  vec_uchar16 hihi_promote = (vec_uchar16) { 0,1,2,3,  16,17,18,19,  8,9,10,11, 24,25,26,27};
	
  vec_uint4 x_eq_y;
  vec_uint4 zero_eq;
  vec_uint4 xabs;
  vec_uint4 x_gt;
  vec_uint4 xhi_inf;
  vec_uint4 xnan;
  vec_uint4 yabs;
  vec_uint4 y_gt;
  vec_uint4 yhi_inf;
  vec_uint4 ynan;
	
  vec_uint4 result;
	
  /*  A)  Check for bit equality  */
  x_eq_y = spu_cmpeq((vec_uint4)x,(vec_uint4)y);
  x_eq_y = spu_and(x_eq_y,spu_slqwbyte(x_eq_y,4));
	
	
  /*  B)  Check for special case of +0 and -0  */
  zero_eq = spu_cmpeq(spu_or((vec_uint4)x,(vec_uint4)y),negzero);
  zero_eq=spu_and(zero_eq,spu_slqwbyte(zero_eq,4));
	

  /*  C)  Check x for NaN  
      C1) If the high word is greater than max_exp (indicates a NaN)
      C2) If the low word is greater than 0 
  */
  xabs = spu_andc((vec_uint4)x,negzero);
  x_gt = spu_cmpgt(xabs,nan_mask);

  /*    C3) Check if the high word is equal to the inf exponent */
  xhi_inf = spu_cmpeq(xabs,nan_mask);
	
  /*  xnan = B1[hi] or (B2[lo] and B3[hi]) */
  xnan = spu_or(x_gt,spu_and(spu_rlqwbyte(x_gt,4),xhi_inf));
	
	
  /*  D)  Check y for NaN  
      D1) If the high word is greater than max_exp (indicates a NaN)
      D2) If the low word is greater than 0 
  */
  yabs = spu_andc((vec_uint4)y,negzero);
  y_gt = spu_cmpgt(yabs,nan_mask);

  /*    D3) Check if the high word is equal to the inf exponent */
  yhi_inf = spu_cmpeq(yabs,nan_mask);
	
  /*  ynan = B1[hi] or (B2[lo] and B3[hi]) */
  ynan = spu_or(y_gt,spu_and(spu_rlqwbyte(y_gt,4),yhi_inf));

  /*  result is true if not (A or B) and not (C or D)  */
  result = spu_andc(spu_nor(x_eq_y,zero_eq),spu_or(xnan,ynan));
	
  result= spu_shuffle(result,result,hihi_promote);
  return (vec_ullong2) result;

#else

  return spu_or(spu_cmpgt(x,y), spu_cmpgt(y,x));

#endif /* __SPU_EDP__ */

}
#endif /* _ISLESSGREATERD2_H_ */
#endif /* __SPU__ */
