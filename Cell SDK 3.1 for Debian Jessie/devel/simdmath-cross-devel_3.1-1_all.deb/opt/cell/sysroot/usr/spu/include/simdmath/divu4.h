/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _DIVU4_H_
#define _DIVU4_H_	1

#include <spu_intrinsics.h>
#include "simdmath.h"

/*
 * FUNCTION
 * 	vector unsigned int _divu4(vector unsigned int dividend, 
 *					 vector unsigned int divisor)
 * 
 * DESCRIPTION
 *	The _divu4 subroutine computes 4 simultaneous unsigned integer
 *	quotients of by dividing each component of the vector dividend  
 *	by the correspoding component of the vector divisor. If the divisor
 *	is 0, then a quotient of 0 is produced.
 *
 */
static __inline divu4_t _divu4(vector unsigned int dividend, vector unsigned int divisor)
{
  vector unsigned int cnt, cnt_d;
  vector unsigned int delta, term, cmp;
  vector unsigned int one = spu_splats((unsigned int)1);
  divu4_t result;
  
  result.quot  = spu_splats((unsigned int)0);
  cnt_d = spu_cntlz(divisor);

  result.rem = dividend;

  /* If the divisor is 0, then force the dividend to zero and the
   * divisor to 1 so the result is 0.
   */
  cmp = spu_cmpeq(divisor, 0);
  dividend = spu_andc(dividend, cmp);
  divisor = spu_sub(divisor, cmp);

  one  = spu_andc(one, spu_cmpgt(divisor, dividend));
  while (spu_extract(spu_gather(one), 0)) {

    cnt = spu_cntlz(dividend);
    delta = spu_sub(cnt_d, cnt);

    term = spu_rl(divisor, (vector signed int)delta);
    cmp  = spu_cmpgt(term, dividend);
    delta = spu_add(delta, cmp);
    term  = spu_rlmask(term, (vector signed int)cmp);

    dividend = spu_sub(dividend, term);
    result.quot = spu_add(result.quot, spu_sl(one, delta));
    result.rem = spu_sel(result.rem, dividend, spu_cmpeq(one, 1));

    one = spu_andc(one, spu_cmpgt(divisor, dividend));
  }

  return result;
}

#endif /* _DIVU4_H_ */
#endif /* __SPU__ */
