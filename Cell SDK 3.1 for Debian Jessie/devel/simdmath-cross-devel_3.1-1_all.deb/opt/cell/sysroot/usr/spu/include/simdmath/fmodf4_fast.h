/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__

#ifndef _FMODF4_FAST_H_
#define _FMODF4_FAST_H_	1

#include <spu_intrinsics.h>

//  These are only needed for the "fast" version
#include "fabsf4.h"
#include "divf4.h"

/*
 * FUNCTION
 *	vector float _fmodf4_fast(vector float x, vector float y)
 *
 * DESCRIPTION
 *	The _fmodf4 function computes the remainder of 4 quotients
 *	by dividing x by y. The return values are x - n*y, where n is
 *	the quotients of x/y, rounded towards zero.
 *
 *	The limited range form computes the fmod of all floating-point 
 *      x/y values in the 32-bit signed integer range. Values outside
 *      this range get clamped.
 *
 */
static __inline vector float _fmodf4_fast(vector float x, vector float y)
{
  /* 32-BIT INTEGER DYNAMIC RANGE 
   */
  vector float abs_y;
  vector float quotient, floored;

  abs_y = _fabsf4(y);
  quotient = _divf4(x, abs_y);

  floored = spu_convtf(spu_convts(quotient, 0), 0);
  return (spu_nmsub(abs_y, floored, spu_mul(abs_y, quotient)));
}


#endif /* _FMODF4_FAST_H_ */
#endif /* __SPU__ */
