/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__

#ifndef _LOGBD2_H_
#define _LOGBD2_H_	1

#include <spu_intrinsics.h>
#include <vec_types.h>

/*
 * FUNCTION
 * 	vector float _logbd2(vector float x)
 *
 * DESCRIPTION
 *  The _logbd2 function returns a vector float that contains the exponent
 *  of the corresponding elements of the input vector x. The exponent is
 *  defined by:
 *    x = frac * FLT_RADIX^exp, with frac in [1, FLT_RADIX).
 *
 *  Special Cases:
 *    x = +/-0, result is -infinity.
 *    x = +/-infinity, result is +infinity.
 *    x = NaN, result is NaN.
 *
 */
static __inline vector double _logbd2(vector double x)
{
  vec_uchar16 swapword    = ((vec_uchar16) {4,5,6,7, 0,1,2,3, 12,13,14,15, 8,9,10,11});
  vec_uchar16 even_to_odd = ((vec_uchar16) {0,1,2,3, 0,1,2,3, 8,9,10,11, 8,9,10,11});
  vec_int4 sign_mask = (vector signed int) {0x80000000, 0x00000000, 0x80000000, 0x00000000};
  vec_int4 mant_mask = (vector signed int) {0x000FFFFF, 0xFFFFFFFF, 0x000FFFFF, 0xFFFFFFFF};
  vec_int4 exp_shift = (vector signed int) {  -20,   -20,   -20,   -20};
  vec_int4 exp_bias  = (vector signed int) {-1023, -1023, -1023, -1023};
  vec_double2 inf  = (vector double)spu_splats(0x7FF0000000000000ull);
  vec_double2 ninf = (vector double)spu_splats(0xFFF0000000000000ull);
  vec_int4 mant;
  vec_int4 exp;
  vec_int4 lz, lzhi, lzlow;
  vec_uint4 isdnorm, isnan;
  vec_double2 xabs;
  vec_double2 result;

  xabs = spu_andc(x, (vec_double2)sign_mask);

  /* Since exponent as an int fits in a word, use the even
   * elements of vec_ints to do calculation.
   */
  mant = spu_and((vec_int4)x, mant_mask);
  exp = spu_rlmask((vec_int4)xabs, exp_shift);

  /* Count leading zeros in mantissa to handle denormals... */
  lz  = (vec_int4)spu_cntlz(mant);
  lzhi  = spu_sub(lz, spu_splats(12));
  lzlow = spu_shuffle(lz, lz, swapword);
  lz = spu_sel(lzhi, spu_add(lzhi, lzlow), spu_cmpeq(lzhi, spu_splats(20)));

  isnan = spu_and(spu_cmpeq(exp, spu_splats(0x7FF)), spu_cmpgt(spu_splats(52), lz));
  isnan = spu_shuffle(isnan, isnan, even_to_odd);

  exp = spu_add(exp, exp_bias);

  /* Adjust exponent for denormals */
  /* Zero case handled explicitly below */
  isdnorm = spu_cmpeq(exp, exp_bias);
  exp = spu_sel(exp, spu_sub(exp, lz), isdnorm);

  result = spu_extend(spu_convtf(exp, 0));

  /* Special Cases */

  /* Zero */
  result = spu_sel(result, ninf, spu_cmpeq(x, spu_splats(0.0)));

  /* Infinity */
  result = spu_sel(result, inf, spu_cmpeq(xabs, inf));

  /* NaN */
  result = spu_sel(result, x, (vec_ullong2)isnan);

  return (result);
}

#endif /* _LOGBD2_H_ */
#endif /* __SPU__ */
