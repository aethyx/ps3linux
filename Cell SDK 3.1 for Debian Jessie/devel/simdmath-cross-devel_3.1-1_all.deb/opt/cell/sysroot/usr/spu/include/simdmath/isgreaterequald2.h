/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _ISGREATEREQUALD2_H_
#define _ISGREATEREQUALD2_H_	1

#include <spu_intrinsics.h>
#include "isnand2.h"

/*
 * FUNCTION
 *	vector unsigned long long _isgreaterequald2(vector double x, vector double y)
 *
 * DESCRIPTION
 *      The _isgreaterequald2 function returns a vector in which each element 
 *      indicates if the corresponding element of x is greater than or equal 
 *      to the corresponding element of y.  This function correctly compare 
 *      subnormal values.
 *
 *      Special Cases:
 *      - if either element is NaN, the comparison is false.
 *      - two zeros compare equal, reguardless of sign
 *
 * RETURNS
 *      The function _isgreaterequald2 returns an unsigned long long vector in
 *      which each element is defined as:
 *
 *        - ULLONG_MAX 	       if the element of x is greater than, or equal 
 *                             to, the element of y
 *        - 0 		       otherwise
 *
 */
static __inline vector unsigned long long _isgreaterequald2(vector double x, vector double y)
{

#ifndef  __SPU_EDP__

  vec_uchar16 splat_hi = (vec_uchar16) { 0,1,2,3, 0,1,2,3, 8,9,10,11, 8,9,10,11 };
  vec_uchar16 borrow_shuffle = (vec_uchar16) { 4,5,6,7, 192,192,192,192, 12,13,14,15, 192,192,192,192 };
  vec_uint4 sign = (vec_uint4) { 0x7FFFFFFF, 0xFFFFFFFF, 0x7FFFFFFF, 0xFFFFFFFF };

  //  Check for NaNs in input
  vec_uint4 x_isnan = (vec_uint4)_isnand2(x);
  vec_uint4 y_isnan = (vec_uint4)_isnand2(y);
	
  // sign of x
  vec_uint4 xsel = spu_rlmaska((vec_uint4)x, -31);
  xsel = spu_shuffle(xsel,xsel,splat_hi);

  // sign of y
  vec_uint4 ysel = spu_rlmaska((vec_uint4)y, -31);
  ysel = spu_shuffle(ysel,ysel,splat_hi);

  // absolute value of x 
  vec_uint4 xabs = spu_and((vec_uint4)x, sign);

  // negative x
  vec_uint4 xbor = spu_genb(spu_splats((unsigned int)0),xabs);
  xbor = spu_shuffle(xbor,xbor,borrow_shuffle);
  vec_uint4 xneg = spu_subx(spu_splats((unsigned int)0),xabs,xbor);

  // pick the one we want
  vec_int4 a=(vec_int4)spu_sel(xabs, xneg, xsel);

  // absolute value of y
  vec_uint4 yabs = spu_and((vec_uint4)y, sign);

  // negative y
  vec_uint4 ybor = spu_genb(spu_splats((unsigned int)0),yabs);
  ybor = spu_shuffle(ybor,ybor,borrow_shuffle);
  vec_uint4 yneg = spu_subx(spu_splats((unsigned int)0),yabs,ybor);

  // pick the one we want
  vec_int4 b=(vec_int4)spu_sel(yabs, yneg, ysel);

  // A) Check if the exponents are different 
  vec_uint4 gt_hi = spu_cmpgt(a,b);
  
  // B) Check if high word equal, and low word greater
  vec_uint4 gt_lo = spu_cmpgt((vec_uint4)a,(vec_uint4)b);
  vec_uint4 eq = spu_cmpeq(a,b);
  vec_uint4 eqgt = spu_and(eq,spu_slqwbyte(gt_lo,4));
  
  // C) Check if high and low words are both equal
  vec_uint4 alleq = spu_and(eq,spu_slqwbyte(eq,4));
  
  //  If A, B, or C is true, return true (unless NaNs detected) 
  vec_uint4 r = spu_or(gt_hi, eqgt);
  r = spu_or(r,alleq);
  
  // splat the high words of the comparison step
  r = spu_shuffle(r,r,splat_hi);
  
  // correct for NaNs in input
  r = spu_andc(r,spu_or(x_isnan,y_isnan));
    
  return (vec_ullong2)r;

#else 

  return spu_or(spu_cmpgt(x,y), spu_cmpeq(x,y));

#endif /* __SPU_EDP__ */

}

#endif /* _ISGREATEREQUALD2_H_ */
#endif /* __SPU__ */
