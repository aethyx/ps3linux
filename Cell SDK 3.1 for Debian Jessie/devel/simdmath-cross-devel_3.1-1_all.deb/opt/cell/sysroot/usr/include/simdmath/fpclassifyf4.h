/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _FPCLASSIFYF4_H_
#define _FPCLASSIFYF4_H_	1

#include <math.h>
#include <altivec.h>
#include <vec_types.h>

#ifndef FP_NAN
#define FP_NAN         0
#endif

#ifndef FP_INFINITE
#define FP_INFINITE    1
#endif

#ifndef FP_ZERO
#define FP_ZERO        2
#endif

#ifndef FP_SUBNORMAL
#define FP_SUBNORMAL   3
#endif

#ifndef FP_NORMAL
#define FP_NORMAL      4
#endif

/*
 * FUNCTION
 *  vector signed int _fpclassifyf4(vector float x)
 *
 * DESCRIPTION
 *  The fpclassifyf4 function returns a vector containing the floating-
 *  point classifications for the corresponding elements of the input
 *  vector. The classifications are defined in math.h.
 *
 *  Special Cases:
 *	- Infinity and NaN are not supported in single precision on the SPU.
 *	  Therefore Infinity and NaNs are classified as Normal numbers.
 *	- Note that on the SPU, single-precision subnormal intrinsic argument
 *	  values are treated as 0, but this function will correctly classify
 *	  them as subnormal.
 *
 */

static __inline vector signed int _fpclassifyf4(vector float x)
{
    vec_uint4 xabs;
    vec_uint4 signbit = (vector unsigned int) {0x80000000, 0x80000000, 0x80000000, 0x80000000};
    vec_uint4 zero    = (vector unsigned int) {0,  0,  0,  0};
    vec_uint4 maxsnorm = (vector unsigned int){0x007FFFFF, 0x007FFFFF, 0x007FFFFF, 0x007FFFFF};
    vec_uint4 inf      = (vector unsigned int){0x7F800000, 0x7F800000, 0x7F800000, 0x7F800000};

    vec_int4  fpzero   = (vector signed int){FP_ZERO,      FP_ZERO,      FP_ZERO,      FP_ZERO};
    vec_int4  fpsnorm  = (vector signed int){FP_SUBNORMAL, FP_SUBNORMAL, FP_SUBNORMAL, FP_SUBNORMAL};
    vec_int4  fpnorm   = (vector signed int){FP_NORMAL,    FP_NORMAL,    FP_NORMAL,    FP_NORMAL};
    vec_int4  fpinf    = (vector signed int){FP_INFINITE,  FP_INFINITE,  FP_INFINITE,  FP_INFINITE};
    vec_int4  fpnan    = (vector signed int){FP_NAN,       FP_NAN,       FP_NAN,       FP_NAN};

    vec_int4  result;

    xabs = vec_andc((vec_uint4)x, signbit);

    result = vec_sel(fpzero, fpsnorm, vec_cmpgt(xabs, zero));
    result = vec_sel(result, fpnorm,  vec_cmpgt(xabs, maxsnorm));
    result = vec_sel(result, fpinf,   vec_cmpeq(xabs, inf));
    result = vec_sel(result, fpnan,   vec_cmpgt(xabs, inf));
    
    return result;
}

#endif /* _FPCLASSIFYF4_H_ */
