/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _TGAMMAF4_H_
#define _TGAMMAF4_H_	1

#include "simdmath.h"

#include "recipf4.h"
#include "truncf4.h"
#include "expf4.h"
#include "logf4.h"
#include "divf4.h"
#include "sinf4.h"
#include "powf4.h"

/*
 * Coefficients for Stirling's Series for Gamma()
 */
#define STIRLING_00   1.000000000000000000000000000000000000E0f
#define STIRLING_01   8.333333333333333333333333333333333333E-2f
#define STIRLING_02   3.472222222222222222222222222222222222E-3f
#define STIRLING_03  -2.681327160493827160493827160493827160E-3f
#define STIRLING_04  -2.294720936213991769547325102880658436E-4f
#define STIRLING_05   7.840392217200666274740348814422888497E-4f
#define STIRLING_06   6.972813758365857774293988285757833083E-5f
#define STIRLING_07  -5.921664373536938828648362256044011874E-4f
#define STIRLING_08  -5.171790908260592193370578430020588228E-5f
#define STIRLING_09   8.394987206720872799933575167649834452E-4f
#define STIRLING_10   7.204895416020010559085719302250150521E-5f
#define STIRLING_11  -1.914438498565477526500898858328522545E-3f
#define STIRLING_12  -1.625162627839158168986351239802709981E-4f
#define STIRLING_13   6.403362833808069794823638090265795830E-3f
#define STIRLING_14   5.401647678926045151804675085702417355E-4f
#define STIRLING_15  -2.952788094569912050544065105469382445E-2f
#define STIRLING_16  -2.481743600264997730915658368743464324E-3f


/*
 * Rational Approximation Coefficients for the 
 * domain [1, 2).
 */
#define TG_P00     -1.8211798563156931777484715e+05f
#define TG_P01     -8.7136501560410004458390176e+04f
#define TG_P02     -3.9304030489789496641606092e+04f
#define TG_P03     -1.2078833505605729442322627e+04f
#define TG_P04     -2.2149136023607729839568492e+03f
#define TG_P05     -7.2672456596961114883015398e+02f
#define TG_P06     -2.2126466212611862971471055e+01f
#define TG_P07     -2.0162424149396112937893122e+01f

#define TG_Q00     1.0000000000000000000000000f
#define TG_Q01    -1.8212849094205905566923320e+05f
#define TG_Q02    -1.9220660507239613798446953e+05f
#define TG_Q03     2.9692670736656051303725690e+04f
#define TG_Q04     3.0352658363629092491464689e+04f
#define TG_Q05    -1.0555895821041505769244395e+04f
#define TG_Q06     1.2786642579487202056043316e+03f
#define TG_Q07    -5.5279768804094054246434098e+01f

/*
 * FUNCTION
 *  vector float _tgammaf4(vector float x)
 *
 * DESCRIPTION
 *  The tgammaf4 function returns a vector containing tgamma for each 
 *  element of x 
 *
 *	We take a fairly standard approach - break the domain into 5 separate regions:
 *
 *	1. [-infinity, 0)  - use gamma(x) = pi/(x*gamma(-x)*sin(x*pi))
 *	2. [0, 1)          - push x into [1,2), then adjust the 
 *	                     result.
 *	3. [1, 2)          - use a rational approximation.
 *	4. [2, 10)         - pull back into [1, 2), then adjust
 *	                     the result.
 *	5. [10, +infinity] - use Stirling's Approximation.
 *
 *
 * Special Cases:
 *	- tgamma(+/- 0) returns +/- infinity
 *	- tgamma(negative integer) returns NaN
 *	- tgamma(-infinity) returns NaN
 *	- tgamma(infinity) returns infinity
 *
 */

/*
 * Coefficients for Stirling's Series for Gamma() are defined in 
 * tgammad2.h
 */

/*
 * Rational Approximation Coefficients for the 
 * domain [1, 2) are defined in tgammad2.h
 */


static __inline vector float _tgammaf4(vector float x)
{
    vector float signbit = ((vector float) {-0.0f, -0.0f, -0.0f, -0.0f});
    vector float zerof   = ((vector float) { 0.0f,  0.0f,  0.0f,  0.0f});
    vector float halff   = ((vector float) { 0.5f,  0.5f,  0.5f,  0.5f});
    vector float onef    = ((vector float) { 1.0f,  1.0f,  1.0f,  1.0f});
    /* Next under 10.0 */
    vector float ninep9f = ((vec_float4)((vec_uint4){0x411FFFFF, 0x411FFFFF, 
                                                    0x411FFFFF, 0x411FFFFF}));
    vector float t38f    = ((vector float) {38.0f, 38.0f, 38.0f, 38.0f});
    vector float pi      = ((vector float) {(float)SM_PI, (float)SM_PI, (float)SM_PI, (float)SM_PI});
    vector float sqrt2pi = ((vector float) {2.5066282746310005024f, 2.5066282746310005024f, 
                                           2.5066282746310005024f, 2.5066282746310005024f});
    vector float inf     = ((vec_float4)((vec_uint4){0x7F800000, 0x7F800000, 
                                                    0x7F800000, 0x7F800000}));
    vector float nan     = ((vec_float4)((vec_uint4){0x7FFFFFFF, 0x7FFFFFFF, 
                                                    0x7FFFFFFF, 0x7FFFFFFF}));
    vector float xabs;
    vector float xscaled;
    vector float xtrunc;
    vector float xinv;
    vector float nresult; /* Negative x result */
    vector float rresult; /* Rational Approx result */
    vector float sresult; /* Stirling's result */
    vector float result;
    vector float pr,qr;

    vector bool int gt0   = vec_cmpgt(x, zerof);
    vector bool int gt1   = vec_cmpgt(x, onef);
    vector bool int gt9p9 = vec_cmpgt(x, ninep9f);
    vector bool int gt38  = vec_cmpgt(x, t38f);

    xabs    = vec_andc(x, signbit);

    /*
     * For x in [0, 1], add 1 to x, use rational
     * approximation, then use:
     *
     * gamma(x) = gamma(x+1)/x
     *
     */
    xabs = vec_sel(vec_add(xabs, onef), xabs, gt1);
    xtrunc = _truncf4(xabs);


    /*
     * For x in [2, 10):
     */
    xscaled = vec_add(onef, vec_sub(xabs, xtrunc));

    /*
     * For x in [1,2), use a rational approximation.
     */
    pr = vec_madd(xscaled, ((vector float){TG_P07, TG_P07, TG_P07, TG_P07}), 
                           ((vector float){TG_P06, TG_P06, TG_P06, TG_P06}));
    pr = vec_madd(pr, xscaled, ((vector float){TG_P05, TG_P05, TG_P05, TG_P05}));
    pr = vec_madd(pr, xscaled, ((vector float){TG_P04, TG_P04, TG_P04, TG_P04}));
    pr = vec_madd(pr, xscaled, ((vector float){TG_P03, TG_P03, TG_P03, TG_P03}));
    pr = vec_madd(pr, xscaled, ((vector float){TG_P02, TG_P02, TG_P02, TG_P02}));
    pr = vec_madd(pr, xscaled, ((vector float){TG_P01, TG_P01, TG_P01, TG_P01}));
    pr = vec_madd(pr, xscaled, ((vector float){TG_P00, TG_P00, TG_P00, TG_P00}));

    qr = vec_madd(xscaled, ((vector float){TG_Q07, TG_Q07, TG_Q07, TG_Q07}), 
                           ((vector float){TG_Q06, TG_Q06, TG_Q06, TG_Q06}));
    qr = vec_madd(qr, xscaled, ((vector float){TG_Q05, TG_Q05, TG_Q05, TG_Q05}));
    qr = vec_madd(qr, xscaled, ((vector float){TG_Q04, TG_Q04, TG_Q04, TG_Q04}));
    qr = vec_madd(qr, xscaled, ((vector float){TG_Q03, TG_Q03, TG_Q03, TG_Q03}));
    qr = vec_madd(qr, xscaled, ((vector float){TG_Q02, TG_Q02, TG_Q02, TG_Q02}));
    qr = vec_madd(qr, xscaled, ((vector float){TG_Q01, TG_Q01, TG_Q01, TG_Q01}));
    qr = vec_madd(qr, xscaled, ((vector float){TG_Q00, TG_Q00, TG_Q00, TG_Q00}));

    rresult = _divf4(pr, qr);
    rresult = vec_sel(_divf4(rresult, x), rresult, gt1);

    /*
     * If x was in [2,10) and we pulled it into [1,2), we need to push
     * it back out again.
     */
    rresult = vec_sel(rresult, vec_madd(rresult, xscaled, zerof), vec_cmpgt(x, xscaled)); /* [2,3) */
    xscaled = vec_add(xscaled, onef);
    rresult = vec_sel(rresult, vec_madd(rresult, xscaled, zerof), vec_cmpgt(x, xscaled)); /* [3,4) */
    xscaled = vec_add(xscaled, onef);
    rresult = vec_sel(rresult, vec_madd(rresult, xscaled, zerof), vec_cmpgt(x, xscaled)); /* [4,5) */
    xscaled = vec_add(xscaled, onef);
    rresult = vec_sel(rresult, vec_madd(rresult, xscaled, zerof), vec_cmpgt(x, xscaled)); /* [5,6) */
    xscaled = vec_add(xscaled, onef);
    rresult = vec_sel(rresult, vec_madd(rresult, xscaled, zerof), vec_cmpgt(x, xscaled)); /* [6,7) */
    xscaled = vec_add(xscaled, onef);
    rresult = vec_sel(rresult, vec_madd(rresult, xscaled, zerof), vec_cmpgt(x, xscaled)); /* [7,8) */
    xscaled = vec_add(xscaled, onef);
    rresult = vec_sel(rresult, vec_madd(rresult, xscaled, zerof), vec_cmpgt(x, xscaled)); /* [8,9) */
    xscaled = vec_add(xscaled, onef);
    rresult = vec_sel(rresult, vec_madd(rresult, xscaled, zerof), vec_cmpgt(x, xscaled)); /* [9,10) */


    /*
     * For x >= 10, we use Stirling's Approximation
     */
    vector float sum;
    xinv    = _recipf4(xabs);            
    sum = vec_madd(xinv, ((vector float){STIRLING_16, STIRLING_16, STIRLING_16, STIRLING_16}), 
                         ((vector float){STIRLING_15, STIRLING_15, STIRLING_15, STIRLING_15}));
    sum = vec_madd(sum, xinv, ((vector float){STIRLING_14, STIRLING_14, STIRLING_14, STIRLING_14}));
    sum = vec_madd(sum, xinv, ((vector float){STIRLING_13, STIRLING_13, STIRLING_13, STIRLING_13}));
    sum = vec_madd(sum, xinv, ((vector float){STIRLING_12, STIRLING_12, STIRLING_12, STIRLING_12}));
    sum = vec_madd(sum, xinv, ((vector float){STIRLING_11, STIRLING_11, STIRLING_11, STIRLING_11}));
    sum = vec_madd(sum, xinv, ((vector float){STIRLING_10, STIRLING_10, STIRLING_10, STIRLING_10}));
    sum = vec_madd(sum, xinv, ((vector float){STIRLING_09, STIRLING_09, STIRLING_09, STIRLING_09}));
    sum = vec_madd(sum, xinv, ((vector float){STIRLING_08, STIRLING_08, STIRLING_08, STIRLING_08}));
    sum = vec_madd(sum, xinv, ((vector float){STIRLING_07, STIRLING_07, STIRLING_07, STIRLING_07}));
    sum = vec_madd(sum, xinv, ((vector float){STIRLING_06, STIRLING_06, STIRLING_06, STIRLING_06}));
    sum = vec_madd(sum, xinv, ((vector float){STIRLING_05, STIRLING_05, STIRLING_05, STIRLING_05}));
    sum = vec_madd(sum, xinv, ((vector float){STIRLING_04, STIRLING_04, STIRLING_04, STIRLING_04}));
    sum = vec_madd(sum, xinv, ((vector float){STIRLING_03, STIRLING_03, STIRLING_03, STIRLING_03}));
    sum = vec_madd(sum, xinv, ((vector float){STIRLING_02, STIRLING_02, STIRLING_02, STIRLING_02}));
    sum = vec_madd(sum, xinv, ((vector float){STIRLING_01, STIRLING_01, STIRLING_01, STIRLING_01}));
    sum = vec_madd(sum, xinv, ((vector float){STIRLING_00, STIRLING_00, STIRLING_00, STIRLING_00}));

    sum = vec_madd(sum, sqrt2pi, zerof);
    sum = vec_madd(sum, _powf4(x, vec_sub(x, halff)), zerof);
    sresult = vec_madd(sum, _expf4(vec_or(x, signbit)), zerof);

    /*
     * Choose rational approximation or Stirling's result.
     */
    result = vec_sel(rresult, sresult, gt9p9);

    result = vec_sel(result, inf, gt38);

    /* For x < 0, use:
     * gamma(x) = pi/(x*gamma(-x)*sin(x*pi))
     */
    nresult = _divf4(pi, vec_madd(x, vec_madd(result, _sinf4(vec_madd(x, pi, zerof)), zerof), zerof));
    result = vec_sel(nresult, result, gt0);

    /*
     * x = non-positive integer, return NaN.
     */
    result = vec_sel(result, nan, vec_andc(vec_cmpeq(x, xtrunc), gt0));

    return result;
}

#endif /* _TGAMMAF4_H_ */




