/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _FDIMF4_H_
#define _FDIMF4_H_	1

#include <altivec.h>
#include <vec_types.h>

/*
 * FUNCTION
 *	vector double _fdimf4(vector float x, vector float y)
 *
 * DESCRIPTION
 *	The _fdimf4 function returns the larger of  x - y and zero for 
 *      each element of x and y.
 *
 */
static __inline vector float _fdimf4(vector float x, vector float y)
{
  vec_float4 result;

  vec_uint4 sign_mask = (vec_uint4) { 0x80000000, 0x80000000, 0x80000000, 0x80000000 };
  vec_uint4 snan_mask = (vec_uint4) { 0x00400000, 0x00400000, 0x00400000, 0x00400000 };
  vec_uint4 nan_threshold = (vec_uint4) { 0x7F800000, 0x7F800000, 0x7F800000, 0x7F800000 };

  vec_uint4 abs_x = vec_andc((vec_uint4)x,sign_mask);
  vec_uint4 abs_y = vec_andc((vec_uint4)y,sign_mask);

  result = (vec_and(vec_sub(x, y), (vector float)vec_cmpgt(x, y)));

  // Correct for NaNs in the input (and promote to sNaNs if detected)
  result = vec_sel(result,vec_or(y,(vec_float4)snan_mask),vec_cmpgt(abs_y,nan_threshold));
  result = vec_sel(result,vec_or(x,(vec_float4)snan_mask),vec_cmpgt(abs_x,nan_threshold));

  return result;
}

#endif /* _FDIMF4_H_ */
