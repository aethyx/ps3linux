/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _ATAN2F4_H_
#define _ATAN2F4_H_	1

#include "divf4.h"
#include "atanf4.h"

/*
 * FUNCTION
 *  vector float _atan2f4(vector float y, vector float x)
 *
 * DESCRIPTION
 *  The atan2f4 function returns a vector containing the angles
 *  whose tangets are y/x for the corresponding elements of the
 *  input vectors.
 *
 *  The reason this function exists is to use the signs of the
 *  arguments to determine the quadrant of the result. Consider
 *  sin(x)/cos(x) on the domain (-pi, pi]. Four quadrants are
 *  defined by the signs of sin and cos on this domain.
 *
 *  Special Cases:
 *	- If the corresponding elements of x and y are zero, the 
 *    resulting element is undefined.
 *
 */


static __inline vector float _atan2f4(vector float y, vector float x)
{
    vector float pi   = (vector float) {(float)SM_PI, (float)SM_PI, (float)SM_PI, (float)SM_PI};
    vector unsigned int signshift = (vector unsigned int) {31, 31, 31, 31};
    vector unsigned int truev = (vector unsigned int) {0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF};
    vector bool int quad1;
    vector bool int quad4;
    vector bool int xlt0;
    vector bool int yge0;
    vector bool int ylt0;

    vector float result;

    xlt0 = (vector bool int)vec_sra((vec_uint4)x, signshift);
    ylt0 = (vector bool int)vec_sra((vec_uint4)y, signshift);
    yge0 = (vector bool int)vec_xor((vec_uint4)ylt0, truev);

    quad1 = vec_and(ylt0, xlt0);
    quad4 = vec_and(yge0, xlt0);

    result = _atanf4(_divf4(y,x));
    result = vec_sel(result, vec_sub(result, pi), quad1);
    result = vec_sel(result, vec_add(result, pi), quad4);

    return result;
}

#endif /* _ATAN2F4_H_ */
