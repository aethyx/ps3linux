/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _LOG1PF4_H_
#define _LOG1PF4_H_	1

#include <altivec.h>
#include <vec_types.h>


#include "logf4.h"
#include "divf4.h"

#define LOG1PF4_P0 0.0000000000000000000000000e+00f
#define LOG1PF4_P1 1.0000000000000000000000000e+00f
#define LOG1PF4_P2 1.4220868022897381610647471e+00f
#define LOG1PF4_P3 5.4254553902256308361984338e-01f
#define LOG1PF4_P4 4.5971908823142115796400731e-02f

#define LOG1PF4_Q0 1.0000000000000000000000000e+00f
#define LOG1PF4_Q1 1.9220868007537357247116461e+00f
#define LOG1PF4_Q2 1.1702556461286610645089468e+00f
#define LOG1PF4_Q3 2.4040413392943396631018516e-01f
#define LOG1PF4_Q4 1.0637426466449625625521058e-02f


/*
 * FUNCTION
 *	vector float _log1pf4(vector float x)
 *
 * DESCRIPTION
 *	The function _log1pf4 computes the natural logarithm of x + 1 
 *	for each of the float word elements of x.
 *
 *
 */

static __inline vector float _log1pf4(vector float x) 
{
  vector float onef    = ((vector float){1.0f, 1.0f, 1.0f, 1.0f});
  vector float rangehi = ((vector float){ 0.35f,  0.35f,  0.35f,  0.35f});
  vector float rangelo = ((vector float){-0.35f, -0.35f, -0.35f, -0.35f});
  vector bool int use_log;
  vector float pr, qr;
  vector float eresult;
  vector float rresult;
  vector float result;

  use_log = vec_or(vec_cmpgt(x, rangehi), vec_cmplt(x, rangelo));

  /*
   * Calculate directly using log(x+1)
   */
  eresult = _logf4(vec_add(x, onef));

  /*
   * For x in [-0.35,0.35], use a rational approximation.
   */
  pr = vec_madd(x, ((vector float){LOG1PF4_P4, LOG1PF4_P4, LOG1PF4_P4, LOG1PF4_P4}), 
                   ((vector float){LOG1PF4_P3, LOG1PF4_P3, LOG1PF4_P3, LOG1PF4_P3}));
  qr = vec_madd(x, ((vector float){LOG1PF4_Q4, LOG1PF4_Q4, LOG1PF4_Q4, LOG1PF4_Q4}), 
                   ((vector float){LOG1PF4_Q3, LOG1PF4_Q3, LOG1PF4_Q3, LOG1PF4_Q3}));
  pr = vec_madd(pr, x, ((vector float){LOG1PF4_P2, LOG1PF4_P2, LOG1PF4_P2, LOG1PF4_P2}));
  qr = vec_madd(qr, x, ((vector float){LOG1PF4_Q2, LOG1PF4_Q2, LOG1PF4_Q2, LOG1PF4_Q2}));
  pr = vec_madd(pr, x, ((vector float){LOG1PF4_P1, LOG1PF4_P1, LOG1PF4_P1, LOG1PF4_P1}));
  qr = vec_madd(qr, x, ((vector float){LOG1PF4_Q1, LOG1PF4_Q1, LOG1PF4_Q1, LOG1PF4_Q1}));
  pr = vec_madd(pr, x, ((vector float){LOG1PF4_P0, LOG1PF4_P0, LOG1PF4_P0, LOG1PF4_P0}));
  qr = vec_madd(qr, x, ((vector float){LOG1PF4_Q0, LOG1PF4_Q0, LOG1PF4_Q0, LOG1PF4_Q0}));
  rresult = _divf4(pr, qr);

  /*
   * Select either direct calculation or rational approximation.
   */
  result = vec_sel(rresult, eresult, use_log);

  return result;
}

#endif /* _LOG1PF4_H_ */
