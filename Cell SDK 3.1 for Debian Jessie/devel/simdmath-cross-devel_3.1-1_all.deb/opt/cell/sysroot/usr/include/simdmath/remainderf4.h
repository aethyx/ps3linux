/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _REMAINDERF4_H_
#define _REMAINDERF4_H_	1

#include <altivec.h>
#include <vec_types.h>
#include "fmodf4.h"

/*
 * FUNCTION
 *      vector float _remainderf4(vector float x, vector float y)
 *
 * DESCRIPTION
 *      The _remainderf4 function computes the remainder of dividing each 
 *      element of x by the corresponding element of y.
 *
 * RETURNS
 *      The return value is x - (n*y), where n is the value x/y, rounded to 
 *      the nearest integer.  If this quotient is 1/2 (mod 1), it is rounded to
 *      the nearest even number reguardless of the current rounding mode.  If
 *      the return value is 0, it has the sign of x.
 *
 */
static __inline vector float _remainderf4(vector float x, vector float y)
{
  vec_uint4 sign_mask = (vec_uint4) { 0x80000000, 0x80000000, 0x80000000, 0x80000000 };
  vec_float4 zero = (vec_float4) { 0.0f, 0.0f, 0.0f, 0.0f };
  vec_float4 half = (vec_float4) { 0.5f, 0.5f, 0.5f, 0.5f };
  vec_float4 snan = (vec_float4)((vec_uint4){ 0x7FC00000, 0x7FC00000, 0x7FC00000, 0x7FC00000 });
  vec_uint4 exp_mask = (vec_uint4) { 0x7F800000, 0x7F800000, 0x7F800000, 0x7F800000 };
  vec_int4 near_denorm = (vec_int4) { 0x01000000, 0x01000000, 0x01000000, 0x01000000 };
  vec_uint4 clip_threshold = (vec_uint4) { 0x7F000000, 0x7F000000, 0x7F000000, 0x7F000000 };
  vec_uint4 sign = vec_and((vec_uint4)x,sign_mask);

  vec_uint4 x_zero = (vec_uint4)vec_cmpeq(vec_and((vec_uint4)x,exp_mask),(vec_uint4)zero);
  vec_uint4 y_zero = (vec_uint4)vec_cmpeq(vec_and((vec_uint4)y,exp_mask),(vec_uint4)zero);

  //  Force denormal inputs to correctly signed zeros
  x = vec_sel(x,(vec_float4)sign,x_zero);
  y = vec_sel(y,(vec_float4)sign,y_zero);

  vec_float4 abs_x = vec_abs(x);
  vec_float4 abs_y = vec_abs(y);

  vec_uint4 x_inf = (vec_uint4)vec_cmpeq((vec_uint4)abs_x,exp_mask);
  vec_uint4 y_inf = (vec_uint4)vec_cmpeq((vec_uint4)abs_y,exp_mask);

  vec_uint4 x_nan = (vec_uint4)vec_cmpgt((vec_uint4)abs_x,exp_mask);
  vec_uint4 y_nan = (vec_uint4)vec_cmpgt((vec_uint4)abs_y,exp_mask);

  vec_float4 result;

  //  If y is smaller than 2^127, then we can safely begin to
  //  process by computing:
  //  x mod 2y
  vec_float4 adj_x = vec_sel(x,_fmodf4(x,vec_add(y,y)),vec_cmplt((vec_uint4)abs_y,clip_threshold));
  
  //  Remove any sign bits
  adj_x = vec_andc(adj_x,(vec_float4)sign_mask);

  //  If y is less than 2^-125 (meaning higher exp)
  //  convert y to y/2
  vec_uint4 near_sel = (vec_uint4)vec_cmplt(abs_y,(vec_float4)near_denorm);
  vec_float4 adj_y = vec_sel(vec_madd(half,abs_y,zero),abs_y,near_sel);
  
  //  x = x - y
  vec_float4 cx1 = vec_sub(adj_x,abs_y);

  //  x = x - 2y
  vec_float4 cx2 = vec_sub(cx1,abs_y);

  vec_float4 tx1 = vec_sel(adj_x,vec_add(adj_x,adj_x),near_sel);
  vec_float4 tx2 = vec_sel(cx1,vec_add(cx1,cx1),near_sel);

  adj_x = vec_sel(adj_x,cx1,vec_cmpgt(tx1,adj_y));
  adj_x = vec_sel(adj_x,cx2,vec_cmpge(tx2,adj_y));

  result = adj_x;

  //  If x == 0, return x
  result = vec_sel(result,x,x_zero);

  //  If y == Inf, return x
  result = vec_sel(result,x,y_inf);

  //  If x is Inf, return sNaN
  result = vec_sel(result,snan,x_inf);

  //  If y is NaN, return sNaN(y)
  result = vec_sel(result,snan,y_nan);

  //  If x is NaN, return sNaN(x)
  result = vec_sel(result,snan,x_nan);

  // Sign bit is that of X if result is 0, otherwise correct it for bias
  sign = vec_sel(vec_xor(sign, vec_and((vec_uint4)adj_x,sign_mask)),sign,vec_cmpeq(result,zero));

  //  Add sign bit back in
  result = (vec_float4)vec_or(vec_andc((vec_uint4)result,sign_mask),sign);
 
  //  If y == 0, return sNaN
  result = vec_sel(result,snan,y_zero);

  return result;
}

#endif /* _REMAINDERF4_H_ */
