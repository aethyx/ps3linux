/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _LOG2F4_H_
#define _LOG2F4_H_	1

#include <altivec.h>
/*
 * FUNCTION
 *	vector float _log2f4(vector float x)
 *
 * DESCRIPTION
 *	The _log2f4 function computes log (base 2) on a vector if inputs 
 *      values x. The _log2f4 function is approximated as a polynomial of
 *      order 8 (C. Hastings, Jr, 1955).
 *
 *                   __8__
 *		     \
 *		      \ 
 *	log2f(1+x) =  /     Ci*x^i
 *                   /____
 *                    i=1
 *
 *	for x in the range 0.0 to 1.0
 *
 *	C1 =  1.4426898816672
 *	C2 = -0.72116591947498
 *	C3 =  0.47868480909345
 *	C4 = -0.34730547155299
 *	C5 =  0.24187369696082
 *	C6 = -0.13753123777116
 *	C7 =  0.052064690894143
 *	C8 = -0.0093104962134977
 *
 *	This function assumes that x is a non-zero positive value.
 *
 */
static __inline vector float _log2f4(vector float x)
{
  vector signed int exponent;
  vector float result;
  vector float x2, x4;
  vector float hi, lo;
  vector float vzero = ((vector float) { 0.0f, 0.0f, 0.0f, 0.0f });

  /* Extract the exponent from the input X. 
   */
  exponent = (vector signed int)vec_and(vec_sr((vector unsigned int)(x), ((vector unsigned int) { 23, 23, 23, 23 })), ((vector unsigned int) { 0xFF, 0xFF, 0xFF, 0xFF }));
  exponent = vec_add(exponent, ((vector signed int) { -127, -127, -127, -127 }));
  /* Compute the remainder after removing the exponent.
   */
  x = (vector float)vec_sub((vector signed int)(x), vec_sl(exponent, ((vector unsigned int) { 23, 23, 23, 23 })));

  /* Calculate the log2 of the remainder using the polynomial
   * approximation.
   */
  x = vec_sub(x, ((vector float) { 1.0f, 1.0f, 1.0f, 1.0f }));

  /* Instruction counts can be reduced if the polynomial was
   * computed entirely from nested (dependent) fma's. However, 
   * to reduce the number of pipeline stalls, the polygon is evaluated 
   * in two halves (hi amd lo). 
   */
  x2 = vec_madd(x, x, vzero);
  x4 = vec_madd(x2, x2, vzero);

  hi = vec_madd(x, ((vector float) { -0.0093104962134977f, -0.0093104962134977f, -0.0093104962134977f, -0.0093104962134977f }), ((vector float) { 0.052064690894143f, 0.052064690894143f, 0.052064690894143f, 0.052064690894143f }));
  hi = vec_madd(x, hi, ((vector float) { -0.13753123777116f, -0.13753123777116f, -0.13753123777116f, -0.13753123777116f }));
  hi = vec_madd(x, hi, ((vector float) {  0.24187369696082f,  0.24187369696082f,  0.24187369696082f,  0.24187369696082f }));
  hi = vec_madd(x, hi, ((vector float) { -0.34730547155299f, -0.34730547155299f, -0.34730547155299f, -0.34730547155299f }));
  lo = vec_madd(x, ((vector float) { 0.47868480909345f, 0.47868480909345f, 0.47868480909345f, 0.47868480909345f }), ((vector float) { -0.72116591947498f, -0.72116591947498f, -0.72116591947498f, -0.72116591947498f }));
  lo = vec_madd(x, lo, ((vector float) { 1.4426898816672f, 1.4426898816672f, 1.4426898816672f, 1.4426898816672f }));

  lo = vec_madd(x, lo, vzero);
  result = vec_madd(x4, hi, lo);

  /* Add the exponent back into the result.
   */
  result = vec_add(result, vec_ctf(exponent, 0));
  
  return (result);
}

#endif /* _LOG2F4_H_ */
