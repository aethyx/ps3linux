/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _FMODF4_H_
#define _FMODF4_H_	1

#include <altivec.h>
#include <vec_types.h>

/*
 * FUNCTION
 *	vector float _fmodf4(vector float x, vector float y)
 *
 * DESCRIPTION
 *	The _fmodf4 function computes the remainder of 4 quotients
 *	by dividing x by y. The return values are x - n*y, where n is
 *	the quotients of x/y, rounded towards zero.
 *
 */
static __inline vector float _fmodf4(vector float x, vector float y)
{

  vec_int4 n;
  vec_uint4 z;
  vec_uint4 abs_x, abs_y;
  vec_uint4 exp_x, exp_y;
  vec_uint4 zero_x, zero_y;
  vec_uint4 logb_x, logb_y;
  vec_uint4 mant_x, mant_y;
  vec_uint4 result, resultx, sign_x, mask;
  vec_uint4 sign_mask = (vec_uint4) { 0x80000000, 0x80000000, 0x80000000, 0x80000000 };
  vec_uint4 implied_1 = (vec_uint4) { 0x00800000, 0x00800000, 0x00800000, 0x00800000 };
  vec_uint4 mant_mask = (vec_uint4) { 0x007FFFFF, 0x007FFFFF, 0x007FFFFF, 0x007FFFFF };
  vec_int4 zero = (vec_int4) { 0, 0, 0, 0 };
  vec_uint4 vui_1 = (vec_uint4) { 0x00000001, 0x00000001, 0x00000001, 0x00000001 };
  vec_int4 vi_n1 = (vec_int4) { -1, -1, -1, -1 };
  vec_uint4 vui_23 = (vec_uint4) { 23, 23, 23, 23 };
  vec_uint4 vui_n127 = (vec_uint4) { -127, -127, -127, -127 };
  vec_uint4 exp_mask = (vec_uint4) { 0x7F800000,0x7F800000,0x7F800000,0x7F800000 };
  vec_uint4 nan_signal = (vec_uint4) { 0x7FC00000,0x7FC00000,0x7FC00000,0x7FC00000 };


  //  Extract the sign of x
  sign_x = vec_and((vec_uint4)x, sign_mask);

  //  Determine absolute values of inputs
  abs_x = (vec_uint4)vec_abs(x);
  abs_y = (vec_uint4)vec_abs(y);

  //  Extract the exponents, and shift them
  exp_x  = vec_sr(abs_x, vui_23);
  exp_y  = vec_sr(abs_y, vui_23);

  //  Set resultx if y > x
  resultx = (vec_uint4)vec_cmpgt(abs_y, abs_x);

  //  Check if either x or y is denormal
  zero_x = (vec_uint4)vec_cmpeq(exp_x, (vec_uint4)zero);  
  zero_y = (vec_uint4)vec_cmpeq(exp_y, (vec_uint4)zero);

  //  Force denormals to zeros (x needs to preserve sign)
  x = (vec_float4)vec_or(vec_andc((vec_uint4)x,zero_x),sign_x);
  y = (vec_float4)vec_andc((vec_uint4)y,zero_y);
  
  //  Compute the logb of x and y
  logb_x = vec_add(exp_x, vui_n127);
  logb_y = vec_add(exp_y, vui_n127);

  //  Extract the mantissas with the addition of an implied 1
  mant_x = vec_sel(implied_1, abs_x, mant_mask);
  mant_y = vec_sel(implied_1, abs_y, mant_mask);


  //  Determine how much we need to shift the elements by
  //  And then align them and subtract to perform a fixed-point mod
  n = vec_sub((vec_int4)logb_x, (vec_int4)logb_y);
  mask = (vec_uint4)vec_cmpgt(n, zero);

  //  As long as any element has a "1" in the LSB ...
  while( vec_any_eq(vec_and(mask,vui_1),vui_1) )
  {
    // Subtract
    z = vec_sub(mant_x, mant_y);

    // But only accept the elements which need it
    mant_x = vec_sel(mant_x, 
		     vec_sel(vec_add(mant_x, mant_x),
			     vec_add(z, z),
			     vec_cmpgt((vec_int4)z, vi_n1)),
		     mask);

    //  Generate a new mask
    n = vec_add(n, vi_n1);
    mask = (vec_uint4)vec_cmpgt(n, zero);
  }
  z = vec_sub(mant_x, mant_y);
  mant_x = vec_sel(mant_x, z, vec_cmpgt((vec_int4)z, vi_n1));


  //  Convert back to floating point
  

  //
  //  Begin count leading zeros...
  //
  
  vec_uchar16 av;
  vec_uchar16 cnt_hi, cnt_lo, cnt, tmp1, tmp2, tmp3;
  vec_uchar16 four    = vec_splat_u8(4);
  vec_uchar16 nib_cnt = (vec_uchar16){4, 3, 2, 2, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0};
  vec_uchar16 eight   = vec_splat_u8(8);
  vec_uchar16 sixteen = (vec_uchar16){16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16};
  vec_uchar16 twentyfour = (vec_uchar16){24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24};

  av = (vec_uchar16)(mant_x);

  cnt_hi = vec_perm(nib_cnt, nib_cnt, vec_sr(av, four));
  cnt_lo = vec_perm(nib_cnt, nib_cnt, av);

  cnt = vec_add(cnt_hi, vec_and(cnt_lo, vec_cmpeq(cnt_hi, four)));

  tmp1 = (vec_uchar16)vec_sl((vec_uint4)(cnt), (vec_uint4)(eight));
  tmp2 = (vec_uchar16)vec_sl((vec_uint4)(cnt), (vec_uint4)(sixteen));
  tmp3 = (vec_uchar16)vec_sl((vec_uint4)(cnt), (vec_uint4)(twentyfour));

  cnt = vec_add(cnt, vec_and(tmp1, vec_cmpeq(cnt, eight)));
  cnt = vec_add(cnt, vec_and(tmp2, vec_cmpeq(cnt, sixteen)));
  cnt = vec_add(cnt, vec_and(tmp3, vec_cmpeq(cnt, twentyfour)));
  
  vec_uint4 cntt = (vec_uint4)((vec_sr((vec_uint4)(cnt), (vec_uint4)(twentyfour))));

  vec_uint4 vui_8 = (vec_uint4) { 8, 8, 8, 8 };

  vec_uint4 z_cnt = vec_sub(cntt,vui_8);
  //
  //  End count leading zeros...
  //
 


  mant_x = vec_rl(vec_andc(mant_x, implied_1), z_cnt);
  exp_y = vec_sub(exp_y, z_cnt);

  //  Move the exponent back into the proper position
  exp_y = vec_rl(exp_y, vui_23);

  //  Merge the exponent, sign of x, and mantissa
  result = vec_sel(vec_or(sign_x,mant_x),exp_y,exp_mask);


  //  Force denorm results to zero
  result = vec_andc(result,vec_sr((vec_uint4)vec_cmpeq(exp_y,(vec_uint4)zero),vui_1));

  //  Force overflows to zero
  result = vec_andc(result,vec_sr((vec_uint4)vec_cmpgt(zero,(vec_int4)exp_y),vui_1));
  

  //  If the mantissa comes up zero, return properly signed 0
  result = vec_andc(result,vec_sr((vec_uint4)vec_cmpeq(mant_x,(vec_uint4)zero),vui_1));
  

  // Handle cases where result should return x
  result = vec_sel(result,(vec_uint4)x, resultx);

  // If y is Inf, force result to x
  result = vec_sel(result,(vec_uint4)x,vec_cmpeq(abs_y,exp_mask));


  //  If x is zero, force result to zero
  result = vec_sel(result, vec_or((vec_uint4)zero, sign_x), zero_x);

  // If x is Inf, force result to sNaN
  result = vec_sel(result,nan_signal,vec_cmpeq(abs_x,exp_mask));
  
  //  If y is zero, force result to sNaN
  result = vec_sel(result,nan_signal,zero_y);

  //  If either input is NaN, force to sNaN (perfer y over x in a tie)
  result = vec_sel(result,vec_or((vec_uint4)y,nan_signal),vec_cmpgt(abs_y,exp_mask));
  result = vec_sel(result,vec_or((vec_uint4)x,nan_signal),vec_cmpgt(abs_x,exp_mask));



  return ((vec_float4)result);

}

#endif // _FMODF4_H_
