/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _ILOGBF4_H_
#define _ILOGBF4_H_	1

#include <altivec.h>
#include <limits.h>
#include <vec_types.h>

/* 
 * FUNCTION
 *      vector signed int _ilogbf4(vector float x)
 *
 * DESCRIPTION
 *      The _ilogbf4 function returns the signed exponent in the floating-point
 *      input. 
 *
 */
static __inline vector signed int _ilogbf4(vector float x)
{
  vec_uint4 lzero        = (vector unsigned int) {0, 0, 0, 0};
  vec_uint4 exp_mask     = (vector unsigned int) {0xFF, 0xFF, 0xFF, 0xFF};
  vec_uint4 exp_shift    = (vector unsigned int) {23, 23, 23, 23};
  vec_uint4 exp_bias     = (vector unsigned int) {127, 127, 127, 127};
  vec_uint4 lFP_ILOGB0   = (vector unsigned int) {INT_MIN, INT_MIN, INT_MIN, INT_MIN};
  vec_uint4 lFP_ILOGBNAN = (vector unsigned int) {INT_MAX, INT_MAX, INT_MAX, INT_MAX};
  vec_uint4 linf  =        (vector unsigned int) {0x7F800000,
		                                          0x7F800000,
                                                  0x7F800000,
                                                  0x7F800000};

  vec_uint4 exp;
  vec_uint4 exp_unbias;
  vec_uint4 xabs;

  /* Coerce input dnorm to 0.
   * PPU does this for us during add operation.
   */
  x = vec_add(x, (vec_float4)lzero);

  exp  = vec_and(vec_sr((vec_uint4)x, exp_shift), exp_mask);

  xabs = (vec_uint4)vec_abs(x);

  exp_unbias = vec_sub(exp, exp_bias);

  /* Zero */
  exp = vec_sel(exp_unbias, lFP_ILOGB0, (vec_uint4)vec_cmpeq(xabs, lzero));

  /* NaN */
  exp = vec_sel(exp, lFP_ILOGBNAN, (vec_uint4)vec_cmpgt(xabs, linf));

  /* Infinite */
  exp = vec_sel(exp, lFP_ILOGBNAN, (vec_uint4)vec_cmpeq(xabs, linf));
		
  /* Denorm Exponent Correction */
  //exp = vec_sel(exp, lFP_ILOGB0, inf);

  return ((vec_int4)exp);
}

#endif /* _ILOGBF4_H_ */
