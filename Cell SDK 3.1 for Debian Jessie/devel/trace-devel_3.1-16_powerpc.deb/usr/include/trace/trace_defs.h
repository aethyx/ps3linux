/*
Licensed Materials - Property of IBM
© Copyright IBM Corp. 2007  All Rights Reserved.
*/
#ifndef __TRACE_DEFS_H__
#define __TRACE_DEFS_H__

#include <trace_basic_defs.h>

/* Payload pointer type: a pointer to a payload structure. */
typedef trace_payload_t* trace_payload_p;

/* Interval pointer type: a pointer to an interval structure. */
typedef void *trace_interval_p;

#endif
