/*
Licensed Materials - Property of IBM
© Copyright IBM Corp. 2007  All Rights Reserved.
*/
#ifndef __TRACE_DYNAMIC_H__
#define __TRACE_DYNAMIC_H__

#ifdef __cplusplus__
extern "C" {
#endif /* __cplusplus__ */

#include <trace_defs.h>

/*****************************************************************************
* Dynamic trace control (set at each level):
*****************************************************************************/

/*****************************************************************************
* Changes the control state of an event according to the requested value
* (trace_false=off or trace_true=on).
*****************************************************************************/
extern void trace_event_control(trace_event_id_t event_id, trace_bool_t value);

/*****************************************************************************
* Changes the state of all the group's events according to the requested
* value (trace_false=off or trace_true=on).
*****************************************************************************/
extern void trace_group_control(trace_group_t group, trace_bool_t value);

/*****************************************************************************
* Returns the current control state of an event.
*****************************************************************************/
extern trace_bool_t trace_event_get_control(trace_event_id_t event_id);

#ifdef __cplusplus__
}
#endif /* __cplusplus__ */

#endif
