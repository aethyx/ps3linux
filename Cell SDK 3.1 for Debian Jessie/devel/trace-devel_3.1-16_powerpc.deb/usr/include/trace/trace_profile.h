#ifndef __TRACE_PROFILE_H__
#define __TRACE_PROFILE_H__
/*
Licensed Materials - Property of IBM
© Copyright IBM Corp. 2007  All Rights Reserved.
*/

#ifdef __cplusplus__
extern "C" {
#endif /* __cplusplus__ */

/**************************************************************
  Interface to the data profiling                            
**************************************************************/
typedef void *trace_profile_handle ; 

/*********************************************************************************************
 Service activation: 
	Parameters 
	event_id 	- the event ID that has been defined in the group. 
	tm_sec 		- interval in 10 milisec units (4 => 40 milisecond interval).
	callback  	- a call back function that is called by the service with two output 
 			parameters (to be filled by the call back function)
	payload_ptr 	- a pointer to the trace record payload of size trace_payload_t (currently 80 chars).
  			The callback function should fill the payload with data.
 
	This function returns a handle (trace_profile_handle) to be used for service control.

*************************************************************************************************/
trace_profile_handle trace_profile_register(trace_event_id_t event_id, int tm_sec, void (*callback)(trace_payload_p payload_ptr) );

/*********************************************************************************************
 Service termination: 
   handle	-	the handle returned by trace_profile_register() 
*************************************************************************************************/
void trace_profile_unregister(trace_profile_handle handle);

/*********************************************************************************************
 Profile trace start: 
*************************************************************************************************/
void trace_profile_start(trace_profile_handle handle);

/*********************************************************************************************
 Profile trace pause: 
*************************************************************************************************/
void trace_profile_pause(trace_profile_handle handle);

#ifdef __cplusplus__
}
#endif /* __cplusplus__ */

#endif /* __TRACE_PROFILE_H__ */


