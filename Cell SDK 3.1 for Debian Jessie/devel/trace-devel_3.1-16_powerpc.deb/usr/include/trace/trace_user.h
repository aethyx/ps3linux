/*
Licensed Materials - Property of IBM
© Copyright IBM Corp. 2007  All Rights Reserved.
*/
#ifndef __TRACE_USER_H__
#define __TRACE_USER_H__

#ifdef __cplusplus__
extern "C" {
#endif /* __cplusplus__ */

#include <trace_defs.h>

/*****************************************************************************
* The PDT User API:
* The following functions are user (programmers) API functions. They are used
* to create user defined trace record at any desired location in the program.
*****************************************************************************/

/*****************************************************************************
* Writes a trace record with the provided payload. The user event id
* is defined by the user and should be the first element (long) in the
* payload. The payload is added to the trace record. On the SPE the
* payload array must be aligned on 16 bytes boundary.
*****************************************************************************/
extern void trace_user_event(trace_payload_p payload);

/*****************************************************************************
* Initiates an user interval that terminates when trace_user_interval_exit()
* is called. This function does NOT write a trace record. The function returns
* a pointer to a trace_interval type that must be used as a parameter to the
* trace_user_interval_exit() function.
*****************************************************************************/
extern trace_interval_p trace_user_interval_entry();

/*****************************************************************************
* Terminates an user interval that was initiated when trace_user_interval_entry()
* was called. The pointer to a trace interval is provided by the
* trace_user_interval_entry() function. The last parameter is an array of payload
* elements, i.e. the list of parameters to be part of the trace record. On the SPE
* this array must be aligned on 16 bytes boundary.
*****************************************************************************/
extern void trace_user_interval_exit(trace_interval_p user_interval, trace_payload_p payload);

#ifdef __cplusplus__
}
#endif /* __cplusplus__ */

#endif
