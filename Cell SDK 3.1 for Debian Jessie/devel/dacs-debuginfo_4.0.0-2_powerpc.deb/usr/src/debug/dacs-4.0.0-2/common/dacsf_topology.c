/* --------------------------------------------------------------  */
/* (C)Copyright 2008                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/*--------------------------------------------------------------------*/
/*   DaCS Fortran Bindings - c mapping implementation                 */
/*   The functions implemented here are called from Fortran code      */
/*   See dacsf_bindings.h for the external function prototypes        */
/*   and the specific implementation files.                           */
/*   Implementation files are grouped for spu space considerations.   */
/*--------------------------------------------------------------------*/
#include"dacs.h"
#include"dacsf_bindings.h"

/*--------------------------------------------------------------------*/
/*  DaCS Fortran API Wrappers.                                        */
/*  The C function names for the DaCS Fortran API wrappers follow     */
/*  the naming convention (dacs_init is used as an example):          */
/*                                                                    */
/*     Type                            Example wrapper name           */
/*     -------------------------       --------------------           */
/*     Function name                   dacsf_init_impl                */
/*     Upper Case Alias                DACSF_INIT                     */
/*     Lower Case Alias                dacsf_init                     */
/*     Singe Underscore Alias          dacsf_init_                    */
/*     Double Underscore Alias         dacsf_init__                   */
/*                                                                    */
/*  The macros FORTRAN_SUBR and FORTRAN_FUNC are used to generate     */
/*  the C function names and aliases for the Fortran bindings.        */
/*                                                                    */
/*  The Fortran compilers provide options to control the symbol name  */
/*  decoration:                                                       */
/*     Compiler  Options                                              */
/*     --------  -----------------------------------                  */
/*     gfortran   -fno-underscoring -fsecond-underscore               */
/*     xLF        -qextname -qnoextname -qmixed                       */
/*     PathScale  -fno-underscoring -fsecond-underscore               */
/*--------------------------------------------------------------------*/


/*--------------------------------------------------------------------*/
/* dacsf_topology.c                                                   */
/*--------------------------------------------------------------------*/
FORTRAN_SUBR(DACSF_GET_NUM_AVAIL_CHILDREN,
             dacsf_get_num_avail_children,(DACS_DE_TYPE_T *type_ptr,
                                           int32_t        *num_children,
                                           DACS_ERR_T     *rc_ptr))
{
  *rc_ptr = dacs_get_num_avail_children(*type_ptr,(uint32_t*)num_children);
}

FORTRAN_SUBR(DACSF_RESERVE_CHILDREN,
             dacsf_reserve_children,(DACS_DE_TYPE_T *type_ptr,
                                     int32_t        *num_children,
                                     int32_t        *de_list,
                                     DACS_ERR_T     *rc_ptr))
{
  *rc_ptr = dacs_reserve_children(*type_ptr,(uint32_t*)num_children,(de_id_t*)de_list);
}

#ifndef DACS_SPU
FORTRAN_SUBR(DACSF_RELEASE_DE_LIST,
             dacsf_release_de_list,(int32_t    *num_des_ptr,
                                    int32_t    *de_list,
                                    DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_release_de_list((uint32_t)*num_des_ptr,(de_id_t*)de_list);
}
#endif

