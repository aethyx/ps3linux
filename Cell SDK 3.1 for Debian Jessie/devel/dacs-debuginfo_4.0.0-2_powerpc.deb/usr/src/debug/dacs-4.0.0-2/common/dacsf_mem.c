/* --------------------------------------------------------------  */
/* (C)Copyright 2008                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/*--------------------------------------------------------------------*/
/*   DaCS Fortran Bindings - c mapping implementation                 */
/*   The functions implemented here are called from Fortran code      */
/*   See dacsf_bindings.h for the external function prototypes        */
/*   and the specific implementation files.                           */
/*   Implementation files are grouped for spu space considerations.   */
/*--------------------------------------------------------------------*/
#include <stdlib.h>
#include"dacs.h"
#include"dacsf_bindings.h"

/*--------------------------------------------------------------------*/
/*  DaCS Fortran API Wrappers.                                        */
/*  The C function names for the DaCS Fortran API wrappers follow     */
/*  the naming convention (dacs_init is used as an example):          */
/*                                                                    */
/*     Type                            Example wrapper name           */
/*     -------------------------       --------------------           */
/*     Function name                   dacsf_init_impl                */
/*     Upper Case Alias                DACSF_INIT                     */
/*     Lower Case Alias                dacsf_init                     */
/*     Singe Underscore Alias          dacsf_init_                    */
/*     Double Underscore Alias         dacsf_init__                   */
/*                                                                    */
/*  The macros FORTRAN_SUBR and FORTRAN_FUNC are used to generate     */
/*  the C function names and aliases for the Fortran bindings.        */
/*                                                                    */
/*  The Fortran compilers provide options to control the symbol name  */
/*  decoration:                                                       */
/*     Compiler  Options                                              */
/*     --------  -----------------------------------                  */
/*     gfortran   -fno-underscoring -fsecond-underscore               */
/*     xLF        -qextname -qnoextname -qmixed                       */
/*     PathScale  -fno-underscoring -fsecond-underscore               */
/*--------------------------------------------------------------------*/


/*--------------------------------------------------------------------*/
/* dacsf_mem.c                                                        */
/*--------------------------------------------------------------------*/
FORTRAN_SUBR(DACSF_MEM_CREATE,
             dacsf_mem_create,(pvoid_holder           addr,
                               int64_t                *mem_size_ptr,
                               DACS_MEM_ACCESS_MODE_T *rmt_access_mode_ptr,
                               DACS_MEM_ACCESS_MODE_T *lcl_access_mode_ptr,
                               int64_t                *mem_handle,
                               DACS_ERR_T             *rc_ptr))
{
#ifdef DACS_ERROR_CHECKING
  if (*mem_size_ptr<0) {
    *rc_ptr = DACS_ERR_INVALID_SIZE;
    return;
  }
#endif
  *rc_ptr = dacs_mem_create(dacsf_makeptr_impl(addr),(uint64_t)*mem_size_ptr,*rmt_access_mode_ptr,*lcl_access_mode_ptr,(dacs_mem_t*) mem_handle);
}

#ifndef DACS_SPU
FORTRAN_SUBR(DACSF_MEM_SHARE,
             dacsf_mem_share,(int32_t    *dst_de_ptr,
                              int64_t    *dst_pid_ptr,
                              int64_t    *mem_handle_ptr,
                              DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_mem_share((de_id_t)*dst_de_ptr,(dacs_process_id_t)*dst_pid_ptr,(dacs_mem_t)*mem_handle_ptr);
}
#endif

FORTRAN_SUBR(DACSF_MEM_REGISTER,
             dacsf_mem_register,(int32_t    *dst_de_ptr,
                                 int64_t    *dst_pid_ptr,
                                 int64_t    *mem_handle_ptr,
                                 DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_mem_register((de_id_t)*dst_de_ptr,(dacs_process_id_t)*dst_pid_ptr,(dacs_mem_t)*mem_handle_ptr);
}

FORTRAN_SUBR(DACSF_MEM_DEREGISTER,
             dacsf_mem_deregister,(int32_t    *dst_de_ptr,
                                   int64_t    *dst_pid_ptr,
                                   int64_t    *mem_handle_ptr,
                                   DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_mem_deregister((de_id_t)*dst_de_ptr,(dacs_process_id_t)*dst_pid_ptr,(dacs_mem_t)*mem_handle_ptr);
}

FORTRAN_SUBR(DACSF_MEM_ACCEPT,
             dacsf_mem_accept,(int32_t    *src_de_ptr,
                               int64_t    *src_pid_ptr,
                               int64_t    *mem_handle,
                               DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_mem_accept((de_id_t)*src_de_ptr,(dacs_process_id_t)*src_pid_ptr,(dacs_mem_t*)mem_handle);
}

FORTRAN_SUBR(DACSF_MEM_RELEASE,
             dacsf_mem_release,(int64_t    *mem_handle,
                                DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_mem_release((dacs_mem_t*)mem_handle);
}

FORTRAN_SUBR(DACSF_MEM_DESTROY,
             dacsf_mem_destroy,(int64_t    *mem_handle,
                                DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_mem_destroy((dacs_mem_t*)mem_handle);
}


//note the return value is a uint64 but the enum passed to fortran is a int32
FORTRAN_SUBR(DACSF_MEM_QUERY_LCL_PERM,
             dacsf_mem_query_lcl_perm,(int64_t                *mem_handle_ptr,
                                       DACS_MEM_ACCESS_MODE_T *mode,
                                       DACS_ERR_T             *rc_ptr))
{
  uint64_t value=0;
  *rc_ptr = dacs_mem_query((dacs_mem_t)*mem_handle_ptr,DACS_LCL_MEM_PERM,&value);
  *mode = (DACS_MEM_ACCESS_MODE_T)value; //assigning int32 from uint64
}

FORTRAN_SUBR(DACSF_MEM_QUERY_RMT_PERM,
             dacsf_mem_query_rmt_perm,(int64_t                *mem_handle_ptr,
                                       DACS_MEM_ACCESS_MODE_T *mode,
                                       DACS_ERR_T             *rc_ptr))
{
  uint64_t value=0;
  *rc_ptr = dacs_mem_query((dacs_mem_t)*mem_handle_ptr,DACS_RMT_MEM_PERM,&value);
  *mode = (DACS_MEM_ACCESS_MODE_T)value; //assigning int32 from uint64
}

FORTRAN_SUBR(DACSF_MEM_QUERY_SIZE,
             dacsf_mem_query_size,(int64_t    *mem_handle_ptr,
                                   int64_t    *mem_size,
                                   DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_mem_query((dacs_mem_t)*mem_handle_ptr,DACS_MEM_SIZE,(uint64_t*)mem_size);
#ifdef DACS_ERROR_CHECKING
  if ((*rc_ptr == DACS_SUCCESS) && (*mem_size<0)) {
    *rc_ptr = DACS_ERR_INVALID_SIZE;
  }
#endif
}

FORTRAN_SUBR(DACSF_MEM_QUERY_ADDR,
             dacsf_mem_query_addr,(int64_t    *mem_handle_ptr,
                                   int64_t    *addr,
                                   DACS_ERR_T *rc_ptr))
{
  uint64_t value=0;
  *rc_ptr = dacs_mem_query((dacs_mem_t)*mem_handle_ptr,DACS_MEM_ADDR,&value);
  *addr = (int64_t)value;
}

FORTRAN_SUBR(DACSF_MEM_LIMITS_QUERY,
             dacsf_mem_limits_query,(DACS_MEM_LIMITS_T *attr_ptr,
                                     int32_t           *tgt_de_ptr,
                                     int64_t           *tgt_pid_ptr,
                                     int64_t           *limit,
                                     DACS_ERR_T        *rc_ptr))
{
  *rc_ptr = dacs_mem_limits_query(*attr_ptr,*tgt_de_ptr,*tgt_pid_ptr,(uint64_t*)(limit));
}

FORTRAN_SUBR(DACSF_MEM_PUT,
             dacsf_mem_put,(int64_t           *dst_rmt_handle_ptr,
                            int64_t           *dst_offset_ptr,
                            int64_t           *src_lcl_handle_ptr,
                            int64_t           *src_offset_ptr,
                            int64_t           *mem_size_ptr,
                            int32_t           *wid_ptr,
                            DACS_ORDER_ATTR_T *order_attr_ptr,
                            DACS_BYTE_SWAP_T  *swap_ptr,
                            DACS_ERR_T        *rc_ptr))
{
#ifdef DACS_ERROR_CHECKING
  if (*mem_size_ptr<0) {
    *rc_ptr = DACS_ERR_INVALID_SIZE;
    return;
  }
#endif
  *rc_ptr = dacs_mem_put((dacs_mem_t)*dst_rmt_handle_ptr,
                         (uint64_t)*dst_offset_ptr,
                         (dacs_mem_t)*src_lcl_handle_ptr,
                         (uint64_t)*src_offset_ptr,
                         (uint64_t)*mem_size_ptr,
                         (dacs_wid_t)*wid_ptr,
                         *order_attr_ptr,
                         *swap_ptr);
}

FORTRAN_SUBR(DACSF_MEM_GET,
             dacsf_mem_get,(int64_t           *dst_lcl_handle_ptr,
                            int64_t           *dst_offset_ptr,
                            int64_t           *src_rmt_handle_ptr,
                            int64_t           *src_offset_ptr,
                            int64_t           *mem_size_ptr,
                            int32_t           *wid_ptr,
                            DACS_ORDER_ATTR_T *order_attr_ptr,
                            DACS_BYTE_SWAP_T  *swap_ptr,
                            DACS_ERR_T        *rc_ptr))
{
#ifdef DACS_ERROR_CHECKING
  if (*mem_size_ptr<0) {
    *rc_ptr = DACS_ERR_INVALID_SIZE;
    return;
  }
#endif
  *rc_ptr = dacs_mem_get((dacs_mem_t)*dst_lcl_handle_ptr,
                         (uint64_t)*dst_offset_ptr,
                         (dacs_mem_t)*src_rmt_handle_ptr,
                         (uint64_t)*src_offset_ptr,
                         (uint64_t)*mem_size_ptr,
                         (dacs_wid_t)*wid_ptr,
                         *order_attr_ptr,
                         *swap_ptr);
}

#ifdef DACS_ERROR_CHECKING
static DACS_ERR_T checkdmalist(dacs_dma_list_t dmalist[],int32_t dlcount)
{
  int x;
  for (x=0;x<dlcount;++x) {
//    printf("%s: checkdmalist index %d value %ld \n",__FILE__,x,(long int)dmalist[x].size);
    if (((int64_t)(dmalist[x].size))<0) return DACS_ERR_INVALID_SIZE;
  }
  return DACS_SUCCESS;

}
#endif
FORTRAN_SUBR(DACSF_MEM_PUT_LIST,
             dacsf_mem_put_list,(int64_t           *dst_rmt_handle_ptr,
                                 dacs_dma_list_t   *dst_list,
                                 int32_t           *dst_count_ptr,
                                 int64_t           *src_lcl_handle_ptr,
                                 dacs_dma_list_t   *src_list,
                                 int32_t           *src_count_ptr,
                                 int32_t           *wid_ptr,
                                 DACS_ORDER_ATTR_T *order_attr_ptr,
                                 DACS_BYTE_SWAP_T  *swap_ptr,
                                 DACS_ERR_T        *rc_ptr))
{
#ifdef DACS_ERROR_CHECKING
  if ((checkdmalist(dst_list,*dst_count_ptr)!= DACS_SUCCESS) ||
      (checkdmalist(src_list,*src_count_ptr)!= DACS_SUCCESS))
  {
     *rc_ptr = DACS_ERR_INVALID_SIZE;
     return;
  }
#endif
  *rc_ptr = dacs_mem_put_list((dacs_mem_t)*dst_rmt_handle_ptr,
                              dst_list,
                              (uint32_t)*dst_count_ptr,
                              (dacs_mem_t)*src_lcl_handle_ptr,
                              src_list,
                              (uint32_t)*src_count_ptr,
                              (dacs_wid_t)*wid_ptr,
                              *order_attr_ptr,
                              *swap_ptr);

}
FORTRAN_SUBR(DACSF_MEM_GET_LIST,
             dacsf_mem_get_list,(int64_t           *dst_lcl_handle_ptr,
                                 dacs_dma_list_t   *dst_list,
                                 int32_t           *dst_count_ptr,
                                 int64_t           *src_rmt_handle_ptr,
                                 dacs_dma_list_t   *src_list,
                                 int32_t           *src_count_ptr,
                                 int32_t           *wid_ptr,
                                 DACS_ORDER_ATTR_T *order_attr_ptr,
                                 DACS_BYTE_SWAP_T  *swap_ptr,
                                 DACS_ERR_T        *rc_ptr))
{
#ifdef DACS_ERROR_CHECKING
  if ((checkdmalist(dst_list,*dst_count_ptr)!= DACS_SUCCESS) ||
      (checkdmalist(src_list,*src_count_ptr)!= DACS_SUCCESS))
  {
     *rc_ptr = DACS_ERR_INVALID_SIZE;
     return;
  }
#endif
  *rc_ptr = dacs_mem_get_list((dacs_mem_t)*dst_lcl_handle_ptr,
                              dst_list,
                              (uint32_t)*dst_count_ptr,
                              (dacs_mem_t)*src_rmt_handle_ptr,
                              src_list,
                              (uint32_t)*src_count_ptr,
                              (dacs_wid_t)*wid_ptr,
                              *order_attr_ptr,
                              *swap_ptr);
}

