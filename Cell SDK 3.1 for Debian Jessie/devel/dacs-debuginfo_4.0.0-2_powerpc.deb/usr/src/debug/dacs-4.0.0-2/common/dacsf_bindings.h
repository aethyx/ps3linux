/* --------------------------------------------------------------  */
/* (C)Copyright 2008                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/*--------------------------------------------------------------------*/
/*   DaCS Fortran Bindings - c interfaces header file                 */
/*   The functions defined are called from Fortran code               */
/*--------------------------------------------------------------------*/
#ifndef _DACSF_COMMON_H_
#define _DACSF_COMMON_H_

#include <stdint.h>
#include <dacs.h>
typedef int64_t * pvoid_holder;
/*--------------------------------------------------------------------*/
/*  DaCS Fortran API Wrappers.                                        */
/*  The C function names for the DaCS Fortran API wrappers follow     */
/*  the naming convention (dacs_init is used as an example):          */
/*                                                                    */
/*     Type                            Example wrapper name           */
/*     -------------------------       --------------------           */
/*     Function name                   dacsf_init_impl                */
/*     Upper Case Alias                DACSF_INIT                     */
/*     Lower Case Alias                dacsf_init                     */
/*     Singe Underscore Alias          dacsf_init_                    */
/*     Double Underscore Alias         dacsf_init__                   */
/*                                                                    */
/*  The macros FORTRAN_SUBR and FORTRAN_FUNC are used to generate     */
/*  the C function names and aliases for the Fortran bindings.        */
/*                                                                    */
/*  The Fortran compilers provide options to control the symbol name  */
/*  decoration:                                                       */
/*     Compiler  Options                                              */
/*     --------  -----------------------------------                  */
/*     gfortran   -fno-underscoring -fsecond-underscore               */
/*     xLF        -qextname -qnoextname -qmixed                       */
/*     PathScale  -fno-underscoring -fsecond-underscore               */
/*--------------------------------------------------------------------*/

/* Fortran Subroutine Macro - return is always void */
#define FORTRAN_SUBR(UPPER,LOWER,PARAM) ALLF(UPPER,LOWER,LOWER##_impl,PARAM,void)

/* Fortran Function Macro - return is always specified */
#define FORTRAN_FUNC(UPPER,LOWER,PARAM,RETV) ALLF(UPPER,LOWER,LOWER##_impl,PARAM,RETV)

#define ALLF(UPPER,LOWER,LOWER_IMPL,PARAMS,RETV) \
extern RETV UPPER  PARAMS __attribute__((weak, alias(#LOWER_IMPL))); \
extern RETV LOWER  PARAMS __attribute__((weak, alias(#LOWER_IMPL))); \
extern RETV LOWER ##_ PARAMS __attribute__((weak, alias(#LOWER_IMPL))); \
extern RETV LOWER ##__ PARAMS __attribute__((weak, alias(#LOWER_IMPL))); \
extern RETV LOWER_IMPL  PARAMS

/*--------------------------------------------------------------------*/
/* dacsf_data_sync.c                                                  */
/*--------------------------------------------------------------------*/
extern void dacsf_test_impl(int32_t    *wid_ptr,
                            DACS_ERR_T *rc_ptr);

extern void dacsf_wait_impl(int32_t    *wid_ptr,
                            DACS_ERR_T *rc_ptr);

/*--------------------------------------------------------------------*/
/* dacsf_dma.c                                                        */
/*--------------------------------------------------------------------*/
extern void dacsf_remote_mem_create_impl(pvoid_holder              addr,
                                         int64_t                   *mem_size_ptr,
                                         DACS_MEMORY_ACCESS_MODE_T *access_mode_ptr,
                                         int64_t                   *mem,
                                         DACS_ERR_T                *rc_ptr);

extern void dacsf_remote_mem_share_impl(int32_t    *dst_de_ptr,
                                        int64_t    *dst_pid_ptr,
                                        int64_t    *mem_ptr,
                                        DACS_ERR_T *rc_ptr);

extern void dacsf_remote_mem_accept_impl(int32_t    *src_de_ptr,
                                         int64_t    *src_pid_ptr,
                                         int64_t    *mem,
                                         DACS_ERR_T *rc_ptr);

extern void dacsf_remote_mem_release_impl(int64_t    *mem,
                                          DACS_ERR_T *rc_ptr);

extern void dacsf_remote_mem_destroy_impl(int64_t    *mem,
                                          DACS_ERR_T *rc_ptr);

extern void dacsf_remote_mem_query_mode_impl(int64_t                   *mem_ptr,
                                             DACS_MEMORY_ACCESS_MODE_T *mode,
                                             DACS_ERR_T                *rc_ptr);

extern void dacsf_remote_mem_query_size_impl(int64_t    *mem_ptr,
                                             int64_t    *mem_size,
                                             DACS_ERR_T *rc_ptr);

extern void dacsf_remote_mem_query_addr_impl(int64_t    *mem_ptr,
                                             int64_t    *addr,
                                             DACS_ERR_T *rc_ptr);

extern void dacsf_put_impl(int64_t           *dst_remote_mem_ptr,
                            int64_t           *dst_remote_mem_offset_ptr,
                            pvoid_holder      src_addr,
                            int64_t           *mem_size_ptr,
                            int32_t           *wid_ptr,
                            DACS_ORDER_ATTR_T *order_attr_ptr,
                            DACS_BYTE_SWAP_T  *swap_ptr,
                            DACS_ERR_T        *rc_ptr);

extern void dacsf_get_impl(pvoid_holder      dst_addr,
                           int64_t           *src_remote_mem_ptr,
                           int64_t           *src_remote_mem_offset_ptr,
                           int64_t           *mem_size_ptr,
                           int32_t           *wid_ptr,
                           DACS_ORDER_ATTR_T *order_attr_ptr,
                           DACS_BYTE_SWAP_T  *swap_ptr,
                           DACS_ERR_T        *rc_ptr);

extern void dacsf_put_list_impl(int64_t           *dst_mem_ptr,
                                dacs_dma_list_t   *dst_list,
                                int32_t           *dst_count_ptr,
                                pvoid_holder      src_addr,
                                dacs_dma_list_t   *src_list,
                                int32_t           *src_count_ptr,
                                int32_t           *wid_ptr,
                                DACS_ORDER_ATTR_T *order_attr_ptr,
                                DACS_BYTE_SWAP_T  *swap_ptr,
                                DACS_ERR_T        *rc_ptr);

extern void dacsf_get_list_impl(pvoid_holder      dst_addr,
                                dacs_dma_list_t   *dst_list,
                                int32_t           *dst_count_ptr,
                                int64_t           *src_mem_ptr,
                                dacs_dma_list_t   *src_list,
                                int32_t           *src_count_ptr,
                                int32_t           *wid_ptr,
                                DACS_ORDER_ATTR_T *order_attr_ptr,
                                DACS_BYTE_SWAP_T  *swap_ptr,
                                DACS_ERR_T        *rc_ptr);

/*--------------------------------------------------------------------*/
/* dacsf_error.c                                                      */
/*--------------------------------------------------------------------*/
extern void dacsf_errhandler_reg_impl(void        *handler_ptr,
                                      int32_t     *flags_ptr,
                                      DACS_ERR_T  *rc_ptr);

extern void dacsf_strerror_impl(DACS_ERR_T *errcode_ptr,
                                char       *errstr,
                                int        errstr_len);

extern void dacsf_error_num_impl(int64_t     *error,
                                 DACS_ERR_T   *errcode);

extern void dacsf_error_code_impl(int64_t     *error,
                                  int32_t      *errcode,
                                  DACS_ERR_T   *rc_ptr);

extern void dacsf_error_str_impl(int64_t     *error,
                                 char         *errstr,
                                 DACS_ERR_T   *rc_ptr,
                                 int          errstr_len);

extern void dacsf_error_de_impl(int64_t     *error,
                                int32_t      *de,
                                DACS_ERR_T   *rc_ptr);

extern void dacsf_error_pid_impl(int64_t     *error,
                                 int64_t      *pid,
                                 DACS_ERR_T   *rc_ptr);

/*--------------------------------------------------------------------*/
/* dacsf_groups.c                                                     */
/*--------------------------------------------------------------------*/
extern void dacsf_group_init_impl(int64_t    *group,
                                  int32_t    *flags_ptr,
                                  DACS_ERR_T *rc_ptr);

extern void dacsf_group_add_member_impl(int32_t    *de_ptr,
                                        int64_t    *pid_ptr,
                                        int64_t    *group_ptr,
                                        DACS_ERR_T *rc_ptr);

extern void dacsf_group_close_impl(int64_t    *group_ptr,
                                   DACS_ERR_T *rc_ptr);

extern void dacsf_group_destroy_impl(int64_t    *group,
                                     DACS_ERR_T *rc_ptr);

extern void dacsf_group_accept_impl(int32_t    *de_ptr,
                                    int64_t    *pid_ptr,
                                    int64_t    *group,
                                    DACS_ERR_T *rc_ptr);

extern void dacsf_group_leave_impl(int64_t    *group,
                                   DACS_ERR_T *rc_ptr);

/*--------------------------------------------------------------------*/
/* dacsf_mailbox.c                                                    */
/*--------------------------------------------------------------------*/
extern void dacsf_mailbox_read_impl(int32_t    *msg,
                                    int32_t    *src_de_ptr,
                                    int64_t    *src_pid_ptr,
                                    DACS_ERR_T *rc_ptr);

extern void dacsf_mailbox_write_impl(int32_t    *msg,
                                     int32_t    *dst_de_ptr,
                                     int64_t    *dst_pid_ptr,
                                     DACS_ERR_T *rc_ptr);

extern void dacsf_mailbox_test_impl(DACS_TEST_MAILBOX_T *rw_flag_ptr,
                                    int32_t             *de_ptr,
                                    int64_t             *pid_ptr,
                                    int32_t             *mbox_status,
                                    DACS_ERR_T          *rc_ptr);

/*--------------------------------------------------------------------*/
/* dacsf_process.c                                                    */
/*--------------------------------------------------------------------*/
extern void dacsf_de_start_std_file_impl(int32_t                   *de_ptr,
                                         char                      *prog,
                                         char                      *argv,
                                         int                       *argv_size_ptr,
                                         char                      *envv,
                                         int                       *envv_size_ptr,
                                         DACS_PROC_CREATION_FLAG_T *creation_flags_ptr,
                                         int64_t                   *pid,
                                         DACS_ERR_T                *rc_ptr,
                                         int                       prog_len,
                                         int                       argv_len,
                                         int                       envv_len);

extern void dacsf_de_start_std_embedded_impl(int32_t    *de_ptr,
                                             void       *prog,
                                             char       *argv,
                                             int        *argv_size_ptr,
                                             char       *envv,
                                             int        *envv_size_ptr,
                                             int64_t    *pid,
                                             DACS_ERR_T *rc_ptr,
                                             int        argv_len,
                                             int        envv_len);

extern void dacsf_de_start_ptr_file_impl(int32_t                   *de_ptr,
                                         char                      *prog,
                                         pvoid_holder              argv,
                                         pvoid_holder              envv,
                                         DACS_PROC_CREATION_FLAG_T *creation_flags_ptr,
                                         int64_t                   *pid,
                                         DACS_ERR_T                *rc_ptr,
                                         int                       prog_len);

extern void dacsf_de_start_ptr_embedded_impl(int32_t      *de_ptr,
                                             void         *prog,
                                             pvoid_holder argv,
                                             pvoid_holder envv,
                                             int64_t      *pid,
                                             DACS_ERR_T   *rc_ptr);

extern void dacsf_num_processes_supported_impl(int32_t    *de_ptr,
                                               int32_t    *num_processes,
                                               DACS_ERR_T *rc_ptr);

extern void dacsf_num_processes_running_impl(int32_t    *de_ptr,
                                             int32_t    *num_processes,
                                             DACS_ERR_T *rc_ptr);

extern void dacsf_de_wait_impl(int32_t    *de_ptr,
                               int64_t    *pid_ptr,
                               int32_t    *exit_status,
                               DACS_ERR_T *rc_ptr);

extern void dacsf_de_test_impl(int32_t    *de_ptr,
                               int64_t    *pid_ptr,
                               int32_t    *exit_status,
                               DACS_ERR_T *rc_ptr);

extern void dacsf_de_kill_impl(int32_t    *de_ptr,
                               int64_t    *process_id_ptr,
                               DACS_KILL_TYPE_T  *kill_flags_ptr,
                               DACS_ERR_T *rc_ptr);

/*--------------------------------------------------------------------*/
/* dacsf_proc_sync.c                                                  */
/*--------------------------------------------------------------------*/
extern void dacsf_mutex_init_impl(int64_t    *mutex,
                                  DACS_ERR_T *rc_ptr);

extern void dacsf_mutex_share_impl(int32_t    *dst_de_ptr,
                                   int64_t    *dst_pid_ptr,
                                   int64_t    *mutex_ptr,
                                   DACS_ERR_T *rc_ptr);

extern void dacsf_mutex_accept_impl(int32_t    *remote_de_ptr,
                                    int64_t    *remote_pid_ptr,
                                    int64_t    *received_mutex,
                                    DACS_ERR_T *rc_ptr);

extern void dacsf_mutex_lock_impl(int64_t    *mutex_ptr,
                                  DACS_ERR_T *rc_ptr);

extern void dacsf_mutex_try_lock_impl(int64_t    *mutex_ptr,
                                      DACS_ERR_T *rc_ptr);

extern void dacsf_mutex_unlock_impl(int64_t    *mutex_ptr,
                                    DACS_ERR_T *rc_ptr);

extern void dacsf_mutex_release_impl(int64_t    *mutex,
                                     DACS_ERR_T *rc_ptr);

extern void dacsf_mutex_destroy_impl(int64_t    *mutex,
                                     DACS_ERR_T *rc_ptr);

extern void dacsf_barrier_wait_impl(int64_t    *group_ptr,
                                    DACS_ERR_T *rc_ptr);

/*--------------------------------------------------------------------*/
/* dacsf_runtime.c                                                    */
/*--------------------------------------------------------------------*/
extern void dacsf_runtime_init_impl(DACS_ERR_T *rc_ptr);

extern void dacsf_init_impl(int32_t *config_flags_ptr,
                            DACS_ERR_T *rc_ptr);

extern void dacsf_runtime_exit_impl(DACS_ERR_T *rc_ptr);

extern void dacsf_exit_impl(DACS_ERR_T *rc_ptr);


/*--------------------------------------------------------------------*/
/* dacsf_send_recv.c                                                  */
/*--------------------------------------------------------------------*/
extern void dacsf_recv_impl(pvoid_holder     dst_data,
                            int32_t          *len_ptr,
                            int32_t          *src_de_ptr,
                            int64_t          *src_pid_ptr,
                            int32_t          *stream_ptr,
                            int32_t          *wid_ptr,
                            DACS_BYTE_SWAP_T *swap_ptr,
                            DACS_ERR_T       *rc_ptr);

extern void dacsf_send_impl(pvoid_holder     src_data,
                            int32_t          *len_ptr,
                            int32_t          *dst_de_ptr,
                            int64_t          *dst_pid_ptr,
                            int32_t          *stream_ptr,
                            int32_t          *wid_ptr,
                            DACS_BYTE_SWAP_T *swap_ptr,
                            DACS_ERR_T       *rc_ptr);

/*--------------------------------------------------------------------*/
/* dacsf_topology.c                                                   */
/*--------------------------------------------------------------------*/
extern void dacsf_get_num_avail_children_impl(DACS_DE_TYPE_T *type_ptr,
                                              int32_t        *num_children,
                                              DACS_ERR_T     *rc_ptr);

extern void dacsf_reserve_children_impl(DACS_DE_TYPE_T *type_ptr,
                                        int32_t        *num_children,
                                        int32_t        *de_list,
                                        DACS_ERR_T     *rc_ptr);

extern void dacsf_release_de_list_impl(int32_t    *num_des_ptr,
                                       int32_t    *de_list,
                                       DACS_ERR_T *rc_ptr);

/*--------------------------------------------------------------------*/
/* dacsf_wids.c                                                       */
/*--------------------------------------------------------------------*/
extern void dacsf_wid_reserve_impl(int32_t    *wid,
                                   DACS_ERR_T *rc_ptr);

extern void dacsf_wid_release_impl(int32_t    *wid,
                                   DACS_ERR_T *rc_ptr);


/*--------------------------------------------------------------------*/
/* dacsf_mem.c                                                        */
/*--------------------------------------------------------------------*/
extern void dacsf_mem_create_impl(pvoid_holder           addr,
                                  int64_t                *mem_size_ptr,
                                  DACS_MEM_ACCESS_MODE_T *rmt_access_mode_ptr,
                                  DACS_MEM_ACCESS_MODE_T *lcl_access_mode_ptr,
                                  int64_t                *mem_handle,
                                  DACS_ERR_T             *rc_ptr);

extern void dacsf_mem_share_impl(int32_t    *dst_de_ptr,
                                 int64_t    *dst_pid_ptr,
                                 int64_t    *mem_handle_ptr,
                                 DACS_ERR_T *rc_ptr);

extern void dacsf_mem_register_impl(int32_t    *dst_de_ptr,
                                    int64_t    *dst_pid_ptr,
                                    int64_t    *mem_handle_ptr,
                                    DACS_ERR_T *rc_ptr);

extern void dacsf_mem_deregister_impl(int32_t    *dst_de_ptr,
                                      int64_t    *dst_pid_ptr,
                                      int64_t    *mem_handle_ptr,
                                      DACS_ERR_T *rc_ptr);

extern void dacsf_mem_accept_impl(int32_t    *src_de_ptr,
                                  int64_t    *src_pid_ptr,
                                  int64_t    *mem_handle_ptr,
                                  DACS_ERR_T *rc_ptr);

extern void dacsf_mem_release_impl(int64_t    *mem_handle,
                                   DACS_ERR_T *rc_ptr);

extern void dacsf_mem_destroy_impl(int64_t    *mem_handle,
                                   DACS_ERR_T *rc_ptr);

extern void dacsf_mem_query_lcl_perm_impl(int64_t                *mem_handle_ptr,
                                          DACS_MEM_ACCESS_MODE_T *mode,
                                          DACS_ERR_T             *rc_ptr);

extern void dacsf_mem_query_rmt_perm_impl(int64_t                *mem_handle_ptr,
                                          DACS_MEM_ACCESS_MODE_T *mode,
                                          DACS_ERR_T             *rc_ptr);

extern void dacsf_mem_query_size_impl(int64_t    *mem_handle_ptr,
                                      int64_t    *mem_size,
                                      DACS_ERR_T *rc_ptr);

extern void dacsf_mem_query_addr_impl(int64_t    *mem_handle_ptr,
                                      int64_t    *addr,
                                      DACS_ERR_T *rc_ptr);

extern void dacsf_mem_limits_query_impl(DACS_MEM_LIMITS_T *attr_ptr,
                                        int32_t           *tgt_de_ptr,
                                        int64_t           *tgt_pid_ptr,
                                        int64_t           *limit,
                                        DACS_ERR_T        *rc_ptr);

extern void dacsf_mem_put_impl(int64_t           *dst_rmt_handle_ptr,
                               int64_t           *dst_offset_ptr,
                               int64_t           *src_lcl_handle_ptr,
                               int64_t           *src_offset_ptr,
                               int64_t           *mem_size_ptr,
                               int32_t           *wid_ptr,
                               DACS_ORDER_ATTR_T *order_attr_ptr,
                               DACS_BYTE_SWAP_T  *swap_ptr,
                               DACS_ERR_T        *rc_ptr);

extern void dacsf_mem_get_impl(int64_t           *dst_lcl_handle_ptr,
                               int64_t           *dst_offset_ptr,
                               int64_t           *src_rmt_handle_ptr,
                               int64_t           *src_offset_ptr,
                               int64_t           *mem_size_ptr,
                               int32_t           *wid_ptr,
                               DACS_ORDER_ATTR_T *order_attr_ptr,
                               DACS_BYTE_SWAP_T  *swap_ptr,
                               DACS_ERR_T        *rc_ptr);

extern void dacsf_mem_put_list_impl(int64_t           *dst_rmt_handle_ptr,
                                    dacs_dma_list_t   *dst_list,
                                    int32_t           *dst_count_ptr,
                                    int64_t           *src_lcl_handle_ptr,
                                    dacs_dma_list_t   *src_list,
                                    int32_t           *src_count_ptr,
                                    int32_t           *wid_ptr,
                                    DACS_ORDER_ATTR_T *order_attr_ptr,
                                    DACS_BYTE_SWAP_T  *swap_ptr,
                                    DACS_ERR_T        *rc_ptr);

extern void dacsf_mem_get_list_impl(int64_t           *dst_lcl_handle_ptr,
                                    dacs_dma_list_t   *dst_list,
                                    int32_t           *dst_count_ptr,
                                    int64_t           *src_rmt_handle_ptr,
                                    dacs_dma_list_t   *src_list,
                                    int32_t           *src_count_ptr,
                                    int32_t           *wid_ptr,
                                    DACS_ORDER_ATTR_T *order_attr_ptr,
                                    DACS_BYTE_SWAP_T  *swap_ptr,
                                    DACS_ERR_T        *rc_ptr);
/*--------------------------------------------------------------------*/
/* dacsf_bindings.c                                                   */
/*--------------------------------------------------------------------*/
/*--------------------------------------------------------------------*/
/*   dacs_makevoid_ is NOT defined in dacsf_interface.h               */
/*   This function converts a void * refernce to an int64_t handle.   */
/*   Both 32 and 64 bit addressing is supported.                      */
/*   The closest corresponding data type to void * is in Fortran is   */
/*   an integer(kind=8) or dacs_int64_t.                              */
/*   To pass a C void * parameter to DaCS the Fortran program must    */
/*   first call the dacs_makevoid subroutine to obtain the 64bit      */
/*   handle for the void * address.  This handle can be used in the   */
/*   DaCS API and converted back to a void *pointer in the call to    */
/*   the standard DaCS C API.                                         */
/*--------------------------------------------------------------------*/
extern void dacsf_makevoid_impl(void     *in,
                           int64_t *out);

extern void * dacsf_makeptr_impl(int64_t *holder);
#endif // _DACSF_COMMON_H_
