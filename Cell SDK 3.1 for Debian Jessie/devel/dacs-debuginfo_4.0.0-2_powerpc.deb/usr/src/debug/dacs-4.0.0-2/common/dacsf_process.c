/* --------------------------------------------------------------  */
/* (C)Copyright 2008                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/*--------------------------------------------------------------------*/
/*   DaCS Fortran Bindings - c mapping implementation                 */
/*   The functions implemented here are called from Fortran code      */
/*   See dacsf_bindings.h for the external function prototypes        */
/*   and the specific implementation files.                           */
/*   Implementation files are grouped for spu space considerations.   */
/*--------------------------------------------------------------------*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include"dacs.h"
#include"dacsf_bindings.h"

/*--------------------------------------------------------------------*/
/*  DaCS Fortran API Wrappers.                                        */
/*  The C function names for the DaCS Fortran API wrappers follow     */
/*  the naming convention (dacs_init is used as an example):          */
/*                                                                    */
/*     Type                            Example wrapper name           */
/*     -------------------------       --------------------           */
/*     Function name                   dacsf_init_impl                */
/*     Upper Case Alias                DACSF_INIT                     */
/*     Lower Case Alias                dacsf_init                     */
/*     Singe Underscore Alias          dacsf_init_                    */
/*     Double Underscore Alias         dacsf_init__                   */
/*                                                                    */
/*  The macros FORTRAN_SUBR and FORTRAN_FUNC are used to generate     */
/*  the C function names and aliases for the Fortran bindings.        */
/*                                                                    */
/*  The Fortran compilers provide options to control the symbol name  */
/*  decoration:                                                       */
/*     Compiler  Options                                              */
/*     --------  -----------------------------------                  */
/*     gfortran   -fno-underscoring -fsecond-underscore               */
/*     xLF        -qextname -qnoextname -qmixed                       */
/*     PathScale  -fno-underscoring -fsecond-underscore               */
/*--------------------------------------------------------------------*/


/*--------------------------------------------------------------------*/
/* dacsf_process.c                                                    */
/*--------------------------------------------------------------------*/
#ifndef DACS_SPU
/*--------------------------------------------------------------------*/
/*  local utility routines                                            */
/*--------------------------------------------------------------------*/
static int findlastchar(char *ptr,int len);
static char * makecstring(char *p,int lastpos);
static char ** buildcstrings(char *fptr,int len,int count);

FORTRAN_SUBR(DACSF_DE_START_STD_FILE,
             dacsf_de_start_std_file,(int32_t                   *de_ptr,
                                      char                      *prog,
                                      char                      *argv,
                                      int                       *argv_size_ptr,
                                      char                      *envv,
                                      int                       *envv_size_ptr,
                                      DACS_PROC_CREATION_FLAG_T *creation_flags_ptr,
                                      int64_t                   *pid,
                                      DACS_ERR_T                *rc_ptr,
                                      int                       prog_len,
                                      int                       argv_len,
                                      int                       envv_len))
{

  int last = findlastchar(prog,prog_len);
  char * prog_ptr = makecstring(prog,last);

  char **argvptr = buildcstrings(argv,argv_len,*argv_size_ptr);

  char **envvptr = buildcstrings(envv,envv_len,*envv_size_ptr);

  //printf("%s: prog[%s]  de_id[0x%08lx]\n",__FILE__,prog_ptr,(long unsigned int)*de_ptr);
  *rc_ptr = dacs_de_start((de_id_t)*de_ptr,prog_ptr,(char const **)argvptr,(char const **)envvptr,*creation_flags_ptr,(dacs_process_id_t*)pid);
  if (prog_ptr != NULL) free(prog_ptr);
  if (argvptr != NULL) free(argvptr);
  if (envvptr != NULL) free(envvptr);

}

FORTRAN_SUBR(DACSF_DE_START_STD_EMBEDDED,
             dacsf_de_start_std_embedded,(int32_t    *de_ptr,
                                          void       *prog,
                                          char       *argv,
                                          int        *argv_size_ptr,
                                          char       *envv,
                                          int        *envv_size_ptr,
                                          int64_t    *pid,
                                          DACS_ERR_T *rc_ptr,
                                          int        argv_len,
                                          int        envv_len))
{

  char **argvptr = buildcstrings(argv,argv_len,*argv_size_ptr);

  char **envvptr = buildcstrings(envv,envv_len,*envv_size_ptr);

  *rc_ptr = dacs_de_start((de_id_t)*de_ptr,prog,(char const **)argvptr,(char const **)envvptr,DACS_PROC_EMBEDDED,(dacs_process_id_t*)pid);
  if (argvptr != NULL) free(argvptr);
  if (envvptr != NULL) free(envvptr);

}

FORTRAN_SUBR(DACSF_DE_START_PTR_FILE,
             dacsf_de_start_ptr_file,(int32_t                   *de_ptr,
                                      char                      *prog,
                                      pvoid_holder              argv,
                                      pvoid_holder              envv,
                                      DACS_PROC_CREATION_FLAG_T *creation_flags_ptr,
                                      int64_t                   *pid,
                                      DACS_ERR_T                *rc_ptr,
                                      int                       prog_len))
{
  int last = findlastchar(prog,prog_len);
  char * prog_ptr = makecstring(prog,last);
  //printf("%s: prog[%s]  de_id[0x%08lx]\n",__FILE__,prog_ptr,(long unsigned int)*de_ptr);
  *rc_ptr = dacs_de_start((de_id_t)*de_ptr,prog_ptr,(char const **)(dacsf_makeptr_impl(argv)),(char const **)(dacsf_makeptr_impl(envv)),*creation_flags_ptr,(dacs_process_id_t*)pid);
}

FORTRAN_SUBR(DACSF_DE_START_PTR_EMBEDDED,
             dacsf_de_start_ptr_embedded,(int32_t      *de_ptr,
                                          void         *prog,
                                          pvoid_holder argv,
                                          pvoid_holder envv,
                                          int64_t      *pid,
                                          DACS_ERR_T   *rc_ptr))
{
  *rc_ptr = dacs_de_start((de_id_t)*de_ptr,prog,(char const **)(dacsf_makeptr_impl(argv)),(char const **)(dacsf_makeptr_impl(envv)),DACS_PROC_EMBEDDED,(dacs_process_id_t*)pid);
}

//return 0 based position of last nonblank, return -1 when string is all blank or length is -1
static int findlastchar(char *ptr,int len) {
  int last;
  for (last=len-1;(last>=0) && (*(ptr+last)==' ');--last);
  //printf("%s: findlastchar %i\n",__FILE__,last);
  return last;
}
static char * makecstring(char *p,int lastpos) {
  char * sptr = NULL;
  if (lastpos>=0) {
    sptr = malloc(lastpos+2); //character count plus null
    memcpy(sptr,p,lastpos+1);
    *(sptr + lastpos +1) = 0;
    //printf("%s: makecstring[%s]\n",__FILE__,((sptr==NULL) ? "NULL" : sptr));
  }
  return sptr;
}

static char ** buildcstrings(char *fptr,int len,int count) {
  if (count ==0) return NULL;
  int caddrsize = (count+1) * sizeof(void *);   //size of the address area including the null terminating address at the end
  int cdatasize = len+1;   //size of one element with null, includes extra blank space from fortran
  int csize = (count * cdatasize) + caddrsize;  //size of dataarea plus address area
  char **caddr = malloc(csize);
  memset(caddr,0,csize);  // clear the whole data area to avoid setting nulls
  char * cdataptr = ((char *)caddr) + caddrsize;  //offset to data area
  int x;
  for (x=0;x<count;++x,fptr+=len,cdataptr+=cdatasize) {
    *(caddr+x) = cdataptr;
    int last = findlastchar(fptr,len);
    memcpy(cdataptr,fptr,last+1);
  }
  return caddr;
}
FORTRAN_SUBR(DACSF_NUM_PROCESSES_SUPPORTED,
             dacsf_num_processes_supported,(int32_t    *de_ptr,
                                            int32_t    *num_processes,
                                            DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_num_processes_supported((de_id_t)*de_ptr,(uint32_t*)num_processes);
  #ifdef DACS_ERROR_CHECKING
    if ((*rc_ptr == DACS_SUCCESS) && (*num_processes<0)) {
      *rc_ptr = DACS_ERR_INVALID_SIZE;
    }
  #endif
}

FORTRAN_SUBR(DACSF_NUM_PROCESSES_RUNNING,
             dacsf_num_processes_running,(int32_t    *de_ptr,
                                          int32_t    *num_processes,
                                          DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_num_processes_running((de_id_t)*de_ptr,(uint32_t*)num_processes);
  #ifdef DACS_ERROR_CHECKING
    if ((*rc_ptr == DACS_SUCCESS) && (*num_processes<0)) {
      *rc_ptr = DACS_ERR_INVALID_SIZE;
    }
  #endif
}


FORTRAN_SUBR(DACSF_DE_WAIT,
             dacsf_de_wait,(int32_t    *de_ptr,
                            int64_t    *pid_ptr,
                            int32_t    *exit_status,
                            DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_de_wait((de_id_t)*de_ptr,(dacs_process_id_t)*pid_ptr,exit_status);
}

FORTRAN_SUBR(DACSF_DE_TEST,
             dacsf_de_test,(int32_t    *de_ptr,
                            int64_t    *pid_ptr,
                            int32_t    *exit_status,
                            DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_de_test((de_id_t)*de_ptr,(dacs_process_id_t)*pid_ptr,exit_status);
}

FORTRAN_SUBR(DACSF_DE_KILL,
             dacsf_de_kill,(int32_t    *de_ptr,
                            int64_t    *process_id_ptr,
                            DACS_KILL_TYPE_T *kill_flags_ptr,
                            DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_de_kill((de_id_t)*de_ptr,(dacs_process_id_t)*process_id_ptr,(DACS_KILL_TYPE_T)*kill_flags_ptr);
}
#endif

