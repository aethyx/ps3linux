/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

// ident = "@(#) internal-src/lib/dacs/common/dacsi_shared_obj.h v1.12 - 9/16/08 09:55:35 @(#)"

#ifndef _DACSI_SHARED_OBJ_H_
#define _DACSI_SHARED_OBJ_H_

#include <dacs_atomic.h>
#include <dacs.h>

//
//  C++ interface
//
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

// Shared objects are cached on the SPE, define how many are held at a time
#define SPE_SHARED_OBJ_CACHE_SIZE 4

//  ---------------------------------------------------------------------
//
// DACS_SHARED_OBJ_NAME
// Shared objects contain a union with all the type-specific data in them.
// The DACSI_SHARED_OBJ_NAME indicates what sort of object is being shared.
//
// Note: The shared object names are tied directly to the streams used in the
//       send/recv handshake.  Thus, the name and the stream must be kept
//       in sync to preserve proper operation. 
//
//  ---------------------------------------------------------------------

typedef enum DACSI_SHARED_OBJ_NAME {
    DACSI_MUTEX_NAME      = 0xDAC50001,
    DACSI_REMOTE_MEM_NAME = 0xDAC50002,
    DACSI_GROUP_NAME      = 0xDAC50003,
    DACSI_ERROR_NAME      = 0xDAC50004,
    DACSI_INVALID_NAME    = 0xDAC5DEAD
} DACSI_SHARED_OBJ_NAME_T;

//  ---------------------------------------------------------------------
//
// DACS_SHARED_OBJ_STREAM
// Share/Accept uses send/recv under the covers for communications.  These 
// use streams that are above STREAM_UB
// Note: The streams are enumerated according to the LS nibble of the shared
//       object name, so it is simple to switch between name and stream ID.
typedef enum DACSI_INTERNAL_STREAMS {
    DACSI_MUTEX_STREAM       = DACS_STREAM_UB + 1,
    DACSI_REMOTE_MEM_STREAM  = DACS_STREAM_UB + 2,
    DACSI_GROUP_STREAM       = DACS_STREAM_UB + 3
} DACSI_INTERNAL_STREAM_NAME_T;

//  ---------------------------------------------------------------------
// This is used by the common code steering logic to indicate whether an 
// object was created on the cell (TIER_2) or on the host above it (TIER_1)
//  ---------------------------------------------------------------------

typedef enum DACS_TIER
{
        TIER_1 = 1,
        TIER_2 = 2,
} DACS_TIER_T;

//  ---------------------------------------------------------------------
// This is the definition of the actual mutex data structure that is used internally
// ---------------------------------------------------------------------

typedef struct dacsi_mutex {
    atomic_t                  lock;      // The mutex itself

    de_id_t                   lock_de;   // The deid that has this mutex locked
    dacs_process_id_t         lock_pid;  // The pid on lock_de that has this locked

} dacsi_mutex_t;

//  ----------------------------------------------------------------------
// The internal definition of a remote memory area
// ---------------------------------------------------------------------

// Each attribute should be a 64 bit type and arranged accoring to
// the DACS_REMOTE_MEM_ATTR_T enumeration.  This allows quick look-up by
// simply offsetting into the dacsi_remote_mem_t using the attribute type.
typedef struct dacsi_remote_mem {
    dacs_addr_64_t  base_addr;
    uint64_t        size;
    uint64_t        access;
    uint64_t        local_access;
} dacsi_remote_mem_t;


//  ----------------------------------------------------------------------
// The internal definition of a group
// ---------------------------------------------------------------------
typedef enum {
    DACSI_GROUP_DESTROYED = 1,
    DACSI_GROUP_OPEN      = 2,
    DACSI_GROUP_CLOSED    = 3
} DACS_GROUP_STATE_T;

// for now, we're going to use 32bits for the barrier and members elements,
// so that the ppu code can do a 32bit atomic operation - works for both the
// 32bit and 64bit libs, and works as long as we have <= 32 spu's. once this 
// requirement goes up, we'll have to use the 64bit element, and change the
// ppu and spu locks to be atomic64 and ldarx/stdcx.
typedef struct dacsi_group {
    union {
	uint32_t _barrier32[2];
	uint64_t _barrier64;
    };
    union {
	uint32_t _members32[2];
	uint64_t _members64;
    };
    volatile DACS_GROUP_STATE_T state;
} dacsi_group_t;  
typedef uint32_t dacsi_barrier_t;
#define dacsi_barrier _barrier32[1]
#define dacsi_members _members32[1]

//  ----------------------------------------------------------------------
// The internal definition of a shared object
// These are 128 bytes in size for atomic ops
// ---------------------------------------------------------------------
#define DACSI_SHARED_OBJ_T_SIZE 128

typedef struct dacsi_shared_obj {
    union {
        struct {
            // The name indicates what type of object is shared
            DACSI_SHARED_OBJ_NAME_T  name;

            // This is who created (and who is allowed to destroy this object
            de_id_t                  owner_de;
            dacs_process_id_t        owner_pid;
            DACS_TIER_T              tier; 

            // A count of how many other DEs this region has been shared with
            // this variable is modified with atomic inc and dec operations
            atomic_t                 refcnt;

            // The list info is used to clean up the structs on exit
            dacs_addr_64_t  prev;
            dacs_addr_64_t  next;

            // An anonymous union to hold the unique parts of the shared object
            union {
                dacsi_mutex_t        mutex;
                dacsi_remote_mem_t   remote_mem;
                dacsi_group_t        group;
            }; // end object-specific anonymous union

            dacs_addr_64_t           hybrid_data;
        }; // end struct
        char pad[DACSI_SHARED_OBJ_T_SIZE];
    }; // end union
} dacsi_shared_obj_t __attribute__ ((aligned(128)));


/*--------------------------------------------------------------------*/
/*  Function Prototypes                                               */
/*--------------------------------------------------------------------*/


DACS_ERR_T dacsi_shared_obj_create(  dacsi_shared_obj_t  **obj, 
                                     dacsi_shared_obj_t  **head,
                                     dacsi_shared_obj_t  **tail);

DACS_ERR_T dacsi_shared_obj_destroy( dacsi_shared_obj_t   *obj,
                                     dacsi_shared_obj_t  **head,
                                     dacsi_shared_obj_t  **tail);

void dacsi_shared_obj_dequeue(dacsi_shared_obj_t *obj,
                             dacsi_shared_obj_t **head,
                             dacsi_shared_obj_t **tail);

void dacsi_shared_obj_delete(dacsi_shared_obj_t* obj);

//
//  C++ interface
//
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif 
