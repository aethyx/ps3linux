/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

static char *ident = "@(#) internal-src/lib/dacs/common.dacs_topology.c v1.18 - 9/16/08 09:57:56 @(#)";

/*
 * dacs_topology.c - defines functions used for viewing, reserving, and releasing child DaCS Elements (DEs)
 */

/*--------------------------------------------------------------------*/
/*  Includes                                                          */
/*--------------------------------------------------------------------*/


#include <dacs.h>
#include <dacs_common.h>

#if defined(DACS_HYBRID)
#include <dacs_hybrid_topology.h>
#endif

#ifdef DACS_PPU
#include <dacs_ppu_topology.h>
#endif

/*--------------------------------------------------------------------*/
/*  Function Definitions                                              */
/*--------------------------------------------------------------------*/

DACS_ERR_T  dacs_get_num_avail_children( DACS_DE_TYPE_T  type,
                                         uint32_t       *num_children )
{

#ifdef DACS_ERROR_CHECKING
    if(!dacsi_is_init())                       return DACS_ERR_NOT_INITIALIZED;
    if(num_children == NULL)                   return DACS_ERR_INVALID_ADDR;
    if((type <= DACS_DE_INVALID )
       || (type >= DACS_DE_MAX_TYPE) ) return DACS_ERR_INVALID_ATTR;
#endif

    DACS_ERR_T rc = DACS_SUCCESS;
#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_get_num_avail_children(type, num_children);
#elif  defined(DACS_PPU)
    rc = dacs_ppu_get_num_avail_children(type, num_children);
#else
#error "Invalid platform or no platform specified"
#endif

    TRACE_POINT(_DACS_GET_NUM_AVAIL_CHILDREN, 1, type, (uintptr_t)num_children, 
                *num_children, rc);

    return rc;
}

/*--------------------------------------------------------------------*/
DACS_ERR_T dacs_reserve_children(DACS_DE_TYPE_T type,
                                 uint32_t       *num_children,
                                 de_id_t        *de_list )
{

#ifdef DACS_ERROR_CHECKING
    if(!dacsi_is_init())                       return DACS_ERR_NOT_INITIALIZED;
    if(num_children == NULL)                   return DACS_ERR_INVALID_ADDR;
    if(de_list == NULL)                        return DACS_ERR_INVALID_ADDR;
    if((type <= DACS_DE_INVALID )
       || (type >= DACS_DE_MAX_TYPE) )         return DACS_ERR_INVALID_ATTR;
    if(*num_children == 0)                     return DACS_ERR_INVALID_SIZE;
#endif

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_RESERVE_CHILDREN, token, 1, type, 
                      (uintptr_t)num_children, *num_children, 
                      (uintptr_t)de_list);

    DACS_ERR_T rc = DACS_SUCCESS;
#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_reserve_children(type, num_children, de_list);
#elif  defined(DACS_PPU)
    rc = dacs_ppu_reserve_children(type, num_children, de_list);
#else
#error "Invalid platform or no platform specified"
#endif

    TRACE_POINT_EXIT(_DACS_RESERVE_CHILDREN,token,1,rc,*num_children,de_list);

    return rc;
}

/*--------------------------------------------------------------------*/
DACS_ERR_T  dacs_release_de_list(uint32_t  num_des,
                                 de_id_t  *de_list )
{
#ifdef DACS_ERROR_CHECKING
    if(!dacsi_is_init())                       return DACS_ERR_NOT_INITIALIZED;
    if(de_list == NULL)                   return DACS_ERR_INVALID_ADDR;
    if(num_des == 0)                   return DACS_ERR_INVALID_SIZE;
#endif

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_RELEASE_DE_LIST, token, 1, num_des, 
                      (uintptr_t)de_list);

    DACS_ERR_T rc = DACS_SUCCESS;
#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_release_de_list(num_des, de_list);
#elif  defined(DACS_PPU)
    rc = dacs_ppu_release_de_list(num_des, de_list);
#else
#error "Invalid platform or no platform specified"
#endif

    TRACE_POINT_EXIT(_DACS_RELEASE_DE_LIST,token,1,rc,num_des,de_list);

    return rc;
}

