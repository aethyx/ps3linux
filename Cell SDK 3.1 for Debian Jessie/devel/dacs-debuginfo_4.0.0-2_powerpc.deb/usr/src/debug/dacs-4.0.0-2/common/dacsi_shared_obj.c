/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

static char *ident = "@(#) internal-src/lib/dacs/common/dacsi_shared_obj.c v1.12 - 9/16/08 09:55:36 @(#)";

#include <dacs.h>

//#include <ppu_atomic.h>        //For atomic functions

#include <dacs_common.h>

#include <errno.h>

#define _XOPEN_SOURCE 600     // required for for posix memalign 
#include <stdlib.h>           // for posix_memalign

//#include <dacs_debug.h>

//  -----   local prototypes    -----

/// dacsi__shared_obj_create is used to malloc and initialize all of the parts of the
/// shared_obj that are not unique (parts not specific to shared_mem, mutex, barrier).
/// the caller then initializes their object-specific version of the structs
DACS_ERR_T  dacsi_shared_obj_create( dacsi_shared_obj_t **obj,  
                                     dacsi_shared_obj_t **head,
                                     dacsi_shared_obj_t **tail)
{
    int err;
    // Allocate the aligned object 
    err     = posix_memalign((void **) obj, DACSI_SHARED_OBJ_T_SIZE, (sizeof(dacsi_shared_obj_t)));
    if(err) return DACS_ERR_NO_RESOURCE;


    // Manage the list of shared objects
    if((*head == NULL) && (*tail == NULL)) {
        // This is the first thing on the list
        (*obj)->prev                  = 0;
        (*obj)->next                  = 0;
        *head                         = *obj;
        *tail                         = *obj;
    } else {
        // There is an existing shared object, add this to the end
        (*obj)->prev                  = (dacs_addr_64_t)(uintptr_t) *tail;
        (*obj)->next                  = 0;
        (*tail)->next                 = (dacs_addr_64_t)(uintptr_t) *obj;
        *tail                         = *obj;
    } 

    // Claim ownership of this object
    (*obj)->owner_de  = dacsi_local_de_id;
    (*obj)->owner_pid = dacsi_local_pid;

    // Init the refcount that is incremented on a share, decremented on a destroy
    // dacspi_atomic_replace(&((*obj)->refcnt), 0);
    (*obj)->refcnt = 0;
    (*obj)->hybrid_data = 0;

    return DACS_SUCCESS;
}

DACS_ERR_T dacsi_shared_obj_destroy( dacsi_shared_obj_t *obj,
                                     dacsi_shared_obj_t **head,
                                     dacsi_shared_obj_t **tail)
{
    dacsi_shared_obj_dequeue(obj,head,tail);
    dacsi_shared_obj_delete(obj);
    return DACS_SUCCESS;
}


void dacsi_shared_obj_dequeue(dacsi_shared_obj_t *obj,
                              dacsi_shared_obj_t **head,
                              dacsi_shared_obj_t **tail)
{
    // Unlink this destroyed object from the list
    if(*head == obj) *head = (dacsi_shared_obj_t *)(uintptr_t) obj->next;
    if(*tail == obj) *tail = (dacsi_shared_obj_t *)(uintptr_t) obj->prev;

    if(obj->next) ((dacsi_shared_obj_t *)(uintptr_t) obj->next)->prev = obj->prev;
    if(obj->prev) ((dacsi_shared_obj_t *)(uintptr_t) obj->prev)->next = obj->next;
}

void dacsi_shared_obj_delete(dacsi_shared_obj_t* obj)
{
    uint32_t delay = 2;
    // We own this shared object - spin while everyone else decrements the refcnt
    while((volatile int) obj->refcnt) {
        usleep(delay);
        delay =  delay < 1024 ? delay*2 : 1024;

    }

    // Then invalidate the structure so that it can't be used until it's reinitialised
    obj->name = DACSI_INVALID_NAME;

    // No users of the object so it can safely be deleted
    free(obj);
}


//  =====   INTERNAL FUNCTIONS  ========================================


//  =====   CONSTRUCTOR and DESTRUCTOR

///
///
///
DACS_ERR_T  dacsi_shared_obj_init(    void * argvp, void *envp )
{

    return  DACS_SUCCESS;
}

///
///
///
DACS_ERR_T  dacsi_shared_obj_exit(    void )
{

    return  DACS_SUCCESS;
}

