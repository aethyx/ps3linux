/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

static char *ident = "@(#) internal-src/lib/dacs/common/dacs_send_recv.c v1.20 - 9/16/08 09:56:59 @(#)";

/*
 * dacs_send_recv.c - defines functions used for DaCS message passing
 */

/*--------------------------------------------------------------------*/
/*  Includes                                                          */
/*--------------------------------------------------------------------*/

#include <dacs.h>
#include <dacs_common.h>

#if defined(DACS_HYBRID)
#include <dacs_hybrid_send_recv.h>
#endif

#ifdef DACS_PPU
#include <dacs_ppu_send_recv.h>
#endif

/*--------------------------------------------------------------------*/
/*  Function Definitions                                              */
/*--------------------------------------------------------------------*/

DACS_ERR_T  dacs_recv(  void               *dst_data,
                        uint32_t            len,
                        de_id_t             src_de,
                        dacs_process_id_t   src_pid,
                        uint32_t            stream,
                        dacs_wid_t          wid,
                        DACS_BYTE_SWAP_T    swap)
{
#ifdef DACS_ERROR_CHECKING
    if(!dacsi_initialized)  return DACS_ERR_NOT_INITIALIZED;
    if (!dst_data)          return DACS_ERR_INVALID_ADDR;
    if ((stream > DACS_STREAM_UB) &&
        (stream != DACS_STREAM_ALL)) return DACS_ERR_INVALID_STREAM;
    if ((swap != DACS_BYTE_SWAP_DISABLE) &&
        (swap != DACS_BYTE_SWAP_HALF_WORD) &&
        (swap != DACS_BYTE_SWAP_WORD) &&
        (swap != DACS_BYTE_SWAP_DOUBLE_WORD)) return DACS_ERR_INVALID_ATTR;

    // can't receive a message from yourself
    if (src_de == DACS_DE_SELF || src_pid == DACS_PID_SELF)
        return DACS_ERR_INVALID_TARGET;

    // We must be using a valid wid 
    if (wid >= DACS_MAX_PPE_WIDS)
        return DACS_ERR_INVALID_WID;

    // The wid must have been reserved
    if (!DACSI_IS_WID_RESERVED(wid))
        return DACS_ERR_INVALID_WID;
#endif

    DACS_ERR_T rc = DACS_SUCCESS;

    TRACE_TIMER_TOKEN(timer_token);
    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_RECV,token,1,(uintptr_t)dst_data,len,src_de,src_pid,stream,wid,swap);
    TRACE_TIMER_START(timer_token);

#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_recv(dst_data, len, src_de, src_pid, stream, wid, swap);
#elif  defined(DACS_HYBRID) && defined(DACS_PPU)
    if (src_de == DACS_DE_PARENT) {
        rc = dacs_hybrid_recv(dst_data, len, src_de, src_pid, stream, wid, swap);
    } else {
        rc = dacs_ppu_recv(dst_data, len, src_de, src_pid, stream, wid, swap);
    }
#elif  !defined(DACS_HYBRID) && defined(DACS_PPU)
        rc = dacs_ppu_recv(dst_data, len, src_de, src_pid, stream, wid, swap);
#else
#error "Invalid platform or no platform specified"
#endif

    if (rc == DACS_SUCCESS) {
	TRACE_COUNTER_INCREMENT(dacs_recv_count,1);
	TRACE_COUNTER_INCREMENT(dacs_recv_bytes,len);
    }
    TRACE_TIMER_END(dacs_recv,timer_token);
    TRACE_POINT_EXIT(_DACS_RECV,token,1,rc);

    return rc;
}

/*--------------------------------------------------------------------*/
DACS_ERR_T dacs_send(   void                *src_data,
                        uint32_t            len,
                        de_id_t             dst_de,
                        dacs_process_id_t   dst_pid,
                        uint32_t            stream,
                        dacs_wid_t          wid,
                        DACS_BYTE_SWAP_T    swap)
{
#ifdef DACS_ERROR_CHECKING
    if(!dacsi_initialized)  return DACS_ERR_NOT_INITIALIZED;
    if (!src_data)          return DACS_ERR_INVALID_ADDR;
    if (stream > DACS_STREAM_UB) return DACS_ERR_INVALID_STREAM;
    if ((swap != DACS_BYTE_SWAP_DISABLE) &&
        (swap != DACS_BYTE_SWAP_HALF_WORD) &&
        (swap != DACS_BYTE_SWAP_WORD) &&
        (swap != DACS_BYTE_SWAP_DOUBLE_WORD)) return DACS_ERR_INVALID_ATTR;

    // can't send a message to yourself
    if (dst_de == DACS_DE_SELF || dst_pid == DACS_PID_SELF)
        return DACS_ERR_INVALID_TARGET;

    // We must be using a valid wid 
    if (wid >= DACSI_WID_MAX)
        return DACS_ERR_INVALID_WID;

    // The wid must have been reserved
    if (!DACSI_IS_WID_RESERVED(wid))
        return DACS_ERR_INVALID_WID;
#endif
    DACS_ERR_T rc = DACS_SUCCESS;
    if(!dacsi_initialized) {
        return DACS_ERR_NOT_INITIALIZED;
    }

    TRACE_TIMER_TOKEN(timer_token);
    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_SEND, token, 1, (uintptr_t)src_data, len, dst_de, dst_pid,
                      stream, wid, swap);
    TRACE_TIMER_START(timer_token);

#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_send(src_data, len, dst_de, dst_pid, stream, wid, swap );
#elif  defined(DACS_HYBRID) && defined(DACS_PPU)
    if (dst_de == DACS_DE_PARENT) {
        rc = dacs_hybrid_send(src_data, len, dst_de, dst_pid, stream, wid, 
                              swap);
    } else {
        rc = dacs_ppu_send(src_data, len, dst_de, dst_pid, stream, wid, swap );
    }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
        rc = dacs_ppu_send(src_data, len, dst_de, dst_pid, stream, wid, swap );
#else
#error "Invalid platform or no platform specified"
#endif

    if (rc == DACS_SUCCESS) {
	    TRACE_COUNTER_INCREMENT(dacs_send_count,1);
	    TRACE_COUNTER_INCREMENT(dacs_send_bytes,len);
    }
    TRACE_TIMER_END(dacs_send,timer_token);
    TRACE_POINT_EXIT(_DACS_SEND,token,1,rc);

    return rc;
}
