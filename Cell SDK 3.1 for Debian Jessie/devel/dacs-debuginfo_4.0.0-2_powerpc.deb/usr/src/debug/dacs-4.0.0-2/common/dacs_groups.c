/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

// @(#) internal-src/lib/dacs/common/dacs_groups.c v1.25 - 9/16/08 09:57:56 @(#)

/*
 * dacs_groups.c - defines functions for controlling DaCS groups
 */

/*--------------------------------------------------------------------*/
/*  Includes                                                          */
/*--------------------------------------------------------------------*/

#include <dacs.h>
#include <dacs_common.h>

#if defined(DACS_HYBRID)
#include <dacs_hybrid_group.h>
#endif

#ifdef DACS_PPU
#include <dacs_ppu_groups.h>
#endif

/*--------------------------------------------------------------------*/
/*  Function Definitions                                              */
/*--------------------------------------------------------------------*/

DACS_ERR_T  dacs_group_init(    dacs_group_t  *group,
                                uint32_t      flags )
{

#ifdef DACS_ERROR_CHECKING
    if(!dacsi_is_init())                       return DACS_ERR_NOT_INITIALIZED;
    if(group == NULL)                          return DACS_ERR_INVALID_ADDR;
    if(flags != 0)                             return DACS_ERR_INVALID_ATTR;
#endif


    DACS_ERR_T  rc = DACS_SUCCESS;
#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_group_init( group, flags );
#elif  defined(DACS_PPU)
    rc = dacs_ppu_group_init( group, flags );
#else
#error "Invalid platform or no platform specified"
#endif

    TRACE_POINT(_DACS_GROUP_INIT,1,(uintptr_t)group,flags,*group,rc);

    return rc;
}

/*--------------------------------------------------------------------*/
DACS_ERR_T  dacs_group_add_member( de_id_t            de,
                                   dacs_process_id_t  pid,
                                   dacs_group_t       group ) 
{

#ifdef DACS_ERROR_CHECKING
    if(!dacsi_is_init())                       return DACS_ERR_NOT_INITIALIZED;
    if(group == 0)                             return DACS_ERR_INVALID_HANDLE;
#endif

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_GROUP_ADD_MEMBER,token,1,de,pid,group);

    DACS_ERR_T  rc = DACS_SUCCESS;
#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_group_add_member( de, pid, group);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_hybrid_group_add_member( de, pid, group);
    if(rc != DACS_ERR_NOT_OWNER) {
        rc = dacs_ppu_group_add_member( de, pid, group);
    }
#elif defined(DACS_PPU)
    rc = dacs_ppu_group_add_member( de, pid, group);
#else
#error "Invalid platform or no platform specified"
#endif

    TRACE_POINT_EXIT(_DACS_GROUP_ADD_MEMBER,token,1,rc);

    return rc;
}

/*--------------------------------------------------------------------*/
DACS_ERR_T  dacs_group_close( dacs_group_t group ){

#ifdef DACS_ERROR_CHECKING
    if(!dacsi_is_init())                       return DACS_ERR_NOT_INITIALIZED;
    if(group == 0)                             return DACS_ERR_INVALID_HANDLE;
#endif

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_GROUP_CLOSE,token,1,group);

    DACS_ERR_T  rc = DACS_SUCCESS;
#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_group_close(group);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_hybrid_group_close(group);
    if (rc == DACS_ERR_INVALID_HANDLE)
        rc = dacs_ppu_group_close(group);
#elif defined(DACS_PPU)
    rc = dacs_ppu_group_close(group);
#else
#error "Invalid platform or no platform specified"
#endif

    TRACE_POINT_EXIT(_DACS_GROUP_CLOSE,token,1,rc);

    return rc;
}

/*--------------------------------------------------------------------*/
DACS_ERR_T  dacs_group_destroy(dacs_group_t *group) {

#ifdef DACS_ERROR_CHECKING
    if(!dacsi_is_init())                        return DACS_ERR_NOT_INITIALIZED;
    if(group == NULL)                           return DACS_ERR_INVALID_ADDR;
    if(*group == 0)                             return DACS_ERR_INVALID_HANDLE;
#endif

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_GROUP_DESTROY,token,1,(uintptr_t)group,*group);

    DACS_ERR_T rc = DACS_SUCCESS;
#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_group_destroy(group);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_hybrid_group_destroy(group);
    if (rc == DACS_ERR_INVALID_HANDLE)
        rc = dacs_ppu_group_destroy(group);
#elif defined(DACS_PPU)
    rc = dacs_ppu_group_destroy(group);
#else
#error "Invalid platform or no platform specified"
#endif

    TRACE_POINT_EXIT(_DACS_GROUP_DESTROY,token,1,rc,*group);

    return rc;
}

/*--------------------------------------------------------------------*/
DACS_ERR_T  dacs_group_accept( de_id_t            de,
                               dacs_process_id_t  pid,
                               dacs_group_t       *group )
{

#ifdef DACS_ERROR_CHECKING
    if(!dacsi_is_init())                        return DACS_ERR_NOT_INITIALIZED;
    if(group == NULL)                           return DACS_ERR_INVALID_ADDR;
    if(de == DACS_DE_SELF)                      return DACS_ERR_INVALID_TARGET;
#endif

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_GROUP_ACCEPT,token,1,de,pid,(uintptr_t)group);

    DACS_ERR_T  rc = DACS_SUCCESS;
#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_group_accept( de, pid, group);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_hybrid_group_accept( de, pid, group);
#elif defined(DACS_PPU)
    rc = dacs_ppu_group_accept( de, pid, group);
#else
#error "Invalid platform or no platform specified"
#endif

    TRACE_POINT_EXIT(_DACS_GROUP_ACCEPT,token,1,rc,*group);

    return rc;
}

/*--------------------------------------------------------------------*/
DACS_ERR_T dacs_group_leave( dacs_group_t *group) {

#ifdef DACS_ERROR_CHECKING
    if(!dacsi_is_init())                        return DACS_ERR_NOT_INITIALIZED;
    if(group == NULL)                           return DACS_ERR_INVALID_ADDR;
    if(*group == 0)                             return DACS_ERR_INVALID_HANDLE;
#endif

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_GROUP_LEAVE,token,1,(uintptr_t)group,*group);

    DACS_ERR_T rc = DACS_SUCCESS;
#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_group_leave(group);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_hybrid_group_leave(group);
    if (rc == DACS_ERR_INVALID_HANDLE)
        rc = dacs_ppu_group_leave(group);
#elif defined(DACS_PPU)
    rc = dacs_ppu_group_leave(group);
#else
#error "Invalid platform or no platform specified"
#endif

    TRACE_POINT_EXIT(_DACS_GROUP_LEAVE,token,1,rc,*group);

    return rc;
}
