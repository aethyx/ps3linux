/* --------------------------------------------------------------  */
/* (C)Copyright 2008                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/**
 * Common DaCS Support for Memory Region Interfaces
 */ 

/*--------------------------------------------------------------------*/
/*  Includes                                                          */
/*--------------------------------------------------------------------*/

#include <dacsi_mem.h>
#include <dacs.h>
#include <dacs_common.h>
#include <dacs_trace.h>
#include <dacsi_shared_obj.h>

#include <stdlib.h>

#ifdef DACS_HYBRID
#include <dacs_hybrid_mem.h>

// This method is made available here so the process can handle incoming
// messages while waiting for the shared object to clean up
void dacsi_hybrid_ml_progress();
#endif


#ifdef DACS_PPU
#include <dacs_ppu_mem.h>
#endif

/*--------------------------------------------------------------------*/
/*  User Types                                                        */
/*--------------------------------------------------------------------*/

/*--------------------------------------------------------------------*/
/*  Constants                                                         */
/*--------------------------------------------------------------------*/

/*--------------------------------------------------------------------*/
/*  Macros                                                            */
/*--------------------------------------------------------------------*/

#ifdef DACS_ERROR_CHECKING
#define MEM_ADDR_TO_OBJ(mem) dacsi_find_mem_by_local_id(mem)
#else
#define MEM_ADDR_TO_OBJ(mem) (dacsi_shared_obj_t*)(uintptr_t)(mem)
#endif

/*--------------------------------------------------------------------*/
/*  Internal Function Prototypes                                      */
/*--------------------------------------------------------------------*/

static dacsi_shared_obj_t * dacsi_find_mem_by_local_id(dacs_mem_t mem);

/*--------------------------------------------------------------------*/
/*  Global Variables                                                  */
/*--------------------------------------------------------------------*/

pthread_mutex_t dacsi_mem_lock = PTHREAD_MUTEX_INITIALIZER;

struct dacsi_mem_list dacsi_mem_list;

/*--------------------------------------------------------------------*/
/* >>> Function <<<                                                   */
/*--------------------------------------------------------------------*/

DACS_ERR_T dacs_mem_create(void *                 addr,
                           uint64_t               size,
                           DACS_MEM_ACCESS_MODE_T rmt_access_mode,
                           DACS_MEM_ACCESS_MODE_T lcl_access_mode,
                           dacs_mem_t             *mem)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized)  return DACS_ERR_NOT_INITIALIZED;
    if ((addr == NULL) || (mem == NULL)) return DACS_ERR_INVALID_ADDR;
    if (size == 0) return DACS_ERR_INVALID_SIZE;
    if (((rmt_access_mode != DACS_MEM_READ_ONLY)  &&
         (rmt_access_mode != DACS_MEM_WRITE_ONLY) &&
         (rmt_access_mode != DACS_MEM_READ_WRITE) &&
         (rmt_access_mode != DACS_MEM_NONE))      ||
        ((lcl_access_mode != DACS_MEM_READ_ONLY)  &&
         (lcl_access_mode != DACS_MEM_WRITE_ONLY) &&
         (lcl_access_mode != DACS_MEM_READ_WRITE) &&
         (lcl_access_mode != DACS_MEM_NONE))) return DACS_ERR_INVALID_ATTR;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MEM_CREATE, token, 1, (uintptr_t)addr, size, 
    		rmt_access_mode, lcl_access_mode, (uintptr_t)mem);

    DACS_MUTEX_LOCK(&dacsi_mem_lock);
    dacsi_shared_obj_t* mem_handle = NULL;
    dacs_rc = dacsi_shared_obj_create(&mem_handle,
                                      &dacsi_mem_list.head,
                                      &dacsi_mem_list.tail);

    if (dacs_rc == DACS_SUCCESS) {
        // Save region information
        mem_handle->name = DACSI_REMOTE_MEM_NAME;
        mem_handle->remote_mem.base_addr    = (uintptr_t)addr;
        mem_handle->remote_mem.size         = size;
        mem_handle->remote_mem.access       = rmt_access_mode;
        mem_handle->remote_mem.local_access = lcl_access_mode;

#ifdef DACS_HYBRID
        dacs_rc = dacs_hybrid_mem_create(mem_handle);

        if (dacs_rc == DACS_SUCCESS) {
            // Successfully created the memory region
        } else {
            // Failed creating the hybrid area
            dacsi_shared_obj_destroy(mem_handle,
                                     &dacsi_mem_list.head,
                                     &dacsi_mem_list.tail);
        }
#endif

        // Return the new handle back to the caller
        *mem = (dacs_mem_t)(uintptr_t)mem_handle;
    } else {
        // Failed creating the shared object
        // Invalidate the handle in case they attempt to use it
        *mem = 0;
    }
    DACS_MUTEX_UNLOCK(&dacsi_mem_lock);

    TRACE_POINT_EXIT(_DACS_MEM_CREATE, token, 1, dacs_rc, *mem);

    return dacs_rc ;
}

/*--------------------------------------------------------------------*/

DACS_ERR_T dacs_mem_destroy(dacs_mem_t * mem)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized) return DACS_ERR_NOT_INITIALIZED;
    if (mem == NULL)        return DACS_ERR_INVALID_ADDR;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MEM_DESTROY, token, 1, *mem);

    DACS_MUTEX_LOCK(&dacsi_mem_lock);
    dacsi_shared_obj_t *mem_handle = MEM_ADDR_TO_OBJ(*mem);

#ifdef DACS_ERROR_CHECKING
    if (mem_handle == NULL) {
        // Handle was invalid or not allocated anymore
        dacs_rc = DACS_ERR_INVALID_HANDLE;
    }

    if (dacs_rc != DACS_SUCCESS) {
        DACS_MUTEX_UNLOCK(&dacsi_mem_lock);
        return dacs_rc;
    }
#endif

#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    dacs_rc = dacs_hybrid_mem_destroy(mem_handle);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    dacs_rc = dacs_hybrid_mem_destroy(mem_handle);
    if (!dacs_rc) {
        dacs_rc = dacs_ppu_mem_destroy(mem);
    }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    dacs_rc = dacs_ppu_mem_destroy(mem);
#else
#error "Invalid platform or no platform specified"
#endif
    if (dacs_rc == DACS_SUCCESS) {
        // Remove the element from access now that we have done our basic
        // cleanup. This will stop any new users of this memory handle
        dacsi_shared_obj_dequeue(mem_handle,
                                 &dacsi_mem_list.head,
                                 &dacsi_mem_list.tail);
    
        DACS_MUTEX_UNLOCK(&dacsi_mem_lock);

        // Totally destroy when all references go away
#if defined (DACS_HYBRID)
        // Need to wait here for the refcnt to drop to zero so we can
        // safely delete the hybrid data before the shared object is
        // totally destroyed
        while(mem_handle->refcnt) {
            dacsi_hybrid_ml_progress();
        }
#endif
        dacsi_mem_destroy(mem_handle);

        // Set the handle to an uninitialized value for safety
        *mem = 0; 
    } else {
        // The destroy failed - just release the lock and return the
        // failure to the caller
        DACS_MUTEX_UNLOCK(&dacsi_mem_lock);
    }

    TRACE_POINT_EXIT(_DACS_MEM_DESTROY, token, 1, dacs_rc);

    return dacs_rc ;
}

/*--------------------------------------------------------------------*/

DACS_ERR_T dacs_mem_share(de_id_t           dst_de,
                          dacs_process_id_t dst_pid,
                          dacs_mem_t        mem)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized)  return DACS_ERR_NOT_INITIALIZED;
    if ((dst_de == DACS_DE_SELF) || (dst_pid == DACS_PID_SELF)) return DACS_ERR_INVALID_TARGET;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MEM_SHARE, token, 1, dst_de, dst_pid, mem);

    // Get a lock on the remote mem list
    DACS_MUTEX_LOCK(&dacsi_mem_lock);

    dacsi_shared_obj_t * mem_handle = MEM_ADDR_TO_OBJ(mem);
#ifdef DACS_ERROR_CHECKING
    // Handle was invalid or not allocated anymore
    if (mem_handle == NULL) {
        dacs_rc = DACS_ERR_INVALID_HANDLE;
    } else if (mem_handle->remote_mem.access == DACS_MEM_NONE) {
        // This region was not set up for remote access
        dacs_rc = DACS_ERR_NO_PERM;
    }

    if (dacs_rc != DACS_SUCCESS)  {
        DACS_MUTEX_UNLOCK(&dacsi_mem_lock);
        return dacs_rc;
    }
#endif

    // Now call the platform specific implementation
#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    dacs_rc = dacs_hybrid_mem_share(dst_de,dst_pid,mem_handle);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    if (dst_de == DACS_DE_PARENT) {
        dacs_rc = dacs_hybrid_mem_share(dst_de,dst_pid,mem_handle);
    } else {
        dacs_rc = dacs_ppu_mem_share(dst_de,dst_pid,mem);
    }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    dacs_rc = dacs_ppu_mem_share(dst_de,dst_pid,mem);
#else
#error "Invalid platform or no platform specified"
#endif

    // Release the lock on the mem list
    DACS_MUTEX_UNLOCK(&dacsi_mem_lock);

    TRACE_POINT_EXIT(_DACS_MEM_SHARE, token, 1, dacs_rc);

    return dacs_rc ;
}

/*--------------------------------------------------------------------*/

DACS_ERR_T dacs_mem_accept(de_id_t src_de,
                           dacs_process_id_t src_pid,
                           dacs_mem_t * mem)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized)  return DACS_ERR_NOT_INITIALIZED;
    if (!mem)                return DACS_ERR_INVALID_ADDR;
    if ((src_de == DACS_DE_SELF) || (src_pid == DACS_PID_SELF)) return DACS_ERR_INVALID_TARGET;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MEM_ACCEPT, token, 1, src_de, src_pid, (uintptr_t)mem);

#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    dacs_rc = dacs_hybrid_mem_accept(src_de,src_pid,mem);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    if (src_de  == DACS_DE_PARENT) {
        dacs_rc = dacs_hybrid_mem_accept(src_de,src_pid,mem);
    } else {
        dacs_rc = dacs_ppu_mem_accept(src_de,src_pid,mem);
    }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    dacs_rc = dacs_ppu_mem_accept(src_de,src_pid,mem);
#else
#error "Invalid platform or no platform specified"
#endif

    TRACE_POINT_EXIT(_DACS_MEM_ACCEPT, token, 1, dacs_rc, *mem);

    return dacs_rc ;
}

/*--------------------------------------------------------------------*/

DACS_ERR_T dacs_mem_release(dacs_mem_t * mem)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized) return DACS_ERR_NOT_INITIALIZED;
    if (!mem)               return DACS_ERR_INVALID_ADDR;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MEM_RELEASE, token, 1, *mem);

    DACS_MUTEX_LOCK(&dacsi_mem_lock);

    dacsi_shared_obj_t *mem_handle = MEM_ADDR_TO_OBJ(*mem);

#ifdef DACS_ERROR_CHECKING
    // Handle was invalid or not allocated anymore
    if (mem_handle == NULL) {
        dacs_rc = DACS_ERR_INVALID_HANDLE;
    }

    if (dacs_rc != DACS_SUCCESS)  {
        DACS_MUTEX_UNLOCK(&dacsi_mem_lock);
        return dacs_rc;
    }
#endif

    // Now call the platform specific implementation
#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    dacs_rc = dacs_hybrid_mem_release(mem_handle);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    if (mem_handle->owner_de == DACS_DE_PARENT) {
        dacs_rc = dacs_hybrid_mem_release(mem_handle);
    } else {
        // only other option is that we are the owner - error
        dacs_rc = DACS_ERR_OWNER;
    }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    dacs_rc = dacs_ppu_mem_release(mem);
#else
#error "Invalid platform or no platform specified"
#endif

    if (!dacs_rc) {
        *mem = 0; // Set the handle to an uninitialized value
    }

    DACS_MUTEX_UNLOCK(&dacsi_mem_lock);

    TRACE_POINT_EXIT(_DACS_MEM_RELEASE, token, 1, dacs_rc);

    return dacs_rc ;
}

/*--------------------------------------------------------------------*/

DACS_ERR_T dacs_mem_register(de_id_t dst_de,
                             dacs_process_id_t dst_pid,
                             dacs_mem_t mem)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized)  return DACS_ERR_NOT_INITIALIZED;
    if ((dst_de == DACS_DE_SELF) || (dst_pid == DACS_PID_SELF))
        return DACS_ERR_INVALID_TARGET;
#endif

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MEM_REGISTER, token, 1, dst_de, dst_pid, mem);

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    DACS_MUTEX_LOCK(&dacsi_mem_lock);

    dacsi_shared_obj_t *mem_handle = MEM_ADDR_TO_OBJ(mem);
#ifdef DACS_ERROR_CHECKING
    if (mem_handle == NULL) {
        // Handle was invalid or not allocated anymore
        dacs_rc = DACS_ERR_INVALID_HANDLE;
    } else if (mem_handle->remote_mem.local_access == DACS_MEM_NONE) {
        // This region was not set up for local access
       dacs_rc = DACS_ERR_NO_PERM;
    }

    if (dacs_rc != DACS_SUCCESS) {
        DACS_MUTEX_UNLOCK(&dacsi_mem_lock);
        return dacs_rc;
    }
#endif

#if    defined(DACS_HYBRID) && !defined(DACS_PPU)
    dacs_rc = dacs_hybrid_mem_register(dst_de,dst_pid,mem_handle);
#elif  defined(DACS_HYBRID) &&  defined(DACS_PPU)
    if (dst_de == DACS_DE_PARENT) {
        dacs_rc = dacs_hybrid_mem_register(dst_de,dst_pid,mem_handle);
    } else {
        dacs_rc = dacs_ppu_mem_register(dst_de,dst_pid,mem);
    }
#elif !defined(DACS_HYBRID) &&  defined(DACS_PPU)
    dacs_rc = dacs_ppu_mem_register(dst_de,dst_pid,mem);
#else
#error "Invalid platform or no platform specified"
#endif

    DACS_MUTEX_UNLOCK(&dacsi_mem_lock);

    TRACE_POINT_EXIT(_DACS_MEM_REGISTER, token, 1, dacs_rc);

    return dacs_rc ;
}

/*--------------------------------------------------------------------*/

DACS_ERR_T dacs_mem_deregister(de_id_t dst_de,
                               dacs_process_id_t dst_pid,
                               dacs_mem_t mem)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized)  return DACS_ERR_NOT_INITIALIZED;
    if ((dst_de == DACS_DE_SELF) || (dst_pid == DACS_PID_SELF))
        return DACS_ERR_INVALID_TARGET;
#endif

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MEM_DEREGISTER, token, 1, dst_de, dst_pid, mem);

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    DACS_MUTEX_LOCK(&dacsi_mem_lock);

    dacsi_shared_obj_t *mem_handle = MEM_ADDR_TO_OBJ(mem);
#ifdef DACS_ERROR_CHECKING
    if (mem_handle == NULL) {
       // Memory handle not found
        DACS_MUTEX_UNLOCK(&dacsi_mem_lock);
        return DACS_ERR_INVALID_HANDLE;
    }
#endif

#if    defined(DACS_HYBRID) && !defined(DACS_PPU)
    dacs_rc = dacs_hybrid_mem_deregister(dst_de,dst_pid,mem_handle);
#elif  defined(DACS_HYBRID) &&  defined(DACS_PPU)
    if (dst_de == DACS_DE_PARENT) {
        dacs_rc = dacs_hybrid_mem_deregister(dst_de,dst_pid,mem_handle);
    } else {
        dacs_rc = dacs_ppu_mem_deregister(dst_de,dst_pid,mem);
    }
#elif !defined(DACS_HYBRID) &&  defined(DACS_PPU)
    dacs_rc = dacs_ppu_mem_deregister(dst_de,dst_pid,mem);
#else
#error "Invalid platform or no platform specified"
#endif

    DACS_MUTEX_UNLOCK(&dacsi_mem_lock);
    TRACE_POINT_EXIT(_DACS_MEM_DEREGISTER, token, 1, dacs_rc);

    return dacs_rc ;
}



/*--------------------------------------------------------------------*/

DACS_ERR_T dacs_mem_query(dacs_mem_t mem,
                          DACS_MEM_ATTR_T attr,
                          uint64_t * value)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized) return DACS_ERR_NOT_INITIALIZED;
    if (value == NULL)      return DACS_ERR_INVALID_ADDR;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    // Get a lock on the mem list
    DACS_MUTEX_LOCK(&dacsi_mem_lock);

    dacsi_shared_obj_t * handle = MEM_ADDR_TO_OBJ(mem);

#ifdef DACS_ERROR_CHECKING
    // Handle was invalid or not allocated anymore
    if (!handle) {
        DACS_MUTEX_UNLOCK(&dacsi_mem_lock);
        return DACS_ERR_INVALID_HANDLE;
    }
#endif

    switch(attr) {
        case DACS_MEM_SIZE:
            *value = handle->remote_mem.size;
            break;

        case DACS_MEM_ADDR:
            *value = handle->remote_mem.base_addr;
            break;

        case DACS_RMT_MEM_PERM:
            *value= handle->remote_mem.access;
            break;

        case DACS_LCL_MEM_PERM:
            *value= handle->remote_mem.local_access;
            break;

        default:
            // Unknown attribute requested
            dacs_rc = DACS_ERR_INVALID_ATTR;
            break;
    }

    // Release the lock now that we are done with it
    DACS_MUTEX_UNLOCK(&dacsi_mem_lock);

    return dacs_rc;
}

/*--------------------------------------------------------------------*/

DACS_ERR_T dacs_mem_limits_query(DACS_MEM_LIMITS_T attr,
                                 de_id_t dst_de,
                                 dacs_process_id_t dst_pid,
                                 uint64_t *value)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized) return DACS_ERR_NOT_INITIALIZED;
    if (value == NULL)      return DACS_ERR_INVALID_ADDR;
    if ((dst_de == DACS_DE_SELF) || (dst_pid == DACS_PID_SELF)) return DACS_ERR_INVALID_TARGET;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

#if    defined(DACS_HYBRID) && !defined(DACS_PPU)
    dacs_rc = dacs_hybrid_mem_limits_query(attr,dst_de,dst_pid,value);
#elif  defined(DACS_HYBRID) &&  defined(DACS_PPU)
    if (dst_de == DACS_DE_PARENT) {
        dacs_rc = dacs_hybrid_mem_limits_query(attr,dst_de,dst_pid,value);
    } else {
        dacs_rc = dacs_ppu_mem_limits_query(attr,dst_de,dst_pid,value);
    }
#elif !defined(DACS_HYBRID) &&  defined(DACS_PPU)
    dacs_rc = dacs_ppu_mem_limits_query(attr,dst_de,dst_pid,value);
#else
#error "Invalid platform or no platform specified"
#endif

    return dacs_rc;
}

/*--------------------------------------------------------------------*/

DACS_ERR_T dacs_mem_put(dacs_mem_t        dst_remote_mem,
                        uint64_t          dst_remote_mem_offset,
                        dacs_mem_t        src_local_mem,
                        uint64_t          src_local_mem_offset,
                        uint64_t          size,
                        dacs_wid_t        wid,
                        DACS_ORDER_ATTR_T order_attr,
                        DACS_BYTE_SWAP_T  swap)
{
    // Translate the handles to objects
    dacsi_shared_obj_t * dst_handle = MEM_ADDR_TO_OBJ(dst_remote_mem);
    dacsi_shared_obj_t * src_handle = MEM_ADDR_TO_OBJ(src_local_mem);

#ifdef DACS_ERROR_CHECKING
    // Check if we are even initialized yet
    if (!dacsi_initialized)  return DACS_ERR_NOT_INITIALIZED;

    // Validate the order attributes
    if ((order_attr != DACS_ORDER_ATTR_NONE)  &&
        (order_attr != DACS_ORDER_ATTR_FENCE) &&
        (order_attr != DACS_ORDER_ATTR_BARRIER)) return DACS_ERR_INVALID_ATTR;

    // Validate the swap attributes
    if ((swap != DACS_BYTE_SWAP_DISABLE) &&
        (swap != DACS_BYTE_SWAP_HALF_WORD) &&
        (swap != DACS_BYTE_SWAP_WORD) &&
        (swap != DACS_BYTE_SWAP_DOUBLE_WORD)) return DACS_ERR_INVALID_ATTR;

    // Validate the remote memory handle
    if (dst_handle == NULL) return DACS_ERR_INVALID_HANDLE;
    if ((dst_handle->remote_mem.access != DACS_MEM_READ_WRITE) &&
        (dst_handle->remote_mem.access != DACS_MEM_WRITE_ONLY)) return DACS_ERR_NO_PERM;
    if ((size > 0) &&
        ((dst_remote_mem_offset >= dst_handle->remote_mem.size) ||
         ((dst_remote_mem_offset + size > dst_handle->remote_mem.size) ||
          (dst_remote_mem_offset + size < dst_remote_mem_offset)))) return DACS_ERR_BUF_OVERFLOW;

    // Validate the local memory handle
    if (src_handle == NULL) return DACS_ERR_INVALID_HANDLE;
    if ((src_handle->remote_mem.local_access != DACS_MEM_READ_WRITE) &&
        (src_handle->remote_mem.local_access != DACS_MEM_READ_ONLY)) return DACS_ERR_NO_PERM;
    if ((size > 0) &&
        ((src_local_mem_offset >= src_handle->remote_mem.size) ||
         ((src_local_mem_offset + size > src_handle->remote_mem.size) ||
          (src_local_mem_offset + size < src_local_mem_offset)))) return DACS_ERR_INVALID_SIZE;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    //TRACE_TIMER_TOKEN(timer_token);
    TRACE_INTERVAL_TOKEN_ARGUMENT(token);

    TRACE_POINT_ENTRY(_DACS_MEM_PUT, token, 1, 
    					dst_remote_mem, dst_remote_mem_offset, 
    					src_local_mem, src_local_mem_offset, 
					size, wid, order_attr, swap);
    //TRACE_TIMER_START(timer_token);

#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    dacs_rc = dacs_hybrid_mem_put(dst_handle,
                                  dst_remote_mem_offset,
                                  src_handle,
                                  src_local_mem_offset,
                                  size,
                                  wid,
                                  order_attr,
                                  swap);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    if (dst_handle->owner_de == DACS_DE_PARENT) {
        dacs_rc = dacs_hybrid_mem_put(dst_handle,
                                      dst_remote_mem_offset,
                                      src_handle,
                                      src_local_mem_offset,
                                      size,
                                      wid,
                                      order_attr,
                                      swap);
    } else {
        dacs_rc = DACS_ERR_NOT_SUPPORTED_YET;
    }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    dacs_rc = DACS_ERR_NOT_SUPPORTED_YET;
#else
#error "Invalid platform or no platform specified"
#endif

    if (dacs_rc == DACS_SUCCESS) {
	TRACE_COUNTER_INCREMENT(dacs_mem_put_count, 1);
	TRACE_COUNTER_INCREMENT(dacs_mem_put_bytes, size);
    }
    //TRACE_TIMER_END(dacs_mem_put, timer_token);
    TRACE_POINT_EXIT(_DACS_MEM_PUT, token, 1, dacs_rc);

    return dacs_rc ;
}

/*--------------------------------------------------------------------*/

DACS_ERR_T dacs_mem_get(dacs_mem_t        dst_local_mem,
                        uint64_t          dst_local_mem_offset,
                        dacs_mem_t        src_remote_mem,
                        uint64_t          src_remote_mem_offset,
                        uint64_t          size,
                        dacs_wid_t        wid,
                        DACS_ORDER_ATTR_T order_attr,
                        DACS_BYTE_SWAP_T  swap)
{
    // Translate the handles to objects
    dacsi_shared_obj_t * dst_handle = MEM_ADDR_TO_OBJ(dst_local_mem);
    dacsi_shared_obj_t * src_handle = MEM_ADDR_TO_OBJ(src_remote_mem);

#ifdef DACS_ERROR_CHECKING
    // Check if we are even initialized yet
    if (!dacsi_initialized)  return DACS_ERR_NOT_INITIALIZED;

    // Validate the order attributes
    if ((order_attr != DACS_ORDER_ATTR_NONE)  &&
        (order_attr != DACS_ORDER_ATTR_FENCE) &&
        (order_attr != DACS_ORDER_ATTR_BARRIER)) return DACS_ERR_INVALID_ATTR;

    // Validate the swap attributes
    if ((swap != DACS_BYTE_SWAP_DISABLE) &&
        (swap != DACS_BYTE_SWAP_HALF_WORD) &&
        (swap != DACS_BYTE_SWAP_WORD) &&
        (swap != DACS_BYTE_SWAP_DOUBLE_WORD)) return DACS_ERR_INVALID_ATTR;

    // Validate the local memory handle
    if (dst_handle == NULL) return DACS_ERR_INVALID_HANDLE;
    if ((dst_handle->remote_mem.local_access != DACS_MEM_READ_WRITE) &&
        (dst_handle->remote_mem.local_access != DACS_MEM_WRITE_ONLY)) return DACS_ERR_NO_PERM;
    if ((size > 0) &&
        ((dst_local_mem_offset >= dst_handle->remote_mem.size) ||
         ((dst_local_mem_offset + size > dst_handle->remote_mem.size) ||
          (dst_local_mem_offset + size < dst_local_mem_offset)))) return DACS_ERR_BUF_OVERFLOW;

    // Validate the remote memory handle
    if (src_handle == NULL) return DACS_ERR_INVALID_HANDLE;
    if ((src_handle->remote_mem.access != DACS_MEM_READ_WRITE) &&
        (src_handle->remote_mem.access != DACS_MEM_READ_ONLY)) return DACS_ERR_NO_PERM;
    if ((size > 0) &&
        ((src_remote_mem_offset >= src_handle->remote_mem.size) ||
         ((src_remote_mem_offset + size > src_handle->remote_mem.size) ||
          (src_remote_mem_offset + size < src_remote_mem_offset)))) return DACS_ERR_INVALID_SIZE;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MEM_GET, token, 1, 
    			dst_local_mem, dst_local_mem_offset, 
    			src_remote_mem, src_remote_mem_offset, 
			size, wid, order_attr, swap);

#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    dacs_rc = dacs_hybrid_mem_get(dst_handle,
                                  dst_local_mem_offset,                                  
                                  src_handle,
                                  src_remote_mem_offset,
                                  size,
                                  wid,
                                  order_attr,
                                  swap);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    if (src_handle->owner_de == DACS_DE_PARENT) {
        dacs_rc = dacs_hybrid_mem_get(dst_handle,
                                      dst_local_mem_offset,
                                      src_handle,
                                      src_remote_mem_offset,
                                      size,
                                      wid,
                                      order_attr,
                                      swap);
    } else {
        dacs_rc = DACS_ERR_NOT_SUPPORTED_YET;
    }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    dacs_rc = DACS_ERR_NOT_SUPPORTED_YET;
#else
#error "Invalid platform or no platform specified"
#endif

    if (dacs_rc == DACS_SUCCESS) {
	TRACE_COUNTER_INCREMENT(dacs_mem_get_count, 1);
	TRACE_COUNTER_INCREMENT(dacs_mem_get_bytes, size);
    }
    TRACE_POINT_EXIT(_DACS_MEM_GET,token, 1, dacs_rc);

    return dacs_rc ;
}

/*--------------------------------------------------------------------*/

DACS_ERR_T dacs_mem_put_list(dacs_mem_t        dst_remote_mem,
                             dacs_dma_list_t*  dst_dma_list,
                             uint32_t          dst_list_size,
                             dacs_mem_t        src_local_mem,
                             dacs_dma_list_t*  src_dma_list,
                             uint32_t          src_list_size,
                             dacs_wid_t        wid,
                             DACS_ORDER_ATTR_T order_attr,
                             DACS_BYTE_SWAP_T  swap)
{
    // Translate the handles to objects
    dacsi_shared_obj_t * dst_handle = MEM_ADDR_TO_OBJ(dst_remote_mem);
    dacsi_shared_obj_t * src_handle = MEM_ADDR_TO_OBJ(src_local_mem);

#ifdef DACS_ERROR_CHECKING
    // Check if we are even initialized yet
    if (!dacsi_initialized)  return DACS_ERR_NOT_INITIALIZED;

    // Validate the order attributes
    if ((order_attr != DACS_ORDER_ATTR_NONE)  &&
        (order_attr != DACS_ORDER_ATTR_FENCE) &&
        (order_attr != DACS_ORDER_ATTR_BARRIER)) return DACS_ERR_INVALID_ATTR;

    // Validate the swap attributes
    if ((swap != DACS_BYTE_SWAP_DISABLE) &&
        (swap != DACS_BYTE_SWAP_HALF_WORD) &&
        (swap != DACS_BYTE_SWAP_WORD) &&
        (swap != DACS_BYTE_SWAP_DOUBLE_WORD)) return DACS_ERR_INVALID_ATTR;

    // Validate the remote memory handle
    if (dst_handle == NULL) return DACS_ERR_INVALID_HANDLE;
    if ((dst_handle->remote_mem.access != DACS_MEM_READ_WRITE) &&
        (dst_handle->remote_mem.access != DACS_MEM_WRITE_ONLY)) return DACS_ERR_NO_PERM;

    // Validate the local memory handle
    if (src_handle == NULL) return DACS_ERR_INVALID_HANDLE;
    if ((src_handle->remote_mem.local_access != DACS_MEM_READ_WRITE) &&
        (src_handle->remote_mem.local_access != DACS_MEM_READ_ONLY)) return DACS_ERR_NO_PERM;

    // Validate the lists are matching in total size
    if ((src_dma_list == NULL) || (dst_dma_list == NULL)) return DACS_ERR_INVALID_ADDR;
    if ((!dst_list_size || !src_list_size) ||
        ((dst_list_size > 1) && (src_list_size > 1)))     return DACS_ERR_INVALID_SIZE;
    unsigned int i;
    uint64_t src_size = 0, dst_size = 0;
    for (i = 0; i < src_list_size; ++i) src_size += src_dma_list[i].size;
    for (i = 0; i < dst_list_size; ++i) dst_size += dst_dma_list[i].size;
    if (src_size > dst_size) return DACS_ERR_BUF_OVERFLOW;
    if (src_size < dst_size) return DACS_ERR_INVALID_SIZE;

    // Validate that the regions aren't out of bounds
    for (i = 0; i < dst_list_size; ++i) {
        if (((dst_dma_list[i].offset + dst_dma_list[i].size) > dst_handle->remote_mem.size) ||
            ((dst_dma_list[i].offset + dst_dma_list[i].size) < dst_dma_list[i].offset)) {     
            return DACS_ERR_BUF_OVERFLOW;
        }
    }

    for (i = 0; i < src_list_size; ++i) {
        if (((src_dma_list[i].offset + src_dma_list[i].size) > src_handle->remote_mem.size) || 
            ((src_dma_list[i].offset + src_dma_list[i].size) < src_dma_list[i].offset)) {
            return DACS_ERR_INVALID_SIZE;
        }
    }
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    //TRACE_TIMER_TOKEN(timer_token);
    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MEM_PUT_LIST, token, 1, 
    			(uintptr_t)dst_remote_mem, (uintptr_t)dst_dma_list, dst_list_size, 
    			(uintptr_t)src_local_mem, (uintptr_t)src_dma_list, src_list_size, 
			wid, order_attr, swap);
    //TRACE_TIMER_START(timer_token);

#if defined(DACS_HYBRID)
    dacs_rc = dacs_hybrid_mem_put_list(dst_handle,
                                       dst_dma_list,
                                       dst_list_size,
                                       src_handle,
                                       src_dma_list,
                                       src_list_size,
                                       wid,
                                       order_attr,
                                       swap);
#elif  !defined(DACS_HYBRID) && defined(DACS_PPU)
    dacs_rc = DACS_ERR_NOT_SUPPORTED_YET;
#else
#error "Invalid platform or no platform specified"
#endif

    if (dacs_rc == DACS_SUCCESS) {
	TRACE_COUNTER_INCREMENT(dacs_mem_put_count,1);
	TRACE_COUNTER_INCREMENT(dacs_mem_put_bytes, dst_list_size);
    }
    //TRACE_TIMER_END(dacs_mem_put_list, timer_token);
    TRACE_POINT_EXIT(_DACS_MEM_PUT_LIST, token, 1, dacs_rc);

    return dacs_rc;

}

/*--------------------------------------------------------------------*/

DACS_ERR_T dacs_mem_get_list(dacs_mem_t       dst_local_mem,
                             dacs_dma_list_t   *dst_dma_list,
                             uint32_t          dst_list_size,
                             dacs_mem_t        src_remote_mem,
                             dacs_dma_list_t   *src_dma_list,
                             uint32_t          src_list_size,
                             dacs_wid_t        wid,
                             DACS_ORDER_ATTR_T order_attr,
                             DACS_BYTE_SWAP_T  swap)
{
    // Translate the handles to objects
    dacsi_shared_obj_t * dst_handle = MEM_ADDR_TO_OBJ(dst_local_mem);
    dacsi_shared_obj_t * src_handle = MEM_ADDR_TO_OBJ(src_remote_mem);

#ifdef DACS_ERROR_CHECKING
    // Check if we are even initialized yet
    if (!dacsi_initialized)  return DACS_ERR_NOT_INITIALIZED;

    // Validate the order attributes
    if ((order_attr != DACS_ORDER_ATTR_NONE)  &&
        (order_attr != DACS_ORDER_ATTR_FENCE) &&
        (order_attr != DACS_ORDER_ATTR_BARRIER)) return DACS_ERR_INVALID_ATTR;

    // Validate the swap attributes
    if ((swap != DACS_BYTE_SWAP_DISABLE) &&
        (swap != DACS_BYTE_SWAP_HALF_WORD) &&
        (swap != DACS_BYTE_SWAP_WORD) &&
        (swap != DACS_BYTE_SWAP_DOUBLE_WORD)) return DACS_ERR_INVALID_ATTR;

    // Validate the local memory handle
    if (dst_handle == NULL) return DACS_ERR_INVALID_HANDLE;
    if ((dst_handle->remote_mem.local_access != DACS_MEM_READ_WRITE) &&
        (dst_handle->remote_mem.local_access != DACS_MEM_WRITE_ONLY)) return DACS_ERR_NO_PERM;

    // Validate the remote memory handle
    if (src_handle == NULL) return DACS_ERR_INVALID_HANDLE;
    if ((src_handle->remote_mem.access != DACS_MEM_READ_WRITE) &&
        (src_handle->remote_mem.access != DACS_MEM_READ_ONLY)) return DACS_ERR_NO_PERM;

    // Validate the sizes of both lists match
    if ((src_dma_list == NULL) || (dst_dma_list == NULL)) return DACS_ERR_INVALID_ADDR;
    if ((!dst_list_size || !src_list_size) ||
        ((dst_list_size > 1) && (src_list_size > 1)))     return DACS_ERR_INVALID_SIZE;
    uint32_t i;
    uint64_t src_size = 0, dst_size = 0;
    for (i = 0; i < src_list_size; ++i) src_size += src_dma_list[i].size;
    for (i = 0; i < dst_list_size; ++i) dst_size += dst_dma_list[i].size;
    if (src_size > dst_size) return DACS_ERR_BUF_OVERFLOW;
    if (src_size < dst_size) return DACS_ERR_INVALID_SIZE;

    // Validate that the regions aren't out of bounds
    // Validate that the regions aren't out of bounds
    for (i = 0; i < dst_list_size; ++i) {
        if (((dst_dma_list[i].offset + dst_dma_list[i].size) > dst_handle->remote_mem.size) ||
            ((dst_dma_list[i].offset + dst_dma_list[i].size) < dst_dma_list[i].offset)) {     
            return DACS_ERR_BUF_OVERFLOW;
        }
    }

    for (i = 0; i < src_list_size; ++i) {
        if (((src_dma_list[i].offset + src_dma_list[i].size) > src_handle->remote_mem.size) || 
            ((src_dma_list[i].offset + src_dma_list[i].size) < src_dma_list[i].offset)) {
            return DACS_ERR_INVALID_SIZE;
        }
    }
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MEM_GET_LIST, token, 1, 
                    (uintptr_t)dst_local_mem, (uintptr_t)dst_dma_list, dst_list_size, 
                    (uintptr_t)src_remote_mem, (uintptr_t)src_dma_list, src_list_size, 
                    wid, order_attr, swap);

#if defined(DACS_HYBRID)
    dacs_rc = dacs_hybrid_mem_get_list(dst_handle,
                                       dst_dma_list,
                                       dst_list_size,
                                       src_handle,
                                       src_dma_list,
                                       src_list_size,
                                       wid,
                                       order_attr,
                                       swap);
#elif  !defined(DACS_HYBRID) && defined(DACS_PPU)
    dacs_rc = DACS_ERR_NOT_SUPPORTED_YET;
#else
#error "Invalid platform or no platform specified"
#endif

    if (dacs_rc == DACS_SUCCESS) {
	TRACE_COUNTER_INCREMENT(dacs_mem_get_count, 1);
	TRACE_COUNTER_INCREMENT(dacs_mem_get_bytes, dst_list_size);
    }
    TRACE_POINT_EXIT(_DACS_MEM_GET_LIST, token, 1, dacs_rc);

    return dacs_rc;
}

/*--------------------------------------------------------------------*/
/*  Internal Function Definitions                                     */
/*--------------------------------------------------------------------*/

DACS_ERR_T dacsi_mem_init()
{
    dacsi_mem_list.head = 0;
    dacsi_mem_list.tail = 0;

    return DACS_SUCCESS;
}

/*--------------------------------------------------------------------*/

DACS_ERR_T dacsi_mem_exit()
{
    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    while (!dacs_rc && dacsi_mem_list.head) {
        dacsi_shared_obj_t* mem_handle = dacsi_mem_list.head;
        dacsi_shared_obj_dequeue(mem_handle,
                                 &dacsi_mem_list.head,
                                 &dacsi_mem_list.tail);
        dacsi_mem_destroy(mem_handle);
    }

    return dacs_rc;
}

/*--------------------------------------------------------------------*/

DACS_ERR_T dacsi_mem_destroy(dacsi_shared_obj_t* handle)
{
    // Release any hybrid resources that were allocated
    if (handle->hybrid_data) {
        free((void*)(uintptr_t)handle->hybrid_data);
        handle->hybrid_data = 0;
    }

    // Now release the shared object storage
    dacsi_shared_obj_delete(handle);

    return DACS_SUCCESS;
}

/*--------------------------------------------------------------------*/

dacsi_shared_obj_t * dacsi_find_mem_by_local_id(dacs_mem_t mem)
{
    dacsi_shared_obj_t * handle = NULL;
    dacsi_shared_obj_t * curr;

    for (curr = dacsi_mem_list.head; curr; curr = (dacsi_shared_obj_t*)(uintptr_t)curr->next)
    {
        if (curr == (dacsi_shared_obj_t*)(uintptr_t)mem) {
            handle = curr;
            break;
        }
    }

    return handle;
}
