/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

static char *ident  __attribute__((unused)) = "@(#) internal-src/lib/dacs/common/dacs_dma.c v1.43 - 9/16/08 09:57:00 @(#)";

/*
 * dacs_dma.c - defines functions used for remote memory operations
 */

/*--------------------------------------------------------------------*/
/*  Includes                                                          */
/*--------------------------------------------------------------------*/

#include <dacsi_dma.h>
#include <dacs_common.h>

#define __USE_UNIX98 // read/write lock support
#include <pthread.h>

#if defined(DACS_HYBRID)
#include <dacs_hybrid_dma.h>
#endif

#ifdef DACS_PPU
#include <dacs_ppu_dma.h>
#endif

#include <dacs_trace.h>
#include <assert.h> // only until error handling is available
#include <stdlib.h>

/*--------------------------------------------------------------------*/
/*  User Types                                                        */
/*--------------------------------------------------------------------*/

/*--------------------------------------------------------------------*/
/*  Constants                                                         */
/*--------------------------------------------------------------------*/

/*--------------------------------------------------------------------*/
/*  Macros                                                            */
/*--------------------------------------------------------------------*/

#ifdef DACS_ERROR_CHECKING
#define REMOTE_MEM_TO_HANDLE(mem) dacsi_find_remote_mem_by_local_id(mem)
#else
#define REMOTE_MEM_TO_HANDLE(mem) ((dacsi_shared_obj_t*)(uintptr_t)(mem))
#endif

#define DACSI_REMOTE_MEM_LIST_RDLOCK() assert(pthread_rwlock_rdlock(&dacsi_remote_mem_lock) == 0)
#define DACSI_REMOTE_MEM_LIST_WRLOCK() assert(pthread_rwlock_wrlock(&dacsi_remote_mem_lock) == 0)
#define DACSI_REMOTE_MEM_LIST_UNLOCK() assert(pthread_rwlock_unlock(&dacsi_remote_mem_lock) == 0)

/*--------------------------------------------------------------------*/
/*  Internal Function Prototypes                                      */
/*--------------------------------------------------------------------*/

dacsi_shared_obj_t * dacsi_find_remote_mem_by_local_id(dacs_remote_mem_t);

DACS_ERR_T dacsi_remote_mem_destroy(dacsi_shared_obj_t* handle);

/*--------------------------------------------------------------------*/
/*  Global Variables                                                  */
/*--------------------------------------------------------------------*/

pthread_rwlock_t dacsi_remote_mem_lock = PTHREAD_RWLOCK_INITIALIZER;

struct dacsi_rmem_list dacsi_remote_mem_list;

/*--------------------------------------------------------------------*/
/*  Function Definitions                                              */
/*--------------------------------------------------------------------*/

DACS_ERR_T  dacs_remote_mem_create ( void                      *addr,
                                     uint64_t                   size,
                                     DACS_MEMORY_ACCESS_MODE_T  access_mode,
                                     dacs_remote_mem_t         *mem )
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized)  return DACS_ERR_NOT_INITIALIZED;
    if (!addr || !mem)       return DACS_ERR_INVALID_ADDR;
    if (!size)              return DACS_ERR_INVALID_SIZE;
    if ((access_mode != DACS_READ_ONLY) &&
        (access_mode != DACS_WRITE_ONLY) &&
        (access_mode != DACS_READ_WRITE)) return DACS_ERR_INVALID_ATTR;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;
    dacsi_shared_obj_t* handle;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_RMEM_CREATE, token, 1, (uintptr_t) addr, size,
                            access_mode, (uintptr_t) mem);

    // Get a write lock on the remote mem list
    DACSI_REMOTE_MEM_LIST_WRLOCK();

    // Allocate the storage for the remote memory and add it to the list
    dacs_rc = dacsi_shared_obj_create(&handle,
                                      &dacsi_remote_mem_list.head,
                                      &dacsi_remote_mem_list.tail);

    if (!dacs_rc) {
        // Initialize the remote memory section of the shared object
        handle->name = DACSI_REMOTE_MEM_NAME;
        handle->remote_mem.base_addr = (uintptr_t)addr;
        handle->remote_mem.size      = size;
        handle->remote_mem.access    = access_mode;

#ifdef DACS_HYBRID
        // Initialize additional hybrid remote mem info
        dacs_hybrid_remote_mem_create(handle);
#endif

        // Set the return memory handle to be the address of the newly created structure
        *mem = (uintptr_t)handle;
    } else {
        // Invalidate the handle in case they attempt to use it
        *mem = 0;
    }

    // Release the lock now that we are done with it
    DACSI_REMOTE_MEM_LIST_UNLOCK();

    TRACE_POINT_EXIT(_DACS_RMEM_CREATE,token,1,dacs_rc,*mem);

    return dacs_rc ;
}

/*--------------------------------------------------------------------*/

DACS_ERR_T dacs_remote_mem_share(de_id_t dst_de,
                                 dacs_process_id_t dst_pid,
                                 dacs_remote_mem_t mem)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized) return DACS_ERR_NOT_INITIALIZED;
    if ((dst_de == DACS_DE_SELF) || (dst_pid == DACS_PID_SELF)) return DACS_ERR_INVALID_TARGET;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_RMEM_SHARE,token,1,dst_de,dst_pid,mem);

    // Get a write lock on the remote mem list
    DACSI_REMOTE_MEM_LIST_WRLOCK();

    dacsi_shared_obj_t * handle = REMOTE_MEM_TO_HANDLE(mem);
#ifdef DACS_ERROR_CHECKING
    // Handle was invalid or not allocated anymore
    if (!handle) {
        DACSI_REMOTE_MEM_LIST_UNLOCK();
        return DACS_ERR_INVALID_HANDLE;
    }
#endif

    // Now call the platform specific implementation
#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    dacs_rc = dacs_hybrid_remote_mem_share(dst_de,dst_pid,handle);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    if (dst_de == DACS_DE_PARENT) {
        dacs_rc = dacs_hybrid_remote_mem_share(dst_de,dst_pid,handle);
    } else {
        dacs_rc = dacs_ppu_remote_mem_share(dst_de,dst_pid,mem);
    }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    dacs_rc = dacs_ppu_remote_mem_share(dst_de,dst_pid,mem);
#else
#error "Invalid platform or no platform specified"
#endif

    // Release the lock now that we are done with it
    DACSI_REMOTE_MEM_LIST_UNLOCK();

    TRACE_POINT_EXIT(_DACS_RMEM_SHARE,token,1,dacs_rc);

    return dacs_rc;
}

/* --------------------------------------------------------------------*/
DACS_ERR_T dacs_remote_mem_accept( de_id_t             src_de,
                                   dacs_process_id_t   src_pid,
                                   dacs_remote_mem_t  *mem)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized) return DACS_ERR_NOT_INITIALIZED;
    if (!mem)               return DACS_ERR_INVALID_ADDR;
    if ((src_de == DACS_DE_SELF) || (src_pid == DACS_PID_SELF)) return DACS_ERR_INVALID_TARGET;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_RMEM_ACCEPT, token, 1, src_de, src_pid,
                           (uintptr_t) mem);

    // Get a write lock on the remote mem list
    DACSI_REMOTE_MEM_LIST_WRLOCK();

    // Now call the platform specific implementation
#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    dacs_rc = dacs_hybrid_remote_mem_accept(src_de,src_pid,mem);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    if (src_de  == DACS_DE_PARENT) {
        dacs_rc = dacs_hybrid_remote_mem_accept(src_de,src_pid,mem);
    } else {
        dacs_rc = dacs_ppu_remote_mem_accept(src_de,src_pid,mem);
    }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    dacs_rc = dacs_ppu_remote_mem_accept(src_de,src_pid,mem);
#else
#error "Invalid platform or no platform specified"
#endif

    // Release the lock now that we are done with it
    DACSI_REMOTE_MEM_LIST_UNLOCK();

    TRACE_POINT_EXIT(_DACS_RMEM_ACCEPT,token,1,dacs_rc,*mem);

    return dacs_rc;
}

/* --------------------------------------------------------------------*/
DACS_ERR_T dacs_remote_mem_release(dacs_remote_mem_t *mem)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized) return DACS_ERR_NOT_INITIALIZED;
    if (!mem)               return DACS_ERR_INVALID_ADDR;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_RMEM_RELEASE,token,1,*mem);

    // Get a write lock on the remote mem list
    DACSI_REMOTE_MEM_LIST_WRLOCK();

#ifdef DACS_HYBRID
    dacsi_shared_obj_t * handle = REMOTE_MEM_TO_HANDLE(*mem);
#ifdef DACS_ERROR_CHECKING
    // Handle was invalid or not allocated anymore
    if (!handle) {
        DACSI_REMOTE_MEM_LIST_UNLOCK();
        return DACS_ERR_INVALID_HANDLE;
    }
#endif
#endif

    // Now call the platform specific implementation
#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    dacs_rc = dacs_hybrid_remote_mem_release(handle);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    if (handle->owner_de == DACS_DE_PARENT) {
        dacs_rc = dacs_hybrid_remote_mem_release(handle);
    } else {
        // only other option is that we are the owner - error
        dacs_rc = DACS_ERR_OWNER;
    }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    dacs_rc = dacs_ppu_remote_mem_release(mem);
#else
#error "Invalid platform or no platform specified"
#endif

    if (!dacs_rc) {
        *mem = 0; // Set the handle to an uninitialized value
    }

    // Release the write lock now that we are done with it
    DACSI_REMOTE_MEM_LIST_UNLOCK();

    TRACE_POINT_EXIT(_DACS_RMEM_RELEASE,token,1,dacs_rc);

    return dacs_rc;
}

/* --------------------------------------------------------------------*/
DACS_ERR_T dacs_remote_mem_destroy (dacs_remote_mem_t *mem)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized) return DACS_ERR_NOT_INITIALIZED;
    if (!mem)               return DACS_ERR_INVALID_ADDR;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_RMEM_DESTROY,token,1,*mem);

    // Get a write lock on the remote mem list
    DACSI_REMOTE_MEM_LIST_WRLOCK();

    dacsi_shared_obj_t * handle = REMOTE_MEM_TO_HANDLE(*mem);
#ifdef DACS_ERROR_CHECKING
    // Handle was invalid or not allocated anymore
    if (!handle) {
        DACSI_REMOTE_MEM_LIST_UNLOCK();
        return DACS_ERR_INVALID_HANDLE;
    }
#endif

    // Now call the platform specific implementation
#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    dacs_rc = dacs_hybrid_remote_mem_destroy(handle);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    dacs_rc = dacs_hybrid_remote_mem_destroy(handle);
    if (!dacs_rc) {
        dacs_rc = dacs_ppu_remote_mem_destroy(mem);
    }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    dacs_rc = dacs_ppu_remote_mem_destroy(mem);
#else
#error "Invalid platform or no platform specified"
#endif

    // Now release the resources
    if (!dacs_rc) {
        dacs_rc = dacsi_remote_mem_destroy(handle);
        *mem = 0; // Set the handle to an uninitialized value
    }

    // Release the write lock now that we are done with it
    DACSI_REMOTE_MEM_LIST_UNLOCK();

    TRACE_POINT_EXIT(_DACS_RMEM_DESTROY,token,1,dacs_rc);

    return  dacs_rc;
}

/* --------------------------------------------------------------------*/
DACS_ERR_T dacs_remote_mem_query(dacs_remote_mem_t        mem,
                                 DACS_REMOTE_MEM_ATTR_T   attr,
                                 uint64_t                *value)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized) return DACS_ERR_NOT_INITIALIZED;
    if (!value)             return DACS_ERR_INVALID_ADDR;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    // Get a read lock on the remote mem list
    DACSI_REMOTE_MEM_LIST_RDLOCK();

    dacsi_shared_obj_t * handle = REMOTE_MEM_TO_HANDLE(mem);
#ifdef DACS_ERROR_CHECKING
    // Handle was invalid or not allocated anymore
    if (!handle) {
        DACSI_REMOTE_MEM_LIST_UNLOCK();
        return DACS_ERR_INVALID_HANDLE;
    }
#endif

    switch(attr) {
        case DACS_REMOTE_MEM_SIZE:
            *value = handle->remote_mem.size;
            break;

        case DACS_REMOTE_MEM_ADDR:
            *value = handle->remote_mem.base_addr;
            break;

        case DACS_REMOTE_MEM_PERM:
            *value= handle->remote_mem.access;
            break;

        default:
            // Unknown attribute requested
            dacs_rc = DACS_ERR_INVALID_ATTR;
            break;
    }

    // Release the write lock now that we are done with it
    DACSI_REMOTE_MEM_LIST_UNLOCK();

    return dacs_rc;
}

/* --------------------------------------------------------------------*/
DACS_ERR_T dacs_put( dacs_remote_mem_t   dst_remote_mem,
                     uint64_t            dst_remote_mem_offset,
                     void               *src_addr,
                     uint64_t            size,
                     dacs_wid_t          wid,
                     DACS_ORDER_ATTR_T   order_attr,
                     DACS_BYTE_SWAP_T    swap )
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized) return DACS_ERR_NOT_INITIALIZED;
    if (!src_addr)          return DACS_ERR_INVALID_ADDR;
    if ((order_attr != DACS_ORDER_ATTR_NONE)  &&
        (order_attr != DACS_ORDER_ATTR_FENCE) &&
        (order_attr != DACS_ORDER_ATTR_BARRIER)) return DACS_ERR_INVALID_ATTR;
    if ((swap != DACS_BYTE_SWAP_DISABLE) &&
        (swap != DACS_BYTE_SWAP_HALF_WORD) &&
        (swap != DACS_BYTE_SWAP_WORD) &&
        (swap != DACS_BYTE_SWAP_DOUBLE_WORD)) return DACS_ERR_INVALID_ATTR;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    TRACE_TIMER_TOKEN(timer_token);
    TRACE_INTERVAL_TOKEN_ARGUMENT(token);

    TRACE_POINT_ENTRY(_DACS_PUT, token, 1, dst_remote_mem, dst_remote_mem_offset,
                        (uintptr_t) src_addr, size, wid, order_attr, swap);
    TRACE_TIMER_START(timer_token);

    // Get a read lock on the remote mem list
    //DACSI_REMOTE_MEM_LIST_RDLOCK();

#ifdef DACS_HYBRID
    dacsi_shared_obj_t * handle = REMOTE_MEM_TO_HANDLE(dst_remote_mem);
#ifdef DACS_ERROR_CHECKING
    // Handle was invalid or not allocated anymore
    if (!handle) {
        //DACSI_REMOTE_MEM_LIST_UNLOCK();
        return DACS_ERR_INVALID_HANDLE;
    }
#endif
#endif

#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    dacs_rc = dacs_hybrid_put(handle,
                              dst_remote_mem_offset,
                              src_addr,
                              size,
                              wid,
                              order_attr,
                              swap);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    if (handle->owner_de == DACS_DE_PARENT) {
        dacs_rc = dacs_hybrid_put(handle,
                                  dst_remote_mem_offset,
                                  src_addr,
                                  size,
                                  wid,
                                  order_attr,
                                  swap);
    } else {
        dacs_rc = dacs_ppu_put(dst_remote_mem,
                               dst_remote_mem_offset,
                               src_addr,
                               size,
                               wid,
                               order_attr,
                               swap);
    }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    dacs_rc = dacs_ppu_put(dst_remote_mem,
                           dst_remote_mem_offset,
                           src_addr,
                           size,
                           wid,
                           order_attr,
                           swap);
#else
#error "Invalid platform or no platform specified"
#endif

    // Release the lock now that we are done with it
    //DACSI_REMOTE_MEM_LIST_UNLOCK();

    if (dacs_rc == DACS_SUCCESS) {
	TRACE_COUNTER_INCREMENT(dacs_put_count,1);
	TRACE_COUNTER_INCREMENT(dacs_put_bytes,size);
    }
    TRACE_TIMER_END(dacs_put,timer_token);
    TRACE_POINT_EXIT(_DACS_PUT,token,1,dacs_rc);

    return dacs_rc;
}

/* --------------------------------------------------------------------*/
DACS_ERR_T dacs_get(void               *dst_addr,
                    dacs_remote_mem_t   src_remote_mem,
                    uint64_t            src_remote_mem_offset,
                    uint64_t            size,
                    dacs_wid_t          wid,
                    DACS_ORDER_ATTR_T   order_attr,
                    DACS_BYTE_SWAP_T    swap )
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized) return DACS_ERR_NOT_INITIALIZED;
    if (!dst_addr)          return DACS_ERR_INVALID_ADDR;
    if ((order_attr != DACS_ORDER_ATTR_NONE)  &&
        (order_attr != DACS_ORDER_ATTR_FENCE) &&
        (order_attr != DACS_ORDER_ATTR_BARRIER)) return DACS_ERR_INVALID_ATTR;
    if ((swap != DACS_BYTE_SWAP_DISABLE)   &&
        (swap != DACS_BYTE_SWAP_HALF_WORD) &&
        (swap != DACS_BYTE_SWAP_WORD)      &&
        (swap != DACS_BYTE_SWAP_DOUBLE_WORD)) return DACS_ERR_INVALID_ATTR;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_GET, token, 1, (uintptr_t) dst_addr,
                        src_remote_mem, src_remote_mem_offset, size,
                        wid, order_attr, swap);

    // Get a read lock on the remote mem list
    //DACSI_REMOTE_MEM_LIST_RDLOCK();

#ifdef DACS_HYBRID
    dacsi_shared_obj_t * handle = REMOTE_MEM_TO_HANDLE(src_remote_mem);
#ifdef DACS_ERROR_CHECKING
    // Handle was invalid or not allocated anymore
    if (!handle) {
        //DACSI_REMOTE_MEM_LIST_UNLOCK();
        return DACS_ERR_INVALID_HANDLE;
    }
#endif
#endif

#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    dacs_rc = dacs_hybrid_get(dst_addr,
                              handle,
                              src_remote_mem_offset,
                              size,
                              wid,
                              order_attr,
                              swap);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    if (handle->owner_de == DACS_DE_PARENT) {
        dacs_rc = dacs_hybrid_get(dst_addr,
                                  handle,
                                  src_remote_mem_offset,
                                  size,
                                  wid,
                                  order_attr,
                                  swap);
    } else {
        dacs_rc = dacs_ppu_get(dst_addr,
                               src_remote_mem,
                               src_remote_mem_offset,
                               size,
                               wid,
                               order_attr,
                               swap);
    }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    dacs_rc = dacs_ppu_get(dst_addr,
                           src_remote_mem,
                           src_remote_mem_offset,
                           size,
                           wid,
                           order_attr,
                           swap);
#else
#error "Invalid platform or no platform specified"
#endif

    // Release the lock now that we are done with it
    //DACSI_REMOTE_MEM_LIST_UNLOCK();

    if (dacs_rc == DACS_SUCCESS) {
	TRACE_COUNTER_INCREMENT(dacs_get_count,1);
	TRACE_COUNTER_INCREMENT(dacs_get_bytes,size);
    }
    TRACE_POINT_EXIT(_DACS_GET,token,1,dacs_rc);

    return dacs_rc;
}

/* --------------------------------------------------------------------*/

DACS_ERR_T dacs_put_list(dacs_remote_mem_t    dst_remote_mem,
                         dacs_dma_list_t     *dst_dma_list,
                         uint32_t             dst_list_size,
                         void                *src_addr,
                         dacs_dma_list_t     *src_dma_list,
                         uint32_t             src_list_size,
                         dacs_wid_t           wid,
                         DACS_ORDER_ATTR_T    order_attr,
                         DACS_BYTE_SWAP_T     swap)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized) return DACS_ERR_NOT_INITIALIZED;
    if (!dst_dma_list || !src_dma_list) return DACS_ERR_INVALID_ADDR;
    if ((!dst_list_size || !src_list_size) ||
        ((dst_list_size > 1) && (src_list_size > 1)))return DACS_ERR_INVALID_SIZE;
    if ((order_attr != DACS_ORDER_ATTR_NONE)  &&
        (order_attr != DACS_ORDER_ATTR_FENCE) &&
        (order_attr != DACS_ORDER_ATTR_BARRIER))     return DACS_ERR_INVALID_ATTR;
    if ((swap != DACS_BYTE_SWAP_DISABLE)   &&
        (swap != DACS_BYTE_SWAP_HALF_WORD) &&
        (swap != DACS_BYTE_SWAP_WORD)      &&
        (swap != DACS_BYTE_SWAP_DOUBLE_WORD))        return DACS_ERR_INVALID_ATTR;

    // Validate the source/destination DMA lists
    unsigned int i;
    uint64_t src_size = 0, dst_size = 0;
    for (i = 0; i < src_list_size; ++i) {
        src_size += src_dma_list[i].size;
        if (((char*)src_addr + src_dma_list[i].offset) == NULL) return DACS_ERR_INVALID_ADDR;
    }
    for (i = 0; i < dst_list_size; ++i) dst_size += dst_dma_list[i].size;
    if (src_size > dst_size) return DACS_ERR_BUF_OVERFLOW;
    if (src_size < dst_size) return DACS_ERR_INVALID_SIZE;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    TRACE_TIMER_TOKEN(timer_token);
    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_PUT_LIST, token, 1, dst_remote_mem, (uintptr_t) dst_dma_list,
                        dst_list_size, (uintptr_t) src_addr, (uintptr_t) src_dma_list, 
                        src_list_size, wid, order_attr, swap);
    TRACE_TIMER_START(timer_token);

    // Get a read lock on the remote mem list
    //DACSI_REMOTE_MEM_LIST_RDLOCK();

    dacsi_shared_obj_t * handle = REMOTE_MEM_TO_HANDLE(dst_remote_mem);
#ifdef DACS_ERROR_CHECKING
    // Handle was invalid or not allocated anymore
    if (!handle) {
        //DACSI_REMOTE_MEM_LIST_UNLOCK();
        return DACS_ERR_INVALID_HANDLE;
    }

    // Validate permissions
    if (handle->remote_mem.access == DACS_READ_ONLY) {
        return DACS_ERR_NO_PERM;
    }

    // Validate that the regions aren't out of bounds
    for (i = 0; i < dst_list_size; ++i) {
        if (((dst_dma_list[i].offset + dst_dma_list[i].size) > handle->remote_mem.size) ||
            ((dst_dma_list[i].offset + dst_dma_list[i].size) < dst_dma_list[i].offset)) {     
            return DACS_ERR_BUF_OVERFLOW;
        }
    }
#endif

#if defined(DACS_HYBRID)
    dacs_rc = dacs_hybrid_put_list(handle,
                                   dst_dma_list,
                                   dst_list_size,
                                   src_addr,
                                   src_dma_list,
                                   src_list_size,
                                   wid,
                                   order_attr,
                                   swap);
#elif  !defined(DACS_HYBRID) && defined(DACS_PPU)
    dacs_rc = DACS_ERR_NOT_SUPPORTED_YET;
#else
#error "Invalid platform or no platform specified"
#endif

    // Release the lock now that we are done with it
    //DACSI_REMOTE_MEM_LIST_UNLOCK();

    if (dacs_rc == DACS_SUCCESS) {
	TRACE_COUNTER_INCREMENT(dacs_put_count,1);
	TRACE_COUNTER_INCREMENT(dacs_put_bytes,dst_list_size);
    }
    TRACE_TIMER_END(dacs_put_list,timer_token);
    TRACE_POINT_EXIT(_DACS_PUT_LIST,token,1,dacs_rc);

    return dacs_rc;
}


/* --------------------------------------------------------------------*/
DACS_ERR_T dacs_get_list(void                *dst_addr,
                         dacs_dma_list_t     *dst_dma_list,
                         uint32_t             dst_list_size,
                         dacs_remote_mem_t    src_remote_mem,
                         dacs_dma_list_t     *src_dma_list,
                         uint32_t             src_list_size,
                         dacs_wid_t           wid,
                         DACS_ORDER_ATTR_T    order_attr,
                         DACS_BYTE_SWAP_T     swap)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized) return DACS_ERR_NOT_INITIALIZED;
    if (!dst_dma_list || !src_dma_list) return DACS_ERR_INVALID_ADDR;
    if ((!dst_list_size || !src_list_size) ||
        ((dst_list_size > 1) && (src_list_size > 1)))return DACS_ERR_INVALID_SIZE;
    if ((order_attr != DACS_ORDER_ATTR_NONE)  &&
        (order_attr != DACS_ORDER_ATTR_FENCE) &&
        (order_attr != DACS_ORDER_ATTR_BARRIER))     return DACS_ERR_INVALID_ATTR;
    if ((swap != DACS_BYTE_SWAP_DISABLE)   &&
        (swap != DACS_BYTE_SWAP_HALF_WORD) &&
        (swap != DACS_BYTE_SWAP_WORD)      &&
        (swap != DACS_BYTE_SWAP_DOUBLE_WORD))        return DACS_ERR_INVALID_ATTR;

    // Validate the source/destination DMA lists
    unsigned int i;
    uint64_t src_size = 0, dst_size = 0;
    for (i = 0; i < src_list_size; ++i) src_size += src_dma_list[i].size;
    for (i = 0; i < dst_list_size; ++i) {
        dst_size += dst_dma_list[i].size;
        if (((char*)dst_addr + dst_dma_list[i].offset) == NULL) return DACS_ERR_INVALID_ADDR;
    }
    if (src_size > dst_size) return DACS_ERR_BUF_OVERFLOW;
    if (src_size < dst_size) return DACS_ERR_INVALID_SIZE;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_GET_LIST, token, 1, (uintptr_t) dst_addr, (uintptr_t) dst_dma_list, 
                        dst_list_size, src_remote_mem, (uintptr_t) src_dma_list, 
                        src_list_size, wid, order_attr, swap);

    // Get a read lock on the remote mem list
    //DACSI_REMOTE_MEM_LIST_RDLOCK();

    dacsi_shared_obj_t * handle = REMOTE_MEM_TO_HANDLE(src_remote_mem);
#ifdef DACS_ERROR_CHECKING
    // Handle was invalid or not allocated anymore
    if (!handle) {
        //DACSI_REMOTE_MEM_LIST_UNLOCK();
        return DACS_ERR_INVALID_HANDLE;
    }

    // Validate permissions
    if (handle->remote_mem.access == DACS_WRITE_ONLY) {
        return DACS_ERR_NO_PERM;
    }

    // Validate that the regions aren't out of bounds
    for (i = 0; i < src_list_size; ++i) {
        if (((src_dma_list[i].offset + src_dma_list[i].size) > handle->remote_mem.size) || 
            ((src_dma_list[i].offset + src_dma_list[i].size) < src_dma_list[i].offset)) {
            return DACS_ERR_INVALID_SIZE;
        }
    }
#endif

#if defined(DACS_HYBRID)
    dacs_rc = dacs_hybrid_get_list(dst_addr,
                              dst_dma_list,
                              dst_list_size,
                              handle,
                              src_dma_list,
                              src_list_size,
                              wid,
                              order_attr,
                              swap);
#elif  !defined(DACS_HYBRID) && defined(DACS_PPU)
    dacs_rc = DACS_ERR_NOT_SUPPORTED_YET;
#else
#error "Invalid platform or no platform specified"
#endif
    // Release the lock now that we are done with it
    //DACSI_REMOTE_MEM_LIST_UNLOCK();

    if (dacs_rc == DACS_SUCCESS) {
	TRACE_COUNTER_INCREMENT(dacs_get_count,1);
	TRACE_COUNTER_INCREMENT(dacs_get_bytes,dst_list_size);
    }
    TRACE_POINT_EXIT(_DACS_GET_LIST,token,1,dacs_rc);

    return dacs_rc;
}

/*--------------------------------------------------------------------*/
/*  Internal Function Definitions                                     */
/*--------------------------------------------------------------------*/

DACS_ERR_T dacsi_remote_mem_init()
{
    dacsi_remote_mem_list.head = 0;
    dacsi_remote_mem_list.tail = 0;

    return DACS_SUCCESS;
}

/*--------------------------------------------------------------------*/

DACS_ERR_T dacsi_remote_mem_exit()
{
    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    while (!dacs_rc && dacsi_remote_mem_list.head) {
        dacs_rc = dacsi_remote_mem_destroy(dacsi_remote_mem_list.head);
    }

    return dacs_rc;
}

/*--------------------------------------------------------------------*/

dacsi_shared_obj_t * dacsi_find_remote_mem_by_local_id(dacs_remote_mem_t mem)
{
    dacsi_shared_obj_t * handle = NULL;
    dacsi_shared_obj_t * curr;

    for (curr = dacsi_remote_mem_list.head; curr; curr = (dacsi_shared_obj_t*)(uintptr_t)curr->next)
    {
        if ((uintptr_t)curr == mem) {
            handle = curr;
            break;
        }
    }

    return handle;
}

/*--------------------------------------------------------------------*/

DACS_ERR_T dacsi_remote_mem_destroy(dacsi_shared_obj_t* handle)
{
    // Release any hybrid resources that were allocated
    if (handle->hybrid_data) {
        free((void*)(uintptr_t)handle->hybrid_data);
        handle->hybrid_data = 0;
    }

    // Now release the shared object
    return dacsi_shared_obj_destroy(handle,
                                      &dacsi_remote_mem_list.head,
                                      &dacsi_remote_mem_list.tail);
}
