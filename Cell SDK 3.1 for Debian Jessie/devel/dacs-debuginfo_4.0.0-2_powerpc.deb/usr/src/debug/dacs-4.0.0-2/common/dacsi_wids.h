/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

// ident = "@(#) internal-src/lib/dacs/common/dacsi_wids.h v1.11 - 9/16/08 09:57:03 @(#)"


#ifndef DACSI_WID_H
#define DACSI_WID_H

/*--------------------------------------------------------------------*/
/*  Includes                                                          */
/*--------------------------------------------------------------------*/

#include <dacs.h>
#include <dacs_common.h>
#include <stdint.h>
#include <pthread.h>

/*--------------------------------------------------------------------*/
/*  Constants                                                         */
/*--------------------------------------------------------------------*/

enum dacsi_wid_elem_type
{
    DACSI_SEND      = 0x0001,
    DACSI_RECV      = 0x0002,
    DACSI_PUT       = 0x0004,
    DACSI_GET       = 0x0008,
    DACSI_PUTL      = 0x0010,
    DACSI_GETL      = 0x0020,

    DACSI_FENCE     = 0x1000,
    DACSI_BARRIER   = 0x2000
};

#define DACSI_WID_MAX 256

/*--------------------------------------------------------------------*/
/*  User Types                                                        */
/*--------------------------------------------------------------------*/

/*
 * This structure contains the details of an outstanding request that can be
 * waited on.  This includes status, location, type ... 
 *
 * On cell, it is critical that the status field remain at the base of the
 * structure, which is guaranteed to be aligned on a 16 byte boundary.  This
 * field is asynchronously updated via a rDMA, so this alignement is critical.
 */
typedef struct dacsi_wid_element
{
    volatile DACS_ERR_T         status;     //  0: Wait status Must be 1st field
    de_id_t                     de;         //  4: DE of wait object
    dacs_process_id_t           pid;        //  8: PID of wait object
    struct dacsi_wid_element   *next;       // 16: Next request for the wid
    uint64_t                    request;    // 24: Pending request
    uint32_t                    type;       // 32: Type of this request
#ifdef DACS_ERROR_CHECKING
    uint32_t                    id;         // 36: ID of the request
    uint32_t                    pad[6];
#else
    uint32_t                    pad[7];
#endif
} dacsi_wid_elem_t __attribute__((aligned(16)));

typedef struct dacsi_wait_queue
{
    pthread_mutex_t lock;
    uint32_t        flags;
#define DACSI_WID_RESERVED 0x80000000

    dacsi_wid_elem_t *head;
    dacsi_wid_elem_t *tail;
} dacsi_wait_queue_t __attribute__((aligned(16)));

/*--------------------------------------------------------------------*/
/*  Macros                                                            */
/*--------------------------------------------------------------------*/
#if defined(DACS_HYBRID) || defined(DACS_PPU)

#define DACSI_WID_QUEUES_LOCK_INIT()   DACS_MUTEX_INIT(&dacsi_waitq_lock)
#define DACSI_LOCK_WID_QUEUES()        DACS_MUTEX_LOCK(&dacsi_waitq_lock)
#define DACSI_UNLOCK_WID_QUEUES()      DACS_MUTEX_UNLOCK(&dacsi_waitq_lock)

#define DACSI_WID_QUEUE_LOCK_INIT(wid) DACS_MUTEX_INIT(&dacsi_waitq[(wid)].lock)
#define DACSI_LOCK_WID_QUEUE(wid)      DACS_MUTEX_LOCK(&dacsi_waitq[(wid)].lock)
#define DACSI_TRYLOCK_WID_QUEUE(wid)   DACS_MUTEX_TRYLOCK(&dacsi_waitq[(wid)].lock)
#define DACSI_UNLOCK_WID_QUEUE(wid)    DACS_MUTEX_UNLOCK(&dacsi_waitq[(wid)].lock)

#else

#error "Invalid platform or no platform specified"

#endif

// We don't lock on this check so that it can be taken under lock.  Plus for
// lightweight debug checks a lock is probably not necessary.
#define DACSI_IS_WID_RESERVED(wid)                             \
        ((dacsi_waitq[wid].flags & DACSI_WID_RESERVED) == DACSI_WID_RESERVED)

#if defined(__GNUC_STDC_INLINE__)
#define __inline__ __attribute__((gnu_inline)) inline
#else
#define __inline__ inline
#endif

/*--------------------------------------------------------------------*/
/*  Global Variables                                                  */
/*--------------------------------------------------------------------*/

#ifdef DACS_WIDS_C
#define GLOBAL
#else
#define GLOBAL extern
#endif

/**
 * Global lock for the all of the wait queues. This is used during
 * reserveation and releasing of wait identifiers to maintain the queue
 * array state
 */
#if defined(DACS_HYBRID) || defined(DACS_PPU)
GLOBAL pthread_mutex_t dacsi_waitq_lock;
#endif

/**
 * Array of wait queues. A wait identifier is an index into this array
 */
#if defined(DACS_PPU)
extern struct dacsi_wait_queue dacsi_waitq[];
#else
GLOBAL struct dacsi_wait_queue dacsi_waitq[DACSI_WID_MAX];
#endif

/*--------------------------------------------------------------------*/
/*  Function Prototypes                                               */
/*--------------------------------------------------------------------*/

/**
 * This function must be called before WIDs are used to initialize the
 * data structures associated with WIDs.
 */
void dacsi_wids_init();

/**
 * This function must be called before DaCS terminates to cleanup any
 * data structures associated with WIDs. It is assumed that all
 * outstanding requests at DaCS termination are cleand up prior to calling
 * this function
 */
void dacsi_wids_destroy();

/**
 * Lock the Queue associated with the specified wid. This allows the
 * client to lock the queue so no changes occur during its use. The user
 * would lock the queue so no additional operations are added/deleted or
 * the wid is not released. This lock should only be held for short
 * durations.
 *
 * @param wid [in] the wait identifier to queue the operation on
 *
 * @return validation status of tag
 * <ul>
 * <li>DACS_ERR_NO_ERROR - operation completed successfully
 * <li>DACS_ERR_WID_NOT_RESERVED - WID is no longer reserved for
 * operations
 * <li>DACS_ERR_INVALID_WID - WID has an out of range value
 * </ul>
 *
 * @see #dacs_wid_unlock
 */
#ifndef DACS_WIDS_C
__inline__ extern
#endif
DACS_ERR_T dacsi_wid_lock(dacs_wid_t wid)
{
#ifdef DACS_ERROR_CHECKING
    if (wid >= DACSI_WID_MAX) return DACS_ERR_INVALID_WID;
#endif

    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    // Lock the queue while we check its status
    DACSI_LOCK_WID_QUEUE(wid);

    // Make sure this wid is still reserved
#ifdef DACS_ERROR_CHECKING
    if (dacsi_waitq[wid].flags & DACSI_WID_RESERVED) {
        // WID is reserved and cannot be releaased until the wid is
        // unlocked by the caller
    } else {
        // Cannot lock wid - not reserved
        dacs_rc = DACS_ERR_INVALID_WID;

        // Unlock the queue now that we are done with it
        DACSI_UNLOCK_WID_QUEUE(wid);
    }
#endif

    return dacs_rc;
}



/**
 * Unlock the queue associated with the specified WID. No error checking
 * is done on the wid, it is assumed that dacsi_wid_lock was called with
 * the same wid to ensure that the wid was valid.
 *
 * @pre #dacsi_wid_lock was called
 * @post wid queue is unlocked
 *
 * @param wid [in] the wait identifier to queue the operation on
 *
 * @return DACS_ERR_NO_ERROR on success or DACS_ERR_GENERIC if the
 * unlock failed
 *
 */
#ifndef DACS_WIDS_C
__inline__ extern
#endif
DACS_ERR_T dacsi_wid_unlock(dacs_wid_t wid)
{
    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    // Unlock the queue now that we are done with it
    DACSI_UNLOCK_WID_QUEUE(wid);

    return dacs_rc;
}

/**
 * Add a new element to a wait queue. The element queued in FIFO order
 * on the wait queue
 *
 * @pre the WID queue is already locked
 * @post the operation is enqueued
 *
 * @param wid [in] the wait identifier to queue the operation on
 * @param elem [in] a pointer to the element to add
 *
 */
#ifndef DACS_WIDS_C
__inline__ extern
#endif
void dacsi_wid_enq_tail(dacs_wid_t wid, dacsi_wid_elem_t *elem)
{
    elem->next = 0; // end of the list

    // If the list is empty, add it to the head
    if (!dacsi_waitq[wid].head) {
        dacsi_waitq[wid].head = elem;
    } else {
        // Add it to the end of the list
        dacsi_waitq[wid].tail->next = elem;
    }

    // Point the tail to the new end
    dacsi_waitq[wid].tail = elem; 
}

/**
 * Remove the head element from the wait queue. It is assumed that the
 * wait queue is locked prior to calling this function
 *
 * @pre the WID queue is already locked
 * @post the operation at the head of the queue is dequeued
 *
 * @param waitq [in] the address of the wait queue to manipulate
 *
 * @return the head element or NULL if the queue is empty
 */
#ifndef DACS_WIDS_C
__inline__ extern
#endif
dacsi_wid_elem_t * dacsi_wid_deq_head(struct dacsi_wait_queue * waitq)
{
    dacsi_wid_elem_t * op = waitq->head;

    if (op) {
        // Pull off the head element and make a new head
        waitq->head = op->next;

        // Make sure this element is no longer in a list
        op->next = NULL;

        // Check if deque the last and only element
        if (waitq->tail == op) {
            waitq->tail = NULL;
        }
    } else {
        // Queue is empty
    }

    return op;
}

#undef GLOBAL

#endif
