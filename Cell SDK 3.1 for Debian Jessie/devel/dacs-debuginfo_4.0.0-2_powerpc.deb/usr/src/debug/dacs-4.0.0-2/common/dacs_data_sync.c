/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/*
 * dacs_data_sync.c - defines functions for DaCS process control
 */

/*--------------------------------------------------------------------*/
/*  Includes                                                          */
/*--------------------------------------------------------------------*/

#include <dacs.h>
#include <dacsi_wids.h>
#include <dacs_common.h>

#if defined(DACS_HYBRID)
#include <dacs_hybrid_data_sync.h>
#endif

#if defined(DACS_PPU)
#include <dacs_ppu_data_sync.h>
#endif

/*--------------------------------------------------------------------*/
/*  Function Definitions                                              */
/*--------------------------------------------------------------------*/



DACS_ERR_T dacs_test(dacs_wid_t wid)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized)   return DACS_ERR_NOT_INITIALIZED;
    if (wid >= DACSI_WID_MAX) return DACS_ERR_INVALID_WID;
#endif

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_TEST,token,1,wid);

    DACS_ERR_T op_rc, dacs_rc = DACS_SUCCESS;

    struct dacsi_wait_queue * q = &dacsi_waitq[wid];
    DACSI_LOCK_WID_QUEUE(wid);

    // Make sure this wid is reserved
    if (q->flags & DACSI_WID_RESERVED) {
        dacs_rc = DACS_WID_READY;

        if (q->head) {
            while(q->head && (dacs_rc != DACS_WID_BUSY)) {
                dacsi_wid_elem_t* op = q->head;

                // Call the approriate tier test code. It is assumed
                // that if the operation is not busy, that the data
                // for the operation was cleaned up by the test code
#if   defined(DACS_HYBRID) && !defined(DACS_PPU)
                op_rc = dacs_hybrid_test(q,op);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
                if ((op->de == DACS_DE_PARENT) && (op->pid == DACS_PID_PARENT)) {
                    op_rc = dacs_hybrid_test(q,op);
                } else {
                    op_rc = dacs_ppu_test(q, wid);
                }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
                op_rc = dacs_ppu_test(q, wid);
#else
#error "Invalid platform or no platform specified"
#endif 
                // Update the function return value only if the
                // current value is success. If any failure is
                // detected, it will report the first one found. All
                // other errors will be ignored
                if (dacs_rc == DACS_SUCCESS) {
                    dacs_rc = op_rc;
                }
            }
        } else {
            // No requests were pending on wait queue
            dacs_rc = DACS_ERR_WID_NOT_ACTIVE;
        }
    } else {
        // Wid was not reserved
        dacs_rc = DACS_ERR_INVALID_WID;
    }

    DACSI_UNLOCK_WID_QUEUE(wid);

#ifdef DACS_HYBRID
    // Ensure all memory is synchronized before continuing
    dacsi_memory_barrier();
#endif

    TRACE_POINT_EXIT(_DACS_TEST,token,1,dacs_rc);

    return dacs_rc;
}

/*--------------------------------------------------------------------*/

DACS_ERR_T dacs_wait(dacs_wid_t wid)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_initialized)   return DACS_ERR_NOT_INITIALIZED;
    if (wid >= DACSI_WID_MAX) return DACS_ERR_INVALID_WID;
#endif

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_WAIT,token,1,wid);

    DACS_ERR_T op_rc, dacs_rc = DACS_SUCCESS;

    struct dacsi_wait_queue * q = &dacsi_waitq[wid];

    DACSI_LOCK_WID_QUEUE(wid);

    TRACE_TIMER_TOKEN(timer_token);
    TRACE_TIMER_START(timer_token);

    // Make sure this wid is reserved
    if (q->flags & DACSI_WID_RESERVED) {            
        if (q->head) {
            while (q->head) {
                dacsi_wid_elem_t* op = q->head;

                // Call the approriate tier wait code. It is assumed
                // that when the call completes (successfully or in error), 
                // the operation is done and the data for the operation was 
                // cleaned up by the wait code
#if   defined(DACS_HYBRID) && !defined(DACS_PPU)
                op_rc = dacs_hybrid_wait(q,op);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
                if ((op->de == DACS_DE_PARENT) && (op->pid == DACS_PID_PARENT)) {
                    op_rc = dacs_hybrid_wait(q,op);
                } else {
                    op_rc = dacs_ppu_wait(q, wid);
                }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
                op_rc = dacs_ppu_wait(q, wid);
#else
#error "Invalid platform or no platform specified"
#endif 
                // Update the function return value only if the
                // current value is success. If any failure is
                // detected, it will report the first one found. All
                // other errors will be ignored
                if (dacs_rc == DACS_SUCCESS) {
                    dacs_rc = op_rc;
                }
            }
        } else {
            // No requests were pending on wait queue
            dacs_rc = DACS_ERR_WID_NOT_ACTIVE;
        }
    } else {
        // The WID was not reserved
        dacs_rc = DACS_ERR_INVALID_WID;
    }

    TRACE_TIMER_END(dacs_wait,timer_token);

    DACSI_UNLOCK_WID_QUEUE(wid); 

#ifdef DACS_HYBRID
    // Ensure all memory is synchronized before continuing
    dacsi_memory_barrier();
#endif

    TRACE_POINT_EXIT(_DACS_WAIT,token,1,dacs_rc);

    return dacs_rc;
}
