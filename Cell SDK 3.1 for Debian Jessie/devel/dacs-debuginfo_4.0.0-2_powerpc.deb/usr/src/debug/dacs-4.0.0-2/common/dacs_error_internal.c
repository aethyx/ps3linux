/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

static char *ident = "@(#) internal-src/lib/dacs/common/dacs_error_internal.c v1.8 - 9/16/08 09:55:53 @(#)";

/*
 * dacs_error_internal.c
 *
 * Common (non-SPU) error handling services, internal to the DaCS lib.
 */
#include <dacs.h>
#include <dacs_error_internal.h>
#include <pthread.h>
#include <signal.h>
#include <stdlib.h>
#include <stdio.h>

#if defined(DACS_HYBRID) && !defined(DACS_PPU)
#include <dacsd_spi.h>
#endif

volatile int            _err_thread_ready = 0;
static int              _err_inited = 0; 
static pthread_t        _err_thread_id;
static dacsi_error_t    _err_info_default =
    { DACSI_ERROR_NAME, DACS_STS_PROC_FAILED, SIGTERM, 0, 0 };

/* list of registered error handlers */
extern dacsi_error_handler_t *_error_handlers;

/*
 * Call error handlers
 *
 * -abnormal termination of a child, and any synchronous errors
 * that get reported to us here are fatal
 */
void
dacsi_throw_error(dacsi_error_t *error, unsigned type)
{
    dacsi_error_handler_t *handler = _error_handlers;

    while (handler) {
        (*handler->handler)((dacs_error_t)error);
        handler = handler->next;
    }

    if ((type == DACSI_ERROR_ASYNC && error->err_num == DACS_STS_PROC_ABORTED)
	|| type == DACSI_ERROR_SYNC)
    {
        fprintf(stderr, "FATAL ERROR: %s de: %08x pid: %llx code: %u\n",
                dacs_strerror(error->err_num), error->err_de,
                (unsigned long long)(error->err_pid), error->err_code); 
        abort();
    }
    return;
}


/*
 * Wait on asynchronous error notification via SIGTERM.
 */
void *
dacsi_error_wait(void *sigmask)
{
    int rc;
    sigset_t mask = *(sigset_t *)sigmask;
    siginfo_t info;
    dacsi_error_t errinfo;

    /* tell my creator I'm on my feet */
    _err_thread_ready = 1;

    /* enable cancelation */
    pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
    pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);

    while (1) {

	sigemptyset(&mask);
	sigaddset(&mask, SIGTERM);
    
        rc = sigwaitinfo(&mask, &info);
        /*
         * Async errors come in as a SIGTERM.  If we're on the host
         * (hybrid only) we query the hdacsd for information on the
         * error.  If we fail to get that information, or we're in
         * any of the other cases, we report just report it as a
         * termination request with no other information.
         */
        if (rc == SIGTERM) {
#if defined(DACS_HYBRID) && !defined(DACS_PPU)
            rc = dacsd_he_get_error(info.si_value.sival_int, &errinfo);
            if (rc == 0)
                dacsi_throw_error(&errinfo, DACSI_ERROR_ASYNC);
            else
#endif
                dacsi_throw_error(&_err_info_default, DACSI_ERROR_ASYNC);
        }
    }

    /* will never get here */
    return NULL;

}

/*
 * Initialize error handling
 * - block SIGTERM and starts error handling thread
 */
DACS_ERR_T
dacsi_error_init()
{
    int rc;
    sigset_t sigmask;
    pthread_attr_t attr;

    /* This is an internal service, so
     * let ourselves off easy if we're
     * already initialized
     */
    if (_err_inited)
        return DACS_SUCCESS;

    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);

    sigemptyset(&sigmask);
    sigaddset(&sigmask, SIGTERM);

    pthread_sigmask(SIG_BLOCK, &sigmask, NULL);
    rc = pthread_create(&_err_thread_id, &attr,
            &dacsi_error_wait, (void *)&sigmask);

    if (rc != 0) {
        pthread_sigmask(SIG_UNBLOCK, &sigmask, NULL);
        return DACS_ERR_NO_RESOURCE;
    }

    /* error handling thread is picking sigmask off
     * our stack so wait here until he's done that
     */
    while (!_err_thread_ready);;

    _err_inited = 1;
    return DACS_SUCCESS;
}

/*
 * Shut down error handling
 * -cancels the error handling thread
 *  and unblocks SIGTERM
 */
void
dacsi_error_exit()
{
    if (_err_inited) {
        sigset_t sigmask;
        sigemptyset(&sigmask);
        sigaddset(&sigmask, SIGTERM);

        pthread_cancel(_err_thread_id);
        pthread_join(_err_thread_id, NULL);
        pthread_sigmask(SIG_UNBLOCK, &sigmask, NULL);

        _err_inited = 0;
    }
    return;
}
