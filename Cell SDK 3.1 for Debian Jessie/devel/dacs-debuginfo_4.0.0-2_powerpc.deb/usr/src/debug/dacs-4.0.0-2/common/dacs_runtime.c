/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

static char *ident = "@(#) internal-src/lib/dacs/common/dacs_runtime.c v1.44 - 9/16/08 09:57:55 @(#)";

/*
 * dacs_runtime.c - defines functions for initializing / deinitializing DaCS processes
 */

/*--------------------------------------------------------------------*/
/*  Includes                                                          */
/*--------------------------------------------------------------------*/

#include <dacs.h>
#include <dacs_common.h>
#include <dacs_error_internal.h> // For init/exit functions
#include <dacsi_wids.h>
#include <dacsi_dma.h>
#include <dacsi_mem.h>
#if defined(DACS_HYBRID)
#include <dacs_hybrid_runtime.h>
#endif
#include <stdlib.h>
#include <limits.h>
#include <errno.h>

#ifdef DACS_PPU
#include <dacs_ppu_runtime.h>
#endif

TRACE_TIMERS_STRUCTURE_DEFINE;
TRACE_COUNTERS_STRUCTURE_DEFINE;

int  dacsi_threaded = 1;
long dacsi_numa_node = -1;

DACS_ERR_T dacs_runtime_init(void *arg1, void *arg2)
{
    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    // The arguments are currently unused and not supported
    if (arg1 || arg2) {
        dacs_rc = DACS_ERR_INVALID_ADDR;
    } else {
        dacs_rc = dacs_init(0);
    }

    return dacs_rc;
}

DACS_ERR_T dacs_runtime_exit()
{
    return dacs_exit();
}

DACS_ERR_T dacs_init(int config_flags)
{
    DACS_ERR_T rc = DACS_SUCCESS;

    TRACE_INIT();

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_INIT,token,1,config_flags);
    TRACE_TIMERS_STRUCTURE_INIT;
    TRACE_COUNTERS_STRUCTURE_INIT;

    if (dacsi_is_init()) {
          rc = DACS_ERR_INITIALIZED;
          goto err_out;
      }

    if ((config_flags != 0) && (config_flags != DACS_INIT_SINGLE_THREADED)) {
        rc = DACS_ERR_INVALID_ATTR;
        goto err_out;
    }

    // Enable or disable threading support based on user input
    if (config_flags & DACS_INIT_SINGLE_THREADED) {
        dacsi_threaded = 0;
    } else {
        dacsi_threaded = 1;
    }

    /* start error handling thread */
    /* moving it so all threads get sigblock for sigterm */
    rc = dacsi_error_init();
    if (rc != DACS_SUCCESS) {
        dacsi_error_exit();
        goto err_out;   
    }

#if    defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_runtime_init(NULL, NULL, &dacsi_local_de_id, 
                                  &dacsi_local_pid);
#elif  defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_hybrid_runtime_init(NULL, NULL, &dacsi_local_de_id, 
                                  &dacsi_local_pid);

    if(rc == DACS_SUCCESS) {
        char * numa_id_str = getenv("DACS_HYBRID_INTERNAL_NUMA_NODE");
        if (numa_id_str != NULL) {
            char *endptr = NULL;
            unsigned long numa_id = strtol(numa_id_str,&endptr,0);

            if ((*endptr != 0) ||
                (((numa_id == LONG_MAX) || (numa_id == LONG_MIN)) && 
                 (errno == ERANGE)))  {
                // Value was invalid - too big, not a number, etc...
                rc = DACS_ERR_INTERNAL;
            } else {
                // Value was converted, use it
                dacsi_numa_node = numa_id;
            }
        } else {
            // Value must be set
            rc = DACS_ERR_INTERNAL;
        }

        if (rc == DACS_SUCCESS) {
            // pass in the ppu's de
            rc = dacs_ppu_init(NULL, NULL, &dacsi_local_de_id, &dacsi_local_pid);
        }
    }
#elif  !defined(DACS_HYBRID) && defined(DACS_PPU)
    dacsi_local_de_id  = 0x01010000; //OPT = 01 BLADE = 01 
    rc = dacs_ppu_init(NULL, NULL, &dacsi_local_de_id, &dacsi_local_pid);
#else
#error "Invalid platform or no platform specified"
#endif

    /* error handling thread */
    if (rc != DACS_SUCCESS) {
        dacsi_error_exit();
    }
    else {
        dacsi_proc_sync_init();
        dacsi_wids_init();
        dacsi_remote_mem_init();
        dacsi_mem_init();
    }

    if (rc == DACS_SUCCESS) {
        dacsi_initialized = 1;
    }

err_out:
    TRACE_POINT_EXIT(_DACS_INIT,token,1,rc);

    return rc;
}

/*--------------------------------------------------------------------*/
DACS_ERR_T dacs_exit()
{
    DACS_ERR_T rc = DACS_SUCCESS;

#ifdef DACS_ERROR_CHECKING
    if(!dacsi_is_init())
        return DACS_ERR_NOT_INITIALIZED;
#endif

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_EXIT,token,1,0);
    TRACE_COUNTERS_TRACE_POINT;
    TRACE_TIMERS_TRACE_POINT;

#if    defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_runtime_exit();
#elif  defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_hybrid_runtime_exit();
    if(rc == DACS_SUCCESS) {
        rc = dacs_ppu_exit();
    }
#elif  !defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_ppu_exit();
#else
#error "Invalid platform or no platform specified"
#endif

    /* shut down error handling thread */
    if (rc == DACS_SUCCESS) {
        dacsi_proc_sync_exit();
        dacsi_wids_destroy();
        dacsi_remote_mem_exit();
        dacsi_mem_exit();
        dacsi_error_exit();
    }

    if (rc == DACS_SUCCESS) {
        dacsi_initialized = 0;
    }

    TRACE_POINT_EXIT(_DACS_EXIT,token,1,rc);

    return rc;
}
