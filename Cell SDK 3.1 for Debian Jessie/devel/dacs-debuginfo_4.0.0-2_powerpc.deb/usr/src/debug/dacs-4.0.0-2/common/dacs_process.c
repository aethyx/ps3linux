/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

static char *ident = "@(#) internal-src/lib/dacs/common/dacs_process.c v1.25 - 9/16/08 09:57:56 @(#)";

/*
 * dacs_process.h - defines functions for starting DaCS processes
 */

/*--------------------------------------------------------------------*/
/*  Includes                                                          */
/*--------------------------------------------------------------------*/

#include <dacs.h>

#include <dacs_common.h>

#if defined(DACS_HYBRID)
#include <dacs_hybrid_process.h>
#endif

#ifdef DACS_PPU
#include <dacs_ppu_process.h>
#endif

/*--------------------------------------------------------------------*/
/*  Function Definitions                                              */
/*--------------------------------------------------------------------*/

DACS_ERR_T dacs_de_start( de_id_t                     de,
                          void                       *text,
                          char const                **argv,
                          char const                **envv,
                          DACS_PROC_CREATION_FLAG_T   creation_flags,
                          dacs_process_id_t          *pid )
{
#ifdef DACS_ERROR_CHECKING
    if(!dacsi_is_init())                       return DACS_ERR_NOT_INITIALIZED;
    if(pid == NULL)                            return DACS_ERR_INVALID_ADDR;
    if(text == NULL)                            return DACS_ERR_INVALID_PROG;
    if((creation_flags != DACS_PROC_LOCAL_FILE) 
       && (creation_flags != DACS_PROC_LOCAL_FILE_LIST)
       && (creation_flags != DACS_PROC_REMOTE_FILE)
       && (creation_flags != DACS_PROC_EMBEDDED) ) return DACS_ERR_INVALID_ATTR;
    if (de == (de_id_t)DACS_DE_SELF)
        return DACS_ERR_INVALID_TARGET;

#endif

    DACS_ERR_T rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_DE_START, token, 1, de, (uintptr_t)text, 
                      (uintptr_t)argv, (uintptr_t)envv, creation_flags, 
                      (uintptr_t)pid);

#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_de_start(de,text,argv,envv,creation_flags,pid);
#elif  defined(DACS_PPU)
    rc = dacs_ppu_de_start(de,text,argv,envv,creation_flags,pid);
#else
#error "Invalid platform or no platform specified"
#endif

    if (rc == DACS_SUCCESS) {
	TRACE_COUNTER_INCREMENT(dacs_de_starts,1);
    }
    TRACE_POINT_EXIT(_DACS_DE_START,token,1,rc,*pid);

    return rc;
}

/*--------------------------------------------------------------------*/
DACS_ERR_T dacs_num_processes_supported(de_id_t de, uint32_t *num_processes)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_init())
        return DACS_ERR_NOT_INITIALIZED;
    if (de == (de_id_t)DACS_DE_SELF)
        return DACS_ERR_INVALID_TARGET;
    if (num_processes == NULL)
        return DACS_ERR_INVALID_ADDR;
#endif

    DACS_ERR_T rc = DACS_SUCCESS;
#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_num_processes_supported(de,num_processes);
#elif  defined(DACS_PPU)
    rc = dacs_ppu_num_processes_supported(de,num_processes);
#else
#error "Invalid platform or no platform specified"
#endif
    return rc;
}

/*--------------------------------------------------------------------*/
DACS_ERR_T dacs_num_processes_running(de_id_t de, uint32_t *num_processes)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_init())
        return DACS_ERR_NOT_INITIALIZED;
    if (de == (de_id_t)DACS_DE_SELF)
        return DACS_ERR_INVALID_TARGET;
    if (num_processes == NULL)
        return DACS_ERR_INVALID_ADDR;
#endif

    DACS_ERR_T rc = DACS_SUCCESS;
#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_num_processes_running(de,num_processes);
#elif  defined(DACS_PPU)
    rc = dacs_ppu_num_processes_running(de,num_processes);
#else
#error "Invalid platform or no platform specified"
#endif
    return rc;
}

/*--------------------------------------------------------------------*/
DACS_ERR_T dacs_de_wait (de_id_t de, dacs_process_id_t pid, int32_t *exit_status)
{

#ifdef DACS_ERROR_CHECKING
    if(!dacsi_is_init())                       return DACS_ERR_NOT_INITIALIZED;
    if(exit_status == NULL)                    return DACS_ERR_INVALID_ADDR;
#endif

    DACS_ERR_T rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_DE_WAIT, token, 1, de, pid, (uintptr_t)exit_status);

#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_de_wait(de,pid,exit_status);
#elif  defined(DACS_PPU)
    rc = dacs_ppu_de_wait(de,pid,exit_status);
#else
#error "Invalid platform or no platform specified"
#endif

    if (rc == DACS_SUCCESS) {
	TRACE_COUNTER_INCREMENT(dacs_de_waits,1);
    }
    TRACE_POINT_EXIT(_DACS_DE_WAIT,token,1,rc,*exit_status);

    return rc;
}

/*--------------------------------------------------------------------*/
DACS_ERR_T dacs_de_test (de_id_t de, dacs_process_id_t pid, int32_t *exit_status)
{
#ifdef DACS_ERROR_CHECKING
    if(!dacsi_is_init())                       return DACS_ERR_NOT_INITIALIZED;
    if(exit_status == NULL)                    return DACS_ERR_INVALID_ADDR;
#endif

    DACS_ERR_T rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_DE_TEST, token, 1, de, pid, (uintptr_t)exit_status);

#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_de_test(de,pid,exit_status);
#elif  defined(DACS_PPU)
    rc = dacs_ppu_de_test(de,pid,exit_status);
#else
#error "Invalid platform or no platform specified"
#endif

    TRACE_POINT_EXIT(_DACS_DE_TEST,token,1,rc,*exit_status);

    return rc;
}

/*--------------------------------------------------------------------*/
DACS_ERR_T dacs_de_kill (de_id_t de, dacs_process_id_t pid,DACS_KILL_TYPE_T kill_type)
{
#ifdef DACS_ERROR_CHECKING
    if(!dacsi_is_init())                       return DACS_ERR_NOT_INITIALIZED;
    if(kill_type != DACS_KILL_TYPE_ASYNC)      return DACS_ERR_INVALID_ATTR;
#endif

    DACS_ERR_T rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_DE_KILL,token,1,de,pid,kill_type);

#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_de_kill(de,pid,kill_type);
#elif  defined(DACS_PPU)
    rc = dacs_ppu_de_kill(de,pid,kill_type);
#else
#error "Invalid platform or no platform specified"
#endif
    
    TRACE_POINT_EXIT(_DACS_DE_KILL,token,1,rc);
    return rc;
}
