/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/*
 * dacs_proc_sync.c - defines functions prototypes for DaCS interprocess synchronization
 */

static char *ident = "@(#) internal-src/lib/dacs/common/dacs_proc_sync.c v1.51 - 5/28/08 11:10:31 @(#)";

/*--------------------------------------------------------------------*/
/*  Includes                                                          */
/*--------------------------------------------------------------------*/

#include <dacs.h>
#include <stdio.h>

#include <dacs_common.h>
#include <dacsi_shared_obj.h>
#include <dacsi_proc_sync.h>

#if defined(DACS_HYBRID)
#include <dacs_hybrid_proc_sync.h>
#define __USE_UNIX98
#include <pthread.h>
#include <assert.h>
#include <sched.h>
#endif

#ifdef DACS_PPU
#include <dacs_atomic.h>
#include <dacs_ppu_proc_sync.h>
#include <dacs.h>
#endif

/*--------------------------------------------------------------------*/
/*  Macros                                                            */
/*--------------------------------------------------------------------*/

/*--------------------------------------------------------------------*/
/*  Global Variables                                                  */
/*--------------------------------------------------------------------*/
#if defined(DACS_HYBRID) || defined(DACS_PPU)
/// We keep a list of all of the shared mutexes, for validity checking and cleanup
pthread_rwlock_t     dacsi_mutex_list_rwlock = PTHREAD_RWLOCK_INITIALIZER;;
dacsi_shared_obj_t * dacsi_mutex_list_head   = NULL;
dacsi_shared_obj_t * dacsi_mutex_list_tail   = NULL;
#endif


/*--------------------------------------------------------------------*/
/*  Function Definitions                                              */
/*--------------------------------------------------------------------*/

DACS_ERR_T  dacs_mutex_init ( dacs_mutex_t *mutex)
{

#ifdef DACS_ERROR_CHECKING
    if ( !dacsi_is_init() )  return DACS_ERR_NOT_INITIALIZED;
    if ( !mutex           )  return DACS_ERR_INVALID_ADDR;
#endif
    DACS_ERR_T err = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MUTEX_INIT,token,1,(uintptr_t)mutex);

#if defined(DACS_HYBRID) || defined(DACS_PPU)
    dacsi_shared_obj_t *obj;

    DACSI_MUTEX_LIST_WRLOCK();

    //Create our shared obj and manage it internally
    err = dacsi_shared_obj_create(  &obj,
                                    &dacsi_mutex_list_head, 
                                    &dacsi_mutex_list_tail);
    if(err) {
        DACSI_MUTEX_LIST_UNLOCK();
	TRACE_POINT_EXIT(_DACS_MUTEX_INIT,token,1,err,NULL,NULL,NULL);
        return err;
    }

    *mutex = (dacs_mutex_t)(uintptr_t)obj;

    // Fill in the mutex specific parts of the shared object
    obj->name       = DACSI_MUTEX_NAME;
    obj->mutex.lock = 0;
    obj->mutex.lock_de = 0;
    obj->mutex.lock_pid = 0;

    DACSI_MUTEX_LIST_UNLOCK();

#else
#error "Invalid platform or no platform specified"
#endif

    TRACE_POINT_EXIT(_DACS_MUTEX_INIT,token,1,err,(uintptr_t)mutex,*mutex,(uintptr_t)&(obj->mutex.lock));

    return err ;
}

/*--------------------------------------------------------------------*/
DACS_ERR_T dacs_mutex_share( de_id_t             dst_de,
                             dacs_process_id_t   dst_pid,
                             dacs_mutex_t        mutex )
{

#ifdef DACS_ERROR_CHECKING
    if ( !dacsi_is_init() )  return DACS_ERR_NOT_INITIALIZED;
    if(mutex == 0)           return DACS_ERR_INVALID_HANDLE;
    if(dst_de == DACS_DE_SELF)   return DACS_ERR_INVALID_TARGET;
#endif


    DACS_ERR_T rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MUTEX_SHARE,token,1,dst_de,dst_pid,mutex);


#if defined(DACS_HYBRID) || defined(DACS_PPU)
    dacsi_shared_obj_t * obj = ADDR_TO_OBJ(mutex,dacsi_mutex_list_head);

#ifdef DACS_ERROR_CHECKING
    if(!obj)  return DACS_ERR_INVALID_HANDLE;
    if(obj->name != DACSI_MUTEX_NAME) return DACS_ERR_INVALID_HANDLE;
#endif

    DACSI_MUTEX_LIST_RDLOCK();

#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_mutex_share( dst_de, dst_pid, mutex);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)

    if((dst_de == DACS_DE_PARENT) && (dst_pid == DACS_PID_PARENT)) {
        rc = dacs_hybrid_mutex_share( dst_de, dst_pid, mutex);
    } else {
        rc = dacs_ppu_mutex_share( dst_de, dst_pid, mutex);
    }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_ppu_mutex_share( dst_de, dst_pid, mutex);
#endif
    
#else
#error "Invalid platform or no platform specified"
#endif

    DACSI_MUTEX_LIST_UNLOCK();

    TRACE_POINT_EXIT(_DACS_MUTEX_SHARE,token,1,rc);

    return rc;
}

/*--------------------------------------------------------------------*/
extern DACS_ERR_T dacs_mutex_accept( de_id_t             remote_de,
                                     dacs_process_id_t   remote_pid,
                                     dacs_mutex_t       *mutex)
{

#ifdef DACS_ERROR_CHECKING
    if ( !dacsi_is_init() )       return DACS_ERR_NOT_INITIALIZED;
    if(mutex == NULL)             return DACS_ERR_INVALID_ADDR;
    if(remote_de == DACS_DE_SELF)   return DACS_ERR_INVALID_TARGET;
#endif

    DACS_ERR_T rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MUTEX_ACCEPT,token,1,remote_de,remote_pid,(uintptr_t)mutex);

#if defined(DACS_HYBRID) || defined(DACS_PPU)

#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_mutex_accept( remote_de, remote_pid, mutex );
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_hybrid_mutex_accept( remote_de, remote_pid, mutex );
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_ppu_mutex_accept( remote_de, remote_pid, mutex );
#endif

#else
#error "Invalid platform or no platform specified"
#endif

    TRACE_POINT_EXIT(_DACS_MUTEX_ACCEPT,token,1,rc,*mutex);

    return rc;
}

/*--------------------------------------------------------------------*/
extern DACS_ERR_T dacs_mutex_lock (dacs_mutex_t mutex)
{

#ifdef DACS_ERROR_CHECKING
    if ( !dacsi_is_init() )                    return DACS_ERR_NOT_INITIALIZED;
    if(mutex == 0)                             return DACS_ERR_INVALID_HANDLE;
#endif

    DACS_ERR_T rc = DACS_SUCCESS;

#if defined(DACS_HYBRID) || defined(DACS_PPU)
    dacsi_shared_obj_t * obj = ADDR_TO_OBJ(mutex,dacsi_mutex_list_head);

#ifdef DACS_ERROR_CHECKING
    if(!obj)  return DACS_ERR_INVALID_HANDLE;
    if(obj->name != DACSI_MUTEX_NAME)          return DACS_ERR_INVALID_HANDLE;
#endif

#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_mutex_lock(mutex);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    if (obj->owner_de & 0x00FFFFFF) {
        rc = dacs_ppu_mutex_lock(mutex);
    } else {
        rc = dacs_hybrid_mutex_lock(mutex);
    }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_ppu_mutex_lock(mutex);
#endif

#else
#error "Invalid platform or no platform specified"
#endif

    return rc;
}

/*--------------------------------------------------------------------*/
extern DACS_ERR_T dacs_mutex_try_lock (dacs_mutex_t mutex)
{

#ifdef DACS_ERROR_CHECKING
    if ( !dacsi_is_init() )                       return DACS_ERR_NOT_INITIALIZED;
    if(mutex == 0)                             return DACS_ERR_INVALID_HANDLE;
#endif

    DACS_ERR_T rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MUTEX_TRY_LOCK,token,1,mutex);

#if defined(DACS_HYBRID) || defined(DACS_PPU)
    dacsi_shared_obj_t * obj = ADDR_TO_OBJ(mutex,dacsi_mutex_list_head);

#ifdef DACS_ERROR_CHECKING
    if(!obj)  return DACS_ERR_INVALID_HANDLE;
    if(obj->name != DACSI_MUTEX_NAME)          return DACS_ERR_INVALID_HANDLE;
#endif


#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_mutex_try_lock(mutex);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    if (obj->owner_de & 0x00FFFFFF) {
        rc = dacs_ppu_mutex_try_lock(mutex);
    } else {
        rc = dacs_hybrid_mutex_try_lock(mutex);
    }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_ppu_mutex_try_lock(mutex);
#endif

#else
#error "Invalid platform or no platform specified"
#endif

    TRACE_POINT_EXIT(_DACS_MUTEX_TRY_LOCK,token,1,mutex,rc);

    return rc;
}

/*--------------------------------------------------------------------*/
extern DACS_ERR_T dacs_mutex_unlock (dacs_mutex_t mutex)
{

#ifdef DACS_ERROR_CHECKING
    if ( !dacsi_is_init() )                       return DACS_ERR_NOT_INITIALIZED;
    if(mutex == 0)                             return DACS_ERR_INVALID_HANDLE;
#endif

    DACS_ERR_T rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MUTEX_UNLOCK,token,1,mutex);

#if defined(DACS_HYBRID) || defined(DACS_PPU)
    dacsi_shared_obj_t * obj = ADDR_TO_OBJ(mutex,dacsi_mutex_list_head);

#ifdef DACS_ERROR_CHECKING
    if(!obj)  return DACS_ERR_INVALID_HANDLE;
    if(obj->name != DACSI_MUTEX_NAME)          return DACS_ERR_INVALID_HANDLE;
#endif


#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_mutex_unlock(mutex);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    if (obj->owner_de & 0x00FFFFFF) {
        rc = dacs_ppu_mutex_unlock(mutex);
    } else {
        rc = dacs_hybrid_mutex_unlock(mutex);
    }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_ppu_mutex_unlock(mutex);
#endif

#else
#error "Invalid platform or no platform specified"
#endif

    TRACE_POINT_EXIT(_DACS_MUTEX_UNLOCK,token,1,rc);

    return rc;
}

/*--------------------------------------------------------------------*/
extern DACS_ERR_T dacs_mutex_release (dacs_mutex_t *mutex)
{
#ifdef DACS_ERROR_CHECKING
    if ( !dacsi_is_init() )                    return DACS_ERR_NOT_INITIALIZED;
    if(mutex == 0)                             return DACS_ERR_INVALID_ADDR;
#endif

    DACS_ERR_T rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MUTEX_RELEASE,token,1,*mutex);

#if defined(DACS_HYBRID) || defined(DACS_PPU)
    dacsi_shared_obj_t * obj = ADDR_TO_OBJ(*mutex,dacsi_mutex_list_head);

#ifdef DACS_ERROR_CHECKING
    if(!obj)  return DACS_ERR_INVALID_HANDLE;
    if(obj->name != DACSI_MUTEX_NAME)          return DACS_ERR_INVALID_HANDLE;
    if (obj->owner_de == dacsi_local_de_id)    return DACS_ERR_OWNER; 
#endif


#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    dacs_hybrid_mutex_release(mutex);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    if (obj->owner_de & 0x00FFFFFF) {
        rc = dacs_ppu_mutex_release(mutex);
    } else {
        rc = dacs_hybrid_mutex_release(mutex);
    }
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_ppu_mutex_release(mutex);
#endif

#else
#error "Invalid platform or no platform specified"
#endif

    if(rc == DACS_SUCCESS) {
        *mutex = 0;
    }

    TRACE_POINT_EXIT(_DACS_MUTEX_RELEASE,token,1,rc);

    return rc;
}

/*--------------------------------------------------------------------*/
extern DACS_ERR_T dacs_mutex_destroy (dacs_mutex_t *mutex)
{

#ifdef DACS_ERROR_CHECKING
    if ( !dacsi_is_init() )                       return DACS_ERR_NOT_INITIALIZED;
    if(mutex == NULL)                             return DACS_ERR_INVALID_ADDR;
#endif

    DACS_ERR_T rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MUTEX_DESTROY,token,1,*mutex);


    dacsi_shared_obj_t * obj = ADDR_TO_OBJ(*mutex,dacsi_mutex_list_head);

#ifdef DACS_ERROR_CHECKING
    if(!obj)  return DACS_ERR_INVALID_HANDLE;
    if(obj->name != DACSI_MUTEX_NAME)          return DACS_ERR_INVALID_HANDLE;
    if (obj->owner_de != dacsi_local_de_id && obj->owner_pid != dacsi_local_pid)    return DACS_ERR_NOT_OWNER; 
#endif

#if defined(DACS_HYBRID)
    rc = dacs_hybrid_mutex_destroy(mutex);
#endif

   
    DACSI_MUTEX_LIST_WRLOCK();

    rc = dacsi_shared_obj_destroy(obj, &dacsi_mutex_list_head, &dacsi_mutex_list_tail);
    if(rc == DACS_SUCCESS ) {
        *mutex = 0;
    }

    DACSI_MUTEX_LIST_UNLOCK();


    TRACE_POINT_EXIT(_DACS_MUTEX_DESTROY,token,1,rc);

    return rc;
}

/*--------------------------------------------------------------------*/
extern DACS_ERR_T dacs_barrier_wait (dacs_group_t group)
{

#ifdef DACS_ERROR_CHECKING
    if ( !dacsi_is_init() )                       return DACS_ERR_NOT_INITIALIZED;
    if(group == 0)                             return DACS_ERR_INVALID_HANDLE;
#endif

    DACS_ERR_T rc = DACS_SUCCESS;


    TRACE_TIMER_TOKEN(timer_token);
    TRACE_INTERVAL_TOKEN_ARGUMENT(token);

    TRACE_POINT_ENTRY(_DACS_BARRIER_WAIT,token,1,group);
    TRACE_TIMER_START(timer_token);

#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_barrier_wait(group);
#elif defined(DACS_HYBRID) && defined(DACS_PPU)
    /*
     * for combined lib, call hybrid first
     * to see if we have a remote handle.
     */
    rc = dacs_hybrid_barrier_wait(group);
    if (rc == DACS_ERR_INVALID_HANDLE)
        rc = dacs_ppu_barrier_wait(group);
#elif !defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_ppu_barrier_wait(group);
#else
#error "Invalid platform or no platform specified"
#endif

    TRACE_TIMER_END(dacs_barrier_wait,timer_token);
    TRACE_POINT_EXIT(_DACS_BARRIER_WAIT,token,1,rc);

    return rc;
}

/*--------------------------------------------------------------------*/

uint32_t dacsi_proc_sync_init()
{
//    dacsi_mutex_list_head = NULL;
//    dacsi_mutex_list_tail = NULL;
//    pthread_rwlock_init(&dacsi_mutex_list_rwlock,0);

    return DACS_SUCCESS;
}

uint32_t dacsi_proc_sync_exit()
{

    pthread_rwlock_destroy(&dacsi_mutex_list_rwlock);

    while(dacsi_mutex_list_head) {
      dacsi_shared_obj_destroy(dacsi_mutex_list_head, &dacsi_mutex_list_head, &dacsi_mutex_list_tail);
    }

    return DACS_SUCCESS;
}


/*--------------------------------------------------------------------*/
extern DACS_ERR_T dacsi_mutex_lock (de_id_t de,dacs_process_id_t pid,dacs_mutex_t mutex) {
    DACS_ERR_T rc = DACS_SUCCESS;

#if defined(DACS_HYBRID) || defined(DACS_PPU)
    dacsi_shared_obj_t * obj = (dacsi_shared_obj_t *)(uintptr_t) mutex;

#if defined(DACS_PPU)

    dacspi_mutex_lock((mutex_ea_t)(uintptr_t) &(obj->mutex.lock));

#else /* opteron only  */

    uint32_t miss_count = 0;
    while(!atomic_int_lock(&obj->mutex.lock)) {
       if(miss_count == 100) { 
           sched_yield(); /*Dont allow a lock to slam cpu*/
           miss_count =0;
       }
       miss_count ++;
    }/*Loop on miss*/

#endif

    if(rc == DACS_SUCCESS) {
        obj->mutex.lock_de = de; 
        obj->mutex.lock_pid = pid; 
    }
#endif/*end of hybrid or ppu*/

    return rc;
}

/*--------------------------------------------------------------------*/
extern DACS_ERR_T dacsi_mutex_trylock (de_id_t de,dacs_process_id_t pid,dacs_mutex_t mutex) {
    DACS_ERR_T rc = DACS_SUCCESS;

#if defined(DACS_HYBRID) || defined(DACS_PPU)
    dacsi_shared_obj_t * obj = (dacsi_shared_obj_t *)(uintptr_t) mutex;
#if defined(DACS_PPU)
    if( dacspi_mutex_trylock((mutex_ea_t)(uintptr_t) &(obj->mutex.lock))) {
        rc = DACS_SUCCESS;
    }
    else {
        rc = DACS_ERR_MUTEX_BUSY;
    }

#else /* opteron only */
    if(atomic_int_lock(&obj->mutex.lock)) {
        rc = DACS_SUCCESS;
    } 
    else {
        rc =DACS_ERR_MUTEX_BUSY;
    }

#endif

    if(rc == DACS_SUCCESS) {
        obj->mutex.lock_de = de; 
        obj->mutex.lock_pid = pid; 
    }
#endif/*end of hybrid or ppu*/

    return rc;
}

/*--------------------------------------------------------------------*/
extern DACS_ERR_T dacsi_mutex_unlock (de_id_t de,dacs_process_id_t pid,dacs_mutex_t mutex) {
    DACS_ERR_T rc = DACS_SUCCESS;

#if defined(DACS_HYBRID) || defined(DACS_PPU)
    dacsi_shared_obj_t * obj = (dacsi_shared_obj_t *)(uintptr_t) mutex;

    #ifdef DACS_ERROR_CHECKING
    if(de != obj->mutex.lock_de || pid != obj->mutex.lock_pid) {
        return DACS_ERR_NO_PERM;
    }
    #endif/*ifdef DACS_ERROR_CHECKING*/
    obj->mutex.lock_de = 0;
    obj->mutex.lock_pid = 0;

#if defined(DACS_PPU)

    dacspi_mutex_unlock((mutex_ea_t)(uintptr_t) &(obj->mutex.lock));

#else /* opteron only */
    atomic_int_unlock(&obj->mutex.lock);
#endif
#endif/*end of hybrid or ppu*/

    return rc;
}
