/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

// ident = "@(#) internal-src/lib/dacs/common/dacs_error_internal.h v1.4 - 9/16/08 09:55:53 @(#)"

/*
 * dacs_error_internal.h
 *
 * Internal definitions for error handling services
 */
#ifndef _DACS_ERROR_INTERNAL_H_
#define _DACS_ERROR_INTERNAL_H_

#include <dacs.h>
#include <dacsi_shared_obj.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
/* error handler entry */

typedef struct dacsi_error_handler {
    dacs_error_handler_t handler;
    struct dacsi_error_handler *next;
    uint32_t flags;
} dacsi_error_handler_t;

/* the error object */
typedef struct dacsi_error {
    DACSI_SHARED_OBJ_NAME_T name;
    DACS_ERR_T  err_num;
    uint32_t    err_code;
    de_id_t     err_de;
    dacs_process_id_t err_pid;
} dacsi_error_t;

#define DACSI_MAX_ERRSTR 32

typedef struct dacsi_error_str {
    const char  str[DACSI_MAX_ERRSTR];
    DACS_ERR_T  err;
    uint32_t pad[3];
} dacsi_error_str_t __attribute__((aligned(16)));

#define ERRHANDLE_VALID(err) \
    (((err) != 0) && ((dacsi_error_t *)(err))->name == DACSI_ERROR_NAME)

#ifdef DACS_SPU
extern void dacssi_throw_error(dacsi_error_t *error, unsigned type);
extern DACS_ERR_T dacs_spu_errhandler_reg(dacs_error_handler_t handler,
                                            uint32_t flags);
#else
extern void dacsi_throw_error(dacsi_error_t *error, unsigned type);
extern void *dacsi_error_wait(void *sigmask);
extern DACS_ERR_T dacsi_error_init(void);
extern void dacsi_error_exit(void);
extern dacsi_error_str_t dacsi_error_strings[];

#endif

#define DACSI_ERROR_SYNC        1       /* synchronous error */
#define DACSI_ERROR_ASYNC       2       /* asynchronous error */

/* internal service for throwing an error */
static inline void
DACS_THROW_ERROR(DACS_ERR_T err, uint32_t code, de_id_t de,
                    dacs_process_id_t pid)
{
    dacsi_error_t error = { DACSI_ERROR_NAME, err, code, de, pid };
#ifdef DACS_SPU
    dacssi_throw_error(&error, DACSI_ERROR_SYNC); /* may not return */
#else
    dacsi_throw_error(&error, DACSI_ERROR_SYNC); /* may not return */
#endif
    return;
}
#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif
