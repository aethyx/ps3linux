/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

// @(#) internal-src/lib/dacs/common/dacs_common.h v1.16 - 9/16/08 09:59:21 @(#)

/*
 * dacs_common.h
 */

#ifndef _DACS_COMMON_H_
#define _DACS_COMMON_H_

/*--------------------------------------------------------------------*/
/*  Includes                                                          */
/*--------------------------------------------------------------------*/

#include <dacs_trace.h>        // for pdt trace
#include <dacsi_shared_obj.h>  // for mutex, remote_mem, and groups/barriers

/*--------------------------------------------------------------------*/
/*  Global Variables                                                  */
/*--------------------------------------------------------------------*/

extern uint32_t dacsi_initialized;
extern de_id_t  dacsi_local_de_id;
extern dacs_process_id_t  dacsi_local_pid;
extern long dacsi_numa_node;
extern int dacsi_threaded;

/*--------------------------------------------------------------------*/
/*  Function Prototypes                                               */
/*--------------------------------------------------------------------*/

#ifdef DACS_ERROR_CHECKING
#define ADDR_TO_OBJ(addr,head) dacsi_find_shared_obj_by_addr(addr,head)
#else
#define ADDR_TO_OBJ(addr,head) ((dacsi_shared_obj_t*)(uintptr_t)(addr))
#endif

dacsi_shared_obj_t * dacsi_find_shared_obj_by_addr(uint64_t  addr,dacsi_shared_obj_t * head);


#if defined(DACS_HYBRID) && !defined(DACS_PPU)
    /*A return of 0 is when ptr value is == to new(MISS).  If not equal then return is 1*/
    inline unsigned char atomic_int_update(uint32_t *ptr,uint32_t old,uint32_t new);
    #define atomic_int_unlock(ptr) atomic_int_update(ptr,1,0)
    #define atomic_int_lock(ptr) atomic_int_update(ptr,0,1)
#endif /* opteron only */


uint32_t dacsi_is_init(void);

uint32_t dacsi_proc_sync_init();
uint32_t dacsi_proc_sync_exit();


#if defined(DACS_HYBRID) && !defined(DACS_PPU) // Hybrid-only
#define DACS_MUTEX_INIT(mutex_ptr)      pthread_mutex_init((mutex_ptr),NULL)
#define DACS_MUTEX_LOCK(mutex_ptr)      (dacsi_threaded ? pthread_mutex_lock((mutex_ptr)) : 0)
#define DACS_MUTEX_TRYLOCK(mutex_ptr)   (dacsi_threaded ? pthread_mutex_trylock((mutex_ptr)) : 0)
#define DACS_MUTEX_UNLOCK(mutex_ptr)    (dacsi_threaded ? pthread_mutex_unlock((mutex_ptr)) : 0)
#define DACS_MUTEX_DESTROY(mutex_ptr)   pthread_mutex_destroy((mutex_ptr))
#elif  defined(DACS_PPU) // Cell-only and Hybrid-Cell
#define DACS_MUTEX_INIT(mutex_ptr)      pthread_mutex_init((mutex_ptr),NULL)
#define DACS_MUTEX_LOCK(mutex_ptr)      (dacsi_threaded ? pthread_mutex_lock((mutex_ptr)) : 0)
#define DACS_MUTEX_TRYLOCK(mutex_ptr)   (dacsi_threaded ? pthread_mutex_trylock((mutex_ptr)) : 0)
#define DACS_MUTEX_UNLOCK(mutex_ptr)    (dacsi_threaded ? pthread_mutex_unlock((mutex_ptr)) : 0)
#define DACS_MUTEX_DESTROY(mutex_ptr)   pthread_mutex_destroy((mutex_ptr))
#else // All others 
#define DACS_MUTEX_INIT(mutex_ptr)   
#define DACS_MUTEX_LOCK(mutex_ptr)  
#define DACS_MUTEX_UNLOCK(mutex_ptr)
#define DACS_MUTEX_DESTROY(mutex_ptr)
#endif

// Read/Write Memory Barrier
#ifdef DACS_HYBRID
#if defined(__i386__) || defined (__x86_64__)
#define dacsi_memory_barrier() __asm__ __volatile__ ("mfence":::"memory")
#elif defined (__powerpc__)
#define dacsi_memory_barrier() __asm__ __volatile__ ("sync":::"memory")
#else
#error dacsi_memory_barrier not supported on this platform
#endif // Processor architecturer
#endif // DACS_HYBRID

#endif  //  _DACS_COMMON_H_
