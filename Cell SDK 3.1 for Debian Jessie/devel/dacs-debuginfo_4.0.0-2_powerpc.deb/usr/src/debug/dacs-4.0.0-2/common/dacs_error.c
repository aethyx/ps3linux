/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

static char *ident = "@(#) internal-src/lib/dacs/common/dacs_error.c v1.18 - 9/16/08 09:55:45 @(#)";
/*
 * dacs_error.c - services for reporting and handling errors
 */

#include <dacs.h>
#include <dacs_error_internal.h>
#include <dacs_common.h>
#include <stdlib.h>

dacsi_error_handler_t *_error_handlers = NULL;

dacsi_error_str_t    dacsi_error_strings[] =
{
    { "DACS_SUCCESS",                   DACS_SUCCESS, 	            {0} },
    { "DACS_WID_BUSY",                  DACS_WID_BUSY, 	            {0} },
    { "DACS_STS_PROC_RUNNING",          DACS_STS_PROC_RUNNING, 	    {0} },
    { "DACS_STS_PROC_FINISHED",         DACS_STS_PROC_FINISHED, 	{0} },
    { "DACS_STS_PROC_FAILED",           DACS_STS_PROC_FAILED, 	    {0} },
    { "DACS_STS_PROC_ABORTED",          DACS_STS_PROC_ABORTED, 	    {0} },
    { "DACS_STS_PROC_KILLED",           DACS_STS_PROC_ABORTED, 	    {0} },
    { "",                               DACS_LAST_STATUS, 	        {0} },
    { "",                               DACS_ERR_FIRST_ERROR, 	    {0} },
    { "DACS_ERR_INTERNAL",              DACS_ERR_INTERNAL, 	        {0} },
    { "DACS_ERR_SYSTEM",                DACS_ERR_SYSTEM, 	        {0} },
    { "DACS_ERR_INVALID_ARGV",          DACS_ERR_INVALID_ARGV, 	    {0} },
    { "DACS_ERR_INVALID_ENV",           DACS_ERR_INVALID_ENV, 	    {0} },
    { "DACS_ERR_INVALID_HANDLE",        DACS_ERR_INVALID_HANDLE, 	{0} },
    { "DACS_ERR_INVALID_ADDR",          DACS_ERR_INVALID_ADDR, 	    {0} },
    { "DACS_ERR_INVALID_ATTR",          DACS_ERR_INVALID_ATTR, 	    {0} },
    { "DACS_ERR_INVALID_DE",            DACS_ERR_INVALID_DE, 	    {0} },
    { "DACS_ERR_INVALID_PID",           DACS_ERR_INVALID_PID, 	    {0} },
    { "DACS_ERR_INVALID_TARGET",        DACS_ERR_INVALID_TARGET, 	{0} },
    { "DACS_ERR_BUF_OVERFLOW",          DACS_ERR_BUF_OVERFLOW, 	    {0} },
    { "DACS_ERR_NOT_ALIGNED",           DACS_ERR_NOT_ALIGNED, 	    {0} },
    { "DACS_ERR_INVALID_SIZE",          DACS_ERR_INVALID_SIZE, 	    {0} },
    { "DACS_ERR_BYTESWAP_MISMATCH",     DACS_ERR_BYTESWAP_MISMATCH, {0} },
    { "DACS_ERR_NO_RESOURCE",           DACS_ERR_NO_RESOURCE, 	    {0} },
    { "DACS_ERR_PROC_LIMIT",            DACS_ERR_PROC_LIMIT, 	    {0} },
    { "DACS_ERR_NO_PERM",               DACS_ERR_NO_PERM, 	        {0} },
    { "DACS_ERR_OWNER",                 DACS_ERR_OWNER, 	        {0} },
    { "DACS_ERR_NOT_OWNER",             DACS_ERR_NOT_OWNER, 	    {0} },
    { "DACS_ERR_RESOURCE_BUSY",         DACS_ERR_RESOURCE_BUSY, 	{0} },
    { "DACS_ERR_GROUP_CLOSED",          DACS_ERR_GROUP_CLOSED, 	    {0} },
    { "DACS_ERR_GROUP_OPEN",            DACS_ERR_GROUP_OPEN, 	    {0} },
    { "DACS_ERR_GROUP_DUPLICATE",       DACS_ERR_GROUP_DUPLICATE, 	{0} },
    { "DACS_ERR_INVALID_WID",           DACS_ERR_INVALID_WID, 	    {0} },
    { "DACS_ERR_INVALID_STREAM",        DACS_ERR_INVALID_STREAM, 	{0} },
    { "DACS_ERR_NO_WIDS",               DACS_ERR_NO_WIDS, 	        {0} },
    { "DACS_ERR_WID_ACTIVE",            DACS_ERR_WID_ACTIVE, 	    {0} },
    { "DACS_ERR_WID_NOT_ACTIVE",        DACS_ERR_WID_NOT_ACTIVE, 	{0} },
    { "DACS_ERR_INITIALIZED",           DACS_ERR_INITIALIZED, 	    {0} },
    { "DACS_ERR_NOT_INITIALIZED",       DACS_ERR_NOT_INITIALIZED, 	{0} },
    { "DACS_ERR_MUTEX_BUSY",            DACS_ERR_MUTEX_BUSY, 	    {0} },
    { "DACS_ERR_NOT_SUPPORTED_YET",     DACS_ERR_NOT_SUPPORTED_YET, {0} },
    { "DACS_ERR_VERSION_MISMATCH",      DACS_ERR_VERSION_MISMATCH, 	{0} },
    { "DACS_ERR_DACSD_FAILURE",         DACS_ERR_DACSD_FAILURE, 	{0} },
    { "DACS_ERR_INVALID_PROG",          DACS_ERR_INVALID_PROG, 	    {0} },
    { "DACS_ERR_ARCH_MISMATCH",         DACS_ERR_ARCH_MISMATCH, 	{0} },
    { "DACS_ERR_INVALID_USERNAME",      DACS_ERR_INVALID_USERNAME, 	{0} },
    { "DACS_ERR_INVALID_CWD",           DACS_ERR_INVALID_CWD, 	    {0} },
    { "DACS_ERR_NOT_FOUND",             DACS_ERR_NOT_FOUND, 	    {0} },
    { "DACS_ERR_TOO_LONG",              DACS_ERR_TOO_LONG, 	        {0} },
    { "DACS_ERR_DE_TERM",               DACS_ERR_DE_TERM,  	        {0} },
    { "",                               DACS_ERR_LAST_ERROR,        {0} }
};

const char *
dacs_strerror(DACS_ERR_T errcode)
{
    unsigned int i = errcode;

    if (errcode < 0)
        i += DACS_LAST_STATUS - DACS_ERR_FIRST_ERROR + 1;

    //
    // Filter out any bad incoming error codes.
    //
    if (errcode > DACS_LAST_STATUS-1 || errcode < DACS_ERR_FIRST_ERROR+1 ||
        (i > (DACS_LAST_STATUS + (DACS_ERR_LAST_ERROR - DACS_ERR_FIRST_ERROR))))
        return NULL;

    return (const char *)&dacsi_error_strings[i];
}


DACS_ERR_T
dacs_errhandler_reg(dacs_error_handler_t handler, uint32_t flags)
{
    dacsi_error_handler_t *new;
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_init())
        return DACS_ERR_NOT_INITIALIZED;

    if (handler == NULL)
        return DACS_ERR_INVALID_ADDR;

    if (flags != 0)
        return DACS_ERR_INVALID_ATTR;
#endif

    new = malloc(sizeof(dacsi_error_handler_t));
    if (new == NULL)
        return DACS_ERR_NO_RESOURCE;
    
    new->handler = handler;
    new->next = _error_handlers;
    _error_handlers = new;

    return DACS_SUCCESS;
}

DACS_ERR_T
dacs_error_num(dacs_error_t error)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_init())
        return DACS_ERR_NOT_INITIALIZED;

    if (!ERRHANDLE_VALID(error))
        return DACS_ERR_INVALID_HANDLE;
#endif

    return ((dacsi_error_t *)error)->err_num;
}

DACS_ERR_T
dacs_error_code(dacs_error_t error, uint32_t *code)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_init())
        return DACS_ERR_NOT_INITIALIZED;

    if (!ERRHANDLE_VALID(error))
        return DACS_ERR_INVALID_HANDLE;

    if (code == NULL)
        return DACS_ERR_INVALID_ADDR;
#endif

    *code = ((dacsi_error_t *)error)->err_code;

    return DACS_SUCCESS;
}

DACS_ERR_T
dacs_error_str(dacs_error_t error, const char **errstr)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_init())
        return DACS_ERR_NOT_INITIALIZED;

    if (!ERRHANDLE_VALID(error))
        return DACS_ERR_INVALID_HANDLE;

    if (errstr == NULL)
        return DACS_ERR_INVALID_ADDR;
#endif

    *errstr = dacs_strerror(((dacsi_error_t *)error)->err_num);

    if (*errstr == NULL)
        return DACS_ERR_INVALID_HANDLE;

    return DACS_SUCCESS;
}

DACS_ERR_T
dacs_error_de(dacs_error_t error, de_id_t *de)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_init())
        return DACS_ERR_NOT_INITIALIZED;

    if (!ERRHANDLE_VALID(error))
        return DACS_ERR_INVALID_HANDLE;

    if (de == NULL)
        return DACS_ERR_INVALID_ADDR;
#endif

    *de = ((dacsi_error_t *)error)->err_de;

    return DACS_SUCCESS;
}

DACS_ERR_T
dacs_error_pid(dacs_error_t error, dacs_process_id_t *pid)
{
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_init())
        return DACS_ERR_NOT_INITIALIZED;

    if (!ERRHANDLE_VALID(error))
        return DACS_ERR_INVALID_HANDLE;

    if (pid == NULL)
        return DACS_ERR_INVALID_ADDR;
#endif

    *pid = ((dacsi_error_t *)error)->err_pid;

    return DACS_SUCCESS;
}
