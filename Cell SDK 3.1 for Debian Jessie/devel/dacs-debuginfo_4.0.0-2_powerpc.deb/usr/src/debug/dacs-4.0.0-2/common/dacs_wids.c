/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/*
 * dacs_wids.c - defines functions for reserving DaCS Wait IDs (wids)
 */

#define DACS_WIDS_C

#include <dacsi_wids.h>
#include <dacs.h>
#include <dacs_common.h>
#include <stddef.h>

DACS_ERR_T dacs_wid_reserve(dacs_wid_t * wid)
{
#ifdef DACS_ERROR_CHECKING
    if(!dacsi_initialized) return DACS_ERR_NOT_INITIALIZED;
    if(!wid) return DACS_ERR_INVALID_ADDR;    
#endif

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_WID_RESERVE,token,1,(uintptr_t)wid);
 
    unsigned i;
    DACS_ERR_T dacs_rc = DACS_ERR_NO_WIDS;
    *wid = DACS_INVALID_WID;

    DACSI_LOCK_WID_QUEUES();

    for (i = 0; i < DACSI_WID_MAX; ++i) {
        if (!(dacsi_waitq[i].flags & DACSI_WID_RESERVED)) {
            // Reserve the WID and return its id to the caller
            dacsi_waitq[i].flags |= DACSI_WID_RESERVED;
            *wid = i;	
            dacs_rc = DACS_SUCCESS;
            break; // wid reserved
        } else {
            // This wid is reserved already - check the next one
        }
    }

    DACSI_UNLOCK_WID_QUEUES();

    TRACE_POINT_EXIT(_DACS_WID_RESERVE,token,1,dacs_rc,*wid);

    return dacs_rc;
}

/*--------------------------------------------------------------------*/

DACS_ERR_T dacs_wid_release(dacs_wid_t * wid)
{
#ifdef DACS_ERROR_CHECKING
    if(!dacsi_initialized) return DACS_ERR_NOT_INITIALIZED;
    if(!wid) return DACS_ERR_INVALID_ADDR;    
#endif

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_WID_RELEASE,token,1,(uintptr_t)wid,*wid);
 
    DACS_ERR_T dacs_rc = DACS_SUCCESS;

    dacs_wid_t id = *wid;

    if (id < DACSI_WID_MAX) {
        // Lock the wid array while we update the reservation
        DACSI_LOCK_WID_QUEUES();

        if (dacsi_waitq[id].flags & DACSI_WID_RESERVED) {

            // Make sure the wid is locked wile checking it
            if(!DACSI_TRYLOCK_WID_QUEUE(id)) {
                if (!dacsi_waitq[id].head) {
                    // There are no active requests on the queue so
                    // the wid can be released
                    dacsi_waitq[id].flags &= ~DACSI_WID_RESERVED;        

                    // Invalidate the ID of this wid from further use
                    *wid = DACS_INVALID_WID;
                } else {
                    // Operation sstill active on queue
                    dacs_rc = DACS_ERR_WID_ACTIVE;
                }

                // All done working with the wid
                DACSI_UNLOCK_WID_QUEUE(id);
            } else {
                // WID queue is locked -- assume it is active
                dacs_rc = DACS_ERR_WID_ACTIVE;
            }
        } else {
            // Valid wid but not reserved
            dacs_rc = DACS_ERR_INVALID_WID;
        }

        // All done messing with the wid array
        DACSI_UNLOCK_WID_QUEUES();
    } else {
        dacs_rc = DACS_ERR_INVALID_WID;
    }

    TRACE_POINT_EXIT(_DACS_WID_RELEASE,token,1,dacs_rc,*wid);

    return dacs_rc;
}

/*--------------------------------------------------------------------*/

void dacsi_wids_init()
{
    unsigned i;

    // Initialize the wait queue lock
    DACSI_WID_QUEUES_LOCK_INIT();

    // Initialize each individual wait queue entry
    for (i = 0; i < DACSI_WID_MAX; ++i) {
        DACSI_WID_QUEUE_LOCK_INIT(i);
        dacsi_waitq[i].flags = 0;
        dacsi_waitq[i].head = dacsi_waitq[i].tail = 0;
    }
}

/*--------------------------------------------------------------------*/

void dacsi_wids_destroy()
{
    // Currently nothing to clean up - data will get reinitialized 
    // when init is called again
}

