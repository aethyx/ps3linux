/* --------------------------------------------------------------  */
/* (C)Copyright 2008                                               */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/*--------------------------------------------------------------------*/
/*   DaCS Fortran Bindings - c mapping implementation                 */
/*   The functions implemented here are called from Fortran code      */
/*   See dacsf_bindings.h for the external function prototypes        */
/*   and the specific implementation files.                           */
/*   Implementation files are grouped for spu space considerations.   */
/*--------------------------------------------------------------------*/
#include"dacs.h"
#include"dacsf_bindings.h"

/*--------------------------------------------------------------------*/
/*  DaCS Fortran API Wrappers.                                        */
/*  The C function names for the DaCS Fortran API wrappers follow     */
/*  the naming convention (dacs_init is used as an example):          */
/*                                                                    */
/*     Type                            Example wrapper name           */
/*     -------------------------       --------------------           */
/*     Function name                   dacsf_init_impl                */
/*     Upper Case Alias                DACSF_INIT                     */
/*     Lower Case Alias                dacsf_init                     */
/*     Singe Underscore Alias          dacsf_init_                    */
/*     Double Underscore Alias         dacsf_init__                   */
/*                                                                    */
/*  The macros FORTRAN_SUBR and FORTRAN_FUNC are used to generate     */
/*  the C function names and aliases for the Fortran bindings.        */
/*                                                                    */
/*  The Fortran compilers provide options to control the symbol name  */
/*  decoration:                                                       */
/*     Compiler  Options                                              */
/*     --------  -----------------------------------                  */
/*     gfortran   -fno-underscoring -fsecond-underscore               */
/*     xLF        -qextname -qnoextname -qmixed                       */
/*     PathScale  -fno-underscoring -fsecond-underscore               */
/*--------------------------------------------------------------------*/

/*--------------------------------------------------------------------*/
/* dacsf_proc_sync.c                                                  */
/*--------------------------------------------------------------------*/
#ifndef DACS_SPU
FORTRAN_SUBR(DACSF_MUTEX_INIT,
             dacsf_mutex_init,(int64_t    *mutex,
                               DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_mutex_init((dacs_mutex_t*)mutex);
}

FORTRAN_SUBR(DACSF_MUTEX_SHARE,
             dacsf_mutex_share,(int32_t    *dst_de_ptr,
                                int64_t    *dst_pid_ptr,
                                int64_t    *mutex_ptr,
                                DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_mutex_share((de_id_t)*dst_de_ptr,(dacs_process_id_t)*dst_pid_ptr,(dacs_mutex_t)*mutex_ptr);
}
#endif

FORTRAN_SUBR(DACSF_MUTEX_ACCEPT,
             dacsf_mutex_accept,(int32_t    *remote_de_ptr,
                                 int64_t    *remote_pid_ptr,
                                 int64_t    *received_mutex,
                                 DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_mutex_accept((de_id_t)*remote_de_ptr,(dacs_process_id_t)*remote_pid_ptr,(dacs_mutex_t*)received_mutex);
}

FORTRAN_SUBR(DACSF_MUTEX_LOCK,
             dacsf_mutex_lock,(int64_t    *mutex_ptr,
                               DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_mutex_lock((dacs_mutex_t)*mutex_ptr);
}

FORTRAN_SUBR(DACSF_MUTEX_TRY_LOCK,
             dacsf_mutex_try_lock,(int64_t    *mutex_ptr,
                                   DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_mutex_try_lock((dacs_mutex_t)*mutex_ptr);
}

FORTRAN_SUBR(DACSF_MUTEX_UNLOCK,
             dacsf_mutex_unlock,(int64_t    *mutex_ptr,
                                 DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_mutex_unlock((dacs_mutex_t)*mutex_ptr);
}

FORTRAN_SUBR(DACSF_MUTEX_RELEASE,
             dacsf_mutex_release,(int64_t    *mutex,
                                  DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_mutex_release((dacs_mutex_t*)mutex);
}

#ifndef DACS_SPU
FORTRAN_SUBR(DACSF_MUTEX_DESTROY,
             dacsf_mutex_destroy,(int64_t    *mutex,
                                  DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_mutex_destroy((dacs_mutex_t*)mutex);
}
#endif

FORTRAN_SUBR(DACSF_BARRIER_WAIT,
             dacsf_barrier_wait,(int64_t    *group_ptr,
                                 DACS_ERR_T *rc_ptr))
{
  *rc_ptr = dacs_barrier_wait((dacs_group_t)*group_ptr);
}

