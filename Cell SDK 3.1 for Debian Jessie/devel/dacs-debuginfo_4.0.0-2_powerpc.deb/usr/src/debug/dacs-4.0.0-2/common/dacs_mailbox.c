/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

// @(#) /family/qdc/vc/0/1/9/7/s.96 v1.10 - 6/25/07 13:52:04

/*
 * dacs_mailbox.c - defines functions for using DaCS mailboxes
 */

/*--------------------------------------------------------------------*/
/*  Includes                                                          */
/*--------------------------------------------------------------------*/

#include <dacs_common.h>

#include <dacs.h>

#if defined(DACS_HYBRID)
#include <dacs_hybrid_mailbox.h>
#endif

#ifdef DACS_PPU
#include <dacs_ppu_mailbox.h>
#endif

/*--------------------------------------------------------------------*/
/*  Function Definitions                                              */
/*--------------------------------------------------------------------*/

DACS_ERR_T dacs_mailbox_read (  uint32_t            *msg,
                                de_id_t              src_de,
                                dacs_process_id_t    src_pid
                                 )
{

#ifdef DACS_ERROR_CHECKING
    if(!dacsi_is_init())        return DACS_ERR_NOT_INITIALIZED;
    if(msg == NULL)             return DACS_ERR_INVALID_ADDR;
    if(src_de == DACS_DE_SELF)  return DACS_ERR_INVALID_TARGET;
#endif

    DACS_ERR_T rc = DACS_SUCCESS;

    TRACE_TIMER_TOKEN(timer_token);
    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MBOX_READ,token,1,(uintptr_t)msg,src_de,src_pid);
    TRACE_TIMER_START(timer_token);

#if    defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_mailbox_read(msg,src_de,src_pid );
#elif  defined(DACS_HYBRID) &&  defined(DACS_PPU)
    if(src_de == DACS_DE_PARENT) {
        rc = dacs_hybrid_mailbox_read(msg,src_de,src_pid );
    }
    else {
        rc = dacs_ppu_mailbox_read(msg,src_de,src_pid );
    }
#elif  !defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_ppu_mailbox_read(msg,src_de,src_pid );
#else
#error "Invalid platform or no platform specified"
#endif

#ifdef DACS_HYBRID
    // Ensure all memory is synchronized before continuing
    dacsi_memory_barrier();
#endif

    TRACE_TIMER_END(dacs_mbox_read,timer_token);
    TRACE_POINT_EXIT(_DACS_MBOX_READ,token,1,rc);

    return rc;
}


/*--------------------------------------------------------------------*/
DACS_ERR_T dacs_mailbox_write ( uint32_t           *msg ,
                                de_id_t             dst_de ,
                                dacs_process_id_t   dst_pid )
{
#ifdef DACS_ERROR_CHECKING
    if(!dacsi_is_init())                       return DACS_ERR_NOT_INITIALIZED;
    if(msg == NULL)                            return DACS_ERR_INVALID_ADDR;
    if(dst_de == DACS_DE_SELF)                            return DACS_ERR_INVALID_TARGET;
#endif

    TRACE_TIMER_TOKEN(timer_token);
    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MBOX_WRITE,token,1,(uintptr_t)msg,dst_de,dst_pid);
    TRACE_TIMER_START(timer_token);

#ifdef DACS_HYBRID
    // Ensure all memory is synchronized before continuing
    dacsi_memory_barrier();
#endif

    DACS_ERR_T rc = DACS_SUCCESS;
#if    defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_mailbox_write(msg,dst_de,dst_pid);
#elif  defined(DACS_HYBRID) && defined(DACS_PPU)
    if(dst_de == DACS_DE_PARENT) {
        rc = dacs_hybrid_mailbox_write(msg,dst_de,dst_pid);
    }
    else {
        rc = dacs_ppu_mailbox_write(msg,dst_de,dst_pid);
    }
#elif  !defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_ppu_mailbox_write(msg,dst_de,dst_pid);
#else
#error "Invalid platform or no platform specified"
#endif

    TRACE_TIMER_END(dacs_mbox_write,timer_token);
    TRACE_POINT_EXIT(_DACS_MBOX_WRITE,token,1,rc);

    return rc;
}

/*--------------------------------------------------------------------*/
DACS_ERR_T dacs_mailbox_test( DACS_TEST_MAILBOX_T  rw_flag,
                              de_id_t              de,
                              dacs_process_id_t    pid,
                              int32_t              *mbox_status)
{
#ifdef DACS_ERROR_CHECKING
    if(!dacsi_is_init())                       return DACS_ERR_NOT_INITIALIZED;
    if(mbox_status == NULL)                    return DACS_ERR_INVALID_ADDR;
    if(de == DACS_DE_SELF)                     return DACS_ERR_INVALID_TARGET;
    if((rw_flag != DACS_TEST_MAILBOX_READ) && 
       (rw_flag != DACS_TEST_MAILBOX_WRITE) )  return DACS_ERR_INVALID_ATTR;

#endif

    DACS_ERR_T rc = DACS_SUCCESS;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MBOX_TEST,token,1,rw_flag,de,pid,(uintptr_t)mbox_status);

#if    defined(DACS_HYBRID) && !defined(DACS_PPU)
    rc = dacs_hybrid_mailbox_test(rw_flag,de,pid,mbox_status);
#elif  defined(DACS_HYBRID) && defined(DACS_PPU)
    if(de == DACS_DE_PARENT) {
        rc = dacs_hybrid_mailbox_test(rw_flag,de,pid,mbox_status);
    }
    else {
        rc = dacs_ppu_mailbox_test(rw_flag,de,pid,mbox_status);
    }
#elif  !defined(DACS_HYBRID) && defined(DACS_PPU)
    rc = dacs_ppu_mailbox_test(rw_flag,de,pid,mbox_status);
#else
#error "Invalid platform or no platform specified"
#endif

    TRACE_POINT_EXIT(_DACS_MBOX_TEST,token,1,rc,*mbox_status);

    return rc;

}

