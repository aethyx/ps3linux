/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */


/*
 * dacs_ppu_mem.c - defines functions for local memory operations on the PPU
 */

#include <stdlib.h>
#include <errno.h>

#include <dacs_ppe_internal.h>
#include <dacs_ppu_shared_obj.h>
#include <dacs_ppu_mem.h>
#include <dacs_ppu_data_sync.h>
#include <dacsi_q.h>
#include <dacs_debug.h>

/* ------------------------------------------------------------------ */

DACS_ERR_T dacs_ppu_mem_destroy( dacs_mem_t *mem )
{
    dacsi_shared_obj_t *obj;

#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_initialized())    return DACS_ERR_NOT_INITIALIZED;
    if (!mem)                       return DACS_ERR_INVALID_ADDR;
#endif

    obj = (dacsi_shared_obj_t *)(uintptr_t) *mem;

#ifdef DACS_ERROR_CHECKING
    if (!obj || obj->name != DACSI_REMOTE_MEM_NAME) 
        return DACS_ERR_INVALID_HANDLE;
#endif

    return DACS_SUCCESS;
}

DACS_ERR_T dacs_ppu_mem_share(   de_id_t            dst_de,
                                 dacs_process_id_t  dst_pid,
                                 dacs_mem_t         mem)
{
    DACS_ERR_T err;
    dacsi_shared_obj_t * obj = (dacsi_shared_obj_t *)(uintptr_t) mem;

#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_initialized())  
        return DACS_ERR_NOT_INITIALIZED;

    // can't share memory with yourself
    if (dst_de == dacspi_local_de_id)  
        return  DACS_ERR_INVALID_TARGET;

    // can't share memory that you don't own - resharing not yet allowed
    if (obj->owner_de != dacspi_local_de_id) 
        return DACS_ERR_NOT_OWNER;
#endif

    err = dacspi_ppu_share_obj(dst_de, dst_pid, obj);
 
    return err;
}

DACS_ERR_T dacs_ppu_mem_accept( de_id_t src_de,
                                dacs_process_id_t src_pid,
                                dacs_mem_t *mem )
{
    return DACS_ERR_NOT_SUPPORTED_YET;
}

DACS_ERR_T dacs_ppu_mem_release( dacs_mem_t *mem )
{
    return DACS_ERR_NOT_SUPPORTED_YET;
}

DACS_ERR_T dacs_ppu_mem_register(de_id_t dst_de,
                                 dacs_process_id_t dst_pid,
                                 dacs_mem_t mem)
{
    return DACS_ERR_NOT_SUPPORTED_YET;
}

DACS_ERR_T dacs_ppu_mem_deregister(de_id_t dst_de,
                                   dacs_process_id_t dst_pid,
                                   dacs_mem_t mem)
{
    return DACS_ERR_NOT_SUPPORTED_YET;
}

DACS_ERR_T dacs_ppu_mem_limits_query(DACS_MEM_LIMITS_T attr,
                                     de_id_t dst_de,
                                     dacs_process_id_t dst_pid,
                                     uint64_t *value)
{
    DACS_ERR_T dacs_rc = DACS_SUCCESS;

#ifdef DACS_ERROR_CHECKING
    DACSPI_TOPO_LOCK();
    dacs_topology_t *topo = dacsi_get_topo(dst_de, &dacs_rc);
    if (!topo) 
        dacs_rc = DACS_ERR_INVALID_DE;
    else {
        if (dst_pid != TOPO_PID_TO_PROCESS_ID(topo,ONLYPID))
            dacs_rc = DACS_ERR_INVALID_PID;
        if (topo->pids[ONLYPID].status == DACSI_PID_INVALID)
            dacs_rc = DACS_ERR_INVALID_PID;
    }
    DACSPI_TOPO_UNLOCK();
    if (dacs_rc != DACS_SUCCESS)
        return dacs_rc;
#endif

    switch (attr) {
        case DACS_MEM_REGION_MAX_NUM:
        case DACS_MEM_REGION_MAX_SIZE:
        case DACS_MEM_REGION_AVAIL:
            *value = UINT64_MAX;
            break;
        default:
            dacs_rc = DACS_ERR_INVALID_ATTR;            
    }

    return dacs_rc;
}

