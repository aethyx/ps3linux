/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
static char *ident = "@(#) internal-src/lib/dacs/cell/ppu/dacs_ppu_tags.c v1.23 - %H % 09:55:50 @(#)";

#include <pthread.h>

#include <dacs_ppe_internal.h>
#include <dacs_ppu_tags.h>
#include    <dacs_debug.h>

unsigned int dacspi_hwtag_mask = 0;
pthread_mutex_t dacspi_hwtag_lock;

//SPUFS only supports 16 HW tags on the PPU, so limit things to that.
#define DACSPI_FALLBACK_TAG 15

//
//  C++ interface
//
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

//  --------------------------------------------------------------------
// Reserve a hardware tag on the PPU
// --------------------------------------------------------------------
dacs_tag_t
dacspi_tag_reserve()
{
    int i;
    unsigned mask = dacspi_hwtag_mask;

    // Initialize the return tag to be the unreservable fallback tag in case
    // we can't successfully allocate one.  This allows us to return a tag 
    // without error, but may cause us DMA backup on the fallback tag.
    dacs_tag_t tag = DACSPI_FALLBACK_TAG;

    if (dacsi_threaded) pthread_mutex_lock(&dacspi_hwtag_lock);

    for (i = 0, mask = dacspi_hwtag_mask; 
         i < DACSPI_FALLBACK_TAG; 
         i++, mask = mask >> 1) {
        if (!(mask & 1)) { 
            dacspi_hwtag_mask |= (1 << i);
            tag = i;
            break;
        }
    }

    if (dacsi_threaded) pthread_mutex_unlock(&dacspi_hwtag_lock);

    // Return the allocated tag
    return tag;
}


//  --------------------------------------------------------------------
//
// --------------------------------------------------------------------
void
dacspi_tag_release(dacs_tag_t tag)
{
    // If the caller is releasing the fallback tag, just return it was never
    // reserved.
    if (tag == DACSPI_FALLBACK_TAG)
        return;

    if (dacsi_threaded) pthread_mutex_lock(&dacspi_hwtag_lock);

    dacspi_hwtag_mask ^= (1 << tag);

    if (dacsi_threaded) pthread_mutex_unlock(&dacspi_hwtag_lock);
}

//  =====   CONSTRUCTOR and DESTRUCTOR

//  --------------------------------------------------------------------
//     tags constructor
// --------------------------------------------------------------------
DACS_ERR_T  dacspi_tags_init( void *argvp,    void *envp )
{
    pthread_mutex_init(&dacspi_hwtag_lock, NULL);

    return  DACS_SUCCESS;
}


//  --------------------------------------------------------------------
//     tags destructor
// --------------------------------------------------------------------
DACS_ERR_T  dacspi_tags_exit( void )
{
    pthread_mutex_destroy(&dacspi_hwtag_lock);

    return  DACS_SUCCESS;
}


//
//  C++ interface
//
#ifdef __cplusplus
}
#endif /* __cplusplus */
