/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

static char *ident = "@(#) internal-src/lib/dacs/cell/ppu/dacs_ppu_mailbox.c v1.19 - 9/16/08 09:55:50 @(#)";

#include <dacs_ppu_mailbox.h>
#include <dacs_ppe_internal.h>
#include <errno.h>
#include <dacs_debug.h>
#include <dacs_trace.h>

static DACS_ERR_T dacspi_mailbox_error_check(void *, de_id_t, 
                                             dacs_process_id_t, 
                                             dacs_topology_t *);

DACS_ERR_T dacs_ppu_mailbox_read(uint32_t *msg, de_id_t src_de,
                                 dacs_process_id_t src_pid )
{
    dacs_topology_t *src_topo;
    DACS_ERR_T err;

#ifdef DACS_ERROR_CHECKING
    if ( !dacsi_is_initialized() )
        return DACS_ERR_NOT_INITIALIZED;
#endif

    src_topo = dacsi_get_topo(src_de, &err);

#ifdef DACS_ERROR_CHECKING
    err = dacspi_mailbox_error_check(msg, src_de, src_pid, src_topo);
    if (err)
        return err;
#endif

    // $$FIXME - Add code to handle peers, the assumption is SPE comm. only

    while(dacspi_ppu_mbox_status(src_topo) == 0)
    {
        usleep(50);
    }

    dacspi_mbox_read(src_topo, msg, 1);

    return DACS_SUCCESS;
}

//  --------------------------------------------------------------------
///
///
/// --------------------------------------------------------------------
DACS_ERR_T dacs_ppu_mailbox_write(uint32_t *msg,
                                  de_id_t dst_de,
                                  dacs_process_id_t dst_pid )
{
    dacs_topology_t *dst_topo;
    DACS_ERR_T err;

#ifdef DACS_ERROR_CHECKING
    if ( !dacsi_is_initialized() )
        return DACS_ERR_NOT_INITIALIZED;
#endif

    dst_topo = dacsi_get_topo(dst_de, &err);

#ifdef DACS_ERROR_CHECKING
    err = dacspi_mailbox_error_check(msg, dst_de, dst_pid, dst_topo);
    if (err)
        return err;
    // We can block writes to completed DEs
    if (dst_topo->pids[ONLYPID].status == DACSI_PID_TERM)
        return DACS_ERR_INVALID_PID;
#endif

    dacspi_mbox_write(dst_topo, msg, 1, SPE_MBOX_ALL_BLOCKING);

    return DACS_SUCCESS;
}


//  --------------------------------------------------------------------
///
///
/// --------------------------------------------------------------------
DACS_ERR_T  dacs_ppu_mailbox_test ( DACS_TEST_MAILBOX_T rw_flag,
                                    de_id_t  de,
                                    dacs_process_id_t pid,
                                    int32_t *blockedflag)
{
    dacs_topology_t *topo;
    DACS_ERR_T err;

#ifdef DACS_ERROR_CHECKING
    if ( !dacsi_is_initialized() )
        return DACS_ERR_NOT_INITIALIZED;
#endif

    topo = dacsi_get_topo(de, &err);

#ifdef DACS_ERROR_CHECKING
    err = dacspi_mailbox_error_check(blockedflag, de, pid, topo);
    if (err)
        return err;
#endif

    // $$FIXME - Add code to handle peers, the assumption now is SPE communication only

    // Only RW flags of READ or WRITE are supported, otherwise it is a failure
    if (rw_flag != DACS_TEST_MAILBOX_READ &&
	rw_flag != DACS_TEST_MAILBOX_WRITE)
	    return DACS_ERR_INVALID_ATTR;

    // Check if the PPE's inbound mbox is empty, if so we'll have a status 
    // of 0, which means we would block if we tried to read it.
    if(rw_flag == DACS_TEST_MAILBOX_READ)
    {
	    // Returns the number of used mbox entries
        *blockedflag = dacspi_ppu_mbox_status(topo);
    }
    // Check if the PPE's outbound mbox is full, if so we'll have a status 
    // of 0, which means we would block if we tried to read it.
    else if(rw_flag == DACS_TEST_MAILBOX_WRITE)
    {
	    // Returns the number of available mbox entries
        *blockedflag = dacspi_spu_mbox_status(topo);
    }

    // One of the SPE calls failed, return failure status
    if (*(int32_t *)blockedflag == -1)
	    return DACS_ERR_SYSTEM;

    return DACS_SUCCESS;
}

static DACS_ERR_T
dacspi_mailbox_error_check(void *addr, de_id_t de, dacs_process_id_t pid,
                           dacs_topology_t *topo)
{
    if (addr == NULL) 
        return DACS_ERR_INVALID_ADDR;

    if (!topo ||
        topo->reservation != DACSI_TOPO_RESERVED)
        return DACS_ERR_INVALID_DE;

    if (de == dacspi_local_de_id || de == DACS_DE_SELF || pid == DACS_PID_SELF)
        return DACS_ERR_INVALID_TARGET;

    if ((pid != TOPO_PID_TO_PROCESS_ID(topo,ONLYPID)) ||
        (topo->pids[ONLYPID].status == DACSI_PID_INVALID))
        return DACS_ERR_INVALID_PID;

    return DACS_SUCCESS;
}

//  =====   CONSTRUCTOR and DESTRUCTOR

///
///
///
DACS_ERR_T  dacspi_mailbox_init( void *argvp,    void *envp )
{

    return  DACS_SUCCESS;
}


///
///
///
DACS_ERR_T  dacspi_mailbox_exit( void )
{

    return  DACS_SUCCESS;
}
