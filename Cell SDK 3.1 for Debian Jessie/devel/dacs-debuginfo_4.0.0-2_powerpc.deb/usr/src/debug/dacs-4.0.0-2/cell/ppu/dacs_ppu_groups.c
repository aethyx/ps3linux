/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

static char *ident = "@(#) internal-src/lib/dacs/cell/ppu/dacs_ppu_groups.c v1.2.1.18 - 9/16/08 09:55:34 @(#)";

#include <dacs_ppu_groups.h>
#include <dacs_ppe_internal.h>
#include <dacs_ppu_shared_obj.h>
#include <dacs_atomic.h>
#include <dacs_debug.h>

/*--------------------------------------------------------------------*/
/*  User Types                                                        */
/*--------------------------------------------------------------------*/

struct {
    dacsi_shared_obj_t *head;
    dacsi_shared_obj_t *tail;
} dacsi_group_list;

/*--------------------------------------------------------------------*/
/*  Macros                                                            */
/*--------------------------------------------------------------------*/

#ifndef DACS_ERROR_CHECKING
#define GROUP_TO_HANDLE(mem) ((dacsi_shared_obj_t*)(uintptr_t)(mem))
#else
#define GROUP_TO_HANDLE(mem) dacspi_find_group_by_local_id(mem)
#endif


#define DACSI_BARRIER_INIT              -1
#define DACSI_BARRIER_MAX_IDX           31
#define DACSI_BARRIER_MASK(idx)        (1 << (idx))

static dacsi_shared_obj_t *
dacspi_find_group_by_local_id(dacs_group_t);

/*
 * Group owner services
 */

DACS_ERR_T
dacs_ppu_group_init(dacs_group_t *group, uint32_t flags)
{
    DACS_ERR_T rc;
    dacsi_shared_obj_t *obj;

#ifdef DACS_ERROR_CHECKING
    if (group == NULL)
        return DACS_ERR_INVALID_ADDR;

    if (flags != 0)
        return DACS_ERR_INVALID_ATTR;
#endif

    rc = dacsi_shared_obj_create(&obj,
                &dacsi_group_list.head, &dacsi_group_list.tail);

    if (rc == DACS_SUCCESS) {
        obj->name = DACSI_GROUP_NAME;
        obj->group.dacsi_barrier = DACSI_BARRIER_INIT;
        obj->group.state = DACSI_GROUP_OPEN;
        obj->group.dacsi_members = 0;
        *group = (dacs_group_t)(uintptr_t)obj;
    }

    return  rc;
}

DACS_ERR_T
dacs_ppu_group_add_member(de_id_t de, dacs_process_id_t pid,
                            dacs_group_t group)
{
    DACS_ERR_T rc = DACS_SUCCESS;
    dacsi_shared_obj_t *obj = GROUP_TO_HANDLE(group);
    dacs_topology_t *topo = NULL;

#ifdef DACS_ERROR_CHECKING
    if (obj == NULL || obj->name != DACSI_GROUP_NAME)
        return DACS_ERR_INVALID_HANDLE;

    if (obj->owner_de != dacspi_local_de_id)
        return DACS_ERR_NOT_OWNER;

    if (obj->group.state != DACSI_GROUP_OPEN)
        return DACS_ERR_GROUP_CLOSED;
#endif
    if (de == (de_id_t)DACS_DE_SELF)
        de = dacsi_local_de_id;
    else {
#ifdef DACS_ERROR_CHECKING
        if (pid == (dacs_process_id_t)DACS_PID_SELF)
            return DACS_ERR_INVALID_TARGET;
#endif
    }
    topo = dacsi_get_topo(de, &rc);
    if (!topo)
        return DACS_ERR_INVALID_DE;

    if (pid == (dacs_process_id_t)DACS_PID_SELF)
        pid = dacsi_local_pid;

#ifdef DACS_ERROR_CHECKING
    if (pid != TOPO_PID_TO_PROCESS_ID(topo,ONLYPID))                                         
        return DACS_ERR_INVALID_PID;                                                         
    
    if (obj->group.dacsi_members & DACSI_BARRIER_MASK(topo->my_index))
        return DACS_ERR_GROUP_DUPLICATE;
#endif

    ASSERT(topo->my_index <= DACSI_BARRIER_MAX_IDX);

    /* anticipate success */
    dacspi_atomic_or((atomic_ea_t)(uintptr_t)&obj->group.dacsi_members,
                    DACSI_BARRIER_MASK(topo->my_index));

    /* share if new member is not ourself */
    if (de != dacsi_local_de_id) {

        rc = dacspi_ppu_share_obj(de, pid, obj);

        /* clear bit if we failed */
        if (rc != DACS_SUCCESS)
            dacspi_atomic_and((atomic_ea_t)(uintptr_t)&obj->group.dacsi_members,
                            ~DACSI_BARRIER_MASK(topo->my_index));
    }

    return  rc;
}

DACS_ERR_T
dacs_ppu_group_close(dacs_group_t group)
{
    DACS_ERR_T rc;
    dacsi_shared_obj_t *obj = GROUP_TO_HANDLE(group);

#ifdef DACS_ERROR_CHECKING
    if (obj == NULL || obj->name != DACSI_GROUP_NAME)
        return DACS_ERR_INVALID_HANDLE;

    if (obj->owner_de != dacsi_local_de_id ||
        obj->owner_pid != dacsi_local_pid)
        return DACS_ERR_NOT_OWNER;

    if (obj->group.state == DACSI_GROUP_CLOSED)
        return DACS_ERR_GROUP_CLOSED;
#endif

    /* initialize barrier and change group state */
    dacspi_atomic_set32((atomic_ea_t)(uintptr_t)&obj->group.dacsi_barrier, obj->group.dacsi_members);
    dacspi_atomic_set32((atomic_ea_t)(uintptr_t)&obj->group.state, DACSI_GROUP_CLOSED);

    return DACS_SUCCESS;
}

DACS_ERR_T
dacs_ppu_group_destroy(dacs_group_t *group)
{
    DACS_ERR_T rc;
    dacsi_shared_obj_t *obj;

#ifdef DACS_ERROR_CHECKING
    if (group == NULL)
        return DACS_ERR_INVALID_ADDR;
#endif

    obj = GROUP_TO_HANDLE(*group);

#ifdef DACS_ERROR_CHECKING
    if (obj == NULL || obj->name != DACSI_GROUP_NAME)
        return DACS_ERR_INVALID_HANDLE;

    if (obj->owner_de != dacspi_local_de_id)
        return DACS_ERR_NOT_OWNER;

    if (obj->group.state != DACSI_GROUP_CLOSED)
        return DACS_ERR_GROUP_OPEN;
#endif

    rc = dacsi_shared_obj_destroy(obj, 
                &dacsi_group_list.head, &dacsi_group_list.tail);
    *group = 0;    

    return rc;
}

/*
 * Group member services - not yet supported on PPU for DaCS on Cell
 */

DACS_ERR_T
dacs_ppu_group_accept(de_id_t de, dacs_process_id_t pid, dacs_group_t *group)
{
    return  DACS_ERR_NOT_SUPPORTED_YET;
}

DACS_ERR_T
dacs_ppu_group_leave(dacs_group_t *group)
{
    dacsi_shared_obj_t *obj;

#ifdef DACS_ERROR_CHECKING
    if (group == NULL)
        return DACS_ERR_INVALID_ADDR;
#endif

    obj = GROUP_TO_HANDLE(*group);

#ifdef DACS_ERROR_CHECKING
    if (obj == NULL || obj->name != DACSI_GROUP_NAME)
        return DACS_ERR_INVALID_HANDLE;

    if (obj->owner_de == dacsi_local_de_id &&
        obj->owner_pid == dacsi_local_pid)
        return DACS_ERR_OWNER;
#endif

    // shouldn't get here but we need
    // to return a failure even in the
    // absence of error checking. since
    // group_accept() is not supported,
    // it's safe to say the handle is
    // not valid
    //
    return DACS_ERR_INVALID_HANDLE;
}


/*
 * Barrier wait service
 */

static inline void
_ppu_barrier(dacsi_group_t *group)
{
    dacsi_barrier_t mask = DACSI_BARRIER_MASK(dacs_tcb.my_index);
    dacsi_barrier_t barrier;
    dacsi_barrier_t members = group->dacsi_members;
    dacsi_barrier_t result;

    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_CLEAR_TOKEN(token); 
    TRACE_INIT_LOOP_COUNTER();
    do {
        if(TRACE_LOOP_COUNTER_EQUALS_ONE()  ){
            TRACE_INTERVAL_BEGIN (_DACS_INTERNAL_PPE_BARRIER_WAIT,token,0);
        }
		
        barrier = __lwarx((volatile int *)&group->dacsi_barrier);

        /* my bit better be on */
        ASSERT(barrier & mask);

        /* if my bit is the only one set,
         * I'm last so post the barrier by
         * turning on everyone's bit
         */
        if (barrier == mask)
            barrier = members;
        else
            barrier &= ~mask;

        result = __stwcx((volatile int *)&group->dacsi_barrier, barrier);
        TRACE_UPDATE_LOOP_COUNTER();
    } while (!result);

    /* if i didn't post the barrier,
     * wait here until someone does
     */
    if (barrier != members)
    {
        if (TRACE_IS_TOKEN_CLEAR(token)) {
            TRACE_INTERVAL_BEGIN (_DACS_INTERNAL_PPE_BARRIER_WAIT,token,0);
        }
        while (!(((volatile dacsi_group_t *)group)->dacsi_barrier & mask));
    }

    if (!TRACE_IS_TOKEN_CLEAR(token)) {
        TRACE_INTERVAL_END (_DACS_INTERNAL_PPE_BARRIER_WAIT,token,0, (long)group->dacsi_barrier);
    }
}

DACS_ERR_T
dacs_ppu_barrier_wait(dacs_group_t group)
{
    dacsi_shared_obj_t *obj = GROUP_TO_HANDLE(group);

#ifdef DACS_ERROR_CHECKING
    if (group == 0)
        return DACS_ERR_INVALID_HANDLE;
    if (obj == NULL || obj->name != DACSI_GROUP_NAME)
        return DACS_ERR_INVALID_HANDLE;
#endif

    dacsi_group_t *grp = &(obj->group);

#ifdef DACS_ERROR_CHECKING
    if (!(grp->dacsi_members & DACSI_BARRIER_MASK(dacs_tcb.my_index)))
        return DACS_ERR_INVALID_HANDLE;
#endif
    _ppu_barrier(grp);

    return DACS_SUCCESS;
}


dacsi_shared_obj_t * 
dacspi_find_group_by_local_id(dacs_group_t group)
{
    dacsi_shared_obj_t * handle = NULL;
    dacsi_shared_obj_t * curr;

    for (curr = dacsi_group_list.head; curr; curr = (dacsi_shared_obj_t*)(uintptr_t)curr->next)
    {
        if ((uintptr_t)curr == group) {
            handle = curr;
            break;
        }
    }

    return handle;
}


/* 
 * Groups init/fini services
 */

DACS_ERR_T
dacspi_groups_init(void *argvp, void *envp )
{
    return  DACS_SUCCESS;
}


DACS_ERR_T
dacspi_groups_exit(void)
{
    return  DACS_SUCCESS;
}


