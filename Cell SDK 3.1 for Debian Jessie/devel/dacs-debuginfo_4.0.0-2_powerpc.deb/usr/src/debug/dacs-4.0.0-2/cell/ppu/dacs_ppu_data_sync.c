/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
static char *ident = "@(#) internal-src/lib/dacs/cell/ppu/dacs_ppu_data_sync.c v1.39 - 9/16/08 09:55:49 @(#)";

// Support for data synchronization on PPE

#include <dacs_ppe_internal.h>
#include <dacsi_q.h>
#include <dacsi_wids.h>
#include <dacs_debug.h>
#include <dacs.h>
#include <stdlib.h>
#include <dacs_trace.h>

//  -----   local prototypes    -----

//  -----   Globals -----
dacsi_wait_queue_t dacsi_waitq[DACSPI_MAX_WIDS] __attribute__((aligned(128)));
dacsi_wid_elem_t *dacspi_we_array;

// Each mask element describes 32 WEs, so size the array by MAX_WES divided by 
// 32 (or shift by 5).
unsigned int dacspi_we_mask[DACSPI_MAX_WES>>5];

DACS_ERR_T
dacspi_wait_test (dacsi_wait_queue_t *widp, dacs_wid_t wid, int waitok)
{
    dacs_topology_t *topo = NULL;
    DACS_ERR_T err = DACS_SUCCESS;
    dacsi_wid_elem_t *wep = widp->head, *next;
    uint32_t pass = 1;

    TRACE_DEBUG(1,MESSAGE,TRACE_DEBUG_PPU_DATA_SYNC_1, we);

#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_initialized()) { 
        return DACS_ERR_NOT_INITIALIZED; 
    }
#endif

    while (wep && !err) {
        // Fetch the topology struct for the source de
        if ((topo = dacsi_get_topo(wep->de, &err)) == NULL) {
            return  DACS_ERR_INVALID_DE;
        }

        if (waitok) {
            err = dacspi_dma_wait(topo, DACSPI_HWTAG(wid));
        }
        else {
            err = dacspi_dma_test(topo, DACSPI_HWTAG(wid));
            if (err == DACS_WID_BUSY)
                return err;
        }

        while (wep->status == DACS_ERR_WID_ACTIVE) {
            if (!waitok)
                return DACS_WID_BUSY;
        }

        err = wep->status;

        // In the name of performance, we don't clear all the fields.  This
        // means we have to make sure to init everything on alloc.
        next = wep->next;
        dacspi_we_free(wep);
        widp->head = wep = next;
    }

    TRACE_DEBUG(1,MESSAGE,TRACE_DEBUG_PPU_DATA_SYNC_11, err);

    return err;
}

//  =====   CONSTRUCTOR and DESTRUCTOR

//
//
//
DACS_ERR_T  dacspi_data_sync_init( void *argvp, void *envp )
{
    unsigned int i;

    dacsi_wids_init();

    if (posix_memalign((void *)&dacspi_we_array, 128, 
                       DACSPI_MAX_WES * sizeof(dacsi_wid_elem_t))) {
        return DACS_ERR_NO_RESOURCE;
    }

    // Each mask element describes 32 WEs, so we need to iterate the mask
    // MAX_WES divided by 32 (or shift by 5).
    for (i = 0; i < (DACSPI_MAX_WES >> 5); i++)
        dacspi_we_mask[i] = -1U;

    return  DACS_SUCCESS;
}


//
//
//
DACS_ERR_T  dacspi_data_sync_exit( void )
{
    dacsi_wait_queue_t *q;
    dacsi_wid_elem_t *elem, *next;
    dacs_addr_64_t *req;
    dacs_addr_64_t req64ptr;
    int wid;

    // Walk through all of our wids and free any waitQe and wid_elem
    // that have been left behind.
    // We have the means for freeing the jobQ stuff here too, but since it is
    // static storage that gets cleared on init, it is not necessary.
    for (wid = 0; wid < DACSI_WID_MAX; wid++) {
        DACSI_LOCK_WID_QUEUE(wid);
        q = &dacsi_waitq[wid];
        elem = q->head;

        while (elem) {
            next = elem->next;
            dacspi_we_free(elem);
            elem = next;
        }
        DACSI_UNLOCK_WID_QUEUE(wid);
    }
    dacsi_wids_destroy();
    return  DACS_SUCCESS;
}
