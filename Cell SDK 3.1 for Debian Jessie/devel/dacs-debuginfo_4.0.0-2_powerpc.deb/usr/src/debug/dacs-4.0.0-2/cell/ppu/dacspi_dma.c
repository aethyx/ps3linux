/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

// ident = @(#) internal-src/lib/dacs/cell/spu/dacs_spe_internal.h v1.1 - 9/16/08 09:59:30 @(#)
static char *ident = "@(#) internal-src/lib/dacs/cell/ppu/dacspi_dma.c v1.1 - 9/16/08 09:59:30 @(#)";

#include <dacs.h>
#include <dacs_ppe_internal.h>
#include <stdlib.h>
#include <string.h>

unsigned int dacspi_unaligned_cnt = 0;

DACS_ERR_T
dacspi_unaligned_dma(uint32_t op, dacs_topology_t *topo, uint32_t ls, 
                     uint64_t ea, uint32_t totlen, uint32_t tag)
{
    DACS_ERR_T err;
    unsigned int Ar, Al; 
    char *_new_ea;
    uintptr_t new_ea = ea;

    Al = (uintptr_t)ea & 0xF;
    Ar = ls & 0xF;

    //
    // If this is an outgoing buffer, we need to shift the data into place
    // prior to sending it out.  This is a shift right, which is represented
    // as a negative shift.
    //
    if (Al != Ar) {
        posix_memalign((void *)&_new_ea, 4096, totlen+16);
        if (!_new_ea)
            return DACS_ERR_NO_RESOURCE;
        new_ea = (uintptr_t)&_new_ea[Ar];
        if (op & MFC_GET_CMD)
            memcpy((char *)new_ea, (char *)(uintptr_t)ea, totlen);
    }

    // Initiate the main buffer DMA.
    // In the case of a PUT, we are sending a buffer with data shifted to
    // match the remote side buffer.
    // In the case of a GET, we are receiving into a location that matches the
    // remote side alignment.
    // In both cases, we are only DMAing the precalculated amount, which could
    // be zero if the alignment and size don't work.
    //
    err = dacspi_dma(op, topo, ls, new_ea, totlen, tag);

    // Ok, if we had to shift things then we have a remainder, so DMA the
    // remainder.
    // If we had to shift, then the users data is in a messed up state, so we
    // can't return until we fix their data up.  This means we have to wait
    // inline for the DMA to finish, then shift the data back into the
    // expected place before returning.  Do that now.
    //
    if (Al != Ar) {
        err = dacspi_dma_wait(topo, tag);

        if (op & MFC_PUT_CMD)
            memcpy((char *)(uintptr_t)ea, (char *)new_ea, totlen);

        free(_new_ea);

        TRACE_PERF(_DACS_PPE_UNALIGNED_DMA, 0, op, ls, ea, totlen);
        dacspi_unaligned_cnt++;
    }

    return err;
}

