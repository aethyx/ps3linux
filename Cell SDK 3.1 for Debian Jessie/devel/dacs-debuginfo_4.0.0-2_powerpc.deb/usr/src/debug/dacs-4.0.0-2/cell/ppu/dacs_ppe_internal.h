/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

// ident = "@(#) internal-src/lib/dacs/cell/ppu/dacs_ppe_internal.h v1.46 - 9/16/08 09:55:49 @(#)"

//
// PPE-specific internal definitions
//

#ifndef _DACS_PPE_INTERNAL_H_
#define _DACS_PPE_INTERNAL_H_

#include <libspe2.h>
#include <dacs_dps.h>

#include <dacs.h>
#include <dacs_atomic.h>
#include <dacsi_wids.h>
#include <dacs_internal.h>       // base definitions
#include <dacs_ppu_tags.h>

typedef dacs_addr_64_t dacs_context_t;

//  ----    send/recv   ------------------------------------------------
extern uint32_t dacspi_jobid;
extern uint32_t dacspi_remote_msgQ[NUM_SPES_PER_BLADE+1][DACSI_NUM_MSG_TYPE];

// Today we only support the use of the first PIDS slot in the topology
// structure.  This define is used for this single index, but it also provides
// an easy way to locate all the code that would need to be adjusted if
// multiple pids/tids were supported.
#define ONLYPID 0

#define DACSPI_MAX_HWTAGS 16
#define DACSPI_MAX_WES 128
#define DACS_MAX_PPE_WIDS 256
#define DACSPI_HWTAG(__wid)     ((__wid) & (DACSPI_MAX_HWTAGS - 1))

// This is the tag to be used internally within DaCS.  The tag ID has been
// chosen to avoid conflict as much as possible.  Typically, WIDs and thus
// tags, are doled out in assending order starting at 0, so we'll start at the
// end.
#define DACSPI_INTERNAL_TAG (DACSPI_MAX_HWTAGS-1)

enum dacspi_internal_wids {
    DACSPI_SHARED_OBJ_WID = DACS_MAX_PPE_WIDS,
    DACSPI_MAX_WIDS
};

extern dacsi_cb_t    dacs_rcb[NUM_SPES_PER_BLADE+1];

//  -----   topology  --------------------------------------------------

//  internal globals
extern dacs_topology_t dacs_tcb;
extern uint32_t dacs_topo_lock;

#define DACSPI_TOPO_LOCK()   do { if (dacsi_threaded) { dacspi_mutex_lock((mutex_ea_t)(uintptr_t)&dacs_topo_lock); } } while(0)
#define DACSPI_TOPO_UNLOCK() do { if (dacsi_threaded) { dacspi_mutex_unlock((mutex_ea_t)(uintptr_t)&dacs_topo_lock); } } while(0)

#define DACSPI_TOPO_CHILD(i) (&dacs_tcb.children[(i)])

extern  DACSI_TOPO_STS_T dacspi_check_reservation(  de_id_t de );
extern  int dacspi_check_children_reservations( dacs_topology_t *de_topo,
                                                DACSI_TOPO_STS_T checkval );
extern  int dacspi_set_children_reservations(    dacs_topology_t *de_topo,
                                                DACSI_TOPO_STS_T setval );

//  -----   test/wait   ------------------------------------------------
extern DACS_ERR_T dacspi_wait_test(dacsi_wait_queue_t *, dacs_wid_t, int);
extern dacsi_wid_elem_t *dacspi_we_array;
extern unsigned int dacspi_we_mask[DACSPI_MAX_WES>>5];

static inline dacsi_wid_elem_t *
dacspi_we_alloc()
{
    unsigned int i = 0;
    while (!dacspi_we_mask[i]) i++;
    unsigned int idx = __cntlzw(dacspi_we_mask[i]);
    unsigned int IDX = (i << 5) + idx;

    dacspi_we_mask[i] &= ~(0x80000000U>>idx);

    dacspi_we_array[IDX].next = 0;

    return &dacspi_we_array[IDX];
}

static inline void
dacspi_we_free(dacsi_wid_elem_t *we_p)
{
    uint64_t idx = 
        ((uintptr_t)we_p - (uintptr_t)dacspi_we_array)/sizeof(dacsi_wid_elem_t);
    unsigned int i = idx >> 5;

    dacspi_we_mask[i] |= (0x80000000U >> (idx & (32-1)));
}

//  =====   PPU "CONSTRUCTOR" CALLS

extern  DACS_ERR_T dacspi_topology_init(    void *argvp, void *envp );
extern  DACS_ERR_T dacspi_process_init(     void *argvp, void *envp );
extern  DACS_ERR_T dacspi_groups_init(      void *argvp, void *envp );
extern  DACS_ERR_T dacspi_tags_init(        void *argvp, void *envp );
extern  DACS_ERR_T dacspi_wids_init(        void *argvp, void *envp );
extern  DACS_ERR_T dacspi_mailbox_init(     void *argvp, void *envp );
extern  DACS_ERR_T dacspi_send_recv_init(   void *argvp, void *envp );
extern  DACS_ERR_T dacspi_data_sync_init(   void *argvp, void *envp );
extern  DACS_ERR_T dacspi_proc_sync_init(   void *argvp, void *envp );
extern  DACS_ERR_T dacspi_dma_init(         void *argvp, void *envp );
extern  DACS_ERR_T dacspi_shared_obj_init(  void *argvp, void *envp );

//  =====   PPU "DESTRUCTOR" CALLS

extern  DACS_ERR_T dacspi_topology_exit(    void );
extern  DACS_ERR_T dacspi_process_exit(     void );
extern  DACS_ERR_T dacspi_groups_exit(      void );
extern  DACS_ERR_T dacspi_tags_exit(        void );
extern  DACS_ERR_T dacspi_wids_exit(        void );
extern  DACS_ERR_T dacspi_mailbox_exit(     void );
extern  DACS_ERR_T dacspi_send_recv_exit(   void );
extern  DACS_ERR_T dacspi_data_sync_exit(   void );
extern  DACS_ERR_T dacspi_proc_sync_exit(   void );
extern  DACS_ERR_T dacspi_dma_exit(         void );
extern  DACS_ERR_T dacspi_shared_obj_exit(  void );

extern DACS_ERR_T dacspi_unaligned_dma(uint32_t, dacs_topology_t *topo, 
                                       uint32_t, uint64_t, uint32_t, uint32_t);

#if defined(DACS_DMA_NO_BREAKUP)
#define DACSPI_DMA(_op, _topo, _ls, _ea, _len, _tag)                        \
            dacspi_aligned_dma(_op, _topo, _ls, _ea, _len, _tag);
#elif defined(DACS_DMA_NO_UNALIGN)
#define DACSPI_DMA(_op, _topo, _ls, _ea, _len, _tag)                        \
            dacspi_dma(_op, _topo, _ls, _ea, _len, _tag)
#else
#define DACSPI_DMA(_op, _topo, _ls, _ea, _len, _tag)                        \
            dacspi_unaligned_dma(_op, _topo, _ls, _ea, _len, _tag)
#endif

// 2 versions of the dma functions - one is the raw functionality; the other
// has the necessary locks. allows for other functions to call the raw and do
// the locking on it's own terms. the _spe_mfc_dma call MUST be protected by a
// mutex_lock so that other commands on the system don't send commands in the
// middle.
static inline DACS_ERR_T
dacspi_aligned_dma_raw(uint32_t op, dacs_topology_t *topo, uint32_t ls,
                       uint64_t ea, uint32_t len, dacs_tag_t tag)
{
    // We must guarantee that all prior writes have completed before we do the
    // proxy DMA otherwise we could send stale data.
    __sync();
    if (_spe_mfc_dma((void *)(uintptr_t)(topo)->mfc_area, ls, ea, len, tag, op))
        return DACS_ERR_SYSTEM;

    return DACS_SUCCESS;
}

static inline DACS_ERR_T
dacspi_aligned_dma(uint32_t op, dacs_topology_t *topo, uint32_t ls,
                   uint64_t ea, uint32_t len, dacs_tag_t tag)
{

    if (dacsi_threaded) {
        DACS_ERR_T ret;

        dacspi_mutex_lock((mutex_ea_t)(uintptr_t)(&(topo)->dma_lock));
        ret = dacspi_aligned_dma_raw(op, topo, ls, ea, len, tag);
        dacspi_mutex_unlock((mutex_ea_t)(uintptr_t)(&(topo)->dma_lock));

        return ret;
    } else {
        return dacspi_aligned_dma_raw(op, topo, ls, ea, len, tag);
    }
}

static inline DACS_ERR_T
dacspi_dma(uint32_t op, dacs_topology_t *topo, uint32_t ls, uint64_t ea,
           uint32_t len, dacs_tag_t tag)
{
    DACS_ERR_T err = DACS_SUCCESS;
    unsigned int mask[] = {1, 2 ,4 ,8, ~0xF, ~0x7, ~0x3, ~0x1, -1};
    register unsigned int sz;
    unsigned int i;

    if (dacsi_threaded)
         dacspi_mutex_lock((mutex_ea_t)(uintptr_t)(&(topo)->dma_lock));

    for (i = 0; i < 4; i++) {
        sz = (uint32_t)ls & mask[i];
        if (sz && sz <= len) {
            err = dacspi_aligned_dma_raw(op, topo, ls, ea, sz, tag);
            ea += sz;
            ls += sz;
            len -= sz;
        }
    }

    while (len > 0) {
        sz = ((len & mask[i]) >= MAX_DMA_SIZE) ? MAX_DMA_SIZE : (len & mask[i]);
        if (sz) {
            err = dacspi_aligned_dma_raw(op, topo, ls, ea, sz, tag);
            ea += sz;
            ls += sz;
            len -= sz;
        }
        i += !(len & mask[i]);
    }

    if (dacsi_threaded)
        dacspi_mutex_unlock((mutex_ea_t)(uintptr_t)(&(topo)->dma_lock));

    return err;
}

static inline DACS_ERR_T
dacspi_dma_put(dacs_topology_t *topo, uint32_t ls, void *ea, unsigned int len,
               dacs_tag_t tag)
{
    return (dacspi_dma(MFC_GET_CMD, topo, ls, (uintptr_t)ea, len, tag));
}

static inline DACS_ERR_T
dacspi_dma_putf(dacs_topology_t *topo, uint32_t ls, void *ea, unsigned int len,
                dacs_tag_t tag)
{
    return (dacspi_dma(MFC_GETF_CMD, topo, ls, (uintptr_t)ea, len, tag));
}

static inline DACS_ERR_T
dacspi_dma_putb(dacs_topology_t *topo, uint32_t ls, void *ea, unsigned int len,
                dacs_tag_t tag)
{
    return (dacspi_dma(MFC_GETB_CMD, topo, ls, (uintptr_t)ea, len, tag));
}

static inline DACS_ERR_T
dacspi_dma_get(dacs_topology_t *topo, uint32_t ls, void *ea, unsigned int len,
               dacs_tag_t tag)
{
    return (dacspi_dma(MFC_PUT_CMD, topo, ls, (uintptr_t)ea, len, tag));
}

static inline DACS_ERR_T
dacspi_dma_getf(dacs_topology_t *topo, uint32_t ls, void *ea, unsigned int len,
                dacs_tag_t tag)
{
    return (dacspi_dma(MFC_PUTF_CMD, topo, ls, (uintptr_t)ea, len, tag));
}

static inline DACS_ERR_T
dacspi_dma_getb(dacs_topology_t *topo, uint32_t ls, void *ea, unsigned int len,
                dacs_tag_t tag)
{
    return (dacspi_dma(MFC_PUTB_CMD, topo, ls, (uintptr_t)ea, len, tag));
}

// 2 versions of the wait and test functions - one is the raw functionality; the 
// other has the necessary locks. allows for other functions to call the raw and 
// do the locking on it's own terms. the _spe_mfc_ calls must be wrapped by a
// mutex_lock so that other commands on the system don't send commands in the
// middle.
static inline DACS_ERR_T 
dacspi_dma_wait_raw(dacs_topology_t *topo, dacs_tag_t tag) 
{
    _spe_mfc_write_tag_mask((void *)(uintptr_t)topo->mfc_area, (1<<tag));
    while (!_spe_mfc_read_tag_status_immediate((void *)(uintptr_t)topo->mfc_area));
    return DACS_SUCCESS;
}

static inline DACS_ERR_T 
dacspi_dma_wait(dacs_topology_t *topo, dacs_tag_t tag) 
{
    DACS_ERR_T ret;

    // 
    // We need to guarantee that memory references occurring after wait are
    // not prefetched before wait is complete.  To accomplish this, we must do
    // a sync prior to exiting wait, so that on completion we are guaranteed
    // that any received data is correct.
    //
    // In the multi-threaded case, we do an unlock to protect the semantics of
    // the raw hardware tag wait.  This unlock performs a sync, so we don't
    // need to perform an explicit one.  However, in the single threaded case,
    // there is no unlock so we must perform an explicit sync.
    //
    if (dacsi_threaded) {

        dacspi_mutex_lock((mutex_ea_t)(uintptr_t)(&(topo)->dma_lock));
        ret = dacspi_dma_wait_raw(topo, tag);
        dacspi_mutex_unlock((mutex_ea_t)(uintptr_t)(&(topo)->dma_lock));

        return ret;
    } else {
        ret = dacspi_dma_wait_raw(topo, tag);
        __sync();

        return ret;
    }
}

static inline DACS_ERR_T 
dacspi_dma_test_raw(dacs_topology_t *topo, dacs_tag_t tag) 
{
    _spe_mfc_write_tag_mask((void *)(uintptr_t)topo->mfc_area, (1<<tag));
    if (_spe_mfc_read_tag_status_immediate((void *)(uintptr_t)topo->mfc_area) & (1<<tag))
        return DACS_WID_READY;
    else
        return DACS_WID_BUSY;
}

static inline DACS_ERR_T 
dacspi_dma_test(dacs_topology_t *topo, dacs_tag_t tag) 
{
    DACS_ERR_T ret;

    // 
    // We need to guarantee that memory references occurring after test are
    // not prefetched before test is complete.  To accomplish this, we must do
    // a sync prior to exiting test, so that on completion we are guaranteed
    // that any received data is correct.
    //
    // In the multi-threaded case, we do an unlock to protect the semantics of
    // the raw hardware tag test.  This unlock performs a sync, so we don't
    // need to perform an explicit one.  However, in the single threaded case,
    // there is no unlock so we must perform an explicit sync.
    //
    if (dacsi_threaded) {
        dacspi_mutex_lock((mutex_ea_t)(uintptr_t)(&(topo)->dma_lock));
        ret = dacspi_dma_test_raw(topo, tag);
        dacspi_mutex_unlock((mutex_ea_t)(uintptr_t)(&(topo)->dma_lock));

        return ret;
    } else {
        ret = dacspi_dma_test_raw(topo, tag);
        __sync();

        return ret;
    }
}

static inline int 
dacspi_ppu_mbox_status(dacs_topology_t *topo)
{
    return _spe_out_mbox_status((void *)(uintptr_t)topo->ctl_area);
}

static inline int 
dacspi_spu_mbox_status(dacs_topology_t *topo)
{
    return _spe_in_mbox_status((void *)(uintptr_t)topo->ctl_area);
}

static inline void
dacspi_mbox_read(dacs_topology_t *topo, unsigned int *data, int count)
{
    int i;
    
    for(i=0; i<count; i++) {
        data[i] = _spe_out_mbox_read((void *)(uintptr_t)topo->ctl_area);
    }
    /* If the SPE puts data into memory and then uses the mailbox to signal
     * the PPE of that fact, then a sync is needed here.  The concern is 
     * that while the PPE is waiting on the mailbox, it may have prefetched 
     * the data that the SPE is updating.
     */
    __sync();
}

static inline void
dacspi_mbox_write(dacs_topology_t *topo, unsigned int *data, int count, 
                  unsigned int behavior)
{
    int i;

    /* If the PPE stores data to memory and sends a mailbox to the SPE
     * to indicate that the data is available, a sync is needed to ensure
     * that the stored data is now visible on the bus.  a lightweight
     * sync would not guarantee this because the data written to memory
     * is in regular cache coherent memory, and the mailbox write is MMIO
     */ 
    __sync();
    for(i=0; i<count; i++) {
        _spe_in_mbox_write((void *)(uintptr_t)topo->ctl_area, data[i]);
    }
}

typedef union {
    unsigned long long ull;
    unsigned int ui[2];
} addr64;


#endif  //  _DACS_PPE_INTERNAL_H_
