/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

static char *ident = "@(#) internal-src/lib/dacs/cell/ppu/dacs_ppu_topology.c v1.28 - 9/16/08 09:55:50 @(#)";

#include    <unistd.h>
#include    <dacs.h>
#include    <dacs_ppe_internal.h>   // internal calls and defs


//  -----   internal fns    --------------------------------------------

DACS_ERR_T
dacs_ppu_get_num_avail_children(DACS_DE_TYPE_T type, uint32_t *num_children)
{
    DACS_ERR_T rc = DACS_SUCCESS;

#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_initialized())  
        return DACS_ERR_NOT_INITIALIZED;

    if (type >= DACS_DE_MAX_TYPE || type <= DACS_DE_INVALID)
        return DACS_ERR_INVALID_ATTR;

    if (num_children == NULL)
        return DACS_ERR_INVALID_ADDR;
#endif

    *num_children = 0;

    // On the PPU the only type of child is a DACS_DE_SPE, so if the user is
    // looking for something else, we'll fall thru with 0 found.
    if (type == DACS_DE_SPE) {
        uint32_t i;

        for (i = 0; i < dacs_tcb.num_children; i++) {
            if (dacs_tcb.children[i].reservation == DACSI_TOPO_FREE)
                (*num_children)++;
        }
    }

    return rc;
}

DACS_ERR_T
dacs_ppu_reserve_children(DACS_DE_TYPE_T type, uint32_t *num_children, 
                          de_id_t *de_list)
{
    DACS_ERR_T rc = DACS_SUCCESS;
    uint32_t childcnt = 0;

#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_initialized())  
        return DACS_ERR_NOT_INITIALIZED;

    if (type >= DACS_DE_MAX_TYPE || type <= DACS_DE_INVALID)
        return DACS_ERR_INVALID_ATTR;

    if (num_children == NULL || de_list == NULL)
        return DACS_ERR_INVALID_ADDR;
#endif

    DACSPI_TOPO_LOCK();
    if (type == DACS_DE_SPE) {
        uint32_t i;

        for (i = 0; i < dacs_tcb.num_children && childcnt < *num_children; i++)
        {
            //
            // If the child is available, let's reserve it.
            //
            if (dacs_tcb.children[i].reservation == DACSI_TOPO_FREE) {
                // The child is now reserved
                dacs_tcb.children[i].reservation = DACSI_TOPO_RESERVED;

                // Add the child's DE_ID to the supplied list
                de_list[childcnt++] = dacs_tcb.children[i].cb->de_id;
            }
        }
    }
    DACSPI_TOPO_UNLOCK();

    // Return the number of children actually reserved.
    *num_children = childcnt;

    return rc;
}

DACS_ERR_T
dacs_ppu_release_de_list(uint32_t num_des, de_id_t *de_list)
{
    DACS_ERR_T rc = DACS_SUCCESS;
    dacs_topology_t *topo;
    uint32_t i;

#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_initialized())  
        return DACS_ERR_NOT_INITIALIZED;

    if (de_list == NULL)
        return DACS_ERR_INVALID_ADDR;

    if (num_des == 0)
        return DACS_ERR_INVALID_SIZE;
#endif

    DACSPI_TOPO_LOCK();

#ifdef DACS_ERROR_CHECKING
    for (i = 0; i < num_des; i++) {
        topo = dacsi_find_de(de_list[i], &dacs_tcb);
        if (!topo) {
           DACSPI_TOPO_UNLOCK();
           return DACS_ERR_INVALID_DE;
        }
        else if (topo->pids[ONLYPID].status != DACSI_PID_INVALID) {
           DACSPI_TOPO_UNLOCK();
           return DACS_ERR_RESOURCE_BUSY;
        }
    }
#endif


    //
    // Walk the provided list and free any DEs that we have reserved.
    //
    for (i = 0; i < num_des; i++) {
        //  attempt to find the de's topo struct
        topo = dacsi_find_de(de_list[i], &dacs_tcb);
        if (!topo) {
            rc = DACS_ERR_INVALID_DE;
            continue;
        }

        // The DE has to be RESERVED and we need to be the parent
        if (topo->reservation == DACSI_TOPO_RESERVED) {
            // The child is now free
            topo->reservation = DACSI_TOPO_FREE;

            // Clear the child from the list
            de_list[i] = DACS_DE_INVALID;
        }
    }
    DACSPI_TOPO_UNLOCK();

    return rc;
}

