/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

static char *ident = "@(#) internal-src/lib/dacs/cell/ppu/dacspi_topology.c v1.34 - 9/16/08 09:55:49 @(#)";

#include <unistd.h>
#include <dacs.h>
#include <dacs_common.h>
#include <dacs_ppe_internal.h>
#include <dacs_debug.h>
#include <libspe2.h>
#include <dacs_trace.h>
//
// Global DaCS topology struct
//
dacs_topology_t dacs_tcb; 

uint32_t dacs_topo_lock;	/* topology lock */

static struct dacs_topology parent_topo;
static struct dacs_topology peers_topo[MAX_PPE_PEERS];
static struct dacs_topology children_topo[NUM_SPES_PER_BLADE + 1];

static void
set_tcb_entry(dacs_topology_t *topo, DACSI_TOPO_STS_T reservation,
                uint32_t my_index, de_handle_t dh, dacsi_cb_t *cb,
                struct dacs_topology *parent, uint32_t num_peers,
                struct dacs_topology *peers, uint32_t num_children,
                struct dacs_topology *children, uint16_t max_processes);


//  --------------------------------------------------------------------
//
// Initializes all the dacs topology globals for the host element.
// Called by dacs_runtime_init()
//
// --------------------------------------------------------------------
DACS_ERR_T
dacspi_topology_init(void *argv, void *envp)
{
    uint32_t    i               = 0;
    DACS_ERR_T  rc              =   DACS_SUCCESS;
    uint32_t    num_child_peers =   0;
    uint32_t    num_children    =   0;

    switch (dacs_rcb[0].type)
    {
        case DACS_DE_CELL_BLADE:
            num_children       = spe_cpu_info_get(SPE_COUNT_USABLE_SPES, -1);
            num_child_peers    =   (NUM_SPES_PER_BLADE);
            break;

        case DACS_DE_CBE:
            num_children       = spe_cpu_info_get(SPE_COUNT_USABLE_SPES, (int)dacsi_numa_node);
            num_child_peers    =   (NUM_SPES_PER_CBE);
            break;

        default:
            rc = DACS_ERR_INTERNAL;
            num_children = 0;
            break;
    }

    DACSPI_TOPO_LOCK();	
    set_tcb_entry(
                    &dacs_tcb,
                    DACSI_TOPO_FREE,
                    0,                  //  my_index      index of host is 0
                    0,                  //  de_handle
                    &dacs_rcb[0],     //  cb
                    NULL,               //  parent topo
                    0,                  //  num_peers
                    NULL,               //  peer topos
                    num_children,       //  number of children
                    &children_topo[0],//  children topos
                    MAX_PROCESSES_PER_DE
                );


    dacs_tcb.children = &children_topo[0];
    for (i=0; i<dacs_tcb.num_children; i++)
    {
        set_tcb_entry(
                        &dacs_tcb.children[i],
                        DACSI_TOPO_FREE,
                        i+1,
                        0,
                        &dacs_rcb[i+1],
                        &dacs_tcb,
                        num_child_peers,
                        NULL,
                        0,
                        NULL,
                        MAX_PROCESSES_PER_DE
                    );
    }
    DACSPI_TOPO_UNLOCK();	

    return rc;
}


//  --------------------------------------------------------------------
//
// Close down all the dacs topology globals for the ppu
// Called by dacs_ppu_runtime_init()
//
// --------------------------------------------------------------------
DACS_ERR_T  dacspi_topology_exit( void )
{
    uint32_t    i   =   0;

    DACSPI_TOPO_LOCK();	
    // clean up children tcbs; set to values that will force an error if they
    //  are used again
    for( i=0; i< dacs_tcb.num_children; i++ )
    {
        set_tcb_entry(  &dacs_tcb.children[i],
                        DACSI_TOPO_INVALID,          //  reservation
                        i,                           //  my_index
                        i,                           //  dh
                        &dacs_rcb[i+1],              //  cb
                        &dacs_tcb,                   //  parent topo
                        0,                           //  num_peers
                        NULL,                        //  array of peers topos
                        0,                           //  leaf, nchildren = 0
                        NULL,                        
                        0                            // num_processes
                    );
    }

    // clean up main tcb, set to values that will force an error if it is
    //  used again
    set_tcb_entry(  &dacs_tcb,
                    DACSI_TOPO_INVALID, //  reservation
                    0,                  //  my_index
                    0,                  //  dh
                    &dacs_rcb[0],       //  cb
                    NULL,               //  parent topo
                    0,                  //  num_peers
                    NULL,               //  array of peers topos
                    0,                  //  number of children
                    NULL,               //  array of children topos
                    0                   // num_processes
                );

    DACSPI_TOPO_UNLOCK();	

    return  DACS_SUCCESS;
}

//  ===== GLOBAL INTERNAL FUNCTIONS ====================================

//
// Internal routine to dump the topology struct, should work on all
// levels.
//
void    dacsi_dump_topo( const char * offset, dacs_topology_t *t )
{
    uint32_t i   =   0;

    if ( t == NULL ) {  return; }

    TRACE_DEBUG(1, GENERAL, TRACE_DEBUG_PI_TOPOLOGY_1, t);
    TRACE_DEBUG(1, GENERAL, TRACE_DEBUG_PI_TOPOLOGY_2, t->reservation);
    TRACE_DEBUG(1, GENERAL, TRACE_DEBUG_PI_TOPOLOGY_3, t->my_index);
    TRACE_DEBUG(1, GENERAL, TRACE_DEBUG_PI_TOPOLOGY_4, (uint64_t) t->ctx);
    TRACE_DEBUG(0, GENERAL, TRACE_DEBUG_PI_TOPOLOGY_5, );
    dacsi_dump_cb( "\t\t", t->cb );

    if ( t->parent != NULL )
    {
        TRACE_DEBUG(1,GENERAL,TRACE_DEBUG_PI_TOPOLOGY_6, t->parent->cb->de_id);
    }

    TRACE_DEBUG(1,GENERAL,TRACE_DEBUG_PI_TOPOLOGY_7, t->num_peers);
    if ( t->peers != NULL )
    {
        for ( i=0; i<MAX_PPE_PEERS; i++ )
        {
            TRACE_DEBUG(1,GENERAL,TRACE_DEBUG_PI_TOPOLOGY_8, t->peers[i].cb->de_id);
        }
    }

    TRACE_DEBUG(1,GENERAL,TRACE_DEBUG_PI_TOPOLOGY_9, t->num_children);
    if ( t->children != NULL )
    {
        for ( i=0; i< t->num_children; i++ )
        {
            dacsi_dump_topo( "\t", &(t->children[i]) );
        }
    }

    TRACE_DEBUG(1, GENERAL, TRACE_DEBUG_PI_TOPOLOGY_10, t->nproc_supported);
    TRACE_DEBUG(1, GENERAL, TRACE_DEBUG_PI_TOPOLOGY_11, t->nproc_active);
    TRACE_DEBUG(0, GENERAL, TRACE_DEBUG_PI_TOPOLOGY_12, );

    return;
}


//
// Search the topology structs for the specified de, starting at "top"
//
dacs_topology_t  *dacsi_find_de( de_id_t de, dacs_topology_t * top )
{
    uint32_t   i   = 0;
    dacs_topology_t *ret =   NULL;

    //  sanity check
    if ( top == NULL )
    {
        return NULL;
    }

    //  just for sanities sake, check that this isn't the de they want.
    if ( de == top->cb->de_id )
    {
        return top;             // well that was easy.
    }

    //  search peers.  Currently (2006-12-15) this is not supported, but
    //  num_peers should be set to 0 everywhere, which should cause this to
    //  drop through
    for ( i=0; i<top->num_peers;  i++ )
    {
        ret = &(dacs_tcb.peers[i]);         // point to next candidate
        if ( ret->cb->de_id  == de )
        {
            // found it
            break;
        }
        ret = NULL;     // reset
    }
    if ( ret !=NULL )
    {
        return ret;
    }


    //  search children.
    for ( i=0; i<top->num_children; i++ )
    {
        ret = &(dacs_tcb.children[i]);      // point to next candidate
        if ( ret->cb->de_id  == de )
        {
            // found it
            break;
        }
        ret = NULL;     // reset
    }

    return  ret;
}




//
// Return a pointer to the topology struct belonging to the specified
//    de_id.  If the de_id is invalid or can't be found, returns NULL.
//
dacs_topology_t *dacsi_get_topo( de_id_t de, DACS_ERR_T *errcode )
{
    *errcode    =   DACS_SUCCESS;
    dacs_topology_t *ret =   NULL;

    if (de == DACS_DE_SELF)
        de = dacspi_local_de_id;

    ret = dacsi_find_de( de, &dacs_tcb );

    return ret;
}

//
// Return a pointer to the topology struct belonging to the specified
//    de_id.  If the de_id is invalid or can't be found, returns NULL.
//
DACSI_TOPO_STS_T dacspi_check_reservation( de_id_t de )
{
    dacs_topology_t *topo =   NULL;


    topo = dacsi_find_de( de, &dacs_tcb );
    if ( topo == NULL )
    {
        return DACSI_TOPO_INVALID;
    }

    return topo->reservation;
}


//
// scan all the children to of the passed-in topology to see if their
// reservation flag matches checkval.
// \param  de_topo  -  pointer to topology struct
// \param  checkval -  reservation flag, one of \ref DACSI_TOPO_STS_T
// \return status:
// -   0   passed, they all match
// -   nonzero, one or more do not match
// \note   this should be written to be recursive, currently it only
// checks the children on the next level down.
//
int dacspi_check_children_reservations( dacs_topology_t *de_topo,
                                        DACSI_TOPO_STS_T checkval )
{
    uint32_t i      =   0;
    int matchcount  =   0xdeadbeef;

    //  sanity check
    if ( de_topo == NULL )
    {
        TRACE_DEBUG(0, GENERAL, TRACE_DEBUG_PI_TOPOLOGY_13, );
        return -1;
    }

    //  by definition, a leaf fails this test.
    if ( de_topo->num_children == 0 )
    {
        TRACE_DEBUG(0, GENERAL, TRACE_DEBUG_PI_TOPOLOGY_14, );
        //$$$$$return -2;
        return  0;      // maybe not.
    }

    matchcount  =   de_topo->num_children;      // init

    //  count the # of children with the same checkval, when we're done it
    //  should match the number of children
    for ( i=0; i<de_topo->num_children; i++ )
    {
        if ( de_topo->children[i].reservation == checkval )
        {
            matchcount --;
        }
    }


    // if all the children matched, matchcount will be 0
    return  matchcount;
}



int dacspi_set_children_reservations(    dacs_topology_t *de_topo,
                                        DACSI_TOPO_STS_T setval )
{
    uint32_t i  =   0;

    if ( de_topo == NULL )
    {
        TRACE_DEBUG(0, GENERAL, TRACE_DEBUG_PI_TOPOLOGY_15, );
        return -1;
    }   // sanity check

    //  count the # of children with the same checkval, when we're done it
    //  should match the number of children
    for ( i=0; i<de_topo->num_children; i++ )
    {

        de_topo->children[i].reservation = setval;
    }

    return  0;      // goodness
}


//
// Check if dacs_runtime_init has been run
//
uint32_t   dacsi_is_initialized( void )
{

    return  dacsi_runtime_initialized;
}

//  ===== INTERNAL FUNCTIONS ====================================

static void
set_tcb_entry(dacs_topology_t *topo, DACSI_TOPO_STS_T reservation,
                uint32_t my_index, dacs_addr_64_t ctx, dacsi_cb_t *cb,
                struct dacs_topology *parent, uint32_t num_peers,
                struct dacs_topology *peers, uint32_t num_children,
                struct dacs_topology *children, uint16_t max_processes)
{
    topo->reservation            =   reservation;
    topo->ctx                    =   ctx;
    topo->my_index               =   my_index;
    topo->cb                     =   cb;
    topo->parent                 =   parent;
    topo->num_peers              =   num_peers;
    topo->peers                  =   peers;
    topo->num_children           =   num_children;
    topo->children               =   children;
    topo->nproc_supported        =   max_processes;
    topo->nproc_active           =   0;

    //  init 1st pid
    topo->pids[ONLYPID].pid.pid_id =   0;
    topo->pids[ONLYPID].status     =   DACSI_PID_INVALID;
    topo->pids[ONLYPID].nwaiters   =   0;

    return;
}

