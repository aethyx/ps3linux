/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

static char *ident = "@(#) internal-src/lib/dacs/cell/ppu/dacs_ppu_dma.c v1.25 - 9/16/08 09:57:02 @(#)";

/*
 * dacs_ppu_dma.c - defines functions for remote memory operations on the PPU
 */

#include <stdlib.h>
#include <errno.h>

#include <dacs_ppe_internal.h>
#include <dacs_ppu_shared_obj.h>
#include <dacs_ppu_dma.h>
#include <dacs_ppu_data_sync.h>
#include <dacsi_q.h>
#include <dacs_debug.h>

//$$FIXME - Need a real mechanism to get my own dacs_process_id
// Currently, only one process allowed per accelerator, so it's moot
#define dacspi_local_pid 0

/* ------------------------------------------------------------------ */

DACS_ERR_T  dacs_ppu_remote_mem_create( void *addr,
                                        uint64_t size,
                                        DACS_MEMORY_ACCESS_MODE_T access_mode,
                                        dacs_remote_mem_t *local_mem )
{
    DACS_ERR_T err = DACS_SUCCESS;
    dacsi_shared_obj_t *obj;
#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_initialized())  
        return DACS_ERR_NOT_INITIALIZED;

    if (!addr || !local_mem)               
        return DACS_ERR_INVALID_ADDR;

    if (!size)
        return DACS_ERR_INVALID_SIZE;

    // Check that the memory that was created is on a 16 byte boundry;
    if ((uint64_t)(uintptr_t) addr & 0xF)
        return DACS_ERR_NOT_ALIGNED;

    if (access_mode != DACS_READ_ONLY ||
        access_mode != DACS_WRITE_ONLY ||
        access_mode != DACS_READ_WRITE)
        return DACS_ERR_INVALID_ATTR;
#endif

    // Create our shared obj and manage it internally
    err = dacspi_ppu_shared_obj_create( (dacsi_shared_obj_t **) local_mem );
    if(err) return err;

    obj = (dacsi_shared_obj_t *)(uintptr_t) *local_mem;

    // If everything went ok, fill in the remote_mem specific parts of the 
    // structure
    obj->name                 = DACSI_REMOTE_MEM_NAME;
    obj->remote_mem.base_addr = (dacs_addr_64_t)(uintptr_t)addr;
    obj->remote_mem.size      = size;
    obj->remote_mem.access    = access_mode;

    return err;
}

// dacs_ppu_remote_mem_share uses a similiar mechanism to send/recv, and 
// also is responsible for allocating and deallocating a wid to wait on.

DACS_ERR_T dacs_ppu_remote_mem_share(   de_id_t            dst_de,
                                        dacs_process_id_t  dst_pid,
                                        dacs_remote_mem_t local_mem )
{
    DACS_ERR_T err;
    dacsi_shared_obj_t * obj = (dacsi_shared_obj_t *)(uintptr_t) local_mem;

#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_initialized())  
        return DACS_ERR_NOT_INITIALIZED;

    // can't share memory with yourself
    if (dst_de == dacspi_local_de_id)  
        return  DACS_ERR_INVALID_TARGET;

    // can't share memory that you don't own - resharing not yet allowed
    if (obj->owner_de != dacspi_local_de_id) 
        return DACS_ERR_NOT_OWNER;
#endif

    err = dacspi_ppu_share_obj(dst_de, dst_pid, obj);
 
    return err;
}


DACS_ERR_T dacs_ppu_remote_mem_accept( de_id_t src_de,
                                       dacs_process_id_t src_pid,
                                       dacs_remote_mem_t *remote_mem )
{
    return DACS_ERR_NOT_SUPPORTED_YET;
}

DACS_ERR_T dacs_ppu_remote_mem_release( dacs_remote_mem_t *remote_mem )
{
    return DACS_ERR_NOT_SUPPORTED_YET;
}


DACS_ERR_T dacs_ppu_remote_mem_destroy( dacs_remote_mem_t *remote_mem )
{
    dacsi_shared_obj_t *obj;

#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_initialized())
        return DACS_ERR_NOT_INITIALIZED;

    if (!remote_mem)
        return DACS_ERR_INVALID_ADDR;
#endif

    obj = (dacsi_shared_obj_t *)(uintptr_t) *remote_mem;

#ifdef DACS_ERROR_CHECKING
    if (!obj || obj->name != DACSI_REMOTE_MEM_NAME) 
        return DACS_ERR_INVALID_HANDLE;
#endif

    return DACS_SUCCESS;
}

DACS_ERR_T dacs_ppu_remote_mem_query(dacs_remote_mem_t       remote_mem,
                                     DACS_REMOTE_MEM_ATTR_T  attr,
                                     uint64_t                *value)
{
    DACS_ERR_T err = DACS_SUCCESS;
    dacsi_shared_obj_t *obj = (dacsi_shared_obj_t *)(uintptr_t)remote_mem;

#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_initialized())
        return DACS_ERR_NOT_INITIALIZED;

    if (!obj || obj->name != DACSI_REMOTE_MEM_NAME) 
        return DACS_ERR_INVALID_HANDLE;

    if (!value)
        return DACS_ERR_INVALID_ADDR;
#endif

    switch(attr) {
        case DACS_REMOTE_MEM_SIZE:
            *value = obj->remote_mem.size;
            break;

        case DACS_REMOTE_MEM_ADDR:
            *value = obj->remote_mem.base_addr;
            break;

        case DACS_REMOTE_MEM_PERM:
            *value = obj->remote_mem.access;
            break;

        default:
            err = DACS_ERR_INVALID_ATTR;
    }

    return err;
}


// dacs_ppu_put kicks off a remote DMA get on the SPU that the memory is 
// shared with. (it's a put from the PPU perspective, but a get from the SPU)
DACS_ERR_T dacs_ppu_put( dacs_remote_mem_t  dst_remote_mem,
                         uint64_t           dst_remote_mem_offset,
                         void              *src_addr,
                         uint64_t           size,
                         dacs_wid_t         wid,
                         DACS_ORDER_ATTR_T  order_attr,
                         DACS_BYTE_SWAP_T   swap)
{
    return DACS_ERR_NOT_SUPPORTED_YET;
}

// dacs_ppu_get kicks off a remote DMA put on the SPU that the memory is 
// shared with.  (it's a get from the PPU perspective, but a put from the SPU)
DACS_ERR_T dacs_ppu_get( void               *dst_addr,
                         dacs_remote_mem_t   src_remote_mem,
                         uint64_t            src_remote_mem_offset,
                         uint64_t            size,
                         dacs_wid_t          wid,
                         DACS_ORDER_ATTR_T   order_attr,
                         DACS_BYTE_SWAP_T    swap )
{
    return DACS_ERR_NOT_SUPPORTED_YET;
}

DACS_ERR_T dacs_ppu_put_list( dacs_remote_mem_t    dst_remote_mem,
                              dacs_dma_list_t     *dst_dma_list,
                              uint32_t             dst_list_size,
                              void                *src_addr,
                              dacs_dma_list_t     *src_dma_list,
                              uint32_t             src_list_size,
                              dacs_wid_t           wid,
                              DACS_ORDER_ATTR_T    order_attr,
                              DACS_BYTE_SWAP_T     swap)
{
    return DACS_ERR_NOT_SUPPORTED_YET;
}

DACS_ERR_T dacs_ppu_get_list( void                *dst_addr,
                              dacs_dma_list_t     *dst_dma_list,
                              uint32_t             dst_list_size,
                              dacs_remote_mem_t    src_remote_mem,
                              dacs_dma_list_t     *src_dma_list,
                              uint32_t             src_list_size,
                              dacs_wid_t           wid,
                              DACS_ORDER_ATTR_T    order_attr,
                              DACS_BYTE_SWAP_T     swap)

{
    return DACS_ERR_NOT_SUPPORTED_YET;
}

//  =====   CONSTRUCTOR and DESTRUCTOR

DACS_ERR_T  dacspi_dma_init(    void * argvp, void *envp )
{
    return  DACS_SUCCESS;
}

DACS_ERR_T  dacspi_dma_exit(    void )
{
    return  DACS_SUCCESS;
}
