/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

static char *ident = "@(#) internal-src/lib/dacs/cell/ppu/dacs_ppu_shared_obj.c v1.18 - 9/16/08 09:55:36 @(#)";

#include <dacs.h>
#include <dacs_ppe_internal.h>
#include <dacs_common.h>
#include <dacs_ppu_data_sync.h>
#include <dacs_ppu_send_recv.h>
#include <dacs_trace.h>

#define _XOPEN_SOURCE 600     // required for for posix memalign 
#include <stdlib.h>           // for posix_memalign

// dacspi_ppu_shared_obj_init is used to malloc and initialize all of the 
// parts of the shared_obj that are not unique (parts not specific to 
// shared_mem, mutex, barrier).  The caller then initializes their 
// object-specific version of the structs
DACS_ERR_T  dacspi_ppu_shared_obj_create( dacsi_shared_obj_t **obj )
{
    return DACS_SUCCESS;
}

// dacspi_ppu_share_obj uses a similiar mechanism to send/recv, and 
// also is responsible for allocating and deallocating a wid to wait on.
DACS_ERR_T dacspi_ppu_share_obj( de_id_t              dst_de,
                                 dacs_process_id_t    dst_pid,
                                 dacsi_shared_obj_t  *obj )
{
    uint32_t                 dst_index;
    dacs_topology_t         *topo;
    DACS_ERR_T               err;
    dacs_wid_t               wid;
    uint32_t                 stream = DACS_STREAM_UB;
    ALIGNED_DATA(send_msg, dacs_addr_64_t, 16, sizeof(dacs_addr_64_t));
    ALIGNED_DATA(recv_msg, DACSI_SHARED_OBJ_NAME_T, 16, 
                 sizeof(DACSI_SHARED_OBJ_NAME_T));

    topo = dacsi_get_topo(dst_de, &err);
#ifdef DACS_ERROR_CHECKING
    if(!topo) 
        return DACS_ERR_INVALID_DE;

    if (obj->name != DACSI_MUTEX_NAME && 
        obj->name != DACSI_REMOTE_MEM_NAME && 
        obj->name != DACSI_GROUP_NAME) {
        return DACS_ERR_INTERNAL;
    }
#endif
    dst_index = topo->my_index;
    stream += (obj->name & 0x3);

    TRACE_DEBUG(1,GENERAL, TRACE_DEBUG_PPU_SHARED_OBJ_1, dst_index);
    TRACE_DEBUG(1,GENERAL, TRACE_DEBUG_PPU_SHARED_OBJ_2, obj->owner_de);
    TRACE_DEBUG(1,GENERAL, TRACE_DEBUG_PPU_SHARED_OBJ_3, obj->owner_pid);
    TRACE_DEBUG(1,GENERAL, TRACE_DEBUG_PPU_SHARED_OBJ_4, obj->tier);
    TRACE_DEBUG(1,GENERAL, TRACE_DEBUG_PPU_SHARED_OBJ_5, obj->name);

    // Send over a pointer to the object 
    *send_msg = (uintptr_t)obj;
    err = dacs_ppu_send(send_msg, sizeof(dacs_addr_64_t), dst_de, dst_pid, 
                        stream, DACSPI_SHARED_OBJ_WID, 0);
    if (!err)
        err = dacs_ppu_wait(&dacsi_waitq[DACSPI_SHARED_OBJ_WID], 
                            DACSPI_SHARED_OBJ_WID);

    if (err)
        return err;
 
    // Wait for the completion message from the other side
    err = dacs_ppu_recv(recv_msg, sizeof(uint32_t), dst_de, dst_pid, stream, 
                        DACSPI_SHARED_OBJ_WID, 0);
    if (!err)
        err = dacs_ppu_wait(&dacsi_waitq[DACSPI_SHARED_OBJ_WID], 
                            DACSPI_SHARED_OBJ_WID);

    if (err)
        return err;

    // The acceptor should send back the ME key to complete the handshake 
    // successfully.  This is just something we use internally as a 
    // nontrivial identifier
    if (*recv_msg != obj->name)
        return DACS_ERR_INTERNAL;

    // Atomically increment the refcount
    dacspi_atomic_modify((atomic_ea_t)(uintptr_t) &(obj->refcnt),1);

    return DACS_SUCCESS;
}


DACS_ERR_T dacspi_ppu_shared_obj_accept(de_id_t src_de,
                                        dacs_process_id_t src_pid,
                                        dacsi_shared_obj_t *obj)
{
    return DACS_ERR_NOT_SUPPORTED_YET;
}

DACS_ERR_T dacspi_ppu_shared_obj_release( dacsi_shared_obj_t * obj)
{
    return DACS_ERR_NOT_SUPPORTED_YET;
}

//  =====   CONSTRUCTOR and DESTRUCTOR

DACS_ERR_T  dacspi_shared_obj_init(void *argvp, void *envp)
{
    return  DACS_SUCCESS;
}

DACS_ERR_T  dacspi_shared_obj_exit(void)
{
    return  DACS_SUCCESS;
}

