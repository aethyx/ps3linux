/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

// @(#) internal-src/lib/dacs/cell/ppu/dacs_ppu_atomic.h v1.6 - 9/16/08 09:55:53 @(#)

/*
 * Atomic primitives for PPU
 */

#ifndef _DACS_PPU_ATOMIC_H_
#define _DACS_PPU_ATOMIC_H_

#include <inttypes.h>
#include "ppu_intrinsics.h"
#include "dacs_trace.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * DACSI_ULL_TO_PTR - convert a 64-bit unsigned long long to a void 
 *                   pointer.
 */
#ifdef __powerpc64__

#define DACSI_ULL_TO_PTR(_ull, _ptr) {  \
  union {                               \
    void *ptr;                          \
    unsigned long long ull;             \
  } _x;                                 \
                                        \
  _x.ull = _ull;                        \
  _ptr = _x.ptr;                        \
}

#else

#define DACSI_ULL_TO_PTR(_ull, _ptr) {  \
  union {                               \
    void *ptr[2];                       \
    unsigned long long ull;             \
  } _x;                                 \
                                        \
  _x.ull = _ull;                        \
  _ptr = _x.ptr[1];                     \
}

#endif


/*
 * atomically loads and replaces the value v with val.
 * Returns the old value at v
 */
static __inline int
dacspi_atomic_replace(atomic_ea_t v, int val)
{
    int old;
    void *p;

    DACSI_ULL_TO_PTR(v, p);

    do {
        old = (int)__lwarx(p);
    } while (__stwcx(p, (unsigned int)val) == 0);

    return old;
}

#define dacspi_atomic_set32 dacspi_atomic_replace

/*
 * atomically loads the value at v, adds val, replaces the
 * value at v with the sum. Returns the old value at v
 */
static __inline int
dacspi_atomic_modify(atomic_ea_t v, int val)
{
    int old, new_val;
    void *p;

    DACSI_ULL_TO_PTR(v, p);

    do {
        old = (int)__lwarx(p);
        new_val = old + val;
    } while (__stwcx(p, (unsigned int)new_val) == 0);

    return old;
}

static __inline int
dacspi_atomic_and(atomic_ea_t v, int val)
{
    int old, new_val;
    void *p;

    DACSI_ULL_TO_PTR(v, p);

    do {
        old = (int)__lwarx(p);
        new_val = old & val;
    } while (__stwcx(p, (unsigned int)new_val) == 0);

    return old;
}

static __inline int
dacspi_atomic_or(atomic_ea_t v, int val)
{
    int old, new_val;
    void *p;

    DACSI_ULL_TO_PTR(v, p);

    do {
        old = (int)__lwarx(p);
        new_val = old | val;
    } while (__stwcx(p, (unsigned int)new_val) == 0);

    return old;
}
#ifdef __powerpc64__

static __inline uint64_t
dacspi_atomic_replace64(atomic_ea_t v, uint64_t val)
{
    uint64_t old;
    void *p;

    DACSI_ULL_TO_PTR(v, p);

    do {
        old = __ldarx(p);
    } while (__stdcx(p, val) == 0);

    return old;
}

#define dacspi_atomic_set64 dacspi_atomic_replace64

static __inline uint64_t
dacspi_atomic_modify64(atomic_ea_t v, uint64_t val)
{
    uint64_t old, new_val;
    void *p;

    DACSI_ULL_TO_PTR(v, p);

    do {
        old = __ldarx(p);
        new_val = old + val;
    } while (__stdcx(p, new_val) == 0);

    return old;
}

static __inline uint64_t
dacspi_atomic_and64(atomic_ea_t v, uint64_t val)
{
    uint64_t old, new_val;
    void *p;

    DACSI_ULL_TO_PTR(v, p);

    do {
        old = __ldarx(p);
        new_val = old & val;
    } while (__stdcx(p, new_val) == 0);

    return old;
}

static __inline uint64_t
dacspi_atomic_or64(atomic_ea_t v, uint64_t val)
{
    uint64_t old, new_val;
    void *p;

    DACSI_ULL_TO_PTR(v, p);

    do {
        old = __ldarx(p);
        new_val = old | val;
    } while (__stdcx(p, new_val) == 0);

    return old;
}
#endif /* __powerpc64__ */

/* function: dacspi_mutex_lock
 *
 * Aquire a lock at a location in system memory by waiting for the
 * value to become zero, then atomically storing 1.
 */
static __inline void
dacspi_mutex_lock(mutex_ea_t lock)
{
    unsigned done = 0;
    void *p;

#ifdef TRACE_PERF_ENABLE
    int miss = -1;
#endif

    TRACE_INTERVAL_TOKEN_ARGUMENT(interval);  
    TRACE_INTERVAL_BEGIN(_DACS_HOST_MUTEX_LOCK, interval, 0);

    DACSI_ULL_TO_PTR(lock, p);

    do {
        if (__lwarx(p) == 0)
            done = __stwcx(p, 1);
#ifdef TRACE_PERF_ENABLE
        miss++;
#endif

    } while (done == 0);
    __isync();

    TRACE_INTERVAL_END(_DACS_HOST_MUTEX_LOCK, interval, 0, lock, miss);
}

/* function: dacspi_mutex_unlock
 *
 * Release a lock held at address 'lock' in system memory.
 * For the PPU, this routine is the same _unlock, and is
 * provided here as a simple convenience for programmers
 * (to match the interfaces that are supported on the SPU).
 * All I need to do is a store since store is an atomic operation by itself
 */
static __inline void
dacspi_mutex_unlock(mutex_ea_t lock)
{
    void *p;

    DACSI_ULL_TO_PTR(lock, p);
    __sync();
    *(int *)p = 0;

    TRACE_PERF(_DACS_HOST_MUTEX_UNLOCK, 0, lock);
}

/* function: dacspi_mutex_trylock 
 *
 * Attempt to immediately aquire a lock at a location in system memory,
 * and return 1 if the lock was aquired or 0 otherwise.
 */
static __inline int
dacspi_mutex_trylock(mutex_ea_t lock)
{
    int val;
    int ret = 0;
    void *p;

    DACSI_ULL_TO_PTR(lock, p);

    do {
        val = (int)__lwarx(p);
        if (val) break;
    } while ((ret = __stwcx(p, 1)) == 0);
    __isync();

    TRACE_PERF(_DACS_HOST_MUTEX_TRYLOCK, 0, lock, ret);

    return (ret);
}

static __inline void
dacspi_mutex_init(mutex_ea_t lock)
{
    dacspi_atomic_set32(lock, 0);

    TRACE_PERF(_DACS_HOST_MUTEX_INIT, 0, lock);
}

#ifdef __cplusplus
}
#endif

#endif //_DACS_ATOMIC_H_
