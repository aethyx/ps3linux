/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

static char *ident = "@(#) internal-src/lib/dacs/cell/ppu/dacs_ppu_process.c v1.57 - 9/16/08 09:55:34 @(#)";

#include <dacs_ppu_process.h>
#include <dacs_ppe_internal.h>
#include <dacs_error_internal.h>
#include <sys/wait.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <dacs_debug.h>
#include <libspe2.h>
#include <dacs_trace.h>

// version of the ppe code:
static uint32_t dacspi_ppe_version = DACSI_VERSION;
uint32_t dacspi_ctx_flags = SPE_MAP_PS|SPE_EVENTS_ENABLE;

#define DACSI_UNKNOWN_ERROR     255
#define MAX_ERROR_RANGE ELOOP
static const int error_mapping_table[] = {
    DACS_ERR_SYSTEM,                      DACS_ERR_NO_PERM/*EPERM:1*/, 
    DACS_ERR_NOT_FOUND/*ENOENT:2*/,       DACS_ERR_SYSTEM, 
    DACS_ERR_SYSTEM,                      DACS_ERR_SYSTEM, 
    DACS_ERR_SYSTEM,                      DACS_ERR_SYSTEM, 
    DACS_ERR_INVALID_PROG/*ENOEXEC:8*/,   DACS_ERR_SYSTEM,
    DACS_ERR_SYSTEM,                      DACS_ERR_SYSTEM, 
    DACS_ERR_NO_RESOURCE/*ENOMEM:12:*/,   DACS_ERR_NO_PERM/*EACCES:13*/, 
    DACS_ERR_INVALID_ADDR/*EFAULT:14*/,   DACS_ERR_SYSTEM, 
    DACS_ERR_SYSTEM,                      DACS_ERR_SYSTEM, 
    DACS_ERR_SYSTEM,                      DACS_ERR_SYSTEM,
    DACS_ERR_NOT_FOUND/*ENOTDIR:20*/,     DACS_ERR_SYSTEM, 
    DACS_ERR_INVALID_PROG/*EINVAL:22*/,   DACS_ERR_SYSTEM, 
    DACS_ERR_SYSTEM,                      DACS_ERR_SYSTEM, 
    DACS_ERR_RESOURCE_BUSY/*ETXTBSY:26*/, DACS_ERR_SYSTEM, 
    DACS_ERR_SYSTEM,                      DACS_ERR_SYSTEM,
    DACS_ERR_SYSTEM,                      DACS_ERR_SYSTEM, 
    DACS_ERR_SYSTEM,                      DACS_ERR_SYSTEM, 
    DACS_ERR_SYSTEM,                      DACS_ERR_SYSTEM, 
    DACS_ERR_TOO_LONG/*ENAMETOOLONG:36*/, DACS_ERR_SYSTEM, 
    DACS_ERR_SYSTEM,                      DACS_ERR_SYSTEM,
    DACS_ERR_TOO_LONG
    /*ELOOP:40 Max error code in mapping table*/
};

static void *
dacsi_pthread_create( void *args )
{
    dacs_topology_t *topo = (dacs_topology_t *)args;
    int rc;
    dacs_stop_info_t *stopinfo = &topo->pids[ONLYPID].stopinfo;

    // enable async cancellation
    pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
    pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);

    // Load the executable for this context
    rc = spe_program_load((spe_context_ptr_t)(uintptr_t)topo->ctx,
                          (spe_program_handle_t *)
                                (uintptr_t)topo->pids[ONLYPID].prog_handle);
    if (rc) {
        TRACE_DEBUG(1, GENERAL, TRACE_DEBUG_PPU_PROCESS_1, rc);
        goto out;
    }

run:
    // Run this SPE thread context.
    // This call does not return until the executable completes.
    rc = spe_context_run((spe_context_ptr_t)(uintptr_t)topo->ctx,
                        &topo->pids[ONLYPID].entry,
                        topo->pids[ONLYPID].flags,
                        (void *)(uintptr_t) topo->pids[ONLYPID].argv,
                        (void *)(uintptr_t) topo->pids[ONLYPID].envv, 
                        (spe_stop_info_t *) stopinfo); 

    DACSPI_TOPO_LOCK();

    // change the process state to stopped to
    // satisfy de_test/wait()
    //
    topo->pids[ONLYPID].status = DACSI_PID_STOPPED;

    TRACE_DEBUG(2, GENERAL, TRACE_DEBUG_PPU_PROCESS_2, 
            stopinfo->stop_reason, stopinfo->result.exit_code);

    // We can't appear to check the return value from context run because
    // sometimes it returns -1 and sometimes it returns 0.  Fortunately, the
    // stop reason, should always be between 1 and 6, so check it instead.
    // If we hit a stop and signal or callback error, we should ignore them
    // and resume where we left off.
    if (stopinfo->stop_reason > 0) {
        if (stopinfo->stop_reason == SPE_STOP_AND_SIGNAL || 
            stopinfo->stop_reason == SPE_CALLBACK_ERROR) {
            TRACE_DEBUG(1, GENERAL, TRACE_DEBUG_PPU_PROCESS_3, stopinfo->stop_reason);
            topo->pids[ONLYPID].status = DACSI_PID_RUNNING;
            DACSPI_TOPO_UNLOCK();
            goto run;
        }

        // SPE thread terminated with an error, notify error handlers
        if ((stopinfo->stop_reason == SPE_EXIT &&
                    stopinfo->result.exit_code != 0)
                || stopinfo->stop_reason != SPE_EXIT)
        {
            dacsi_error_t error;
            DACS_ERR_T status;

            topo->pids[ONLYPID].status = DACSI_PID_TERM;

            if (stopinfo->stop_reason == SPE_EXIT)
                status = DACS_STS_PROC_FAILED;
            else
                status = DACS_STS_PROC_ABORTED;

            error.name = DACSI_ERROR_NAME;
            error.err_num = status;
            error.err_code = stopinfo->result.exit_code;
            error.err_de = topo->cb->de_id;
            error.err_pid = TOPO_PID_TO_PROCESS_ID(topo,ONLYPID);

            // unlock before calling error handlers
            // so they can call de_test/wait()
            DACSPI_TOPO_UNLOCK();
            dacsi_throw_error(&error, DACSI_ERROR_ASYNC);
            goto out;
        }
    }
#if DACS_DEBUG
    else
        ASSERT(0);
#endif
    topo->pids[ONLYPID].status = DACSI_PID_TERM;

    DACSPI_TOPO_UNLOCK();

out:
    pthread_exit(NULL);
}

//
// dacspi_send_cb_by_mailbox - Send the initial control block to a given 
//                             SPE context.
// The CB info is sent via 3 ordered mailbox entries:
//     1) cb_64_addr.hi
//     2) cb_64_addr.lo
//     3) dacspi_ppe_version
//
// If the recipient mailbox can't accomodate 3 mailbox entries then we fail.
// This situation would be odd as we should be the only one sending to this
// context.
//
// NOTE: [ONLYPID] This function currently only supports a single thread
//       per SPE.  The function will require DE/PID arguments in the 
//       future in order to support multi-threading.
//
static DACS_ERR_T
dacspi_send_cb_by_mailbox(dacs_topology_t *topo, dacsi_cb_t *cb)
{
    addr64 cb_64_addr;
    DACS_ERR_T err = DACS_SUCCESS;
    int timer = 0;
    unsigned int cb_data[3];
    uint32_t index = cb->index;
    unsigned int spe_version;

    TRACE_DEBUG(3, GENERAL, TRACE_DEBUG_PPU_PROCESS_4, topo->ctx, cb, index );

    // $$ possibly add wait loop
    if ((dacspi_spu_mbox_status(topo)) <  3 )
    {
        // not enough slots in mailbox to start
        // How could this have happened on a newly created thread?
        TRACE_DEBUG(1, GENERAL, TRACE_DEBUG_PPU_PROCESS_5, dacspi_spu_mbox_status(topo));
        return DACS_ERR_SYSTEM;       // not enough mailbox slots
    }

    // Package our mailbox data mailbox writes of 3 pieces of data.
    cb_64_addr.ull = (unsigned long long)(uintptr_t) cb;   // convert to uint64
    cb_data[0] = cb_64_addr.ui[0];
    cb_data[1] = cb_64_addr.ui[1];

    // Send the CB data to the recipient context.
    // We wait until all data has been sent.
    dacspi_mbox_write(topo, &cb_data[0], 1, SPE_MBOX_ALL_BLOCKING);
    dacspi_mbox_write(topo, &cb_data[1], 1, SPE_MBOX_ALL_BLOCKING);

    // now send our version
    TRACE_DEBUG(1, GENERAL, TRACE_DEBUG_PPU_PROCESS_18, dacspi_ppe_version);

    dacspi_mbox_write(topo, &dacspi_ppe_version, 1, SPE_MBOX_ALL_BLOCKING);

    // Complete the handshake by waiting for the SPE to ack us back
    TRACE_DEBUG(1, GENERAL, TRACE_DEBUG_PPU_PROCESS_9, index);

    // Wait for acknowledgement to be sent back from the recipient
    while (dacspi_ppu_mbox_status(topo) == 0) {
        usleep(50);
        if(topo->pids[ONLYPID].status == DACSI_PID_TERM)
            return DACS_ERR_DE_TERM;
    }

    TRACE_DEBUG(2, GENERAL, TRACE_DEBUG_PPU_PROCESS_11, index, timer);

    // check the spe version
    dacspi_mbox_read(topo, &spe_version, 1);
    TRACE_DEBUG(1, GENERAL, TRACE_DEBUG_PPU_PROCESS_19, spe_version);

    if (err != DACS_SUCCESS) {
        return DACS_ERR_INTERNAL;
    } else if (dacspi_ppe_version != spe_version) {
        TRACE_DEBUG(1, GENERAL, TRACE_DEBUG_PPU_PROCESS_20,
                                DACS_ERR_VERSION_MISMATCH);
        // this is either a true mismatch, and even works if the
        //  spe is old (sdk3.0) and unversioned - the 3rd value
        //  it sends is a LSA of it's completion buffer.
        return DACS_ERR_VERSION_MISMATCH;
    }

    // Get the ack return data from the SPU
    // mailbox entry contains send Q address
    dacspi_mbox_read(topo, &dacspi_remote_msgQ[index][DACSI_MSG_SEND], 1);

    if (!dacspi_remote_msgQ[index][DACSI_MSG_SEND]) {
        err = DACS_ERR_INTERNAL;
        TRACE_DEBUG(2, GENERAL, TRACE_DEBUG_PPU_PROCESS_12, err,
                        dacspi_remote_msgQ[index][DACSI_MSG_SEND]);
    }

    // Get the ack return data from the SPU
    // The receive Q address follows the send so simply calc it's location.
    dacspi_remote_msgQ[index][DACSI_MSG_RECV] = 
            dacspi_remote_msgQ[index][DACSI_MSG_SEND] + 
                (DACSI_MAX_MSG_QE * sizeof(dacsi_msgQe_t));

    return err;
}

/// Start a DaCS process on an accelerator

DACS_ERR_T dacs_ppu_de_start (de_id_t de,
                              void *prog_name,
                              char const **my_argv,
                              char const **my_env,
                              DACS_PROC_CREATION_FLAG_T creation_flags,
                              dacs_process_id_t *pid)
{
    dacs_topology_t *topo;
    unsigned int my_cbe_mask;
    DACS_ERR_T errcode = DACS_SUCCESS;
    int32_t rc = 0;

#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_initialized())
        return DACS_ERR_NOT_INITIALIZED;

    if (prog_name == NULL || pid == NULL)
        return DACS_ERR_INVALID_ADDR;

    if (de == DACS_DE_PARENT || de == DACS_DE_SELF || de == dacspi_local_de_id)
        return DACS_ERR_INVALID_TARGET;
#endif

    DACSPI_TOPO_LOCK();
    topo = dacsi_get_topo(de, &errcode);

#ifdef DACS_ERROR_CHECKING
    if (!topo) {
        DACSPI_TOPO_UNLOCK();
        return DACS_ERR_INVALID_DE;
    }

    if (dacspi_check_reservation(de) != DACSI_TOPO_RESERVED) {
        DACSPI_TOPO_UNLOCK();
        return DACS_ERR_INVALID_DE;
    }
#endif

    /* We only support one process per de currently
     * so we can get by with just checking the single
     * pid state for now.
     * The STOPPED state can happen in normal operation, 
     * so it's still considered running
     */
    if ((topo->pids[ONLYPID].status == DACSI_PID_RUNNING) ||
        (topo->pids[ONLYPID].status == DACSI_PID_STOPPED)) 
        errcode = DACS_ERR_PROC_LIMIT;
    else {
        topo->nproc_active++;
        topo->pids[ONLYPID].status = DACSI_PID_RUNNING;
    }

    DACSPI_TOPO_UNLOCK();

    if (errcode != DACS_SUCCESS)
        return errcode;

    // Set the processor affinity, and SPE tells which CBE is allocated to this
    my_cbe_mask = 1 << (topo->my_index / NUM_SPES_PER_CBE);

    // Make sure the SPU program is mapped into memory
    if (creation_flags == DACS_PROC_EMBEDDED) {
        topo->pids[ONLYPID].prog_handle = prog_name;
    }
    else if(creation_flags == DACS_PROC_LOCAL_FILE) {
        topo->pids[ONLYPID].prog_handle = 
               spe_image_open((const char *) prog_name);

        if (topo->pids[ONLYPID].prog_handle == NULL)  {
            errcode = ((errno < 0) || (errno > MAX_ERROR_RANGE)) ? 
                        DACS_ERR_SYSTEM : error_mapping_table[ errno ];
            goto err_out;
        }

    }
    else {
        errcode = DACS_ERR_INVALID_ATTR;
        goto err_out;
    }

    // If we have not created a context yet, then do so now.
    // This will get cleaned up on dacs_exit rather than on de_kill or
    // de_wait/test, in order to promote reuse.
    if (!topo->ctx) {
        topo->ctx = (dacs_addr_64_t)(uintptr_t)
                        spe_context_create(dacspi_ctx_flags, NULL);

        if (!topo->ctx) {
            TRACE_DEBUG(1, GENERAL, TRACE_DEBUG_PPU_PROCESS_13, errno);
            errcode = DACS_ERR_SYSTEM;
            goto err_out;
        }

        // get direct problem state area for mfc ops
        topo->mfc_area = (dacs_addr_64_t)(uintptr_t)
                            spe_ps_area_get((spe_context_ptr_t)(uintptr_t)topo->ctx,
                            SPE_MFC_COMMAND_AREA);
        if (!topo->mfc_area) {
            errcode = DACS_ERR_SYSTEM;
            goto err_out;
        }

        // get direct problem state area for control/mbox ops
        topo->ctl_area = (dacs_addr_64_t)(uintptr_t)
                            spe_ps_area_get((spe_context_ptr_t)(uintptr_t)topo->ctx,
                            SPE_CONTROL_AREA);
        if (!topo->ctl_area) {
            errcode = DACS_ERR_SYSTEM;
            goto err_out;
        }

    }

    // Save off the argument data
    topo->pids[ONLYPID].argv = (dacs_addr_64_t)(uintptr_t) my_argv;
    topo->pids[ONLYPID].envv = (dacs_addr_64_t)(uintptr_t) my_env;

    // For now always start at the beginning
    topo->pids[ONLYPID].entry = SPE_DEFAULT_ENTRY;

    // Clear out our status/stopinfo data, so we start fresh.
    topo->pids[ONLYPID].stopinfo.stop_reason = 0;
    topo->pids[ONLYPID].stopinfo.result.exit_code = 0;
    topo->pids[ONLYPID].stopinfo.spu_status = 0;

    rc = pthread_create(&(topo->pids[ONLYPID].pid.pthread_id), NULL,
                            &dacsi_pthread_create, topo);

    if (rc) {
        ASSERT((rc != EPERM) && (rc != EINVAL));
        errcode = DACS_ERR_NO_RESOURCE;
        goto err_out;
    }

    //  send cb and index by the mailbox.  
    //  We send the base of the remote control block array because it 
    //  contains our (parent) CB.  The child can offset in based on index to
    //  get it's own.
    rc = dacspi_send_cb_by_mailbox(topo, &dacs_rcb[topo->my_index]);
    if ( rc ) {
        TRACE_DEBUG(1, GENERAL, TRACE_DEBUG_PPU_PROCESS_14, rc);
    	// failed to send cb & index to child.
    	// Release resources we grabbed above.
    	// Blow away the thread and context we created above.
    	// We are ignoring their status, as the first failure is more
	    // interesting.
        pthread_cancel(topo->pids[ONLYPID].pid.pthread_id);
        pthread_join(topo->pids[ONLYPID].pid.pthread_id, NULL);
        errcode = rc;
        goto err_out;
    }

    // everything passed, fill in struct and return
    *pid = (uintptr_t)TOPO_PID_TO_PROCESS_ID(topo,ONLYPID);             
    TRACE_DEBUG(3, GENERAL, TRACE_DEBUG_PPU_PROCESS_15,
            (uint64_t)topo->pids[ONLYPID].pid.pthread_id,&(topo->pids[ONLYPID].pid.pthread_id),*((uint64_t *)pid) );

    return DACS_SUCCESS;

err_out:
    topo->nproc_active--;
    topo->pids[ONLYPID].pid.pthread_id = 0;
    topo->pids[ONLYPID].status = DACSI_PID_INVALID;
    topo->pids[ONLYPID].prog_handle = NULL;
    return errcode;
}

// Indicate how many processes are supported on a DE.  
// Currently, SPEs are 1, CBEs are 1, and Blades are up to 2.
//
DACS_ERR_T
dacs_ppu_num_processes_supported (de_id_t de, uint32_t *num_processes )
{
    dacs_topology_t *topo;
    DACS_ERR_T    errcode;

#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_initialized())
        return  DACS_ERR_NOT_INITIALIZED;

    if (num_processes == NULL) 
        return DACS_ERR_INVALID_ADDR;
#endif

    // Get a pointer to the dacs topology struct for the DE
    topo = dacsi_get_topo(de, &errcode);

    if (topo == NULL)
        return DACS_ERR_INVALID_DE;

    *num_processes = 1;

    return DACS_SUCCESS;
}

#define DACS_DE_NOWAIT  0
#define DACS_DE_WAIT    1

//
// Common implementation of de_test() and de_wait()
//
DACS_ERR_T
dacspi_de_test(de_id_t de, dacs_process_id_t pid, int32_t *ret, int waitok)
{
    int32_t status;
    dacs_stop_info_t *stopinfo;
    dacs_topology_t *topo;
    DACS_ERR_T errcode;

#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_initialized())
        return DACS_ERR_NOT_INITIALIZED;

    if (ret == NULL)
        return DACS_ERR_INVALID_ADDR;

    if (de == DACS_DE_SELF || de == dacspi_local_de_id || pid == DACS_PID_SELF)
        return DACS_ERR_INVALID_TARGET;
#endif

    DACSPI_TOPO_LOCK();
    topo = dacsi_get_topo(de, &errcode);

#ifdef DACS_ERROR_CHECKING
    if (topo == NULL) {
        DACSPI_TOPO_UNLOCK();
        return DACS_ERR_INVALID_DE;
    }

    if (dacspi_check_reservation(de) != DACSI_TOPO_RESERVED) {
        DACSPI_TOPO_UNLOCK();
        return DACS_ERR_INVALID_DE;
    }

    if (topo->pids[ONLYPID].status == DACSI_PID_INVALID) {
        DACSPI_TOPO_UNLOCK();
        return DACS_ERR_INVALID_PID;
    }

    if ((pid != TOPO_PID_TO_PROCESS_ID(topo,ONLYPID)) && (pid != DACS_PROCESS_ALL)) {
        DACSPI_TOPO_UNLOCK();
        return DACS_ERR_INVALID_PID;
    }
#endif

    // If this is a test (NOWAIT) and the proc is still RUNNING then just
    // return the status.
    if (topo->pids[ONLYPID].status == DACSI_PID_RUNNING &&
        waitok == DACS_DE_NOWAIT) {
        DACSPI_TOPO_UNLOCK();
        return DACS_STS_PROC_RUNNING;
    }

    // Otherwise, we are doing a test in which the DE is done or we are doing
    // a wait.  In either case, we need to do a join on the thread to
    // close it out.  In the wait case, if the proc is still running, this
    // will stall.  
    //
    // increment the waiters count so other
    // de_test/wait() calls (from error handler
    // for example) don't destroy the stopinfo
    //
    // drop the lock while we're waiting so
    // de_test() can be called asynchronously
    //
    topo->pids[ONLYPID].nwaiters++;
    DACSPI_TOPO_UNLOCK();

    pthread_join(topo->pids[ONLYPID].pid.pthread_id, NULL);

    DACSPI_TOPO_LOCK();
    topo->pids[ONLYPID].nwaiters--;

    // If we get here, the thread has now terminated
    ASSERT(topo->pids[ONLYPID].status == DACSI_PID_TERM);

    stopinfo = &topo->pids[ONLYPID].stopinfo;

    TRACE_DEBUG(2, GENERAL, TRACE_DEBUG_PPU_PROCESS_16, 
            stopinfo->stop_reason, stopinfo->result.exit_code);

    // DaCS currently reports all abnormal termination of a
    // child generically as ABORTED, so we only report three
    // cases: FINISHED, FAILED, and ABORTED.
    //
    switch (stopinfo->stop_reason) {

        case SPE_EXIT:
            *ret = stopinfo->result.exit_code;

            if (*ret == 0)
                status = DACS_STS_PROC_FINISHED;
            else
                status = DACS_STS_PROC_FAILED;

            break;

        case SPE_STOP_AND_SIGNAL:
        case SPE_RUNTIME_ERROR:
        case SPE_RUNTIME_EXCEPTION:
        case SPE_RUNTIME_FATAL:
        case SPE_CALLBACK_ERROR:
        default:

            *ret = stopinfo->result.exit_code;
            status = DACS_STS_PROC_ABORTED;
            break;

    }

    // decrement active proc count and reset
    // the process info if there are no waiters
    //
    if (topo->pids[ONLYPID].nwaiters == 0) {
        topo->nproc_active--;
        topo->pids[ONLYPID].status = DACSI_PID_INVALID;
        topo->pids[ONLYPID].pid.pthread_id = 0;
        topo->pids[ONLYPID].prog_handle = NULL;
        topo->pids[ONLYPID].flags = 0;
        topo->pids[ONLYPID].entry = 0;
        // leave the stop reason and stop code set for debug
    }

    DACSPI_TOPO_UNLOCK();

    return status;
}

DACS_ERR_T
dacs_ppu_de_test(de_id_t de, dacs_process_id_t pid, int32_t *ret)
{
    return (dacspi_de_test(de, pid, ret, DACS_DE_NOWAIT));
}

DACS_ERR_T
dacs_ppu_de_wait(de_id_t de, dacs_process_id_t pid, int32_t *ret)
{
    return (dacspi_de_test(de, pid, ret, DACS_DE_WAIT));
}

DACS_ERR_T
dacs_ppu_num_processes_running(de_id_t de, uint32_t *num_processes)
{
    dacs_topology_t *topo;
    DACS_ERR_T errcode;

#ifdef DACS_ERROR_CHECKING
    if (!dacsi_is_initialized())
        return DACS_ERR_NOT_INITIALIZED;

    if (num_processes == NULL)
        return DACS_ERR_INVALID_ADDR;
#endif

    topo = dacsi_get_topo(de, &errcode);

#ifdef DACS_ERROR_CHECKING
    if (!topo)
        return DACS_ERR_INVALID_DE;
#endif

    *num_processes = topo->nproc_active;

    return DACS_SUCCESS;
}

DACS_ERR_T
dacs_ppu_de_kill(de_id_t de, dacs_process_id_t pid, DACS_KILL_TYPE_T kill_type)
{
    return DACS_ERR_NOT_SUPPORTED_YET;
}



//  =====   CONSTRUCTOR and DESTRUCTOR

//
// dacspi_process_init only checks if we want to halt in the SPU code if we
// encounter an exception.
//
// DACS_SPE_EXCEPTION_HALT - This environment variable is not published.  It
// is intended to be used as a tool in debugging SPU exceptions.  The default
// is to not have this defined, in which case SPE encountering exceptions will
// simply abort and allow program execution to continue.
//
DACS_ERR_T  dacspi_process_init( void *argvp, void *envp )
{
    if (getenv("DACS_SPE_EXCEPTION_HALT"))
        dacspi_ctx_flags &= ~SPE_EVENTS_ENABLE;

    return  DACS_SUCCESS;
}


//
// dacspi_process_exit
//
// -clean up spe contexts
//
DACS_ERR_T  dacspi_process_exit( void )
{
    dacs_topology_t *topo;
    DACS_ERR_T errcode;
    unsigned int i;

    DACSPI_TOPO_LOCK();
    for (i = 0; i < dacs_tcb.num_children; i++)
    {
        topo = DACSPI_TOPO_CHILD(i);

        // Remove all the contexts we created during init
        if (topo->ctx) {

            // cancel any threads that may exist
            if (topo->pids[ONLYPID].status != DACSI_PID_INVALID) {
                pthread_cancel(topo->pids[ONLYPID].pid.pthread_id);
                pthread_join(topo->pids[ONLYPID].pid.pthread_id, NULL);
                topo->pids[ONLYPID].status = DACSI_PID_INVALID;
                topo->pids[ONLYPID].pid.pthread_id = 0;
            }

            errcode = spe_context_destroy((spe_context_ptr_t)(uintptr_t)topo->ctx);

            // Check if we failed to destroy the context.
            if (errcode) {
                // The possible failures are:
                //      ESRCH  - Our context was invalid, this should not
                //               happen since we zero out invalid contexts.
                //      EFAULT - Something happened in libspe?
                //      EAGAIN - The context is still in use.
                //
                // Note: the current runtime_exit policy is 'force'
                // so we don't actually report this error yet.
                //
                errcode = DACS_ERR_SYSTEM;
            }
            topo->ctx = 0ULL;
        }
    }
    DACSPI_TOPO_UNLOCK();

    return  DACS_SUCCESS;
}

