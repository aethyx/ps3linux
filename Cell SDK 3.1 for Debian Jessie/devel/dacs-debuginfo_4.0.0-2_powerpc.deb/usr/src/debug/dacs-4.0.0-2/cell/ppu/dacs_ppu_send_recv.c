/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

static char *ident = "@(#) internal-src/lib/dacs/cell/ppu/dacs_ppu_send_recv.c v1.49 - 9/16/08 09:55:50 @(#)";

//
// Messaging API's for PPE
//

#include <unistd.h>
#include <stddef.h>
#include <stdlib.h>
#include <dacs_ppe_internal.h>
#include <dacs_ppu_send_recv.h>
#include <dacsi_q.h>
#include <dacs_debug.h>
#include <dacsi_wids.h>
#include <dacs_trace.h>
#include <vec_types.h>
#include <altivec.h>

#ifdef DACS_ERROR_CHECKING
// Starting job id for PPE.  Nonzero for debug
#define DACSPI_START_MSGID 1
// counter for the message id's submitted to jobs Q
uint32_t dacspi_msgid = DACSPI_START_MSGID;
#endif

//  -----   local prototypes    -----
static inline void dacspi_msg_q_lock(uint32_t, uint32_t);
static inline void dacspi_msg_q_unlock(uint32_t, uint32_t);
static inline uint32_t dacspi_remove_Qe(uint32_t, dacsi_msg_type_t, uint32_t);
static inline dacsi_msgQe_t *dacspi_get_local_msg(uint32_t, dacsi_msg_type_t, 
                                                  uint32_t);
static void dacspi_post_remote_msg(dacs_topology_t *, uint32_t, 
                                          dacsi_msgQe_t *);
static inline DACS_ERR_T common_input_check(de_id_t, dacs_process_id_t, void *,
                                      uint32_t, dacs_wid_t, DACS_BYTE_SWAP_T);

//  -----   Globals -----
dacsi_msgQ_lock_t dacspi_msgQ_lock[NUM_SPES_PER_BLADE+1][DACSI_NUM_MSG_TYPE];
dacsi_msgQe_t dacspi_local_msgQ[NUM_SPES_PER_BLADE+1][DACSI_NUM_MSG_TYPE]
                               [DACSI_MAX_MSG_QE];
uint32_t dacspi_remote_msgQ[NUM_SPES_PER_BLADE+1][DACSI_NUM_MSG_TYPE];

const DACS_ERR_T dacspi_msg_success __attribute__((aligned(16))) = DACS_SUCCESS;

DACS_ERR_T 
dacspi_send_recv (void *data, uint32_t len, de_id_t de, dacs_process_id_t pid, 
                  uint32_t stream, dacs_wid_t wid, DACS_BYTE_SWAP_T swap, 
                  dacsi_msg_type_t type)
{
    DACS_ERR_T reterr = DACS_SUCCESS;
    dacs_topology_t *topo = NULL;
    dacsi_wid_elem_t *we;
    dacsi_msgQe_t *msg;
    ALIGNED_DATA(dacspi_msgbuf, dacsi_msgQe_t, 16, sizeof(dacsi_msgQe_t));

    // Initialize our completion message to the global success pointer
    volatile DACS_ERR_T *msgerr = (DACS_ERR_T *)&dacspi_msg_success;

    TRACE_DEBUG(5, MESSAGE, TRACE_DEBUG_PPU_SEND_RECV_1, (unsigned int)de, 
                (unsigned int)pid, wid, data, len);

#ifdef DACS_ERROR_CHECKING
    // Now check for errors that we need to propagate to the other side.
    reterr = common_input_check(de, pid, data, len, wid, swap);

    if (reterr)
        return reterr;
#endif

    // Fetch the topology struct for the source de
    // Don't overwrite previously encountered errors
    topo = dacsi_get_topo(de, &reterr);
    if (!topo) {
        return DACS_ERR_INVALID_DE;
    }

#ifdef DACS_ERROR_CHECKING
    if (topo->reservation != DACSI_TOPO_RESERVED)
        return DACS_ERR_INVALID_DE;

    // If this is not the PID matching the DE or we have DE waited 
    // on the PID, then it is invalid.
    if ((pid != TOPO_PID_TO_PROCESS_ID(topo,ONLYPID)) ||
        (topo->pids[ONLYPID].status == DACSI_PID_INVALID))
        return DACS_ERR_INVALID_PID;
#endif

    dacspi_msg_q_lock(topo->my_index, type);

    we = dacspi_we_alloc();
    if (!we) {
        dacspi_msg_q_unlock(topo->my_index, type);
        return DACS_ERR_NO_RESOURCE;
    }

    msg = dacspi_get_local_msg(topo->my_index, type, stream);

    // No match!!  We need to start things by posting the first half of the
    // transaction in the remote queue.
    if (!msg) {
        // Ok, we have a wid element, fill out our message details to post on
        // the other end. 
        msg = dacspi_msgbuf;
        msg->ms = (uintptr_t)data;
        msg->len = len;
        msg->stream = stream;
#ifdef DACS_ERROR_CHECKING
        msg->msgid = dacspi_msgid++;
#endif
        msg->status_addr = (uintptr_t)we;

        dacspi_post_remote_msg(topo, type, msg);

        ASSERT(!dacspi_get_local_msg(topo->my_index, type, stream));

        we->status = DACS_ERR_WID_ACTIVE;
    }

    // Otherwise, the other participant has already posted a matching message
    // request, so we can use it to initiate the DMA.
    else {
        uint32_t ls = msg->ls;

        we->status = DACS_SUCCESS;

        // Check that the receive buffer is large enough.
        // If not we must fail the pending job
        if ((type == DACSI_MSG_RECV && len < msg->len) ||
            (type == DACSI_MSG_SEND && len > msg->len)) {
            TRACE_DEBUG(2, MESSAGE, TRACE_DEBUG_PPU_SEND_RECV_4, len, msg->len);
            we->status = DACS_ERR_BUF_OVERFLOW;
        }
        else if (!dacsi_is_dma_aligned(ls, (uintptr_t)data, len)) {
            TRACE_DEBUG(2, MESSAGE, TRACE_DEBUG_PPU_SEND_RECV_5, msg->ls, data);
            we->status = DACS_ERR_NOT_ALIGNED;
        }

        // It's that time, initiate the DMA and the fenced state update.
        if (!we->status) {
            we->status = DACSPI_DMA((type==DACSI_MSG_RECV) ? MFC_PUT_CMD 
                                                           : MFC_GET_CMD,
                                    topo, ls, (uintptr_t)data, len, 
                                    DACSPI_HWTAG(wid));
        }

        // If we encountered an error at this point, we need to communicate it
        // to the other end of the transaction.  Set our WE status to reflect
        // the error.  We DMA the completion message out of our WE in this
        // case.
        if (we->status)
            msgerr = &we->status;

        // Initiate the state update for the remote participant.  This is what
        // causes the remote participant to break lose from waiting.  This
        // could be a success or failure update.
        reterr = dacspi_aligned_dma(MFC_GETF_CMD, topo, msg->status_addr,
                                    (uintptr_t)msgerr, sizeof(DACS_ERR_T), 
                                    DACSPI_HWTAG(wid));

        // If we got an error on the fenced status update then the other side
        // is probably going to get stuck.  At least set our wait side in
        // error, so we know something bad happened.
        if (!we->status && reterr)
            we->status = reterr;
    }

    // If we get here with a we, then we were either the first in on the 
    // messaging transaction or we were the second and we have an error to
    // report.  Either way, we need to finish setting up and queuing the 
    // wid element.
    // NOTE: We should never get here with an error to return from this call.
    if (we) {
        if (dacsi_waitq[wid].head) {
            dacsi_waitq[wid].tail->next = we;
        }
        else {
            dacsi_waitq[wid].head = we;
        }

        dacsi_waitq[wid].tail = we;

        we->type |= type;

        // At this time we only need the DE in wait, eventually we may also
        // need the pid, but for now down fill it in.
        we->de = de;
#ifdef DACS_ERROR_CHECKING
        we->id = msg->msgid;
#endif
    }

    ASSERT(!dacspi_get_local_msg(topo->my_index, type, stream));

    dacspi_msg_q_unlock(topo->my_index, type);

    return DACS_SUCCESS;
}

//  =====   INTERNAL FUNCTIONS  ========================================
//
static inline void
dacspi_msg_q_lock(uint32_t spe, uint32_t type)
{
    unsigned done = 0;
#ifdef TRACE_PERF_ENABLE
    int miss = -1;
#endif

    TRACE_INTERVAL_TOKEN_ARGUMENT(interval);
    TRACE_INTERVAL_BEGIN(_DACS_HOST_MUTEX_LOCK, interval, 0);

    do {
        if (__lwarx((volatile int *)&dacspi_msgQ_lock[spe][type].lock) == 0)
            done = __stwcx((volatile int *)&dacspi_msgQ_lock[spe][type].lock, 1);
#ifdef TRACE_PERF_ENABLE
        miss++;
#endif
    } while (done == 0);
    __isync();

    TRACE_INTERVAL_END(_DACS_HOST_MUTEX_LOCK, interval, 0, 
                       (uintptr_t)&dacspi_msgQ_lock[spe][type].lock, miss);
}

static inline void
dacspi_msg_q_unlock(uint32_t spe, uint32_t type)
{
     __sync();
     dacspi_msgQ_lock[spe][type].lock = 0;

     TRACE_PERF(_DACS_HOST_MUTEX_UNLOCK, 0, (uintptr_t)&dacspi_msgQ_lock[spe][type].lock);
}

static inline uint32_t
dacspi_remove_Qe(uint32_t spe, dacsi_msg_type_t type, uint32_t idx)
{
    dacsi_msgQ_lock_t *buf = &dacspi_msgQ_lock[spe][type];
    vector unsigned char mask = {-1, -1, -1, -1, -1, -1, -1, -1};
    dacsi_uchar_vector_t shift = {.vec = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}};
    vector unsigned char perm = {1,2,3,4,5,6,7,0};
    dacsi_uchar_vector_t order = {.vec = buf->ppeQ.order.vec};
    unsigned char last = order.elem[idx];

    shift.elem[sizeof(shift)-1] = idx<<3;
    order.vec = vec_sel(order.vec, vec_perm(order.vec, order.vec, perm), 
                    vec_sro(mask, shift.vec));
    order.elem[DACSI_MAX_MSG_QE-1] = last;

    buf->ppeQ.order.vec = order.vec;
    buf->ppeQ.freeidx--;

    return last;
}

dacsi_msgQe_t *
dacspi_get_local_msg(uint32_t spe, dacsi_msg_type_t type, uint32_t stream)
{
    dacsi_msgQ_lock_t *buf = &dacspi_msgQ_lock[spe][type];
    uint32_t i = 0, freeidx = buf->ppeQ.freeidx;
    dacsi_uchar_vector_t order = {.vec = buf->ppeQ.order.vec};
    dacsi_msgQe_t *msgQe = NULL;
    
    ASSERT(freeidx < 8);

    if (!freeidx)
        return NULL;

    if (stream == DACS_STREAM_ALL)
        return &dacspi_local_msgQ[spe][type][dacspi_remove_Qe(spe, type, 0)];

    do {
        if (dacspi_local_msgQ[spe][type][order.elem[i]].stream == DACS_STREAM_ALL || 
            dacspi_local_msgQ[spe][type][order.elem[i]].stream == stream) {
            msgQe = &dacspi_local_msgQ[spe][type][dacspi_remove_Qe(spe,type,i)];
            break;
        }
     } while (++i < freeidx);

    return msgQe;
}

static void
dacspi_post_remote_msg(dacs_topology_t *topo, uint32_t type, dacsi_msgQe_t *msg)
{
    unsigned int status;
    unsigned int spe = topo->my_index;
    unsigned int freeidx = dacspi_msgQ_lock[spe][type].speQ.freeidx++;
    unsigned int off = dacspi_msgQ_lock[spe][type].speQ.order.elem[freeidx] * 
                       sizeof(dacsi_msgQe_t);

    ASSERT(freeidx < 8);
    dacspi_dma_put(topo, dacspi_remote_msgQ[spe][type] + off, msg, 
                   sizeof(*msg), DACSPI_INTERNAL_TAG);
    dacspi_dma_wait(topo, DACSPI_INTERNAL_TAG);
}

static DACS_ERR_T  
common_input_check(de_id_t de, dacs_process_id_t pid, void *data, 
                   uint32_t len, dacs_wid_t wid, DACS_BYTE_SWAP_T swap)
{
    // can't receive a message from yourself
    if (de == dacspi_local_de_id)
        return DACS_ERR_INVALID_TARGET;

    if ((swap != DACS_BYTE_SWAP_DISABLE) &&
        (swap != DACS_BYTE_SWAP_HALF_WORD) &&
        (swap != DACS_BYTE_SWAP_WORD) &&
        (swap != DACS_BYTE_SWAP_DOUBLE_WORD)) 
        return DACS_ERR_INVALID_ATTR;

    if (swap != DACS_BYTE_SWAP_DISABLE)
        return DACS_ERR_NOT_SUPPORTED_YET;

    return DACS_SUCCESS;
}

static inline void
dacsi_init_msgQ_lock()
{
    int i, j, k;
    vector unsigned char order = {0,1,2,3,4,5,6,7};

    for (i = 0; i < NUM_SPES_PER_BLADE+1; i++) {
        for (j = 0; j < 2; j++) {
                dacspi_msgQ_lock[i][j].lock = 0ULL;
                dacspi_msgQ_lock[i][j].ppeQ.freeidx = 0;
                dacspi_msgQ_lock[i][j].speQ.freeidx = 0;
                dacspi_msgQ_lock[i][j].ppeQ.order.vec = vec_splat_u8(0);
                dacspi_msgQ_lock[i][j].speQ.order.vec = vec_splat_u8(0);
                dacspi_msgQ_lock[i][j].ppeQ.order.vec = 
                    vec_or(dacspi_msgQ_lock[i][j].ppeQ.order.vec, order);
                dacspi_msgQ_lock[i][j].speQ.order.vec = 
                    vec_or(dacspi_msgQ_lock[i][j].speQ.order.vec, order);
                for (k = 0; k < DACSI_MAX_MSG_QE; k++)
                    dacspi_local_msgQ[i][j][k].stream = 0;
        }
    }
}

//  =====   CONSTRUCTOR and DESTRUCTOR

DACS_ERR_T 
dacspi_send_recv_init(void *argvp, void *envp)
{
    unsigned int q, spe;

    dacsi_init_msgQ_lock();

    for (spe = 1; spe < NUM_SPES_PER_BLADE+1; spe++) {
        for (q = 0; q < DACSI_NUM_MSG_TYPE; q++) {
            dacs_rcb[spe].remote_msgQ[q] = 
                        (dacs_addr_64_t)(uintptr_t)&dacspi_local_msgQ[spe][q];
            dacs_rcb[spe].msgQ_lock[q] =
                        (dacs_addr_64_t)(uintptr_t)&dacspi_msgQ_lock[spe][q];
        }
    }

#ifdef DACS_ERROR_CHECKING
    dacspi_msgid = DACSPI_START_MSGID;      // reset message id counter
#endif

    return DACS_SUCCESS;
}


// --------------------------------------------------------------------
// "Destructor" for messaging functions
// --------------------------------------------------------------------
DACS_ERR_T  dacspi_send_recv_exit( void )
{
    return  DACS_SUCCESS;
}
