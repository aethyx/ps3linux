/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

// ident = "@(#) internal-src/lib/dacs/cell/common/dacs_internal.h v1.56 - 9/16/08 09:55:46 @(#)"

#ifndef _DACS_INTERNAL_H_
#define _DACS_INTERNAL_H_

//
// Internal definitions common to SPE and PPE
//

#include <pthread.h>
#include <dacs.h>
#include <dacsi_q.h>

// version of the spe and ppe code:
//  must be a 'negative' number so unversioned spu code will 'correctly' fail.
//  0xFFFFFFFF - initial dacs4.0 release in sdk3.1
//  0xFFFFFFFE - <next number>
#define DACSI_VERSION 0xFFFFFFFF

#define likely(_c)     \
    __builtin_expect((_c), 1)

#define unlikely(_c)    \
    __builtin_expect((_c), 0)

// Signature string 'DaCS' to verify correctness of the DaCS Control Block
#define DACS_CB_SIGNATURE   0x44614353

// Generic macro for aligning data on routine stacks.  
// Note: This is only needed as long as the aligned attribute does not work on
//       the stack.
#define ALIGNED_DATA(__name, __type, __align, __size)               \
    unsigned char __name##_data[(__align) + (__size)];              \
    __type *__name =                                                \
      (__type *)((unsigned long)&__name##_data[(__align)] & ~((__align)-1));

#define DACSI_64_TO_32(__addr)  ((unsigned long)(__addr))

#define DACSI_DMA_ALIGN_16 16
#define DACSI_DMA_ALIGN_128 128
#define DACSI_ALIGN_MEMSIZE 4*1024*1024

static int
dacsi_is_dma_aligned(uint32_t ls, dacs_addr_64_t ea, uint32_t size)
{
#if defined(DACS_DMA_NO_UNALIGN) || defined(DACS_DMA_NO_BREAKUP)

    if ((ls & 0xF) != (ea & 0xF))
        return 0;

#if defined(DACS_DMA_NO_BREAKUP)

    // Sizes over 16 bytes must by a multiple of 16
    if ((size >= 16) && (size & 0xF))
        return 0;

        uint32_t power = 0x8;
    if (size < 16) {
        while (!(power & ((uint32_t)size & 0xf))) power >>= 1;
        if ((power != size) || (ls & (power-1)))
            return 0;
    }

#endif

#endif

    return 1;
}

typedef enum dacsi_msg_type
{
#if defined(DACS_PPU)
    DACSI_MSG_SEND = 0,
    DACSI_MSG_RECV = 1,
#else
    DACSI_MSG_RECV = 0,
    DACSI_MSG_SEND = 1,
#endif
    DACSI_NUM_MSG_TYPE
} dacsi_msg_type_t;

//
// PPE->SPE control block entry.  the PPE should set
// this up when it runs dacs_ppu_runtime_init().
// When the spe's are started, they should copy the control block array to
// Local Store.
// \note   The control block array is meant to hold \b static information only.
// \note   The pad declaration at the bottom is supposed to be a portable
//         way to pad the struct out to a multiple of of 16 bytes, to
//         avoid DMA crashes.  The anonymous union currently in use is not
//         as portable, but has the advanwide of actually compiling correctly.
//
typedef struct dacsi_cb
{
    union
    {
        struct
        {
        uint32_t          signature;                    //  0: 'DaCS'
        uint32_t          index;                        //  4: Index of this DE
        de_id_t           de_id;                        //  8: id for this DE
        DACS_DE_TYPE_T    type;                         // 12: type of DE
        dacs_process_id_t pid;                          // 16: process id for
                                                        //     the (static) 
                                                        //     PPE pid
        dacs_addr_64_t remote_msgQ[DACSI_NUM_MSG_TYPE]; // 24: MS addr of the
                                                        //     remote msg Qs
        dacs_addr_64_t msgQ_lock[DACSI_NUM_MSG_TYPE];   // 40: bytes: msg Qs
                                                        //     lock info.
        dacs_addr_64_t errstrlist;                      // 56: mainstore
                                                        //     location of the
                                                        //     list of error
                                                        //     strings.
        DACS_DE_TYPE_T    ptype;                        // 64: parent type
        unsigned int put_align;                         // 68: DMA put alignment                                                               to use.
        };
        unsigned char   pad[128];                       //< pad to 128 bytes
    };
} dacsi_cb_t __attribute__ ((aligned(16)));


//
// "handle" of the ae context.  On cell this maps to an speid, on systemX
// this should map to a pthread id.
//
typedef uint64_t de_handle_t;    // make it big enough to handle anything

//
// Process ID status
//
typedef enum DACSI_PID_STS
{
    DACSI_PID_INVALID='I',          // 'I' pid status is invalid
    DACSI_PID_RUNNING='R',          // 'R' process is running
    DACSI_PID_STOPPED='S',          // 'S' process has stopped
    DACSI_PID_TERM='T',             // 'S' process finished or died
}   DACSI_PID_STS_T;


//
// Descriptor of DE process termination information
// NOTE: This is the same as the libspe2 stopinfo struct and should be kept
//       the same.
//

typedef struct dacs_stop_info
{
    unsigned int stop_reason;
    union { 
        int exit_code; 
        int signal_code; 
        int runtime_error; 
        int runtime_exception; 
        int runtime_fatal; 
        int callback_error; 
        void *__reserved_ptr; 
        unsigned long long __reserved_u64; 
    } result; 
    int spu_status;
} dacs_stop_info_t;

// dacs_process_id_t will point to the address of a variable that contains
// a pid or a pthread_t type
typedef struct dacs_ptid
{                      
    union {                  
#if defined(DACS_PPU)
        pthread_t           pthread_id;                // thread id
#else // SPU - no pthread_t in spu include files
        uint64_t            pthread_id;                // thread id
#endif
        pid_t               pid_id;                    // process id
    };
} dacs_ptid_t;
             
// macros and functions to handle the dacs_process_id_t as a handle
#ifdef DACS_ERROR_CHECKING
#define PROCESS_ID_TO_PTID(_topo,_pid) \
            (dacsi_find_ptid_handle(_topo,_pid)).pthread_id
#else
#define PROCESS_ID_TO_PTID(_topo,_pid) (*((dacs_ptid_t *)(_pid))).pthread_id
#endif

#define TOPO_PID_TO_PROCESS_ID(_topo,_process) \
            (dacs_process_id_t)(uintptr_t)(&((_topo)->pids[_process].pid))

//
// Descriptor of each process running on a de.
//
typedef struct  dacs_topo_pid
{
    dacs_ptid_t         pid;                // process/thread id
    void                *prog_handle;       // program handle
    DACSI_PID_STS_T     status;             // status
    unsigned int        flags;	            // thread flags
    unsigned int        entry;		        // thread PC
    dacs_stop_info_t    stopinfo;	        // context termination info
    unsigned int        nwaiters;           // number of waiters present
    dacs_addr_64_t      argv;               // 8 bytes: argv pointer
    dacs_addr_64_t      envv;               // 8 bytes: argv pointer
} dacs_topo_pid_t;


//
// status of the de_id represented by this topology struct
typedef enum DACSI_TOPO_STS
{
    DACSI_TOPO_INVALID=0x47,        //< 'G' topo status is invalid
    DACSI_TOPO_FREE,                //< 'H' topo is free
    DACSI_TOPO_RESERVED,            //< 'I' topo is reserved
} DACSI_TOPO_STS_T;

//
// Topology tree descriptor.   The topology is considered to be linked to
// the hardware structure, thus the pointer to the runtime control block.
//
// This structure needs to be aligned and sized to accomodate DMAing, so it
// must be aligned on a 16 byte boundary and sized to a mulitple of 16 bytes.
//
typedef struct  dacs_topology
{
    union
    {
        struct
        {
            DACSI_TOPO_STS_T        reservation;    // reserved flag
            uint32_t                my_index;       // my index in the 
                                                    //  parent's children array 
            dacs_addr_64_t          ctx;            // "handle" of the de 
                                                    //  context: speid, 
                                                    //  pthreadid, etc.
            dacsi_cb_t              *cb;            // pointer to control 
                                                    //  block of the current DE.
            struct dacs_topology    *parent;        // ptr to parent topology 
                                                    //  node
            uint32_t                num_peers;      // number of peers
            struct dacs_topology    *peers;         // ptr to array of peer 
                                                    //  topo's
            uint32_t                num_children;   // number of children
            struct dacs_topology    *children;      // ptr to array of children 
                                                    //  topo's
            uint16_t                nproc_supported;
            uint16_t                nproc_active;
            dacs_topo_pid_t         pids[MAX_PROCESSES_PER_DE];
            uint32_t dma_lock;                      // DMA synchronization
            dacs_addr_64_t          mfc_area;       // Problem State - MFC
            dacs_addr_64_t          ctl_area;       // Problem State - Control/mboxes
        };
        unsigned char pad[ 128 ];
    };
}   dacs_topology_t __attribute__ ((aligned(16)));

// Maximum individual DMA size.  All DMAs greater than this must be broken up
// into pieces of MAX size or smaller.
#define MAX_DMA_SIZE 0x4000

//  ===== internal global vars  ========================================
extern  de_id_t     dacspi_local_de_id;          // declared in dacs_*_runtime.c
extern  uint32_t    dacsi_runtime_initialized;  // declared in dacs_*_runtime.c

//  ----- inter-section calls (common functions, spe and ppe)   --------

// -----   runtime
extern  uint32_t           dacsi_is_initialized( void );

//  -----   topology
extern dacs_topology_t *dacsi_find_de( de_id_t de, dacs_topology_t * top );
extern dacs_topology_t *dacsi_get_topo( de_id_t de, DACS_ERR_T *errcode );
extern DACSI_TOPO_STS_T dacsi_check_reservation( de_id_t de );
extern int dacsi_check_children_reservations(dacs_topology_t *de_topo,
                                              DACSI_TOPO_STS_T checkval );
extern int dacsi_check_children_reservations(dacs_topology_t *de_topo,
                                              DACSI_TOPO_STS_T setval );

//  ----- internal debug routines --------------------------------------
extern void dacsi_dump_cb( const char *offset, dacsi_cb_t *cb );
extern void dacsi_dump_topo( const char * offset, dacs_topology_t * t );

extern dacs_ptid_t dacsi_find_ptid_handle(dacs_topology_t *topo,dacs_process_id_t pid);      

#endif  //  _DACS_INTERNAL_H_
