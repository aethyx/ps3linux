/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

// @(#) internal-src/lib/dacs/cell/common/dacsi_q.h v1.12 - 9/16/08 09:55:46 @(#)

#ifndef _DACSI_Q_H_
#define _DACSI_Q_H_

//
//  C++ interface
//
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define DACSI_MAX_MSG_QE 8
typedef struct dacsi_msgQe
{
    union {                        // 0x00: Remote message address
        uint64_t    ms;
        struct {
            uint32_t unused;
            uint32_t ls;
        };
    };
    uint32_t len;                   // 0x08: Remote message length
    uint32_t stream;                // 0x0c: Remote message stream
    uint64_t status_addr;           // 0x10: Remote address to send state upd.
    uint32_t msgid;                 // 0x18: [DEBUG] Remote create Job ID
    uint32_t pad[1];                // 0x1c:
} dacsi_msgQe_t __attribute__((aligned(32)));

typedef union dacsi_uchar_vector
{
    vector unsigned char vec;
    unsigned char elem[16];
} dacsi_uchar_vector_t;

typedef union dacsi_uint_vector
{
    vector unsigned int vec;
    unsigned int elem[4];
} dacsi_uint_vector_t;

typedef struct dacsi_msgQ_info
{
    dacsi_uchar_vector_t order;
    uint32_t freeidx;
    uint32_t pad[3];
} dacsi_msgQ_info_t __attribute__((aligned(16)));

/*
 * This lock structure protects and manages an individual message transaction 
 * between the PPE and an SPE.  This is a SINGLE direction transaction 
 * (ie. PPE send & SPE receive or PPE receive & SPE send).  A pair of these
 * exist for each PPE/SPE combination.
 * This structure contains the lock to synchronize the above transaction.
 * Like a lock, this lock is updated with an atomic operation.  However,
 * unlike a conventional lock, the lock is followed by information needed
 * for managing and using the message queues tied to the transaction.  This
 * takes advantage of the atomic ops use of an entire 128 byte cache line,
 * saving the time to fetch the additional information.  For this reason, this
 * structure must be aligned on a 128 byte boundary and must never exceed 128
 * bytes.
 */
typedef struct dacsi_msgQ_lock
{
    uint32_t lock;                  // 0x00:
    uint32_t pad1[3];               // 0x04:
    dacsi_msgQ_info_t ppeQ;         // 0x10: PPE side queue info
    dacsi_msgQ_info_t speQ;         // 0x30: SPE side queue info
    uint32_t pad2[12];              // 0x50:
} dacsi_msgQ_lock_t __attribute__((aligned(128)));

//
//  C++ interface
//
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif  //  _DACSI_Q_H_
