/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

static char *ident = "@(#) internal-src/lib/dacs/cell/ppu/dacs_ppu_proc_sync.c v1.19 - 9/16/08 09:57:02 @(#)";

#include <dacs_ppe_internal.h>
#include <dacs_ppu_shared_obj.h>
#include <dacs_common.h>
#include <dacs_atomic.h>
#include <dacs_ppu_tags.h>
#include <dacs_ppu_data_sync.h>
#include <dacs_ppu_send_recv.h>
#include <dacs_ppu_proc_sync.h>
#include <dacs_debug.h>

#define dacspi_local_pid 0

DACS_ERR_T dacs_ppu_mutex_share(de_id_t dst_de,
                                dacs_process_id_t dst_pid,
                                dacs_mutex_t mutex)
{
    DACS_ERR_T err = DACS_SUCCESS;
    dacsi_shared_obj_t * obj = (dacsi_shared_obj_t *)(uintptr_t) mutex;

#ifdef DACS_ERROR_CHECKING
    if (dst_de == dacspi_local_de_id && dst_pid == dacspi_local_pid)
        return DACS_ERR_INVALID_TARGET;

    if (!obj || obj->name != DACSI_MUTEX_NAME || 
        obj->owner_de != dacspi_local_de_id)
        return DACS_ERR_INVALID_HANDLE;
#endif

    err = dacspi_ppu_share_obj(dst_de, dst_pid, obj);
 
    return err;
}

DACS_ERR_T dacs_ppu_mutex_accept(de_id_t dst_de,
                                 dacs_process_id_t dst_pid,
                                 dacs_mutex_t *mutex)
{
    // Currently, we do not accept, as there is no support for sharing out 
    // of an SPU
    return DACS_ERR_NOT_SUPPORTED_YET;
}

DACS_ERR_T dacs_ppu_mutex_release (dacs_mutex_t *mutex)
{
    DACS_ERR_T err = DACS_SUCCESS;
    dacsi_shared_obj_t *obj;

#ifdef DACS_ERROR_CHECKING
    if (!mutex)
        return DACS_ERR_INVALID_ADDR;
#endif

    obj = (dacsi_shared_obj_t *)(uintptr_t) *mutex;

#ifdef DACS_ERROR_CHECKING
    if (!obj || obj->name != DACSI_MUTEX_NAME)
        return DACS_ERR_INVALID_HANDLE;
#endif

    err = dacspi_ppu_shared_obj_release(obj);
    *mutex = 0;
    return err;

}


DACS_ERR_T dacs_ppu_mutex_lock( dacs_mutex_t mutex )
{
    DACS_ERR_T err = DACS_SUCCESS;
    dacsi_shared_obj_t *obj = (dacsi_shared_obj_t *)(uintptr_t) mutex;

#ifdef DACS_ERROR_CHECKING
    if (!obj || obj->name != DACSI_MUTEX_NAME)
        return DACS_ERR_INVALID_HANDLE;
#endif

#ifdef TRACE_ENABLED_LIB
    uint32_t miss;
    TRACE_INTERVAL_TOKEN_ARGUMENT(token);
    TRACE_POINT_ENTRY(_DACS_MUTEX_LOCK,token,2,mutex);

    // we want miss count, so first do a try lock and see if that works
    if (dacspi_mutex_trylock((mutex_ea_t)(uintptr_t) &(obj->mutex.lock)) == 1) {
    	miss = 0;
	    TRACE_COUNTER_INCREMENT(dacs_mutex_try_success,1);
    } else {
	    dacspi_mutex_lock((mutex_ea_t)(uintptr_t) &(obj->mutex.lock));
        miss = 1;
	    TRACE_COUNTER_INCREMENT(dacs_mutex_try_failure,1);
    }

    TRACE_POINT_EXIT(_DACS_MUTEX_LOCK,token,2,mutex,miss,DACS_SUCCESS);

#else /* not TRACE */
    dacspi_mutex_lock((mutex_ea_t)(uintptr_t) &(obj->mutex.lock));
#endif

#ifdef DACS_ERROR_CHECKING
    obj->mutex.lock_de  = dacspi_local_de_id;
    obj->mutex.lock_pid = dacspi_local_pid;
#endif
    
    return DACS_SUCCESS;
}

DACS_ERR_T dacs_ppu_mutex_try_lock( dacs_mutex_t mutex )
{
    DACS_ERR_T err = DACS_SUCCESS;
    dacsi_shared_obj_t *obj = (dacsi_shared_obj_t *)(uintptr_t) mutex;

#ifdef DACS_ERROR_CHECKING
    if (!obj || obj->name != DACSI_MUTEX_NAME)
        return DACS_ERR_INVALID_HANDLE;
#endif

    if( dacspi_mutex_trylock((mutex_ea_t)(uintptr_t) &(obj->mutex.lock)))
    {
#ifdef DACS_ERROR_CHECKING
        obj->mutex.lock_de  = dacspi_local_de_id;
        obj->mutex.lock_pid = dacspi_local_pid;
#endif
	    TRACE_COUNTER_INCREMENT(dacs_mutex_try_success,1);
    }
    else
    {
        err = DACS_ERR_MUTEX_BUSY;
	    TRACE_COUNTER_INCREMENT(dacs_mutex_try_failure,1);
    }

    return err;
}

DACS_ERR_T dacs_ppu_mutex_unlock (  dacs_mutex_t mutex )
{
    dacsi_shared_obj_t * obj = (dacsi_shared_obj_t *)(uintptr_t) mutex;

#ifdef DACS_ERROR_CHECKING
    if (!obj || obj->name != DACSI_MUTEX_NAME)
        return DACS_ERR_INVALID_HANDLE;

    if ((obj->mutex.lock_de  != dacspi_local_de_id)|| 
        (obj->mutex.lock_pid != dacspi_local_pid))    
        return DACS_ERR_NO_PERM;

    obj->mutex.lock_de = 0;
    obj->mutex.lock_pid = 0;
#endif

    dacspi_mutex_unlock((mutex_ea_t)(uintptr_t) &(obj->mutex.lock));

    return DACS_SUCCESS;
}

//  =====   CONSTRUCTOR and DESTRUCTOR

DACS_ERR_T  dacspi_proc_sync_init(  void *argvp,    void *envp )
{
    return  DACS_SUCCESS;
}

DACS_ERR_T  dacspi_proc_sync_exit(  void )
{
    return  DACS_SUCCESS;
}
