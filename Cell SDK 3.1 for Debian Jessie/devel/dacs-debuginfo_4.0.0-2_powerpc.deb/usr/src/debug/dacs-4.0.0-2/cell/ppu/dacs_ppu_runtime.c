/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

static char *ident = "@(#) internal-src/lib/dacs/cell/ppu/dacs_ppu_runtime.c v1.50 - 9/16/08 09:55:50 @(#)";

//
// Runtime initialization for PPE
//

#include    <unistd.h>
#include    <stdio.h>
#include    <string.h>
#include    <dacs_ppe_internal.h>
#include    <dacs_debug.h>
#include    <dacs_error_internal.h>
#include    <dacs_ppu_runtime.h>
#include    <dacs_trace.h>

//
//  add all the detailed function descriptions to the PPE LLD
//  Note that REPEAT_BRIEF is on in the Doxyfile, so the @brief descriptions
//  in the .h file will be prepended to these detailed descriptions - no need
//  to repeat them here.
//

//  -----   local prototypes    -----
static void set_spe_cb_entry(uint32_t, de_id_t, DACS_DE_TYPE_T, DACS_DE_TYPE_T);


//  -----   Globals ----------------------------------------------------
// The local de_id of the PPE
de_id_t     dacspi_local_de_id = NULL_DE_ID;

// Worst case scenario is we will force alignment to a cache line (128 byte).
// If the penalty is lower we'll adjust the alignment restriction later.
unsigned int dacsi_put_align = DACSI_DMA_ALIGN_128;

//
// flag showing that dacs_runtime_init() has been run
uint32_t   dacsi_runtime_initialized    =   0;      // init to FALSE

//
// Runtime Control Block array for PPE and its' children.
// Index 0 is reserved for PPE, indices 1-N are reserved for
// the SPE's.
// Since the PPE can be configured as either DACS_DE_BLADE (16 spe's),
// or DACS_DE_CBE (with 8 spe's), we will allocate the maximum size
// here.
// This block should only be used for \b static information
// since it will be downloaded \b once during dacs_runtime_init.
//
dacsi_cb_t   dacs_rcb[1+NUM_SPES_PER_BLADE] __attribute__ ((aligned (128)));

//
// PPU Runtime Initialization
// This initializes the DaCS "interface" with the
// children DE's
// dacs_hybrid_runtime_init() should have run already and found out who and
// what we are.
//
// We check here to see what our DE type is.
// If it's DACS_DE_CBE, we own 8 spe's, if it's DACS_DE_BLADE, we own all 16.
// (8 and 16 are the values of NUM_SPES_PER_CBE/NUM_SPES_PER_BLADE of course)
//
DACS_ERR_T  dacs_ppu_init(void *argvp, void *envp, de_id_t *de_to_pass, 
                          dacs_process_id_t *pid_to_pass)
{
    int   i                 =   0;
    FILE *fd;
    DACS_DE_TYPE_T  my_type =   DACS_DE_INVALID;
    DACS_ERR_T  err_code    =   DACS_SUCCESS;

#ifdef DACS_ERROR_CHECKING
    if(dacsi_runtime_initialized)
    {
        TRACE_DEBUG(0, GENERAL, TRACE_DEBUG_PPU_RUNTIME_1, );
        return DACS_ERR_INITIALIZED;
    }
#endif

    TRACE_DEBUG(2, GENERAL, TRACE_DEBUG_PPU_RUNTIME_2, 
                de_to_pass ? *de_to_pass : 0, pid_to_pass ? *pid_to_pass : 0);
    dacspi_local_de_id = *de_to_pass;      // store local copy

    //  parse our de to determine if we're a blade or a CBE
    if ((dacspi_local_de_id & 0x0000FF00) != 0)
    {
        my_type = DACS_DE_CBE;
    }
    else if((dacspi_local_de_id & 0x00FF0000) != 0 )
    {
        my_type = DACS_DE_CELL_BLADE;
    }

    // Examine the memory config.  Certain memory configurations perform
    // better aligned to 128 byte boundaries.  Check if this is necessarily
    // the case.
    fd = fopen("/proc/meminfo", "r");
    if (fd) {
        unsigned int memsize = 0;
        char label[16];
        int rdcnt = fscanf(fd, "%s %d kb", label, &memsize);

        // The above assumes that the first line of /proc/meminfo is the total
        // memory size.  If not, then we don't adjust the alignment.
        if (rdcnt == 2 && !strcmp(label, "MemTotal:")) {
                int cpucnt = spe_cpu_info_get(SPE_COUNT_PHYSICAL_CPU_NODES, -1);
                // If we have less than 4GB per CPU (4194304k), then we can
                // force alignment at 16 bytes with little impact.
                if (memsize/cpucnt < DACSI_ALIGN_MEMSIZE)
                        dacsi_put_align = DACSI_DMA_ALIGN_16;
        }

        fclose(fd);
    }

    //
    // File in the PPD control block entry
    //
    TRACE_DEBUG(0, GENERAL, TRACE_DEBUG_PPU_RUNTIME_3, );

    set_spe_cb_entry(0, dacspi_local_de_id, my_type, 0);

    TRACE_DEBUG(0, GENERAL, TRACE_DEBUG_PPU_RUNTIME_4, );

    //
    //  Fill in SPE control blocks
    //
    for (i = 1; i < (NUM_SPES_PER_BLADE)+1; i++ )
    {
        set_spe_cb_entry(i, (dacspi_local_de_id+i), DACS_DE_SPE, my_type);
    }

    //
    //  initialize all ppe modules
    //
    TRACE_DEBUG(0, GENERAL, TRACE_DEBUG_PPU_RUNTIME_5, );
    err_code = dacspi_topology_init(argvp,envp);

    if ( err_code != DACS_SUCCESS ) {
        TRACE_DEBUG(1, GENERAL, TRACE_DEBUG_PPU_RUNTIME_6, err_code);
        // don't update if failure
        return err_code;
    }
    if (pid_to_pass != NULL) {
       DACS_ERR_T rc2 = DACS_SUCCESS;
       dacs_topology_t * topo = dacsi_get_topo(dacspi_local_de_id, &rc2);
       topo->pids[ONLYPID].pid.pid_id = getpid();                                            
       *pid_to_pass = TOPO_PID_TO_PROCESS_ID(topo,ONLYPID);
       TRACE_DEBUG(3, GENERAL,TRACE_DEBUG_PPU_RUNTIME_7, 
                   topo->pids[ONLYPID].pid.pid_id, &(topo->pids[ONLYPID].pid), 
                   *pid_to_pass);
    }                                                                                        
    // else someone (hybrid) already set this to it's own value                              

    //  set up process control
    if ( err_code == DACS_SUCCESS ) {
        TRACE_DEBUG(0, GENERAL, TRACE_DEBUG_PPU_RUNTIME_8, );
        err_code = dacspi_process_init( argvp,envp );
    }

    //  set up dacs groups structures
    if ( err_code == DACS_SUCCESS ) {
        TRACE_DEBUG(0, GENERAL, TRACE_DEBUG_PPU_RUNTIME_9, );
        err_code = dacspi_groups_init( argvp,envp );
    }       
    
    //  set up dacs shared object structures
    if ( err_code == DACS_SUCCESS ) {
        TRACE_DEBUG(0, GENERAL, TRACE_DEBUG_PPU_RUNTIME_10, );
        err_code = dacspi_shared_obj_init( argvp,envp );
    }

    //  set up dacs tags structures
    if ( err_code == DACS_SUCCESS ) {
        TRACE_DEBUG(0, GENERAL, TRACE_DEBUG_PPU_RUNTIME_11, );
        err_code = dacspi_tags_init( argvp,envp );
    }

    //  set up mailbox queues
    if ( err_code == DACS_SUCCESS ) {
        TRACE_DEBUG(0, GENERAL, TRACE_DEBUG_PPU_RUNTIME_12, );
        err_code = dacspi_mailbox_init( argvp,envp );
    }

    //  set up messaging
    if ( err_code == DACS_SUCCESS ) {
        TRACE_DEBUG(0, GENERAL, TRACE_DEBUG_PPU_RUNTIME_13, );
        err_code = dacspi_send_recv_init( argvp,envp );
    }

    //  set up data sync
    if ( err_code == DACS_SUCCESS ) {
        TRACE_DEBUG(0, GENERAL, TRACE_DEBUG_PPU_RUNTIME_14, );
        err_code = dacspi_data_sync_init( argvp,envp );
    }

    //  set up process sync
    if ( err_code == DACS_SUCCESS ) {
        TRACE_DEBUG(0, GENERAL, TRACE_DEBUG_PPU_RUNTIME_15, );
        err_code = dacspi_proc_sync_init( argvp,envp );
    }

    //  set up dma / windowing
    if ( err_code == DACS_SUCCESS ) {
        TRACE_DEBUG(0, GENERAL, TRACE_DEBUG_PPU_RUNTIME_16, );
        err_code = dacspi_dma_init( argvp,envp );
    }

    // set runtime flag to true
    if ( err_code == DACS_SUCCESS )
        dacsi_runtime_initialized = 1;
     
    // If we had an error, we need to clean things up
    if (err_code != DACS_SUCCESS)
        dacs_ppu_exit();

    /*  end critical section */

    return err_code;
}

//
//  Wrapper for PPU runtime exit.
//
DACS_ERR_T  dacs_ppu_exit( void )
{
    DACS_ERR_T  err_code  =   DACS_SUCCESS;

    /* critical section */

    // What ?!?!? We're not even initialized.  Return an error.
    if (!dacsi_runtime_initialized)
        return DACS_ERR_NOT_INITIALIZED;

    //  - terminate all ppe modules
    err_code = dacspi_dma_exit(   );          //  set up dma / windowing
    if ( err_code != DACS_SUCCESS ) {  return ( err_code );    }
    err_code = dacspi_proc_sync_exit(   );    //  set up process sync
    if ( err_code != DACS_SUCCESS ) {  return ( err_code );    }
    err_code = dacspi_data_sync_exit(   );    //  set up data sync
    if ( err_code != DACS_SUCCESS ) {  return ( err_code );    }
    err_code = dacspi_send_recv_exit(   );    //  set up messaging
    if ( err_code != DACS_SUCCESS ) {  return ( err_code );    }
    err_code = dacspi_mailbox_exit(   );      //  set up mailbox queues
    if ( err_code != DACS_SUCCESS ) {  return ( err_code );    }
    err_code = dacspi_shared_obj_exit(   );   // close down shared_objs
    if ( err_code != DACS_SUCCESS ) {  return ( err_code );    }
    err_code = dacspi_tags_exit(   );         //  set up dacs tags structures
    if ( err_code != DACS_SUCCESS ) {  return ( err_code );    }
    err_code = dacspi_groups_exit(   );       //  set up dacs groups structures
    if ( err_code != DACS_SUCCESS ) {  return ( err_code );    }
    err_code = dacspi_process_exit(   );      //  set up process control
    if ( err_code != DACS_SUCCESS ) {  return ( err_code );    }
    err_code = dacspi_topology_exit( );
    if ( err_code != DACS_SUCCESS ) {   return ( err_code );    }

    // set runtime flag back to false 
    // "Unit Test exited abnormally (status: b)!")
    dacsi_runtime_initialized    =   0;      

    /* end critical section */

    return  DACS_SUCCESS;
}


//  ====================    PRIVATE ROUTINES    ========================


//  ----- PPE->SPE  runtime --------------------------------------------

void 
dacsi_dump_cb( const char *offset, dacsi_cb_t *cb )
{
    if ( cb == NULL )   { return;   }   // sanity check

    TRACE_DEBUG(1, GENERAL,TRACE_DEBUG_PPU_RUNTIME_17, cb);
    TRACE_DEBUG(1, GENERAL,TRACE_DEBUG_PPU_RUNTIME_18, (uint32_t)cb->de_id);
    TRACE_DEBUG(1, GENERAL,TRACE_DEBUG_PPU_RUNTIME_19, (uint32_t)cb->type);
}

static void 
set_spe_cb_entry(uint32_t index, de_id_t de_id, DACS_DE_TYPE_T type,
                 DACS_DE_TYPE_T ptype)
{
    dacs_rcb[index].signature   =   DACS_CB_SIGNATURE;
    dacs_rcb[index].index       =   index;
    dacs_rcb[index].de_id       =   de_id;
    dacs_rcb[index].type        =   type;
    dacs_rcb[index].ptype       =   ptype;
    dacs_rcb[index].errstrlist  =   (dacs_addr_64_t)dacsi_error_strings;
    dacs_rcb[index].put_align   =   dacsi_put_align;
}

                                                                                               
dacs_ptid_t dacsi_find_ptid_handle(dacs_topology_t *topo, dacs_process_id_t pid)             
{                                                                                            
    uint32_t i;                                                                              
    dacs_ptid_t ptid;                                                                        
                                                                                             
    ptid.pid_id = 0;                                                                         
                                                                                             
    /* look through all of the pids to find on that matches */                               
//    for (i=0;i<MAX_PROCESSES_PER_DE;i++)                                                   
// for now, there's only 1 process per de                                                    
      {                                                                                      
        i = ONLYPID;                                                                         
        if (TOPO_PID_TO_PROCESS_ID(topo,i) == pid)                                           
           return topo->pids[i].pid;                                                         
    } /* for */                                                                              
                                                                                             
    return ptid;                                                                             
}                                                                                            
