/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef __ALF_DEF_H_INC__
#define __ALF_DEF_H_INC__

/*
 ************************************************************
 * ALF Shared header
 ************************************************************
 */

/**
ALF_DATA_TYPE_T;
This enumeration type defines the data types that will be considered during the data movements between the control node and accelerator nodes.  The ALF runtime shall doing byte swapping on the fly when moving data if the endianess of control node and accelerator nodes are different.
Notes: last byte of each type indicate the size of the type, please follow this rule when you add or modify it! 
*/
typedef enum _ALF_DATA_TYPE_T_ {
  ALF_DATA_BYTE = 0x01,         // For data types that are independent of byte orders
  ALF_DATA_INT16 = 0x02,        // For two bytes signed / unsigned integer types
  ALF_DATA_INT32 = 0x04,        // For four bytes signed / unsigned integer types
  ALF_DATA_INT64 = 0x08,        // For eight bytes signed / unsigned integer types
  ALF_DATA_FLOAT = 0x104,        // For four bytes float point types
  ALF_DATA_DOUBLE = 0x108,       // For eight bytes float point types
  ALF_DATA_ADDR32 = 0x204,       // 32 bit pointer
  ALF_DATA_ADDR64 = 0x208,       // 64 bit pointer
} ALF_DATA_TYPE_T;

/* Accelerator Management Policy */
typedef enum _ALF_ACCEL_RESV_POLICY_T_ {
  ALF_ACCEL_RESV_POLICY_PERSIST = 0xA000,
  ALF_ACCEL_RESV_POLICY_COMPROMISE = 0xA001,
  ALF_ACCEL_RESV_POLICY_TRY = 0xA002,
} ALF_ACCEL_RESV_POLICY_T;



/* working block type */
typedef enum _ALF_WORK_BLOCK_TYPE_T_ {
  ALF_WB_SINGLE = 0,            // single call working block
  ALF_WB_MULTI = 1,             // repeater working block
} ALF_WORK_BLOCK_TYPE_T;

// sync point type
typedef enum _ALF_SYNC_TYPE_T_
{
    ALF_SYNC_BARRIER = 0,   
    ALF_SYNC_NOTIFY = 1,
} ALF_SYNC_TYPE_T;

// error handling policy
typedef enum _ALF_ERR_POLICY_T_ {
  ALF_ERR_POLICY_IGNORE = 0,    //  the ALF runtime should ignore the error and continue.
  ALF_ERR_POLICY_RETRY = 1,     //  the ALF runtime should retry the operation that caused the error.
  ALF_ERR_POLICY_SKIP = 2,      //  the ALF runtime should skip the operation that caused the error
  ALF_ERR_POLICY_ABORT = -1     //  the ALF runtime must abort the operations and shutdown.
} ALF_ERR_POLICY_T;

// global error type info
typedef enum _ALF_ERR_TYPE_T_ {
  ALF_ERR_WARNING = 0,          //  we may choose to continue by ignoring the error
  ALF_ERR_EXCEPTION = 1,        //  we may choose to retry or skip current operation
  ALF_ERR_FATAL = 2             //  we can not continue, the framework has to shutdown.
} ALF_ERR_TYPE_T;

/*
 * this typedef is for the in/out buffer to differentiate between the two
 * sections within the in/out buffer
 */
typedef enum _ALF_BUF_TYPE_T_ {
  ALF_BUF_IN,          /* input buffer */
  ALF_BUF_OUT,         /* output buffer */
  ALF_BUF_OVL_IN,      /* I/O buffer input */
  ALF_BUF_OVL_OUT,     /* I/O buffer output */
  ALF_BUF_OVL_INOUT,   /* I/O buffer in and out */
} ALF_BUF_TYPE_T;

typedef enum ALF_DATASET_ACCESS_MODE {
  ALF_DATASET_READ_ONLY = 0,
  ALF_DATASET_WRITE_ONLY = 1,
  ALF_DATASET_READ_WRITE = 2,
  ALF_DATASET_NO_READ_WRITE = 3,
} ALF_DATASET_ACCESS_MODE_T;

typedef enum _ALF_ACCEL_TYPE_T_ {
  ALF_ACCEL_TYPE_SPE = 0,
  ALF_ACCEL_TYPE_EDP = 1,
} ALF_ACCEL_TYPE_T;

#define ALF_NULL_HANDLE (0x0)

#define ALF_STRING_TOKEN_MAX	251     // maximum length of string tokens

#define ALF_DATASET_BUFFER_MAX_NUM     8 

typedef unsigned char alf_data_byte_t;
typedef unsigned short alf_data_uint16_t;
typedef signed short alf_data_int16_t;
typedef unsigned int alf_data_uint32_t;
typedef signed int alf_data_int32_t;
typedef unsigned long long alf_data_uint64_t;
typedef signed long long alf_data_int64_t;
typedef unsigned int alf_data_addr32_t;
typedef unsigned long long alf_data_addr64_t;




#endif
