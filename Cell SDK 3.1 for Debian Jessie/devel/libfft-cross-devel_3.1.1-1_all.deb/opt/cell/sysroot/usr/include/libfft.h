/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2008       All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

#ifndef _LIB_FFT_H_
#define _LIB_FFT_H_	1


#define FFT_DOUBLE_PRECISION    0x001
#define FFT_INPUT_REAL          0x002
#define FFT_OUTPUT_REAL         0x004
#define FFT_TILED               0x008
#define FFT_TILE_TO_RECTANGULAR 0x010

#define FFT_TYPE_C2C            0x020
#define FFT_TYPE_R2C            0x040
#define FFT_TYPE_C2R            0x080

#define FFT_ARRAY_OF_ROWS       0x100

#define FFT_RC_SUCCESS        0
#define FFT_RC_NO_SPUS       -1
#define FFT_RC_BAD_DIMENSION -2
#define FFT_RC_NO_INVERSE    -3
#define FFT_RC_BAD_PARM      -4
#define FFT_RC_FAILED        -5
#define FFT_RC_NOT_IMPLEMENTED -6
#define        MAXINT          INT_MAX
#define E_TAG_RESERVE -7


typedef void *fft_2d_sqp2_handle_t;

#ifdef __powerpc64__
	typedef unsigned long long fft_addr_t;
#else
	typedef unsigned int fft_addr_t;
#endif


void tiler_SP(float *source, float *dest, unsigned int xdim, unsigned int ydim);
void untiler_SP(float *source, float *dest, unsigned int xdim, unsigned int ydim);
int fft_2d_sqp2_transform_format(void *in, void *out, unsigned int x_elems, unsigned int y_elems, unsigned int flags);


typedef unsigned int fft_handle_t;


int fft_1d_sp_initialize(fft_handle_t *handle,unsigned int nspus);
int fft_1d_sp_perform(fft_handle_t handle, unsigned int n_arrays, unsigned int num_elems, void **src_addr, void **dst_addr, unsigned int inverse_flag, unsigned int format_flag);
int fft_1d_sp_terminate(fft_handle_t handle);

typedef unsigned int fft_2d_handle_t;


int fft_2d_sp_initialize(fft_2d_handle_t *handle, unsigned int nspus);
int fft_2d_sp_perform(fft_2d_handle_t handle, unsigned int xdim, unsigned int ydim, void **src_addr, void **dst_addr, unsigned int inverse_flag, unsigned int format_flag);
int fft_2d_sp_terminate(fft_2d_handle_t handle);

int fft_2d_dp_initialize(fft_2d_handle_t *handle, unsigned int nspus);
int fft_2d_dp_perform(fft_2d_handle_t handle, unsigned int xdim, unsigned int ydim, void **src_addr, void **dst_addr,  unsigned int inverse_flag, unsigned int format_flag);
int fft_2d_dp_terminate(fft_2d_handle_t handle);


#endif /* _LIB_FFT_H_ */
