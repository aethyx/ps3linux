/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include "alf_host.h"
#include "libmisc.h"
#include <string.h>

void *alf_wbpool_group_create(unsigned int wb_size, unsigned int align)
{
  alf_wb_group *grp = calloc(1,sizeof(alf_wb_group));

  if( grp == NULL)
  {
    return NULL;
  }
  
  grp->wb_array = calloc_align(_ALF_WB_GRP_CAP,
                               _ALF_SIZE_ALIGN_(wb_size,align),align); 
  if(grp->wb_array == NULL)
  {
    free(grp);
    return NULL;
  }

  grp->wb_size = _ALF_SIZE_ALIGN_(wb_size,align);

  return grp;
}
void alf_wbpool_group_destroy(alf_wb_group* grp)
{
  if(grp == NULL) return;

  if(grp->wb_array != NULL)
    free_align(grp->wb_array);
 
  free(grp);

}
void *alf_wbpool_group_alloc(alf_wb_group *grp)
{  
  void *wb_ptr;
  //find free wb
  if(grp->dirty_num < _ALF_WB_GRP_CAP) 
  {
    wb_ptr =  grp->wb_array + grp->wb_size * grp->dirty_num;
    grp->dirty_num ++;
    return wb_ptr;
  } 
  else return NULL;
}
int alf_wbpool_group_cleanup(alf_wb_group *grp)
{
  if(grp == NULL) return -1;

  alf_api_wb_t *wb;
  int i;
  //start from last unfinished wb for efficiency
  int start = _ALF_WB_GRP_CAP-grp->dirty_num;

  for(i=start;i<_ALF_WB_GRP_CAP;i++)
  {
    wb =  grp->wb_array + grp->wb_size * i;
   
    //assume FIFO for simplicity 
    if(wb->status == _ALF_API_WB_STATUS_FIN)
      grp->dirty_num--; 
    else break;
  }

  if(grp->dirty_num == 0)
  {
    //can be optimized to wb initialization
    memset(grp->wb_array, 0, _ALF_WB_GRP_CAP * grp->wb_size);
  }

  return grp->dirty_num;  
}
void *alf_wbpool_create(unsigned int wb_size, unsigned int align)
{
  alf_wb_pool *pool = NULL;

  if(wb_size <= 0 || align <= 0) return NULL;
  
  pool = calloc(1,sizeof(alf_wb_pool));

  if(pool == NULL) return NULL;

  pool->wb_size = wb_size;   
  pool->align = align;

  pthread_mutex_init(&pool->lock,NULL);

  return pool;  
}
void alf_wbpool_destroy(alf_wb_pool* pool)
{
  //destroy cur grp
  alf_wbpool_group_destroy(pool->cur_grp);
  
  //destroy dirty grp
  alf_wb_group *next;

  alf_wb_group *grp = pool->first_dirty;

  while(grp != NULL)
  {
    next = grp->next;

    alf_wbpool_group_destroy(grp);
    
    grp = next;

  }

  pthread_mutex_destroy(&pool->lock);
 
  //itself 
  free(pool);

}

void *alf_wbpool_alloc_wb(alf_wb_pool *pool)
{
  void *wb_ptr;
  alf_wb_group* grp;

  pthread_mutex_lock(&pool->lock);
  //create cur wb grp
  if( pool->cur_grp == NULL)
  {
    pool->cur_grp = alf_wbpool_group_create(pool->wb_size,pool->align);
    if(pool->cur_grp == NULL)
    {
      pthread_mutex_unlock(&pool->lock);
      return NULL;
    }
  }


  if( ( wb_ptr = alf_wbpool_group_alloc(pool->cur_grp) ) != NULL)
  {
    pthread_mutex_unlock(&pool->lock);
    return wb_ptr;
  }

  grp = pool->cur_grp;
  //wb in cur grp used up  
  alf_wb_group *free_grp = NULL;
  if(alf_wbpool_group_cleanup(pool->first_dirty)!=0)
  {
    free_grp = alf_wbpool_group_create(pool->wb_size,pool->align);
    if(free_grp == NULL)
    {
      pthread_mutex_unlock(&pool->lock);
      return NULL;
    }

    if( pool->first_dirty == NULL )
    {
      pool->first_dirty = grp;
    }
    else
    {
      pool->last_dirty->next = grp;
    }
    pool->last_dirty = grp;

    pool->cur_grp = free_grp;
  
    //should not fail! 
    wb_ptr = alf_wbpool_group_alloc(pool->cur_grp);
    pthread_mutex_unlock(&pool->lock);
    return wb_ptr;
 
  } 
  else
  {
    free_grp = pool->first_dirty;
    if( free_grp->next != NULL )
    {
      pool->first_dirty = free_grp->next;
      pool->last_dirty->next = grp;
      pool->last_dirty = grp;
    }
    else 
    {
      pool->first_dirty = grp;
      pool->last_dirty = grp;
    }
 
    pool->cur_grp = free_grp;
    free_grp->next = NULL;
    
    //should not fail! 
    wb_ptr = alf_wbpool_group_alloc(pool->cur_grp);
    pthread_mutex_unlock(&pool->lock);
    return wb_ptr;
 
  }

}
void alf_wbpool_free_wb(void *wb_ptr)
{
  alf_api_wb_t* wb;
  if(wb_ptr ==NULL) 
    return;

  wb = (alf_api_wb_t*) wb_ptr;

  wb->status = _ALF_API_WB_STATUS_FIN;
 
}
