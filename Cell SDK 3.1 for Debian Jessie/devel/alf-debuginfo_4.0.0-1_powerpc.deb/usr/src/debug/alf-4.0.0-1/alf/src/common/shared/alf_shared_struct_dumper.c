/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include <stdio.h>

#include <alf.h>
#include <alf_host.h>
//#include "alf_common.h"




#define dump_head_printf(struct_name,func,file,line) {			\
    if(_pad == 0)							\
    {									\
      fprintf(stdout,"[%s] %s decode (%s, %s:%d)\n",_ALF_PLATFORM_STRING,struct_name,func,file,line); fflush(stdout); \
    }									\
  }

#define dump_printf(fmt, arg...) {					\
    fprintf(stdout,"[%s]      %*"  "s" fmt,_ALF_PLATFORM_STRING, _pad, "", ##arg); }

const char *_ALF_API_STATE_TYPE_T_tostring(ALF_API_STATE_TYPE_T state)
{
  switch (state) {
  case ALF_API_STATUS_RUNNING:
    return "RUNNING";

  case ALF_API_STATUS_EXITING:
    return "EXITING";

  case ALF_API_STATUS_EXITED:
    return "EXITED";

  default:
    return "(unknown)";
  }
}

const char *_ALF_EXIT_POLICY_T_tostring(ALF_EXIT_POLICY_T p)
{
  switch (p) {
  case ALF_EXIT_POLICY_FORCE:
    return "FORCE";

  case ALF_EXIT_POLICY_WAIT:
    return "WAIT";

  case ALF_EXIT_POLICY_TRY:
    return "TRY";

  default:
    return "(unknown)";
  }

}

void _dump_pthread_mutex_t(pthread_mutex_t m, const char *func, const char *file, int line, int _pad)
{
  dump_head_printf("pthread_mutex_t", func, file, line);

  dump_printf("  lock  : %d\n", m.__data.__lock);
  dump_printf("  count : %u\n", m.__data.__count);
  dump_printf("  owner : %d\n", m.__data.__owner);
#if __WORDSIZE == 64
  dump_printf("  nusers: %u\n", m.__data.__nusers);
#endif
  dump_printf("  kind  : %d\n", m.__data.__kind);
#if __WORDSIZE == 64
  dump_printf("  spins : %d\n", m.__data.__spins);
  dump_printf("  list  : { prev*: %p, next*: %p }\n", m.__data.__list.__prev, m.__data.__list.__next);
#else
  dump_printf("  nusers: %u\n", m.__data.__nusers);
#endif


}

void _dump_pthread_cond_t(pthread_cond_t c, const char *func, const char *file, int line, int _pad)
{
  dump_head_printf("pthread_cond_t", func, file, line);

  dump_printf("  lock         : %d\n", c.__data.__lock);
  dump_printf("  futex        : %u\n", c.__data.__futex);
  dump_printf("  total_seq    : %llu\n", c.__data.__total_seq);
  dump_printf("  wakeup_seq   : %llu\n", c.__data.__wakeup_seq);
  dump_printf("  woken_seq    : %llu\n", c.__data.__woken_seq);
  dump_printf("  mutex*       : %p\n", c.__data.__mutex);
  dump_printf("  nwaiters     : %u\n", c.__data.__nwaiters);
  dump_printf("  broadcast_seq: %u\n", c.__data.__broadcast_seq);
}

void _dump_alf_arraylist_t(alf_arraylist_t * list, const char *func, const char *file, int line, int _pad)
{
  dump_head_printf("alf_arraylist_t", func, file, line);

  dump_printf("  lock ==>\n");
  _dump_pthread_mutex_t(list->lock, func, file, line, _pad + 2);
  dump_printf("  front_index: %u\n", list->front_index);
  dump_printf("  rear_index: %u\n", list->rear_index);
  dump_printf("  capacity: %u\n", list->capacity);
  dump_printf("  data_ptr**: %p\n", list->data_ptr);

}
void _dump_alf_instance_t(alf_instance_t * h, const char *func, const char *file, int line, int _pad)
{
  dump_head_printf("alf_instance_t", func, file, line);
  dump_printf("  threadpool.elems               : %p\n", h->threadpool.elems);
  dump_printf("  threadpool.num_threads         : %u\n", h->threadpool.num_threads);
  dump_printf("  accel_num                      : %u\n", h->accel_num);
  dump_printf("  alf_arraylist_t* init_task_list: %p\n", h->init_task_list);
  if (h->init_task_list != NULL) {
    _dump_alf_arraylist_t(h->init_task_list, func, file, line, _pad + 2);
  }
  dump_printf("  ready_task_list*               : %p\n", h->ready_task_list);
  if (h->ready_task_list != NULL) {
    _dump_alf_arraylist_t(h->ready_task_list, func, file, line, _pad + 2);
  }
  dump_printf("  exec_task_list*                : %p\n", h->exec_task_list);
  if (h->exec_task_list != NULL) {
    _dump_alf_arraylist_t(h->exec_task_list, func, file, line, _pad + 2);
  }
  dump_printf("  destroy_task_list*             : %p\n", h->destroy_task_list);
  if (h->destroy_task_list != NULL) {
    _dump_alf_arraylist_t(h->destroy_task_list, func, file, line, _pad + 2);
  }
  dump_printf("  ref_task_list*                 : %p\n", h->ref_task_list);
  if (h->ref_task_list != NULL) {
    _dump_alf_arraylist_t(h->ref_task_list, func, file, line, _pad + 2);
  }
  dump_printf("  platform_handle                : %p\n", h->platform_handle);
  dump_printf("  pthread_t scheduler            : %p\n", (void *)h->scheduler);
}
void _dump_alf_api_t(alf_api_t * h, const char *func, const char *file, int line, int _pad)
{
  dump_head_printf("alf_api_t", func, file, line);

  dump_printf("  pthread_mutex_t lock ==>\n");
  _dump_pthread_mutex_t(h->lock, func, file, line, _pad + 2);

  dump_printf("  pthread_cond_t cond ==>\n");
  _dump_pthread_cond_t(h->cond, func, file, line, _pad + 2);
  dump_printf("  state                          : %s (0x%08X)\n", _ALF_API_STATE_TYPE_T_tostring(h->state), h->state);
  dump_printf("  task_unfinished                : %u (0x%08X)\n", h->task_unfinished, h->task_unfinished);
//  dump_printf("  err_handler          :  <WEIRD>\n");
  dump_printf("  err_handler_data_ptr           : %p\n", h->err_handler_data_ptr);
  dump_printf("  exit_policy                    : %s (0x%08X)\n", _ALF_EXIT_POLICY_T_tostring(h->exit_policy),
              h->exit_policy);
  dump_printf("  datasets*                      : %p\n", h->datasets);
}
