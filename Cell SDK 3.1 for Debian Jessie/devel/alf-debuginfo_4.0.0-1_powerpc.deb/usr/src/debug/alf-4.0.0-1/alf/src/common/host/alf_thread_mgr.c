/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include <stdlib.h>
#include <string.h>
#include "alf_host.h"
#include "alf_debug.h"
#include "alf_hooks_perform_host.h"
#include "alf_stp.h"

// TODO: need some smarter algorithm for the detection of image change

// create a copy of the image info

static int alf_thread_mgr_image_info_copy(alf_thread_image_t *image,  alf_api_task_info_t *p_info)
{
    strncpy(image->lib_name, p_info->pal.api_str[ALF_API_KERNEL_LIBRARY], ALF_STRING_TOKEN_MAX);
    image->lib_name[ALF_STRING_TOKEN_MAX] = 0;
    strncpy(image->image_name, p_info->pal.api_str[ALF_API_KERNEL_IMAGE], ALF_STRING_TOKEN_MAX);
    image->image_name[ALF_STRING_TOKEN_MAX] = 0;
    return 0;
}


// return 0 when the info is identical

static int alf_thread_mgr_image_info_cmp(alf_thread_image_t *image1,  alf_thread_image_t *image2)
{
	if(strcmp(image1->lib_name, image2->lib_name) == 0 &&
	   strcmp(image1->image_name, image2->image_name) == 0 )
	  return 1;
        else return 0;
}

static int alf_thread_mgr_image_info_update(alf_thread_image_t *dst, alf_thread_image_t *src)
{
    strncpy(dst->lib_name, src->lib_name, ALF_STRING_TOKEN_MAX);
    strncpy(dst->image_name, src->image_name, ALF_STRING_TOKEN_MAX);
    return 0;
}
/*
 * Setup the thread manager
 * will allocate the thread pool to cache
 * the PAL thread used before
 */
int 
alf_thread_mgr_setup(alf_instance_t* alf_instance, unsigned int num_of_accels)
{
    unsigned int i;
    int rtn;
    
    pthread_mutex_init(&alf_instance->thread_lock, NULL);
    
    // check if we have already did the init
    if (alf_instance->accel_num > 0)	// we already did the init
  	{
  		return -ALF_ERR_PERM;	// not permitted
  	}


    //  try to reserve from PAL layer
    rtn = alf_pal_accelerators_reserve (alf_instance->platform_handle,
				 num_of_accels,
				 ALF_ACCEL_RESV_POLICY_PERSIST, -1);
    if(rtn < 0)
  	{
	  return -ALF_ERR_PERM;   // not permitted
  	}

	num_of_accels = (unsigned)rtn;  // this is what we actually get

    // get the pool elements
	alf_instance->threadpool.elems = (alf_thread_pool_elem_t *)
                         calloc(num_of_accels, sizeof(alf_thread_pool_elem_t));
	if(alf_instance->threadpool.elems == NULL)
		{
			return -ALF_ERR_NOMEM;  // or -ALF_ERR_GENERIC ?
		}
    // allocate memory for cache images
    alf_instance->thread_cache.thread_images = (alf_thread_cache_image_t *)
                                             calloc(num_of_accels, sizeof(alf_thread_cache_image_t));	
	if(alf_instance->thread_cache.thread_images == NULL)
		{
                        //free allocated memory for threadpool
		        free(alf_instance->threadpool.elems);
                	return -ALF_ERR_NOMEM;  // or -ALF_ERR_GENERIC ?
		}

	alf_instance->accel_num = num_of_accels;
    //number of threads seen by user
    alf_instance->threadpool.num_threads = 0;

    alf_instance->threadpool.used_threads = 0;  // not yet used

    // initial the states
	for(i=0; i<num_of_accels; i++) 
    {
       alf_instance->threadpool.elems[i].status = ALF_API_THREAD_STATUS_INIT;
    }
 
    return 0;   
}

int 
alf_thread_mgr_num_set(alf_instance_t* alf_instance, unsigned int num_of_accels)
{
  //only support number increase
  if(num_of_accels > alf_instance->threadpool.num_threads && num_of_accels <= alf_instance->accel_num)
    alf_instance->threadpool.num_threads = num_of_accels; 
  return 0; 
}

unsigned int 
alf_thread_mgr_num_get(alf_instance_t* alf_instance)
{
  return alf_instance->threadpool.num_threads; 
}
/*
 * Start all the PAL threads for a task
 * If there are some PAL threads cache, reuse them
 */
int
alf_thread_mgr_start_thread(alf_instance_t* alf_instance, alf_api_task_t* task_handle)
{
  unsigned int allocated_accels = 0;
  unsigned int i, accel;
  unsigned int num_avail = alf_instance->threadpool.num_threads - alf_instance->threadpool.used_threads;
  alf_thread_image_t task_image;
  alf_pal_task_info_t *pal_info;
  int rtn;
  
  if(num_avail == 0 || (task_handle->num_accel_req > num_avail && (task_handle->attr & ALF_TASK_ATTR_SCHED_FIXED)) ) 
  {
  	return -ALF_ERR_AGAIN;	// we have no resource
  }

  // we do not deal with increamental now, maybe in the future
  if( task_handle->num_accels > 0 )
  {
    return -ALF_ERR_BADR;
  }

  pal_info = (alf_pal_task_info_t *)task_handle->task_info;
  PTR_TO_ADDR64(task_handle->p_thread_context, pal_info->context_to_set);
  pal_info->vtol_id_map = calloc(task_handle->num_accel_req, sizeof(unsigned int));

  // first, check for cached threads to see if we can reuse it
  alf_thread_mgr_image_info_copy(&task_image, task_handle->task_info);
  
  // TODO: need more advanced methods to check for image changes
  pthread_mutex_lock(&alf_instance->thread_lock);
  
  for(i = 0; i < alf_instance->threadpool.num_threads; i++) 
  {
    if ((alf_instance->threadpool.elems[i].status == ALF_API_THREAD_STATUS_STANDBY)  && 
	alf_thread_mgr_image_info_cmp(&alf_instance->threadpool.elems[i].image, &task_image))
    {
      pal_info->vtol_id_map[allocated_accels++] = i;
      alf_thread_mgr_cache_flush(alf_instance, &alf_instance->threadpool.elems[i].image);
    }
  
    if (allocated_accels == task_handle->num_accel_req) 
    {
      goto label_thread_mgr_start_done;
    }
  }

  // then, check for unused threads
  for(i = 0; i < alf_instance->threadpool.num_threads; i++)
  {
    if (alf_instance->threadpool.elems[i].status == ALF_API_THREAD_STATUS_INIT)
    {
      pal_info->vtol_id_map[allocated_accels++] = i;
    }
       
    if (allocated_accels == task_handle->num_accel_req) 
    {
      goto label_thread_mgr_start_done;
    }
  }

  // lastly, go for more expensive cache flush
  for(i = 0; i < alf_instance->threadpool.num_threads; i++)
  {
    if ((alf_instance->threadpool.elems[i].status == ALF_API_THREAD_STATUS_STANDBY)  && 
	!alf_thread_mgr_image_info_cmp(&alf_instance->threadpool.elems[i].image, &task_image))
    {
      rtn = alf_pal_thread_destroy(alf_instance->threadpool.elems[i].task_thread);
      if(rtn < 0)
      {
        // TODO: need to check if extra things to do in the case of destroy failure
        goto label_thread_mgr_start_err;
      }

      alf_thread_mgr_cache_flush(alf_instance, &alf_instance->threadpool.elems[i].image);
      pal_info->vtol_id_map[allocated_accels++] = i;
      alf_instance->threadpool.elems[i].status = ALF_API_THREAD_STATUS_INIT;
    }

    if(allocated_accels == task_handle->num_accel_req) 
    {
      goto label_thread_mgr_start_done;
    }
  }


#if 0  
  // as designed, we should not have such situation as we have checked before
  // only misuse could cause such problem

  // we can not afford to satsify the task
  if(allocated_accels > 0 && (task_handle->attr & ALF_TASK_ATTR_SCHED_FIXED) ) 
  {
    // clean up the mess :-(
	for(i=0; i<allocated_accels; i++)
	{
        alf_instance->threadpool.elems[task_handle->p_task_threads[i].accel_id].status = ALF_API_THREAD_STATUS_STANDBY;
	}
	task_handle->num_accels = 0;
	alf_instance->threadpool.used_threads -= allocated_accels;
  	rtn = -ALF_ERR_BADR;	// we have no resource
	goto label_thread_mgr_start_err;
  }
#endif

label_thread_mgr_start_done:

  //can be less than required thread number for non-fixed mapping
  task_handle->num_accels = pal_info->accels = allocated_accels;

  /* For ALF LTS Only */
  if (task_handle->dataset != NULL && pal_info->task_type == ALF_TASK_TYPE_LIGHTWEIGHT)
    pal_info->task_attr |= ALF_LTS_WITH_DATASET;

  //start all the threads
  for (i = 0; i < allocated_accels; ++i)
  {
    ALF_STP_PROF_BEGIN( task_handle->p_task_threads[i].start_time );
    accel = pal_info->vtol_id_map[i];
    if (alf_instance->threadpool.elems[accel].status == ALF_API_THREAD_STATUS_INIT)
    {
      rtn = alf_pal_thread_create(task_handle->alf_handle->config_handle,i, accel, pal_info,
                                  pal_info->context_to_set,
                                  &task_handle->p_task_threads[i].thread);
      if(rtn < 0)
      {
        // we need to clean up allocated threads so far
        allocated_accels = i;
        goto label_thread_mgr_start_err;
      }
	  
      rtn = alf_thread_mgr_image_info_copy(&alf_instance->threadpool.elems[accel].image, task_handle->task_info);
      if(rtn < 0)
      {
        // we need to clean up allocated threads so far
        alf_pal_thread_destroy(task_handle->p_task_threads[i].thread);
		allocated_accels = i;
        goto label_thread_mgr_start_err;
      }
    }
    else
    {
      rtn = alf_pal_thread_reset(pal_info, alf_instance->threadpool.elems[accel].task_thread, i);
      if(rtn < 0)
      {
        // we need to clean up allocated threads so far
        allocated_accels = i;
        goto label_thread_mgr_start_err;
      }
      if( task_handle->p_thread_context != 0)
      {
        //update task context after reset
        rtn = alf_pal_thread_context_swap(alf_instance->threadpool.elems[accel].task_thread,
                                          pal_info->context_to_set, 0);
      }
      if(rtn < 0)
      {
        // we need to clean up allocated threads so far
        allocated_accels = i;
        goto label_thread_mgr_start_err;
      }
      task_handle->p_task_threads[i].thread = alf_instance->threadpool.elems[accel].task_thread;
    }
    alf_instance->threadpool.elems[accel].status = ALF_API_THREAD_STATUS_RUNNING;
    alf_instance->threadpool.elems[accel].task_thread = task_handle->p_task_threads[i].thread;
    task_handle->p_task_threads[i].finished_wbs = 0;  // just started
    task_handle->p_task_threads[i].accel_id = accel;
    alf_instance->threadpool.used_threads ++;
    ALF_STP_PROF_END( task_handle->p_task_threads[i].start_time );

    alf_int_task_call_event_handler(task_handle, ALF_TASK_EVENT_INSTANCE_START);
  }
  
  _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "Entering dataset check\n");  
  _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task_handle->dataset=%p\n",task_handle->dataset);
  
  /* Does this task have an associated data set? */
  if (task_handle->dataset != NULL) {
  	
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task_handle->dataset != NULL\n");

    /* If so, for each thread (for each accelerator) */
    for (i = 0; i < allocated_accels; i++) {
    	
      _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "accel %d\n", i);

      /* Associate thread to dataset */
      alf_pal_thread_dataset_associate(task_handle->p_task_threads[i].thread, task_handle->dataset->pal_dataset);
      
    }
    
#ifndef ASSOCIATE_DATASET_TO_ALL_MIDS
    /* Put the PAL dataset to the accelerators */
    alf_pal_dataset_put_no_wait(task_handle->dataset->pal_dataset);
#endif    

    /* Wait for data set to be put into remote data set(s) in accelerator main storage */
    alf_pal_dataset_wait_for_put(task_handle->dataset->pal_dataset);
    
  }

  _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "Exiting dataset check\n");

  // we have not satisfied the task_handle->num_accel_req, but the task should be ok to run
  // in current situation
  pthread_mutex_unlock(&alf_instance->thread_lock);
  // return the number of allocated accels
  return (int)allocated_accels;

label_thread_mgr_start_err:
	
  for(i = 0; i < allocated_accels; i++)
  {
    alf_instance->threadpool.elems[task_handle->p_task_threads[i].accel_id].status = ALF_API_THREAD_STATUS_STANDBY;
  }
  task_handle->num_accels = 0;
  alf_instance->threadpool.used_threads -= allocated_accels;
  
  pthread_mutex_unlock(&alf_instance->thread_lock);

  return rtn; 
}


/*
 * After task finish its work, the PAL threads will be returned to 
 * thread manager for cache
 */
int
alf_thread_mgr_return_thread(alf_instance_t* alf_instance ,alf_api_task_t* task_handle)
{
  unsigned int i;
  // shall we check for errors ?
  pthread_mutex_lock(&alf_instance->thread_lock);
  for(i=0; i<task_handle->num_accels; i++)
  {
    if(alf_pal_thread_wait(task_handle->p_task_threads[i].thread, 0))
    {
      // need to shutdown it
      alf_pal_thread_destroy(task_handle->p_task_threads[i].thread);
      alf_instance->threadpool.elems[task_handle->p_task_threads[i].accel_id].status = ALF_API_THREAD_STATUS_INIT;
    }
    else 
    { 
      // the thread is safe to put back as idle
      alf_instance->threadpool.elems[task_handle->p_task_threads[i].accel_id].status = ALF_API_THREAD_STATUS_STANDBY;
    }
    //alf performance hook end
    TRACE_INTERVAL_END(_ALF_THREAD_RUN_INTERVAL,alf_instance->threadpool.elems[task_handle->p_task_threads[i].accel_id].thread_run_token,1,task_handle);
  
    alf_int_task_call_event_handler(task_handle, ALF_TASK_EVENT_INSTANCE_END);
  }
  alf_instance->threadpool.used_threads -= task_handle->num_accels;
  task_handle->num_accels = 0;
  alf_thread_mgr_cache_write(alf_instance, task_handle);
  pthread_mutex_unlock(&alf_instance->thread_lock);
  return 0;
}



/*
 * Return how many accelerate is free
 *
 */
int 
alf_thread_mgr_query(alf_instance_t* alf_instance)
{
  return alf_instance->threadpool.num_threads - alf_instance->threadpool.used_threads;
}



/*
 * Cleanup the thread pool
 *
 */
int
alf_thread_mgr_cleanup(alf_instance_t* alf_instance)
{
  unsigned int i;

  // will not check parm error for internal API

   for(i=0; i<alf_instance->threadpool.num_threads; i++)
  {
    if(alf_instance->threadpool.elems[i].status != ALF_API_THREAD_STATUS_INIT)
    {
      alf_pal_thread_destroy(alf_instance->threadpool.elems[i].task_thread);
    }
  }
  if(alf_instance->threadpool.elems != NULL)
  {
    free(alf_instance->threadpool.elems);
    alf_instance->threadpool.elems = NULL;
  }
  alf_instance->threadpool.num_threads = 0;
  alf_instance->threadpool.used_threads = 0;  // not yet used
  if(alf_instance->thread_cache.thread_images != NULL)
  {
    free(alf_instance->thread_cache.thread_images);
    alf_instance->thread_cache.thread_images = NULL;
  }
  alf_instance->thread_cache.num_images = 0;
  if(alf_instance->accel_num != 0)
    alf_pal_accelerators_release(alf_instance->platform_handle, alf_instance->accel_num);
  alf_instance->accel_num = 0;
  
  return 0;
}

void alf_thread_mgr_cache_write(alf_instance_t *alf_instance, alf_api_task_t *task_handle)
{
  alf_thread_image_t task_image;
  int i;
 
  alf_thread_mgr_image_info_copy(&task_image, task_handle->task_info);
  
  //search in cached images
  for(i=0;i<alf_instance->thread_cache.num_images;i++)
  {
    //already cached
    if(alf_thread_mgr_image_info_cmp(&alf_instance->thread_cache.thread_images[i].image, 
                                     &task_image)) 
    {
      break;
    }
  }
  //not cached yet, add a new entry
  if(i>=alf_instance->thread_cache.num_images)
  { 
    alf_thread_mgr_image_info_update(&alf_instance->thread_cache.thread_images[i].image,
                                   &task_image);
    alf_instance->thread_cache.num_images++;
  }
  //increase counter for both cases
  alf_instance->thread_cache.thread_images[i].num_threads++;
  
}

void alf_thread_mgr_cache_flush(alf_instance_t *alf_instance, alf_thread_image_t *task_image)
{
  int i;
 
  for(i=0;i<alf_instance->thread_cache.num_images;i++)
  {
    //found in cached images
    if(alf_thread_mgr_image_info_cmp(&alf_instance->thread_cache.thread_images[i].image, 
                                     task_image)) 
    {
      //decrease thread counter
      alf_instance->thread_cache.thread_images[i].num_threads--;
      //if cached thread used up, remove this entry
      //move forward all other entries after it 
      if(alf_instance->thread_cache.thread_images[i].num_threads == 0)
      {
         if (i < alf_instance->thread_cache.num_images - 1 )
         {
           memcpy(&alf_instance->thread_cache.thread_images[i], 
               &alf_instance->thread_cache.thread_images[i+1], 
               (alf_instance->thread_cache.num_images - i - 1) * sizeof(alf_thread_cache_image_t));
         }
         alf_instance->thread_cache.num_images--; 
      }
      break;
    }
  }
}
int alf_thread_mgr_cache_hit(alf_instance_t *alf_instance, alf_api_task_t *task_handle)
{
  alf_thread_image_t task_image;
  int i;
 
  alf_thread_mgr_image_info_copy(&task_image, task_handle->task_info);
  
  for(i=0;i<alf_instance->thread_cache.num_images;i++)
  {
    //found in cached images
    if(alf_thread_mgr_image_info_cmp(&alf_instance->thread_cache.thread_images[i].image, 
                                     &task_image)) 
    {
      return 1; 
    }
  }
  return 0;
}
