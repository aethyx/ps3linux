/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <alf_stp.h>
#include "alf_common.h"

// enable this macro only when you need to check the range of parameters 
// for the probe calls. This will increase the overhead a little bit, however.
#define _STP_DEBUG_CHECK	1

// The following section defines the basic get timer operation.
// I recommand you to use some system specific light weight and accurate timers
// I have not define the time units due to that I haven't find a reliable and universal way to get the 
// actual value of system timer ticks per second
// for powerPC64 linux, you can get it from /proc/ppc64/systemcfg
#if defined(__powerpc64__) || defined(__powerpc__)
    // on powerpc we have the timebase counter
    // the basic unit of timing is 1/14318000 second on current CellBE Linux, better get it from /proc/ppc64/systemcfg
	#ifdef __powerpc64__   // ppc64
	#define __stp_get_sys_timer()          ({unsigned long rval;   \
							asm volatile("mftb %0" : "=r" (rval)); rval;})
	#else  // ppc32
	#define __stp_get_sys_timer()          ({union {unsigned long long rval; unsigned long rv[2];} v;  \
							asm volatile("mftbu %0" : "=r" (v.rv[0])); asm volatile("mftbl %0" : "=r" (v.rv[1])); v.rval;})
    #endif
#else
  // we will fall back to gettimeofday for this, but it is a bit too heavy and less accurate.  
  // the basic unit of timing is one microsecond as defined in gettimeofday
  #include <sys/time.h>
  static inline unsigned long long __stp_get_sys_timer()
  {
	  struct timeval tv;
	  gettimeofday(&tv, NULL);
	  return (unsigned long long)tv.tv_sec*1000*1000 + tv.tv_usec;
  }
#endif

#define _STP_ALIGNED  __attribute__ ((aligned(16)))  // define this to empty if your compiler does not support it

//==============================================
// Simple Tracing Data Structures
//==============================================

static struct __stp_trace_data_t__
{
   unsigned long long *pd;
   unsigned int idx;
   unsigned int max;
   unsigned char *_buf;
   unsigned char *dummy[3];  // pad
   char name[256];
} _trace_data[STP_TRACE_TOKEN_MAX]   _STP_ALIGNED;

static volatile int _trace_used _STP_ALIGNED = 0;

//==============================================
// Simple Profiling Data Structures
//==============================================

static struct __stp_prof_data_t__
{
   unsigned long long acc;
   unsigned long long last;
   unsigned long long min;
   unsigned long long max;
   unsigned int cnt;
   unsigned int dummy[3];  // pad
   char name[256];
} _prof_data[STP_PROF_TOKEN_MAX]   _STP_ALIGNED;

static volatile int _prof_used _STP_ALIGNED = 0;

static pthread_mutex_t _mt =  PTHREAD_MUTEX_INITIALIZER;

static int init _STP_ALIGNED = 0;
static unsigned long long _reftime _STP_ALIGNED;  // reference time start

//==============================================
// Simple Tracing Functions
//==============================================

int alf_stp_init(void)
{
   int rtn = -1;

   pthread_mutex_lock(&_mt);
   
   if(init)
	   return 0;
   _reftime = __stp_get_sys_timer();
   init = 1;
   
   pthread_mutex_unlock(&_mt);
   
   return rtn;
}

int alf_stp_deinit(void)
{
   pthread_mutex_lock(&_mt);
   
   if(_trace_used > 0)
   {
       int i;
       for(i=0; i<_trace_used; i++)
       {
           free(_trace_data[_trace_used]._buf);
       }
       _trace_used = 0;
   }

   _prof_used = 0;

   init = 0;
   
   pthread_mutex_unlock(&_mt);

   return 0;
}

void alf_stp_trace(int trace)
{
#ifdef _STP_DEBUG_CHECK
    if(trace < 0 || trace >= _trace_used) 
		 return;
#endif
    if(_trace_data[trace].idx == _trace_data[trace].max)
		return;
     _trace_data[trace].pd[_trace_data[trace].idx++] = __stp_get_sys_timer();
}

int alf_stp_trace_create(char *pname, unsigned int max_entries)
{
   int rtn = -1;

   if(max_entries > 1024*1024*1024) //  1G, too much 
       return -1;

   pthread_mutex_lock(&_mt);
   if(_trace_used < STP_TRACE_TOKEN_MAX || !init)
   {
       _trace_data[_trace_used]._buf = malloc((max_entries+1)*sizeof(unsigned long long));
       if(NULL != _trace_data[_trace_used]._buf)
       {
           memset(_trace_data[_trace_used]._buf, 0, (max_entries+1)*sizeof(unsigned long long)); // touch it
#ifdef _ALF_64B_
           _trace_data[_trace_used].pd = (unsigned long long *)(
                       ((unsigned long long)_trace_data[_trace_used]._buf+sizeof(unsigned long long)-1) &
                      ~(unsigned long long)(sizeof(unsigned long long)-1));
#else 
           _trace_data[_trace_used].pd = (unsigned long long *)(
                       ((unsigned int)_trace_data[_trace_used]._buf+sizeof(unsigned long long)-1) &
                      ~(sizeof(unsigned long long)-1));
#endif
           _trace_data[_trace_used].max = max_entries;
           _trace_data[_trace_used].idx = 0;
           if(NULL == pname)
               pname = "No Name"; 
           strncpy( _trace_data[_trace_used].name, pname, 255);
           rtn = _trace_used;
           _trace_used++;
       }
   }
   pthread_mutex_unlock(&_mt);
   return rtn;
}

static void alf_stp_trace_dump_single(int i, FILE *fp)
{
    unsigned int j;
    fprintf(fp, "---------------------------------------------\n"
                "%10d  %s\n"
                "---------------------------------------------\n", i, _trace_data[i].name);
    for(j=0; j< _trace_data[i].idx; j++)
    {
        fprintf(fp, "%10d   %20llu\n", j, _trace_data[i].pd[j]-_reftime); 
    }
}

int alf_stp_trace_dump(int trace, FILE * fp)
{
  int i;
  if (NULL == fp)
    fp = stderr;

  if (trace < 0) {
    for (i = 0; i < _trace_used; i++) {
      alf_stp_trace_dump_single(i, fp);
    }
  } else if (trace < _trace_used) {
    alf_stp_trace_dump_single(trace, fp);
  } else {
    return -1;
  }

  return 0;
}

//==============================================
// Simple Profiling Functions
//==============================================

void alf_stp_prof_begin(int prof)
{
#ifdef _STP_DEBUG_CHECK
    if(prof < 0 || prof >= _prof_used)
		return;
#endif
    _prof_data[prof].last = __stp_get_sys_timer();
}

void alf_stp_prof_end(int prof)
{
	register unsigned long long due;
#ifdef _STP_DEBUG_CHECK
    if(prof < 0 || prof >= _prof_used)
        return;
#endif
	due = __stp_get_sys_timer() - _prof_data[prof].last;
    _prof_data[prof].acc += due;
	_prof_data[prof].cnt++;
    if(_prof_data[prof].max < due){
       _prof_data[prof].max = due;
    }
    if(_prof_data[prof].min > due){
        _prof_data[prof].min = due;
    }
}

int alf_stp_prof_create(char *pname)
{
   int rtn = -1;

   pthread_mutex_lock(&_mt);
   if(_prof_used < STP_PROF_TOKEN_MAX)
   {
       _prof_data[_prof_used].acc = 0LL;
	   _prof_data[_prof_used].cnt = 0;
	   _prof_data[_prof_used].min = (unsigned long long)-1;
	   _prof_data[_prof_used].max = 0;
       if(NULL == pname)
           pname = "No Name"; 
       strncpy( _prof_data[_prof_used].name, pname, 255);
	   rtn = _prof_used;
	   _prof_used++;
   }
   pthread_mutex_unlock(&_mt);
   return rtn;
}


static void alf_stp_prof_dump_single(int i, FILE *fp, int title)
{
	if(title){
		fprintf(fp, "%5s\t%10s\t%15s\t%10s\t%10s\t%10s\t| Token\n", 
                "Id", "Count", "Total", "Min", "Max", "Average");
        }
	fprintf(fp, "%5u\t%10u\t%15llu\t%10llu\t%10llu\t%10.2f\t| %s\n",
		i+1, 
		_prof_data[i].cnt,  
		_prof_data[i].cnt == 0 ? 0LL : _prof_data[i].acc,
		_prof_data[i].cnt == 0 ? 0LL : _prof_data[i].min,
		_prof_data[i].cnt == 0 ? 0LL : _prof_data[i].max,
		_prof_data[i].cnt == 0 ? 0.0 : (double)(_prof_data[i].acc)/(double)(_prof_data[i].cnt),
		_prof_data[i].name);
}

int alf_stp_prof_dump(int prof, FILE * fp)
{
  int i;

  if (NULL == fp){
     fp = stdout;
  }

  if (prof < 0) {
    fprintf(fp, "* PPU *\n");
    fprintf(fp, "-----------------------------------------------------"
                "-----------------------------------------------------\n");
    for (i = 0; i < _prof_used; i++) {
      alf_stp_prof_dump_single(i, fp, i == 0);
    }
    fprintf(fp, "\n\n");
  } else if (prof < _prof_used) {
    alf_stp_prof_dump_single(prof, fp, 0);
  } else {
    return -1;
  }

  return 0;
}
