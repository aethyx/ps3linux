/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "alf_common_platform.h"
#include "alf_arraylist.h"

/**
 * Arraylist create routine.
 *
 * This function creates an arraylist with "capacity" number elements.
 *
 * Parameters:
 * capacity[IN]: Expected capacity of the arraylist.
 * 
 * Return Values:
 * The address of the resulting arraylist is returned.
 */

alf_arraylist_t *alf_arraylist_create(unsigned int capacity)
{
  alf_arraylist_t *al;

  if (capacity == 0) {

    /* If capacity invalid, return an error */
    return NULL;
  }

  /* Allocate and set the arraylist object pointer */
  al = (alf_arraylist_t *) calloc(1, sizeof(alf_arraylist_t));

  /* Check if the arraylist object allocation suceeded */
  if (al == NULL) {

    /* If not, return an error */
    return NULL;
  }

  /* Initialize the arraylist object */
  al->length = 0; // cached value
  al->capacity = capacity;
  al->rear_index = al->front_index = 0;

  /* Allocate and set the arraylist's dataptr array */
  al->data_ptr = calloc(1, sizeof(void *) * capacity);

  /* Check if the arraylist's dataptr array allocation succeeded */
  if (!al->data_ptr) {

    /* If not, free the arraylist object */
    free(al);

    /* Return an error */
    return NULL;
  }

  /* Initialize the arraylist lock */
  pthread_mutex_init(&al->lock, NULL);

  /* Return success */
  return al;
}

/**
 * Arraylist enqueue element at the end routine.
 *
 * This function adds a data element into the end of the arraylist, and returns
 * the data element after insertion. If there are insufficient space to
 * add this data element to the arraylist then the arraylist is doubled in size
 * before inserting the data element.
 *
 * Parameters:
 * al[IN]: Pointer to a arraylist.
 * data[IN]: Pointer to data element which needed to be enqueued.
 *
 * Return Values:
 * Address to data element which was enqueued. NULL is returned if any errors are encountered
 *
 */

void *alf_arraylist_enqueue(alf_arraylist_t * al, void *data)
{
  void **data_ptr;
  void **np;
  void **p1;
  void **p2;

  /* Lock the arraylist object */
  pthread_mutex_lock(&al->lock);

  data_ptr = al->data_ptr;
  if (!(((al->rear_index + 1) % al->capacity) == al->front_index)) {
    data_ptr[al->rear_index] = data;
  } else {                      /*Try to double the data array. */

    np = calloc(1, (sizeof(void *)) * (al->capacity << 1));
    if (np != NULL) {
      /*We need to move data here, because the capacity will be changed! */
      if (al->front_index > al->rear_index) {
        if (al->front_index > (al->capacity >> 1)) {
         /**
          *          Old data          p1        |        New data buffer   p2
          * +----+----+----+-----+-----+----+----+----+----+----+-----+-----+----+----+
          *                      ^     ^ al->front_index
          *                al->rear_index   
          */
          p1 =  data_ptr + al->front_index;
          p2 = np + (al->capacity + al->front_index);
          memcpy(p2, p1, sizeof(void *) * (al->capacity - al->front_index));
          memcpy(np,  data_ptr, sizeof(void *) * al->rear_index);

          al->front_index += al->capacity;
        }
         /**
          *                                      p2 
          *          Old data                    |       New data buffer  
          * +----+----+----+-----+-----+----+----+----+----+----+-----+-----+----+----+
          *      ^    ^ al->front_index
          * al->rear_index
          */
        else {
          p2 = np + al->capacity;
          p1 = np + al->front_index;
          memcpy(p2,  data_ptr, sizeof(void *) * (al->rear_index));
          memcpy(p1,  (data_ptr + al->front_index), sizeof(void *) * (al->capacity - al->front_index));

          al->rear_index += al->capacity;
        }
      } /*if (al->front_index > al->rear_index) */
      else {                    /*copy it directly */

        memcpy(np, (void **) data_ptr, sizeof(void *) * al->capacity);
      }

      free((void *) data_ptr);

      data_ptr = np;
      al->data_ptr = data_ptr;
      data_ptr[al->rear_index] = data;

      al->capacity = al->capacity << 1;
    }
    /*if (al->front_index > al->rear_index) */
    /*if (np !=NULL) */
    else {
      pthread_mutex_unlock(&al->lock);
      return NULL;
    }
  }                             /* else */
  _ALF_SYNC_MEMORY();
  /* update the rear index */
  al->rear_index = (al->rear_index + 1) % al->capacity;
  
  /* update the length */
  al->length = (al->rear_index - al->front_index + al->capacity) % al->capacity;


  /* Unlock the arraylist object */
  pthread_mutex_unlock(&al->lock);

  return data;
}

/**
 * Arraylist dequeue element from the front routine.
 *
 * This function removes the first data element from arraylist, and return it.
 *
 * Parameter:
 * al[IN]: Pointer to the arraylist.
 *
 * Return Values:
 * Address of the first data element. NULL is returned if the is empty.
 *
 */

void *alf_arraylist_dequeue(alf_arraylist_t * al)
{
  void *data;

  /* Lock the arraylist object */
  pthread_mutex_lock(&al->lock);

  /* Is the arraylist non-empty? */
  if (al->front_index != al->rear_index) {

    /* Return the front element */
    data = al->data_ptr[al->front_index];

    /* Clear the front element entry to NULL */
    al->data_ptr[al->front_index] = NULL;

    /* Index to the next element */
    al->front_index = (al->front_index + 1) % al->capacity;
    
    /* Update the length */
    al->length = (al->rear_index - al->front_index + al->capacity) % al->capacity;

    _ALF_SYNC_MEMORY();
    
  } else {

    /* Return a NULL for an empty arraylist */
    data = NULL;

  }

  /* Unlock the arraylist object */
  pthread_mutex_unlock(&al->lock);

  return data;
}

/**
 * Arraylist dequeue element from the end routine.
 *
 * This function removes the last data element from arraylist, and return it.
 *
 * Parameter:
 * al[IN]: Pointer to the arraylist.
 *
 * Return Values:
 * Address of the last data element. NULL is returned if the arraylist is empty.
 *
 */

void *alf_arraylist_dequeue_from_end(alf_arraylist_t * al)
{
  void *data;

  /* Lock the arraylist object */
  pthread_mutex_lock(&al->lock);

  /* Is the arraylist non-empty? */
  if (al->front_index != al->rear_index) {

    /* Index to the rear element */
    al->rear_index = (al->rear_index - 1 + al->capacity) % al->capacity;

    /* Return the rear element */
    data = al->data_ptr[al->rear_index];

    /* Clear the rear element entry to NULL */
    al->data_ptr[al->rear_index] = NULL;

    /* Update the length */
    al->length = (al->rear_index - al->front_index + al->capacity) % al->capacity;

    _ALF_SYNC_MEMORY();
    
  } else {

    /* Return a NULL for an empty arraylist */
    data = NULL;
  }

  /* Unlock the arraylist object */
  pthread_mutex_unlock(&al->lock);

  return data;
}

/**
 * Arraylist remove element by value routine.
 * 
 * This function removes an data element from the arraylist, and returns it.
 * 
 * Parameter:
 * al[IN]: Pointer to the arraylist
 * data[IN]: Pointer to the data element to be removed
 * 
 * Return Values:
 * Address of the data element that was removed. NULL is returned if the data element is not found in the arraylist.
 * 
 */

void *alf_arraylist_remove(alf_arraylist_t * al, void *data)
{
  unsigned int i, j;

  if (al == NULL) {
    return NULL;
  }

  if (data == NULL) {
    return NULL;
  }

  /* Lock the arraylist object */
  pthread_mutex_lock(&al->lock);

  /* Is the arraylist non-empty? */
  if (al->front_index != al->rear_index) {

    /* For each element in the arraylist */
    for (i = al->front_index; i != al->rear_index; i = ((i + 1) % al->capacity)) {

      /* Does this element match with the one given as an argument */
      if (al->data_ptr[i] == data) {

        /* For each succeeding element in the arraylist */
        for (j = ((i + 1) % al->capacity); j != al->rear_index;
             i = ((i + 1) % al->capacity), j = ((j + 1) % al->capacity)) {

          /* Set the previous element to the next element */
          al->data_ptr[i] = al->data_ptr[j];

        }

        /* Move the index to remove one element */
        al->rear_index = (al->rear_index - 1 + al->capacity) % al->capacity;

        /* Clear the rear element entry to NULL */
        al->data_ptr[al->rear_index] = NULL;

        /* Update the length */
        al->length = (al->rear_index - al->front_index + al->capacity) % al->capacity;

        _ALF_SYNC_MEMORY();
    
        /* Unlock the arraylist object */
        pthread_mutex_unlock(&al->lock);

        /* Return success */
        return data;
      }
    }
  }

  /* Unlock the arraylist object */
  pthread_mutex_unlock(&al->lock);

  /* Return failure */
  return NULL;
}

/**
 * Arraylist remove element by index routine.
 * 
 * This function removes an data element from the arraylist at a specific index, and returns it.
 * 
 * Parameter:
 * al[IN]: Pointer to the arraylist
 * index[IN]: Index for the expected data element from 0 to length-1.
 * 
 * Return Values:
 * Address of the data element that was removed. NULL is returned if any errors are encountered.
 * 
 */

void *alf_arraylist_remove_element(alf_arraylist_t * al, unsigned int index)
{
  unsigned int i, j;
  void *data;

  if (al == NULL) {
    return NULL;
  }

  if (index >= alf_arraylist_get_length(al)) {
    /* Return failure */
    return NULL;
  }

  /* Access the indexed element */
  data = al->data_ptr[(al->front_index + index) % al->capacity];

  /* Lock the arraylist object */
  pthread_mutex_lock(&al->lock);

  /* For each succeeding element in the arraylist */
  for (i = index, j = ((i + 1) % al->capacity); j != al->rear_index;
       i = ((i + 1) % al->capacity), j = ((j + 1) % al->capacity)) {

    /* Set the previous element to the next element */
    al->data_ptr[i] = al->data_ptr[j];

  }

  /* Move the index to remove one element */
  al->rear_index = (al->rear_index - 1 + al->capacity) % al->capacity;

  /* Clear the rear element entry to NULL */
  al->data_ptr[al->rear_index] = NULL;

  /* Update the length */
  al->length = (al->rear_index - al->front_index + al->capacity) % al->capacity;

  _ALF_SYNC_MEMORY();
    
  /* Unlock the arraylist object */
  pthread_mutex_unlock(&al->lock);

  /* Return success */
  return data;
}

/**
 * Arraylist get front element routine
 * 
 * This function gets the data element from the arraylist at the front and returns it.
 * This is equivlaent to arraylist dequeue, but the element is not removed from the list.
 * Since the arraylist is not modified, no locks are used.
 * 
 * Parameters:
 * al[IN]: Pointer to the arraylist.
 * 
 * Return value:
 * Address of the expected data element. NULL is returns for a empty list.
 */
void *alf_arraylist_get_front(alf_arraylist_t * al)
{
  void *data;

  pthread_mutex_lock(&al->lock);
  /* Is the arraylist non-empty? */
  if (al->front_index != al->rear_index) {

    /* Return the front element */
    data = al->data_ptr[al->front_index];

  } else {

    /* Return a NULL for an empty arraylist */
    data = NULL;

  }
  pthread_mutex_unlock(&al->lock);

  return data;
}

/**
 * Arraylist get rear element routine
 * 
 * This function gets the data element from the arraylist at the rear and returns it.
 * This is equivlaent to arraylist dequeue_from_end, but the element is not removed from the list.
 * Since the arraylist is not modified, no locks are used.
 * 
 * Parameters:
 * al[IN]: Pointer to the arraylist.
 * 
 * Return value:
 * Address of the expected data element. NULL is returns for a empty list.
 */
void *alf_arraylist_get_rear(alf_arraylist_t * al)
{
  void *data;

  /* Is the arraylist non-empty? */
  if (al->front_index != al->rear_index) {

    /* Return the rear element */
    data = al->data_ptr[(al->rear_index - 1 + al->capacity) % al->capacity];

  } else {

    /* Return a NULL for an empty arraylist */
    data = NULL;

  }

  return data;
}

/** 
 * Arraylist get data element routine
 *
 * This function gets the data element from the arraylist at a specific index and returns it.
 *
 * Parameters:
 * al[IN]: Pointer of the arraylist.
 * index[IN]: Index for the expected data element from 0 to length-1.
 *
 * Return Value:
 * Address of the indexed data element. NULL is returned if any errors are encountered.
 */

void *alf_arraylist_get_element(alf_arraylist_t * al, unsigned int index)
{
  if (index >= alf_arraylist_get_length(al)) {
    /* Return failure */
    return NULL;
  }

  /* Access the indexed element */
  return al->data_ptr[(al->front_index + index) % al->capacity];
}



/**
 * Arraylist contains data element routine.
 * 
 * This function queries if an data element is contained in the arraylist.
 * 
 * Parameter:
 * al[IN]: Pointer to the arraylist
 * data[IN]: Pointer to the data element to be queried
 * 
 * Return Values:
 * ==1 Arraylist contains the data element 
 * ==0 Arraylist does not contains the data element 
 */

int alf_arraylist_contains(alf_arraylist_t * al, void *data)
{
  unsigned int i;

  if (al == NULL) {
    return 0;
  }

  if (data == NULL) {
    return 0;
  }

  /* Lock the arraylist object */
  pthread_mutex_lock(&al->lock);

  /* Is the arraylist non-empty? */
  if (al->front_index != al->rear_index) {

    /* For each element in the arraylist */
    for (i = al->front_index; i != al->rear_index; i = ((i + 1) % al->capacity)) {

      /* Does this element match with the one given as an argument */
      if (al->data_ptr[i] == data) {

        /* Unlock the arraylist object */
        pthread_mutex_unlock(&al->lock);

        /* Return success */
        return 1;
      }
    }
  }

  /* Unlock the arraylist object */
  pthread_mutex_unlock(&al->lock);

  /* Return the condition value */
  return 0;
}

/**
 * Arraylist print routine.
 *
 * This function prints the internal contents of the arraylist.
 *
 * Parameters:
 * al[IN]: Pointer to the arraylist.
 *
 * Return Values:
 * None.
 */

void alf_arraylist_print(alf_arraylist_t * al)
{
  unsigned int i;

  printf("In alf_arraylist_print: al=%p\n", al);
  if (al != NULL) {

    /* Lock the arraylist object */
    pthread_mutex_lock(&al->lock);

    printf("In alf_arraylist_print: al->capacity=%d\n", al->capacity);
    printf("In alf_arraylist_print: al->front_index=%d\n", al->front_index);
    printf("In alf_arraylist_print: al->rear_index=%d\n", al->rear_index);
    printf("In alf_arraylist_print: al->length=%d\n", al->length);
    printf("In alf_arraylist_print: al->data_ptr=%p\n", al->data_ptr);
    if (al->data_ptr != NULL) {
      for (i = 0; i < al->capacity; i++) {
        printf("In alf_arraylist_print: al->data_ptr[%d@%p]=%p\n", i, &al->data_ptr[i], al->data_ptr[i]);
      }
    }
    /* Unlock the arraylist object */
    pthread_mutex_unlock(&al->lock);
  }

  fflush(stdout);
}

/**
 * Arraylist destroy routine.
 *
 * This function free the resouces allocateed for arraylist.
 *
 * Parameters:
 * al[IN]: Pointer to the arraylist.
 *
 * Return Values:
 * None.
 */

void alf_arraylist_destroy(alf_arraylist_t * al)
{
  if (al == NULL) {
    return;
  }

  /* Lock the arraylist object */
  pthread_mutex_lock(&al->lock);

  /* Free the arraylist's dataptr array */
  free(al->data_ptr);

  /* Nullify the arraylist's dataptr array */
  al->data_ptr = NULL;

  /* Unlock the arraylist object */
  pthread_mutex_unlock(&al->lock);

  /* Destroy the arraylist's lock */
  pthread_mutex_destroy(&al->lock);

  /* Free the arraylist */
  free(al);
}

void alf_arraylist_destroy_nl(alf_arraylist_nl_t *al_nl){

  alf_arraylist_t *picker;
  alf_arraylist_t *tmp;

  picker = al_nl->head;
  while(picker!=NULL){
      tmp = picker;
      picker = picker->next; 
      alf_arraylist_destroy(tmp);
  }
  free(al_nl);
}




alf_arraylist_nl_t *alf_arraylist_create_nl(unsigned int capacity)
{
  alf_arraylist_nl_t *al;

  if (capacity == 0) {

    /* If capacity invalid, return an error */
    return NULL;
  }

  /* Allocate and set the arraylist object pointer */
  al = (alf_arraylist_nl_t *) calloc(1, sizeof(alf_arraylist_nl_t));

  /* Check if the arraylist object allocation suceeded */
  if (al == NULL) {

    /* If not, return an error */
    return NULL;
  }

  /* Initialize the arraylist object */
  al->capacity = capacity;

  al->head = alf_arraylist_create(al->capacity);

  /* Check if the arraylist's dataptr array allocation succeeded */
  if (!al->head) {

    /* If not, free the arraylist object */
    free(al);

    /* Return an error */
    return NULL;
  }

  al->tail = al->head;
  
  pthread_mutex_init(&al->lock, NULL);
  /* Return success */
  return al;
}


void *alf_arraylist_enqueue_nl(alf_arraylist_nl_t * al_nl, void *data)
{

  pthread_mutex_lock(&al_nl->lock);

  alf_arraylist_t* al = al_nl->tail;

  if (!(((al->rear_index + 1) % al->capacity) == al->front_index)) {
    al->data_ptr[al->rear_index] = data;
  } else {                      /*Try to double the data array. */
    al = alf_arraylist_create(al_nl->capacity);
    al->data_ptr[al->rear_index] = data;
    al_nl->tail->next = al;
    al_nl->tail = al;
  }                             /* else */
  _ALF_SYNC_MEMORY();
  /* update the rear index */
  al->rear_index = (al->rear_index + 1) % al->capacity;
  
  /* update the length */
  al->length = (al->rear_index - al->front_index + al->capacity) % al->capacity;

  pthread_mutex_unlock(&al_nl->lock);

  return data;
}


void *alf_arraylist_dequeue_nl(alf_arraylist_nl_t * al_nl)
{
  void *data;

  alf_arraylist_t* al = al_nl->head;

  /* Is the arraylist non-empty? */
  if (al->front_index != al->rear_index) {

    /* Return the front element */
    data = al->data_ptr[al->front_index];

    /* Clear the front element entry to NULL */
    al->data_ptr[al->front_index] = NULL;

    _ALF_SYNC_MEMORY();
    /* Index to the next element */
    al->front_index = (al->front_index + 1) % al->capacity;
    
    /* Update the length */
    al->length = (al->rear_index - al->front_index + al->capacity) % al->capacity;

    
  } else {

    /* Return a NULL for an empty arraylist */
    if(al->next != NULL)
    {
      al_nl->head = al->next;
      alf_arraylist_destroy(al);
      al = al_nl->head;
 
      if (al->front_index != al->rear_index) {

      /* Return the front element */
      data = al->data_ptr[al->front_index];

      /* Clear the front element entry to NULL */
      al->data_ptr[al->front_index] = NULL;

      _ALF_SYNC_MEMORY();
      /* Index to the next element */
      al->front_index = (al->front_index + 1) % al->capacity;
    
      /* Update the length */
      al->length = (al->rear_index - al->front_index + al->capacity) % al->capacity;
      }
      else data = NULL;
    }  
    else data = NULL;

  }

  return data;
}



void *alf_arraylist_get_front_nl(alf_arraylist_nl_t * al_nl)
{
  alf_arraylist_t* al = al_nl->head;
  void *data;

  /* Is the arraylist non-empty? */
  if (al->front_index != al->rear_index) {

    /* Return the front element */
    data = al->data_ptr[al->front_index];

  } else {

    if(al->next != NULL)
    {
      al = al->next;
      al_nl->head = al->next;
 
      if (al->front_index != al->rear_index) {

      /* Return the front element */
      data = al->data_ptr[al->front_index];

      }
      else data = NULL;
    }
    else data = NULL;

  }

  return data;

}

