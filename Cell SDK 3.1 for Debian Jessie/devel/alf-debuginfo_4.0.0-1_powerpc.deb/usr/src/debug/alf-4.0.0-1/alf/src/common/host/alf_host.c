/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/*
 ************************************************************
 * ALF Host Internal Utility API
 ************************************************************
 */

#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include <libmisc.h>
#include <alf.h>
#include "alf_host.h"
#include "alf_debug.h"
#include "alf_stp.h"
#include "alf_api_local.h"
/*
 ************************************************************
 * Globals
 ************************************************************
 */

/*
 ************************************************************
 * Local Globals
 ************************************************************
 */

/*
 ************************************************************
 * Local APIs
 ************************************************************
 */

//---------------------------------------------------------------------------------------------------
// alf_api_task_wb_enqueue
//---------------------------------------------------------------------------------------------------

int alf_api_task_sync_wb_enqueue(alf_api_task_t * task_handle, alf_api_wb_t * wb_handle)
{
  unsigned int accel_index;
  if (task_handle->attr & ALF_TASK_ATTR_WB_CYCLIC) {
    //we can enqueue wb directly to accel's wb queue
    for(accel_index = 0; accel_index < task_handle->num_accel_req; accel_index++)
    { 
      if(NULL == alf_arraylist_enqueue_nl(task_handle->accel_wbq[accel_index],wb_handle))
      {
        _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "wb enqueue failed\n");
        return -ALF_ERR_NOMEM;
      }
      _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "wb enqueued to accel %d\n", accel_index);
    }
  } else {
    //enqueue wb to a global queue and leave scheduling work to scheduler
    if(NULL == alf_arraylist_enqueue_nl(task_handle->task_wbq, wb_handle))
    {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "wb enqueue failed\n");
      return -ALF_ERR_NOMEM;
    }
  }
  return 0;
}

int alf_api_task_wb_enqueue(alf_api_task_t * task_handle, alf_api_wb_t * wb_handle)
{
  if (task_handle->attr & ALF_TASK_ATTR_WB_CYCLIC) {
    //we can enqueue wb directly to accel's wb queue
    if(NULL == alf_arraylist_enqueue_nl(task_handle->accel_wbq[task_handle->cur_accel],wb_handle))
    {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "wb enqueue failed\n");
      return -ALF_ERR_NOMEM;
    }

    task_handle->dist_num += 1;

    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "wb enqueued to accel %d\n", task_handle->cur_accel);
    if (task_handle->dist_num == task_handle->wb_dist_size) {
      //current wb bundle finished
      //set current accel to next accel
      task_handle->cur_accel = (task_handle->cur_accel + 1) % task_handle->num_accel_req;
      task_handle->dist_num = 0;
    }
  } else {
    //enqueue wb to a global queue and leave scheduling work to scheduler
    if(NULL == alf_arraylist_enqueue_nl(task_handle->task_wbq, wb_handle))
    {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "wb enqueue failed\n");
      return -ALF_ERR_NOMEM;
    }
  }
  return 0;
}

/* try to free finished wb as much as possible
**/
void alf_sched_task_wb_try_free(alf_api_task_t * task_handle)
{
  alf_api_wb_t *wb;
  alf_pal_thread_status_t status;
  int wb_num;
  unsigned int accel_index;
  int wb_index;
  //we asumme wb is processed serially on each accel
  //so when we get new finished wb number
  //we release the same number of wb on the top of the garbage queue
  for (accel_index = 0; accel_index < task_handle->num_accels; accel_index++) {
    if (alf_pal_thread_status_query(task_handle->p_task_threads[accel_index].thread, 
                                    &status) >= 0) {
      if ((wb_num = (int)(status.finished_wbs - task_handle->p_task_threads[accel_index].finished_wbs))
            > 0) {
        for (wb_index = 0; wb_index < wb_num; wb_index++) {
          if( (wb = alf_arraylist_dequeue(task_handle->accel_fin_wbq[accel_index])) != NULL )
          {
            alf_int_wb_handle_destroy(wb, task_handle);
            alf_sched_task_wb_count_dec(task_handle);
          }
        }
        task_handle->p_task_threads[accel_index].finished_wbs = status.finished_wbs;
      }
    } else
      break;
  }
  
}

/* free all wb for finished or destroyed task
**/
void alf_sched_task_wb_free(alf_api_task_t * task_handle)
{
  alf_api_wb_t *wb;
  int i;
  //destroy wb in task wb queue if it has
  if (task_handle->task_wbq != NULL) {
    while ((wb = (alf_api_wb_t *) alf_arraylist_dequeue_nl(task_handle->task_wbq)) != NULL) {
      alf_int_wb_handle_destroy(wb, task_handle);
    }
  }
  //destroy wb in accel garbage wb queue if it has
  for (i = 0; i < (int) task_handle->num_accel_req; i++) {
    if (NULL != task_handle->accel_fin_wbq && NULL != task_handle->accel_fin_wbq[i]) {
      while ((wb = (alf_api_wb_t *) alf_arraylist_dequeue(task_handle->accel_fin_wbq[i])) != NULL) {
        alf_int_wb_handle_destroy(wb, task_handle);
        //only dec count for finished wb
        alf_sched_task_wb_count_dec(task_handle);
      }
    }
  }
}

void alf_sched_sync_wbq_destroy(alf_arraylist_t *sync_wbq)
{
  alf_api_wb_t *wb;
  alf_wb_sync_t *sync_wb;
  if (sync_wbq != NULL) {
    while ((wb = (alf_api_wb_t *) alf_arraylist_dequeue(sync_wbq)) != NULL)
    {
      sync_wb = (alf_wb_sync_t *)&wb->pal;
      if(sync_wb->p_context!=NULL)
        free(sync_wb->p_context);
      free(wb);
    }
    alf_arraylist_destroy(sync_wbq);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "sync wbq free succeed\n");
  }
}

/* destroy wb resources includes:
 * wb handle
 * pal dtl group
 * wb parm
**/
void alf_int_wb_handle_destroy(alf_api_wb_t * wb, alf_api_task_t* task)
{
    int rtn;

  if(wb == NULL)
    return;

  if (wb->type != _ALF_WB_SYNC) {  
    rtn = alf_pal_wb_cleanup(&wb->pal);
  }

  if(rtn < 0)
  {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "wb pal wb_cleanup failed %d\n", rtn);
      // FIXME: shall we choose to continue here ?
      //    the current implementation is to continue on error, else we could leak resources
      // FIXME: we need an error callback here
  }

  //FIXME free dtl here  
  if(wb->dtl != NULL)
  {
    alf_api_dtl_free(task->alf_handle->dtl_pool,wb->dtl);
  }
 
  //return wb to wb pool
  alf_wbpool_free_wb(wb);
  _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "wb handle free succeed\n");
}

#if 0
int alf_sched_task_list_cleanup(alf_api_t *alf_handle,alf_arraylist_t* task_list)
{
  alf_api_task_t *task_handle;
  unsigned int len = alf_arraylist_get_length(task_list);
  unsigned int i;
 
  for(i=0;i<len;i++)
  {
    if((task_handle = alf_arraylist_dequeue(task_list)) != NULL) {
      //do not count unfinished task caused by alf_task_destroy
      if(task_handle->state != ALF_API_TASK_STATUS_DESTROY)
        alf_handle->task_unfinished++;

      _ALF_API_STD_COND_SIG(task_handle->lock, task_handle->cond, 
                              task_handle->state = ALF_API_TASK_STATUS_DESTROY);

      alf_int_task_res_destroy(task_handle);
    }
  }
  return len;
}
#endif

/*garbage collection for finished or destroyed task
*/
int alf_sched_task_release(alf_instance_t * alf_instance)
{
  alf_api_task_t *task_handle;

  if ( alf_arraylist_get_length(alf_instance->destroy_task_list) < ALF_GC_THRESHOLD &&
       !alf_instance->gc_flag) {
    return 0;
  }

  ALF_STP_PROF_BEGIN(alf_instance->rel_time);
  while ((task_handle = alf_arraylist_dequeue(alf_instance->destroy_task_list)) != NULL) {

    if(task_handle->state != ALF_API_TASK_STATUS_FINISH)
    {
      _ALF_API_STD_COND_SIG(task_handle->lock, task_handle->cond, 
                            task_handle->state = ALF_API_TASK_STATUS_DESTROYED);
    }
    
    alf_int_task_res_destroy(task_handle, 1);
  }

  ALF_STP_PROF_END( alf_instance->rel_time );
  return 0;
}

/* init following resources
 * task list
 * task info list
 * sync wbq
 * dtl pool
 * data set
 * lock & cond
 * error handler
 */
int alf_api_handle_init(alf_api_t * alf_handle, void* sys_config_info, alf_instance_t *alf_instance)
{
  int rtn = 0;

  alf_handle->task_list = alf_arraylist_create(_ALF_API_TASK_QUEUE_LEN);
  if (alf_handle->task_list == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf create task list failed\n");
    return rtn;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf ref list allocate succeed\n");

  //create task info list
  alf_handle->task_info_list = alf_arraylist_create(_ALF_API_TASK_INFO_NUM);
  if (alf_handle->task_info_list == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf create task info list failed\n");
    return rtn;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf task info list allocate succeed\n");

  //create sync wbq
  alf_handle->sync_wbq = alf_arraylist_create(_ALF_API_TASK_SYNC_QUEUE_LEN);
  if (NULL == alf_handle->sync_wbq) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf create sync wbq failed\n");
    return rtn;
  }
  else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf sync wbq allocate succeed\n");

  //create dtl pool  
  //allocate double size for both header & entry
  //the last one entry used as ending indicator 
  alf_handle->dtl_pool = alf_api_dtl_pool_create( 2 * ALF_PAL_MAX_DTL_NUM_ENTRY + 1);
  if (alf_handle->dtl_pool == NULL) {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "dtl pool create failed\n");
      return rtn;
  }

  //init cond & lock
  rtn = pthread_mutex_init(&alf_handle->lock, NULL);
  if (rtn != 0) {
    rtn = -ALF_ERR_GENERIC;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf handle lock init failed\n");
    return rtn;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf lock init succeed\n");

  rtn = pthread_cond_init(&alf_handle->cond, NULL);
  if (rtn != 0) {
    rtn = -ALF_ERR_GENERIC;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, " alf handle cond init failed\n");
    return rtn;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf cond init succeed\n");
  
  //create dataset list
  alf_handle->datasets = alf_arraylist_create(_ALF_API_DATASET_LIST_LEN);
  if (alf_handle->datasets == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf dataset list init failed\n");
    return rtn;
  }

  rtn = alf_pal_config_init(alf_instance->platform_handle, sys_config_info , &alf_handle->config_handle);
  if (rtn != 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, " alf handle init failed\n");
    return rtn;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf handle init succeed\n");
  
  //set default error handler and start error handler thread
  alf_handle->err_handler = (alf_error_handler_t)alf_err_default_error_handler;
  alf_handle->err_handler_data_ptr = NULL;
  
  //all init succeed, start running
  alf_handle->state = ALF_API_STATUS_RUNNING;

  return rtn;
}

/* destroy alf handle resources includes
 * task list
 * task info list
 * sync wbq
 * dtl pool
 * data set
 * lock & cond
 */
void alf_api_handle_destroy(alf_api_t * alf_handle)
{
  alf_api_task_info_t *task_info;
  if (NULL != alf_handle) {
    //destroy pal config handle
    if(alf_handle->config_handle != NULL)
    {
      alf_pal_config_exit(alf_handle->config_handle);
    }
    //free all task info
    if(alf_handle->task_info_list != NULL)
    {
      while (NULL != (task_info = alf_arraylist_dequeue(alf_handle->task_info_list))) {
        alf_int_task_info_destroy(task_info);
      }
    }
    //destroy task info list
    alf_arraylist_destroy(alf_handle->task_info_list);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf task info list free succeed\n");
    alf_handle->task_info_list = NULL;
		
    //destroy task list
    alf_arraylist_destroy(alf_handle->task_list);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf task list free succeed\n");
    alf_handle->task_list = NULL;
		
    //destroy sync wbq
    alf_sched_sync_wbq_destroy(alf_handle->sync_wbq);
    alf_handle->sync_wbq = NULL;
		
    //destroy dtl pool
    alf_api_dtl_pool_destroy(alf_handle->dtl_pool);
    alf_handle->dtl_pool = NULL;
		
    ALF_API_ALF_HANLDE_HASH_REMOVE(alf_handle->self);
    ALF_API_TASK_HASH_DESTROY(alf_handle);

    pthread_cond_destroy(&alf_handle->cond);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf cond free succeed\n");
    
    pthread_mutex_destroy(&alf_handle->lock);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf lock free succeed\n");
   
    alf_arraylist_destroy(alf_handle->datasets);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf datasets free succeed\n");
    
    free(alf_handle);
		
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf handle free succeed\n");
    alf_handle = NULL;
  }

}

/* destroy task desc resources include:
 * lock
 * arch tinfo
 * pal context desc
 * task desc handle
**/
void alf_int_task_info_destroy(alf_api_task_info_t * task_info)
{
  if (NULL != task_info) {
    pthread_mutex_destroy(&task_info->lock);
    if (NULL != task_info->pal.p_arch_tinfo) {
      free(task_info->pal.p_arch_tinfo);
    }
    if (NULL != task_info->pal.context_desc)
    {
      free(task_info->pal.context_desc);
    }
    free(task_info);
    task_info = NULL;
  }

}

/* destroy alf task resources includes:
 * pal task info
 * child_tasks queue
 * task wbq
 * accel wbq
 * accel garbage wbq
 * thread array
 * lock & cond
 * * * 
 * Notes: task handle itself should be destroy in alf destroy
**/
void alf_int_task_res_destroy(alf_api_task_t * task_handle, int force)
{
  int i, rtn = 0;

  alf_api_t* alf_handle;
  alf_instance_t *alf_instance;
  alf_task_handle_t task_key;	
  
  if (NULL == task_handle)
    return;

  alf_handle = task_handle->alf_handle;
  if (NULL == alf_handle) 
    return;
  
  alf_instance = alf_handle->instance;
  if (NULL == alf_instance) 
    return;	

  task_key = task_handle->self;

  // force == 1, release task from Scheduler
  // force == 0, release task from API
  if (force) {  
    // rtn == -ALF_ERR_PERM, this task handle is referenced by API, just re-enqueue it to destroyed_task_list
    // rtn == -ALF_ERR_BADF, this task handle is marked as DESTROYED, release wb resources, 
    //                       leave task_handle to be released from alf_instance restroy. 
    // rtn == 0, this task handle is a finished handle, finished handle will be removed from the HT, all associated
    //           resource, like wb as well as task_handle itself, will be released.
#ifndef _ALF_PLATFORM_HYBRID_
    rtn = ALF_API_TASK_HASH_REMOVE(alf_handle, task_handle->self);
    if (rtn == -ALF_ERR_PERM) { // task handle is referenced by API, just return
      alf_arraylist_enqueue(alf_instance->destroy_task_list, task_handle);
      return;
    }
    
    if (rtn == 0) { // finished handle
                    // destroyed task handle only can be freed when alf_api_instance_destroy
      alf_arraylist_remove(alf_instance->ref_task_list, task_handle);
    }
    // dequeue task handle from alf handle task list
    alf_arraylist_remove(alf_handle->task_list, task_handle);
#endif
    // finished or detroyed task handle, decrease task_handle_num of alf_handle
    ALF_GC_ALF_HANDLE_SIG(alf_handle);	 //inform API that all task handle has been processed, GC will leave.
  }

  //destroy task work blocks
  alf_sched_task_wb_free(task_handle);

  //destroy wb pool
  if (NULL != task_handle->wb_pool) {
    alf_wbpool_destroy(task_handle->wb_pool);
    task_handle->wb_pool = NULL;
  }

  // free mirror task_info associated with task_handle
  // real task_info will be release by task_desc_destroy
  if (NULL != task_handle->task_info) {
    //free pal arch tinfo
    if( NULL != task_handle->task_info->pal.p_arch_tinfo ) {
      free(task_handle->task_info->pal.p_arch_tinfo);
      task_handle->task_info->pal.p_arch_tinfo = NULL;
      _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task info free succeed\n");
    }

    //free context desc
    if( NULL != task_handle->task_info->pal.context_desc ) {
      free_align(task_handle->task_info->pal.context_desc);
      task_handle->task_info->pal.context_desc = NULL;
      _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task info free succeed\n");
    }

    //free dependency list 
    if ( NULL != task_handle->child_tasks) {
      alf_arraylist_destroy(task_handle->child_tasks);
      task_handle->child_tasks = NULL;
      _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task child list free succeed\n");
    }
  
    free(task_handle->task_info);
    task_handle->task_info = NULL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task event handler data free succeed\n");
  }

  //destroy task wbq 
  if ( NULL != task_handle->task_wbq) {
    alf_arraylist_destroy_nl(task_handle->task_wbq);
    task_handle->task_wbq = NULL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task wbq free succeed\n");
  }

  //free each accel wbq and accel wbq ptr array 
  if (NULL != task_handle->accel_wbq) {
    for (i = 0; i < (int) task_handle->num_accel_req; i++) {
      if (NULL != task_handle->accel_wbq[i]) {
        task_handle->accel_wbq[i] = NULL;
        _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task accel wbq free succeed\n");
      }else
        break;
    }
    free(task_handle->accel_wbq);
    task_handle->accel_wbq = NULL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task accel wbq ptr free succeed\n");
  }

  //free each accel garbage wbq and ptr array
  if (NULL != task_handle->accel_fin_wbq) {
    for (i = 0; i < (int) task_handle->num_accel_req; i++) {
      if (NULL != task_handle->accel_fin_wbq[i]) {
        alf_arraylist_destroy(task_handle->accel_fin_wbq[i]);
        task_handle->accel_fin_wbq[i] = NULL;
        _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task accel wbq free succeed\n");
      }else
        break;
    }

    free(task_handle->accel_fin_wbq);
    task_handle->accel_fin_wbq = NULL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task accel fin wbq ptr free succeed\n");
  }

  //free task thread array
  if (NULL != task_handle->p_task_threads) {
    free(task_handle->p_task_threads);
    task_handle->p_task_threads = NULL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task thread ptr free succeed\n");
  }
		
  //free thread context buffer
  if (NULL != task_handle->p_thread_context) {
    free_align(task_handle->p_thread_context);
    task_handle->p_thread_context = NULL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task thread context free succeed\n");
  }
		
  //free event handler data
  if (NULL != task_handle->event_handler.p_data) {
    free(task_handle->event_handler.p_data);
    task_handle->event_handler.p_data = NULL;
   _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task event handler data free succeed\n");
  }

  // destroyed task handle will be hold in task handle hash
  // only finished task handle in scheduler and task handle in API is freed
  if (rtn == 0) {
#ifndef _ALF_PLATFORM_HYBRID_
    pthread_mutex_destroy(&task_handle->lock);
    pthread_cond_destroy(&task_handle->cond);
  
    free(task_handle);
#endif
  }
}


void alf_sched_task_wb_count_dec(alf_api_task_t * task_handle)
{
  pthread_mutex_lock(&task_handle->lock);
  task_handle->num_wb_pending--;
  pthread_mutex_unlock(&task_handle->lock);
}

int alf_sched_task_wbq_create(alf_api_task_t * task_handle)
{
  unsigned int i;
  //for non-fixed mapping
  //the number of accel wbq can only be decided after thread allocated
  if (!(task_handle->attr & ALF_TASK_ATTR_SCHED_FIXED))
  {
    //for bundled wb, we need to create accel wbq to buffer wb in one bundle
    if(task_handle->wb_dist_size > 1) {
      for (i = 0; i < task_handle->num_accels; i++) {
        if (NULL == task_handle->accel_wbq[i]) {
          task_handle->accel_wbq[i] = alf_arraylist_create_nl(task_handle->wb_dist_size);
          if (NULL == task_handle->accel_wbq[i]) {
            return -ALF_ERR_NOMEM;
          }
        }
        else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task accel wbq allocate succeed\n");
      }
    }
    //garbage queue is always needed
    for (i = 0; i < task_handle->num_accels; i++) {
      if (NULL == task_handle->accel_fin_wbq[i]) {
        task_handle->accel_fin_wbq[i] = alf_arraylist_create(_ALF_API_ACCEL_WB_QUEUE_LEN);
        if (NULL == task_handle->accel_fin_wbq[i]) {
          return -ALF_ERR_NOMEM;
        }
      }
      else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task accel fin wbq allocate succeed\n");
    }
  }
  return 0;
}

int alf_api_task_wbq_create(alf_api_task_t * task_handle)
{
  unsigned int num_accelerators = task_handle->num_accel_req;
  unsigned int i;

  task_handle->accel_wbq = (alf_arraylist_nl_t **) calloc(num_accelerators, sizeof(alf_arraylist_nl_t *));

  if (NULL == task_handle->accel_wbq) {
    return -ALF_ERR_NOMEM;
  }
  else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task accel wbq ptr allocate succeed\n");

  task_handle->accel_fin_wbq = (alf_arraylist_t **) calloc(num_accelerators, sizeof(alf_arraylist_t *));

  if (NULL == task_handle->accel_fin_wbq) {
    return -ALF_ERR_NOMEM;
  }
  else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task accel fin wbq ptr allocate succeed\n");

  if (task_handle->attr & ALF_TASK_ATTR_WB_CYCLIC) {
    //for cyclic distribution, create accel wbq when task created
    for (i = 0; i < num_accelerators; i++) {
      task_handle->accel_wbq[i] = alf_arraylist_create_nl(_ALF_API_ACCEL_WB_QUEUE_LEN);
      if (NULL == task_handle->accel_wbq[i]) {
        return -ALF_ERR_NOMEM;
      }
      else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task accel wbq allocate succeed\n");
      //also create garbage queue
      task_handle->accel_fin_wbq[i] = alf_arraylist_create(_ALF_API_ACCEL_WB_QUEUE_LEN);
      if (NULL == task_handle->accel_fin_wbq[i]) {
        return -ALF_ERR_NOMEM;
      }
      else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task fin accel wbq allocate succeed\n");
    }
  } else {
    //for non-cyclic distribution, create task wbq when task created
    task_handle->task_wbq = alf_arraylist_create_nl(_ALF_API_ACCEL_WB_QUEUE_LEN);
    if (NULL == task_handle->task_wbq) {
      return -ALF_ERR_NOMEM;
    }
    else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task wbq allocate succeed\n");
    if (task_handle->attr & ALF_TASK_ATTR_SCHED_FIXED) 
    {
      if( task_handle->wb_dist_size > 1) {
        //for bundled wb, we need to create accel wbq to buffer wb in one bundle
        //for fixed mapping we can create the accel wbq when task created
        //since we can know the number of accels at this time
        for (i = 0; i < num_accelerators; i++) {
          task_handle->accel_wbq[i] = alf_arraylist_create_nl(task_handle->wb_dist_size + 1);
          if (NULL == task_handle->accel_wbq[i]) {
            return -ALF_ERR_NOMEM;
          }
          else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task accel wbq allocate succeed\n");
        }
      }
      //create garbage queue
      for (i = 0; i < num_accelerators; i++) {
        task_handle->accel_fin_wbq[i] = alf_arraylist_create(_ALF_API_ACCEL_WB_QUEUE_LEN);
        if (NULL == task_handle->accel_fin_wbq[i]) {
          return -ALF_ERR_NOMEM;
        }
        else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task accel fin wbq allocate succeed\n");
      }
    }
  }
  return 0;
}

int alf_api_task_offspring_destroy(alf_api_task_t * task_handle, alf_arraylist_t* tasks)
{
  int child_num;
  int i;
  int ret = 0;

  alf_api_task_t *child_task;
  
  pthread_mutex_lock(&task_handle->lock);
  //for tasks not finished or destroyed
  if (task_handle->state <= ALF_API_TASK_STATUS_EXEC) {
    if (NULL != tasks && task_handle->state == ALF_API_TASK_STATUS_EXEC) 
      alf_arraylist_enqueue(tasks, task_handle);

    task_handle->state = ALF_API_TASK_STATUS_DESTROY;
    alf_int_task_call_event_handler(task_handle, ALF_TASK_EVENT_DESTROY);

#ifdef _ALF_PLATFORM_HYBRID_
    if (task_handle->dataset != NULL)
      _ALF_API_DEC_DATASET_TASK_COUNT(task_handle);
#endif

    child_num = alf_arraylist_get_length(task_handle->child_tasks);
    for (i = 0; i < child_num; i++) {
      child_task = alf_arraylist_dequeue(task_handle->child_tasks);
      alf_api_task_offspring_destroy(child_task, tasks);
    }
  } else if (task_handle->state >= ALF_API_TASK_STATUS_DESTROY ) {
    ret = -ALF_ERR_SRCH;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task already destroyed\n");
  } 
  //do nothing for finished task
  pthread_mutex_unlock(&task_handle->lock);
  return ret;
}

int alf_int_task_call_event_handler(alf_api_task_t * task_handle, ALF_TASK_EVENT_TYPE_T event)
{
  if (task_handle->event_handler.event_mask & event && 
      task_handle->event_handler.callback_func != NULL) {
    return (int) (*task_handle->event_handler.callback_func)
                 (task_handle->self, event, task_handle->event_handler.p_data);
  }
  return 0;
}

ALF_ERR_POLICY_T  alf_err_default_error_handler(void *p_context_data  DECLARE_UNUSED, ALF_ERR_TYPE_T error_type, int error_code, char *error_string)
{
    // I need not to check parms here as you will see
    switch(error_type)
    {
        case ALF_ERR_WARNING:   // warnings shall be ignored
            if(error_string)
                fprintf(stderr, "ALF runtime warning: %d '%s'\n", error_code, error_string);
            else
                fprintf(stderr, "ALF runtime warning: %d\n", error_code);
            return ALF_ERR_POLICY_IGNORE;
            
        case ALF_ERR_EXCEPTION: // exceptions shall abort by default
            if(error_string)
                fprintf(stderr, "ALF runtime exception: %d '%s'\n", error_code, error_string);
            else
                fprintf(stderr, "ALF runtime exception: %d\n", error_code);
            return ALF_ERR_POLICY_ABORT;

        case ALF_ERR_FATAL:     // we have no choice but abort
            if(error_string)
                fprintf(stderr, "ALF runtime error: %d '%s'\n", error_code, error_string);
            else
                fprintf(stderr, "ALF runtime error: %d\n", error_code);
            return ALF_ERR_POLICY_ABORT;

         default:               // if we are called wrongly
             fprintf(stderr, "ALF runtime internal error: unexpected error_type %d \n", error_type);
             return ALF_ERR_POLICY_ABORT;
    }
    // we need no return here, zombie code
}

int alf_api_task_info_copy(alf_api_task_t* task_handle, alf_api_task_info_t* task_info, 
                       void *p_task_context_data)
{
  void *ptmp;
  alf_api_task_info_t* local_task_info;
  /* library, image and comp kernel string could not be null, this is not allowed */
  if(!task_info->pal.api_str[ALF_API_KERNEL_COMP_KERNEL][0] ||
     !task_info->pal.api_str[ALF_API_KERNEL_IMAGE][0] )
  {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "api str is null: comp_kernel=\"%s\", library=\"%s\", image=\"%s\"\n",task_info->pal.api_str[ALF_API_KERNEL_COMP_KERNEL],task_info->pal.api_str[ALF_API_KERNEL_LIBRARY],task_info->pal.api_str[ALF_API_KERNEL_IMAGE]);
    return -ALF_ERR_NOEXEC;
  }
  //copy task info content
  local_task_info = malloc(sizeof(alf_api_task_info_t));
  if (local_task_info == NULL) 
  {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task info handle allocate memory failed\n");
    return -ALF_ERR_NOMEM;
  }

  memcpy(local_task_info, task_info, sizeof(alf_api_task_info_t));
  task_handle->task_info = local_task_info;

  if(p_task_context_data != NULL && task_info->pal.context_desc_num != 0)
  {

    //store context ptr
    task_handle->p_context = p_task_context_data;

    //copy context desc
    ptmp = malloc_align(task_info->pal.context_desc_num*sizeof(alf_pal_data_entry_desc_t),
                        task_handle->task_info->accel_align);  
    if (ptmp == NULL) {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task ctx desc allocate memory failed\n");
      return -ALF_ERR_NOMEM;
    }
    else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task ctx desc allocate succeed\n");
    task_handle->task_info->pal.context_desc = ptmp;

    memcpy(task_handle->task_info->pal.context_desc, task_info->pal.context_desc,
         task_info->pal.context_desc_num*sizeof(alf_pal_data_entry_desc_t));

    //each accel have a buffer for task context
    task_handle->task_info->pal.task_context_size = _ALF_SIZE_ALIGN_(
                                                   task_handle->task_info->ctx_entry_size,
                                                   task_handle->task_info->accel_align);
    task_handle->p_thread_context = (void *) malloc_align((task_handle->num_accel_req )* 
                                                  task_handle->task_info->pal.task_context_size,
                                                  task_handle->task_info->accel_align);
    if (task_handle->p_thread_context == NULL) {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task thread context allocate memory failed\n");
      return -ALF_ERR_NOMEM;
    }
    else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task thread ptr allocate succeed\n");
  }
  else 
  {
    task_handle->task_info->pal.context_desc = NULL;
    task_handle->task_info->pal.context_desc_num = 0;
    task_handle->task_info->pal.task_context_size = 0;
  }
  return 0;  
}

//---------------------------------------------------------------------------------------------------
// alf_api_task_dump
//---------------------------------------------------------------------------------------------------

void alf_api_task_dump(char *prefix, alf_api_task_t * task)
{
  printf("%salf_api_task_t=%p\n", prefix, task);
  printf("%s\tself=%llu\n", prefix, task->self);
  printf("%s\talf_handle=%p\n", prefix, task->alf_handle);
  printf("%s\tnext_ptr=%p\n", prefix, task->next_ptr);
  printf("%s\tattr=%u\n", prefix, task->attr);
  printf("%s\twb_dist_size=%u\n", prefix, task->wb_dist_size);
  printf("%s\tnum_accel_req=%u\n", prefix, task->num_accel_req);
  printf("%s\tstate=%d\n", prefix, task->state);
  printf("%s\tfinalized_flag=%d\n", prefix, task->finalized_flag);
  printf("%s\task_wbq=%p\n", prefix, task->task_wbq);
  printf("%s\taccel_wbq=%p\n", prefix, task->accel_wbq);
  printf("%s\taccel_fin_wbq=%p\n", prefix, task->accel_fin_wbq);
  printf("%s\tparent_count=%u\n", prefix, task->parent_count);
  printf("%s\tchild_tasks=%p\n", prefix, task->child_tasks);
  printf("%s\tdist_num=%u\n", prefix, task->dist_num);
  printf("%s\tcur_accel=%d\n", prefix, task->cur_accel);
  printf("%s\tp_task_threads=%p\n", prefix, task->p_task_threads);
  printf("%s\tnum_accels=%d\n", prefix, task->num_accels);
  printf("%s\tnum_wb_pending=%d\n", prefix, task->num_wb_pending);
  printf("%s\tnum_wb=%d\n", prefix, task->num_wb);
  printf("%s\tdataset=%p\n", prefix, task->dataset);
}

//---------------------------------------------------------------------------------------------------
// alf_api_wb_dump
//---------------------------------------------------------------------------------------------------

void alf_api_wb_dump(char *prefix, alf_api_wb_t * wb)
{
  char prefix_buffer[strlen(prefix)+2];
	
  printf("%salf_api_wb_t=%p\n", prefix, wb);
  
  if (wb == NULL) {
  	return;
  }
  
  printf("%s\ttask=%llx\n", prefix, wb->task);
  printf("%s\tcur_dtl=%p\n", prefix, wb->cur_dtl);
  printf("%s\tcur_dtl_buffer_type=%d\n", prefix, wb->cur_dtl_buffer_type);

  strcpy(prefix_buffer,prefix);
  strcat(prefix_buffer,"\t");
  
  alf_pal_wb_dump(prefix_buffer,&wb->pal);
}

//---------------------------------------------------------------------------------------------------
// alf_api_dataset_dump
//---------------------------------------------------------------------------------------------------

void alf_api_dataset_dump(char *prefix, alf_api_dataset_t * dataset)
{
  unsigned int i;

  /* Lock the data set before updating and accessing it */
  pthread_mutex_lock(&dataset->lock);

  printf("%salf_api_dataset_t=%p\n", prefix, dataset);
  printf("%s\tapi_handle=%p\n", prefix, dataset->api_handle);
  printf("%s\tstate=%d\n", prefix, dataset->state);

  /* For each buffer */
  printf("%s\tbuffers=%p\n", prefix, dataset->buffers);
  for (i = 0; i < alf_arraylist_get_length(dataset->buffers); i++) {

    /* Get data set buffer address */
    alf_api_dataset_buffer_t *dataset_buffer =
        (alf_api_dataset_buffer_t *) alf_arraylist_get_element(dataset->buffers, i);

    printf("%s\tdataset_buffer=%p: addr=0x%016llx, size=0x%016llx, access_mode=%d\n", prefix, dataset_buffer, dataset_buffer->addr, dataset_buffer->size, dataset_buffer->access_mode);

  }

  printf("%s\tpal_dataset=%p\n", prefix, dataset->pal_dataset);

  if (dataset->pal_dataset != NULL) {
  	char prefix_buffer[strlen(prefix)+2];

    strcpy(prefix_buffer,prefix);
    strcat(prefix_buffer,"\t");
  
    alf_pal_dataset_dump(prefix_buffer, dataset->pal_dataset);
  }

  /* Unlock data set object */
  pthread_mutex_unlock(&dataset->lock);

}

int alf_api_dtl_begin(alf_api_wb_t *wb,ALF_BUF_TYPE_T buffer_type, alf_data_uint64_t local_offset)
{

  if(wb->dtl_entry_num >= ALF_PAL_MAX_DTL_NUM_ENTRY)
    return -ALF_ERR_NOMEM; 

  wb->dtl[wb->dtl_ele_num].header.buffer_type = buffer_type;
  wb->dtl[wb->dtl_ele_num].header.local_offset = local_offset;
  wb->cur_dtl = &wb->dtl[wb->dtl_ele_num]; 
  wb->dtl_ele_num++; 
  
  wb->cur_dtl->header.num_entries = 0;

  return 0;  
}

int alf_api_dtl_entry_add(alf_api_wb_t *wb,unsigned int size,alf_data_addr64_t address, ALF_DATA_TYPE_T data_type)
{
  if(wb->dtl_entry_num >= ALF_PAL_MAX_DTL_NUM_ENTRY)
    return -ALF_ERR_NOMEM; 
  
  wb->dtl[wb->dtl_ele_num].entry.size = size;
  wb->dtl[wb->dtl_ele_num].entry.data_type = data_type;
  wb->dtl[wb->dtl_ele_num].entry.address = address;
 
  wb->cur_dtl->header.num_entries++; 
  wb->dtl_ele_num++; 
  wb->dtl_entry_num++; 

  return 0;
}

void alf_api_dtl_end(alf_api_wb_t *wb)
{

  if( wb->cur_dtl != NULL  && wb->cur_dtl->header.num_entries == 0 )
  {
    //current dtl do not have entry
    //so roll back 
    wb->dtl_ele_num--; 
  }
  
  //set last element as tail
  wb->dtl[wb->dtl_ele_num].header.num_entries = 0;
}
void *alf_api_dtl_pool_create(unsigned int dtlist_size)
{
  alf_api_dtl_pool_t *pool = NULL;
  pool = calloc(1,sizeof(alf_api_dtl_pool_t));
  if(pool == NULL) 
    return NULL;  
  
  pool->free_dtlists = calloc(_ALF_API_DTLIST_NUM , sizeof(void *)); 
  
  if(pool->free_dtlists == NULL) 
    goto err;  

  pool->used_dtlists = calloc(_ALF_API_DTLIST_NUM , sizeof(void *)); 
  
  if(pool->used_dtlists == NULL) 
    goto err;  
  
  pool->capacity = _ALF_API_DTLIST_NUM;
 
  pool->entry_size = dtlist_size;

  pthread_mutex_init(&pool->lock,NULL);

  return pool; 

err:
  if(pool != NULL)
  {
    if(pool->free_dtlists != NULL)
      free(pool->free_dtlists);
    free(pool);
  }
  return NULL;

}

void alf_api_dtl_pool_destroy(alf_api_dtl_pool_t *pool)
{
  int i;
  int index;
  
  if(pool == NULL)
    return;

  if(pool->free_dtlists != NULL)
  {
    for(i=0;i<pool->capacity;i++)
    {
      index = (pool->free_head + i) % pool->capacity;
      if(pool->free_dtlists[index] != NULL)
      {
        free(pool->free_dtlists[index]);
        pool->free_dtlists[index] = NULL;
      }
      else break;
    }
    free(pool->free_dtlists);
    pool->free_dtlists = NULL;
  }

  if(pool->used_dtlists != NULL)
  {
    for(i=0;i<pool->capacity;i++)
    {
      if(pool->used_dtlists[i] != NULL)
      {
        free(pool->used_dtlists[i]);
        pool->used_dtlists[i] = NULL;
      }
    }
    free(pool->used_dtlists);
  }
 
  pthread_mutex_destroy(&pool->lock);
  free(pool); 
}
void *alf_api_dtl_alloc(alf_api_dtl_pool_t *pool)
{
  void *new_ptr = NULL;
  int i,j;
  int index;
  pthread_mutex_lock(&pool->lock);
  //first try to reuse dtl in free dtlists
  for(i=0;i<pool->capacity;i++)
  {
     index = (pool->free_head + i) % pool->capacity;
    if(pool->free_dtlists[index] != NULL)
    {
      //free dtlists is a loop queue
      //always get from the head and put to the tail
      for(j=0;j<pool->capacity;j++)
      {
        if(pool->used_dtlists[j] == NULL)
        {
          pool->used_dtlists[j] = pool->free_dtlists[index];
          pool->free_dtlists[index] = NULL;
          pool->free_head = (pool->free_head + 1) % pool->capacity;
          new_ptr = pool->used_dtlists[j];
          pthread_mutex_unlock(&pool->lock);
          return new_ptr;
        }
      }
    }
    else break;
  }

  //no free dtl can be reused, request memory from OS
  //need to check every entry until find an empty one
  //since empty entry and non-empty entry maybe overlapped
  for(i=0;i<pool->capacity;i++)
  {
     if(pool->used_dtlists[i] == NULL)
     {
       new_ptr = calloc(1,pool->entry_size);
       if(new_ptr == NULL) 
       {
         pthread_mutex_unlock(&pool->lock);
         return NULL;
       }
       pool->used_dtlists[i] = new_ptr;
       pthread_mutex_unlock(&pool->lock);
       return new_ptr;
     }  
  }
 
  //used dtlists is full, try to enlarge it linearly 
  new_ptr = realloc(pool->used_dtlists,(pool->capacity + _ALF_API_DTLIST_NUM ) * sizeof(void*));
  
  if(new_ptr == NULL) 
  {
    pthread_mutex_unlock(&pool->lock);
    return NULL;
  }

  pool->used_dtlists = new_ptr;
  memset(&pool->used_dtlists[pool->capacity], 0, _ALF_API_DTLIST_NUM*sizeof(void*)); 
  new_ptr = NULL;

  //always enlarge free dtlists as the same size at this time 
  new_ptr = realloc(pool->free_dtlists,(pool->capacity + _ALF_API_DTLIST_NUM ) * sizeof(void*));
  if(new_ptr == NULL) 
  {
    pthread_mutex_unlock(&pool->lock);
    return NULL;
  }
  pool->free_dtlists = new_ptr;
  memset(&pool->free_dtlists[pool->capacity], 0, _ALF_API_DTLIST_NUM*sizeof(void*)); 
  new_ptr = NULL;
  
  new_ptr = calloc(1,pool->entry_size);
  if(new_ptr == NULL) 
  {
    pthread_mutex_unlock(&pool->lock);
    return NULL;
  }
 
  pool->used_dtlists[pool->capacity] = new_ptr;
  pool->capacity += _ALF_API_DTLIST_NUM;
  
  pthread_mutex_unlock(&pool->lock);
  return new_ptr;
}
void alf_api_dtl_free(alf_api_dtl_pool_t *pool,void *dtlist)
{
  int i,index;
  if(pool == NULL || dtlist == NULL)
    return;
  
  pthread_mutex_lock(&pool->lock);
  //remove from used dtlists
  for(i=0;i<pool->capacity;i++)
  {
    if(pool->used_dtlists[i] == dtlist)
    {
      pool->used_dtlists[i] = NULL; 
      break;
    }
  }
  //put into free dtlists
  //should not be full since it has the same size as used dtlists
  for(i=0;i<pool->capacity;i++)
  {
    index = (pool->free_tail + i ) % pool->capacity;
    if(pool->free_dtlists[index] == NULL)
    {
      pool->free_dtlists[index] = dtlist;
      pool->free_tail = (pool->free_tail + 1) % pool->capacity; 
      break;
    }
  }
  pthread_mutex_unlock(&pool->lock);
}

/* init alf instance resources include:
 * alf pal
 * alf accel pal
 * 5 task lists
 * alf handle list
 * lock & cond
 * scheduler thread 
 */
int alf_api_instance_init(alf_instance_t* alf_instance, void* sys_config_info)
{
  int rtn = 0;

  alf_instance->gc_flag = 0;

  //init the scheduler wakeup condition variable
  pthread_cond_init(&alf_instance->task_cond, NULL);

  //pal init
  rtn = alf_pal_init(sys_config_info, &alf_instance->platform_handle);
  if (rtn != 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf pal init failed\n");
    return rtn;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf pal allocate succeed\n");

  //pal error handler register
  rtn = alf_pal_error_handler_register(alf_instance->platform_handle,
                                       &alf_err_pal_error_handler,(void *)alf_instance);
  if (rtn != 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf pal error handler register failed\n");
    return rtn;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf pal error handler register succeed\n");

  rtn = alf_pal_query(alf_instance->platform_handle, ALF_PAL_Q_NUM_ACCELS, 
                      &alf_instance->max_thread_num);
  if (rtn != 0) {
    return rtn;
  } else if (alf_instance->max_thread_num == 0) {
    rtn = -ALF_ERR_NODATA;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "number of accelerators is zero\n");
    return rtn;
  }

  //allocate once for maximum number of threads
  rtn = alf_thread_mgr_setup(alf_instance, alf_instance->max_thread_num);
  if (rtn < 0)                  // failure
  {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf threadpool allocate failed\n");
    return rtn;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf threadpool allocate succeed\n");
  
  //create alf handle list
  alf_instance->alf_handle_list = alf_arraylist_create(_ALF_API_HANDLE_NUM);
  if (alf_instance->alf_handle_list == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf create handle list failed\n");
    return rtn;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf handle list allocate succeed\n");

  //create task list
  alf_instance->init_task_list = alf_arraylist_create(_ALF_API_TASK_QUEUE_LEN);
  if (alf_instance->init_task_list == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf create init task list failed\n");
    return rtn;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf init list allocate succeed\n");

  alf_instance->ready_task_list = alf_arraylist_create(_ALF_API_TASK_QUEUE_LEN);
  if (alf_instance->ready_task_list == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf create ready task list failed\n");
    return rtn;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf ready list allocate succeed\n");

  alf_instance->exec_task_list = alf_arraylist_create(alf_instance->max_thread_num);
  if (alf_instance->exec_task_list == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf create exec task list failed\n");
    return rtn;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf exec list allocate succeed\n");

  alf_instance->destroy_task_list = alf_arraylist_create(_ALF_API_TASK_QUEUE_LEN);
  if (alf_instance->destroy_task_list == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf create destroy task list failed\n");
    return rtn;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf destroy list allocate succeed\n");

  alf_instance->ref_task_list = alf_arraylist_create(_ALF_API_TASK_QUEUE_LEN);
  if (alf_instance->ref_task_list == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf create ref task list failed\n");
    return rtn;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf ref list allocate succeed\n");
  
  //create error msg list
  alf_instance->err_msg_list = alf_arraylist_create(_ALF_API_ERR_NUM);
  if (alf_instance->err_msg_list == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf create err list failed\n");
    return rtn;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf err list allocate succeed\n");
  //init cond & lock
  rtn = pthread_mutex_init(&alf_instance->lock, NULL);
  if (rtn != 0) {
    rtn = -ALF_ERR_GENERIC;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf handle lock init failed\n");
    return rtn;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf lock init succeed\n");

  rtn = pthread_mutex_init(&alf_instance->err_lock, NULL);
  if (rtn != 0) {
    rtn = -ALF_ERR_GENERIC;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf err lock init failed\n");
    return rtn;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf err lock init succeed\n");

  rtn = pthread_cond_init(&alf_instance->cond, NULL);
  if (rtn != 0) {
    rtn = -ALF_ERR_GENERIC;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, " alf handle cond init failed\n");
    return rtn;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf cond init succeed\n");
  //create scheduler thread,all memory allocation should be done before it
  rtn = pthread_create(&alf_instance->scheduler, NULL, alf_api_scheduler, alf_instance);
  if (rtn != 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf scheduler init failed\n");
    return rtn;
  }
  alf_instance->scheduler_active = 1;

  return rtn;
}

/* destroy alf runtime resources include:
 * alf handle
 * alf pal
 * alf accel pal
 * 5 task lists
 * lock & cond
 * all task handle
**/
void alf_api_instance_destroy(alf_instance_t* alf_instance)
{
  alf_api_task_t *task_handle;

  if (NULL != alf_instance) {
    //cancel scheduler thread
    if(alf_instance->scheduler_active != 0 )
    {
      pthread_cancel(alf_instance->scheduler);
      pthread_join(alf_instance->scheduler,NULL);
      alf_instance->scheduler_active = 0;
    }

    // destroy all destroyed task list
    if(alf_instance->ref_task_list != NULL)
    {
      while (NULL != (task_handle = alf_arraylist_dequeue(alf_instance->ref_task_list))) {
        pthread_mutex_destroy(&task_handle->lock);
        _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task lock free succeed\n");
        pthread_cond_destroy(&task_handle->cond);
        _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task cond free succeed\n");
        free(task_handle);
        _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task handle free succeed\n");
      }
    }

    //destroy pal thread
    alf_thread_mgr_cleanup(alf_instance);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf threadpool free succeed\n");
    //release accel and pal resources
    if(alf_instance->platform_handle != NULL)
    {
      alf_pal_exit(alf_instance->platform_handle);
      _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf pal free succeed\n");
    }
    //destroy all task lists
    alf_arraylist_destroy(alf_instance->init_task_list);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf init list free succeed\n");
    alf_arraylist_destroy(alf_instance->ready_task_list);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf ready list free succeed\n");
    alf_arraylist_destroy(alf_instance->exec_task_list);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf exec list free succeed\n");
    alf_arraylist_destroy(alf_instance->destroy_task_list);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf destroy list free succeed\n");
    alf_arraylist_destroy(alf_instance->ref_task_list);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf ref list free succeed\n");
    //destroy errro msg list
    alf_arraylist_destroy(alf_instance->err_msg_list);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf err list free succeed\n");
    //destroy lock & cond
    pthread_mutex_destroy(&alf_instance->err_lock);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf err lock free succeed\n");
    pthread_cond_destroy(&alf_instance->cond);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf cond free succeed\n");
    pthread_mutex_destroy(&alf_instance->lock);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf lock free succeed\n");
    //free alf handle
    free(alf_instance);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf handle free succeed\n");
    alf_instance = NULL;
  }
}

/* cancel unfinished tasks when force exit */
int alf_api_task_cancel(alf_api_t *alf_handle)
{
  alf_api_task_t* task_handle;
  int num = 0;
 
  pthread_mutex_lock(&alf_handle->lock); 

  if (alf_handle->task_list == NULL)
    return -ALF_ERR_BADR;

  //destroy unfinished task in task list
  while( NULL != ( task_handle = alf_arraylist_dequeue(alf_handle->task_list) ) )
  {
    pthread_mutex_lock(&task_handle->lock);
    if (task_handle->state <= ALF_API_TASK_STATUS_EXEC) {
      //just mark the state is ok
      //scheduler will do the resource cleanup
      pthread_cond_signal(&task_handle->cond);
      task_handle->state = ALF_API_TASK_STATUS_DESTROY;
      
#ifdef _ALF_PLATFORM_HYBRID_
      if (task_handle->dataset != NULL)
        _ALF_API_DEC_DATASET_TASK_COUNT(task_handle);
#endif

      num++;
    }
    pthread_mutex_unlock(&task_handle->lock);
  }
  pthread_mutex_unlock(&alf_handle->lock);

  return num;
}


/* Hash operation for ALF handle */
int ALF_API_ALF_HANDLE_HASH_INSERT(alf_api_t* alf_handle, alf_handle_t* alf_handle_key)
{
  extern pthread_mutex_t g_alf_handle_bucket_lock;
  extern alf_api_handle_bucket_t g_alf_handle_bucket[ALF_API_ALF_HANDLE_HASH_BUCKET_SIZE];
  extern alf_handle_t g_alf_handle_counter;

  pthread_mutex_lock(&g_alf_handle_bucket_lock);
  
  alf_handle_t handle_index = ALF_API_ALF_HANDLE_HASH_INDEX(g_alf_handle_counter);
  alf_handle_t l_handle_counter = g_alf_handle_counter;

  if (g_alf_handle_counter == (unsigned int)(-1)) {
    pthread_mutex_unlock(&g_alf_handle_bucket_lock);
    return -ALF_ERR_OVERFLOW;
  }	

  g_alf_handle_counter ++;   // Valid Hashed ALF handle start from 0x00000001, 0 stands for ALF_NULL_HANDLE

  alf_api_handle_bucket_t* handle_bucket = &g_alf_handle_bucket[handle_index];
  if (!handle_bucket->init_flag) {
    pthread_mutex_init(&handle_bucket->lock, NULL);
    handle_bucket->init_flag = 1;
  }		

  // make sure alf handle is inserted in order
  pthread_mutex_lock(&handle_bucket->lock);
  pthread_mutex_unlock(&g_alf_handle_bucket_lock);
  	
  alf_api_t *handle_elmnt = handle_bucket->top_ptr, *pre_elmnt = NULL;
  
  alf_handle->next_ptr = NULL;
  alf_handle->self = l_handle_counter;	

  if (handle_bucket->top_ptr == NULL) {
    handle_bucket->top_ptr = alf_handle;
  }else{

    do{
      pre_elmnt = handle_elmnt;
      handle_elmnt = handle_elmnt ->next_ptr;
    }while(handle_elmnt != NULL);
	
    pre_elmnt->next_ptr = alf_handle;
  }
	
  *alf_handle_key = l_handle_counter;		
  pthread_mutex_unlock(&handle_bucket->lock);
	
  return 0;
}

alf_api_t* ALF_API_ALF_HANDLE_HASH_ACQUIRE(alf_handle_t alf_handle_key)
{
  alf_api_t* rtn;
  extern alf_api_handle_bucket_t g_alf_handle_bucket[ALF_API_ALF_HANDLE_HASH_BUCKET_SIZE];
  extern alf_handle_t g_alf_handle_counter;
  extern pthread_mutex_t g_alf_handle_bucket_lock; 
  // ALF_NULL_HANDLE
  CHECK_ALF_HANDLE(alf_handle_key);
	
  alf_handle_t handle_index = ALF_API_ALF_HANDLE_HASH_INDEX(alf_handle_key);
  alf_api_handle_bucket_t* handle_bucket = &g_alf_handle_bucket[handle_index];

  pthread_mutex_lock(&handle_bucket->lock);

  alf_api_t *alf_handle = handle_bucket->top_ptr;

  if (alf_handle == NULL) {
    pthread_mutex_unlock(&handle_bucket->lock);
    return NULL;
  }

  while(alf_handle->next_ptr != NULL && alf_handle->self != alf_handle_key) {
    alf_handle = alf_handle->next_ptr;
  }

  if (alf_handle->self == alf_handle_key)
    rtn = alf_handle;
  else 
    rtn = NULL;

  pthread_mutex_unlock(&handle_bucket->lock);
  return rtn;
}

void ALF_API_ALF_HANLDE_HASH_REMOVE(alf_handle_t alf_handle_key)
{
  extern alf_api_handle_bucket_t g_alf_handle_bucket[ALF_API_ALF_HANDLE_HASH_BUCKET_SIZE];

  if (alf_handle_key == ALF_NULL_HANDLE) 
    return;

  alf_handle_t handle_index = ALF_API_ALF_HANDLE_HASH_INDEX(alf_handle_key);
  alf_api_handle_bucket_t* handle_bucket = &g_alf_handle_bucket[handle_index];

  pthread_mutex_lock(&handle_bucket->lock);

  alf_api_t *alf_handle = handle_bucket->top_ptr, *pre_handle = NULL;

 // find the right element
  while(alf_handle->next_ptr != NULL && alf_handle->self != alf_handle_key) {
    pre_handle = alf_handle;
    alf_handle = alf_handle->next_ptr;
  }

  if (pre_handle == NULL) {  // only one entry
    handle_bucket->top_ptr = NULL;
  }else{                   // remove the element
    pre_handle->next_ptr = alf_handle->next_ptr;
  }

  pthread_mutex_unlock(&handle_bucket->lock);
}

int ALF_API_TASK_HASH_CREATE(alf_api_t* alf_handle)
{
  /* task handle HT creation */
  alf_handle->task_handle_bucket = calloc(sizeof(alf_api_task_bucket_t), ALF_API_TASK_HANDLE_HASH_BUCKET_SIZE);
  if (alf_handle->task_handle_bucket  == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf create task handle hash failed\n");
    return -ALF_ERR_NOMEM;
  }	
  
  alf_handle->task_handle_counter = 1;  // task_handle_counter as 0 means ALF_NULL_HANDLE		
  alf_handle->task_handle_num = 0;
	
  return 0;  
}

/* Hash operation for task handle */
int ALF_API_TASK_HASH_INSERT(alf_api_t* alf_handle, alf_api_task_t* task_handle, alf_task_handle_t* task_handle_key)
{
  pthread_mutex_lock(&alf_handle->lock);
	
  alf_task_handle_t task_counter = alf_handle->task_handle_counter;

  if (task_counter == (unsigned int)(-1)) {
    pthread_mutex_unlock(&alf_handle->lock);
    return -ALF_ERR_OVERFLOW;	
  }
	
  alf_task_handle_t handle_index = ALF_API_TASK_HANDLE_HASH_INDEX(task_counter);
  alf_handle->task_handle_counter ++;  // task counter start from 1, 0 means ALF_NULL_HANDLE
  alf_handle->task_handle_num ++;      
	
  alf_api_task_bucket_t *task_bucket = &alf_handle->task_handle_bucket[handle_index];
  if (!task_bucket->init_flag ) {
    pthread_mutex_init(&task_bucket->lock, NULL);
    task_bucket->init_flag = 1;
  }

  // insure the task handle is inserted in order
  pthread_mutex_lock(&task_bucket->lock);
  pthread_mutex_unlock(&alf_handle->lock);

  if (task_bucket->top_ptr == NULL) {
    task_bucket->top_ptr = task_handle;
  }else{
  
    alf_api_task_t *l_task_handle = task_bucket->top_ptr, *pre_handle = NULL;

    do{
      pre_handle = l_task_handle;
      l_task_handle = l_task_handle->next_ptr;
    }while(l_task_handle != NULL); 

    pre_handle->next_ptr = task_handle;
  }

  *task_handle_key = ALF_API_TASK_MAKE_HANDLE(alf_handle->self, task_counter);
  task_handle->self = *task_handle_key;
  task_handle->next_ptr = NULL;

  pthread_mutex_unlock(&task_bucket->lock);
  return 0;
}

// search the task handle Hash table 
// return matached task handle or NULL 
// if a task handle is found, lock this task handle reference
// return value:
//  -ALF_ERR_NODATA: task handle is finished
//  -ALF_ERR_RANGE: task handle is invalid
//  0: task handle is referenced by API
int ALF_API_TASK_HASH_ACQUIRE(alf_task_handle_t task_handle_key, alf_api_task_t **p_task_handle)
{
  int rtn = 0;

  alf_handle_t alf_handle_key = ALF_API_GET_ALF_HANDLE(task_handle_key);
  alf_api_t *alf_handle = ALF_API_ALF_HANDLE_HASH_ACQUIRE(alf_handle_key);

  *p_task_handle = NULL;
  CHECK_TASK_HANDLE(alf_handle, task_handle_key)

  alf_task_handle_t handle_index = ALF_API_TASK_HANDLE_HASH_INDEX(task_handle_key);
  alf_api_task_bucket_t *task_bucket = &alf_handle->task_handle_bucket[handle_index];

  pthread_mutex_lock(&task_bucket->lock);

  alf_api_task_t* task_handle = task_bucket->top_ptr;
  if (task_handle == NULL) {
    pthread_mutex_unlock(&task_bucket->lock);
    *p_task_handle = NULL;
    rtn = -ALF_ERR_NODATA;           // task_handle must be finished
    return rtn;
  }

  while (task_handle->next_ptr != NULL && task_handle->self != task_handle_key) {
   task_handle = task_handle->next_ptr;
  }
  
  if (task_handle->self == task_handle_key) {

    // lock task handle to protect the reference by API
    pthread_mutex_lock(&task_handle->gc_lock);
    // unlock task_bucket
    pthread_mutex_unlock(&task_bucket->lock);
    
    // searched task handle
    task_handle->ref_num ++;
    pthread_mutex_unlock(&task_handle->gc_lock);
   
    *p_task_handle = task_handle;        // searched task_handle
    rtn = 0;
  }else{
    // not acquired, must have be removed
    pthread_mutex_unlock(&task_bucket->lock);    // task_handle must be finished 
    *p_task_handle = NULL;
    rtn = -ALF_ERR_NODATA;
  }
  
  return rtn;
}

// decrease ref_num so that gc can do something.
void ALF_API_TASK_HASH_RESTORE(alf_api_task_t *task_handle)
{
  pthread_mutex_lock(&task_handle->gc_lock);
  task_handle->ref_num --;
  pthread_mutex_unlock(&task_handle->gc_lock);
}

// this function will lock the task_bucket until task handle is freed
// return value:
//  -ALF_ERR_PERM: task handle is referenced by API
//  -ALF_ERR_BADF: destroyed task handle
//  0: task handle will be released
int ALF_API_TASK_HASH_REMOVE(alf_api_t* alf_handle, alf_task_handle_t task_handle_key)
{
  int rtn;

  alf_task_handle_t handle_index = ALF_API_TASK_HANDLE_HASH_INDEX(task_handle_key);
  alf_api_task_bucket_t *task_bucket = &alf_handle->task_handle_bucket[handle_index];

  pthread_mutex_lock(&task_bucket->lock);

  alf_api_task_t* task_handle = task_bucket->top_ptr;
  alf_api_task_t* pre_handle = NULL;

  // find the right element
  while (task_handle->next_ptr != NULL && task_handle->self != task_handle_key) {
    pre_handle = task_handle;
    task_handle = task_handle->next_ptr;
  }

  pthread_mutex_lock(&task_handle->gc_lock);  
  if (!task_handle->ref_num) {  // protect a reference in API from being released  
  
    if (task_handle->state == ALF_API_TASK_STATUS_FINISH) {  
      if (pre_handle == NULL) 
        task_bucket->top_ptr = NULL;
      else
        pre_handle->next_ptr = task_handle->next_ptr;

      rtn = 0;
    }else{
      rtn = -ALF_ERR_BADF;          // destroyed task_handle
    }
  }else{   // this task handle is referenced by API, can not be released!
    rtn = -ALF_ERR_PERM;
  }
	
  pthread_mutex_unlock(&task_bucket->lock);
  pthread_mutex_unlock(&task_handle->gc_lock);

  return rtn;
}

void ALF_API_TASK_HASH_DESTROY(alf_api_t* alf_handle)
{
  free(alf_handle->task_handle_bucket);
}
