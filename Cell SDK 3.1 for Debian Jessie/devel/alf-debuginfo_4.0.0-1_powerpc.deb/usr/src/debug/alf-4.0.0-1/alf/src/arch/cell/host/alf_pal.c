/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pthread.h>
#include <libmisc.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <dirent.h>

#include <alf.h>
#include <alf_errno.h>
#include "alf_misc_ppu.h"
#include "alf_pal_internal.h"
#include "alf_debug.h"

static pthread_mutex_t g_callback_lock = PTHREAD_MUTEX_INITIALIZER;
static int g_callback;

//********************************************************
// Global Data Structure
//********************************************************

//********************************************************
// APIs
//********************************************************

//--------------------------------------------------------
// Framework APIs
//--------------------------------------------------------


/**
 * ALF PAL system configuration information query routine.
 *   This function queries the platform abstraction layer for various values 
 *   which can be used to control later functions.  For example, the number of 
 *   accelerators can be queried and this number can be used to reserve some 
 *   accelerators.
 *
 * Parameters:
 *   platform_handle [in]     the platform-handle that points to a platform 
 *                            runtime instance.
 *   selector [in] 	      the selector specifying which value to be queried.
 *   result [in/out]	      the address of the result to be set.  Upon 
 *                            success, the result is set to the value of the 
 *                            query.  Upon failure, the value is set to zero.
 *
 * Returns:
 *   = 0 	success, the platform has been queried.
 *   < 0	failure
 *     ALF_ERR_INVAL 	invalid arguments or query selector
 *     ALF_ERR_BADF	invalid platform handle
 */
int alf_pal_query(alf_pal_handle platform_handle, ALF_PLATFORM_QUERY_SELECTOR selector, unsigned int *result)
{
  long long mem_size;
  alf_pal_descriptor_t *p_alf_pal_desc;
  int ret = 0;

#ifdef _ALF_CFG_CHECK_STRICT_
  if (platform_handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF runtime handle pointer\n");
    if(result != NULL)
      *result = 0;
    ret = -ALF_ERR_BADF;
    goto RET;
  }
#endif

  p_alf_pal_desc = (alf_pal_descriptor_t *) platform_handle;
#ifdef _ALF_CFG_CHECK_STRICT_
  if (_alf_pal_check_handle(p_alf_pal_desc) < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF runtime handle\n");
    if(result != NULL)
      *result = 0;
    ret = -ALF_ERR_BADF;
    goto RET;
  }
#endif

  if (result == NULL) {
    ret = 0;
    goto RET;
  }

  switch (selector) {
  case ALF_PAL_Q_NUM_ACCELS:
    {
      *result = spe_count_physical_spes();
    }
    break;
  case ALF_PAL_Q_NUM_ACCELS_EDP:
    {
      if (is_celledp() == 0)
      {
        *result = 0;
      }
      else
      {
        /* Return physical spes if is cell edp */
        *result = spe_count_physical_spes();
      }
    }
    break;
  case ALF_PAL_Q_NUM_ACCELS_AVAIL:
    {
      *result = spe_cpu_info_get(SPE_COUNT_USABLE_SPES, -1);
    }
    break;
  case ALF_PAL_Q_NUM_ACCELS_USED:
    {
      *result = spe_count_physical_spes() - spe_cpu_info_get(SPE_COUNT_USABLE_SPES, -1);
    }
    break;
  case ALF_PAL_Q_HOST_MEM_SIZE:
    {
      mem_size = _alf_get_system_pmem_size();
      if (mem_size < 0) {
        ret = -ALF_ERR_BADF;
      } else {
        *result = (mem_size % (2llu << 42));
      }
    }
    break;
  case ALF_PAL_Q_HOST_MEM_SIZE_EXT:
    {
      mem_size = _alf_get_system_pmem_size();
      if (mem_size < 0) {
        ret = -ALF_ERR_BADF;
      } else {
        *result = (mem_size / (2llu << 42));
      }
    }
    break;
  case ALF_PAL_Q_ACCEL_MEM_SIZE:
    {
      /* SPU local size 256K */
      *result = 0x100;
    }
    break;
  case ALF_PAL_Q_ACCEL_MEM_SIZE_EXT:
    {
      *result = 0;
    }
    break;
  case ALF_PAL_Q_HOST_ADDR_ALIGN:
    {
      *result = 4;
    }
    break;
  case ALF_PAL_Q_ACCEL_ADDR_ALIGN:
    {
      /* accelerator align is 2^4 = 16 */
      *result = 4;
    }
    break;
  case ALF_PAL_Q_DTL_ADDR_ALIGN:
    {
      *result = 4;
    }
    break;
  case ALF_PAL_Q_HOST_ENDIANNESS:
    {
      *result = 1;              /* set result word to 1 for endian check */
      *result = !(*((char *) (result)));        /* compute endianess */
    }
    break;
  case ALF_PAL_Q_ACCEL_ENDIANNESS:
    {
      *result = 1;              // Big endian
    }
    break;
  default:
    {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid query_id:%d\n", selector);
      *result = 0;
      ret = -ALF_ERR_INVAL;
    }
  }

RET:
  return ret;
}


/**
 * ALF PAL init routine.
 *  This function configures and initializes the platform abstraction layer.
 * 
 * Parameters:
 *    config_parms [in] 	the platform-specific configuration parameters 
 *                              or NULL if there are no parameters required for
 *                               the specific platform.
 *
 *    platform_handle [in/out] 	the address of the platform-handle to set.  
 *                              Upon success, the platform-handle is set to the
 *                              platform runtime instance.  Upon failure, the 
 *                              platform-handle is set to NULL.
 *
 * Returns:
 *    = 0 	success, the platform has been initialized.
 *    < 0	failure
 *       ALF_ERR_INVAL	invalid input argument
 *       ALF_ERR_BADF	the configuration information is invalid
 *       ALF_ERR_BADR	no platform resource available
 *       ALF_ERR_PERM	the platform init is not permitted in current context
 */
int alf_pal_init(void* sys_config_info __attribute__ ((unused)), alf_pal_handle * platform_handle)
{

  alf_pal_descriptor_t *p_alf_pal_desc;
  int ret = 0;
#ifdef _ALF_CFG_CHECK_STRICT_
  if (platform_handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF pal runtime handle pointer\n");
    ret = -ALF_ERR_INVAL;
    goto RET;
  }
#endif

   
  pthread_mutex_lock(&g_callback_lock);
  if (g_callback == 0)
  {
    ret = spe_callback_handler_register(&alf_spe_error_callback, _ALF_ERROR_CALLBACK_NUM, SPE_CALLBACK_NEW);
  }
  g_callback++;
  pthread_mutex_unlock(&g_callback_lock);

  p_alf_pal_desc = (alf_pal_descriptor_t *) calloc(1, sizeof(alf_pal_descriptor_t));

  *platform_handle = p_alf_pal_desc;
  if (p_alf_pal_desc == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Init alf_handle error.\n");
    ret = -ALF_ERR_BADR;
    goto RET;
  }

  p_alf_pal_desc->acces = 0;
  p_alf_pal_desc->spe_running = 0;
  p_alf_pal_desc->magic_id = _ALF_HANDLE_T_MAGIC_ID;
  p_alf_pal_desc->state = _ALF_PAL_RUNNABLE;

RET:
  return ret;
}

/**
 * ALF PAL deinit routine.
 *  This function terminates the platform abstraction layer.  Any accelerators 
 *  that were previously reserved are released.
 *
 * Parameters:
 *   platform_handle [in]     the platform-handle that points to a platform 
 *                            runtime instance.
 *
 * Returns:
 *   = 0 	success, the platform has been terminated.
 *   < 0	failure
 *     ALF_ERR_BADF	invalid platform handle
 *     ALF_ERR_GENERIC	internal error
 *     ALF_ERR_PERM	the requested operation is not valid in current context
 */
int alf_pal_exit(alf_pal_handle platform_handle)
{
  alf_pal_descriptor_t *p_alf_pal_desc;
  int ret = 0;

#ifdef _ALF_CFG_CHECK_STRICT_
  if (platform_handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF runtime handle pointer\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }
#endif
  pthread_mutex_lock(&g_callback_lock);
  g_callback--;
  if (g_callback == 0)
    spe_callback_handler_deregister(_ALF_ERROR_CALLBACK_NUM);
  pthread_mutex_unlock(&g_callback_lock);

  p_alf_pal_desc = (alf_pal_descriptor_t *) platform_handle;
#ifdef _ALF_CFG_CHECK_STRICT_
  if (_alf_pal_check_handle(p_alf_pal_desc) < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF runtime handle\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }

  if (p_alf_pal_desc->state != _ALF_PAL_RUNNABLE) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF runtime handle\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }
#endif


  p_alf_pal_desc->state = _ALF_PAL_EXITED;

  free(p_alf_pal_desc);

#ifdef _ALF_CFG_CHECK_STRICT_
RET:
#endif
  return ret;
}

int alf_pal_config_init(alf_pal_handle platform_handle /* in */,
                        void *config_parms /* in */,
                        alf_pal_config_handle * config_handle /* out */ )
{
#ifdef _ALF_PLATFORM_HYBRID_
  alf_sys_config_t_Hybrid * config_ptr;
#else
  alf_sys_config_t_CBEA * config_ptr;
#endif

  alf_pal_config_t *p_alf_pal_config;
  int ret = 0;
  char *library_path;
  int valid_path = 0;
  alf_lib_path_iter_t iter_path;

#ifdef _ALF_PLATFORM_HYBRID_
  config_ptr =(alf_sys_config_t_Hybrid *) config_parms;
#else
  config_ptr =(alf_sys_config_t_CBEA *) config_parms;
#endif
#ifdef _ALF_CFG_CHECK_STRICT_
  if (config_handle == NULL || platform_handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF pal config handle pointer\n");
    ret = -ALF_ERR_INVAL;
    goto RET;
  }
#endif

  if (config_ptr == NULL || config_ptr->library_path == NULL) {
    library_path = getenv("ALF_LIBRARY_PATH");
    if (library_path == NULL) {
      library_path = _ALF_LIBRARY_PATH;
    }
  } else if (strlen(config_ptr->library_path)) { //Only check the directories if the path is not empty
    iter_path.config = config_ptr->library_path;
    iter_path.start = iter_path.end = 0; 
    while(  alf_lib_path_split(&iter_path)  != NULL) {
      if(opendir(iter_path.single_path) != NULL) 
      {
        //at least one valid path is found
        valid_path++;
        break;
      }
      else 
      {
        _ALF_DPRINTF(_ALF_ERR_LEVEL_BAD_, "The alf library path directory \"%s\" open failed \n",iter_path.single_path);
      }
    }    
    if( valid_path <= 0) 
    {
      ret = -ALF_ERR_INVAL;
      goto RET;
    }
    library_path = config_ptr->library_path;
  }
  else { //If the library path is empty, just assign the empty string
    library_path = "";
  }

  p_alf_pal_config = (alf_pal_config_t *) calloc(1, sizeof(alf_pal_config_t));

  if (p_alf_pal_config == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Init alf pal config handle error.\n");
    ret = -ALF_ERR_BADR;
    goto RET;
  }
  *config_handle = p_alf_pal_config;

  p_alf_pal_config->pal_handle = platform_handle;

  strncpy(p_alf_pal_config->config_parm, library_path, ALF_STRING_TOKEN_MAX);
  p_alf_pal_config->config_parm[ALF_STRING_TOKEN_MAX-1] = 0;

RET:
  return ret;
  
}

int alf_pal_config_exit(alf_pal_config_handle config_handle /* in */ )
{
  alf_pal_config_t *p_alf_pal_config;
  int ret = 0;

#ifdef _ALF_CFG_CHECK_STRICT_
  if (config_handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF pal config handle pointer\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }
#endif

  p_alf_pal_config = (alf_pal_config_t *) config_handle;

  free(p_alf_pal_config);

#ifdef _ALF_CFG_CHECK_STRICT_
RET:
#endif
  return ret;
  
}
/**
 * This function dump the information of alf PAL handle
 *
 * Parameters:
 *   platform_handle [in]     the platform-handle that points to a platform
 *                            runtime instance.
 */
void alf_pal_handle_dump(char *prefix, alf_pal_handle platform_handle)
{
  alf_pal_descriptor_t *p_alf_pal_desc;

  printf("%salf_pal_handle: %p\n", prefix, platform_handle);

  if (platform_handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF runtime handle pointer\n");
    return;
  }

  p_alf_pal_desc = (alf_pal_descriptor_t *) platform_handle;

  printf("%s\taccels num: %d\n", prefix, p_alf_pal_desc->acces);
  printf("%s\tstate: %d\n", prefix, p_alf_pal_desc->state);
  printf("%s\tmagic_id: 0x%x\n", prefix, p_alf_pal_desc->magic_id);
  
  fflush(stdout);
}


/**
 * ALF PAL Accelerator Reserve Routine
 *   This function reserves a number of accelerators (N) depending upon the 
 *   given policy.   It is suggested the PAL layer should support dynamic 
 *   reservation of accelerators at appropriate context.  However, if there are
 *   limitations to do this, when the initial reservation is finished, further 
 *   calls to the API should return ALF_ERR_PERM.  In case where dynamic 
 *   reservation is supported, the accelerator logic ID of the newly reserved 
 *   ones are started next to existing ones.
 *
 * Parameters:
 *   platform_handle [in] 	the platform-handle that points to a platform 
 *                              runtime instance.
 *   num_of_accels [in] 	the number of accelerators to reserve.  If the 
 *                              num_of_accels is zero (0) then all unallocated 
 *                              available accelerators are reserved.
 *   policy [in] 	        the policy to use when reserving accelerators.
 *                              If there are not enough accelerators to satisfy
 *                              the request, the behavior of the function is 
 *                              defined according to the following:
 *    ALF_ACCEL_RESV_POLICY_PERSIST	
 *                              waits until requested accelerator resources are
 *                               available or fail with timeout
 *    ALF_ACCEL_RESV_POLICY_COMPROMISE 
 *                              gets all available resources and continues, 
 *                              even if the number of accelerator nodes is less
 *                              than requested
 *    ALF_ACCEL_RESV_POLICY_TRY 
 *                              quits with a failure value if the number of 
 *                              accelerators can not be satisfied.
 *  time_out [in]	        a time out value that has the following values
 *    > 0	
 *                              it shall wait at most the specified milliseconds
 *                              before a timeout error happens
 *    = 0	       
 *                              return immediately
 *    < 0	
 *                              it shall wait until the all of the accelerator 
 *                              is reserved.  Only effective when 
 *                              ALF_ACCEL_RESV_POLICY_PERSIST is given
 * 
 * Returns:
 *   > 0	       success, the number of allocated accelerators is returned
 *   = 0 	       undefined.
 *   < 0	       failure
 *     ALF_ERR_INVAL   invalid argument
 *     ALF_ERR_BADF    bad platform handle
 *     ALF_ERR_TIME    time out
 *     ALF_ERR_BADR    requested accelerator resource not available
 *     ALF_ERR_PERM    the operation is not valid in current context
 *     ALF_ERR_NOSYS   the required policy is not supported
 *     ALF_ERR_GENERIC generic internal error
 */
int alf_pal_accelerators_reserve(alf_pal_handle platform_handle,
                                 unsigned int num_of_acces, ALF_ACCEL_RESV_POLICY_T policy, int time_out)
{
  alf_pal_descriptor_t *p_alf_pal_desc;
  int ret = 0;
  unsigned int avail_spes = 0;
  alf_spe_thread *spe_thread;
  int acces, i;
  struct timeval now;
  unsigned long long begin_time, wait_time;
  int time_out_msec;

  p_alf_pal_desc = (alf_pal_descriptor_t *) platform_handle;
#ifdef _ALF_CFG_CHECK_STRICT_
  if (_alf_pal_check_handle(p_alf_pal_desc) < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF PAL handle\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }
  /* Currently dynamic reserve is not supported */
  if (p_alf_pal_desc->acces != 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Dynamic reserve not supported yet\n");
    ret = -ALF_ERR_PERM;
    goto RET;
  }
#endif

  avail_spes = spe_cpu_info_get(SPE_COUNT_USABLE_SPES, -1);
  time_out_msec = time_out;

  if (alf_unlikely(num_of_acces > avail_spes)) {

    /* avail spes is not enough, so we should check the policy
     * to decide what we should do
     */
    if (policy == ALF_ACCEL_RESV_POLICY_PERSIST) {
      if (time_out == 0) {
        /* if time out = 0, return error immediately */
        ret = -ALF_ERR_TIME;
        goto RET;
      } else {
        /* wait until time out, if time out = -1, wait persist */
        gettimeofday(&now, NULL);
        begin_time = now.tv_sec * 1000 + now.tv_usec / 1000;
        while (1) {

          usleep(5);

          avail_spes = spe_cpu_info_get(SPE_COUNT_USABLE_SPES, -1);
          if (avail_spes >= num_of_acces) {
            p_alf_pal_desc->acces = num_of_acces;
            break;
          }

          if (time_out > 0) {
            gettimeofday(&now, NULL);
            wait_time = now.tv_sec * 1000 + now.tv_usec / 1000;
            time_out_msec -= (int) (wait_time - begin_time);
            if (time_out_msec <= 0) {
              ret = -ALF_ERR_TIME;
              goto RET;
            }
          }
        }
      }
    } else if (policy == ALF_ACCEL_RESV_POLICY_COMPROMISE) {
      if (avail_spes > 0) {
        p_alf_pal_desc->acces = avail_spes;
      } else {
        ret = -ALF_ERR_BADR;
        goto RET;
      }
    } else if (policy == ALF_ACCEL_RESV_POLICY_TRY) {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Could not satisfy accelerator requirement, only :%d available\n", avail_spes);
      ret = -ALF_ERR_BADR;
      goto RET;
    } else {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "The required policy is not supported\n");
      ret = -ALF_ERR_NOSYS;
      goto RET;
    }
  } else {
    /* avail spes is enough for user request, if request acces = 0, we should 
     * return all avail spes
     */
    if (num_of_acces != 0) {
      p_alf_pal_desc->acces = num_of_acces;
    } else {
      p_alf_pal_desc->acces = avail_spes;
    }
  }

  /* We got the acclerator number to be reserved, so begin reservation here */
  acces = p_alf_pal_desc->acces;
  p_alf_pal_desc->threads = (alf_pal_thread_t *)
      malloc_align((acces * sizeof(alf_pal_thread_t)), 7);

  if (NULL == p_alf_pal_desc->threads) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Alloc accelerator slot error.\n");
    ret = -ALF_ERR_GENERIC;
    goto RET;
  }

  p_alf_pal_desc->mapped_areas = (alf_mapped_area_t *)
      malloc_align((acces * sizeof(alf_mapped_area_t)), 7);

  if (NULL == p_alf_pal_desc->mapped_areas) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Alloc mapped areas error.\n");
    ret = -ALF_ERR_GENERIC;
	free_align(p_alf_pal_desc->threads);
    goto RET;
  }

  for (i = 0; i < acces; ++i) {
	void *ptr;

    spe_thread = &(_ALF_GET_SPU_SLOT(p_alf_pal_desc, i).spe_thread);

// ALF_SPE_EXCEPTION_HALT - This environment variable is not published.  It
// is intended to be used as a tool in debugging SPU exceptions.  The default
// is to not have this defined, in which case when the SPE encounters an exception
// spe_context_run will simply return and allow program execution to handle the exception.
//
    if (NULL == getenv("ALF_SPE_EXCEPTION_HALT")) {
      spe_thread->spe_context = spe_context_create(SPE_EVENTS_ENABLE | SPE_MAP_PS | SPE_CFG_SIGNOTIFY1_OR | SPE_CFG_SIGNOTIFY2_OR, NULL);
    } else {
      spe_thread->spe_context = spe_context_create(SPE_MAP_PS | SPE_CFG_SIGNOTIFY1_OR | SPE_CFG_SIGNOTIFY2_OR, NULL);
    }
    if(spe_thread->spe_context == NULL)
      break;

	ptr = spe_ls_area_get(spe_thread->spe_context);
    PTR_TO_ADDR64(ptr, p_alf_pal_desc->mapped_areas[i].area_eas[ALF_MAPPED_AREA_LS]);
    ptr = spe_ps_area_get(spe_thread->spe_context, SPE_MSSYNC_AREA);
    PTR_TO_ADDR64(ptr, p_alf_pal_desc->mapped_areas[i].area_eas[ALF_MAPPED_AREA_SYNC]);
    ptr = spe_ps_area_get(spe_thread->spe_context, SPE_MFC_COMMAND_AREA);
    PTR_TO_ADDR64(ptr, p_alf_pal_desc->mapped_areas[i].area_eas[ALF_MAPPED_AREA_CMD]);
    ptr = spe_ps_area_get(spe_thread->spe_context, SPE_CONTROL_AREA);
    PTR_TO_ADDR64(ptr, p_alf_pal_desc->mapped_areas[i].area_eas[ALF_MAPPED_AREA_CTRL]);
    ptr = spe_ps_area_get(spe_thread->spe_context, SPE_SIG_NOTIFY_1_AREA);
    PTR_TO_ADDR64(ptr, p_alf_pal_desc->mapped_areas[i].area_eas[ALF_MAPPED_AREA_SIG1]);
    ptr = spe_ps_area_get(spe_thread->spe_context, SPE_SIG_NOTIFY_2_AREA);
    PTR_TO_ADDR64(ptr, p_alf_pal_desc->mapped_areas[i].area_eas[ALF_MAPPED_AREA_SIG2]);

    ret = _alf_pal_spu_pthread_create(&p_alf_pal_desc->threads[i]);
    if (ret != 0) {
      break;
    }
  }

  /*Set the slot state into unused */
  for (i = 0; i < acces; ++i) {
    _ALF_GET_SPU_SLOT(p_alf_pal_desc, i).state = _ALF_SPU_SLOT_UNUSED;
  }

  if (ret != 0) {

    /* error occur, release the resource before leave */
    for (i = 0; i < acces; ++i) {
      _alf_pal_spu_pthread_destroy(p_alf_pal_desc,i);
      if(_ALF_GET_SPU_SLOT(p_alf_pal_desc, i).spe_thread.spe_context != NULL) {
        spe_context_destroy(spe_thread->spe_context);
      }

    }
    free_align(p_alf_pal_desc->threads);
    free_align(p_alf_pal_desc->mapped_areas);

  } else {
    ret = acces;
  }

RET:
  return ret;

}

/**
 * ALF PAL Acceleator Release Routine
 *   This function releases a number of accelerators that had been previously 
 *   reserved. If there are running threads on the accelerators, the thread are
 *    destroyed immediately.
 *
 * Parameters:
 *   platform_handle [in] 	the platform-handle that points to a platform 
 *                              runtime instance.
 *   num_of_accels [in] 	the number of accelerators to release.  If the 
 *                              num_of_accels is zero (0) then all previously 
 *                              reserved accelerators are released.   If the 
 *                              num_of_accels is larger than actually allocated
 *                              accelerators, the number of actually freed 
 *                              accelerators is returned.
 *
 * Returns:
 *   >= 0	success, the number of released accelerators is returned
 *   < 0	failure
 *     ALF_ERR_BADF 	invalid platform handle
 *     ALF_ERR_PERM	the operation is not valid in current context
 *     ALF_ERR_GENERIC	generic internal error
 */
int alf_pal_accelerators_release(alf_pal_handle platform_handle, unsigned int num_of_acces __attribute__ ((unused)))
{
  alf_pal_descriptor_t *p_alf_pal_desc;
  int ret = 0;

  p_alf_pal_desc = (alf_pal_descriptor_t *) platform_handle;
#ifdef _ALF_CFG_CHECK_STRICT_
  if (_alf_pal_check_handle(p_alf_pal_desc) < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF runtime handle\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }

  /* if num_of_acces = 0, all acceleators reserved will be release */
  if ((num_of_acces != 0) && (num_of_acces != p_alf_pal_desc->acces)) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Dynamic resource resv/release not supported yet: num_of_acces=%d, p_alf_pal_desc->acces=%d\n", num_of_acces, p_alf_pal_desc->acces);
    ret = -ALF_ERR_PERM;
    goto RET;
  }
#endif

  // If SPE THREAD RUNNING, WE WILL DESTROY IT
  _alf_pal_spu_threads_destroy(p_alf_pal_desc);

  _alf_pal_deinit_spes(p_alf_pal_desc);

  ret = p_alf_pal_desc->acces;
  p_alf_pal_desc->acces = 0;

#ifdef _ALF_CFG_CHECK_STRICT_
RET:
#endif
  return ret;
}

int alf_pal_task_info_check(alf_pal_config_handle config_handle,
                            alf_pal_task_info_t *task_info)
{
  alf_lib_path_iter_t iter_path;
  int ret = 0;

  /* check arguments */
  if (config_handle == NULL || task_info == NULL)
    return -ALF_ERR_BADR;


  alf_pal_config_t *p_alf_pal_config = (alf_pal_config_t *)config_handle;

  /* dlsym version symbol */
  if ((strlen(task_info->api_str[ALF_API_KERNEL_IMAGE] + 8)) >   /* length of symbol name is less than 8 */
       (2 * ALF_STRING_TOKEN_MAX)) 
    return -ALF_ERR_BADR;
  
  iter_path.config = p_alf_pal_config->config_parm;
  iter_path.start = iter_path.end = 0; 
  if(!strlen(iter_path.config))
  {
    return alf_pal_task_info_check_compat(iter_path.config, task_info);
  }
  else
  {
    while( alf_lib_path_split(&iter_path)  != NULL) {
      if( ( ret = alf_pal_task_info_check_compat(iter_path.single_path, task_info) ) == 0) 
      {
        //at least one valid path is found
        break;
      }
    }
  }    

  return ret;

}


//--------------------------------------------------------
// Task APIs
//--------------------------------------------------------

/**
 * ALF PAL thread create routine.
 *  This function starts a thread for the specified task on one accelerator and
 *  set the thread context.  The accelerator must be idle to start a new thread.
 *  
 *  Parameters
 *    platform_handle [in]	the platform handle
 *    accel_id [in]	the accelerator logic ID
 *    task_info [in]	pointer to the task info data structure
 *    context_to_set [in]	context that is set to the thread
 *    thread_handle [in/out]	the address where the thread handle is returned.
 *                              Upon success the thread handle is written to 
 *                              this location.  Upon failure, the thread_handle 
 *                              is set to NULL.
 *
 *  Returns
 *    = 0	The thread is created successfully
 *    < 0	failure
 *      ALF_ERR_INVALID		invalid argument
 *      ALF_ERR_PERM	        the operation is not valid in the current 
 *                              context.  
 *      ALF_ERR_NOEXEC		the task info is invalid
 *      ALF_ERR_NOMEM		the memory requirement of the thread can not 
 *                              be satisfied
 *      ALF_ERR_NODATA	        the required context is not specified
 *      ALF_ERR_GENERIC	        generic internal error
 *      ALF_ERR_ACCEL	        generic accelerator error
 */
int alf_pal_thread_create(alf_pal_config_handle config_handle,
                          unsigned int vid, unsigned int accel_id,
                          alf_pal_task_info_t * task_info,
                          alf_data_addr64_t context_to_set, alf_pal_thread_handle * thread_handle)
{
  spe_program_handle_t *spe_task_image;
  alf_pal_thread_t *p_alf_pal_thread;
  alf_pal_config_t *p_alf_pal_config;
  alf_pal_descriptor_t *p_alf_pal_desc;
  alf_pal_sym_info_t *p_sym;
  alf_aal_pkt_t *pkt_ptr;
  alf_aal_pkt_queue_t *pkt_queue;
  int ret = 0;

#ifdef _ALF_CFG_CHECK_STRICT_
  if (thread_handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid task handle pointer\n");
    ret = -ALF_ERR_INVAL;
    goto RET;
  }

  if (task_info == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid task info handle pointer\n");
    ret = -ALF_ERR_INVAL;
    goto RET;
  }
#endif

  *thread_handle = NULL;

  p_alf_pal_config = (alf_pal_config_t *) config_handle;
  p_alf_pal_desc = (alf_pal_descriptor_t *) p_alf_pal_config->pal_handle;

#ifdef _ALF_CFG_CHECK_STRICT_
  if (_alf_pal_check_handle(p_alf_pal_desc) < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF runtime handle\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }
#endif

  /* Search the spu image in the dynamic library, then get the symbol address 
   * of the ALF API
   */
#ifdef _ALF_PLATFORM_HYBRID_
  //If config_parm is an empty string, just call alf_pal_dlsym with an empty string, 
  //otherwise try to split the lib path
  if (strlen(p_alf_pal_config->config_parm)) {
    alf_lib_path_iter_t iter_path;
  
    iter_path.config = p_alf_pal_config->config_parm;
    iter_path.start = iter_path.end = 0; 
    while( alf_lib_path_split(&iter_path)  != NULL) {
      if((ret = _alf_pal_dlsym(iter_path.single_path, task_info)) >= 0) {
          //at least one valid path is found
          break;
      }
    }    
  }
  else {
    //Try to load the spu library using the LD_LIBRARY_PATH 
    ret = _alf_pal_dlsym("", task_info);
  }
  
  if( ret < 0)
  { 
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Error occur when open dynamic library\n");
    goto RET;
  }
#endif

#ifdef _ALF_CFG_CHECK_STRICT_
  /* accel_id check */
  if ((p_alf_pal_desc->acces == 0) || (accel_id > (p_alf_pal_desc->acces - 1))) {
    ret = -ALF_ERR_PERM;
    goto RET;
  }

  /* Check the slot is used or not */
  if (_ALF_GET_SPU_SLOT(p_alf_pal_desc, accel_id).state != _ALF_SPU_SLOT_UNUSED) {
    ret = -ALF_ERR_PERM;
    goto RET;
  }
#endif

  p_alf_pal_thread = &p_alf_pal_desc->threads[accel_id];
#ifdef _ALF_CFG_CHECK_STRICT_
  if (p_alf_pal_thread == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Alloc memory exception for task_handle\n");
    ret = -ALF_ERR_PERM;
    goto RET;
  }
#endif

  /* Translate the task info for CELL */
  if ((ret = _alf_pal_task_info_init(p_alf_pal_thread, task_info, task_info->accels, 0)) < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid task info\n");
    goto RET;
  }
#ifdef _ALF_PLATFORM_HYBRID_
  /* For LTS Hybrid, this field should be initialized by context_to_set 
   * This operation does not affect WTS Hybrid
   */
  p_alf_pal_thread->data.task_info.ctx_ea = context_to_set;
#endif
  
  p_sym = (alf_pal_sym_info_t *)(task_info->p_arch_tinfo);

  /* Create the spe thread */
  spe_task_image = p_sym->spe_task_image;
  PTR_TO_ADDR64(spe_task_image, p_alf_pal_thread->data.handle);
  p_alf_pal_thread->data.lib_handle = p_sym->lib_handle;
  p_alf_pal_thread->data.state = _ALF_TASK_Q_ACTIVE;
  p_alf_pal_thread->data.alf_pal_desc_ptr = p_alf_pal_desc;

  /* Init the statistic info of the thread */
  p_alf_pal_thread->data.total_wbs = 0;
  p_alf_pal_thread->data.pending_wbs = 0;
  p_alf_pal_thread->data.running_wbs = 0;
  p_alf_pal_thread->data.finished_wbs = 0;
  p_alf_pal_thread->data.total_pkt_req = 0;
  p_alf_pal_thread->data.finished_pkt_req = 0;

  p_alf_pal_thread->data.thread_error = 0;
  p_alf_pal_thread->data.task_type = task_info->task_type;
  
  *thread_handle = p_alf_pal_thread;

   /* Init the packet */
  _alf_pal_req_queue_init(p_alf_pal_thread, vid);
  if (task_info->task_type == ALF_TASK_TYPE_LIGHTWEIGHT)
  {
    int i;
    alf_aal_spu_instance_t *spu_instance = &p_alf_pal_thread->data.spu_instance;

    spu_instance->dataset_ready = 0;
    PTR_TO_ADDR64(&p_alf_pal_thread->data.task_info, spu_instance->ti_ea);
    PTR_TO_ADDR64(p_alf_pal_desc->mapped_areas, spu_instance->mapped_areas_ea);
    for (i = 0; i < (int)task_info->accels; ++i)
    {
      spu_instance->vtol_id_map[i] = task_info->vtol_id_map[i];
    }
  }

  if ((ret = _alf_pal_spu_thread_create(p_alf_pal_desc, p_alf_pal_thread, spe_task_image)) < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Create spu thread error, error_code:%d\n", ret);
    //_alf_error_handler(alf_handle, ALF_ERR_FATAL, ret, 0); 
    goto RET;
  }

  if (task_info->task_type == ALF_TASK_TYPE_LIGHTWEIGHT)
	  return 0;

  pkt_queue = &p_alf_pal_thread->data.pkt_queue;
  pkt_ptr = (alf_aal_pkt_t *) &pkt_queue->pkts[pkt_queue->ppu_info.rear];

  _alf_pal_pkt_init(p_alf_pal_thread, pkt_ptr, NULL, 0L, 0L, 0L, ALF_AAL_PKT_TASK_SETUP);

  _alf_pal_req_queue_enqueue(p_alf_pal_thread, pkt_ptr);
  //Set the context pointer
  if (context_to_set != 0LL) {
    /* Need setup the context first */
    ret = alf_pal_thread_context_swap(p_alf_pal_thread, context_to_set, 0LL);
    if (ret < 0)
      goto RET;
  }

RET:
#ifdef _ALF_PLATFORM_HYBRID_
  //This doesn't get freed on hybrid at the api level
  if (task_info->p_arch_tinfo != NULL) {
    free(task_info->p_arch_tinfo);
  }
#endif
  if (ret < 0 && (thread_handle != NULL)) {
    *thread_handle = NULL;
  }
  return ret;
}

/**
 * ALF PAL thread waiting routine.
 *  This function waits for the task thread to complete its current work 
 *  (all queued work block operations and context operations to complete)
 *
 *  Parameters
 *    thread_handle [in]     the thread handle
 *    time_out [in]	     a time out value that has the following values
 *       > 0	
 *                           it shall wait at most the specified milliseconds 
 *                           before a timeout error happens
 *       = 0	        
 *                           return immediately
 *       < 0	
 *                           it shall wait until the thread is idle
 * Returns
 *    > 0	the thread is still busy, only available when time_out == 0
 *    = 0	success, the thread is idle
 *    < 0	failure or some internal errors happened
 *     ALF_ERR_BADF	invalid task handle
 *     ALF_ERR_TIME	timeout
 *     ALF_ERR_PROTO	there is an error occurred when processing work blocks 
 *                      or contexts, the thread may not able to continue
 *     ALF_ERR_GENERIC	internal error
 */
int alf_pal_thread_wait(alf_pal_thread_handle thread_handle, int time_out)
{
  alf_pal_thread_t *p_alf_pal_thread = NULL;
  struct timeval now;
  unsigned long long begin_time, end_time;
  int wait_time = 0;
  int all_pkt_finished = 0;
  int ret = 0;

#ifdef _ALF_CFG_CHECK_STRICT_
  if (thread_handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid task handle pointer\n");
    ret = -ALF_ERR_BADF;
    return ret;
  }
#endif

  p_alf_pal_thread = (alf_pal_thread_t *) thread_handle;
  
  if (p_alf_pal_thread->data.thread_error != 0) {
    return p_alf_pal_thread->data.thread_error;
  }

  if (p_alf_pal_thread->data.state == _ALF_TASK_Q_ACTIVE) {
    p_alf_pal_thread->data.state = _ALF_TASK_Q_WAIT;
  }


  gettimeofday(&now, NULL);
  begin_time = now.tv_sec * 1000 + now.tv_usec / 1000;
  while (1) {

    all_pkt_finished = _alf_pal_is_all_pkt_finished(p_alf_pal_thread);

//    printf("In %s: all_pkt_finished=%d\n", __func__,all_pkt_finished);

    gettimeofday(&now, NULL);
    end_time = now.tv_sec * 1000 + now.tv_usec / 1000;
    wait_time = (int) (end_time - begin_time);

    if (all_pkt_finished) {
      break;
    } else {

      if (time_out == 0) {
        ret = !all_pkt_finished;
        break;
      }
      else if (time_out > 0 && wait_time >= time_out) {
        ret = -ALF_ERR_TIME;
        break;
      }
    }


    usleep(5);
  }

  return ret;
}


/**
 * ALF PAL thread reset routine
 *  This function reset the status of an idle thread to initial status.
 *  For a running thread, this call will return failure.  If a thread 
 *  already runs into internal errors, this API can be used to reset 
 *  the thread.
 * 
 * Parameters
 *   task_info [in]	pointer to the task info data structure
 *   thread_handle [in]	the thread handle
 * Returns
 *   >= 0	success, the logic Id of the accelerator is returned
 *   < 0	failure
 *    ALF_ERR_BADF	invalid task handle
 *    ALF_ERR_BUSY	the thread is not idle
 *    ALF_ERR_GENERIC	internal error
 */
int alf_pal_thread_reset(alf_pal_task_info_t * task_info, alf_pal_thread_handle thread_handle, unsigned int vid)
{
  alf_pal_descriptor_t *p_alf_pal_desc = NULL;
  alf_pal_thread_t *p_alf_pal_thread;
  volatile alf_aal_spu_instance_t *spu_instance;
  alf_aal_pkt_t *pkt_ptr;
  alf_aal_pkt_queue_t *pkt_queue;
  void *lib_handle = NULL;
  int ret = 0;

#ifdef _ALF_CFG_CHECK_STRICT_
  if (thread_handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid thread handle pointer\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }
#endif
  p_alf_pal_thread = (alf_pal_thread_t *) thread_handle;

  /* If thread running, return error */
  if (p_alf_pal_thread->data.task_type == ALF_TASK_TYPE_WORKBLOCK && !_alf_pal_is_all_pkt_finished(p_alf_pal_thread)) {
    ret = -ALF_ERR_BUSY;
    goto RET;
  }

  /* FIXME: If this thread has met some internal errors, restart the thread */
  //check the error code here

  lib_handle = p_alf_pal_thread->data.lib_handle;
#ifdef _ALF_CFG_CHECK_STRICT_
  if(lib_handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid lib handle\n");
    ret = -ALF_ERR_GENERIC;
    goto RET;
  }
#endif

  /* ask the spe thread reinit */
  spu_instance = &p_alf_pal_thread->data.spu_instance;
  PTR_TO_ADDR64((void*)0, spu_instance->dataset_ea);
  _ALF_SYNC_MEMORY();

  /* if task_info is NULL, will be treated as not changed. */
  if (task_info != NULL) {
    p_alf_pal_desc = p_alf_pal_thread->data.alf_pal_desc_ptr;

    /* set the new task info */
    ret = _alf_pal_task_info_init(p_alf_pal_thread, task_info, 
                                  task_info->accels, 1);
    if(ret < 0) {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid task info\n");
      goto RET;
    }

    if (task_info->task_type == ALF_TASK_TYPE_LIGHTWEIGHT)
    {
      int i;
	  for (i = 0; i < (int)task_info->accels; ++i)
      {
        spu_instance->vtol_id_map[i] = task_info->vtol_id_map[i];
      }
    }
  }

  /* Init the statistic info of the thread */
  p_alf_pal_thread->data.total_wbs = 0;
  p_alf_pal_thread->data.pending_wbs = 0;
  p_alf_pal_thread->data.running_wbs = 0;
  p_alf_pal_thread->data.finished_wbs = 0;
  p_alf_pal_thread->data.total_pkt_req = 0;
  p_alf_pal_thread->data.finished_pkt_req = 0;
  
  p_alf_pal_thread->data.thread_error = 0;

  /* Init the packet */
  _alf_pal_req_queue_reinit(p_alf_pal_thread, vid);

  if (task_info->task_type == ALF_TASK_TYPE_LIGHTWEIGHT)
	  return 0;

  pkt_queue = &p_alf_pal_thread->data.pkt_queue;
  pkt_ptr = (alf_aal_pkt_t *) &pkt_queue->pkts[pkt_queue->ppu_info.rear];
  /* Initialize the packet */
  _alf_pal_pkt_init(p_alf_pal_thread, pkt_ptr, NULL, 0L, 0L, 0L, ALF_AAL_PKT_TASK_SETUP);

  /* Add the packet into packet queue */
  _alf_pal_req_queue_enqueue(p_alf_pal_thread, pkt_ptr);

  p_alf_pal_thread->data.state = _ALF_TASK_Q_ACTIVE;


  ALF_DUMP_SINGLE_SPU_PROF(p_alf_pal_thread->data.spu_instance.id, &p_alf_pal_thread->data.spu_prof);

RET:
  return ret;
}


/**
 * ALF thread destroy routine.
 *  This function destroys the thread running on the accelerator immediately. 
 *  All unfinished work is lost.
 *
 * Parameters
 *  thread_handle [in]	the thread handle
 *
 * Returns
 *  >= 0	success, the logic Id of the accelerator is returned
 *  < 0	        failure
 *   ALF_ERR_BADF	invalid task handle
 *   ALF_ERR_GENERIC	internal error
 */
int alf_pal_thread_destroy(alf_pal_thread_handle thread_handle)
{
  alf_pal_thread_t *p_alf_pal_thread;
  pthread_t spe_id;
  unsigned int accel_id;
  void *lib_handle;
#ifdef _ALF_CFG_CHECK_STRICT_
  int ret = 0;
#endif

  p_alf_pal_thread = (alf_pal_thread_t *) thread_handle;
#ifdef _ALF_CFG_CHECK_STRICT_
  if (p_alf_pal_thread == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF runtime handle\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }
#endif

  if (p_alf_pal_thread->data.state != _ALF_TASK_Q_DESTROY) {
    p_alf_pal_thread->data.state = _ALF_TASK_Q_FIN;
  }

  lib_handle = p_alf_pal_thread->data.lib_handle;
#ifdef _ALF_CFG_CHECK_STRICT_
  if(lib_handle == NULL) {
    ret = -ALF_ERR_GENERIC;
    goto RET;
  }
#endif

  accel_id = _alf_pal_get_accel_id(p_alf_pal_thread);

  spe_id = p_alf_pal_thread->data.id;
#ifdef _ALF_CFG_CHECK_STRICT_
  if (alf_unlikely(spe_id == 0L)) {
    ret = -ALF_ERR_BADF;
    goto RET;
  }
#endif

  /* notify the spe thread to exit */
  _ALF_SYNC_MEMORY();

  //singal notification will only be used for informing spe to exit
  if (p_alf_pal_thread->data.task_type == ALF_TASK_TYPE_WORKBLOCK)
    _alf_pal_notify_spe_thread(thread_handle, SIG_SPE_EXIT);
  else
    p_alf_pal_thread->data.spu_instance.control_blk.abort = 1;

  _alf_pal_spu_thread_destroy(p_alf_pal_thread);

  dlclose(lib_handle);

#ifdef _ALF_CFG_CHECK_STRICT_
RET:
  if (ret < 0)
    return ret;
#endif
  return accel_id;
}

/**
 * Thread status query routine.
 *   This function checks the status of the thread, such as, if there any work 
 *   block running or pending, if there are some task context operations being 
 *   carried out or pending,, etc
 *
 * Parameters
 *   thread_handle [in]	the thread handle
 *   status [in/out]	pointer to an alf_pal_thread_status_t data structure 
 *                      where the result is filled upon success.  This pointer 
 *                      can be NULL if the output is not wanted.  Upon failure 
 *                      (except ALF_ERR_PROTO), the content of the status data 
 *                      is undefined.  For application scenario where only a 
 *                      light weight status check is needed, please refer to 
 *                      alf_pal_thread_wait(time_out = 0) for a solution.
 *
 * Returns
 *   >= 0	success, the logic ID of the accelerator is returned
 *   < 0	failure or some internal errors happened
 *    ALF_ERR_BADF	invalid thread handle
 *    ALF_ERR_FAULT	invalid *status pointer
 *    ALF_ERR_PROTO	there is an error occurred when processing work blocks 
 *                      or contexts, the thread may not able to continue
 *    ALF_ERR_GENERIC	internal error
 */
int alf_pal_thread_status_query(alf_pal_thread_handle thread_handle, alf_pal_thread_status_t * status)
{
  alf_pal_thread_t *p_alf_pal_thread;
  alf_aal_pkt_queue_t *pkt_queue;
  unsigned int accel_id;
  int ret = 0;

  p_alf_pal_thread = (alf_pal_thread_t *) thread_handle;
#ifdef _ALF_CFG_CHECK_STRICT_
  if (p_alf_pal_thread == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF runtime handle\n");
    ret = -ALF_ERR_BADF;
    return ret;
  }

  if (status == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid output buffer\n");
    ret = -ALF_ERR_INVAL;
    return ret;
  }
#endif


  accel_id = _alf_pal_get_accel_id(thread_handle);

  if (p_alf_pal_thread->data.task_type == ALF_TASK_TYPE_LIGHTWEIGHT) {
    alf_aal_spu_instance_t *spu_instance = &p_alf_pal_thread->data.spu_instance;

    status->status = 0;
    if (spu_instance->control_blk.tasks > spu_instance->control_blk.fin_tasks)
	  status->status |= ALF_PAL_THREAD_STATUS_WB_OP;
    goto RET;
  }

  pkt_queue = &p_alf_pal_thread->data.pkt_queue;

  p_alf_pal_thread->data.finished_wbs = pkt_queue->spu_info.finished_wb_cnt;

  status->total_wbs = p_alf_pal_thread->data.total_wbs;
  status->pending_wbs = _alf_pal_wb_req_entries(p_alf_pal_thread);
  status->finished_wbs = p_alf_pal_thread->data.finished_wbs;
  status->running_wbs = status->total_wbs - status->pending_wbs - status->finished_wbs;

  status->status = 0;
  if (status->total_wbs != status->finished_wbs) {
    status->status |= ALF_PAL_THREAD_STATUS_WB_OP;
  }
  if (p_alf_pal_thread->data.total_pkt_req != p_alf_pal_thread->data.finished_pkt_req) {
    status->status |= ALF_PAL_THREAD_STATUS_CTX_OP;
  }

RET:
  ret = accel_id;

  return ret;
}


/**
 * ALF PAL thread handle dump routine
 *  This function prints the contents of all of the fields of the data structure
 *   that is pointed to by the given ALF thread handle.
 */
void alf_pal_thread_dump(char *prefix, alf_pal_thread_handle thread_handle)
{
  alf_pal_thread_t *p_alf_pal_thread;

  printf("%salf_pal_thread_t: %p\n", prefix, thread_handle);

  if (thread_handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF thread handle pointer\n");
    return;
  }

  p_alf_pal_thread = (alf_pal_thread_t *) thread_handle;
  
  /* TODO: output the remaining fields  */
  
  fflush(stdout);
}


//--------------------------------------------------------
// Work Block APIs
//--------------------------------------------------------


/* This function setups the platform specific header of work block that are used
  * by PAL layer.  It will also convert the abstracted DTL to platform specific format
  * and store the result into the platform specific header.  
  */

int alf_pal_wb_setup(alf_pal_wb_handle wb_handle, alf_pal_dtlist_t *p_dtlist)
{
    alf_aal_wbh_t *pwb_aal=NULL;
    unsigned int dtl_size;
    alf_aal_dtl_t *pdtl=NULL;
    int rtn;

    
#ifdef _ALF_CFG_CHECK_STRICT_
    if(wb_handle == NULL) 
    {
        _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF wb handle\n");
        return -ALF_ERR_BADF;
    }

    if(wb_handle->hostdata.p_task_info->task_attr & ALF_PAL_TASK_ATTR_PARTITION_ON_ACCEL || p_dtlist == NULL) // accel partition
    {
        dtl_size = 0;
    }
    else
#endif
    {
        pwb_aal = (alf_aal_wbh_t *)wb_handle->pal_resv;
        // check and estimate the dtl buffer size
        rtn = _alf_pal_dtl_check(p_dtlist, wb_handle->hostdata.p_task_info, &pwb_aal->ovl_dtl_size, &pwb_aal->input_dtl_size, &pwb_aal->output_dtl_size);
        if(rtn < 0)
        {
            _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "PAL DTL error %d\n", rtn);
            return rtn;
        }

        // we have the DTL structure that ovl_io is the first section, then in+ovl_in, then out+ovl_out
        // there will be a NIL header between in and out DTL
        // the SPU will load the ovl_io + in first,  then load the out to replace the in section.
        //  here is the details 
        //  PPU DTL            SPU DTL-IN      SPU_DTL-OUT
        // ---------------        ----------      -----------
        // | OVL_IO      |   ->   | OVL_IO |  ->  | OVL_IO  |
        // ---------------        ----------      -----------
        // | IN+OVL_IN   |   ->   | IN     |  /-> | OUT     |
        // ---------------        ----------  |   -----------  
        // | OUT+OVL_OUT |   ----------------/  
        // --------------- 
        

        // adjust the table size for space of a NIL header
        //  the accelerator side will use the NIL as an indication of end of table
        
        if(pwb_aal->input_dtl_size || pwb_aal->ovl_dtl_size)  // need a NIL only when the size is not zero
            pwb_aal->input_dtl_size += _ALF_AAL_DTL_HEADER_SIZE;  // we need to place an NIL header at the end of this DTL
            
        if(pwb_aal->output_dtl_size != 0) // need a NIL only when the size is not zero
            pwb_aal->output_dtl_size += _ALF_AAL_DTL_HEADER_SIZE; // we need to place an NIL header at the end of this DTL

        // the total size of AAL DTL
        dtl_size = pwb_aal->ovl_dtl_size + pwb_aal->input_dtl_size + pwb_aal->output_dtl_size;


        if(dtl_size > 0)
        {
            // allocate the dtl buffer
            pdtl = malloc_align(dtl_size*sizeof(alf_aal_dtl_t), ALF_PAL_DATA_ALIGN_REQ);
            if(NULL == pdtl)
            {
                _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Out of memory for DTL\n");
                return -ALF_ERR_NOMEM;
            }
            
            // convert the dtl to AAL dtl
            _alf_pal_dtl_convert(p_dtlist, wb_handle->hostdata.p_task_info, pdtl, pwb_aal->ovl_dtl_size, pwb_aal->input_dtl_size, pwb_aal->output_dtl_size);
        }
    }


    pwb_aal->status = _ALF_WORK_BLOCK_STATUS_INIT;
    pwb_aal->loop_num = wb_handle->hostdata.total_count;
    pwb_aal->udata_size = wb_handle->hostdata.parm_size;

    if(dtl_size != 0)  // we have DTL, so setup the buffers
    {
        pwb_aal->input_dtl_size += pwb_aal->ovl_dtl_size;   // the input size shall include the overlapped I/O size
#ifdef _ALF_64B_
        pwb_aal->input_dtl_ea = (alf_data_addr64_t)pdtl;    // the DTL buffer address
        pwb_aal->output_dtl_ea = (alf_data_addr64_t)(pdtl + pwb_aal->input_dtl_size);
#else
        pwb_aal->input_dtl_ea = (alf_data_addr64_t)(unsigned int)pdtl;    // the DTL buffer address
        pwb_aal->output_dtl_ea = (alf_data_addr64_t)(unsigned int)(pdtl + pwb_aal->input_dtl_size);
#endif
    }
    // else we do not need to fill them as the header is set to zero by API layer code

    return 0;
}



/**
 * ALF PAL work block enqueue routine.
 *   This function puts a work block to the queue.  The work block is dequeued 
 *   by the PAL layer automatically when it has been processed by the task 
 *   thread.  The PAL layer implementation may choose to create extra internal 
 *   data related with the work block when it is enqueued and release that data
 *   when the work block is processed and dequeued.  Also please note that the 
 *   runtime code above the PAL still needs to track the work block when it is 
 *   enqueued to the PAL.  It is the higher layer code's responsibility to 
 *   release the resource when the work block is processed.  
 *
 * Parameters
 *  thread_handle [in]	the thread handle
 *  wb_handle [in]	the work block handle (pointer to the work block data 
 *                      structure)
 *
 * Results
 *  > 0	successful, return the number of work blocks in the queue
 *  = 0	undefined
 *  < 0	failure
 *   ALF_ERR_INVAL	Invalid argument
 *   ALF_ERR_BADF	invalid thread handle
 *   ALF_ERR_NOBUFS	the thread work block queue is full
 */
int alf_pal_wb_enqueue(alf_pal_thread_handle thread_handle, alf_pal_wb_handle wb_handle)
{
  alf_pal_thread_t *p_alf_pal_thread;
  alf_pal_wb_t *wb = (alf_pal_wb_t *) wb_handle;
  alf_aal_pkt_queue_t *pkt_queue;
  alf_aal_pkt_t *pkt_ptr = NULL;

  int ret = 0;


  p_alf_pal_thread = (alf_pal_thread_t *) thread_handle;
  pkt_queue = &p_alf_pal_thread->data.pkt_queue;
#ifdef _ALF_CFG_CHECK_STRICT_
  if (p_alf_pal_thread == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF thread handle\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }

  if (p_alf_pal_thread->data.state >= _ALF_TASK_Q_WAIT) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF task handle\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }

  if (p_alf_pal_thread->data.state != _ALF_TASK_Q_ACTIVE) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Could not add work blocks after calling alf_pal_thread_wait\n");
    ret = -ALF_ERR_PERM;
    goto RET;
  }

  if (wb == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF task handle\n");
    ret = -ALF_ERR_BADF;
    goto RET; 
  }

  if (_alf_pal_is_req_queue_full(pkt_queue)) {
    /* Scheduler should call wbqueue_query first to avoid this happen */
    ret = -ALF_ERR_NOBUFS;
    goto RET;
  }
#endif

  _alf_pal_wb_init(p_alf_pal_thread, wb);

  /* Must be 128 bit align */
  pkt_ptr = (alf_aal_pkt_t *) &pkt_queue->pkts[pkt_queue->ppu_info.rear];

  /* Initialize the packet, set the work block header according to PAL work block The type of DTLs would be set here */
  if ((ret = _alf_pal_pkt_init(p_alf_pal_thread, pkt_ptr, 
                              (alf_pal_wb_t *)wb, 0L, 0L, 0L, ALF_AAL_PKT_WBH)) < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "wbh req pkt init failed\n");
    goto RET;
  }

  /* Add the packet into packet queue */
  _alf_pal_req_queue_enqueue(p_alf_pal_thread, pkt_ptr);

RET:
  return ret;
}

/**
 * ALF PAL work block cleanup routine.
 *   cleanup the work block of PAL layer resource usage when the work block has been processed or aborted
 *
 * Parameters
 *  wb_handle [in]	the work block handle (pointer to the work block data 
 *                      structure)
 *
 * Results
 *  > 0	successful
 *  = 0	undefined
 *  < 0	failure
 *   ALF_ERR_BADF	invalid wb handle
 */

int alf_pal_wb_cleanup(alf_pal_wb_handle wb_handle /*in */ __attribute__ ((unused)))
{
    int ret = 0;
    alf_aal_wbh_t *pwb_aal;
    
#ifdef _ALF_CFG_CHECK_STRICT_
    if (wb_handle == NULL) {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "wb handle can not be NULL\n");
      ret = -ALF_ERR_BADF;
      return ret;
    }
#endif

    pwb_aal = (alf_aal_wbh_t *)wb_handle->pal_resv;

    if(pwb_aal->input_dtl_ea != (alf_data_addr64_t)0)
    {
#ifdef _ALF_32B_
        free_align((void *)(unsigned int)pwb_aal->input_dtl_ea);
#else
        free_align((void *)pwb_aal->input_dtl_ea);
#endif    
        pwb_aal->input_dtl_ea = 0;
    }
    
    return ret;
}

/**
 * ALF PAL WBQUEUE query 
 *  This function queries the work block queue and returns an alf_wbqueue_info_t
 *   structure, which includes total_entries, and free_entries.
 *
 * Parameters
 *  thread_handle [in]	the thread handle
 *  wbqueue_info [in/out]   pointer to the data structure where the results
 *                          are returned upon success.  A NULL pointer could be
 *                          supplied when these detailed results are not 
 *                          required.  Upon failure, the contents of 
 *                          webqueue_info is undefined.
 *
 * Returns
 *  >= 0	success, the number of free entries for work blocks
 *  < 0	        failure
 *   ALF_ERR_BADF	invalid handle
 */
int alf_pal_wbqueue_query(alf_pal_thread_handle thread_handle, alf_pal_wbqueue_info_t * wbqueue_info)
{
  alf_pal_thread_t *p_alf_pal_thread;
  int free_entries = 0;
  int ret = 0;

  p_alf_pal_thread = (alf_pal_thread_t *) thread_handle;
#ifdef _ALF_CFG_CHECK_STRICT_
  if(p_alf_pal_thread == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid alf pal thread handle\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }
#endif

  free_entries = _alf_pal_req_queue_free_entries(p_alf_pal_thread);
  if (wbqueue_info != NULL) {
    wbqueue_info->total_entries = ALF_AAL_PKT_QLEN;
    wbqueue_info->free_entries = free_entries;
  }

  ret = free_entries;
#ifdef _ALF_CFG_CHECK_STRICT_
RET:
#endif
  return ret;
}


static char *_alf_pal_data_type2string(ALF_DATA_TYPE_T type)
{
    switch(type)
    {
        case ALF_DATA_BYTE:
            return "ALF_DATA_BYTE";
        case ALF_DATA_INT16:
            return "ALF_DATA_INT16";
        case ALF_DATA_INT32:
            return "ALF_DATA_INT32";
        case ALF_DATA_INT64:
            return "ALF_DATA_INT64";
        case ALF_DATA_FLOAT:
            return "ALF_DATA_FLOAT";
        case ALF_DATA_DOUBLE:
            return "ALF_DATA_DOUBLE";
        case ALF_DATA_ADDR32:
            return "ALF_DATA_ADDR32";
        case ALF_DATA_ADDR64:
            return "ALF_DATA_ADDR64";
        default:
            return "**** INVALID_DATA_TYPE ****";
    }
}

static void _alf_pal_dump_aal_dtl(alf_aal_dtl_t *paal_dtl, char *prefix)
{
    static char *buf_type[5] = {
        "ALF_BUF_IN",          /* input buffer */
        "ALF_BUF_OUT",         /* output buffer */
        "ALF_BUF_OVL_IN",      /* I/O buffer input */
        "ALF_BUF_OVL_OUT",     /* I/O buffer output */
        "ALF_BUF_OVL_INOUT",   /* I/O buffer in and out */
    };

    while(paal_dtl[0].header1.total_size != 0)
    {
        // dump the header
        printf("%s\t  [%4d] DTL header1 (%s  total_size %d,  num_dtl_entry %d, num_type_entry %d)\n",
               prefix, 0,  buf_type[paal_dtl[0].header1.buf_type], paal_dtl[0].header1.total_size, 
               paal_dtl[0].header1.num_dtl_entry, paal_dtl[0].header1.num_type_entry);
        printf("%s\t  [%4d] DTL header2 (ea_high 0x%08x,  local offset 0x%08x)\n",
               prefix, 1,  paal_dtl[1].header2.ea_high, paal_dtl[1].header2.local_offset);
        // dump the DMA list part
        unsigned int lth = paal_dtl[0].header1.num_dtl_entry+2;
        unsigned int i;
        
        for(i=2; i<lth; i++)
        {
            printf("%s\t  [%4d] DTL (ea_low 0x%08x,  size %d)\n", 
                prefix, i, paal_dtl[i].dtl.eal, paal_dtl[i].dtl.size);
        }
        // dump the TYPE list part
        lth += paal_dtl[0].header1.num_type_entry;
        for(; i<lth; i++)
        {
            printf("%s\t  [%4d] TYPE (%s,  count %d)\n", 
                prefix, i, _alf_pal_data_type2string(paal_dtl[i].type.type), paal_dtl[i].type.count);
        }
        for(; i<paal_dtl[0].header1.total_size; i++)
        {
            printf("%s\t  [%4d] PADDING\n", prefix, i);
        }
        
        paal_dtl += paal_dtl[0].header1.total_size;  // next list
    }
    
}


/** 
 * ALF PAL WB HANDLE DUMP 
 * This function prints the contents of all of the fields of the data structure
 *  that is pointed to by the given ALF work block handle.
 */
void alf_pal_wb_dump(char *prefix, alf_pal_wb_handle handle)
{
  char prefix_buffer[strlen(prefix)+2];

  printf("%salf_pal_wb: %p\n", prefix, handle);

  if (handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "handle can't be NULL.\n");
    return;
  }

  alf_pal_wb_t *pal_wb = (alf_pal_wb_t *) handle;
  alf_pal_wb_host_data_t *wb = (alf_pal_wb_host_data_t *) handle;
  alf_aal_wbh_t *paal_wb = (alf_aal_wbh_t *)pal_wb->pal_resv;
  
  printf("%s\tpal_resv: %p\n", prefix, pal_wb->pal_resv);
  printf("%s\ttotal_count: %d\n", prefix, wb->total_count);
  printf("%s\tparm_size: %d\n", prefix, wb->parm_size);
  printf("%s\tp_task_info: %p\n", prefix, wb->p_task_info);
  
  strcpy(prefix_buffer,"\t");
  strcat(prefix_buffer,prefix);

  printf("%s\tovl_io_dtl+in_dtl+ovl_in_dtl: 0x%016llx size %d \n", prefix, paal_wb->input_dtl_ea, paal_wb->input_dtl_size);
  printf("%s\t with ovl_io_dtl: size %d\n", prefix, paal_wb->ovl_dtl_size);
  if(paal_wb->input_dtl_size > 0)
  {
#ifdef _ALF_64B_
      _alf_pal_dump_aal_dtl((alf_aal_dtl_t *)paal_wb->input_dtl_ea, prefix);
#else
      _alf_pal_dump_aal_dtl((alf_aal_dtl_t *)(unsigned int)paal_wb->input_dtl_ea, prefix);
#endif
  }
  printf("%s\tout_dtl+ovl_out_dtl: 0x%016llx size %d \n", prefix, paal_wb->output_dtl_ea, paal_wb->output_dtl_size);
  if(paal_wb->input_dtl_size > 0)
  {
#ifdef _ALF_64B_
    _alf_pal_dump_aal_dtl((alf_aal_dtl_t *)paal_wb->output_dtl_ea, prefix);
#else
    _alf_pal_dump_aal_dtl((alf_aal_dtl_t *)(unsigned int)paal_wb->output_dtl_ea, prefix);
#endif
  }
  
  fflush(stdout);

}

/**
 * ALF PAL thread context swap routine
 *  This function lets the existing thread cast back its current thread context, *  then assign a new thread context buffer to the thread and tell the 
 *  accelerator side runtime to invoke the thread context initialization method.
 *
 * Parameters
 *   thread_handle [in]	the thread handle
 *   context_to_set [in]	context that is set to the thread
 *   context_to_get [in]	context that is cast out
 * 
 * Returns
 *   = 0	success
 *   < 0	failure
 *     ALF_ERR_PERM	the thread does not have context
 *     ALF_ERR_BADF	invalid thread handle
 *     ALF_ERR_GENERIC	generic error
 *     ALF_ERR_ACCEL	accelerator error
 */
int alf_pal_thread_context_swap(alf_pal_thread_handle thread_handle,
                                alf_data_addr64_t context_to_set, alf_data_addr64_t context_to_get)
{
  alf_pal_thread_t *p_alf_pal_thread;
  alf_aal_pkt_queue_t *pkt_queue;
  alf_aal_pkt_t *pkt_ptr;
  int ret = 0;

#ifdef _ALF_CFG_CHECK_STRICT_
  if (thread_handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid task handle pointer\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }
#endif

  p_alf_pal_thread = (alf_pal_thread_t *) thread_handle;
#ifdef _ALF_CFG_CHECK_STRICT_
  if (p_alf_pal_thread == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF PAL thread handle\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }
#endif

  if (p_alf_pal_thread->data.task_type == ALF_TASK_TYPE_LIGHTWEIGHT)
    return 0;

  pkt_queue = &p_alf_pal_thread->data.pkt_queue;
  if (_alf_pal_is_req_queue_full(pkt_queue)) {
    /* Scheduler should call wbqueue_query first to avoid this happen */
    ret = -ALF_ERR_NOBUFS;
    goto RET;
  }
  pkt_ptr = (alf_aal_pkt_t *) &pkt_queue->pkts[pkt_queue->ppu_info.rear];

  /* Init the packet, set the work block header according to PAL work block */
  ret = _alf_pal_pkt_init(p_alf_pal_thread, pkt_ptr, NULL, context_to_set, context_to_get, 0L, ALF_AAL_PKT_CTX_SWAP);
  if(ret < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "context swap req pkt init failed\n");
    goto RET;
  }

  /* Add the work block processing packet into packet queue */
  _alf_pal_req_queue_enqueue(p_alf_pal_thread, pkt_ptr);

RET:
  return ret;

}


/**
 * ALF PAL thread context merge rutine
 *  This function loads a temporary thread context buffer into the accelerator 
 *  and lets the accelerator's runtime call the thread context merge method 
 *  after it finishes already enqueued work blocks. 
 *
 * Parameters
 *  thread_handle [in]	   the thread handle
 *  context_to_merge [in]  context that is merged to the threads context
 *
 * Returns
 *   = 0	success
 *   < 0	failure
 *    ALF_ERR_PERM	the thread does not have context
 *    ALF_ERR_BADF	invalid thread handle
 *    ALF_ERR_NOBUFS	the available memory on the accelerator can not hold 
 *                      the temporary context buffer
 *    ALF_ERR_GENERIC	generic error
 *    ALF_ERR_ACCEL	accelerator error
 */
int alf_pal_thread_context_merge(alf_pal_thread_handle thread_handle, alf_data_addr64_t context_to_merge)
{
  alf_pal_thread_t *p_alf_pal_thread;
  alf_aal_pkt_t *pkt_ptr;
  alf_aal_pkt_queue_t *pkt_queue;
  int ret = 0;

#ifdef _ALF_CFG_CHECK_STRICT_
  if (thread_handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid task handle pointer\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }
#endif

  p_alf_pal_thread = (alf_pal_thread_t *) thread_handle;
#ifdef _ALF_CFG_CHECK_STRICT_
  if (p_alf_pal_thread == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF thread handle\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }
#endif

  pkt_queue = &p_alf_pal_thread->data.pkt_queue;
  if (_alf_pal_is_req_queue_full(pkt_queue)) {
    /* Scheduler should call wbqueue_query first to avoid this happen */
    ret = -ALF_ERR_NOBUFS;
    goto RET;
  }
  pkt_ptr = (alf_aal_pkt_t *) &pkt_queue->pkts[pkt_queue->ppu_info.rear];

  /* Initialize the packet */
  ret = _alf_pal_pkt_init(p_alf_pal_thread, pkt_ptr, NULL, 0L, 0L, context_to_merge, ALF_AAL_PKT_CTX_MERGE);
  if(ret < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "context merge req pkt init failed\n");
    goto RET;
  }

  /* Add the packet into packet queue */
  _alf_pal_req_queue_enqueue(p_alf_pal_thread, pkt_ptr);

RET:
  return ret;
}






#if 0 // to be removed


/**
 * ALF PAL dtl group create
 *  This function creates a data transfer list group handle for holding related
 *  data transfer lists.
 *
 * Parameters
 *  platform_handle [in]	the platform handle
 *  dataset_handle [in]		the data set handle or NULL if there is no associated data set
 *  dtl_grp_handle [in/out]	a pointer to buffer that receives the created 
 *                              handle upon success.  Upon failure, the 
 *                              dtl_grp_handle is set to NULL.
 *
 * Returns
 *   = 0	success
 *   < 0	failure
 *     ALF_ERR_INVAL	invalid argument, e.g. NULL pointer to dtl_handle
 *     ALF_ERR_BADF	invalid platform handle
 *     ALF_ERR_NOMEM	out of memory
 *     ALF_ERR_GENERIC	generic error
 */
int alf_pal_dtl_group_create(alf_pal_handle platform_handle, alf_pal_dataset_handle dataset_handle
                             __attribute__ ((unused)), alf_pal_dtl_group_handle * dtl_grp_handle)
{
  alf_pal_descriptor_t *p_alf_pal_desc;
  alf_data_transfer_info_t *dtl_info = NULL;
  mfc_element_t *dma_elmnt_ptr;
  alf_mfc_dma_list_t *dma_list_ptr;
  unsigned int dtl_buf_size;
  unsigned int dma_elmnts_size;
  unsigned int dma_list_size;
  int ret = 0;

  p_alf_pal_desc = (alf_pal_descriptor_t *) platform_handle;
#ifdef _ALF_CFG_CHECK_STRICT_
  if(p_alf_pal_desc == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF PAL handle\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }
#endif

  /* Alloc the Memory for dtl group
   *    Including DTL Lists Buffer and DMA Elements Buffer
   */
  dtl_buf_size = _ALF_DMA_SIZE_ALIGN_(sizeof(alf_data_transfer_info_t));
  dma_elmnts_size = _ALF_DMA_DEFAULT_ELEMENT_NUM * _ALF_MFC_ELEMENT_SIZE;
  dma_list_size = _ALF_MAX_DTL_NUM * sizeof(alf_mfc_dma_list_t);

  dtl_info = (alf_data_transfer_info_t *) calloc_align(1, dtl_buf_size, 7);
  if (dtl_info == NULL) {
    ret = -ALF_ERR_NOMEM;
    goto RET;
  }

  dma_elmnt_ptr = (mfc_element_t *) calloc_align(1, dma_elmnts_size, 7);
  if (dma_elmnt_ptr == NULL) {
    free(dtl_info);
    ret = -ALF_ERR_NOMEM;
    goto RET;
  }
  
  dma_list_ptr = (alf_mfc_dma_list_t *) calloc_align(1, dma_list_size, 7);
  if (dtl_info == NULL) {
    ret = -ALF_ERR_NOMEM;
    goto RET;
  }
  /* Init the data transfer info 
   *   Max DMA List Number is fixed, DMA elements buffer can be enlarged
   */
  dtl_info->dmalist_num = 0;
  dtl_info->max_elmnts_num = _ALF_DMA_DEFAULT_ELEMENT_NUM;
  dtl_info->entry_desc_ea = 0LL;

  PTR_TO_ADDR64(dma_elmnt_ptr, dtl_info->elmnts_ea);
  PTR_TO_ADDR64(dma_list_ptr, dtl_info->dmalist_ea);

  dtl_info->elmnts_num = 0;

  *dtl_grp_handle = dtl_info;

RET:
  return ret;
}


/** 
 * ALF PAL dtl group destroy
 *  This function releases the data transfer list group data structure and all 
 *  data transfer lists in the group.
 *
 * Parameters
 *  dtl_grp_handle [in]	the data transfer list group handle
 *  
 * Returns
 *   = 0	success
 *   < 0	failure
 *    ALF_ERR_BADF	invalid handle
 *    ALF_ERR_BUSY	the data transfer list is still in use (TBD, shall we)
 *    ALF_ERR_GENERIC	generic error
 */
int alf_pal_dtl_group_destroy(alf_pal_dtl_group_handle dtl_grp_handle)
{
  int ret = 0;
  alf_data_transfer_info_t *dtl_info = NULL;
  mfc_element_t *dma_elmnt_ptr = NULL;
  alf_mfc_dma_list_t *dma_list_ptr = NULL;

  /* Free all the resource allocated when gtl group crate */
  dtl_info = (alf_data_transfer_info_t *) dtl_grp_handle;
#ifdef _ALF_CFG_CHECK_STRICT_
  if (dtl_info != NULL) {
#endif
    ADDR64_TO_PTR(dtl_info->elmnts_ea, mfc_element_t *, dma_elmnt_ptr);
    //dma_elmnt_ptr = (mfc_element_t *) ((unsigned int) dtl_info->elmnts_ea);
    ADDR64_TO_PTR(dtl_info->dmalist_ea, alf_mfc_dma_list_t *, dma_list_ptr);

    if (dma_elmnt_ptr != NULL) {
      free_align(dma_elmnt_ptr);
    }
    if (dma_list_ptr != NULL) {
      free_align(dma_list_ptr);
    }
    free_align(dtl_info);
#ifdef _ALF_CFG_CHECK_STRICT_
  } else
    ret = -ALF_ERR_BADF;
#endif

  return ret;
}


/**
 * ALF PAL dtl create routine
 *  This function creates a data transfer list in the group for later entry 
 *  addition.
 *
 * Parameters
 *  dtl_grp_handle [in]	the data transfer list group handle
 *  buffer_type [in]		the buffer_type
 *  dtl_handle [in/out]	a pointer to buffer that receives the created handle 
 *                      upon success.  Upon failure, the dtl_handle is set to 
 *                      NULL.
 *
 * Returns
 *   = 0	success
 *   < 0	failure
 *     ALF_ERR_INVAL	invalid argument, e.g. NULL pointer to dtl_handle
 *     ALF_ERR_BADF	invalid platform handle
 *     ALF_ERR_NOMEM	out of memory
 *     ALF_ERR_GENERIC	generic error
 */
int alf_pal_dtl_create(alf_pal_dtl_group_handle dtl_grp_handle, ALF_BUF_TYPE_T buffer_type,
                       unsigned int local_offset, alf_pal_dtl_handle * dtl_handle)
{
  alf_data_transfer_info_t *dtl_info;
  alf_mfc_dma_list_t *dma_list_ptr;
  unsigned int dmalist_index;
  int ret = 0;

  dtl_info = (alf_data_transfer_info_t *) dtl_grp_handle;
#ifdef _ALF_CFG_CHECK_STRICT_
  if(dtl_info == NULL || dtl_handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid dtl group handle or dtl handle\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }
#endif

  if (dtl_info->dmalist_num >= _ALF_MAX_DTL_NUM) {
    ret = -ALF_ERR_NOMEM;
    goto RET;
  }

  /* Get the index of dtl */
  dmalist_index = dtl_info->dmalist_num;
  
  ADDR64_TO_PTR(dtl_info->dmalist_ea, alf_mfc_dma_list_t *, dma_list_ptr);
  dma_list_ptr += dmalist_index;
  
  /* Init the dma list */
  dma_list_ptr->eah32 = 0;
  dma_list_ptr->elmnt_offset = dtl_info->elmnts_num;
  dma_list_ptr->elmnt_cnt = 0;
  dma_list_ptr->ls_off = local_offset;
  dma_list_ptr->cur_ls_size = 0;
  dma_list_ptr->type  = buffer_type;
  dtl_info->dmalist_num++;

  *dtl_handle = dmalist_index;

RET:
  return ret;
}


/**
 * ALF PAL dtl entry add
 *  This function adds an entry to the data transfer list.
 *
 * Parameters
 *  dtl_grp_handle [in]	the data transfer list group handle
 *  dtl_handle [in]	the data transfer list handle
 *  size [in]	        the size of the data in unit of the data type
 *  address [in]	a host memory address that the data is read or written 
 *  data_type [in]	the type of the data as defined by ALF_DATA_TYPE_T
 *
 * Returns
 *  = 0 	success
 *  < 0         failure
 *   ALF_ERR_BADF	invalid data transfer list handle
 *   ALF_ERR_INVAL	invalid argument
 *   ALF_ERR_FAULT	invalid host address or host address plus the transfer 
 *                      size is out of allowed range
 *   ALF_ERR_2BIG	the added entry overflows the accelerator address range
 *   ALF_ERR_NOMEM	out of memory
 *   ALF_ERR_GENERIC	generic error
 */
int alf_pal_dtl_entry_add(alf_pal_dtl_group_handle dtl_grp_handle,
                          alf_pal_dtl_handle dtl_handle,
                          unsigned int size, alf_data_addr64_t address, ALF_DATA_TYPE_T data_type)
{
  alf_data_transfer_info_t *dtl_info;
  alf_data_addr64_t ea_remote;
  int data_type_size = 0;
  int ret = 0;
  dtl_info = (alf_data_transfer_info_t *) dtl_grp_handle;

  /* We do nothing about the bye order transformation, we just check the data type
   * and size 
   */
  data_type_size = ALF_GET_SIZE_OF_TYPE(data_type);
#ifdef _ALF_CFG_CHECK_STRICT_
  if (data_type_size == 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid data type\n");
    ret = -ALF_ERR_INVAL;
    goto RET;
  }
#endif

  size *= data_type_size;
#ifdef _ALF_CFG_CHECK_STRICT_
  if (size & (data_type_size - 1)) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid data size which is aligned to data type\n");
    ret = -ALF_ERR_NOBUFS;
    goto RET;
  }
#endif

  ea_remote = address;

  if (!IS_VALID_DMA_SIZE(size) || size == 0 || ea_remote == 0 || !_ALF_IS_SIMD_ALIGNED_(ea_remote)) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid dma entry data size_of_data %d ea_remote 0x%llx \n", size, ea_remote);
    ret = -ALF_ERR_INVAL;
    goto RET;
  }


  /* Add the DMA elements in MFC DMA List
   *   If Current DMA List reach max elements number, New element will be inserted 
   *   in the next MFC DMA List.
   *   If DMA elements buffer has no free space to hold the new element, DMA elements 
   *   buffer would be realloced, alf_data_transfer_info_t->elmnts_ea should updated 
   *   with the new address.
   */
#ifdef _ALF_32B_

  if((ret = _alf_pal_dtl_entry_add(dtl_info, dtl_handle, ea_remote, size)) < 0) {
    goto RET;
  }

#elif _ALF_64B_
  /* This entry across the 4G border, so split this entry into two */
  if( (ea_remote >> 32) != ((ea_remote + size) >> 32) ) {
    alf_data_addr64_t split_size;
    alf_data_addr64_t border_addr;

    border_addr = (ea_remote + size) & BORDER_MASK;
    split_size = border_addr - ea_remote;

    if((ret = _alf_pal_dtl_entry_add(dtl_info, dtl_handle, ea_remote, split_size)) < 0) {
      goto RET;
    }
    if((ret = _alf_pal_dtl_entry_add(dtl_info, dtl_handle, border_addr, size - split_size)) < 0) {
      goto RET;
    }

  }
  else {
    if((ret = _alf_pal_dtl_entry_add(dtl_info, dtl_handle, ea_remote, size)) < 0 ){
      goto RET;
    }
  }

#endif

RET:
  return ret;
}


/**
 * ALF PAL DTL Handle dump
 *  This function prints the contents of all of the fields of the data structure
 *  that is pointed to by the given ALF data transfer list handle.
 */
void alf_pal_dtl_dump(char *prefix, alf_pal_dtl_group_handle dtl_grp_handle, alf_pal_dtl_handle handle)
{
  int dmalist_index;
  alf_data_transfer_info_t *dtl_info;
  alf_mfc_dma_list_t *dma_list_ptr;

  printf("%salf_pal_dtl: %p\n", prefix, dtl_grp_handle);

  if (dtl_grp_handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "dtl group handle can not be NULL\n");
    return;
  }

  dtl_info = (alf_data_transfer_info_t *) dtl_grp_handle;

  printf("%s\tdmalist_num: %d\n", prefix, dtl_info->dmalist_num);
  printf("%s\tmax_elmnts_num: %d\n", prefix, dtl_info->max_elmnts_num);
  printf("%s\telmnts_ea: 0x%016llx\n", prefix, dtl_info->elmnts_ea);
  printf("%s\tentry_desc_ea: 0x%016llx\n", prefix, dtl_info->entry_desc_ea);
  printf("%s\telmnts_num: %d\n", prefix, dtl_info->elmnts_num);
  printf("%s\tlsptr_edesc: 0x%08x\n", prefix, dtl_info->lsptr_edesc);

  dmalist_index = (int) handle;
  
  ADDR64_TO_PTR(dtl_info->dmalist_ea, alf_mfc_dma_list_t *, dma_list_ptr);
  dma_list_ptr += dmalist_index;
  
  printf
      ("%s\tdmalist_ptr[%d]: eah32: 0x%08x, elmnt_cnt: %d, elmnt_offset: 0x%08x, ls_off: 0x%08x, cur_ls_size: 0x%08x\n",
       prefix, dmalist_index, dma_list_ptr->eah32,
       dma_list_ptr->elmnt_cnt, dma_list_ptr->elmnt_offset,
       dma_list_ptr->ls_off, dma_list_ptr->cur_ls_size);
  
  fflush(stdout);
}


#endif


/**
 * 
 *   This function registers an error handler callback for the PAL layer.  Please refer to 
 * the ALF high level design for documentation of the expected behaviors of the callback. 
 * Please note that an ALF common layer code implementation is suggested to register their 
 * internal error handler callback in order to trap the PAL layer problems.
 * 
 * Parameters
 *   platform_handle [in]	the platform handle
 *   call_back_function [in]	the function pointer of the callback.  A NULL unregisters 
 *                              the previously registered callback
 *   p_context_data [in]	a pointer that is passed to the callback when it is invoked
 * 
 * Returns
 *   = 0	success
 *   < 0	failure
 *    ALF_ERR_BADF	invalid platform handle
 *    ALF_ERR_PERM	the operation is not permitted in current context
 *    ALF_ERR_GENERIC	generic internal error
 */
int alf_pal_error_handler_register(alf_pal_handle platform_handle /*in */  ,
                                   alf_pal_error_handler_t call_back_function  /*in */
                                   , void *p_context_data /*in */ )
{
  alf_pal_descriptor_t *p_alf_pal_desc;
  int ret = 0;

#ifdef _ALF_CFG_CHECK_STRICT_
  if (platform_handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF runtime handle pointer\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }
#endif

  p_alf_pal_desc = (alf_pal_descriptor_t *) platform_handle;
#ifdef _ALF_CFG_CHECK_STRICT_
  if (_alf_pal_check_handle(p_alf_pal_desc) < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid ALF runtime handle\n");
    ret = -ALF_ERR_BADF;
    goto RET;
  }
#endif

  if(call_back_function == NULL) {
    p_alf_pal_desc->err_handler = NULL;
    p_alf_pal_desc->err_handler_ctx = NULL;
  }
  else {
    p_alf_pal_desc->err_handler = call_back_function;
    p_alf_pal_desc->err_handler_ctx = p_context_data;
  }

#ifdef _ALF_CFG_CHECK_STRICT_
RET:
#endif
  return ret;
}

/* Create a data set */
int alf_pal_dataset_create(alf_pal_handle platform_handle __attribute__ ((unused)), alf_pal_dataset_handle * p_pal_dataset __attribute__ ((unused))) {
	return 0;
}

/* Add buffer to a data set */
int alf_pal_dataset_buffer_add(alf_pal_dataset_handle pal_dataset __attribute__ ((unused)), alf_data_addr64_t addr __attribute__ ((unused)), unsigned long long size __attribute__ ((unused)),
                               ALF_DATASET_ACCESS_MODE_T access_mode __attribute__ ((unused))) {
	return 0;
}

/* End adding buffers to a data set */
int alf_pal_dataset_close(alf_pal_dataset_handle pal_dataset __attribute__ ((unused)))
{
	return 0;
}

/* Associate a data set to a thread */
int alf_pal_thread_dataset_associate(alf_pal_thread_handle thread_handle __attribute__ ((unused)), alf_pal_dataset_handle pal_dataset __attribute__ ((unused))) {
	return 0;
}

/* Put a data set to the accelerators and do not wait */
int alf_pal_dataset_put_no_wait(alf_pal_dataset_handle pal_dataset __attribute__ ((unused))) {
	return 0;
}
  
/* Wait for data set put to the accelerators to complete */
int alf_pal_dataset_wait_for_put(alf_pal_dataset_handle pal_dataset __attribute__ ((unused))) {
	return 0;
}
  
/* Get a data set from first accelerator */
int alf_pal_dataset_get_and_wait(alf_pal_dataset_handle pal_dataset __attribute__ ((unused))) {
	return 0;
}

/* Destroy a data set */
int alf_pal_dataset_destroy(alf_pal_dataset_handle pal_dataset __attribute__ ((unused))) {
	return 0;
}
  
/* Dump a data set*/
void alf_pal_dataset_dump(char *prefix __attribute__ ((unused)), alf_pal_dataset_handle pal_dataset __attribute__ ((unused))) {
	return;
}
