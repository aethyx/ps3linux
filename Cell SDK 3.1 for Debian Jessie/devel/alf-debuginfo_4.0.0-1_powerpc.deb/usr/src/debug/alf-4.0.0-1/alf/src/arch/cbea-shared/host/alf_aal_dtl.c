/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pthread.h>
#include <libmisc.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <dirent.h>

#include "alf_common_platform.h"
#include "alf_misc.h"
#include "alf_misc_ppu.h"
#include "alf_common.h"
#include "alf_api_local.h"
#include "alf_debug.h"
#include "alf_aal.h"
#include <alf_errno.h>

#ifdef _ALF_PLATFORM_HYBRID_   // FIXME:  this is not needed for big endian hybrid host
    #define  _ALF_DTL_GEN_TYPE_TABLE_ 1    // little endian hybrid host that needs to do the endianness translation for data
    #define  _ALF_DTL_GEN_LITTLE_ENDIAN 1   // little endian hybrid host generate MFC DMA list
#else
    #undef _ALF_DTL_GEN_TYPE_TABLE_
    #undef _ALF_DTL_GEN_LITTLE_ENDIAN 
#endif

//********************************************************
// APIs
//********************************************************


/*
  *  check PAL DTL for problems and estimize the needed Cell DTL size
  */

// = 0 success, return the number of entries for Cell DTL
// < 0 error,    return the location by p_ovl_io_entry
//     ALF_ERR_FAULT	invalid host address or host address plus the transfer size is out of allowed range
//     ALF_ERR_2BIG	some of the entries overflows the accelerator address range

int _alf_pal_dtl_check(alf_pal_dtlist_t *ppal_dtl,  alf_pal_task_info_t *ptask_info __attribute__((unused)),
    unsigned int *p_ovl_io_entry, unsigned int *p_in_entry, unsigned int *p_out_entry)
{
    unsigned int total_dtl_size = 0; // counts for DTL
    unsigned int total_dtl_entry = 0; // counts for DTL
    unsigned int total_dtl = 0; // counts for DTL
    unsigned int curr;
    //dtl entry num, do not include type entry & header
    unsigned int io_dtl_entry = 0;
    unsigned int in_dtl_entry = 0;
    unsigned int out_dtl_entry = 0;

    curr = 0;

    // for each table, we count and accumulate the total_dtl_size
    *p_in_entry = 0;
    *p_out_entry = 0;
    *p_ovl_io_entry = 0;
    
    while(ppal_dtl[curr].header.num_entries != 0)  // we end the table with a size zero entry
    {
        unsigned int i, last_entry; // the loop counter
        unsigned int curr_dtl_cnt; // the counter of dtl entries
#if defined(_ALF_CFG_CHECK_STRICT_) || defined(_ALF_DTL_GEN_TYPE_TABLE_)  
        unsigned int curr_type_cnt; // the counter of type entries for this list
        ALF_DATA_TYPE_T last_type;     // last type
#endif
        unsigned int max_size;
        unsigned int buf_offset;
        unsigned int *p_entry;
        unsigned int *p_dtl_entry;
        
#ifdef _ALF_64B_    // for the cross 4GB address issue in 64 bit mode
        unsigned int last4gb;  // last 4GB address
#endif        

        // check the buffer types and size
        // we have the DTL structure that ovl_io is the first section, then in+ovl_in, then out+ovl_out
        // there will be a NIL header between in and out DTL
        // the SPU will load the ovl_io + in first,  then load the out to replace the in section.
        //  here is the details 
        //  PPU DTL            SPU DTL-IN      SPU_DTL-OUT
        // ---------------        ----------      -----------
        // | OVL_IO      |   ->   | OVL_IO |  ->  | OVL_IO  |
        // ---------------        ----------      -----------
        // | IN+OVL_IN   |   ->   | IN     |  /-> | OUT     |
        // ---------------        ----------  |   -----------  
        // | OUT+OVL_OUT |   ----------------/  
        // --------------- 

        // here we count them seperately
        
        switch(ppal_dtl[curr].header.buffer_type)
        {
            case ALF_BUF_IN:
                max_size = ptask_info->input_buffer_size;
                p_entry = p_in_entry;
                p_dtl_entry = &in_dtl_entry;
                break;

            case ALF_BUF_OUT:
                max_size = ptask_info->output_buffer_size;
                p_entry = p_out_entry;
                p_dtl_entry = &out_dtl_entry;
                break;

            case ALF_BUF_OVL_IN:
                max_size = ptask_info->overlapped_buffer_size;
                p_entry = p_in_entry;
                p_dtl_entry = &in_dtl_entry;
                break;
                
            case ALF_BUF_OVL_OUT:
                max_size = ptask_info->overlapped_buffer_size;
                p_entry = p_out_entry;
                p_dtl_entry = &out_dtl_entry;
                break;

            case ALF_BUF_OVL_INOUT:
                max_size = ptask_info->overlapped_buffer_size;
                p_entry = p_ovl_io_entry;
                p_dtl_entry = &io_dtl_entry;
                break;
            default:
                // what wrong types you give me ?
                *p_ovl_io_entry = curr;
                return -ALF_ERR_FAULT;
        }

        // it is out of range at the beginning
        if(ppal_dtl[curr].header.local_offset >= max_size)
        {
            _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Out of local memory range in DTL entry[%d]\n", curr);
            *p_ovl_io_entry = curr;
            return -ALF_ERR_2BIG;
        }

        // remember the offset, avoiding the pointer magic to access it in the future
        // seems compiler may optimize it anyway if no alias can be assumed

        buf_offset = ppal_dtl[curr].header.local_offset;  // local offset
        
        last_entry = ppal_dtl[curr].header.num_entries+curr;  // the last entry

        curr_dtl_cnt = 0;  // not counted yet

#ifdef _ALF_DTL_GEN_TYPE_TABLE_  // that so said hybrid
        curr_type_cnt = 1;  // at least one entry
#endif
#if defined(_ALF_CFG_CHECK_STRICT_) || defined(_ALF_DTL_GEN_TYPE_TABLE_)  
        last_type = ppal_dtl[curr+1].entry.data_type;  // type set to the first entry
#endif

#ifdef _ALF_64B_    // for the cross 4GB address issue in 64 bit mode
        last4gb = _ALF_CELL_GET_HIGH_ADDRESS(ppal_dtl[curr+1].entry.address);
#endif        

        // for each entry of the table
        for(i=curr+1; i<=last_entry; i++)  // loop through the table entries
        {
            unsigned int entry_size = ALF_GET_SIZE_OF_TYPE(ppal_dtl[i].entry.data_type)*ppal_dtl[i].entry.size; // ah, shall we consider the multiplication overflow problem here ?
#if defined(_ALF_64B_) || defined(_ALF_CFG_CHECK_STRICT_)        // for the cross 4GB address issue in 64 bit mode
            alf_data_addr64_t curr_addr = ppal_dtl[i].entry.address;  // current address
#if defined(_ALF_64B_)        // for the cross 4GB address issue in 64 bit mode
            unsigned int curr4gb; // current 4GB address
            unsigned int entry_size_above4gb=0;  // entry size above 4GB
            alf_data_addr64_t addr_4gb;  // temprary for computing 4GB address
#endif
#endif        

            
#ifdef _ALF_CFG_CHECK_STRICT_  //we do check if the entry size is unresonably huge such that the calcualted entry_size can be wrong by 32 bit math
            if(ppal_dtl[i].entry.size > 1024*1024)  // most of the time, 256*1024 is already good enough for cell
            {
                _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Out of local memory range in DTL entry[%d]\n", i);
                *p_ovl_io_entry = curr;
                return -ALF_ERR_2BIG;
            }
#endif            
            // check if they goes across the bound
            if(entry_size + buf_offset > max_size)
            {
                _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Out of local memory range in DTL entry[%d]\n", i);
                *p_ovl_io_entry = curr;
                return -ALF_ERR_2BIG;
            }
            //!!  the following piece of code is very Cell specific
            else
            {

#if defined(_ALF_CFG_CHECK_STRICT_)  //FIXME: should this be a strict check only option ?
                // we check if the address alignment requirement is met
                // FIXME: shall we hide all these 0x0f magic numbers by macro ?
                if(entry_size < 16)  // if it is less than 16, it must be 1,2,4,8 and naturelly aligned and on identical low 4 bit address
                {
                    if( (entry_size != 1 && entry_size != 2 && entry_size != 4 && entry_size != 8) || // so this is 1,2,4,8
                        (buf_offset & 0x0f) != ((unsigned int)curr_addr & 0x0f) ||  // the same low 4 bit address
                        ((buf_offset & (ALF_GET_SIZE_OF_TYPE(last_type)-1)) != 0 )    // nature align for types
                      )
                    {
                        _ALF_DPRINTF(_ALF_ERR_LEVEL_BAD_, "Unaligned DMA Address in DTL entry[%d]: size %d, local %08x, remote %016llu \n", 
                                        i, entry_size, buf_offset,  curr_addr);
                        *p_ovl_io_entry = curr;
                        return -ALF_ERR_FAULT;
                    }
                }
                // else everyone must be aligned to 16 byte, no exception allowed :-(
                else if((entry_size & 0x0f) != 0 ||
                        (buf_offset & 0x0f) != 0 || 
                        (curr_addr & 0x0f) != 0)  
                {
                    _ALF_DPRINTF(_ALF_ERR_LEVEL_BAD_, "Unaligned DMA Address in DTL entry[%d]: size %d, local %08x, remote %016llu \n", 
                                    i, entry_size, buf_offset,  curr_addr);
                    *p_ovl_io_entry = curr;
                    return -ALF_ERR_FAULT;
                }
#endif


                // then we need to deal with the 16KB, 4GB and 2048 entry problems

#ifdef _ALF_64B_   // 64 bit mode, we need to take care of the 4GB issue
                do  // this do is only used for 64 bit mode
                {
                    curr4gb = _ALF_CELL_GET_HIGH_ADDRESS(curr_addr); // current 4GB address
                    if(last4gb !=  curr4gb) // first to check if we have changed the 4GB address
                    {
                        // we already need a new DTL since we changed the 4GB
                        // update the total size and make sure we pad it to even entry
#ifdef _ALF_DTL_GEN_TYPE_TABLE_  // that so said hybrid
                        total_dtl_size += (curr_dtl_cnt + _ALF_AAL_DTL_HEADER_SIZE + curr_type_cnt + 1)&0xfffffffe;
                        curr_type_cnt = 1;
                        last_type = ppal_dtl[i].entry.data_type;
#else
                        total_dtl_size += (curr_dtl_cnt + _ALF_AAL_DTL_HEADER_SIZE + 1)&0xfffffffe;
#endif
                        total_dtl_entry += curr_dtl_cnt;
                        total_dtl ++;

                        curr_dtl_cnt = 0;
                        last4gb = curr4gb;
                    }
                    
                    // then check if we cross that magic 4GB within this entry
                    addr_4gb  = curr_addr + (alf_data_addr64_t)entry_size;  // certainly we can let the compiler to optimize this simple reference, but for readability.
                    
                    if(curr4gb != _ALF_CELL_GET_HIGH_ADDRESS(addr_4gb) && //first the high address differs
                       (unsigned int)addr_4gb != 0)  // then check if it is not just on the boundary
                    {
                        entry_size_above4gb = (unsigned int)addr_4gb;  // the size of section above 4GB, just trunk it to 32 bit
                        entry_size -= entry_size_above4gb;
                        addr_4gb = addr_4gb&0xFFFFFFFF00000000ULL;  // start from zero within the 4GB
                    }

#endif

#if defined(_ALF_CFG_CHECK_STRICT_) || defined(_ALF_DTL_GEN_TYPE_TABLE_)  

                    // then, check if we need to deal with a new data type
                    if(ppal_dtl[i].entry.data_type != last_type)
                    {
                        curr_type_cnt ++;
                        last_type = ppal_dtl[i].entry.data_type;
                    }
#endif

                    // _ALF_32B_ ,  or one section of inside 4GB in the case of 64 bit
                    // currently we do not have the cross 4GB problem
                    if(entry_size > _CELL_DMA_MAX_SIZE)  // this is a Cell Specific limitation
                    {
                        curr_dtl_cnt += (entry_size + _CELL_DMA_MAX_SIZE - 1)/_CELL_DMA_MAX_SIZE; // break the list to segments of multiple transfers
                    }
                    else  // fit into one transfer
                    {
                        curr_dtl_cnt++;
                    }
                    
                    // update the local buffer offset, it will be moved to next 16 byte address as specified in Cell Manual
                    buf_offset = (buf_offset + entry_size + 15)&0xfffffff0; 

                    // here comes the 2048 problem
                    if(curr_dtl_cnt > _CELL_DMALIST_MAX_SIZE)   // need to break the current list to two
                    // It is safe to assume "(curr_dtl_cnt /_CELL_DMALIST_MAX_SIZE) == 1", can I ?
                    {
                        // update the total size and make sure we pad it to even entry
#ifdef _ALF_DTL_GEN_TYPE_TABLE_  // that so said hybrid
                        total_dtl_size += (_CELL_DMALIST_MAX_SIZE + _ALF_AAL_DTL_HEADER_SIZE + curr_type_cnt + 1)&0xfffffffe;
                        curr_type_cnt = 1;
                        // last_type unchanged
#else
                        total_dtl_size += (_CELL_DMALIST_MAX_SIZE + _ALF_AAL_DTL_HEADER_SIZE + 1)&0xfffffffe;
#endif
                        total_dtl_entry += curr_dtl_cnt;
                        total_dtl++;
                        curr_dtl_cnt -= _CELL_DMALIST_MAX_SIZE ; 
                    }

#ifdef  _ALF_64B_
                    // curr_addr += entry_size;  // we do not use it here, just for readability
                    entry_size = entry_size_above4gb;
                    curr_addr = addr_4gb;
                    entry_size_above4gb = 0;  // we only need a single loop here
                }
                while(entry_size != 0);
#endif
            }   // else         
            
        }// for

        // accumulate it now
        // update the total size and make sure we pad it to even entry
#ifdef _ALF_DTL_GEN_TYPE_TABLE_  // that so said hybrid
        total_dtl_size += (curr_dtl_cnt + _ALF_AAL_DTL_HEADER_SIZE + curr_type_cnt + 1)&0xfffffffe;
#else
        total_dtl_size += (curr_dtl_cnt + _ALF_AAL_DTL_HEADER_SIZE + 1)&0xfffffffe;
#endif
        total_dtl_entry += curr_dtl_cnt;
        total_dtl ++;

        *p_entry += total_dtl_size;  // accumulate according to type
        *p_dtl_entry += total_dtl_entry;  // accumulate according to type

        total_dtl_size = 0;  // for another count
        total_dtl_entry = 0;  // for another count
        
        curr = last_entry+1;  // and go to next table in chain

    }// while

    // then check if we have enough DTL for the accelerator side
    unsigned int accel_num_dtl = io_dtl_entry + max(in_dtl_entry, out_dtl_entry);
    // check if that requires larger DTL buffer than what given in advance
    if(accel_num_dtl > ptask_info->dt_list_entries || total_dtl > ptask_info->dt_list_num )
    {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_BAD_, "The accelerator side DTL buffer is too small (%d) than required (%d)\n",
                    ptask_info->dt_list_entries, accel_num_dtl);
      return -ALF_ERR_RANGE;  // FIXME: how to define this error ?
    }
            
    // we are here finally
    
    return 0;  // vola
}


/*
  *  convert PAL DTL to Cell DTL
  */

void _alf_pal_dtl_convert(alf_pal_dtlist_t *ppal_dtl,  alf_pal_task_info_t *ptask_info __attribute__ ((unused)),
             alf_aal_dtl_t *pdtl,  unsigned int num_ovl_io, unsigned int num_in, unsigned int num_out)
{
    unsigned int ovl_io_loc, in_loc, out_loc;  // current new header location for the three sections
    unsigned int curr;   // current PAL DTL header location

#ifdef _ALF_DTL_GEN_TYPE_TABLE_  // that so said hybrid
    alf_aal_dtl_t type_list[_CELL_DMALIST_MAX_SIZE];  // a temporary type list buffer, we will copy it to the end of DMA list after the DMA list is constructed
#endif    

    curr = 0;  // the table always starts from zero

    // we have the DTL structure that ovl_io is the first section, then in+ovl_in, then out+ovl_out
    // there will be a NIL header between in and out DTL
    // the SPU will load the ovl_io + in first,  then load the out to replace the in section.
    //  here is the details 
    //  PPU DTL            SPU DTL-IN      SPU_DTL-OUT
    // ---------------        ----------      -----------
    // | OVL_IO      |   ->   | OVL_IO |  ->  | OVL_IO  |
    // ---------------        ----------      -----------
    // | IN+OVL_IN   |   ->   | IN     |  /-> | OUT     |
    // ---------------        ----------  |   -----------  
    // | OUT+OVL_OUT |   ----------------/  
    // --------------- 

    ovl_io_loc = 0;        // start of OVL_IO
    in_loc = num_ovl_io;   // start of IN+OVL_IN
    out_loc = num_ovl_io + num_in; // start of OUT + OVL_OUT


    // loop through each table    
    while(ppal_dtl[curr].header.num_entries != 0)  // we end the table with a size zero entry
    {
        unsigned int i, last_entry; // the loop counter
        unsigned int curr_dtl_cnt; // the counter of dtl entries
#ifdef _ALF_DTL_GEN_TYPE_TABLE_  // that so said hybrid
        unsigned int curr_type_cnt; // the counter of type entries for this list
        ALF_DATA_TYPE_T last_type;     // last type
#endif
        unsigned int buf_offset;   // offset inside the correspondent local buffer
        unsigned int buf_used;     // the actual buffer used by the correspondent DMA operation
        unsigned int buf_type;     // the current buffer been accessed, always equals to ppal_dtl[curr].header.buffer_type
        unsigned int *p_loc = NULL;     //pointer to location of current table
        alf_aal_dtl_t *pcurr_dtl_entry;  // pointer to the table currently been filled
        
#ifdef _ALF_64B_    // for the cross 4GB address issue in 64 bit mode
        unsigned int last4gb;  // last 4GB address
#endif        

        // find the new table location based on buffer type
        buf_type = (unsigned int)ppal_dtl[curr].header.buffer_type;
        switch(ppal_dtl[curr].header.buffer_type)
        {
            case ALF_BUF_IN:
                p_loc = &in_loc;
                break;

            case ALF_BUF_OUT:
                p_loc = &out_loc;
                break;

            case ALF_BUF_OVL_IN:
                p_loc = &in_loc;
                break;
                
            case ALF_BUF_OVL_OUT:
                p_loc = &out_loc;
                break;

            case ALF_BUF_OVL_INOUT:
                p_loc = &ovl_io_loc;
                break;
        }

        pcurr_dtl_entry = pdtl + *p_loc;  // so here is the table location


        // remember the offset, avoiding the pointer magic to access it in the future
        // seems compiler may optimize it anyway if no alias can be assumed

        buf_offset = ppal_dtl[curr].header.local_offset;  // local offset
        
        last_entry = ppal_dtl[curr].header.num_entries+curr;  // the last entry

        // reset the counters
        curr_dtl_cnt = 0;  // not counted yet

#ifdef _ALF_DTL_GEN_TYPE_TABLE_  // that so said hybrid
        curr_type_cnt = 1;  // at least one entry
        last_type = ppal_dtl[curr+1].entry.data_type;  // type set to the first entry
#endif

        // fill the header
        pcurr_dtl_entry[0].header1.buf_type = _DTL_VAL_16B((unsigned short)buf_type);
        pcurr_dtl_entry[1].header2.ea_high =  _DTL_VAL_32B(_ALF_CELL_GET_HIGH_ADDRESS(ppal_dtl[curr+1].entry.address));
        pcurr_dtl_entry[1].header2.local_offset = _DTL_VAL_32B(buf_offset);

#ifdef _ALF_DTL_GEN_TYPE_TABLE_  // that so said hybrid
        // get the first type entry
        type_list[0].type.type = _DTL_VAL_32B(last_type);
        type_list[0].type.count = 0;  // not counted yet, we will add it till next change
#endif       
            
#ifdef _ALF_64B_    // for the cross 4GB address issue in 64 bit mode
        last4gb = _ALF_CELL_GET_HIGH_ADDRESS(ppal_dtl[curr+1].entry.address);
#endif        

        // for each entry of the table
        for(i=curr+1; i<=last_entry; i++)  // loop through the table entries
        {
            unsigned int entry_size = ALF_GET_SIZE_OF_TYPE(ppal_dtl[i].entry.data_type)*ppal_dtl[i].entry.size; // ah, shall we consider the multiplication overflow problem here ?
            alf_data_addr64_t curr_addr = ppal_dtl[i].entry.address;  // current address
#ifdef _ALF_64B_    // for the cross 4GB address issue in 64 bit mode
            unsigned int curr4gb; // current 4GB address
            unsigned int entry_size_above4gb=0;  // entry size above 4GB
            unsigned int divided_4gb = 0;  // flag if we have do the 4GB division
            alf_data_addr64_t addr_4gb = 0;  // temprary for computing 4GB address
#endif        

            
            // we need to deal with the 16KB, 4GB and 2048 entry problems
            // while filling the DMA list
            // I tried to reuse the code pieces instead of copying all around,
            // so the code can be sort of hard to understand
            //  For one PAL DTL entry, it can be very large and can run across the 4GB
            //  boundary, we need to break it into several small pieces of AAL DTL, 
            //  because of the above mentioned limitations.
            //  The following do-while loop will run until the "entry_size" is consumed
            //

            do  
            
            {
                unsigned int segment_size;

               // check if we need to break the current list to a new one
               // either in the case of over 2048 entries or across 4GB address space

#ifdef _ALF_64B_   // 64 bit mode, we need to take care of the 4GB issue
                curr4gb = _ALF_CELL_GET_HIGH_ADDRESS(curr_addr); // current 4GB address

                if((curr_dtl_cnt == _CELL_DMALIST_MAX_SIZE)   //  the 2048 problem
                    || (last4gb !=  curr4gb)) // first to check if we have changed the 4GB address
#else
                if((curr_dtl_cnt == _CELL_DMALIST_MAX_SIZE))   //  the 2048 problem
#endif
                {
                    // so we need to start a new DTL
                    
                    // finishing current DTL

#ifdef _ALF_DTL_GEN_TYPE_TABLE_  // that so said hybrid
                    // adjust last count for data type size
                    type_list[curr_type_cnt-1].type.count = 
                          _DTL_VAL_32B(type_list[curr_type_cnt-1].type.count / ALF_GET_SIZE_OF_TYPE(last_type));
#endif
                    // update the table header
                    pcurr_dtl_entry[0].header1.num_dtl_entry = _DTL_VAL_16B((unsigned short)curr_dtl_cnt);

#ifdef _ALF_DTL_GEN_TYPE_TABLE_  // that so said hybrid
                    pcurr_dtl_entry[0].header1.num_type_entry = _DTL_VAL_16B((unsigned short)curr_type_cnt);
                    // append the type list
                    memcpy(pcurr_dtl_entry + curr_dtl_cnt + _ALF_AAL_DTL_HEADER_SIZE, 
                        type_list, curr_type_cnt*sizeof(alf_aal_dtl_t));
#else
                    pcurr_dtl_entry[0].header1.num_type_entry = 0;
#endif

                    // padding the table to even size
#ifdef _ALF_DTL_GEN_TYPE_TABLE_  // that so said hybrid
                    curr_dtl_cnt = (curr_dtl_cnt + _ALF_AAL_DTL_HEADER_SIZE + curr_type_cnt + 1)&0xfffffffe;
                    curr_type_cnt = 1;
                    last_type = ppal_dtl[i].entry.data_type;
#else
                    curr_dtl_cnt = (curr_dtl_cnt + _ALF_AAL_DTL_HEADER_SIZE + 1)&0xfffffffe;
#endif
                    pcurr_dtl_entry[0].header1.total_size = _DTL_VAL_16B((unsigned short)curr_dtl_cnt);

                    // update the table header and location pointer
                    *p_loc += curr_dtl_cnt;
                    pcurr_dtl_entry += curr_dtl_cnt;
                    
                    curr_dtl_cnt = 0;
#ifdef _ALF_64B_                        
                    last4gb = curr4gb;
#endif

                    // and begin a new header
                    pcurr_dtl_entry[0].header1.buf_type = _DTL_VAL_16B((unsigned short)buf_type);
                    pcurr_dtl_entry[1].header2.ea_high = _DTL_VAL_32B(_ALF_CELL_GET_HIGH_ADDRESS(curr_addr));
                    pcurr_dtl_entry[1].header2.local_offset = _DTL_VAL_32B(buf_offset);
                    
#ifdef _ALF_DTL_GEN_TYPE_TABLE_  // that so said hybrid
                    // get the first type entry
                    type_list[0].type.type = _DTL_VAL_32B(last_type);  // type is the same
                    type_list[0].type.count = 0;  // not counted yet, we will add it till next change
#endif

                }
                
#ifdef _ALF_64B_ 
                // I'm pretty sure taht we should not have a single entry that run across two 4GB segments in the future
                // unless you can make the SPU's local mem bigger than 4GB.  :-)  That should be a dream in the future.
                // so I only consider the case that we need to divide it once.
                if(0 == divided_4gb)  // check if we already divided it, the flag is used to avoid useless checks in the future
                {
                    // for the case where a single entry run across 4GB, we will divide it into
                    // two parts, that below 4GB and that above 4GB
                    addr_4gb  = curr_addr + (alf_data_addr64_t)entry_size;  // top of the new 4GB address.

                    // the following condition will only be true the first time we need to divide it
                    if(curr4gb != _ALF_CELL_GET_HIGH_ADDRESS(addr_4gb) && //first the high address differs
                       (unsigned int)addr_4gb != 0)  // then check if it is not just on the boundary
                    {
                        entry_size_above4gb = (unsigned int)addr_4gb;  // the size of section above 4GB, just trunk it to 32 bit
                        entry_size -= entry_size_above4gb;
                        addr_4gb = addr_4gb&0xFFFFFFFF00000000ULL;  // start from zero within the new 4GB
                        divided_4gb = 1;
                    }
                }
#endif
                // calculate the real segment size
                
                segment_size = entry_size;  // initially it is the same as entry_size
                if(segment_size > _CELL_DMA_MAX_SIZE)  // this is a Cell Specific limitation
                {
                    segment_size = _CELL_DMA_MAX_SIZE;  // trunk it
                }

#ifdef _ALF_DTL_GEN_LITTLE_ENDIAN  // hybrid little endian  
                // since the size entry is not aligned to byte/short boundary
                // it has to be handled carefully on little endian system
                //    0  1..16  17:31  32:63
                //    n  res    size   eal
                {
                   unsigned char *pd = (unsigned char *)&pcurr_dtl_entry[_ALF_AAL_DTL_HEADER_SIZE + curr_dtl_cnt].dtl;
                   pd[0] = pd[1] = 0;  // notify and reserved[1..15]
                   pd[2] = (unsigned char)(segment_size>>8); // save the &0x7f bit op, since segment_size is always less than 16K
                   pd[3] = (unsigned char)segment_size;
                }
                // the eal is on boundary
                pcurr_dtl_entry[_ALF_AAL_DTL_HEADER_SIZE + curr_dtl_cnt].dtl.eal = _DTL_VAL_32B(curr_addr);

#else
                // fill the entry
                pcurr_dtl_entry[_ALF_AAL_DTL_HEADER_SIZE + curr_dtl_cnt].dtl.size = _DTL_VAL_16B(segment_size);
                pcurr_dtl_entry[_ALF_AAL_DTL_HEADER_SIZE + curr_dtl_cnt].dtl.eal = _DTL_VAL_32B(curr_addr);
                pcurr_dtl_entry[_ALF_AAL_DTL_HEADER_SIZE + curr_dtl_cnt].dtl.notify = 0;
                pcurr_dtl_entry[_ALF_AAL_DTL_HEADER_SIZE + curr_dtl_cnt].dtl.reserved = 0;
#endif

                entry_size -= segment_size;  // next segment, if there is
                curr_addr += segment_size;   // next address
                
                // calculate the current local buffer offset, it will be moved to next 16 byte address as specified in Cell Manual
                buf_used = (buf_offset + segment_size + 15)&0xfffffff0; 

                curr_dtl_cnt++;

#ifdef _ALF_DTL_GEN_TYPE_TABLE_  // that so said hybrid
                // update the type table
                // check if we need to deal with a new data type
                if(ppal_dtl[i].entry.data_type != last_type)
                {
                    // adjust last count for data type size
                    type_list[curr_type_cnt-1].type.count = 
                          _DTL_VAL_32B(type_list[curr_type_cnt-1].type.count / ALF_GET_SIZE_OF_TYPE(last_type));
                    
                    // begin a new entry
                    last_type = ppal_dtl[i].entry.data_type;  // the new type
                    
                    type_list[curr_type_cnt].type.type = _DTL_VAL_32B(last_type);  // remember the type

                    type_list[curr_type_cnt].type.count = buf_used - buf_offset;  // not counted yet, we will add it till next change

                    curr_type_cnt ++;
                }
                else
                {
                    type_list[curr_type_cnt-1].type.count += buf_used - buf_offset;
                }
#endif
                buf_offset = buf_used;
                
                
#ifdef  _ALF_64B_
                // check if we need to run the loop for the divided 4GB case,
                // the entry_size_above4gb is a better condition than divided_4gb
                if(entry_size == 0 && entry_size_above4gb != 0)  
                {
                    entry_size = entry_size_above4gb;
                    curr_addr = addr_4gb;
                    entry_size_above4gb = 0;  // we only need a single entry here
                }
#endif
            }
            while(entry_size != 0);
        }   

        // finishing current DTL
        
#ifdef _ALF_DTL_GEN_TYPE_TABLE_  // that so said hybrid
        // adjust last count for data type size
        type_list[curr_type_cnt-1].type.count = 
              _DTL_VAL_32B(type_list[curr_type_cnt-1].type.count / ALF_GET_SIZE_OF_TYPE(last_type));
#endif        
        // update the table header
        pcurr_dtl_entry[0].header1.num_dtl_entry = _DTL_VAL_16B((unsigned short)curr_dtl_cnt);

#ifdef _ALF_DTL_GEN_TYPE_TABLE_  // that so said hybrid
        pcurr_dtl_entry[0].header1.num_type_entry = _DTL_VAL_16B((unsigned short)curr_type_cnt);
        // append the type list
        memcpy(pcurr_dtl_entry + curr_dtl_cnt + _ALF_AAL_DTL_HEADER_SIZE, 
            type_list, curr_type_cnt*sizeof(alf_aal_dtl_t));
#else
        pcurr_dtl_entry[0].header1.num_type_entry = 0;
#endif

        // padding the table to even size
#ifdef _ALF_DTL_GEN_TYPE_TABLE_  // that so said hybrid
        curr_dtl_cnt = (curr_dtl_cnt + _ALF_AAL_DTL_HEADER_SIZE + curr_type_cnt + 1)&0xfffffffe;
#else
        curr_dtl_cnt = (curr_dtl_cnt + _ALF_AAL_DTL_HEADER_SIZE + 1)&0xfffffffe;
#endif
        pcurr_dtl_entry[0].header1.total_size = _DTL_VAL_16B((unsigned short)curr_dtl_cnt);
        
        
        // update the table header and location pointer
        *p_loc += curr_dtl_cnt;
        pcurr_dtl_entry += curr_dtl_cnt;

        curr = last_entry+1;  // and go to next table in chain

    }// while

    // we are here finally

    // one more thing, we need to place the NIL at end of in and out table
    // the space has already been preallocated by the higher layer

    if (in_loc)  // we have ovl_io and/or in DTL, so a NIL is needed
      pdtl[in_loc ].header1.total_size = pdtl[in_loc ].header1.num_dtl_entry = 0;  // end of in table

    if (num_out) // we have out DTL, so a NIL is needed
      pdtl[out_loc].header1.total_size = pdtl[out_loc].header1.num_dtl_entry = 0;  // end of out table

    // done
    
    return;  // vola
}




