/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef __ALF_H_INC__
#define __ALF_H_INC__

/*
 ************************************************************
 * ALF Host API
 ************************************************************
 */

#include <alf_config.h>
#include <alf_def.h>
#include <alf_errno.h>

//********************************************************
// Platform Dependent Header Files 
//********************************************************

#ifdef _ALF_PLATFORM_CELL_
#include <arch/cell/alf_cell.h>
#elif _ALF_PLATFORM_HYBRID_
#include <arch/hybrid/alf_hybrid.h>
#else
#error "No ALF platform configured."
#endif

/*
 ************************************************************
 * Constants
 ************************************************************
 */

/* Environmental Information Query */
typedef enum _ALF_QUERY_SYS_INFO_T_ {
  ALF_QUERY_NUM_ACCEL = 100,    // number of accelerators in total
  ALF_QUERY_AVAIL_ACCEL = 101,  // number of free available accelerators
  ALF_QUERY_USED_ACCEL = 102,   // number of accelerators been used by the runtime
  ALF_QUERY_HOST_MEM_SIZE = 103,        // host memory size in 1KB (2^10)
  ALF_QUERY_HOST_MEM_SIZE_EXT = 104,    // host memory size in 4TB (2^42)
  ALF_QUERY_ACCEL_MEM_SIZE = 105,       // accelerator memory size in 1KB (2^10)
  ALF_QUERY_ACCEL_MEM_SIZE_EXT = 106,   // accelerator memory size in 4TB (2^42)
  ALF_QUERY_HOST_ADDR_ALIGN = 107,      // memory addr align on host, in exp of 2
  ALF_QUERY_ACCEL_ADDR_ALIGN = 108,     // memory addr align on accel, in exp of 2
  ALF_QUERY_DTL_ADDR_ALIGN = 109,       // DTL addr align, in exp of 2
  ALF_QUERY_HOST_ENDIANNESS = 110,      // 1: big,  0: little
  ALF_QUERY_ACCEL_ENDIANNESS = 111,     // 1: big,  0: little
} ALF_QUERY_SYS_INFO_T;

typedef enum _ALF_QUERY_ENDIANNESS_T_ {
  ALF_ENDIAN_ORDER_LITTLE = 0,
  ALF_ENDIAN_ORDER_BIG = 1,
} ALF_QUERY_ENDIANNESS_T;

/* Shutdown Policy */
typedef enum _ALF_EXIT_POLICY_T_ {
  ALF_EXIT_POLICY_FORCE = 0xA100,
  ALF_EXIT_POLICY_WAIT = 0xA101,
  ALF_EXIT_POLICY_TRY = 0xA102,
} ALF_EXIT_POLICY_T;

/* Task Info */
typedef enum _ALF_TASK_DESC_FIELD_T_ {
  ALF_TASK_DESC_TASK_TYPE,
  ALF_TASK_DESC_WB_PARM_CTX_BUF_SIZE,
  ALF_TASK_DESC_WB_IN_BUF_SIZE,
  ALF_TASK_DESC_WB_OUT_BUF_SIZE,
  ALF_TASK_DESC_WB_INOUT_BUF_SIZE,
  ALF_TASK_DESC_NUM_DTL_ENTRIES,
  ALF_TASK_DESC_TSK_CTX_SIZE,
  ALF_TASK_DESC_PARTITION_ON_ACCEL,
  ALF_TASK_DESC_ACCEL_IMAGE_REF_L,
  ALF_TASK_DESC_ACCEL_LIBRARY_REF_L,
  ALF_TASK_DESC_MAX_STACK_SIZE,
  ALF_TASK_DESC_ACCEL_KERNEL_REF_L,
  ALF_TASK_DESC_ACCEL_INPUT_DTL_REF_L,
  ALF_TASK_DESC_ACCEL_OUTPUT_DTL_REF_L,
  ALF_TASK_DESC_ACCEL_CTX_SETUP_REF_L,
  ALF_TASK_DESC_ACCEL_CTX_MERGE_REF_L,
  ALF_TASK_DESC_ACCEL_LTS_MAIN_REF_L,
  ALF_TASK_DESC_NUM_DTL,
} ALF_TASK_DESC_FIELD_T;

typedef enum _ALF_TASK_TYPE_T_ {
  ALF_TASK_TYPE_WORKBLOCK,            //work block task
  ALF_TASK_TYPE_LIGHTWEIGHT,          //lightweight task
} ALF_TASK_TYPE_T;

typedef enum _ALF_TASK_ATTR_TYPE_T_ {
  ALF_TASK_ATTR_SCHED_FIXED = 0x00000001,       // fixed processor map
  ALF_TASK_ATTR_WB_CYCLIC = 0x00000200, // cyclic work block map
} ALF_TASK_ATTR_TYPE_T;

typedef enum _ALF_TASK_EVENT_TYPE_T_ {
  ALF_TASK_EVENT_READY = 0x00010000,    // callback before the task will be loaded
  ALF_TASK_EVENT_FINISHED = 0x00020000, // callback before task finishes
  ALF_TASK_EVENT_FINALIZED = 0x00040000,        // task finialize
  ALF_TASK_EVENT_INSTANCE_START = 0x00080000,   // callback before a new accelerator thread is created
  ALF_TASK_EVENT_INSTANCE_END = 0x00100000,     // callback before a new accelerator thread is shutdown
  ALF_TASK_EVENT_DESTROY = 0x002000000, // task will be destroyed explicitly
} ALF_TASK_EVENT_TYPE_T;

/*
 ************************************************************
 * Data Structures
 ************************************************************
 */

typedef alf_data_uint32_t alf_handle_t;
typedef void *alf_task_desc_handle_t;
typedef alf_data_uint64_t alf_task_handle_t;
typedef void *alf_wb_handle_t;
typedef void *alf_wb_sync_handle_t;
typedef void *alf_dataset_handle_t;

/* the ALF runtime error handling function prototype */
typedef ALF_ERR_POLICY_T(*alf_error_handler_t) (void *p_context_data,
                                                ALF_ERR_TYPE_T error_type, int error_code, char *error_string);

#ifdef __cplusplus
extern "C" {
#endif                        /* __cplusplus */

/*
 ************************************************************
 * Framework
 ************************************************************
 */

  int alf_init(void *sys_config_info, alf_handle_t * alf_handle_ptr);
  int alf_init_shared(void *sys_config_info, alf_handle_t * alf_handle_ptr);

  int alf_query_system_info(alf_handle_t alf_handle, ALF_QUERY_SYS_INFO_T query_info, ALF_ACCEL_TYPE_T accel_type,
                            unsigned int *query_result);

  int alf_error_handler_register(alf_handle_t alf_handle, alf_error_handler_t error_handler_function, void *p_context);

  const char* alf_strerror(int error_code);
  
  int alf_num_instances_set(alf_handle_t alf_handle, unsigned int number_of_instances);
  
  int alf_num_instances_query(alf_handle_t alf_handle);

  int alf_exit(alf_handle_t alf_handle, ALF_EXIT_POLICY_T exit_policy, int timeout);

/*
 ************************************************************
 * Task Management
 ************************************************************
 */

  int alf_task_desc_create(alf_handle_t alf_handle, ALF_ACCEL_TYPE_T accel_type,
                           alf_task_desc_handle_t * task_desc_handle_ptr);

  int alf_task_desc_destroy(alf_task_desc_handle_t task_desc_handle);

  int alf_task_desc_set_int32(alf_task_desc_handle_t task_desc_handle, ALF_TASK_DESC_FIELD_T field, unsigned int value);

  int alf_task_desc_set_int64(alf_task_desc_handle_t task_desc_handle,
                              ALF_TASK_DESC_FIELD_T field, unsigned long long value);

  int alf_task_desc_ctx_entry_add(alf_task_desc_handle_t task_desc_handle,
                                  ALF_DATA_TYPE_T data_type, unsigned int size);

  int alf_task_create(alf_task_desc_handle_t task_desc_handle,
                      void *p_task_context_data,
                      unsigned int num_instances,
                      unsigned int tsk_attr, unsigned int wb_dist_size, alf_task_handle_t * task_handle_ptr);

  int alf_task_event_handler_register(alf_task_handle_t task_handle,
                                      int (*task_event_handler) (alf_task_handle_t task_handle,
                                                                 ALF_TASK_EVENT_TYPE_T event, void *p_data),
                                      void *p_data, unsigned int data_size, unsigned int event_mask);

  int alf_task_finalize(alf_task_handle_t task_handle);

  int alf_task_destroy(alf_task_handle_t task_handle);

  int alf_task_wait(alf_task_handle_t task_handle, int time_out);

  int alf_task_query(alf_task_handle_t task_handle, unsigned int *p_unfinished_wbs, unsigned int *p_total_wbs);

  int alf_task_depends_on(alf_task_handle_t task_handle_dependent, alf_task_handle_t task_handle_depending);

/*
 ************************************************************
 * Workblock Management
 ************************************************************
 */

  int alf_wb_create(alf_task_handle_t task_handle,
                    ALF_WORK_BLOCK_TYPE_T work_block_type, unsigned int repeat_count, alf_wb_handle_t * p_wb_handle);

  int alf_wb_enqueue(alf_wb_handle_t wb_handle);

  int alf_wb_parm_add(alf_wb_handle_t wb_handle,
                      void *pdata,
                      unsigned int size_of_data, ALF_DATA_TYPE_T data_type, unsigned int address_alignment);

  int alf_wb_dtl_begin(alf_wb_handle_t wb_handle, ALF_BUF_TYPE_T io_type, unsigned int offset_to_the_local_buffer);

  int alf_wb_dtl_entry_add(alf_wb_handle_t wb_handle,
                           void *p_address, unsigned int size_of_data, ALF_DATA_TYPE_T data_type);

  int alf_wb_dtl_end(alf_wb_handle_t wb_handle);

  int alf_wb_sync ( alf_task_handle_t task_handle_ptr, ALF_SYNC_TYPE_T sync_type, int (*sync_callback_func)( alf_wb_sync_handle_t sync_handle, void* p_context), void* p_context, unsigned int context_size, alf_wb_sync_handle_t  *p_sync_handle );

  int alf_wb_sync_wait (alf_wb_sync_handle_t sync_handle, int time_out);

/*
 ************************************************************
 * Dataset Management
 ************************************************************
 */

  int alf_dataset_create(alf_handle_t alf_handle, alf_dataset_handle_t * p_dataset_handle);

  int alf_dataset_buffer_add(alf_dataset_handle_t dataset, void *buffer, unsigned long long size,
                             ALF_DATASET_ACCESS_MODE_T access_mode);

  int alf_task_dataset_associate(alf_task_handle_t task, alf_dataset_handle_t dataset);

  int alf_dataset_destroy(alf_dataset_handle_t dataset);

#ifdef __cplusplus
}
#endif                        /* __cplusplus */
#endif                          /* __ALF_API_H_INC__ */
