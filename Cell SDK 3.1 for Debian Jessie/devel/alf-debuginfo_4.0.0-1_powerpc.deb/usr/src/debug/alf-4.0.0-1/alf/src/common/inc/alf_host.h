/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef __ALF_HOST_H_INC__
#define __ALF_HOST_H_INC__

/*
 ************************************************************
 * ALF Host Code Internal API
 ************************************************************
 */

#include <pthread.h>
#include <stdlib.h>

#include <alf.h>
#include "alf_pal.h"
#include "alf_arraylist.h"
#include "alf_wb_pool.h"
#include "alf_trace.h"
#include "alf_config.h"
#include "alf_debug.h"
/*
 ************************************************************
 * Adjustable Constants
 ************************************************************
 */

/* Size of the alf handle buffer. It specified the number of alf instances can be created 
 * simultaneously. if only one single instance is expected, set to 1 */
#define ALF_API_ALF_HANDLE_HASH_BUCKET_SIZE  (1024)

/* Size of the task info handle hash buffer, must be 2^n */
#define ALF_API_TASK_INFO_HASH_BUFFER_SIZE  (256)

/* Size of the task handle hash buffer, must be 2^n */
#define ALF_API_TASK_HANDLE_HASH_BUCKET_SIZE  (1024 * 1024)

#define ALF_API_DESTROYED_TASK_HASH_BUCKET_SIZE (1024)

#define ALF_GC_THRESHOLD 1024

#define _ALF_API_HANDLE_NUM (8)
#define _ALF_API_ERR_NUM (128)
#define _ALF_API_TASK_INFO_NUM (128)
#define _ALF_API_TASK_QUEUE_LEN (1024)
#define _ALF_API_TASK_DEP_NUM (8)
#define _ALF_API_TASK_CTX_DESC_NUM (128)
#define _ALF_API_TASK_SYNC_QUEUE_LEN (128)
#define _ALF_API_ACCEL_WB_QUEUE_LEN (1024)
#define _ALF_API_ACCEL_DEFAULT_STACK_SIZE (1024)
#define _ALF_API_ACCEL_DEFAULT_ALIGN (7)
#define _ALF_API_WB_DTL_NUM (128)
#define _ALF_API_WB_PARM_MAX_ALIGN (16)
#define _ALF_API_DATASET_LIST_LEN (16)
#define _ALF_API_DTLIST_NUM (16)
#ifdef _ALF_PLATFORM_HYBRID_
#define _ALF_SCHED_ACCEL_WB_QUEUE_DEPTH (16)
#else
#define _ALF_SCHED_ACCEL_WB_QUEUE_DEPTH (4)
#endif



/*
 ************************************************************
 * Constants
 ************************************************************
 */

typedef enum _ALF_API_TASK_STATE_TYPE_T_ {
  ALF_API_TASK_STATUS_INIT = 0x00000001,
  ALF_API_TASK_STATUS_PENDING = 0x00000002,
  ALF_API_TASK_STATUS_READY = 0x00000003,
  ALF_API_TASK_STATUS_EXEC = 0x00000004,
  ALF_API_TASK_STATUS_FINISH = 0x00000005,
  ALF_API_TASK_STATUS_DESTROY = 0x00000006,
  ALF_API_TASK_STATUS_DESTROYED = 0x00000007,
} ALF_API_TASK_STATE_TYPE_T;


typedef enum _ALF_API_TASK_QUERY_STATE_TYPE_T_ {
  ALF_API_TASK_QUERY_STATUS_FINISHED = 0x0,
  ALF_API_TASK_QUERY_STATUS_RUNNING = 0x00000001,
  ALF_API_TASK_QUERY_STATUS_PENDING = 0x00000002,
} ALF_API_TASK_QUERY_STATE_TYPE_T;


typedef enum _ALF_API_STATE_TYPE_T_ {
  ALF_API_STATUS_RUNNING = 0x00000001,
  ALF_API_STATUS_EXITING = 0x00000002,
  ALF_API_STATUS_EXITED = 0x00000003,
} ALF_API_STATE_TYPE_T;

typedef enum _ALF_API_HANDLE_TYPE_T_ {
  ALF_API_HANDLE_ISOLATED = 0x00000001,
  ALF_API_HANDLE_SHARED =  0x00000002,
} ALF_API_HANDLE_TYPE_T;

typedef enum _ALF_API_THREAD_STATUS_T_
{
  ALF_API_THREAD_STATUS_INIT     = 0x00000001,   /* thread not created */ 
  ALF_API_THREAD_STATUS_RUNNING  = 0x00000002,   /* thread is running task */
  ALF_API_THREAD_STATUS_STANDBY  = 0x00000003,  /* thread can be reused */
} ALF_API_THREAD_STATUS_T;

typedef enum _ALF_WB_TYPE_T_
{
    _ALF_WB_NORMAL = 0,   /*normal work block*/
    _ALF_WB_SYNC = 1,   /*sync work block*/
} ALF_WB_TYPE_T;

typedef enum _ALF_API_WB_STATUS_TYPE_T_ {
  _ALF_API_WB_STATUS_INIT = 0x0,
  _ALF_API_WB_STATUS_ENQ = 0x00000001,
  _ALF_API_WB_STATUS_FIN = 0x00000002,
} _ALF_API_WB_STATUS_TYPE_T;

/* status for sync point
 * */
typedef enum _ALF_API_SYNC_STATUS_TYPE_T_ {
  _ALF_SYNC_UNFINISHED   =    0x0,
  _ALF_SYNC_FINISHED     =    0x1,
} _ALF_API_WB_SYNC_TYPE_T;

typedef enum _ALF_API_WB_BARRIER_STATUS_TYPE_T_ {
  _ALF_BARRIER_CLEAR          =    0x0,
  _ALF_BARRIER_UNRESOLVED     =    0x1,
  _ALF_BARRIER_RESOLVED       =    0x2,
} _ALF_API_WB_BARRIER_TYPE_T;

typedef enum _ALF_API_DATASET_STATE_TYPE_T_ {
  ALF_API_DATASET_STATUS_OPEN = 0x00000001,
  ALF_API_DATASET_STATUS_CLOSED = 0x00000002,
  ALF_API_DATASET_STATUS_ERROR = 0x00000003,
} ALF_API_DATASET_STATE_TYPE_T;

/*
 ************************************************************
 * Data Stuctures
 ************************************************************
 */

/* thread image */
typedef struct _alf_thread_image_t_
{
  char lib_name[ALF_STRING_TOKEN_MAX+1];
  char image_name[ALF_STRING_TOKEN_MAX+1];
} alf_thread_image_t;

/* cached threads of same image */
typedef struct _alf_thread_cache_image_t_
{
  alf_thread_image_t image;
  unsigned int num_threads;
} alf_thread_cache_image_t;


/* thread cache */
typedef struct _alf_thread_cache_
{
  alf_thread_cache_image_t* thread_images;
  int num_images;
#ifdef _ALF_64B_
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
} alf_thread_cache;
/* the thread pool instance */
typedef struct _alf_thread_pool_elem
{
  // TODO: more smart ways to check image changes
  alf_thread_image_t image;
  alf_pal_thread_handle task_thread;		// PAL thread handle
  TRACE_INTERVAL_TOKEN_ARGUMENT(thread_run_token);
  ALF_API_THREAD_STATUS_T status;  			// status of the thread

#ifdef _ALF_64B_
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
} alf_thread_pool_elem_t;


/* the thread pool */
typedef struct _alf_thread_pool
{
  alf_thread_pool_elem_t* elems;	//  threads
  unsigned int num_threads;      	// number of threads in pool
  unsigned int used_threads;			// count of threads in use
} alf_thread_pool;

typedef struct _alf_api_dtlist_pool_t_ {
  void **used_dtlists;
  void **free_dtlists;
  int free_head;
  int free_tail;
  int entry_size;
  int capacity;  
  pthread_mutex_t lock;
} alf_api_dtl_pool_t;

/* alf instance data structure */
typedef struct _alf_instance_t_ {
  pthread_mutex_t lock;         // instance lock
  pthread_mutex_t thread_lock;  //threadpool lock
  pthread_cond_t task_cond;     //wakeup scheduler
  pthread_cond_t cond;          //wakeup user wait
  volatile ALF_API_STATE_TYPE_T state;  //alf runtime state
  unsigned int max_thread_num;   //maximum of threads number supported
  unsigned int accel_num;       // number of accelerators reserved currently
  unsigned int gc_flag;         // indicate gc to run

  /* task processing list */
  alf_arraylist_t *init_task_list;
  alf_arraylist_t *ready_task_list;
  alf_arraylist_t *exec_task_list;
  alf_arraylist_t *destroy_task_list;
  alf_arraylist_t *ref_task_list;
  alf_arraylist_t *err_msg_list;


  // error handling
  pthread_mutex_t err_lock;
  pthread_t err_thread;
#ifdef _ALF_32B_
  char _pad_2_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
  volatile unsigned long long err_num;
  volatile unsigned long long err_finished;

  // scheduler thread
  pthread_t scheduler;
  unsigned int scheduler_active; //set to 1 when the scheduler thread is running, 0 otherwise
  char _pad_3_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility

#ifdef _ALF_STP_ENABLE_HOST
  int exit_time, sel_time, sched_time, run_time, rel_time, lock_time, idle_time;
  char _pad_4_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif

  // signaled when the scheduler loop has work or when exiting

  alf_pal_handle platform_handle;
  alf_arraylist_t *alf_handle_list; //alf handle list
  alf_thread_pool threadpool;       // thread pool 
  alf_thread_cache thread_cache;    // thread cache

} alf_instance_t;


/* alf_handle_t internal data structure  */
typedef struct _alf_api_t_ {
  ALF_API_HANDLE_TYPE_T type;  // alf handle type
  volatile ALF_API_STATE_TYPE_T state;  //alf runtime state
  
  pthread_mutex_t lock;         // exclusive lock
  pthread_cond_t cond;

  // error handler
  alf_error_handler_t err_handler;
  void *err_handler_data_ptr;
  
  alf_instance_t * instance; //pointer to alf instance
  alf_pal_config_handle config_handle;

  ALF_EXIT_POLICY_T exit_policy;
  unsigned int task_unfinished; //number of unfinished task when exit

  alf_arraylist_t *task_info_list;
  alf_arraylist_t *datasets;    // list of data sets

  //store all sync wb
  alf_arraylist_t *sync_wbq;
  //wb dtl pool
  alf_api_dtl_pool_t *dtl_pool;
  
  alf_arraylist_t *task_list;  //all task belong to this alf handle
  struct _alf_api_t_ *next_ptr;    /* hook to next in the hash bucket */
  
  alf_handle_t self;       // self pointer
  unsigned int task_handle_counter;  //
  unsigned int task_handle_num;   // remaining task handle
  char _pad_[4];

  struct _alf_api_task_bucket_t_* task_handle_bucket; // address of associated task handle bucket
  struct _alf_api_destroyed_task_bucket_t_ *destroyed_task_bucket; // address of associated destroyed task handle bucket

} alf_api_t;

typedef struct _alf_err_msg {
  alf_api_t *alf_handle;
  int error_type;
  ALF_ERR_TYPE_T error_code;
  char *error_string;
  ALF_ERR_POLICY_T ret;
#ifdef _ALF_64B_
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
} alf_err_msg;

/* the alf data set */
typedef struct _alf_api_dataset_t_ {
  pthread_mutex_t lock;

  alf_api_t *api_handle;        // backward ptr to api runtime object owning this data set
  alf_arraylist_t *buffers;     // list of data set buffers in this data set
  alf_pal_dataset_handle pal_dataset;   // PAL data set
#ifdef _ALF_32B_
  char _pad_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
  ALF_API_DATASET_STATE_TYPE_T state;   // state of this data set
  unsigned int task_count;
} alf_api_dataset_t;

/* the alf data set buffer */
typedef struct _alf_api_dataset_buffer_t_ {
  alf_data_addr64_t addr;       // data buffer address
  unsigned long long size;      // data size
  ALF_DATASET_ACCESS_MODE_T access_mode;        // data access mode
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
} alf_api_dataset_buffer_t;

/* alf_task_info_handle_t internal data structure */

typedef struct _alf_api_task_info_t_ {
  alf_pal_task_info_t pal;      /* this must be the first field */
  pthread_mutex_t lock;

  alf_api_t *alf_handle;
  struct _alf_api_task_info_t_ *next_ptr;

  /* host data structure */
  alf_task_handle_t self;       // self pointer

  /* hook to next in the hash bucket */
  unsigned int accel_mem_size;
  unsigned int accel_align;
  unsigned int max_context_desc_num;
  unsigned int ctx_entry_size;
} alf_api_task_info_t;

/* sync wb */
typedef struct _alf_wb_sync
{
  volatile int state;
  ALF_SYNC_TYPE_T type;
  int (*callback_func)(alf_wb_sync_handle_t sync_handle, void* p_context);
  void *p_context;
  unsigned int context_size;
#ifdef _ALF_64B_
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
  pthread_mutex_t _cond_lock;
#ifdef _ALF_32B_
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
  pthread_cond_t _cond;
} alf_wb_sync_t;

/* thread of a task */
typedef struct _alf_task_thread
{
  alf_pal_thread_handle thread;  // PAL thread
  int		accel_id;
  unsigned int finished_wbs;
  unsigned int barrier_status;
#ifdef _ALF_STP_ENABLE_HOST
  int start_time;
#else
  #ifdef _ALF_64B_
    char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
  #endif
#endif
} alf_task_thread_t;


typedef struct _alf_task_event_handler
{
  int (*callback_func)(alf_task_handle_t task_handle, ALF_TASK_EVENT_TYPE_T event,
                            void* p_data);
  void *p_data;
  unsigned int data_size;
  unsigned int event_mask;
} alf_task_event_handler_t;

/* alf_task_handle_t internal data structure */
typedef struct _alf_api_task_t_ {
  /* host data structure */
  alf_task_handle_t self;       // self pointer
  alf_task_event_handler_t event_handler;

  alf_api_t *alf_handle;		// refer to alf handle
  struct _alf_api_task_t_ *next_ptr;    /* hook to next in the hash bucket */
  
  // synchronization flags
  pthread_mutex_t lock;         // exclusive lock
  pthread_cond_t cond;
  pthread_mutex_t gc_lock;

  /* basic task enviromental information */

  /* all other static task information follow here */
  unsigned int attr;
  unsigned int wb_dist_size;
  unsigned int num_accel_req;   // required number of accelerators
  unsigned int ref_num;        // number of reference in API

#ifdef _ALF_32B_
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
  alf_api_task_info_t* task_info;        /* a copied task info that is referenced by this task only */

  /* task status info */
  ALF_API_TASK_STATE_TYPE_T state;     // working state in scheduler
  unsigned int finalized_flag;
  
  alf_task_thread_t *p_task_threads;        /* the task thread container */
  void *p_thread_context;
  unsigned int max_desc_num;
  unsigned int num_accels;      /* actually utilized number of accelerators */

  alf_arraylist_nl_t **accel_wbq;
  alf_arraylist_nl_t *task_wbq;
  alf_arraylist_t **accel_fin_wbq;
  void *p_context;   // context buffer as supplied

  /* record dependency */
  unsigned int dist_num;
  int cur_accel;

  volatile int num_wb_pending;
  volatile int num_wb;

  unsigned int sync_num;
  unsigned int parent_count;
  
  alf_arraylist_t* child_tasks;
  alf_wb_pool* wb_pool;

  alf_wb_sync_t *sync_wb;
  /* Fixme:  any other TBDs */
  alf_api_dataset_t *dataset;   // associated data set
  
#ifdef _ALF_PLATFORM_HYBRID_  
  unsigned int dataset_dec;     // flag to decrease dataset->task_count
  char _pad_2_[4];  
#endif

#ifdef _ALF_STP_ENABLE_HOST
  int dis_time, feed_time, gar_time, wait_time, mer_time, query_time;
  //char _pad_5_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif

  TRACE_INTERVAL_TOKEN_ARGUMENT(task_before_exec_token);
  TRACE_INTERVAL_TOKEN_ARGUMENT(task_in_exec_token);

} alf_api_task_t;


/* alf_wb_handle_t internal data structure */

typedef struct _alf_api_wb_t_ {

  //alf_api_task_t *task;         // associated task handle
  alf_task_handle_t task;
 
  ALF_WB_TYPE_T type; 
  _ALF_API_WB_STATUS_TYPE_T status;

  //used by alf_api_dtl_begin/alf_api_dtl_entry_add
  alf_pal_dtlist_t *dtl;   // PAL DTL
  alf_pal_dtlist_t *cur_dtl; //curent DTL header 
  
  unsigned int dtl_ele_num; //including both header and entry
  unsigned int dtl_entry_num;

  //for error checking
  unsigned int cur_dtl_size;
  unsigned int cur_dtl_offset;
  ALF_BUF_TYPE_T cur_dtl_buffer_type; 

#ifdef _ALF_32B_
  char pad[ALF_PAL_WB_HOST_PRIV_DATA_SIZE-44];
#else
  char pad[ALF_PAL_WB_HOST_PRIV_DATA_SIZE-52];
#endif
  alf_pal_wb_t pal;             /* this must be the first field */
} alf_api_wb_t;

/* the alf handle hash table */
typedef struct _alf_api_task_info_bucket_t_ {
  pthread_mutex_t lock;         // exclusive lock
  unsigned int count;           // current bucket depth
#ifdef _ALF_64B_
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
  alf_api_task_info_t *top_ptr; // the first one in bucket
} alf_api_task_info_bucket_t;


/* the alf handle hash table */
typedef struct _alf_api_task_bucket_t_ {
  pthread_mutex_t lock;         // exclusive lock
  unsigned int init_flag;           // initialized or not
#ifdef _ALF_64B_
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
  alf_api_task_t *top_ptr;      // the first one in bucket
} alf_api_task_bucket_t;

typedef struct _alf_api_handle_bucket_t_ {
  pthread_mutex_t lock;    // lock
  unsigned int init_flag;    // initialized or not?
#ifdef _ALF_64B_
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
  alf_api_t *top_ptr;       // first one in the bucket
}alf_api_handle_bucket_t;

#ifdef __cplusplus
extern "C" {
#endif                          /* __cplusplus */

/*
 ************************************************************
 * APIs
 ************************************************************
 */

/* handle operations */
#define ALF_API_GET_ALF_HANDLE(handle) ((alf_data_uint32_t)((handle)>>32))

#define ALF_API_GET_HANDLE_HASH(handle) ((alf_data_uint32_t)(handle))

#define ALF_API_TASK_MAKE_HANDLE(alf_handle, handle) ( ((alf_data_uint64_t)(alf_handle)<<32) \
                                                     |(alf_data_uint64_t)(handle))

  /* hash table */
#define ALF_API_TASK_INFO_HASH_INDEX(handle)     ((handle&(ALF_API_TASK_INFO_HASH_BUFFER_SIZE-1))

#define ALF_API_ALF_HANDLE_HASH_INDEX(handle) ((handle)&(ALF_API_ALF_HANDLE_HASH_BUCKET_SIZE-1))
#define ALF_API_TASK_HANDLE_HASH_INDEX(handle)     ((handle)&(ALF_API_TASK_HANDLE_HASH_BUCKET_SIZE-1))
#define ALF_API_DESTROYED_TASK_HASH_INDEX(handle) ((handle) & (ALF_API_DESTROYED_TASK_HASH_BUCKET_SIZE -1))

#define ALF_GC_ALF_HANDLE_SIG(alf_handle) {        \
  pthread_mutex_lock(&alf_handle->lock);           \
  alf_handle->task_handle_num --;                  \
  if (alf_handle->task_handle_num == 0)            \
    pthread_cond_signal(&alf_handle->cond);        \
  pthread_mutex_unlock(&alf_handle->lock);         \
}

#define ALF_HANDLE_MAX_COUNT (g_alf_handle_counter - 1)

#define CHECK_ALF_HANDLE(handle) {                   \
  pthread_mutex_lock(&g_alf_handle_bucket_lock);     \
  if ( handle > ALF_HANDLE_MAX_COUNT) {              \
    pthread_mutex_unlock(&g_alf_handle_bucket_lock); \
    return NULL;                                     \
  }                                                  \
  pthread_mutex_unlock(&g_alf_handle_bucket_lock);   \
}

#define CHECK_TASK_HANDLE(alf_handle, task_handle_key) {          \
  pthread_mutex_lock(&alf_handle->lock);                          \
  if ((unsigned int)task_handle_key >                             \
     (alf_handle->task_handle_counter - 1)) {                     \
    pthread_mutex_unlock(&alf_handle->lock);                      \
    return -ALF_ERR_RANGE;                                        \
  }                                                               \
  pthread_mutex_unlock(&alf_handle->lock);                        \
}

/* Hash operation for ALF handle */
int ALF_API_ALF_HANDLE_HASH_INSERT(alf_api_t* alf_handle, alf_handle_t* alf_handle_key);
alf_api_t* ALF_API_ALF_HANDLE_HASH_ACQUIRE(alf_handle_t alf_handle_key);
void ALF_API_ALF_HANLDE_HASH_REMOVE(alf_handle_t alf_handle_key);

/* Hash operation for task handle */
int ALF_API_TASK_HASH_CREATE(alf_api_t *alf_handle);
int ALF_API_TASK_HASH_INSERT(alf_api_t* alf_handle, alf_api_task_t* ask_handle, alf_task_handle_t* task_handle_key);
int ALF_API_TASK_HASH_ACQUIRE(alf_task_handle_t task_handle_key, alf_api_task_t **task_handle);
void ALF_API_TASK_HASH_RESTORE(alf_api_task_t* task_handle);
int ALF_API_TASK_HASH_REMOVE(alf_api_t* alf_handle, alf_task_handle_t task_handle_key);
void ALF_API_TASK_HASH_DESTROY(alf_api_t* alf_handle);

/* host internal api with prefix alf_api_ */
  void *alf_api_scheduler(void *alf_ptr);
  int alf_api_task_wb_enqueue(alf_api_task_t * task_handle, alf_api_wb_t * wb_handle);
  int alf_api_task_sync_wb_enqueue(alf_api_task_t * task_handle, alf_api_wb_t * wb_handle);
  int alf_api_instance_init(alf_instance_t *alf_instance, void* sys_config_info);
  void alf_api_instance_destroy(alf_instance_t *alf_instance);
  int alf_api_handle_init(alf_api_t *alf_handle, void* config, alf_instance_t *alf_instance);
  void alf_api_handle_destroy(alf_api_t * alf_handle);
  int alf_api_task_offspring_destroy(alf_api_task_t *task_handle, alf_arraylist_t* tasks);
  int alf_api_task_info_copy(alf_api_task_t* task_handle, alf_api_task_info_t* task_info, 
                       void *p_task_context_data);
  int alf_api_task_wbq_create (alf_api_task_t * task_handle);
  int alf_api_task_cancel(alf_api_t* alf_handle);

/* error handler internal api with prefix alf_err_ */
  ALF_ERR_POLICY_T  alf_err_default_error_handler(void *p_context_data  DECLARE_UNUSED, ALF_ERR_TYPE_T error_type, int error_code, char *error_string);
  ALF_ERR_POLICY_T  alf_err_pal_error_handler(void *p_context_data, void *task_handle, ALF_ERR_TYPE_T error_type, int error_code, char *error_string);
  ALF_ERR_POLICY_T alf_err_call_error_handler(alf_api_t* alf_instance, ALF_ERR_TYPE_T error_type, int error_code, char *err_msg);
  ALF_ERR_POLICY_T alf_err_error_processing(alf_api_t* alf_instance, ALF_ERR_TYPE_T error_type, int error_code, char *err_msg);

/* host and scheduler shared internal api with prefix alf_int_ */
  void alf_int_task_info_destroy(alf_api_task_info_t * task_info);
  void alf_int_task_res_destroy(alf_api_task_t * task_handle, int force);
  void alf_int_wb_handle_destroy(alf_api_wb_t * wb, alf_api_task_t* task);
  int alf_int_task_call_event_handler(alf_api_task_t* task_handle, ALF_TASK_EVENT_TYPE_T event);

/* scheduler internal api with prefix alf_sched_ */
  void alf_sched_task_wb_count_dec(alf_api_task_t * task_handle);
  int alf_sched_task_wb_dispatch(alf_api_task_t * task_handle);
  void alf_sched_task_wb_try_free(alf_api_task_t * task_handle);
  void alf_sched_task_wb_free(alf_api_task_t * task_handle);
  int alf_sched_task_wbq_create (alf_api_task_t * task_handle);
  int alf_sched_task_release (alf_instance_t* alf_handle);
  void alf_sched_task_select(alf_instance_t * alf_handle);
  void alf_sched_task_schedule(alf_instance_t* alf_handle);
  void alf_sched_task_run(alf_instance_t* alf_instance);
  void alf_sched_task_context_merge(alf_api_task_t *task_handle, unsigned int depth);
  void alf_sched_task_child_notify(alf_api_task_t* task_handle);
  void alf_sched_task_destroy(alf_instance_t *alf_instance, alf_api_task_t* task_handle);
  int alf_sched_task_threads_wait(alf_api_task_t *task_handle);
  int alf_sched_task_stop(alf_instance_t * alf_instance, alf_api_task_t * task_handle);


/* thread manager internal api with prefix alf_thread_mgr_ */
int alf_thread_mgr_setup(alf_instance_t* alf_instance, unsigned int num_of_accels);
int alf_thread_mgr_num_set(alf_instance_t* alf_instance, unsigned int num_of_accels);
unsigned int alf_thread_mgr_num_get(alf_instance_t* alf_instance);
int alf_thread_mgr_start_thread(alf_instance_t* alf_instance, alf_api_task_t* task_handle);
int alf_thread_mgr_return_thread(alf_instance_t* alf_instance ,alf_api_task_t* task_handle);
int alf_thread_mgr_query(alf_instance_t* alf_instance);
int alf_thread_mgr_cleanup(alf_instance_t* alf_instance);

/* thread cache api */
void alf_thread_mgr_cache_write(alf_instance_t* alf_instance, alf_api_task_t* task_handle);
void alf_thread_mgr_cache_flush(alf_instance_t* alf_instance, alf_thread_image_t* task_image);
int alf_thread_mgr_cache_hit(alf_instance_t* alf_instance, alf_api_task_t* task_handle);
void alf_api_task_dump(char *prefix, alf_api_task_t * wb);
void alf_api_wb_dump(char *prefix, alf_api_wb_t * wb);
void alf_api_dataset_dump(char *prefix, alf_api_dataset_t * dataset);

  int alf_api_dataset_check(alf_api_dataset_t * dataset, alf_data_addr64_t addr, unsigned long long size,
                            ALF_DATASET_ACCESS_MODE_T access_mode);
  int alf_api_dataset_put(alf_api_dataset_t * dataset);
  int alf_api_dataset_get(alf_api_dataset_t * dataset);
  int alf_api_dataset_close(alf_api_dataset_t * dataset);

  int alf_api_dtl_begin(alf_api_wb_t *wb,ALF_BUF_TYPE_T buffer_type, alf_data_uint64_t local_offset);
  int alf_api_dtl_entry_add(alf_api_wb_t *wb,unsigned int size,alf_data_addr64_t address, ALF_DATA_TYPE_T data_type);
  void alf_api_dtl_end(alf_api_wb_t *wb);

  void *alf_api_dtl_pool_create(unsigned int dtlist_size);
  void alf_api_dtl_pool_destroy(alf_api_dtl_pool_t *pool);
  void *alf_api_dtl_alloc(alf_api_dtl_pool_t *pool);
  void alf_api_dtl_free(alf_api_dtl_pool_t *pool,void *dtlist); 
/*
 ************************************************************
 * Globals
 ************************************************************
 */


#ifdef __cplusplus
}
#endif                          /* __cplusplus */
#endif                          /* __ALF_HOST_H_INC__ */
