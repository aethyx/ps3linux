/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "alf_linkedlist.h"

/**
 * Linkedlist create routine.
 *
 * This function creates an linkedlist.
 *
 * Parameters:
 * None.
 * 
 * Return Values:
 * The address of the resulting linkedlist is returned.
 */

alf_linkedlist_t *alf_linkedlist_create()
{

  /* Allocate and set the linkedlist object pointer */
  alf_linkedlist_t *ll = (alf_linkedlist_t *) calloc(1, sizeof(alf_linkedlist_t));

  /* Check if the linkedlist object allocation suceeded */
  if (ll == NULL) {

    /* If not, return an error */
    return NULL;
  }

  /* Initialize the linkedlist object */
  ll->first = NULL;
  ll->last = NULL;
  ll->count = 0;
  pthread_mutex_init(&ll->lock, NULL);

  /* Return success */
  return ll;
}

/**
 * Linkedlist enqueue on the end routine.
 *
 * This function adds a data element into the end of the linkedlist, and returns
 * the data element after insertion.
 *
 * Parameters:
 * ll[IN]: Pointer to a linkedlist.
 * d[IN]: Pointer to data element which needed to be enqueued.
 *
 * Return Values:
 * Pointer to data element which needed to be enqueued. NULL is returned if any errors are encountered
 *
 */

void *alf_linkedlist_enqueue(alf_linkedlist_t * ll, void *data)
{
  alf_linkedlist_element_t *e;

  if (ll == NULL) {
    return NULL;
  }
  if (data == NULL) {
    return NULL;
  }

  /* Lock the linkedlist object */
  pthread_mutex_lock(&ll->lock);

  /* Allocate a linkedlist element object */
  e = (alf_linkedlist_element_t *) calloc(1, sizeof(alf_linkedlist_element_t *));

  /* Check if this is the first element to be added to the linkedlist */
  if ((ll->last == NULL) && (ll->first == NULL)) {

    /* This is the first block */
    e->next = NULL;
    e->prev = NULL;
    e->data = data;
    ll->first = e;
    ll->last = e;

  } else {

    /* There's something else in the list */
    ll->last->next = e;
    e->next = NULL;
    e->prev = ll->last;
    e->data = data;
    ll->last = e;

  }

  ll->count++;

  /* Unlock the linkedlist object */
  pthread_mutex_unlock(&ll->lock);

  return data;
}

/**
 * Linkedlist dequeue from the front routine.
 *
 * This function remove the first data element from linkedlist, and return it.
 *
 * Parameter:
 * ll[IN]: Pointer to the linkedlist.
 *
 * Return Values:
 * Effective address of the first data element. NULL is returned if the is empty.
 *
 */

void *alf_linkedlist_dequeue(alf_linkedlist_t * ll)
{
  alf_linkedlist_element_t *e = NULL;
  void *data = NULL;

  if (ll == NULL || (ll->first == NULL && ll->last == NULL)) {
    return NULL;
  }

  /* Lock the linkedlist object */
  pthread_mutex_lock(&ll->lock);

  /* Unlink first list element from list */
  e = alf_linkedlist_unlink(ll, ll->first);
  data = e->data;
  free(e);

  /* Unlock the linkedlist object */
  pthread_mutex_unlock(&ll->lock);

  return data;
}

/**
 * Linkedlist dequeue from the end routine.
 *
 * This function remove the last data element from linkedlist, and return it.
 *
 * Parameter:
 * ll[IN]: Pointer to the linkedlist.
 *
 * Return Values:
 * Effective address of the last data element. NULL is returned if the linkedlist is empty.
 *
 */

void *alf_linkedlist_dequeue_from_end(alf_linkedlist_t * ll)
{
  alf_linkedlist_element_t *e = NULL;
  void *data = NULL;

  if (ll == NULL || (ll->first == NULL && ll->last == NULL)) {
    return NULL;
  }

  /* Lock the linkedlist object */
  pthread_mutex_lock(&ll->lock);

  /* Unlink last list element from list */
  e = alf_linkedlist_unlink(ll, ll->last);
  data = e->data;
  free(e);

  /* Unlock the linkedlist object */
  pthread_mutex_unlock(&ll->lock);

  return data;
}

/**
 * Linkedlist remove data element routine.
 * 
 * This function removes a data element from the linkedlist, and returns it.
 * 
 * Parameter:
 * ll[IN]: Pointer to the arraylist
 * data: Pointer to the data element to be removed
 * 
 * Return Values:
 * Effective address of the data element that was removed. NULL is returned if the data element is not found in the arraylist.
 * 
 */

void *alf_linkedlist_remove(alf_linkedlist_t * ll, void *data)
{
  alf_linkedlist_element_t *e = NULL;

  if (ll == NULL || (ll->first == NULL && ll->last == NULL)) {
    return NULL;
  }

  if (data == NULL) {
    return NULL;
  }

  /* Lock the linkedlist object */
  pthread_mutex_lock(&ll->lock);

  e = ll->first;
  while (e != NULL) {

    if (e->data == data) {

      /* Unlink matching list element from list */
      e = alf_linkedlist_unlink(ll, e);
      data = e->data;
      free(e);

      break;
    }

    e = e->next;
  }

  /* Unlock the linkedlist object */
  pthread_mutex_unlock(&ll->lock);

  return data;
}

/** 
 * Linkedlist get data element routine
 *
 * This function gets the data element from the linkedlist at a specific index and returns it.
 *
 * Parameters:
 * ll[IN]: Pointer of the linkedlist.
 * index[IN]: Index for the expected data element from 0 to capacity-1.
 *
 * Return Value:
 * Effective for the expected data element. NULL is returned if any errors are encountered.
 */

void *alf_linkedlist_get_element(alf_linkedlist_t * ll, unsigned int index)
{
  unsigned int i;
  alf_linkedlist_element_t *e = NULL;

  if (ll == NULL) {
    return NULL;
  }

  if (index >= ll->count) {
    return NULL;
  }

  /* Lock the linkedlist object */
  pthread_mutex_lock(&ll->lock);

  e = ll->first;
  for (i = 0; i < index; i++) {
    e = e->next;
  }

  /* Unlock the linkedlist object */
  pthread_mutex_unlock(&ll->lock);

  return e->data;
}

/**
 * Linkedlist get length routine
 *
 * This function return the length of the linkedlist, that is, the current number of elements in the linkedlist.
 *
 * Parameters:
 * ll[IN]: Pointer to the linkedlist.
 *
 * Return Values:
 * Length of the linkedlist.
 */

unsigned int alf_linkedlist_get_length(alf_linkedlist_t * ll)
{
  return ll->count;
}

/**
 * Linkedlist query if empty routine.
 *
 * This function checks whether the linkedlist is empty.
 *
 * Parameters:
 * ll[IN]: Pointer to the arraylist.
 *
 * Return Values:
 * ==1 Linkedlist is empty. 
 * ==0 Linkedlist is not empty.
 */

int alf_linkedlist_is_empty(alf_linkedlist_t * ll)
{
  /* If the linkedlist count is zero, then the linkedlist is empty */
  return (ll->count == 0) ? 1 : 0;
}

/**
 * Linkedlist query if full routine.
 *
 * This function checks whether the linkedlist is full.
 *
 * Parameters:
 *   ll[IN]: Pointer to the linkedlist.
 *
 * Return Values:
 * ==1 Linkedlist is full. 
 * ==0 Linkedlist is not full.
 */

int alf_linkedlist_is_full(alf_linkedlist_t * ll __attribute__ ((unused)))
{
  /* Always return not full, that is, a linkedlist can never be full */
  return 0;
}

/**
 * Linkedlist contains data element routine.
 * 
 * This function queries if an data element is contained in the linkedlist.
 * 
 * Parameter:
 * ll[IN]: Pointer to the linkedlist
 * data[IN]: Pointer to the data element to be queried
 * 
 * Return Values:
 * ==1 Linkedlist contains the data element 
 * ==0 Linkedlist does not contains the data element 
 */

int alf_linkedlist_contains(alf_linkedlist_t * ll, void *data)
{
  alf_linkedlist_element_t *e = NULL;

  if (ll == NULL || (ll->first == NULL && ll->last == NULL)) {
    return 0;
  }

  if (data == NULL) {
    return 0;
  }

  /* Lock the linkedlist object */
  pthread_mutex_lock(&ll->lock);

  e = ll->first;
  while (e != NULL) {

    if (e->data == data) {

      /* Unlock the linkedlist object */
      pthread_mutex_unlock(&ll->lock);

      return 1;
    }

    e = e->next;
  }

  /* Unlock the linkedlist object */
  pthread_mutex_unlock(&ll->lock);

  return 0;
}

/**
 * Linkedlist print routine.
 *
 * This function prints the internal contents of the linkedlist.
 *
 * Parameters:
 *   ll[IN]: Pointer to the linkedlist.
 *
 * Return Values:
 * None.
 */

void alf_linkedlist_print(alf_linkedlist_t * ll)
{
  alf_linkedlist_element_t *e = NULL;
  unsigned int i;

  printf("In alf_linkedlist_print: ll=%p\n", ll);
  if (ll != NULL) {

    /* Lock the arraylist object */
    pthread_mutex_lock(&ll->lock);

    printf("In alf_linkedlist_print: ll->first=%p\n", ll->first);
    printf("In alf_linkedlist_print: ll->last=%p\n", ll->last);
    printf("In alf_linkedlist_print: ll->count=%d\n", ll->count);
    i = 0;
    e = ll->first;
    while (e != NULL) {
      printf("In alf_linkedlist_print: %d@%p, e->prev=%p, e->next=%p, e->data=%p\n", i, e, e->prev, e->next, e->data);
      e = e->next;
      i++;
    }

    /* Unlock the arraylist object */
    pthread_mutex_unlock(&ll->lock);

  }

  fflush(stdout);
}

/**
 * Linkedlist destroy routine.
 *
 * This function free the resouces allocateed for linkedlist.
 *
 * Parameters:
 * ll[IN]: Pointer to the linkedlist.
 *
 * Return Values:
 * None.
 */

/**
 * destroy the list and not the elements associated with the list, 
 * but not the data pointed to by those elements
 */
void alf_linkedlist_destroy(alf_linkedlist_t * ll)
{
  alf_linkedlist_element_t *p;

  if (ll == NULL) {
    return;
  }

  /* Lock the linkedlist object */
  pthread_mutex_lock(&ll->lock);

  /* delete all the linkedlist elements */
  p = ll->first;
  while (p != NULL) {
    alf_linkedlist_element_t *t = p->next;
    free(p);
    p = t;
  }
  ll->first = NULL;
  ll->last = NULL;
  ll->count = 0;

  /* Unlock the linkedlist object */
  pthread_mutex_unlock(&ll->lock);

  /* Destroy the linkedlist's lock */
  pthread_mutex_destroy(&ll->lock);

  /* Free the linkedlist */
  free(ll);

  return;
}

/**
 * Linkedlist unlink routine.
 *
 * This function unlinks the list element from the linkedlist.
 *
 * Parameters:
 * ll[IN]: Pointer to the linkedlist.
 * e[IN]: Pointer to the linkedlist element.
 *
 * Return Values:
 * Pointer to the linkedlist element.
 */

alf_linkedlist_element_t *alf_linkedlist_unlink(alf_linkedlist_t * ll, alf_linkedlist_element_t * e)
{
  /* Check if this list element is the only one in the linkedlist */
  if ((ll->first == e) && (ll->last == e)) {

    ll->last = NULL;
    ll->first = NULL;

  } else {

    if (ll->first == e) {

      /* list element in front */
      e->next->prev = e->prev;
      ll->first = e->next;
      e->next = NULL;

    } else if (ll->last == e) {

      /* list element in back */
      e->prev->next = e->next;
      ll->last = e->prev;
      e->prev = NULL;

    } else {

      /* list element is somewhere in the middle */
      e->next->prev = e->prev;
      e->prev->next = e->next;
      e->prev = NULL;
      e->next = NULL;

    }

  }

  ll->count--;

  return e;
}
