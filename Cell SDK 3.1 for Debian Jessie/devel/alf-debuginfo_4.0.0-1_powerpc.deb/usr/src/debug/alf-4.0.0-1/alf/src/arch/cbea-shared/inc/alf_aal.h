/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef __ALF_AAL_H
#define __ALF_AAL_H

#include "alf_def.h"
#include "alf_common.h"
#include "alf_pal.h"

#ifdef _ALF_PLATFORM_HYBRID_
#define ALF_AAL_PKT_QLEN  16
#define ALF_AAL_PKT_QMASK 15
#else
#define ALF_AAL_PKT_QLEN  128
#define ALF_AAL_PKT_QMASK 127
#endif

/*Signal type for SPE running*/
#define SIG_PKT_ENQUEUE  0x2
#define SIG_SPE_EXIT     0x1

#define _ALF_ERROR_CALLBACK_NUM    0x0E
#define _ALF_ERROR_CALLBACK_SIGNAL 0x210E

/* AAL Version */
#define ALF_AAL_VERSION_VALUE 0x01       /* AAL version value */
#define ALF_AAL_VERSION ALF_AAL_VERSION_VALUE  /* Final AAL version format */

/* AAL version for Host runtime*/
#define GEN_HOST_ALF_AAL_VERSION ALF_AAL_VERSION 

/* Platform symbol value */
#define ALF_PLATFORM_TYPE_CELL 0x01
#define ALF_PLATFORM_TYPE_HYBRID 0x02 

#ifdef _ALF_PLATFORM_HYBRID_
#define ALF_PLATFORM_TYPE ALF_PLATFORM_TYPE_HYBRID
#else
#define ALF_PLATFORM_TYPE ALF_PLATFORM_TYPE_CELL
#endif

/* Platform value for Host runtime */
#define GEN_HOST_ALF_PLATFORM_TYPE ALF_PLATFORM_TYPE

#define ALF_TASK_TYPE_WTS 0x0         /* workblock task support */
#define ALF_TASK_TYPE_LTS 0x01        /* lightweight task support */

#define ALF_LTS_WITH_DATASET 0x0100

// these constants will be used in creation of DTL for Cell, 

#define _CELL_DMA_MAX_SIZE (16*1024)

#define _CELL_DMALIST_MAX_SIZE (2048)

#define _ALF_AAL_DTL_HEADER_SIZE (2)

#define _ALF_CELL_GET_HIGH_ADDRESS(_addr_)  (unsigned int)((alf_data_addr64_t)(_addr_)>>32)

#pragma pack(8)

typedef struct _alf_aal_pkt_queue_spu_info
{
  volatile unsigned int front;
  volatile unsigned int finished_pkt_cnt;
  volatile unsigned int spu_status;
  volatile unsigned int dummy;

  volatile unsigned int finished_wb_cnt;
  volatile unsigned int dummy3[3];
} alf_aal_pkt_queue_spu_info_t;

typedef struct _alf_aal_pkt_queue_ppu_info
{
  volatile unsigned int rear;
  unsigned int enqueued_wb_cnt;
  unsigned int dummy[2];
}alf_aal_pkt_queue_ppu_info_t;

#pragma pack()

#pragma pack(1)

typedef struct _alf_aal_wb_pkt
{
  unsigned int loop_num;
  unsigned int udata_size;
  unsigned int input_dtl_size;
  alf_data_addr64_t input_dtl_ea;
  alf_data_addr64_t udata_ea;
} alf_aal_wb_pkt_t;

typedef struct _alf_aal_task_ctx_pkt
{
  unsigned int in_buf_size;
  unsigned int out_buf_size;
  alf_data_addr64_t in_buf_ea;
  alf_data_addr64_t out_buf_ea;
} alf_aal_task_ctx_pkt_t;

typedef struct _alf_aal_token_pkt
{
  unsigned int size;
  alf_data_addr64_t token_ea;
  unsigned int data[4];
} alf_aal_token_pkt_t;

typedef enum _ALF_AAL_PKT_TYPE
{
  ALF_AAL_PKT_FLUSH,
  ALF_AAL_PKT_WBH,
  ALF_AAL_PKT_TASK_SETUP,
  ALF_AAL_PKT_CTX_SWAP,
  ALF_AAL_PKT_CTX_MERGE,
  ALF_AAL_PKT_TOKEN,
} ALF_AAL_PKT_TYPE_T;

typedef struct _alf_aal_pkt
{
  union
  {
    alf_aal_wb_pkt_t wbh;
    alf_data_addr64_t task_info_ea;
    alf_aal_task_ctx_pkt_t ctx;
    alf_aal_token_pkt_t tok;
    unsigned char pad[32-4];
  };
  unsigned short flag;
  unsigned short type;
} alf_aal_pkt_t;

#pragma pack()

#pragma pack(8)

typedef struct _alf_aal_pkt_queue
{
  alf_aal_pkt_queue_spu_info_t spu_info;

  alf_aal_pkt_queue_ppu_info_t ppu_info;

  alf_aal_pkt_t pkts[ALF_AAL_PKT_QLEN];
} alf_aal_pkt_queue_t;

typedef struct _alf_aal_wbh
{
  unsigned int status;
  unsigned int loop_num;
  unsigned int udata_size;
  unsigned int input_dtl_size;
  alf_data_addr64_t input_dtl_ea;
  unsigned int output_dtl_size;
  unsigned int ovl_dtl_size;
  alf_data_addr64_t output_dtl_ea;
  unsigned char pad[ALF_PAL_WB_PRIV_DATA_SIZE-40];
  unsigned char udata[];
} alf_aal_wbh_t;

typedef enum _ALF_MAPPED_AREA {
  ALF_MAPPED_AREA_LS,
  ALF_MAPPED_AREA_SYNC,
  ALF_MAPPED_AREA_CMD,
  ALF_MAPPED_AREA_CTRL,
  ALF_MAPPED_AREA_SIG1,
  ALF_MAPPED_AREA_SIG2
} ALF_MAPPED_AREA_T;

typedef struct _alf_mapped_area {
  alf_data_addr64_t area_eas[ALF_MAPPED_AREA_SIG2 + 1];
} alf_mapped_area_t;

typedef struct _alf_aal_task_control_block
{
  int fin_tasks;
  int tasks;
  int abort;
  int pad;
} alf_aal_task_control_block_t;

#define MAX_NUM_ACCELS 16

typedef struct _alf_aal_spu_instance
{
  union
  {
    struct
    {
      alf_aal_task_control_block_t control_blk;
      alf_data_addr64_t ti_ea;
      alf_data_addr64_t mapped_areas_ea;
      unsigned int vtol_id_map[MAX_NUM_ACCELS];
    };
    struct
    {
      alf_data_addr64_t pkt_queue_ea;
      alf_data_addr64_t prof_ea;
    };
    char pad[128 - 32];
  };	
  unsigned int id;
  unsigned int dataset_ready;
  alf_data_addr64_t thread_ea;
  alf_data_addr64_t error_ea;
  alf_data_addr64_t dataset_ea;
} alf_aal_spu_instance_t;

typedef union _alf_aal_dtl_t_
{
  struct dtl_header1_t
  {
    unsigned short int total_size;
    unsigned short int buf_type;
    unsigned short int num_dtl_entry;
    unsigned short int num_type_entry;
  } header1;
  struct dtl_header2_t
  {
    unsigned int ea_high;
    unsigned int local_offset;
  } header2;
  struct mfc_element_t
  {
    unsigned int notify : 1;
    unsigned int reserved : 16;
    unsigned int size : 15;
    unsigned int eal : 32;
  } dtl;
  struct data_type_table_t
  {
    ALF_DATA_TYPE_T type;
    unsigned int count;
  } type;
} alf_aal_dtl_t;

#pragma pack()

/**
 * The responses from the SPU to the PPU
 */
#define _ALF_STATE_START_TASK_ACK   0xEADC
#define _ALF_STATE_EXIT_TASK_ACK    0xAECD
#define _ALF_STATE_CHANGE_TASK_ACK  0xCAED
#define _ALF_STATE_NONE             0x0000

/**
 * Status of work block 
 * _ALF_WORK_BLOCK_STATUS_INIT: The work block has schduled to execute.
 * _ALF_WORK_BLOCK_STATUS_EQ:   The work block has been put into queue.
 * _ALF_WORK_BLOCK_STATUS_FIN:  The work block has been executed successfully.
 *
 */
#define _ALF_WORK_BLOCK_STATUS_INIT   0x1
#define _ALF_WORK_BLOCK_STATUS_EQ     0x2
#define _ALF_WORK_BLOCK_STATUS_FIN    0x3


//! Size of a single dma entry
#define _ALF_MFC_ELEMENT_SIZE     8

//! Maxim dma list number supported in a single data transfer information structure
#define _ALF_MAX_DMALIST_NUM      8

//! Maxim data transfer size for a single dma entry
#define _ALF_MAX_SINGLE_DT_SIZE (16 * 1024)

//! Maxim number of dma entries can be supported in a single dma list
#define _ALF_DMA_LIST_MAX_ELEMENT_NUM   (2 * 1024)

//Default number of mfc elements for a workblock
#define _ALF_DMA_DEFAULT_ELEMENT_NUM   (128)

//Default number of dma lists for a workblock
#define _ALF_DMA_DEFAULT_LIST_NUM   (10)


//! Maxim spe local store buffer size for working block header, user data and etc.
#define _ALF_MAX_SPE_LS_SIZE_ 240 * 1024

//! Maxim alignment factor which is allowed
#define _ALF_MAX_ALIGN_FACTOR_  8

//! Maxim dma entry number
#define _ALF_MAX_DMA_ENTRY_NUM  (_ALF_MAX_DMALIST_NUM * _ALF_DMA_LIST_MAX_ELEMENT_NUM)


#pragma pack(8)

typedef struct _alf_error_msg 
{
  int error_code;
  ALF_ERR_TYPE_T error_type;
  int extra_error_code;
  ALF_ERR_POLICY_T error_handle_policy;
	unsigned int error_reason;
	unsigned int error_sub_reason;
	unsigned int error_spu_vid;
	unsigned int error_spu_vid_max;
  unsigned char _pad[128 - 8 * 4];
} alf_error_msg;

/**
 * Data entry descriptor. 
 * It will describe the constituion of a continuous memory,
 * Data entry is divided into multiple units.
 */
typedef struct _entry_desc
{
  ALF_DATA_TYPE_T type; //unit's data type
  int size; //how many units
} entry_desc_t;

/**
 * Task information, holds all the attributes of a task which will be
 * used by SPE thread to do memory allocation.
 */
typedef struct _alf_task_info 
{
  unsigned int accels;            //number of accelerators executing this task
  unsigned int ctx_size;          //task context size
  alf_data_addr64_t ctx_ea;
  alf_data_addr64_t ctx_entry_desc_ea; //effective address of context data entry descriptor, please see entry_desc_t
  unsigned int ctx_entry_num;     //number of context data entry descriptors
  unsigned int wb_max_udata_size; //maximum user data size in work block
  unsigned int wb_max_in_size;    //maximum input data size in work block
  unsigned int wb_max_out_size;   //maximum output data size in work block
  unsigned int wb_max_inout_size; //maximum inout data size in work block
  unsigned int wb_max_dtl_entries;    //maximum data transfer size in work block
  unsigned int wb_max_dtl_num;
  unsigned int wb_max_dtl_size;
  unsigned int wb_max_stack_size; //maximum stack size
  unsigned int task_attr;         //task attr
  alf_data_addr64_t task_handle_ea;
  unsigned int api_addrs[5];
  char pad[36];
} alf_task_info_t;

#ifdef _ALF_PLATFORM_HYBRID_
#define _ALF_MAX_DTL_SIZE(dtl_num, entry_num) ((dtl_num + entry_num + 1) * 2 * sizeof(alf_aal_dtl_t))
#else
#define _ALF_MAX_DTL_SIZE(dtl_num, entry_num) (((dtl_num + 1) * 2 + entry_num) * sizeof(alf_aal_dtl_t))
#endif

/**
 * Describe a MFC element required by CELL hardware.
 */
typedef struct _mfc_element
{
  unsigned int notify : 1;
  unsigned int reserved : 16;
  unsigned int size : 15;
  unsigned int eal : 32;
} mfc_element_t;

/**
 * Describe a MFC dma list.
 * SPU will use this data structure to issue a DMA Get List command.
 */
typedef struct _alf_mfc_dma_list
{
  unsigned int eah32;        //high 32-bit of effective address
  int elmnt_offset; //offset to elments_ea in alf_data_transfer_info_t
  int elmnt_cnt;    //number of MFC elements belong to this dma list
  int ls_off;       //local store offset 
  int type;                  //which type of I/O buffer this dma list targets to
  int cur_ls_size;  //the data transfer size of this dma list
} alf_mfc_dma_list_t;

#define _ALF_MAX_DTL_NUM        (128)
#define _ALF_MAX_SINGLE_DT_SIZE (16 * 1024)
/**
 * Describe data transfer information for a work block.
 * SPU will use this data structure to get input data and put output data.
 */
typedef struct _alf_data_transfer_info
{
  alf_data_addr64_t dmalist_ea;       //effective address of all the dma lists
  int dmalist_num;                        //number of used dma list
  int max_elmnts_num;                     //maximum number of MFC elements
  alf_data_addr64_t elmnts_ea;         //effective address of all the MFC elements
  alf_data_addr64_t entry_desc_ea;     //one-to-one relationship with elmnts_ea, i.e. for each MFC element,
                            //there is a data entry descriptor
  int elmnts_num;  //number of available MFC elements in elmnts_ea
  unsigned int lsptr_edesc; //local store address of the entry description list
} alf_data_transfer_info_t;

#ifdef _ALF_PLATFORM_HYBRID_
/**
 * Describes a dataset buffer
 * This data structure is quadword aligned
 */ 
typedef struct _alf_dataset_buffer
{
  alf_data_addr64_t host_addr;           // host address of the buffer
  alf_data_addr64_t mid_offset;            //offset of the buffer in the PPE remote shared memory. 
  unsigned long long size;               //size of the buffer
  ALF_DATASET_ACCESS_MODE_T access_mode; //access mode
  unsigned int pad;
} alf_dataset_buffer_t;
#endif /* _ALF_PLATFORM_HYBRID_ */

#pragma pack()

#endif

