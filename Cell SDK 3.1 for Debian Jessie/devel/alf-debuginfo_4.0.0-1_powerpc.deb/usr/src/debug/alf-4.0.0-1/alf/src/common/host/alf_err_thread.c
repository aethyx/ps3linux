/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include <unistd.h>
#include <alf.h>
#include "alf_host.h"
#include "alf_debug.h"

ALF_ERR_POLICY_T  alf_err_pal_error_handler(void *p_context_data, void *task_handle, ALF_ERR_TYPE_T error_type, int error_code, char *error_string)
{
  unsigned long long err;
  int ret;
  alf_instance_t *alf_instance = p_context_data;
  alf_api_task_t* task_api_handle = task_handle;
  alf_api_t* alf_handle = task_api_handle->alf_handle;

  if (alf_instance->state >= ALF_API_STATUS_EXITING) 
    return -ALF_ERR_GENERIC;

  pthread_mutex_lock(&alf_instance->err_lock);
  err = alf_instance->err_num + 1;
  alf_instance->err_num = err;
  ret = alf_err_error_processing(alf_handle, error_type, error_code, error_string);
  alf_instance->err_finished++;
  pthread_mutex_unlock(&alf_instance->err_lock);
  
  return ret;
}

ALF_ERR_POLICY_T alf_err_call_error_handler(alf_api_t* alf_handle, ALF_ERR_TYPE_T error_type, int error_code, char *err_msg)
{
    ALF_ERR_POLICY_T rtn;
    //lock to avoid user register a new error handler
    pthread_mutex_lock(&alf_handle->lock); 
    switch(error_type)
    {
        case ALF_ERR_WARNING:
            rtn = alf_handle->err_handler(alf_handle->err_handler_data_ptr, error_type, error_code, err_msg);
            break;
            
        case ALF_ERR_EXCEPTION: 
            rtn = alf_handle->err_handler(alf_handle->err_handler_data_ptr, error_type, error_code, err_msg);
            if(ALF_ERR_POLICY_IGNORE == rtn)
            {
                _ALF_DPRINTF(_ALF_ERR_LEVEL_WARNING_, "User error handler required to ignore EXCEPTIONS, will do SKIP!\n");
                rtn = ALF_ERR_POLICY_SKIP;
            }
            break;

        case ALF_ERR_FATAL:     // we have no choice but abort
            rtn = alf_handle->err_handler(alf_handle->err_handler_data_ptr, error_type, error_code, err_msg);

            if(ALF_ERR_POLICY_ABORT != rtn)
            {
                _ALF_DPRINTF(_ALF_ERR_LEVEL_WARNING_, "User error handler required to continue with FATAL, will do ABORT!\n");
                rtn = ALF_ERR_POLICY_ABORT;
            }
            break;

         default:               // if we are called wrongly
             _ALF_DPRINTF(_ALF_ERR_LEVEL_WARNING_, "ALF runtime internal error: unexpected error_type %d \n", error_type);
             rtn = ALF_ERR_POLICY_ABORT;
             break;
    }
    pthread_mutex_unlock(&alf_handle->lock); 

    return rtn;
}
ALF_ERR_POLICY_T alf_err_error_processing(alf_api_t* alf_handle, ALF_ERR_TYPE_T error_type, int error_code, char *err_msg)
{
  ALF_ERR_POLICY_T err;
	_ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Enter: alf_handle=%p, error_type=%d, error_code=%d, err_msg=%s\n", alf_handle, error_type, error_code, err_msg);
  err = alf_err_call_error_handler(alf_handle, error_type, error_code, err_msg);
  switch(err)
  {
    case ALF_ERR_POLICY_IGNORE:
    {
    }
    break;
    case ALF_ERR_POLICY_RETRY:
    {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Retry unsupported yet!\n");
    }
    break;
    case ALF_ERR_POLICY_SKIP:
    {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Skip error with error code %d, error string \"%s\"\n",error_code,err_msg);
    }
    break;
    case ALF_ERR_POLICY_ABORT:
    {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_ALWAYS_, "An Error with error code:%d, error string \"%s\" caught, aborting.\n",
                   error_code, err_msg);
      //return to main loop to force exit 
      //the user main thread should be still alive 
      pthread_mutex_lock(&alf_handle->lock);
      alf_handle->state = ALF_API_STATUS_EXITING;
      alf_handle->exit_policy = ALF_EXIT_POLICY_FORCE; 
      pthread_mutex_unlock(&alf_handle->lock);
      alf_api_task_cancel(alf_handle);
    }
    break;
    default:
    {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Out of policy error!\n");
    }
  }
  _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Exit\n");
  return err;
}

