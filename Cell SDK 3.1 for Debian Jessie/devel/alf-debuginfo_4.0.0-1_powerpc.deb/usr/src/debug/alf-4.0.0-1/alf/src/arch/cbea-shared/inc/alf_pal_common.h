/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include "alf_aal.h"
#if defined(__PPU__) || defined(__SPU__)
#include <libspe2.h>
#endif
#include "alf_prof.h"
#include "alf_config.h"

/*Queue length for free data buffer*/
#define _ALF_WB_FREE_DATA_BUF_LEN     ALF_AAL_PKT_QLEN

/**
 * Status of task queue.
 *
 * _ALF_TASK_Q_ACTIVE: Task queue has been initialized.
 * _ALF_TASK_Q_WAIT:   Task queue in waiting status
 * _ALF_TASK_Q_FIN:    Task queue has accomplished his mission. 
 * _ALF_TASK_Q_DESTROY: Task queue can be destroyed.
 * _ALF_TASK_Q_CLOSE:  Task handle has been closed.
 */
#define _ALF_TASK_Q_ACTIVE            0xDB01
#define _ALF_TASK_Q_WAIT              0xDB02
#define _ALF_TASK_Q_FIN               0xDB03
#define _ALF_TASK_Q_DESTROY           0xDB04
#define _ALF_TASK_Q_CLOSE             0xDB05


typedef struct _alf_spe_thread {
#if defined(__PPU__) || defined(__SPU__)
 spe_program_handle_t* handle;
 struct spe_context *spe_context;
#else
  void *handle;
  void *spe_context;
#endif
  void *argp;
  void *envp;
  volatile int state;
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
  pthread_cond_t cond;
  pthread_mutex_t lock;
#if defined(__PPU__) || defined(__SPU__)
  spe_stop_info_t stop_info;
#else
  char stop_info[24]; // this is a pad, and must be the same length as a LIBSPE2 spe_stop_info_t structure
#endif
} alf_spe_thread;


/**
 * struct _alf_wq_free_dq
 *
 * This data structure is used for storing the ea which is the pointer to the
 * data need to be freed.
 *
 * front_index: Front index for this loop queue.
 * rear_index:  Rear index for this loop queue.
 * capacity:    Capacity of this loop queue. By default, it should be
 *              _ALF_WB_FREE_DATA_BUF_LEN + 1.
 * data:        Data array which holds the ea address.
 */
typedef struct _alf_wq_free_dq {
  volatile int front_index;
  volatile int rear_index;
  int capacity;
#ifdef _ALF_64B_
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
  void *data[_ALF_WB_FREE_DATA_BUF_LEN + 1];
} alf_wq_free_dq_t;

typedef struct _alf_pal_sym_info {
#if defined(__PPU__) || defined(__SPU__)
  spe_program_handle_t *spe_task_image;
#else
  void *spe_task_image;
#endif
  void *lib_handle;
  unsigned int api_addrs[5];
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
} alf_pal_sym_info_t ;


typedef union _alf_pal_thread {
  struct _alf_spu_thread_content {
    alf_aal_spu_instance_t spu_instance;     //! MUST be 128 bytes Aligned
    alf_task_info_t task_info;  //! MUST be 128 bytes Aligned
    alf_aal_pkt_queue_t pkt_queue; //! MUST be 128 bytes Aligned
    alf_error_msg error_handle; //! MUST be 128 bytes Aligned
#ifdef _ALF_STP_ENABLE_ACCEL
    alf_spu_prof_t spu_prof; //! MUST be 128 bytes Aligned
#endif
    int state;  //  seems to be either _ALF_SPU_SLOT_UNUSED or _ALF_SPU_SLOT_ACTIVE from alf_pal_internal.h
#ifdef _ALF_64B_
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
    pthread_t id;
#ifdef _ALF_32B_
  char _pad_2_[8]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
    alf_spe_thread spe_thread;
    alf_pal_handle alf_pal_desc_ptr;
    alf_wq_free_dq_t freedq;
    void *lib_handle;
    alf_data_addr64_t handle;
    unsigned int total_wbs;
    unsigned int pending_wbs;
    unsigned int running_wbs;
    unsigned int finished_wbs;
    unsigned int total_pkt_req;
    unsigned int finished_pkt_req;
	ALF_TASK_TYPE_T task_type;
    int thread_error;
  } data;
  unsigned char _pad[(sizeof(struct _alf_spu_thread_content) + 127) & 0xFF80];
} alf_pal_thread_t;


typedef struct _alf_pal_descriptor {
  unsigned int acces;
  int task_id;
  int magic_id;
#ifdef _ALF_64B_
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
  alf_pal_thread_t *threads;
  alf_mapped_area_t *mapped_areas;

  /* error handler call back */
  alf_pal_error_handler_t err_handler;
  void *err_handler_ctx;                /* error handler context buffer */
  int state;
  int spe_running;
  unsigned int running_task;
  char _pad_2_[4];
} alf_pal_descriptor_t;

typedef struct _alf_pal_config {
  alf_pal_descriptor_t *pal_handle;
#ifdef _ALF_64B_
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
  char config_parm[ALF_STRING_TOKEN_MAX+1];
} alf_pal_config_t;

typedef struct _alf_lib_path_iter {
  int start;  /* out */
  int end;  /* out */
  char *config;  /* in */
#ifdef _ALF_64B_
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
  char single_path[ALF_STRING_TOKEN_MAX+1];  /* out */
} alf_lib_path_iter_t;
