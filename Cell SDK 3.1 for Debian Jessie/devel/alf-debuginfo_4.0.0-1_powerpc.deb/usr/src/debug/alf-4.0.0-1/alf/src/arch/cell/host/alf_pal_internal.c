/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pthread.h>
#include <libmisc.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <dirent.h>
//#include <cbe_mfc.h>

#include "alf_debug.h"
#include "alf_misc.h"
#include "alf_pal_internal.h"
#include "alf_misc_ppu.h"
#include "alf_common.h"
#include "alf_api_local.h"
#include "alf_aal.h"
#include <alf_errno.h>



//********************************************************
// APIs
//********************************************************

//--------------------------------------------------------
// Framework APIs
//--------------------------------------------------------

#define PROC_CPUINFO "/proc/cpuinfo"

/* Check the pvr in cpuinfo, if found the known eDP pvr, return 1, otherwise return 0 */
int is_celledp()
{   
    FILE* fd;
    int ret = 0;
    char buf1[PATH_MAX];
    char buf2[PATH_MAX];
    short int major=0, minor = 0;
    int pvr_ver = 0, pvr_rev = 0;

    fd = fopen(PROC_CPUINFO, "r");
    if (fd)
    {   
        while (fscanf(fd, "%s", buf1) != EOF)
        {   
            /* process lines starts with revision */
            if (strncmp(buf1, "revision", 8) == 0)
            {   
                if (fscanf(fd, "\t: %hd.%hd (%s %d %d)", &major, &minor, buf2, &pvr_ver, &pvr_rev) == 5) {
                    /* Check the revision for eDP: 0070 3000 */
                    if ((strncmp(buf2, "pvr", 3) == 0) &&
                        ((pvr_ver == 70) && (pvr_rev == 3000||pvr_rev == 500)))
                    {   
                        ret = 1;
                        break;
                    }
                }
            }
        }

        fclose(fd);
    }

    return ret;
}

/**
 * Count the total system spe number
 */
int spe_count_physical_spes()
{
  int count = 0;
  DIR *dirp;
  struct dirent *dptr;
  if ((dirp = opendir("/sys/devices/system/spu")) != NULL) {
    while ((dptr = readdir(dirp))) {
      count++;
    }
    closedir(dirp);

    /* . and .. should not been counted */
    count -= 2;
  }

  // get number of desired spes from env variable
  {
	  int	num_of_spes = count;
	  char	*num_of_spes_string = NULL;
	  
	  num_of_spes_string = getenv("ALF_NUM_OF_SPES");
	  if (num_of_spes_string != NULL) {
		  num_of_spes = atoi(num_of_spes_string);
		  _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "ALF_NUM_OF_SPES=%s\n", num_of_spes_string);

		  if ((num_of_spes > 0) && (num_of_spes < count)) {
			  count = num_of_spes;
		  }
	  }
	  _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "spe_count_physical_spes=%d\n", count);
  }

  return count;
}


int _alf_pal_is_task_info_changed(alf_pal_thread_t * thread_handle, alf_pal_task_info_t * task_info)
{
  alf_task_info_t *p_tinfo = &thread_handle->data.task_info;

  if (p_tinfo->wb_max_udata_size != task_info->parm_ctx_buffer_size)
    return 1;

  return 0;
}


/**
 * Init the task info for SPU runtime according alf_pal_task_info
 */
int
_alf_pal_task_info_init(alf_pal_thread_t * p_alf_pal_thread,
                        alf_pal_task_info_t * task_info, 
                        unsigned int num_of_accels, int is_reset)
{
  alf_task_info_t *p_tinfo = &p_alf_pal_thread->data.task_info;
  alf_pal_sym_info_t *p_sym;
  unsigned int total_size = 0u;
  int i;

  if (task_info->parm_ctx_buffer_size > _ALF_MAX_SPE_LS_SIZE_ ||
      task_info->task_context_size > _ALF_MAX_SPE_LS_SIZE_ ||
      task_info->input_buffer_size > _ALF_MAX_SPE_LS_SIZE_ ||
      task_info->output_buffer_size > _ALF_MAX_SPE_LS_SIZE_ ||
      task_info->overlapped_buffer_size > _ALF_MAX_SPE_LS_SIZE_ ||
      task_info->dt_list_entries > _ALF_MAX_DMA_ENTRY_NUM || task_info->stack_size > _ALF_MAX_SPE_LS_SIZE_) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid io size\n");
    return -ALF_ERR_NOEXEC;
  }

  p_alf_pal_thread->data.task_type = task_info->task_type;
  p_tinfo->ctx_ea = task_info->context_to_set;
  p_tinfo->wb_max_dtl_size = _ALF_MAX_DTL_SIZE(task_info->dt_list_num, task_info->dt_list_entries);
  p_tinfo->wb_max_dtl_size = _ALF_DMA_SIZE_ALIGN_(p_tinfo->wb_max_dtl_size);
  
  p_tinfo->wb_max_dtl_entries = task_info->dt_list_entries;
  p_tinfo->wb_max_dtl_num = task_info->dt_list_num;

  p_tinfo->accels = num_of_accels;
  p_tinfo->wb_max_udata_size = task_info->parm_ctx_buffer_size;
  p_tinfo->ctx_size = task_info->task_context_size;
  p_tinfo->wb_max_in_size = task_info->input_buffer_size;
  p_tinfo->wb_max_out_size = task_info->output_buffer_size;
  p_tinfo->wb_max_inout_size = task_info->overlapped_buffer_size;
  p_tinfo->wb_max_stack_size = task_info->stack_size;
  p_tinfo->task_handle_ea = task_info->task_handle_ea;
  PTR_TO_ADDR64(task_info->context_desc, p_tinfo->ctx_entry_desc_ea);
  p_tinfo->ctx_entry_num = task_info->context_desc_num;

  //FIXME
  p_tinfo->task_attr = task_info->task_attr;

  if( !is_reset ) {
    p_sym = (alf_pal_sym_info_t *)task_info->p_arch_tinfo;
    for(i=0; i<ALF_API_KERNEL_NUM; i++) {
      p_tinfo->api_addrs[i] = p_sym->api_addrs[i];
    }
  }
  else {
    /*  Symbol name to address when thread reset */
    if(_alf_pal_symname_to_addr(p_alf_pal_thread->data.lib_handle, p_tinfo, task_info) < 0)
      return -ALF_ERR_NOEXEC; 
  }
 
  total_size += _ALF_DMA_SIZE_ALIGN_(p_tinfo->ctx_size);
  total_size += _ALF_DMA_SIZE_ALIGN_(p_tinfo->wb_max_udata_size);
  total_size += _ALF_DMA_SIZE_ALIGN_(p_tinfo->wb_max_in_size);
  total_size += _ALF_DMA_SIZE_ALIGN_(p_tinfo->wb_max_out_size);
  total_size += _ALF_DMA_SIZE_ALIGN_(p_tinfo->wb_max_inout_size);
  total_size += _ALF_DMA_SIZE_ALIGN_(p_tinfo->wb_max_dtl_size);
  total_size += _ALF_DMA_SIZE_ALIGN_(p_tinfo->wb_max_stack_size);


  if (total_size > _ALF_MAX_SPE_LS_SIZE_) {
    goto ERR;
  }

  return 0;

ERR:

  _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid task information "
               "task_max_context_size %d "
               "wb_max_udata_size %d "
               "wb_max_in_size %d wb_max_out_size %d wb_max_inout_size %d"
               "wb_max_dti__size %d"
               "wb_max_stack_size %d\n",
               p_tinfo->ctx_size,
               p_tinfo->wb_max_udata_size,
               p_tinfo->wb_max_in_size,
               p_tinfo->wb_max_out_size,
               p_tinfo->wb_max_inout_size, p_tinfo->wb_max_dtl_size, p_tinfo->wb_max_stack_size);

  return -ALF_ERR_NOEXEC;

}


/**
 * Get the logical id of PAL thread
 */
unsigned int _alf_pal_get_accel_id(alf_pal_thread_t * p_alf_pal_thread)
{
  alf_pal_descriptor_t *p_alf_pal_desc;
  unsigned int accel_id;

  p_alf_pal_desc = (alf_pal_descriptor_t *) (p_alf_pal_thread->data.alf_pal_desc_ptr);

#ifdef _ALF_32B_
  accel_id = ((unsigned long) p_alf_pal_thread - (unsigned long) (p_alf_pal_desc->threads)) / sizeof(alf_pal_thread_t);
#elif _ALF_64B_
  accel_id = ((unsigned long long) p_alf_pal_thread -
              (unsigned long long) (p_alf_pal_desc->threads)) / sizeof(alf_pal_thread_t);
#endif
  return accel_id;
}



int _alf_pal_freedq_full(alf_wq_free_dq_t * fdb_ptr)
{
  return ((fdb_ptr->rear_index + 1) % fdb_ptr->capacity == fdb_ptr->front_index);
}



/**
 * Init the packet queue, spu 
 * runtime will get the packet from this queue
 */
void _alf_pal_req_queue_init(alf_pal_thread_t * thread_handle, unsigned int spu_id)
{
  alf_aal_spu_instance_t *spu_instance;
  alf_aal_pkt_queue_t *pkt_queue;

  spu_instance = &(thread_handle->data.spu_instance);
  if (thread_handle->data.task_type == ALF_TASK_TYPE_LIGHTWEIGHT)
  {
    spu_instance->control_blk.tasks = 1;
    spu_instance->control_blk.fin_tasks = 0;
    spu_instance->control_blk.abort = 0;
  }
  else
  {
    pkt_queue = &(thread_handle->data.pkt_queue);

    //init spu info
    pkt_queue->spu_info.front = 0;
    pkt_queue->spu_info.finished_wb_cnt = 0;
    pkt_queue->spu_info.finished_pkt_cnt = 0;
    pkt_queue->spu_info.spu_status = 0;

    //init ppu info
    pkt_queue->ppu_info.rear = 0;
    pkt_queue->ppu_info.enqueued_wb_cnt = 0;

	PTR_TO_ADDR64(&(thread_handle->data.pkt_queue), spu_instance->pkt_queue_ea);

#ifdef _ALF_STP_ENABLE_ACCEL
    PTR_TO_ADDR64(&(thread_handle->data.spu_prof), spu_instance->prof_ea);
#endif
  }

  spu_instance->id = spu_id;

#ifdef _ALF_PLATFORM_HYBRID_
#else
  PTR_TO_ADDR64(thread_handle, spu_instance->thread_ea);
#endif
  PTR_TO_ADDR64(&(thread_handle->data.error_handle), spu_instance->error_ea);
 
  PTR_TO_ADDR64((void*)0, spu_instance->dataset_ea);

  thread_handle->data.error_handle.error_code = 0;
}

void _alf_pal_req_queue_reinit(alf_pal_thread_t * thread_handle, unsigned int spu_id)
{
  alf_aal_spu_instance_t *spu_instance = &thread_handle->data.spu_instance;
  alf_aal_pkt_queue_t *pkt_queue;

  spu_instance->id = spu_id;
  if (thread_handle->data.task_type == ALF_TASK_TYPE_LIGHTWEIGHT)
  {
    spu_instance->control_blk.abort = 0;
    spu_instance->dataset_ready = 0;
    spu_instance->control_blk.tasks++;
    return;
  }

  pkt_queue = &(thread_handle->data.pkt_queue);

  //init spu info
  pkt_queue->spu_info.finished_wb_cnt = 0;
  pkt_queue->spu_info.finished_pkt_cnt = 0;
  pkt_queue->spu_info.spu_status = 0;

  //init ppu info
  pkt_queue->ppu_info.enqueued_wb_cnt = 0;

  thread_handle->data.error_handle.error_code = 0;
}

/**
 * Check if all the packets are finished
 */
int _alf_pal_is_all_pkt_finished(alf_pal_thread_t * thread_handle)
{
  unsigned int finished_wbs;
  unsigned int finished_pkt_req;
  unsigned int total_wbs;
  unsigned int total_pkt_req;

  if (thread_handle->data.task_type == ALF_TASK_TYPE_LIGHTWEIGHT)
  {
    alf_aal_spu_instance_t *spu_instance = &thread_handle->data.spu_instance;
    return spu_instance->control_blk.tasks == spu_instance->control_blk.fin_tasks;
  }
  
  finished_wbs = thread_handle->data.pkt_queue.spu_info.finished_wb_cnt;
  finished_pkt_req = thread_handle->data.pkt_queue.spu_info.finished_pkt_cnt;

  total_wbs = thread_handle->data.total_wbs;
  total_pkt_req = thread_handle->data.total_pkt_req;
  
  return (total_pkt_req == finished_pkt_req  && total_wbs == finished_wbs);
}


/**
 * Packet queue enqueue routine.
 *   packet enqueue, then send the notification to spu runtime
 */
int _alf_pal_req_queue_enqueue(alf_pal_thread_t * thread_handle, alf_aal_pkt_t * pkt)
{
  volatile alf_aal_pkt_queue_t *pkt_queue;
  int ppu_index;
  
  pkt_queue = &thread_handle->data.pkt_queue;
  ppu_index = pkt_queue->ppu_info.rear;

  _ALF_SYNC_MEMORY();
  pkt_queue->ppu_info.rear = (ppu_index + 1) &  ALF_AAL_PKT_QMASK;

  _ALF_SYNC_MEMORY();
  _alf_pal_notify_spe_thread(thread_handle, SIG_PKT_ENQUEUE);

  if (pkt->type == ALF_AAL_PKT_WBH) 
  {
    thread_handle->data.total_wbs++;
  }
  thread_handle->data.total_pkt_req++;
  
  return 0;
}

static __inline__ void _spe_sig_notify_1_write(volatile spe_sig_notify_1_area_t *ps_area, unsigned int data)
{
    ps_area->SPU_Sig_Notify_1 = data;
/*   volatile unsigned int prev;
    do
    {
      prev = ps_area->SPU_Sig_Notify_1;
    }  while(prev!=0);
    __asm__("eieio");
    ps_area->SPU_Sig_Notify_1 = data;
*/
}

/**
 * Notify routine
 *   notify spu runtime that there is a new packet
 */
int _alf_pal_notify_spe_thread(alf_pal_thread_t * thread_handle,unsigned int sig_val)
{
  spe_sig_notify_1_area_t *sig1_ps;
  alf_spe_thread spe_thread = thread_handle->data.spe_thread;

  sig1_ps = spe_ps_area_get(spe_thread.spe_context, SPE_SIG_NOTIFY_1_AREA);

  _spe_sig_notify_1_write(sig1_ps, sig_val);

  return 0;
}


/**
 * Check the packet queue is full or not
 */
int _alf_pal_is_req_queue_full(alf_aal_pkt_queue_t * pkt_queue)
{

  return (((pkt_queue->ppu_info.rear + 1) & ALF_AAL_PKT_QMASK)
          == pkt_queue->spu_info.front);
}

/**
 * Checking whether all the spus are finished.
 *  This function checks whether all the spus accomplished their work.
 */
int _alf_pal_is_all_spu_finished(alf_pal_descriptor_t * p_alf_pal_desc)
{
  int i;
  alf_aal_pkt_queue_t *pkt_queue;
  int acces = p_alf_pal_desc->acces;

  for (i = 0; i < acces; ++i) {
    pkt_queue = &_ALF_GET_SPU_SLOT(p_alf_pal_desc, i).pkt_queue;
    if (pkt_queue->ppu_info.rear != pkt_queue->spu_info.front) {
      return 0;
    }
  }

  return 1;
}


void _alf_pal_spu_pthread_idle(alf_spe_thread* spe_thread)
{
  int ret;
  struct timeval now;
  struct timespec wait_time;
#ifdef HOT_SPINNING
    if(spe_thread->state == _ALF_SPU_PTHREAD_IDLE)
      pthread_yield();
#else
    _ALF_API_STD_COND_WAIT(spe_thread->lock,
                         spe_thread->cond,
                         wait_time, now,
                         -1,
                         spe_thread->state == _ALF_SPU_PTHREAD_IDLE ,
                         ret );
#endif
}
int _alf_pal_spu_pthread_wait(alf_spe_thread* spe_thread)
{
  int ret = 0;
  struct timeval now;
  struct timespec wait_time;
#ifdef HOT_SPINNING
    if(spe_thread->state != _ALF_SPU_PTHREAD_IDLE)
      pthread_yield();
#else
    _ALF_API_STD_COND_WAIT(spe_thread->lock,
                         spe_thread->cond,
                         wait_time, now,
                         500,
                         spe_thread->state != _ALF_SPU_PTHREAD_IDLE ,
                         ret );
#endif
  return ret;
}
void *_alf_spe_pthread(void *data)
{

  alf_spe_thread *spe_thread = (alf_spe_thread *) data;
  unsigned int flags = 0;       //SPE_RUN_USER_REGS;
  unsigned int entry;
  int ret;

  pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);

  // run SPE context
  do {
    _alf_pal_spu_pthread_idle(spe_thread);

    if(spe_thread->state == _ALF_SPU_PTHREAD_ACTIVE)
    {
      entry = SPE_DEFAULT_ENTRY;
      ret = spe_program_load(spe_thread->spe_context, spe_thread->handle);
      ret = spe_context_run(spe_thread->spe_context, &entry, flags, 
                          spe_thread->argp, spe_thread->envp, &spe_thread->stop_info);
#if 0
    printf
        ("After spe_context_run, context=%p, ret=%d, entry=0x%x, stop_info.stop_reason=0x%x\n",
         spe_thread->spe_context, ret, entry, spe_thread->stop_info.stop_reason);
    switch (spe_thread->stop_info.stop_reason) {
    case SPE_EXIT:
        printf
            ("After spe_context_run, context=%p, SPE_EXIT stop_info.result.stop_exit_code=%d\n",
             spe_thread->spe_context, spe_thread->stop_info.result.spe_exit_code);
        break;
    case SPE_STOP_AND_SIGNAL:
        printf
            ("After spe_context_run, context=%p, SPE_STOP_AND_SIGNAL stop_info.result.stop_signal_code=%d\n",
             spe_thread->spe_context, spe_thread->stop_info.result.spe_signal_code);
        break;
    case SPE_RUNTIME_ERROR:
        printf
            ("After spe_context_run, context=%p, SPE_RUNTIME_ERROR stop_info.result.spe_runtime_error=%d\n",
             spe_thread->spe_context, spe_thread->stop_info.result.spe_runtime_error);
        break;
    case SPE_RUNTIME_EXCEPTION:
        printf
            ("After spe_context_run, context=%p, SPE_RUNTIME_EXCEPTION stop_info.result.spe_runtime_exception=%d\n",
             spe_thread->spe_context, spe_thread->stop_info.result.spe_runtime_exception);
        break;
    case SPE_RUNTIME_FATAL:
        printf
            ("After spe_context_run, context=%p, SPE_RUNTIME_FATAL stop_info.result.spe_runtime_fatal=%d\n",
             spe_thread->spe_context, spe_thread->stop_info.result.spe_runtime_fatal);
        break;
    case SPE_CALLBACK_ERROR:
        printf
            ("After spe_context_run, context=%p, SPE_CALLBACK_ERROR stop_info.result.spe_callback_error=%d\n",
             spe_thread->spe_context, spe_thread->stop_info.result.spe_callback_error);
        break;
    case SPE_ISOLATION_ERROR:
        printf
            ("After spe_context_run, context=%p, SPE_ISOLATION_ERROR stop_info.result.spe_isolation_error=%d\n",
             spe_thread->spe_context, spe_thread->stop_info.result.spe_isolation_error);
        break;
    default:
        printf("After spe_context_run, context=%p, UNKNOWN\n", spe_thread->spe_context);
        break;
    }
    printf
        ("After spe_context_run, context=%p, stop_info.spu_status=0x%x\n",
         spe_thread->spe_context, spe_thread->stop_info.spu_status);
#endif

      if (spe_thread->stop_info.stop_reason == SPE_RUNTIME_ERROR ||
          spe_thread->stop_info.stop_reason == SPE_RUNTIME_EXCEPTION ||
    		  spe_thread->stop_info.stop_reason == SPE_RUNTIME_FATAL ||
    		  spe_thread->stop_info.stop_reason == SPE_CALLBACK_ERROR ||
    		  spe_thread->stop_info.stop_reason == SPE_ISOLATION_ERROR) {

         /* Get address of instance structure */    		  	
         alf_aal_spu_instance_t *instance_handle = (alf_aal_spu_instance_t *)spe_thread->argp;
         
         /* Set values into the error structure for ASYNC error case */
         alf_error_msg *errs;
         ADDR64_TO_PTR(instance_handle->error_ea, alf_error_msg *, errs);
         errs->error_type = ALF_ERR_FATAL;
         errs->error_code = ALF_ERR_ACCEL;
         errs->extra_error_code = 0;
         errs->error_reason = spe_thread->stop_info.stop_reason;
         errs->error_sub_reason = spe_thread->stop_info.result.spe_runtime_exception;
         
         /* Invoke error handler */
         alf_spe_error_callback_helper(instance_handle);
      }
                          
      pthread_mutex_lock(&spe_thread->lock);
      if(spe_thread->state != _ALF_SPU_PTHREAD_EXITING)
      {
        pthread_cond_signal(&spe_thread->cond);
        spe_thread->state = _ALF_SPU_PTHREAD_IDLE;
      }
      pthread_mutex_unlock(&spe_thread->lock);
    }
    else if(spe_thread->state == _ALF_SPU_PTHREAD_EXITING) break;
  } while (1); 
  // done - now exit thread
  _ALF_API_STD_COND_SIG(spe_thread->lock,spe_thread->cond,spe_thread->state = _ALF_SPU_PTHREAD_EXITED);
  pthread_exit(NULL);

}

int
_alf_pal_spu_pthread_create(alf_pal_thread_t* thread_handle )
{
    int ret = 0;
    alf_spe_thread* spe_thread=&thread_handle->data.spe_thread;

    thread_handle->data.id = 0L;
    
    spe_thread->argp = thread_handle;
    spe_thread->envp = NULL;
    ret = pthread_mutex_init(&spe_thread->lock,NULL); 
    if(ret != 0)
      goto RET;
 
    ret = pthread_cond_init(&spe_thread->cond,NULL); 
    if(ret != 0)
      goto RET;

    spe_thread->state = _ALF_SPU_PTHREAD_IDLE;
    _ALF_SYNC_MEMORY();
    ret = pthread_create(&thread_handle->data.id,
                         NULL, &_alf_spe_pthread, spe_thread);

RET:
    return ret; 
}
void
_alf_pal_spu_pthread_destroy(alf_pal_descriptor_t* p_alf_pal_desc,
                            int i)
{
    alf_spe_thread* spe_thread;
    spe_thread = &(_ALF_GET_SPU_SLOT(p_alf_pal_desc, i).spe_thread);
    pthread_t id =_ALF_GET_SPU_SLOT(p_alf_pal_desc, i).id;

    pthread_mutex_destroy(&spe_thread->lock); 
    pthread_cond_destroy(&spe_thread->cond); 
    if(id !=0)
    {
      pthread_cancel(id);
      pthread_join(id,NULL);
    }
      
    return;
}
/**
 * Spu thread create routine.
 *   This function creates spe thread and initilize the spu slot.
 */
int
_alf_pal_spu_thread_create(alf_pal_handle platform_handle,
                           alf_pal_thread_t * thread_handle, spe_program_handle_t * handle)
{
  int ret = 0;
  alf_spe_thread *spe_thread;

 /**
  Make sure that the compiler will not 'optimize' the queue addresss 
  some bugs have been found about it in PPC native compiling enviorment
 */
  volatile alf_aal_spu_instance_t *volatile spu_instance;
  spu_instance = &thread_handle->data.spu_instance;

  thread_handle->data.state = _ALF_SPU_SLOT_ACTIVE;
  
  if(thread_handle->data.id == 0L)
  {
    ret = _alf_pal_spu_pthread_create(thread_handle);
    if( ret != 0)
    {
      goto RET;
    }
  }

  /**
     Make sure that the spu can access the queue address 
     when libspe help to load it as a "parameter" for main routine entry
  */

  spe_thread = &thread_handle->data.spe_thread;
  spe_thread->handle = handle; 
  _ALF_SYNC_MEMORY();

  _ALF_API_STD_COND_SIG(spe_thread->lock,spe_thread->cond,spe_thread->state = _ALF_SPU_PTHREAD_ACTIVE);
  thread_handle->data.alf_pal_desc_ptr = platform_handle;
  thread_handle->data.state = _ALF_SPU_SLOT_ACTIVE;

RET:
  if (ret != 0) {
    thread_handle->data.state = _ALF_SPU_SLOT_UNUSED;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Create accelerator error\n");
  }
  return ret;
}


/**
 * Destroy all PAL threads 
 */
void _alf_pal_spu_threads_destroy(alf_pal_descriptor_t * p_alf_pal_desc)
{
  int i;
  pthread_t spe_id;
  alf_spe_thread* spe_thread; 

  int acces = p_alf_pal_desc->acces;

  for (i = 0; i < acces; ++i) {

    spe_id = _ALF_GET_SPU_SLOT(p_alf_pal_desc, i).id;
    spe_thread = &(_ALF_GET_SPU_SLOT(p_alf_pal_desc, i).spe_thread);

    if (alf_likely(spe_id != 0L)) {
      _ALF_API_STD_COND_SIG(spe_thread->lock,spe_thread->cond,spe_thread->state = _ALF_SPU_PTHREAD_EXITING);

      pthread_join(spe_id, NULL);
      _ALF_GET_SPU_SLOT(p_alf_pal_desc, i).id = 0L;
      _ALF_GET_SPU_SLOT(p_alf_pal_desc, i).state = _ALF_SPU_SLOT_UNUSED;
    }
  }

  ALF_DUMP_SPU_PROF(p_alf_pal_desc);

  p_alf_pal_desc->spe_running = 0;
  
}


/**
 * Destroy one PAL thread 
 */
void _alf_pal_spu_thread_destroy(alf_pal_thread_t * p_alf_pal_thread)
{
  pthread_t spe_id;
  alf_spe_thread* spe_thread; 
  int ret;
 
  spe_id = p_alf_pal_thread->data.id;
  spe_thread = &p_alf_pal_thread->data.spe_thread;

  if (alf_likely(spe_id != 0L)) {
    ret = _alf_pal_spu_pthread_wait(spe_thread);  
    /* If time out, maybe spe thread is in a infinite loop, so cancel it */
    if(ret != 0) {
      pthread_cancel(spe_id);
      pthread_join(spe_id,NULL);
      p_alf_pal_thread->data.id = 0L;
    }
    
    p_alf_pal_thread->data.state = _ALF_SPU_SLOT_UNUSED;
  }

  ALF_DUMP_SINGLE_SPU_PROF(p_alf_pal_thread->data.spu_instance.id, 
                           &p_alf_pal_thread->data.spu_prof);
}

/**
 * Deinit all the spe related resources.
 */
void _alf_pal_deinit_spes(alf_pal_descriptor_t * p_alf_pal_desc)
{
  int i;
  int acces = p_alf_pal_desc->acces;

  for (i = 0; i < acces; ++i) {
    spe_context_destroy(_ALF_GET_SPU_SLOT(p_alf_pal_desc, i).spe_thread.spe_context);
  }

  if (p_alf_pal_desc->threads) {
    free_align(p_alf_pal_desc->threads);
    p_alf_pal_desc->threads = NULL;
  }

}

/**
 * Get the total work block processing packet number in the packet queue
 */
inline int _alf_pal_wb_req_entries(alf_pal_thread_t * thread_handle)
{
  volatile alf_aal_pkt_queue_t *pkt_queue;
  alf_aal_pkt_t *pkt = NULL;
  int start, end;
  int i;
  int pending_wbs = 0;

  pkt_queue = &thread_handle->data.pkt_queue;

  start = pkt_queue->spu_info.front;
  end = pkt_queue->ppu_info.rear;


  for (i = start; i != end; i = (i + 1) % ALF_AAL_PKT_QLEN) {

    pkt = &pkt_queue->pkts[i];
    if (pkt->type == ALF_AAL_PKT_WBH)
      pending_wbs++;
  }

  return pending_wbs;
}


/**
 * Get the free entries number in the packet queue
 */
inline int _alf_pal_req_queue_free_entries(alf_pal_thread_t * thread_handle)
{
  alf_aal_pkt_queue_t *pkt_queue;
  int free_entries;
  int used_entries;

  pkt_queue = &thread_handle->data.pkt_queue;
  used_entries = (pkt_queue->ppu_info.rear - pkt_queue->spu_info.front + ALF_AAL_PKT_QLEN) % ALF_AAL_PKT_QLEN;

  free_entries = ALF_AAL_PKT_QLEN - used_entries - 1;

  return free_entries;
}


void _alf_pal_wb_init(alf_pal_thread_t *thread_handle __attribute__ ((unused)),alf_pal_wb_t* wb)
{
      alf_aal_wbh_t *aal_wbh = (alf_aal_wbh_t *)wb->pal_resv;
      alf_pal_wb_host_data_t *hostdata=&wb->hostdata; 

      aal_wbh->status = _ALF_WORK_BLOCK_STATUS_INIT;
      aal_wbh->loop_num = hostdata->total_count;
      aal_wbh->udata_size = hostdata->parm_size;

#if 0
      if(!thread_handle->data.task_info.task_attr) {
        //dtl_grp_handle point to the begin address of alf_data_transfer_into_t
        PTR_TO_ADDR64(wb->hostdata.dtl_grp, aal_wbh->input_dtl_ea);
      }
      _alf_pal_io_type_combine(hostdata);
#endif

}

/**
 * Packet init routine
 *   Init all types of packet here 
 */
int _alf_pal_pkt_init(alf_pal_thread_t * thread_handle,
                          alf_aal_pkt_t * pkt_ptr,
                          alf_pal_wb_t * wb, alf_data_addr64_t context_to_set,
                          alf_data_addr64_t context_to_get, alf_data_addr64_t context_to_merge, int type)
{
  switch (type) {
  case ALF_AAL_PKT_WBH:
  {
      alf_aal_wb_pkt_t *wbh_pkt;
      alf_aal_wbh_t *wbh = (alf_aal_wbh_t *)wb->pal_resv;
      wbh_pkt = (alf_aal_wb_pkt_t *) pkt_ptr;

      wbh_pkt->loop_num = wb->hostdata.total_count;
      wbh_pkt->udata_size = wb->hostdata.parm_size + sizeof(alf_aal_wbh_t);
      PTR_TO_ADDR64(wb->pal_resv, wbh_pkt->udata_ea);
      wbh_pkt->input_dtl_ea = wbh->input_dtl_ea;
      wbh_pkt->input_dtl_size = wbh->input_dtl_size;
      

#if 0
      //FIXME 
      //input_dtl_size = ;

      if(!thread_handle->data.task_info.task_attr) {
        //dtl_grp_handle point to the begin address of alf_data_transfer_into_t
        PTR_TO_ADDR64(wb->hostdata.dtl_grp, wbh_pkt->input_dtl_ea);
      }
#endif      
      pkt_ptr->type = type;
    }
    break;

  case ALF_AAL_PKT_CTX_SWAP:
    {
      alf_aal_task_ctx_pkt_t *ctx_req = (alf_aal_task_ctx_pkt_t *) pkt_ptr;
      if ((context_to_set == 0ll) && (context_to_get == 0ll))
        return -ALF_ERR_BADF;

      ctx_req->in_buf_ea = context_to_set;
      ctx_req->out_buf_ea = context_to_get;

      pkt_ptr->type = type;
    }

    break;

  case ALF_AAL_PKT_CTX_MERGE:
    {
      alf_aal_task_ctx_pkt_t *ctx_req = (alf_aal_task_ctx_pkt_t *) pkt_ptr;
      if (context_to_merge == 0ll)
        return -ALF_ERR_BADF;

      ctx_req->in_buf_ea = context_to_merge;

      pkt_ptr->type = type;
    }

    break;

  case ALF_AAL_PKT_TASK_SETUP:
    {
      PTR_TO_ADDR64(&thread_handle->data.task_info,pkt_ptr->task_info_ea);
      pkt_ptr->type = type;
    }

    break;

  default:
    return -ALF_ERR_GENERIC;
    break;
  }

  return 0;
}


/**
 * Symbol name to address, used when thread reset, when reset, we only 
 * need translate the symbol name again, because maybe kernel changed
 */
int _alf_pal_symname_to_addr(void *lib_handle, alf_task_info_t *p_tinfo, 
                             alf_pal_task_info_t *task_info)
{
  char *error;
  int i;

  /**
   * Find the symbol address, max api number in each kernel is
   *  ALF_API_KERNEL_NUM
   */
  for(i=0; i<ALF_API_KERNEL_NUM; i++) {
    if(task_info->api_str[i][0]) {
      char api_str[2 * ALF_STRING_TOKEN_MAX + 2];
      strcpy(api_str, task_info->api_str[ALF_API_KERNEL_IMAGE]);
      strcat(api_str, "_");
      strcat(api_str, task_info->api_str[i]);
      api_str[2*ALF_STRING_TOKEN_MAX + 1] = 0;

      _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "unsigned int *val = (unsigned int *) dlsym(lib_handle, \"%s\")\n",api_str);
      unsigned int *val = (unsigned int *) dlsym(lib_handle, api_str);
      if((error = dlerror()) != NULL)
      {
        return -ALF_ERR_NOEXEC;
      }
      p_tinfo->api_addrs[i] = *val;

    }
    else
      p_tinfo->api_addrs[i] = 0;
  }

  /* Comp kernel could not be null, this is not allowed */
  if(p_tinfo->api_addrs[ALF_API_KERNEL_COMP_KERNEL] == 0)
  {
    return -ALF_ERR_NOEXEC;
  }

  return 0;
}

 
/**
 * Symbol name to address  
 */
int _alf_pal_dlsym(char *single_path, alf_pal_task_info_t *task_info)
{
  spe_program_handle_t *spe_task_image;
  char fname[2 * ALF_STRING_TOKEN_MAX + 2] = { 0 };
  char* filename = fname;
  void *lib_handle;
  alf_pal_sym_info_t *p_sym;
  char *error;
  int ret, i;

  /* Check if dynamic library opened by other thread, if so no need to redo such thing */
  if (task_info->p_arch_tinfo != NULL ) 
  {
    if(task_info->size_of_arch_tinfo != sizeof(alf_pal_sym_info_t))
    { 
      _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Library previously opened, but sizeof task info (%d) != sizeof alf_pal_sym_info_t (%ld)",task_info->size_of_arch_tinfo,(unsigned long)sizeof(alf_pal_sym_info_t));
      return -ALF_ERR_NOEXEC;
    }
    else
    {
      return 0;
    }
  }


  /* First open the dynamic library 
   *  (1) open the dynamcic library, find the spe image
   *  (2) find the symbol address in this image 
   */
  if ( task_info->api_str[ALF_API_KERNEL_LIBRARY][0] )
  {
    //If the path is not empty, prepend it to the library name
    if (strlen(single_path)) {
      strcpy(fname, single_path);
      strcat(fname, "/");
      strcat(fname, task_info->api_str[ALF_API_KERNEL_LIBRARY]);
      fname[2*ALF_STRING_TOKEN_MAX +1] = 0;
    }
    else { //just copy the library name, this allows LD_LIBRARY_PATH to be searched
      strcpy(fname, task_info->api_str[ALF_API_KERNEL_LIBRARY]);
      fname[2*ALF_STRING_TOKEN_MAX +1] = 0;
    }
  }
  else
  {
    filename = NULL;
    strcpy ( fname, "<SELF>" );
  }
  _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "lib_handle = dlopen(\"%s\", RTLD_LOCAL | RTLD_NODELETE | RTLD_NOW)\n",fname);
  lib_handle = dlopen(filename, RTLD_LOCAL | RTLD_NODELETE | RTLD_NOW);
  if (lib_handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Failed to open %s, native error: %s\n", fname, dlerror());
    return -ALF_ERR_NOEXEC;
  }

  spe_task_image = dlsym(lib_handle, task_info->api_str[ALF_API_KERNEL_IMAGE]);
  if (spe_task_image == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid task info handle: %s, native error: %s\n",task_info->api_str[ALF_API_KERNEL_IMAGE], dlerror());
    dlclose(lib_handle);
    return -ALF_ERR_NOEXEC;
  }

  p_sym = malloc(sizeof(alf_pal_sym_info_t));
  if(p_sym == NULL) 
  {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Failed to allocate memory\n");
    return -ALF_ERR_NOMEM;
  }


  /**
   * Find the symbol address, max api number in each kernel is 
   *  ALF_API_KERNEL_NUM
   */
  for(i=0; i<ALF_API_KERNEL_NUM; i++) {
    if(task_info->api_str[i][0]) {
      char api_str[2 * ALF_STRING_TOKEN_MAX + 2];
      strcpy(api_str, task_info->api_str[ALF_API_KERNEL_IMAGE]);
      strcat(api_str, "_");
      strcat(api_str, task_info->api_str[i]);
      api_str[2*ALF_STRING_TOKEN_MAX + 1] = 0;

      _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "unsigned int *val = (unsigned int *) dlsym(lib_handle, \"%s\")\n",api_str);
      unsigned int *val = (unsigned int *) dlsym(lib_handle, api_str);
      if((error = dlerror()) != NULL)
      {
	_ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Failed to locate function: %s, native error: %s\n",api_str, error);
        ret = -ALF_ERR_NOEXEC;
        goto ERR;
      }
      p_sym->api_addrs[i] = *val;

    }
    else
      p_sym->api_addrs[i] = 0;
  }

  /* Comp kernel could not be null, this is not allowed */
  if(p_sym->api_addrs[ALF_API_KERNEL_COMP_KERNEL] == 0)
  {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "NULL computation kernel not allowed\n");
    ret = -ALF_ERR_NOEXEC;
    goto ERR;
  }

  p_sym->spe_task_image = spe_task_image;
  p_sym->lib_handle = lib_handle;
  task_info->p_arch_tinfo = p_sym;
  task_info->size_of_arch_tinfo = sizeof(alf_pal_sym_info_t);

  return 0;

ERR:
  free(p_sym);
  task_info->size_of_arch_tinfo = 0;
  return ret;
}


void _alf_report_invalid_dma()
{
  _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid DMA\n");
}


/**
 * ALF PAL runtime handle checking routine.
 */
int _alf_pal_check_handle(alf_pal_descriptor_t * p_alf_pal_desc)
{
  if (!ALF_VALID_HANDLE(p_alf_pal_desc)) {
    return -EBADF;
  }

  if (p_alf_pal_desc->magic_id != _ALF_HANDLE_T_MAGIC_ID) {
    return -EBADF;
  }

  return 0;
}

/**
  * spe error callback handler
  */
int alf_spe_error_callback(char *ls_base, unsigned ls_address)
{
	unsigned arg = *(unsigned int *)(ls_base + ls_address);
  unsigned long long instance_ea = *(unsigned long long *)(ls_base + arg);
  alf_aal_spu_instance_t *instance_handle;
  
  ADDR64_TO_PTR(instance_ea, alf_aal_spu_instance_t *, instance_handle);

	/* Set values into the error structure for SYNC error case */
	alf_error_msg *errs;
	ADDR64_TO_PTR(instance_handle->error_ea, alf_error_msg *, errs);
	errs->error_reason = 0; // ALF ERROR CALLBACK
	errs->error_sub_reason = -1;  // ALF SYNC ERROR

  /* call common helper fcn. */
  alf_spe_error_callback_helper(instance_handle);
  return 0;
}

/**
 * spe error callback helper fcn.
 */
void alf_spe_error_callback_helper(alf_aal_spu_instance_t *instance_handle)
{
  // FIXME: If you can find a better way, please fix this. 
  // This UGLY CAST works because spe_instance is the first member in the ALF PAL thread structure
  // After much thought this was the best we could do. 
  // We need this to get the task info structure for error purposes.
  alf_pal_thread_t *thread_handle = (alf_pal_thread_t *)instance_handle; 
  alf_task_info_t *task_info = &thread_handle->data.task_info;
  
  alf_error_msg *errs;
  ADDR64_TO_PTR(instance_handle->error_ea, alf_error_msg *, errs);
 
 	// fill out common error fields
  errs->error_spu_vid = instance_handle->id;
  errs->error_spu_vid_max = task_info->accels;

#ifdef _ALF_PLATFORM_HYBRID_
  extern int alf_accel_error_receiver_remote(alf_data_addr64_t thread_ea);
 
  alf_accel_error_receiver_remote(instance_handle->thread_ea);
#else
  alf_pal_descriptor_t *p_alf_pal_desc = NULL;
  ALF_ERR_POLICY_T err;
  void* task_handle;
  char error_string[ALF_STRING_TOKEN_MAX];
  
  ADDR64_TO_PTR(thread_handle->data.task_info.task_handle_ea, void*, task_handle);
  
  p_alf_pal_desc = thread_handle->data.alf_pal_desc_ptr;
  if((thread_handle->data.error_handle.error_code != 0) && 
                (p_alf_pal_desc->err_handler != NULL)) {
                	
     /* Prepare error string */
     snprintf(error_string, ALF_STRING_TOKEN_MAX, "task_handle: %p, instance_id: %d, number_of_instances: %d, extra error code: 0x%08x, error reason: 0x%08x, error sub reason: 0x%08x",
     					task_handle, errs->error_spu_vid, errs->error_spu_vid_max, errs->extra_error_code, errs->error_reason, errs->error_sub_reason);
     
     /* Invoke error handler */
     err = p_alf_pal_desc->err_handler(p_alf_pal_desc->err_handler_ctx,
                      task_handle, 
                      errs->error_type,
                      errs->error_code,
                      error_string);
                      
    //Change the error state of the thread in the abort case so that thread_wait can return an error
    if (err == ALF_ERR_POLICY_ABORT) {
      thread_handle->data.thread_error = -ALF_ERR_GENERIC;
    }
    
    errs->error_handle_policy = err;
    errs->error_code = 0;
  }
#endif
}

char* alf_lib_path_split(alf_lib_path_iter_t* lib_path)
{
  while(1)
  { 
    if(lib_path->config[lib_path->end] != '\0' && lib_path->config[lib_path->end] != ':')
    {
        lib_path->end++;
    }
    else
    {
        //first or last char is colon or two consecutive colon
        if(lib_path->end - lib_path->start <= 0)
        {
          if(lib_path->config[lib_path->end] == '\0')
            return NULL;
          else 
          {
            lib_path->end++;
            lib_path->start = lib_path->end;
            continue;
          }
        }
        if(lib_path->end - lib_path->start > ALF_STRING_TOKEN_MAX)
          return NULL; 
        strncpy(lib_path->single_path, &lib_path->config[lib_path->start], lib_path->end - lib_path->start);
        lib_path->single_path[lib_path->end - lib_path->start] = 0;
        if(lib_path->config[lib_path->end] != '\0')
          lib_path->end++;
        lib_path->start = lib_path->end;
        return lib_path->single_path;
    }
  }

  return lib_path->single_path;
}

int alf_pal_task_info_check_compat(char *single_path, alf_pal_task_info_t *task_info) 
{
  spe_program_handle_t *spe_task_image;
  void *lib_handle;
  int* alf_runtime_aal_version, *alf_runtime_platform, *alf_runtime_tasktype;
  char fname[2 * ALF_STRING_TOKEN_MAX + 2] = {0};  /* temporary usage */
  char* filename = fname;



  if ( task_info->api_str[ALF_API_KERNEL_LIBRARY][0] )
  {
    /* dlopen .so accelerator binary */
    if ((strlen(single_path) + strlen(task_info->api_str[ALF_API_KERNEL_LIBRARY])) >
        (2 * ALF_STRING_TOKEN_MAX))                           /* check string length */
        return -ALF_ERR_BADR;

    /* dlopen .so accelerator binary */
    //if ALF_LIBRARY_PATH is set to an empty string, do not concatenate "/" to the filename
    //as a result, dlopen will search LD_LIBRARY_PATH
    if(strlen(single_path))
    {
      strcpy(fname, single_path);
      strcat(fname, "/");
    }
    strcat(fname, task_info->api_str[ALF_API_KERNEL_LIBRARY]);
    fname[2*ALF_STRING_TOKEN_MAX + 1] = 0;
  }
  else
  {
    filename = NULL;
    strcpy ( fname, "<SELF>" );
  }
  _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "lib_handle = dlopen(\"%s\", RTLD_LOCAL | RTLD_NODELETE | RTLD_NOW)\n", fname);
  lib_handle = dlopen(filename, RTLD_LOCAL | RTLD_NODELETE | RTLD_NOW);
  if (lib_handle == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Failed to open %s, native error: %s\n", fname, dlerror());
    return -ALF_ERR_NOEXEC;
  }

  /* dlsym spe_program_handle symbol */
  spe_task_image = dlsym(lib_handle,task_info->api_str[ALF_API_KERNEL_IMAGE]);
  if (spe_task_image == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Invalid task info handle: %s, native error: %s\n", task_info->api_str[ALF_API_KERNEL_IMAGE], dlerror());
    dlclose(lib_handle);
    return -ALF_ERR_NOEXEC;
  }

  /* AAL symbol check */  
  strcpy(fname, task_info->api_str[ALF_API_KERNEL_IMAGE]);
  strcat(fname, "_");
  strcat(fname, "version");
  alf_runtime_aal_version = dlsym(lib_handle, fname);
  
  if (alf_runtime_aal_version == NULL || GEN_HOST_ALF_AAL_VERSION != *alf_runtime_aal_version ) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Accelerator version is null or current version %d does not match accelerator version %d\n", GEN_HOST_ALF_AAL_VERSION, *alf_runtime_aal_version);
    dlclose(lib_handle);
    return -ALF_ERR_INCOMPAT;
  }

  /* Task type symbol check */
  strcpy(fname, task_info->api_str[ALF_API_KERNEL_IMAGE]);
  strcat(fname, "_");
  strcat(fname, "tasktype");
  alf_runtime_tasktype = dlsym(lib_handle, fname);
  
  if (alf_runtime_tasktype == NULL || task_info->task_type != (unsigned int)(*alf_runtime_tasktype) ) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Accelerator task type is null or current task type %d does not match accelerator task type %d\n", task_info->task_type, *alf_runtime_tasktype);
    dlclose(lib_handle);
    return -ALF_ERR_INCOMPAT;
  }

  /* Platform symbol check */
  strcpy(fname, task_info->api_str[ALF_API_KERNEL_IMAGE]);
  strcat(fname, "_");
  strcat(fname, "platform");
  alf_runtime_platform = dlsym(lib_handle, fname);

  if (alf_runtime_platform == NULL || GEN_HOST_ALF_PLATFORM_TYPE != *alf_runtime_platform ) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Accelerator platform type is null or current platform type %d does not match accelerator platform type %d\n", GEN_HOST_ALF_PLATFORM_TYPE, *alf_runtime_platform);
    dlclose(lib_handle);
    return -ALF_ERR_INCOMPAT;
  }
  
#ifdef _ALF_PLATFORM_HYBRID_
  return 0;
#else

  /* Cell version ONLY
 *    * Record user defined SPE function address */
  alf_pal_sym_info_t *p_sym;
  char *error;
  int i;
  int ret;

  /* _alf_pal_dlsym */
  p_sym = malloc(sizeof(alf_pal_sym_info_t));
  if(p_sym == NULL)
  {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Failed to allocate memory\n");
    return -ALF_ERR_NOMEM;
  }
  for(i=0; i<ALF_API_KERNEL_NUM; i++) {
    if(task_info->api_str[i][0]) {
      char api_str[2 * ALF_STRING_TOKEN_MAX + 2];
      
      if ((strlen(task_info->api_str[ALF_API_KERNEL_IMAGE]) + strlen(task_info->api_str[i])) >
          2 * ALF_STRING_TOKEN_MAX ) {
        ret = -ALF_ERR_BADR;
        goto ERR;
      }
      
      strcpy(api_str, task_info->api_str[ALF_API_KERNEL_IMAGE]);
      strcat(api_str, "_");
      strcat(api_str, task_info->api_str[i]);
      api_str[2*ALF_STRING_TOKEN_MAX + 1] = 0;

      _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "unsigned int *val = (unsigned int *) dlsym(lib_handle, \"%s\")\n",api_str);
      unsigned int *val = (unsigned int *) dlsym(lib_handle, api_str);
      if((error = dlerror()) != NULL)
      {
        _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "Failed to locate function: %s, native error: %s\n",api_str, error);
        ret = -ALF_ERR_NOEXEC;
        goto ERR;
      }
      p_sym->api_addrs[i] = *val;

    }
    else
      p_sym->api_addrs[i] = 0;
  }

  /* Comp kernel could not be null, this is not allowed */
  if(p_sym->api_addrs[ALF_API_KERNEL_COMP_KERNEL] == 0)
  {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_FATAL_, "NULL computation kernel not allowed\n");
    ret = -ALF_ERR_NOEXEC;
    goto ERR;
  }

  p_sym->spe_task_image = spe_task_image;
  p_sym->lib_handle = lib_handle;
  task_info->p_arch_tinfo = p_sym;
  task_info->size_of_arch_tinfo = sizeof(alf_pal_sym_info_t);
  dlclose(lib_handle);

  return 0;

ERR:
  free(p_sym);
  task_info->size_of_arch_tinfo = 0;
  return ret;
#endif
}
