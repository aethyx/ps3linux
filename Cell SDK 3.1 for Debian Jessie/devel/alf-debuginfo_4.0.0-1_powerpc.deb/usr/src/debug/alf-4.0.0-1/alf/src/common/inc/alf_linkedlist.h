/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef ALF_LINKEDLIST_H_
#define ALF_LINKEDLIST_H_

#include <pthread.h>
#include "alf_config.h"
#include "alf_common.h"

//********************************************************
// Data Structures
//********************************************************

/*
 * this data structure represents a block for the single user allocator
 */
typedef struct alf_single_block {
  struct alf_single_block *next;
  struct alf_single_block *prev;
  void *data;
} alf_linkedlist_element_t;

/**
 * this data structure represents a list of alf_single_block*
 */
typedef struct alf_block_list {
  pthread_mutex_t lock;
  alf_linkedlist_element_t *first;
  alf_linkedlist_element_t *last;
  unsigned int count;
#ifdef _ALF_64B_
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
} alf_linkedlist_t;

//********************************************************
// APIs
//********************************************************

/**
 * Linkedlist create routine.
 *
 * This function creates an linkedlist.
 *
 * Parameters:
 * None.
 * 
 * Return Values:
 * The address of the resulting linkedlist is returned.
 */

alf_linkedlist_t *alf_linkedlist_create();

/**
 * Linkedlist enqueue on the end routine.
 *
 * This function adds a data element into the end of the linkedlist, and returns
 * the data element after insertion.
 *
 * Parameters:
 * ll[IN]: Pointer to a linkedlist.
 * d[IN]: Pointer to data element which needed to be enqueued.
 *
 * Return Values:
 * Pointer to data element which needed to be enqueued. NULL is returned if any errors are encountered
 *
 */

void *alf_linkedlist_enqueue(alf_linkedlist_t * ll, void *d);

/**
 * Linkedlist dequeue from the front routine.
 *
 * This function remove the first data element from linkedlist, and return it.
 *
 * Parameter:
 * ll[IN]: Pointer to the linkedlist.
 *
 * Return Values:
 * Effective address of the first data element. NULL is returned if the is empty.
 *
 */

void *alf_linkedlist_dequeue(alf_linkedlist_t * ll);

/**
 * Linkedlist dequeue from the end routine.
 *
 * This function remove the last data element from linkedlist, and return it.
 *
 * Parameter:
 * ll[IN]: Pointer to the linkedlist.
 *
 * Return Values:
 * Effective address of the last data element. NULL is returned if the linkedlist is empty.
 *
 */

void *alf_linkedlist_dequeue_from_end(alf_linkedlist_t * ll);

/**
 * Linkedlist remove data element routine.
 * 
 * This function removes a data element from the linkedlist, and returns it.
 * 
 * Parameter:
 * ll[IN]: Pointer to the arraylist
 * data: Pointer to the data element to be removed
 * 
 * Return Values:
 * Effective address of the data element that was removed. NULL is returned if the data element is not found in the arraylist.
 * 
 */

void *alf_linkedlist_remove(alf_linkedlist_t * ll, void *data);

/** 
 * Linkedlist get data element routine
 *
 * This function gets the data element from the linkedlist at a specific index and returns it.
 *
 * Parameters:
 * ll[IN]: Pointer of the linkedlist.
 * index[IN]: Index for the expected data element from 0 to capacity-1.
 *
 * Return Value:
 * Effective for the expected data element. NULL is returned if any errors are encountered.
 */

void *alf_linkedlist_get_element(alf_linkedlist_t * ll, unsigned int index);

/**
 * Linkedlist get length routine
 *
 * This function return the length of the linkedlist, that is, the current number of elements in the linkedlist.
 *
 * Parameters:
 * ll[IN]: Pointer to the linkedlist.
 *
 * Return Values:
 * Length of the linkedlist.
 */

unsigned int alf_linkedlist_get_length(alf_linkedlist_t * ll);

/**
 * Linkedlist query if empty routine.
 *
 * This function checks whether the linkedlist is empty.
 *
 * Parameters:
 * ll[IN]: Pointer to the arraylist.
 *
 * Return Values:
 * ==1 Linkedlist is empty. 
 * ==0 Linkedlist is not empty.
 */

int alf_linkedlist_is_empty(alf_linkedlist_t * ll);

/**
 * Linkedlist query if full routine.
 *
 * This function checks whether the linkedlist is full.
 *
 * Parameters:
 *   ll[IN]: Pointer to the linkedlist.
 *
 * Return Values:
 * ==1 Linkedlist is full. 
 * ==0 Linkedlist is not full.
 */

int alf_linkedlist_is_full(alf_linkedlist_t * ll);

/**
 * Linkedlist contains data element routine.
 * 
 * This function queries if an data element is contained in the linkedlist.
 * 
 * Parameter:
 * ll[IN]: Pointer to the linkedlist
 * data[IN]: Pointer to the data element to be queried
 * 
 * Return Values:
 * ==1 Linkedlist contains the data element 
 * ==0 Linkedlist does not contains the data element 
 */

int alf_linkedlist_contains(alf_linkedlist_t * ll, void *data);

/**
 * Linkedlist print routine.
 *
 * This function prints the internal contents of the linkedlist.
 *
 * Parameters:
 *   ll[IN]: Pointer to the linkedlist.
 *
 * Return Values:
 * None.
 */

void alf_linkedlist_print(alf_linkedlist_t * ll);

/**
 * Linkedlist destroy routine.
 *
 * This function free the resouces allocated for linkedlist.
 *
 * Parameters:
 * ll[IN]: Pointer to the linkedlist.
 *
 * Return Values:
 * None.
 */

void alf_linkedlist_destroy(alf_linkedlist_t * ll);

/**
 * Linkedlist unlink routine.
 *
 * This function unlinks the list element from the linkedlist.
 *
 * Parameters:
 * ll[IN]: Pointer to the linkedlist.
 * e[IN]: Pointer to the linkedlist element.
 *
 * Return Values:
 * Pointer to the linkedlist element.
 */

alf_linkedlist_element_t *alf_linkedlist_unlink(alf_linkedlist_t * ll, alf_linkedlist_element_t * e);

#endif /* ALF_LINKEDLIST_H_ */
