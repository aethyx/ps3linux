/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef __ALF_PAL_H_INC__
#define __ALF_PAL_H_INC__

/*
 * The Platform Abstraction Layer (PAL) for ALF
 */

/* commonly shared ALF headers, included here just in case you missed that */
#include <alf_config.h>
#include <alf_def.h>
#include <alf.h>

#include "alf_common.h"
#include "alf_misc.h"

typedef void *alf_pal_handle;
typedef void *alf_pal_config_handle;
typedef void *alf_pal_thread_handle;
typedef unsigned int alf_pal_dtl_handle;
typedef void *alf_pal_dtl_group_handle;
typedef void *alf_pal_dataset_handle;


#define ALF_PAL_MAX_DTL_NUM_ENTRY ALF_PAL_WB_MAX_DTL_NUM * 2 * 1024 /* maximum number of DTL entry for one wb */
#define ALF_PAL_WB_HOST_PRIV_DATA_SIZE 64    /* size of private data for host layer */


#ifdef _ALF_PLATFORM_CELL_
#define ALF_PAL_WB_MAX_DTL_NUM	8     /* the maximum number of DTLs for each kind of I/O */
#define ALF_PAL_WB_PRIV_DATA_SIZE     128       /* the size of private PAL work block header area in unit of 4 bytes */
#define ALF_PAL_DATA_ALIGN_REQ 4
#else // hybrid or others
#define ALF_PAL_WB_MAX_DTL_NUM	8      /* the maximum number of DTLs for each kind of I/O */
#define ALF_PAL_WB_PRIV_DATA_SIZE     128       /* the size of private PAL work block header area in unit of 4 bytes */
#define ALF_PAL_DATA_ALIGN_REQ 4
#endif


#define ALF_PAL_DATA_SIZE_ALIGN(data_size) _ALF_SIZE_ALIGN_(data_size,ALF_PAL_DATA_ALIGN_REQ)



/* the DT list description data structure */
/*  it is structured like a link list as: */
/*  header[0] { num_entries = NUM0, ¡­}  */
/*     entry[0],  ¡­, entry[NUM0 - 1]  */
/*  header[1] { num_entries = NUM1, ¡­}  */
/*     entry[0],  ¡­, entry[NUM1 - 1]  */
/*  header[1] { num_entries = NUM2, ¡­}  */
/*     entry[0],  ¡­, entry[NUM2 - 1]  */
/*  header[N] { num_entries = 0, ¡­}   END of LIST  */


// the PAL layer abstract model for the work block DT list
typedef struct _alf_pal_dtlist_t_
{
  union 
  {
    struct alf_pal_dtlist_header    // the header
    {
        unsigned int num_entries;  // number of entries in this DT list section
        ALF_BUF_TYPE_T buffer_type;  // buffer type
        alf_data_uint64_t local_offset;  // offset in local buffer
    } header;
    struct alf_pal_dtlist_entry   // the real entries
    {
        unsigned int size;               // size of this entry 
        ALF_DATA_TYPE_T data_type;  // data type    
        alf_data_addr64_t address;        // global address
    } entry;
  };
} alf_pal_dtlist_t;


/* the thread context data structure as understandable by the PAL layer */
typedef struct _alf_pal_data_entry_desc_t_ {
  unsigned int size;            // size of the entry
  ALF_DATA_TYPE_T data_type;    // type of the entry
} alf_pal_data_entry_desc_t;


typedef enum _ALF_PAL_TASK_ATTR_T_ {
  ALF_PAL_TASK_ATTR_PARTITION_ON_ACCEL = 0x80000000,    // partition on accelerator
} ALF_PAL_TASK_ATTR_T;

/* the task info data stucture for the PAL layer */
typedef struct _alf_pal_task_info_t_ {
  /* platform dependent task info */
  alf_data_addr64_t task_handle_ea; // effective address of task handle
  alf_data_addr64_t context_to_set; // effective address of task context
  ALF_TASK_TYPE_T task_type;        // task type
  unsigned int accels;
  unsigned int *vtol_id_map;        // virtual to logic id mapping table
  
  
  void *p_arch_tinfo;           // we may want to make a copy of the p_arch_task_info as

  unsigned int size_of_arch_tinfo;      // passed in by the host API, so we need to know the size too
#ifdef _ALF_64B_
  char pad2[4];
#endif

  /* below is shared task info between API and PAL */


  // description of task context data structure
  alf_pal_data_entry_desc_t *context_desc;      // description of the context size
  void *_pad;
  unsigned int context_desc_num;        // description of the context size
#ifdef _ALF_64B_
  char pad3[4];
#endif

  unsigned int task_attr;       // an bit wise OR of ALF_PAL_TASK_ATTR_T
  // do we have a method to eliminate the following fields in the future ?
  unsigned int task_context_size;       // the max size of the task context buffer
  unsigned int parm_ctx_buffer_size;    // the max size of parameter and temp buffer for work blocks
  unsigned int input_buffer_size;       // the max size of the input only buffer
  unsigned int output_buffer_size;      // the max size of the output only buffer
  unsigned int overlapped_buffer_size;  // the max size of the input and output buffer

  //TBD,  the following fields should better be put into the p_arch_task_info
  unsigned int stack_size;      // the stack size for accel
  unsigned int dt_list_entries; // the maximum possible size of DT list, accel side partition prefers to have this
  unsigned int dt_list_num;     // the maximum number of dt lists

  // Fixme: multiple kernel info should be included here
  // TODO:  as above
  char api_str[ALF_API_KERNEL_INDEX_NUM][ALF_STRING_TOKEN_MAX+1];
  
} alf_pal_task_info_t;






// Please note that not all of these states are intended to be reliable marks of the  
// current status of the work block
// TBD: are we still need this ?
typedef enum _ALF_PAL_WB_STATUS_T_ {
  ALF_PAL_WB_STATUS_FINISHED = 0,       // the work block is aleady finished (final status)
  ALF_PAL_WB_STATUS_INIT = 1,   // work block has not been assigned to a thread queue (initial status, change on time)
  ALF_PAL_WB_STATUS_PENDING = 2,        // work block is pending in the thread queue (change on time)
  ALF_PAL_WB_STATUS_WORKING = 3,        // work block is processed by the thread. (change on time)
  ALF_PAL_WB_STATUS_ABORTED = 4,        // work block is aborted before or during processing, 
  //    the output result is not trustable (final status)
} ALF_PAL_WB_STATUS_T;


typedef struct _alf_pal_wb_host_data_t
{
  unsigned int total_count;     // the number of repeats for a multi use (repeater) work block
  unsigned int parm_size;       // size of the parameter buffer in the host memory
  /* the following is shared by API and PAL */
  alf_pal_task_info_t *p_task_info;     // pointer to related task info
  alf_pal_dataset_handle dataset;
  void* pal_data;
  // here goes the DT lists for the real payload
  // the ALF API layer should fill these accordingly
  // for the accelerator side partition, these fields are not used

#if 0  // to be removed
  alf_pal_dtl_group_handle dtl_grp;     // the dtl group handle
  void *pal_data;               //PAL specific data

  unsigned int input_dtl_num;   // size of the DT list group, 0 stands for no
  unsigned int output_dtl_num;  // size of the DT list group, 0 stands for no
  unsigned int inout_in_dtl_num;        // size of the DT list group, 0 stands for no
  unsigned int inout_out_dtl_num;       // size of the DT list group, 0 stands for no
  unsigned int inout_inout_dtl_num;     // size of the DT list group, 0 stands for no

  // the DTL handles, we use fixed size array for simplicity according to "IBM GTO trends"  :-)
  alf_pal_dtl_handle input_dtls[ALF_PAL_WB_MAX_DTL_NUM];        // the DTL handles for in buffer
  alf_pal_dtl_handle output_dtls[ALF_PAL_WB_MAX_DTL_NUM];       // the DTL handles for out buffer
  alf_pal_dtl_handle inout_in_dtls[ALF_PAL_WB_MAX_DTL_NUM];     // the DTL handles for inout buffer in
  alf_pal_dtl_handle inout_out_dtls[ALF_PAL_WB_MAX_DTL_NUM];    // the DTL handles for inout buffer out
  alf_pal_dtl_handle inout_inout_dtls[ALF_PAL_WB_MAX_DTL_NUM];  // the DTL handles for inout buffer inout
#endif
} alf_pal_wb_host_data_t;

// The work block data structure that is shared by the common, the PAL and the accel
// This is to save some extra data copies.
// This data structure must be properlly aligned according to platform aligment as   
//    ALF_PAL_Q_HOST_ADDR_ALIGN and ALF_PAL_Q_ACCEL_ADDR_ALIGN
// HINT:
// The alf common code should define its alf_api_wb_t as 
// struct {
//   alf_pal_wb_t pal_wb;
//   api layer private data here;
// }
// thus it can pass this one directly into the PAL.

typedef struct _alf_pal_wb_t_ {
  union
  {
    alf_pal_wb_host_data_t hostdata;
    unsigned char pad[ALF_PAL_DATA_SIZE_ALIGN(sizeof(alf_pal_wb_host_data_t))];
  };

  // I would recommend the runtime do the endianess conversion transparently when the parameters are filled in.
  // instead of using another DT list.

  // this is used by PAL internal, please make sure this is aligned to the ALF_PAL_DATA_ALIGN_REQ
  unsigned char pal_resv[ALF_PAL_WB_PRIV_DATA_SIZE];     // Reserved for PAL internal WB header and DTL Info

  //  the work block parameter data follow here, the buffer should at least be parm_size aligned to ALF_PAL_DATA_ALIGN_REQ
  unsigned char parm[];
} alf_pal_wb_t, *alf_pal_wb_handle;


// the query attributes, more TBD
// recommendations, 
typedef enum _ALF_PLATFORM_QUERY_SELECTOR_T_ {
  ALF_PAL_Q_NUM_ACCELS = 100,   // the number of accelerators in the system  
  ALF_PAL_Q_NUM_ACCELS_AVAIL = 101,     // the number of accelerators we can allocate  
  ALF_PAL_Q_NUM_ACCELS_USED = 102,      // the number of accelerators we already allocated  
  ALF_PAL_Q_HOST_MEM_SIZE = 103,        // the size of the host memory in 1KB units
  ALF_PAL_Q_HOST_MEM_SIZE_EXT = 104,    // the size of the host memory in 4TB units
  ALF_PAL_Q_ACCEL_MEM_SIZE = 105,       // accel memory in 1KB
  ALF_PAL_Q_ACCEL_MEM_SIZE_EXT = 106,   // accel memory in 4TB, (do we need this ?)
  ALF_PAL_Q_HOST_ADDR_ALIGN = 107,      // host side basic address alignment requirement in 2^n, 0 for byte, 4 for 16 byte, etc
  ALF_PAL_Q_ACCEL_ADDR_ALIGN = 108,     // accelerator side address alignment in 2^n
  ALF_PAL_Q_DTL_ADDR_ALIGN = 109,       // data transfer list address alignment in 2^n
  ALF_PAL_Q_HOST_ENDIANNESS = 110,      // host side endianess nightmare  1: big,  0: little
  ALF_PAL_Q_ACCEL_ENDIANNESS = 111,     // accelside endianess nightmare  1: big,  0: little
  ALF_PAL_Q_NUM_ACCELS_EDP = 112,
} ALF_PLATFORM_QUERY_SELECTOR;


//Status of the specific task tread/instance when we want to know, used by alf_pal_thread_status_query.
typedef enum _ALF_PAL_THREAD_STATUS_FLAG_T {
  // error status
  ALF_PAL_THREAD_STATUS_WB_ERR = 0x00000001,    // work block handling error
  ALF_PAL_THREAD_STATUS_CTX_ERR = 0x00000010,   // context handling error
  ALF_PAL_THREAD_STATUS_GEN_ERR = 0x00000100,   // generic accelerator side error

  // operation status
  ALF_PAL_THREAD_STATUS_WB_OP = 0x00010000,     // working with worklbokcs
  ALF_PAL_THREAD_STATUS_CTX_OP = 0x00100000,    // working with work blocks

} ALF_PAL_THREAD_STATUS_FLAG_T;



// status of the specific task tread/instance when we want to know
typedef struct _alf_pal_thread_status_t_ {
  unsigned int total_wbs;       // totally assigned work blocks
  unsigned int pending_wbs;     // pending
  unsigned int running_wbs;     // already in the pipeline
  unsigned int finished_wbs;    // finished ones
  unsigned int status;          // extra status information, bitwise OR of ALF_PAL_THREAD_STATUS_FLAG_T
} alf_pal_thread_status_t;

// the thread thread/instance specific work block queue query result
typedef struct _alf_pal_wbqueue_info_t_ {
  unsigned int total_entries;   // how much we have in total, since this one won't change in time, 
  // maybe we should put it into somewhere else ?
  unsigned int free_entries;    // how much free
} alf_pal_wbqueue_info_t;

#ifdef __cplusplus
extern "C" {
#endif                          /* __cplusplus */

/** Platform management */

/*  Initializes and internally sets a config handle to a configuration structure*/

  int alf_pal_config_init(alf_pal_handle platform_handle /* in */,
                          void *config_parms /* in */,
                          alf_pal_config_handle * config_handle /* out */ );


/* Initializes and internally sets a platform handle to a platform 
 * runtime structure. 
 */
  int alf_pal_init(void *sys_config_info, alf_pal_handle * platform_handle /*out */ );

/* Query information of the platform */

  int alf_pal_query(alf_pal_handle platform_handle /*in */ ,
                    ALF_PLATFORM_QUERY_SELECTOR selector /*in */ ,
                    unsigned int *result /*out */ );

/* Destroys the internal platform structure referenced by the platform 
 * handle. Any accelerators that were previously reserved are released.
 */

  int alf_pal_exit(alf_pal_handle platform_handle);

/* Destroys the internal configuration structure referenced by the config handle */

  int alf_pal_config_exit(alf_pal_config_handle config_handle /* in */ );


/* This function prints the contents of all of the fields of the data
 * structure that is pointed to by the given ALF platform handle.
 */

  void alf_pal_handle_dump(char *prefix, alf_pal_handle handle);


/** Accelerator Management */
/* 
 * Accelerator ID is a number that works as a logical id of the accelerators.
 * The platform dependent layer manages the mapping of this id to the physical
 * accelerators
 */

/* This reserves a number (N) of accelerators and must be 
 * called before any threads are created
 */

  int alf_pal_accelerators_reserve(alf_pal_handle platform_handle /*in */ ,
                                   unsigned int num_of_accels /*in */ ,
                                   ALF_ACCEL_RESV_POLICY_T policy /*in */ ,
                                   int timeout /*in */ );

/* This releases a number of accelerators. If the num_of_accels is 
 * zero, all are released. If the num_of_accels is non-zero, then 
 * the M accelerators starting at accel_id (N-M+1) until N-1 are released.
 * Any threads running on the released accelerators are killed unconditionally.
 */

  int alf_pal_accelerators_release(alf_pal_handle platform_handle /*in */ ,
                                   unsigned int num_of_accels /*in */ );

/* Version compatibility check (Cell and Hybrid) and
 * Record user defined SPE function address (Cell ONLY) */
  int alf_pal_task_info_check(alf_pal_config_handle config_handle /* in */,
                              alf_pal_task_info_t *task_info /* in */);

/** Task management */

/* Starts a thread for the task on an accelerator and set the context. 
 * The accelerator side runtime to invoke the thread context initialization method.
 */

  int alf_pal_thread_create(alf_pal_config_handle config_handle /*in */ ,
                            unsigned int vid, unsigned int accel_id /*in */ ,
                            alf_pal_task_info_t * task_info /*in */ ,
                            alf_data_addr64_t context_to_set /*in */ ,
                            alf_pal_thread_handle * thread_handle /*out */ );

/* Wait for the task thread to complete its current work (all in queue work block operations
 * and context operations to complete)
 */

  int alf_pal_thread_wait(alf_pal_thread_handle thread_handle /*in */ ,
                          int time_out /*in */ );

/* int alf_pal_thread_reset ( alf_pal_thread_handle thread_handle )
 * This function reset the status of an idle thread to initial status.  
 * For a running thread, this call will return failure.
 */

  int alf_pal_thread_reset(alf_pal_task_info_t * task_info /*in */ ,
                           alf_pal_thread_handle thread_handle /*in */, unsigned int vid);

/* Stop the thread and free the resource of the accelerator, all unfinished 
 * work blocks and thread contexts will be lost
 */

  int alf_pal_thread_destroy(alf_pal_thread_handle thread_handle /*in */ );

/* Check the status of the thread, is there any work block running, is the thread idle, etc
 */

  int alf_pal_thread_status_query(alf_pal_thread_handle thread_handle /*in */ ,
                                  alf_pal_thread_status_t * status /*out */ );


/*
 * This function prints the contents of all of the fields of the data structure 
 * that is pointed to by the given ALF thread handle.
 */

  void alf_pal_thread_dump(char *prefix, alf_pal_thread_handle handle);


/* Let the existing thread cast back its current thread context, then assign a new 
 * thread context buffer to the thread and tell the accelerator side runtime to invoke
 * the thread context initialization method.  Only possible when the thread is idle as returned by 
 * alf_pal_thread_status_query or alf_pal_thread_wait. 
 * A NULL pointer tells the accelerator the correspondent set/get is not necessary.
 */

  int alf_pal_thread_context_swap(alf_pal_thread_handle thread_handle /*in */ ,
                                  alf_data_addr64_t context_to_set /*in */ ,
                                  alf_data_addr64_t context_to_get /*in */ );

/* Load a temporary thread context buffer to the accelerator and lets the accelerator's 
 * runtime call the thread context merge method. Only possible when the thread is idle. 
 * as returned by alf_pal_thread_status_query or alf_pal_thread_wait. 
 */

  int alf_pal_thread_context_merge(alf_pal_thread_handle thread_handle /*in */ ,
                                   alf_data_addr64_t context_to_merge /*in */ );

/** Work block management */

/* Returns an alf_wbqueue_info_t structure, which includes total_entries, and free_entries. 
 */

  int alf_pal_wbqueue_query(alf_pal_thread_handle thread_handle /*in */ ,
                            alf_pal_wbqueue_info_t * wbqueue_info /*out */ );



/* This function setups the platform specific header of work block that are used
  * by PAL layer.  It will also convert the abstracted DTL to platform specific format
  * and store the result into the platform specific header.  
  */

int alf_pal_wb_setup(alf_pal_wb_handle wb_handle, alf_pal_dtlist_t *p_dtlist);



/* Put a work block to the queue. The PAL layer implementation may choose to create extra 
 * internal data related with the work block and release that data when the work block is processed
 * Also please note that the runtime code above the PAL still need to track the work block when it 
 * is enqueued to the PAL. It is the higher layer code's responsibility to release the resource
 * when the work block is processed.
 */



  int alf_pal_wb_enqueue(alf_pal_thread_handle thread_handle /*in */ ,
                         alf_pal_wb_handle wb_handle /*in */ );

/* cleanup the work block of PAL layer resource usage. */
  int alf_pal_wb_cleanup(alf_pal_wb_handle wb_handle /*in */ );
  
/* This function prints the contents of all of the fields of the data
 * structure that is pointed to by the given ALF work block handle.
 */
  void alf_pal_wb_dump(char *prefix, alf_pal_wb_handle handle);


#if 0 // to be removed

/** Data transfer list management */
/* Purpose of these APIs is to create the data transfer list in a platform independent
 * and efficient way 
 */

/* create a data transfer list group 
 */

  int alf_pal_dtl_group_create(alf_pal_handle platform_handle /*in */ , alf_pal_dataset_handle dataset_handle /* in */,
                               alf_pal_dtl_group_handle * dtl_grp_handle /*out */ );

/* destroy a data transfer list group 
 */

  int alf_pal_dtl_group_destroy(alf_pal_dtl_group_handle dtl_grp_handle /*in */ );


/* Return a data transfer list handle.
 */

  int alf_pal_dtl_create(alf_pal_dtl_group_handle dtl_grp_handle /*in */ , ALF_BUF_TYPE_T buffer_type /* in */, 
                         unsigned int local_offset, alf_pal_dtl_handle * dtl_handle /*out */ );

/* Add an entry to the data transfer list */

  int alf_pal_dtl_entry_add(alf_pal_dtl_group_handle dtl_grp_handle /*in */ ,
                            alf_pal_dtl_handle dtl_handle /*in */ ,
                            unsigned int size /*in */ ,
                            alf_data_addr64_t address /*in */ ,
                            ALF_DATA_TYPE_T data_type /*in */ );


/* This function prints the contents of all of the fields of the data
 * structure that is pointed to by the given ALF data transfer list handle.
 */
  void alf_pal_dtl_dump(char *prefix, alf_pal_dtl_group_handle dtl_grp_handle, alf_pal_dtl_handle handle);

#endif


/** Error handling */

typedef ALF_ERR_POLICY_T(*alf_pal_error_handler_t) (void *p_context_data, void* task_handle,
                                                ALF_ERR_TYPE_T error_type, int error_code, char *error_string);
/* The API registers an error handler callback to the PAL layer. Please refer to the 
 * ALF high level design for documentation of the expected behaviors of the callback
 * Please note that an ALF common layer code implementation is suggested to register 
 * their internal error handler callback in order to trap the PAL layer problems.
 */

  int alf_pal_error_handler_register(alf_pal_handle platform_handle /*in */ ,
                                     alf_pal_error_handler_t call_back_function,
                                     void *p_context_data /*in */ );

  /** Data set */

  /* Create a data set */
  int alf_pal_dataset_create(alf_pal_handle platform_handle /* in */, alf_pal_dataset_handle * p_pal_dataset /* out */ );

  /* Add buffer to a data set */
  int alf_pal_dataset_buffer_add(alf_pal_dataset_handle pal_dataset, alf_data_addr64_t addr, unsigned long long size,
                                 ALF_DATASET_ACCESS_MODE_T access_mode);

  /* End adding buffers to a data set */
  int alf_pal_dataset_close(alf_pal_dataset_handle pal_dataset);

  /* Associate a data set to a thread */
  int alf_pal_thread_dataset_associate(alf_pal_thread_handle thread_handle, alf_pal_dataset_handle pal_dataset);

  /* Put a data set to the accelerators and do not wait */
  int alf_pal_dataset_put_no_wait(alf_pal_dataset_handle pal_dataset);

  /* Wait for data set put to the accelerators to complete */
  int alf_pal_dataset_wait_for_put(alf_pal_dataset_handle pal_dataset);

  /* Get a data set from an accelerator */
  int alf_pal_dataset_get_and_wait(alf_pal_dataset_handle pal_dataset);

  /* Destroy a data set */
  int alf_pal_dataset_destroy(alf_pal_dataset_handle pal_dataset);
  
  /* Dump a data set*/
  void alf_pal_dataset_dump(char *prefix, alf_pal_dataset_handle pal_dataset);

#ifdef __cplusplus
}
#endif                          /* __cplusplus */
#endif                          /* __ALF_PAL_H_INC__ */
