/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/*
 ************************************************************
 * ALF Host Scheduler
 ************************************************************
 */

#include <stddef.h>
#include <string.h>
#include <stdio.h>

//#define _ALF_DEBUG_LEVEL_           _ALF_ERR_LEVEL_TRACE_   //  0 to 10,
#include <alf.h>

#include "alf_host.h"
#include "alf_debug.h"
#include "alf_api_local.h"
#include "alf_trace.h"
#include "alf_stp.h"
#include "alf_arraylist.h"
#include "alf_hooks_perform_host.h"

/*
 ************************************************************
 * Globals
 ************************************************************
 */



/*
 ************************************************************
 * Local Globals
 ************************************************************
 */


/*
 ************************************************************
 * Local APIs
 ************************************************************
 */

/* This is the prototype of ALF scheduler */

void *alf_api_scheduler(void *alf_ptr)
{
  alf_instance_t *alf_instance = (alf_instance_t *) alf_ptr;
  _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Enter: alf_ptr=%p\n", alf_ptr);
  do {
    //if there are no tasks in the various task lists and we're not exiting then we can wait for the API
    //to signal that there is work to do or that it's time to exit.
    //This reduces competition with other threads/processes when there are no tasks pending.
    ALF_STP_PROF_BEGIN( alf_instance->lock_time );
    pthread_mutex_lock(&alf_instance->lock);
    if (!(alf_arraylist_get_length(alf_instance->destroy_task_list) || alf_arraylist_get_length(alf_instance->exec_task_list) ||
        alf_arraylist_get_length(alf_instance->ready_task_list) || alf_arraylist_get_length(alf_instance->init_task_list)) && 
        alf_instance->state != ALF_API_STATUS_EXITING) {
      pthread_cond_wait(&alf_instance->task_cond, &alf_instance->lock);
    }
    pthread_mutex_unlock(&alf_instance->lock);
    ALF_STP_PROF_END( alf_instance->lock_time );    
    
    if (alf_instance->state == ALF_API_STATUS_EXITING) {
      ALF_STP_PROF_BEGIN(alf_instance->exit_time);
      _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf_instance->state=ALF_API_STATUS_EXITING\n");
      if (alf_arraylist_is_empty(alf_instance->init_task_list)
          && alf_arraylist_is_empty(alf_instance->ready_task_list)
          && alf_arraylist_is_empty(alf_instance->exec_task_list)) {
        //non-force exit, only exit when there's no running or pending task
        break;
      }
    }

    if (alf_arraylist_is_empty(alf_instance->ready_task_list)
        || alf_thread_mgr_query(alf_instance)) 
      //if ready list is empty or threads still available, call task select
      alf_sched_task_select(alf_instance);
    
    //pick up task to run
    alf_sched_task_schedule(alf_instance);

    //do work block scheduling for each running task
    alf_sched_task_run(alf_instance);

    //release resources of finished or destroyed tasks
    alf_sched_task_release(alf_instance);
  }
  while (1);

  _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "Signal alf_instance->cond with alf_instance->state = ALF_API_STATUS_EXITED\n");
  _ALF_API_STD_COND_SIG(alf_instance->lock, alf_instance->cond, alf_instance->state = ALF_API_STATUS_EXITED);
  _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Exit: ret=%p\n", NULL);

  ALF_STP_PROF_END(alf_instance->exit_time);
  return NULL;
}

void alf_sched_pal_wb_enqueue(alf_api_task_t* task_handle, int i, alf_api_wb_t *wb)
{
  int pal_ret = 0;
  alf_pal_wb_handle pal_wb = (alf_pal_wb_handle)&wb->pal;

  _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Enter: task_handle=%p, i=%d, wb=%p\n", task_handle, i, wb);
   pal_ret = alf_pal_wb_enqueue(task_handle->p_task_threads[i].thread, 
                                pal_wb);
   if( 0 == pal_ret )
   {
     //enqueue to garbage queue failed will cause memory leak
     //but we can still go on
     if( NULL == alf_arraylist_enqueue(task_handle->accel_fin_wbq[i], 
                                        wb))
     {
       alf_err_error_processing(task_handle->alf_handle, ALF_ERR_WARNING, ALF_ERR_NOMEM, 
                                  "WB:enqueue to garbage queue failed\n");
     }
   }
   //if pal enqueue failed, call error handler
   else
   {
     alf_err_error_processing(task_handle->alf_handle, ALF_ERR_WARNING, pal_ret, 
                                  "WB:enqueue to PAL queue failed\n");
   }
	_ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Exit\n");
}

int alf_sched_pal_wbqueue_query(alf_pal_thread_handle thread_handle)
{
  alf_pal_wbqueue_info_t qinfo;
  alf_pal_wbqueue_query(thread_handle,&qinfo);
  return _ALF_SCHED_ACCEL_WB_QUEUE_DEPTH - (qinfo.total_entries - qinfo.free_entries);
}

int alf_sched_task_threads_wait(alf_api_task_t *task_handle)
{
  ALF_STP_PROF_BEGIN( task_handle->wait_time );   
  unsigned int i;
	_ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Enter: task_handle=%p\n", task_handle);
  //wait for all thread idle
  for (i = 0; i < task_handle->num_accels; i++) {
    if (0 != alf_pal_thread_wait(task_handle->p_task_threads[i].thread, 0)) {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Exit: ret=1\n");
      return 1;
    }
  }
  ALF_STP_PROF_END( task_handle->wait_time );
  _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Exit: ret=0\n");
  return 0;
}

void alf_sched_wb_sync_proc(alf_api_task_t* task_handle, alf_wb_sync_t* sync_wb)
{

  int ret = 0;

  //ensure finished wb are counted correctly after barrier
  alf_sched_task_wb_try_free(task_handle);

  if(sync_wb->callback_func != NULL)
  {
    ret = (int)(*sync_wb->callback_func)(sync_wb,sync_wb->p_context);
    if( ret < 0 )
    {
       alf_err_error_processing(task_handle->alf_handle, ALF_ERR_WARNING, ALF_ERR_GENERIC, 
                                  "WB:sync callback failed\n");
    }
  }

  pthread_mutex_lock(&sync_wb->_cond_lock);
  pthread_cond_signal(&sync_wb->_cond);
  sync_wb->state=_ALF_SYNC_FINISHED;
  pthread_mutex_unlock(&sync_wb->_cond_lock);

  task_handle->sync_wb = NULL;

}

/* cyclic distribution
 * dispatch wb from accel wb queue to pal wb queue directly
 */
int alf_accel_wb_cyclic_dispatch(alf_api_task_t * task_handle)
{
  alf_api_wb_t *wb;
  alf_wb_sync_t *sync_wb;
  int i;
  int ret = 0;
	_ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Enter: task_handle=%p\n", task_handle);
  for (i = 0; i < (int) task_handle->num_accels; i++) {
    if(task_handle->p_task_threads[i].barrier_status )
    {
        //unresolved barrier 
        //check thread status
        if(task_handle->p_task_threads[i].barrier_status  == _ALF_BARRIER_UNRESOLVED)
        {
          if (0 != alf_pal_thread_wait(task_handle->p_task_threads[i].thread, 0)) {
          }
          else
          {
            //this thread is idle
            task_handle->sync_num++;
            task_handle->p_task_threads[i].barrier_status = _ALF_BARRIER_RESOLVED;
          }
        }
        ret = 1;
        //barrier resolved, wait for other thread
        continue;
    }
    while (!alf_arraylist_is_empty_nl(task_handle->accel_wbq[i])) {
      ALF_STP_PROF_BEGIN(task_handle->query_time);
      ALF_STP_PROF_BEGIN(task_handle->feed_time);
      wb = alf_arraylist_get_front_nl(task_handle->accel_wbq[i]);
      //peek the top of the queue to see if it's a sync wb
      if(wb->type == _ALF_WB_SYNC)
      {
        alf_arraylist_dequeue_nl(task_handle->accel_wbq[i]);
        sync_wb = (alf_wb_sync_t *)&wb->pal;
        if(sync_wb->type == ALF_SYNC_BARRIER )
        {
          //store sync wb infomarion and turn to next thread 
          //when next time enter this subroutine will check if each thread idle
          task_handle->p_task_threads[i].barrier_status = _ALF_BARRIER_UNRESOLVED;
          task_handle->sync_wb = sync_wb;
        }
        else if(sync_wb->type == ALF_SYNC_NOTIFY )
        {
          //do not need to check thread status for notify 
          task_handle->sync_wb = sync_wb;
          task_handle->sync_num++;
          task_handle->p_task_threads[i].barrier_status = _ALF_BARRIER_RESOLVED;
        }
        ret = 1;
        break;
      }
      //dispatch as much as possible wb to corresponding thread
      if (alf_sched_pal_wbqueue_query(task_handle->p_task_threads[i].thread) > 0) {
        wb = alf_arraylist_dequeue_nl(task_handle->accel_wbq[i]);
        alf_sched_pal_wb_enqueue(task_handle, i, wb);
        ALF_STP_PROF_END(task_handle->feed_time);
      } else {
        ALF_STP_PROF_END(task_handle->query_time);
        ret = 1;
        break;
      }
    }
  }
  if(task_handle->sync_num == task_handle->num_accels)
  {       
    //all threads reached this point 
    alf_sched_wb_sync_proc(task_handle, task_handle->sync_wb);      
    task_handle->sync_num = 0;
    for (i = 0; i < (int) task_handle->num_accels; i++) {
     task_handle->p_task_threads[i].barrier_status = _ALF_BARRIER_CLEAR;
    }
  }
	_ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Exit: ret=%d\n", ret);
  return ret;
}

int alf_accel_buffer_wb_dispatch(alf_api_task_t * task_handle)
{
    unsigned int accel_index;
    alf_api_wb_t* wb;
    int ret = 0;
    if(task_handle->accel_wbq == NULL)
      return ret;
    for (accel_index = 0; accel_index < task_handle->num_accels; accel_index ++) {
      if(task_handle->accel_wbq[accel_index] == NULL)
        break;
      while (!alf_arraylist_is_empty_nl(task_handle->accel_wbq[accel_index])) {
        ALF_STP_PROF_BEGIN(task_handle->query_time);
        ALF_STP_PROF_BEGIN(task_handle->feed_time);
        //dispatch wb in accel wb queue to pal wb queue 
        if (alf_sched_pal_wbqueue_query(task_handle->p_task_threads[accel_index].thread) > 0) {
          ALF_STP_PROF_END(task_handle->query_time);
          wb = alf_arraylist_dequeue_nl(task_handle->accel_wbq[accel_index]);
          alf_sched_pal_wb_enqueue(task_handle, accel_index, wb);
          ALF_STP_PROF_END(task_handle->feed_time);
          _ALF_DPRINTF_X(_ALF_ERR_LEVEL_TRACE_, "accel %d dispatch from buffer queue to pal queue\n", accel_index);
        } else {
          ALF_STP_PROF_END(task_handle->query_time);
          //still have buffered wb 
          ret = 1;
          break;
        }
      }
    }

  return ret;
}

/* non-cyclic distribution
 */
int alf_accel_wb_noncyclic_dispatch(alf_api_task_t * task_handle)
{
  alf_api_wb_t *wb;
  alf_wb_sync_t *sync_wb;
  unsigned int accel_visited = 0;
  unsigned int num_wb_enqueued = 0;
  int ret = 0;
  _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Enter: task_handle=%p\n", task_handle);

  //if no wb bundle, no accel wb queue needed
  //dispatch from task wb queue to pal wb queue
  if (task_handle->wb_dist_size == 1) {
    if(task_handle->sync_wb != NULL)
    {
      if(alf_sched_task_threads_wait(task_handle))
        return 1;
      alf_sched_wb_sync_proc(task_handle, task_handle->sync_wb);    
    }
    while (!alf_arraylist_is_empty_nl(task_handle->task_wbq)) {
      wb = alf_arraylist_get_front_nl(task_handle->task_wbq);
      //peek the top of the queue to see if it's a sync wb
      if(wb->type == _ALF_WB_SYNC)
      {
        alf_arraylist_dequeue_nl(task_handle->task_wbq);
        sync_wb = (alf_wb_sync_t *)&wb->pal;
        if(sync_wb->type == ALF_SYNC_BARRIER )
        {
          //store sync wb infomarion and return
          //when next time enter this subroutine will check if all threads idle
          task_handle->sync_wb = sync_wb;
          ret = 1;
          break;
        }
        else if(sync_wb->type == ALF_SYNC_NOTIFY )
        {
          alf_sched_wb_sync_proc(task_handle, sync_wb);      
        }
        continue;
      }
      if (accel_visited  >= task_handle->num_accels )
      { 
        if( !num_wb_enqueued) 
        //all accel pal queue is full
        {
          break;
        } else {  //start over again
          num_wb_enqueued = 0;
          accel_visited = 0;
        }
       }
      ALF_STP_PROF_BEGIN(task_handle->query_time);
      ALF_STP_PROF_BEGIN(task_handle->feed_time);
      //dispatch wb as much as possible to pal queue
      if (alf_sched_pal_wbqueue_query(task_handle->p_task_threads[task_handle->cur_accel].thread) > 0) 
      {
        ALF_STP_PROF_END(task_handle->query_time);
        wb = alf_arraylist_dequeue_nl(task_handle->task_wbq);
        alf_sched_pal_wb_enqueue(task_handle, task_handle->cur_accel, wb);
        ALF_STP_PROF_END(task_handle->feed_time);
        num_wb_enqueued++;
      } else {
        ALF_STP_PROF_END(task_handle->query_time);
        ret = 1;
      }
      task_handle->cur_accel = (task_handle->cur_accel + 1) % task_handle->num_accels;
      accel_visited ++;
    }                           //while  
  }                             //if
  else {
    //unresolved barrier
    if(task_handle->sync_wb != NULL)
    {
      //try to dispatch all buffer wb first
      if(alf_accel_buffer_wb_dispatch(task_handle))
        return 1;
      //check if all threads idle
      if(alf_sched_task_threads_wait(task_handle))
        return 1;
      //barrier resolved
      alf_sched_wb_sync_proc(task_handle, task_handle->sync_wb);    
    }
    while (!alf_arraylist_is_empty_nl(task_handle->task_wbq)) {
      wb = alf_arraylist_get_front_nl(task_handle->task_wbq);
      //peek the top of the queue to see if it's a sync wb
      if(wb->type == _ALF_WB_SYNC)
      {
        alf_arraylist_dequeue_nl(task_handle->task_wbq);
        sync_wb = (alf_wb_sync_t *)&wb->pal;
        if(sync_wb->type == ALF_SYNC_BARRIER )
        {
          //store sync wb infomarion and return
          //when next time enter this subroutine will check if all threads idle
          task_handle->sync_wb = sync_wb;
          ret = 1;
          break;
        }
        else if(sync_wb->type == ALF_SYNC_NOTIFY )
        {
          //call user callback directly for notify
          alf_sched_wb_sync_proc(task_handle, sync_wb);      
        }
        continue;
      }
      if (accel_visited >= task_handle->num_accels) {
        if(!num_wb_enqueued) 
        //all accel pal queue is full
        {
          break;
        } else {  //start over again
          accel_visited = 0;
          num_wb_enqueued = 0;
        }
      }
      //try to dispatch buffer wb to pal wb queue as much as possble
      while (!alf_arraylist_is_empty_nl(task_handle->accel_wbq[task_handle->cur_accel])) {
        ALF_STP_PROF_BEGIN(task_handle->query_time);
        ALF_STP_PROF_BEGIN(task_handle->feed_time);
        if (alf_sched_pal_wbqueue_query(task_handle->p_task_threads[task_handle->cur_accel].thread) > 0) {
          ALF_STP_PROF_END(task_handle->query_time);
          wb = alf_arraylist_dequeue_nl(task_handle->accel_wbq[task_handle->cur_accel]);
          alf_sched_pal_wb_enqueue(task_handle, task_handle->cur_accel, wb);
          ALF_STP_PROF_END(task_handle->feed_time);
          _ALF_DPRINTF_X(_ALF_ERR_LEVEL_TRACE_, "accel %d dispatch from buffer queue to pal queue\n", task_handle->cur_accel);
        } else {
          ALF_STP_PROF_END(task_handle->query_time);
          //still have buffered wb 
          ret = 1;
          break;
        }
      }
      ALF_STP_PROF_BEGIN(task_handle->query_time);
      ALF_STP_PROF_BEGIN(task_handle->feed_time);
      //if this accel's last bundle not finished, wb must be buffered to this accel first
      //else skip this accel
      if ( !alf_arraylist_is_empty_nl(task_handle->accel_wbq[task_handle->cur_accel]) ) 
      {
        if(task_handle->dist_num > 0)
        {
              wb = alf_arraylist_dequeue_nl(task_handle->task_wbq);
              if(NULL == alf_arraylist_enqueue_nl(task_handle->accel_wbq[task_handle->cur_accel], 
                                                  wb))
              {
                 alf_err_error_processing(task_handle->alf_handle, ALF_ERR_WARNING, 
                                     ALF_ERR_NOMEM, 
                                     "WB:enqueue to buffer queue failed\n");
              }
              task_handle->dist_num++;
              _ALF_DPRINTF_X(_ALF_ERR_LEVEL_TRACE_, "accel %d put into buffer queue\n", task_handle->cur_accel);
              ret = 1; 
        }
      } else {
           //last bundle finished, try to dispatch to pal queue first
           if(alf_sched_pal_wbqueue_query(task_handle->p_task_threads[task_handle->cur_accel].thread) > 0)
           {
              wb = alf_arraylist_dequeue_nl(task_handle->task_wbq);
              alf_sched_pal_wb_enqueue(task_handle, task_handle->cur_accel, wb);
              ALF_STP_PROF_END(task_handle->feed_time);
              _ALF_DPRINTF_X(_ALF_ERR_LEVEL_TRACE_, "accel %d dispatch from task queue to pal queue\n", task_handle->cur_accel);
              num_wb_enqueued++;
              task_handle->dist_num++;
              ALF_STP_PROF_END(task_handle->query_time);
           }
           //buffer wb if pal queue full
           else
           {   
              wb = alf_arraylist_dequeue_nl(task_handle->task_wbq);
              if(NULL == alf_arraylist_enqueue_nl(task_handle->accel_wbq[task_handle->cur_accel], 
                                                  wb))
              {
                 alf_err_error_processing(task_handle->alf_handle, ALF_ERR_WARNING, 
                                     ALF_ERR_NOMEM, 
                                     "WB:enqueue to buffer queue failed\n");
              }
              task_handle->dist_num++;
              _ALF_DPRINTF_X(_ALF_ERR_LEVEL_TRACE_, "accel %d put into buffer queue\n", task_handle->cur_accel);
              ret = 1; 
            }
      }
      if (task_handle->dist_num >= task_handle->wb_dist_size || task_handle->dist_num == 0) {
            accel_visited++;
            task_handle->cur_accel = (task_handle->cur_accel + 1) % task_handle->num_accels;
            task_handle->dist_num = 0;
      }
    }                       //while alf_arraylist_get_length
  }                             //else
	_ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Exit: ret=%d\n", ret);
  return ret;
}

int alf_sched_task_wb_dispatch(alf_api_task_t * task_handle)
{
	int ret;
	_ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Enter: task_handle=%p\n", task_handle);
  ALF_STP_PROF_BEGIN(task_handle->dis_time);
  if (task_handle->attr & ALF_TASK_ATTR_WB_CYCLIC) {
    ret = alf_accel_wb_cyclic_dispatch(task_handle);
  } else {
    ret = alf_accel_wb_noncyclic_dispatch(task_handle);
  }
  ALF_STP_PROF_END(task_handle->dis_time);
	_ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Exit: ret=%d\n", ret);
	return ret;
}

/*
*  alf task selection 
*  pick up ready task from init list and put into ready list
*/
void alf_sched_task_select(alf_instance_t * alf_instance)
{
  ALF_STP_PROF_BEGIN( alf_instance->sel_time );
  ALF_STP_PROF_BEGIN( alf_instance->idle_time );
  unsigned int i;
  alf_api_task_t *task_handle;
  _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Enter: alf_instance=%p\n", alf_instance);

  unsigned int task_num = alf_arraylist_get_length(alf_instance->init_task_list);
  for (i = 0; i < task_num; i++) {
    task_handle = (alf_api_task_t *) alf_arraylist_dequeue(alf_instance->init_task_list);

    pthread_mutex_lock(&task_handle->lock);

    //task not ready, put it back into init list
    if (task_handle->state == ALF_API_TASK_STATUS_INIT)
    {
      //finalized task with no wb enqueued should also be selected to run 
      if(task_handle->finalized_flag && task_handle->parent_count == 0)
      {
        task_handle->state = ALF_API_TASK_STATUS_READY;
        pthread_mutex_unlock(&task_handle->lock);
        if(NULL == alf_arraylist_enqueue(alf_instance->ready_task_list, task_handle))
        {
          alf_err_error_processing(task_handle->alf_handle, ALF_ERR_EXCEPTION, 
                                       ALF_ERR_NOMEM, 
                                       "TASK:enqueue to ready list failed\n");
        }
      }
      else
      {
        pthread_mutex_unlock(&task_handle->lock);
        if(NULL == alf_arraylist_enqueue(alf_instance->init_task_list, task_handle))
        {
          alf_err_error_processing(task_handle->alf_handle, ALF_ERR_EXCEPTION, 
                                       ALF_ERR_NOMEM, 
                                       "TASK:enqueue to init list failed\n");
        }
      }
    }
    //if task ready to run, put into ready list
    else if (task_handle->state == ALF_API_TASK_STATUS_PENDING )
    {
      if( task_handle->parent_count == 0 )
      {
        task_handle->state = ALF_API_TASK_STATUS_READY;
        pthread_mutex_unlock(&task_handle->lock);
        if(NULL == alf_arraylist_enqueue(alf_instance->ready_task_list, task_handle))
        {
          alf_err_error_processing(task_handle->alf_handle, ALF_ERR_EXCEPTION, 
                                       ALF_ERR_NOMEM, 
                                       "TASK:enqueue to ready list failed\n");
        }
      }
      else
      {
        pthread_mutex_unlock(&task_handle->lock);
        if(NULL == alf_arraylist_enqueue(alf_instance->init_task_list, task_handle))
        {
          alf_err_error_processing(task_handle->alf_handle, ALF_ERR_EXCEPTION, 
                                       ALF_ERR_NOMEM, 
                                       "TASK:enqueue to init list failed\n");
        }
      }  
    } 
    //task destroyed
    else
    {
      pthread_mutex_unlock(&task_handle->lock);
      alf_sched_task_destroy(alf_instance, task_handle);
    }
  }
#ifdef _ALF_STP_ENABLE_HOST
  if(task_num == 0)
  {
    ALF_STP_PROF_END(alf_instance->idle_time);
  }
  else 
    ALF_STP_PROF_END(alf_instance->sel_time);
#endif
	_ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Exit\n");
}

int alf_sched_task_start(alf_instance_t * alf_instance,alf_api_task_t *task_handle, int index)
{
  int rtn;
  pthread_mutex_lock(&task_handle->lock);

  if (task_handle->state == ALF_API_TASK_STATUS_READY) {
    //copy context
    if(task_handle->p_context != NULL 
       && task_handle->task_info->ctx_entry_size != 0 ) {
      memcpy(task_handle->p_thread_context, task_handle->p_context, 
             task_handle->task_info->ctx_entry_size);
    }
    
    //if threads allocated successfully, put into exec list to run
    rtn = alf_thread_mgr_start_thread(alf_instance, task_handle);
    if( rtn > 0 ) {
      //create accel wbq and garbage queue for non-fixed mapping
      rtn = alf_sched_task_wbq_create(task_handle);
      if(rtn < 0)
      {
        //if failed, return thread and keep task in ready list
        alf_thread_mgr_return_thread(alf_instance, task_handle);
        index++;
      } else {
        //enqueue to exec list and remove from ready list
        if(NULL == alf_arraylist_enqueue(alf_instance->exec_task_list, task_handle)) {
          alf_err_error_processing(task_handle->alf_handle, ALF_ERR_EXCEPTION, 
                                   ALF_ERR_NOMEM, 
                                   "TASK:enqueue to exec list failed\n");
          index++;
        } else {
          alf_arraylist_remove_element(alf_instance->ready_task_list,index);

          //alf performance hook end ALF_TASK_BEFORE_EXEC_INTERVAL
	  TRACE_INTERVAL_END(_ALF_TASK_BEFORE_EXEC_INTERVAL,task_handle->task_before_exec_token,1,task_handle);
          task_handle->state = ALF_API_TASK_STATUS_EXEC;
          //alf performance hook begin ALF_TASK_EXEC_INTERVAL
          TRACE_INTERVAL_BEGIN(_ALF_TASK_EXEC_INTERVAL,task_handle->task_in_exec_token,1);
          alf_int_task_call_event_handler(task_handle, ALF_TASK_EVENT_READY);
        }
      }
    } else {
      //required threads not available, so keep it in ready list
      if( rtn != -ALF_ERR_AGAIN) {
        // Thread creation failed fatally.  Mark thread as dead, and
        // broadcast out a signal to unblock any waiting user threads
        // The task mutex is already (somewhat dubiously) held
        task_handle->state = ALF_API_TASK_STATUS_DESTROY;
        pthread_cond_signal(&task_handle->cond);

#ifdef _ALF_PLATFORM_HYBRID_
        if (task_handle->dataset != NULL)
          _ALF_API_DEC_DATASET_TASK_COUNT(task_handle);
#endif
	  
        alf_err_error_processing(task_handle->alf_handle, ALF_ERR_EXCEPTION, 
                                 rtn, "TASK:start pal thread failed\n");
      }
      index++;
    }
    pthread_mutex_unlock(&task_handle->lock);
  } else {
    //task destroyed
    //remove from ready list and put into destroy list
    alf_arraylist_remove_element(alf_instance->ready_task_list,index);
    pthread_mutex_unlock(&task_handle->lock);
    alf_sched_task_destroy(alf_instance, task_handle);
  }

  return index;
}

/*
 * alf task scheduling
 * schedule task to run on pal thread
*/
void alf_sched_task_schedule(alf_instance_t * alf_instance)
{
  ALF_STP_PROF_BEGIN( alf_instance->sched_time );
  ALF_STP_PROF_BEGIN( alf_instance->idle_time );
  unsigned int i,ti;
  alf_api_task_t *task_handle;
  _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Enter: alf_instance=%p\n", alf_instance);
  _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Enter: alf_instance=%p\n", alf_instance);
  unsigned int task_num;

  //first round 
  //pick up thread cached task to schedule
  task_num = alf_arraylist_get_length(alf_instance->ready_task_list);
  ti = 0;
  for (i = 0; i < task_num; i++) {
    //if no thread left, skip the left tasks
    if(alf_thread_mgr_query(alf_instance) <= 0)
    {
      break;
    }
    task_handle = (alf_api_task_t *) alf_arraylist_get_element(alf_instance->ready_task_list,ti);
    //if current task is not scheduled, keep it in ready list
    //and increase index to process next task 
    //otherwise remove task from ready list and do not increase index
    //since next task will be moved forward during task removal 
    if(alf_thread_mgr_cache_hit(alf_instance,task_handle))
    {
      ti = alf_sched_task_start(alf_instance,task_handle,ti);
    }
    else ti++;
  }

#ifdef _ALF_STP_ENABLE_HOST
  if(task_num == 0)
  {
    ALF_STP_PROF_END(alf_instance->idle_time);
  }
  else 
    ALF_STP_PROF_END(alf_instance->sched_time);
#endif
  ALF_STP_PROF_BEGIN(alf_instance->sched_time);
  ALF_STP_PROF_BEGIN(alf_instance->idle_time);

  //second round
  //schedule other tasks
  task_num = alf_arraylist_get_length(alf_instance->ready_task_list);
  ti = 0;
  for (i = 0; i <task_num ; i++) {
    //if no thread left, skip the left tasks
    if(alf_thread_mgr_query(alf_instance) <= 0)
    {
      break;
    }
    task_handle = (alf_api_task_t *) alf_arraylist_get_element(alf_instance->ready_task_list,ti);
    ti = alf_sched_task_start(alf_instance,task_handle,ti);
  }
#ifdef _ALF_STP_ENABLE_HOST
  if(task_num == 0)
  {
    ALF_STP_PROF_END(alf_instance->idle_time);
  }
  else 
    ALF_STP_PROF_END(alf_instance->sched_time);
#endif
    _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Exit\n");
}

/* alf task stop
 * do the following things to stop a task:
 * free all wb
 * context merge
 * call event handler
 * send finish signal
 * update parent count
 * release threads
*/
int alf_sched_task_stop(alf_instance_t * alf_instance, alf_api_task_t * task_handle)
{
  _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Enter: alf_instance=%p, task_handle=%p\n", alf_instance, task_handle);
  
  //free left wb
  alf_sched_task_wb_free(task_handle);

  //context merge
  if(task_handle->task_info->pal.api_str[ALF_API_KERNEL_CTX_MERGE][0]   /* check if context merge API is defined */
     && task_handle->p_context != NULL 
     && task_handle->task_info->ctx_entry_size != 0 )
  {
    ALF_STP_PROF_BEGIN(task_handle->mer_time);
    alf_sched_task_context_merge(task_handle,0);
    ALF_STP_PROF_END(task_handle->mer_time);
  }

  //release threads
  alf_thread_mgr_return_thread(alf_instance, task_handle);

#ifdef _ALF_PLATFORM_HYBRID_
  //get dataset only if ALF_TASK_EVENT_FINISHED registered, otherwise alf_task_wait must be called to get the dataset
  if(task_handle->dataset != NULL && (task_handle->event_handler.event_mask & ALF_TASK_EVENT_FINISHED)) {
    alf_pal_dataset_get_and_wait(task_handle->dataset->pal_dataset);
    _ALF_API_DEC_DATASET_TASK_COUNT(task_handle);
  }
#endif

  //call event handler
  alf_int_task_call_event_handler(task_handle, ALF_TASK_EVENT_FINISHED);

  //send finish signal
  _ALF_API_STD_COND_SIG(task_handle->lock, task_handle->cond, task_handle->state = ALF_API_TASK_STATUS_FINISH);

  //alf perfomance hook end ALF_TASK_EXEC_INTERVAL
  TRACE_INTERVAL_END(_ALF_TASK_EXEC_INTERVAL,task_handle->task_in_exec_token,1,task_handle);
 
  //update child tasks parent count
  alf_sched_task_child_notify(task_handle);
  
  _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Exit: ret=0\n");
  return 0;
}

/* alf task run 
 * do work block scheduling for a task
*/
void alf_sched_task_run(alf_instance_t * alf_instance)
{
  ALF_STP_PROF_BEGIN(alf_instance->run_time);
  ALF_STP_PROF_BEGIN(alf_instance->idle_time);
  unsigned int i;
  alf_api_task_t *task_handle;

  _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Enter: alf_instance=%p\n", alf_instance);

  unsigned int task_num = alf_arraylist_get_length(alf_instance->exec_task_list);

  for (i = 0; i < task_num; i++) {

    task_handle = (alf_api_task_t *) alf_arraylist_dequeue(alf_instance->exec_task_list);
    if (task_handle->state == ALF_API_TASK_STATUS_EXEC) {
      //task finalized, try to stop it
      if (task_handle->finalized_flag) {
        if (alf_sched_task_wb_dispatch(task_handle) || 
            alf_accel_buffer_wb_dispatch(task_handle)) {

          //try to free some memory
          ALF_STP_PROF_BEGIN( task_handle->gar_time );
          alf_sched_task_wb_try_free(task_handle);
          ALF_STP_PROF_END( task_handle->gar_time ); 

          //not all wb dispatched, put back to exec list
          ALF_STP_PROF_BEGIN(alf_instance->lock_time);
          alf_arraylist_enqueue(alf_instance->exec_task_list, task_handle);
          ALF_STP_PROF_END(alf_instance->lock_time);

          continue;
        }
        if(alf_sched_task_threads_wait(task_handle))
        {

          ALF_STP_PROF_BEGIN(alf_instance->lock_time);
          //thread is still busy, put back to exec list
          alf_arraylist_enqueue(alf_instance->exec_task_list, task_handle);
          ALF_STP_PROF_END(alf_instance->lock_time);

          continue;
        }

        ALF_STP_PROF_BEGIN( task_handle->gar_time );
        alf_sched_task_stop(alf_instance,task_handle);
        ALF_STP_PROF_END( task_handle->gar_time );

        alf_sched_task_destroy(alf_instance, task_handle);
      } else {
        //task still running
        alf_sched_task_wb_dispatch(task_handle);
        //try to free some memory
        ALF_STP_PROF_BEGIN( task_handle->gar_time );
        alf_sched_task_wb_try_free(task_handle);
        ALF_STP_PROF_END( task_handle->gar_time ); 
        //should not fail here, since just put back it will not cause queue size exceeding
        alf_arraylist_enqueue(alf_instance->exec_task_list, task_handle);
      }
    }                           //if
    else if (task_handle->state == ALF_API_TASK_STATUS_DESTROY) {
      // the following will stop the threads if they are still busy
      alf_thread_mgr_return_thread(alf_instance, task_handle);
      ALF_STP_PROF_BEGIN( task_handle->gar_time );
      alf_sched_task_destroy(alf_instance, task_handle);
      ALF_STP_PROF_END( task_handle->gar_time );
    } //else
  }
#ifdef _ALF_STP_ENABLE_HOST
  if(task_num == 0)
  {
    ALF_STP_PROF_END(alf_instance->idle_time);
  }
  else 
    ALF_STP_PROF_END(alf_instance->run_time);
#endif
  _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Exit\n");
}

/* update parent count of it's child tasks when finished
**/
void alf_sched_task_child_notify(alf_api_task_t * task_handle)
{
  int child_num;
  int i;

  _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Enter: task_handle=%p\n", task_handle);
  alf_api_task_t *child_task;
  child_num = alf_arraylist_get_length(task_handle->child_tasks);
  for (i = 0; i < child_num; i++) {
    child_task = alf_arraylist_dequeue(task_handle->child_tasks);
    pthread_mutex_lock(&child_task->lock);
    child_task->parent_count--;
    pthread_mutex_unlock(&child_task->lock);
  }
  _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Exit\n");
}

/* merge context in parallel
 * merge neibourhood context in pair and recursively
 *  0<-1 2<-3 4<-5 6<-7 
 *  0<-2      4<-6
 *  0<-4
**/
void alf_sched_task_context_merge(alf_api_task_t* task_handle, unsigned int depth)
{
  _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Enter: task_handle=%p, depth=%d\n", task_handle, depth);
  unsigned int i;
  unsigned int ctx_size = task_handle->task_info->pal.task_context_size;
  int jump = 1<<(depth+1);
  int next = 1<<depth;
  alf_data_addr64_t ctx_addr;
  int ret;
  if( (task_handle->num_accels == 1 && depth == 1)
      || (depth > 1 && (1<<(depth-1)) >= (int)task_handle->num_accels) )
  {
      while(1)
      {
        ret = alf_pal_thread_wait(task_handle->p_task_threads[0].thread, 0);
        if( 0 == ret ) break;
        else if( ret < 0) return;
      } 
      _ALF_DPRINTF_X(_ALF_ERR_LEVEL_TRACE_,"wait thread %d\n",0);
      PTR_TO_ADDR64(task_handle->p_thread_context,ctx_addr);
      alf_pal_thread_context_swap(task_handle->p_task_threads[0].thread,0,
                                  ctx_addr);  
      _ALF_DPRINTF_X(_ALF_ERR_LEVEL_TRACE_,"swap thread %d to context %d\n",0,0);
      while(1)
      {
        ret = alf_pal_thread_wait(task_handle->p_task_threads[0].thread, 0);
        if( 0 == ret ) break;
        else if( ret < 0) return;
      } 
      memcpy(task_handle->p_context, task_handle->p_thread_context, 
             task_handle->task_info->ctx_entry_size);
      _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Exit\n");
      return;
  }
  //swap out odd thread
  //1 3 5 7, start = 1, jump = 2 
  //2 6, start = 2, jump = 4
  //4, start = 4, jump = 8
  for(i=next;i<task_handle->num_accels;i+=jump)
  {
      while(1)
      {
        ret = alf_pal_thread_wait(task_handle->p_task_threads[i].thread, 0);
        if( 0 == ret ) break;
        else if( ret < 0) return;
      } 
      _ALF_DPRINTF_X(_ALF_ERR_LEVEL_TRACE_,"wait thread %d\n",i);
      PTR_TO_ADDR64(&((char *)task_handle->p_thread_context)[ctx_size*i],ctx_addr);
      alf_pal_thread_context_swap(task_handle->p_task_threads[i].thread,0,
                                  ctx_addr);  
      _ALF_DPRINTF_X(_ALF_ERR_LEVEL_TRACE_,"swap thread %d to context %d\n",i,i);
  }
  //merge even thread with odd thread
  //0<-1 2<-3 4<-5 6<-7,jump = 2
  //0<-2 4<-6, jump = 4
  //0<-4, jump = 8 
  for(i=0;i<task_handle->num_accels;i+=jump)
  {
    if(i+next<task_handle->num_accels)
    {
      while(1)
      {
        ret = alf_pal_thread_wait(task_handle->p_task_threads[i+next].thread, 0);
        if( 0 == ret ) break;
        else if( ret < 0) return;
      } 
        _ALF_DPRINTF_X(_ALF_ERR_LEVEL_TRACE_,"wait thread %d\n",i+next);
        PTR_TO_ADDR64(&((char *)task_handle->p_thread_context)[ctx_size*(i+next)],ctx_addr);
        alf_pal_thread_context_merge(task_handle->p_task_threads[i].thread,ctx_addr);  
        _ALF_DPRINTF_X(_ALF_ERR_LEVEL_TRACE_,"merge context %d to thread %d\n",i+next,i);
    }
  }
  alf_sched_task_context_merge(task_handle,depth+1);
  _ALF_DPRINTF(_ALF_ERR_LEVEL_ENTRYEXIT_, "Exit\n");
}

/*
 * scheduler process finished or destroyed task
 */
void alf_sched_task_destroy(alf_instance_t *alf_instance, alf_api_task_t *task_handle)
{
  _ALF_API_DEC_TASK_COUNT(task_handle->alf_handle);

#ifdef _ALF_PLATFORM_HYBRID_
  if (task_handle->state != ALF_API_TASK_STATUS_FINISH) {

    _ALF_API_STD_COND_SIG(task_handle->lock, task_handle->cond, 
                          task_handle->state = ALF_API_TASK_STATUS_DESTROYED);
  }
#endif

  if(NULL == alf_arraylist_enqueue(alf_instance->destroy_task_list, task_handle)) {
    //only fail when list is full and no memory for realloc
    //release task resource here
    alf_int_task_res_destroy(task_handle, 1);
  }
}
