/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/*
 ************************************************************
 * ALF Host API
 ************************************************************
 */

#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include <sys/time.h>
#include <libmisc.h>

#include <alf.h>
#include "alf_common.h"
#include "alf_common_platform.h"
#include "alf_host.h"
#include "alf_debug.h"
#include "alf_trace.h"
#include "alf_stp.h"
#include "alf_hooks_perform_host.h"
#include "alf_arraylist.h"
/*
 ************************************************************
 * Globals
 ************************************************************
 */

static pthread_mutex_t g_alf_shared_instance_lock = PTHREAD_MUTEX_INITIALIZER;
static alf_instance_t* g_alf_shared_instance = NULL;

alf_api_handle_bucket_t g_alf_handle_bucket[ALF_API_ALF_HANDLE_HASH_BUCKET_SIZE];
alf_handle_t g_alf_handle_counter = 1;  // 0 means ALF_NULL_HANDLE. valid ALF handle start from 1
pthread_mutex_t g_alf_handle_bucket_lock  = PTHREAD_MUTEX_INITIALIZER;

/* enable this macro in case you want to make sure all the other APIs
 * to be pure race free with "alf_exit" call.   It will try to get the 
 * g_alf_lock when it checks the correspondent alf_handle.
 * In most cases, I would suggest we disable this macro for better
 * performance
 */

#define _ALF_API_EXIT_RACE_FREE_GLOBAL_LOCK_    1

TRACE_HOST_COUNTERS_STRUCTURE_DEFINE;
TRACE_HOST_TIMERS_STRUCTURE_DEFINE;

/*
 ************************************************************
 * Local Globals
 ************************************************************
 */

/*
 ************************************************************
 * Local APIs
 ************************************************************
 */

#include "alf_api_local.h"
#include "alf_timers.h"

ALF_DEFINE_TIMER(alf_timer);
#ifdef _ALF_PLATFORM_HYBRID_
ALF_DEFINE_TIMER(alf_only_timer);
ALF_DEFINE_EXTERN_TIMER(dacs_timer);
#endif

/*
 ************************************************************
 * APIs
 ************************************************************
 */

//---------------------------------------------------------------------------------------------------
// alf_init
//---------------------------------------------------------------------------------------------------

int alf_init(void *sys_config_info, alf_handle_t * alf_handle_ptr)
{
  int rtn = 0;
  alf_instance_t *alf_instance = NULL;
  alf_api_t *alf_handle = NULL;
  alf_handle_t handle_key;
  
ALF_START_TIMER(alf_timer);
ALF_PRINT_TIMER(alf_timer);

  _ALF_API_STD_ENTRY();

  //ALF trace init
  TRACE_INIT();
  TRACE_HOST_COUNTERS_STRUCTURE_INIT;
  TRACE_HOST_TIMERS_STRUCTURE_INIT;

  //API :alf_init DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_INIT, trace_token, 1, sys_config_info, alf_handle_ptr);

  //STP start
  ALF_STP_INIT();

  if (NULL == alf_handle_ptr) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL alf_handle_ptr\n");
    goto label_alf_init_err;
  }
  
  //allocate alf instance memory
  alf_instance = (alf_instance_t *) calloc(1, sizeof(alf_instance_t));
  if (alf_instance == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf instance allocate memory failed\n");
    goto label_alf_init_err;
  } else
  _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf instance allocate succeed\n");

  ALF_STP_PROF_CREATE("ALF_EXIT", alf_instance->exit_time);
  ALF_STP_PROF_CREATE("ALF_SELECT", alf_instance->sel_time);
  ALF_STP_PROF_CREATE("ALF_SCHEDULE", alf_instance->sched_time);
  ALF_STP_PROF_CREATE("ALF_RUN", alf_instance->run_time);
  ALF_STP_PROF_CREATE("ALF_RELEASE", alf_instance->rel_time);
  ALF_STP_PROF_CREATE("ALF_IDLE", alf_instance->idle_time);
  ALF_STP_PROF_CREATE("ALF_LOCK",alf_instance->lock_time);
  rtn = alf_api_instance_init(alf_instance, sys_config_info);
  if( rtn < 0)
  {
    goto label_alf_init_err;
  }
  
  //allocate alf handle memory
  alf_handle = (alf_api_t *) calloc(1, sizeof(alf_api_t));
  if (alf_handle == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf handle allocate memory failed\n");
    goto label_alf_init_err;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf handle allocate succeed\n");

  rtn = alf_api_handle_init(alf_handle,sys_config_info,alf_instance);

  if( rtn < 0)
  {
    goto label_alf_init_err;
  }

  // create task handle hash table
  rtn = ALF_API_TASK_HASH_CREATE(alf_handle);
  if( rtn < 0)
  {
    goto label_alf_init_err;
  }
	
  //set alf handle type
  //point to global instance
  //put into handle list
  alf_handle->type = ALF_API_HANDLE_ISOLATED;
  alf_handle->instance = alf_instance;
  alf_arraylist_enqueue(alf_instance->alf_handle_list, alf_handle); 

  rtn = ALF_API_ALF_HANDLE_HASH_INSERT(alf_handle, &handle_key);
  if (rtn < 0) {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf create task handle hash failed\n");
    return rtn;
  }	
  alf_handle->self = handle_key;
  alf_handle->next_ptr = NULL;
	
  *alf_handle_ptr = handle_key;

  //API :alf_init DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_INIT, trace_token, 1, rtn);

  _ALF_API_STD_EXIT(rtn);
label_alf_init_err:
  alf_api_handle_destroy(alf_handle);
  alf_api_instance_destroy(alf_instance);
  if (alf_handle_ptr != NULL) 
    *alf_handle_ptr = ALF_NULL_HANDLE;

  //API :alf_init DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_INIT, trace_token, 1, rtn);

  _ALF_API_STD_EXIT(rtn);
}

int alf_init_shared(void *sys_config_info, alf_handle_t * alf_handle_ptr)
{
  int rtn = 0;
  alf_instance_t *alf_instance = NULL;
  alf_api_t *alf_handle = NULL;
  alf_handle_t handle_key;	
  
  _ALF_API_STD_ENTRY();

  if (NULL == alf_handle_ptr) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL alf_handle_ptr\n");
    goto label_alf_init_shared_err;
  }
  
  //allocate alf handle memory
  alf_handle = (alf_api_t *) calloc(1, sizeof(alf_api_t));
  if (alf_handle == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf handle allocate memory failed\n");
    goto label_alf_init_shared_err;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf handle allocate succeed\n");

  pthread_mutex_lock(&g_alf_shared_instance_lock);
  if(g_alf_shared_instance == NULL)
  {  
    //allocate alf instance memory
    alf_instance = (alf_instance_t *) calloc(1, sizeof(alf_instance_t));
    if (alf_instance == NULL) {
      pthread_mutex_unlock(&g_alf_shared_instance_lock);
      rtn = -ALF_ERR_NOMEM;
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf instance allocate memory failed\n");
      goto label_alf_init_shared_err;
    } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf instance allocate succeed\n");

    rtn = alf_api_instance_init(alf_instance, sys_config_info);
    if( rtn < 0)
    {
      pthread_mutex_unlock(&g_alf_shared_instance_lock);
      goto label_alf_init_shared_err;
    }
    g_alf_shared_instance = alf_instance;
  }

  rtn = alf_api_handle_init(alf_handle, sys_config_info, g_alf_shared_instance);
  if( rtn < 0)
  {
    goto label_alf_init_shared_err;
  }

  //set alf handle type
  //point to global instance
  //put into handle list
  alf_handle->type = ALF_API_HANDLE_SHARED;
  alf_handle->instance = g_alf_shared_instance;
  alf_arraylist_enqueue(g_alf_shared_instance->alf_handle_list, alf_handle); 
  pthread_mutex_unlock(&g_alf_shared_instance_lock);
  
  // create task handle hash table
  rtn = ALF_API_TASK_HASH_CREATE(alf_handle);
  if( rtn < 0)
  {
    goto label_alf_init_shared_err;
  }
	
  rtn = ALF_API_ALF_HANDLE_HASH_INSERT(alf_handle, &handle_key);
  if (rtn < 0) {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf create task handle hash failed\n");
    goto label_alf_init_shared_err;
  }	

  alf_handle->self = handle_key;
  alf_handle->next_ptr = NULL;

  *alf_handle_ptr = handle_key;

  _ALF_API_STD_EXIT(rtn);
label_alf_init_shared_err:
  alf_api_handle_destroy(alf_handle);
  alf_api_instance_destroy(alf_instance);
  if (alf_handle_ptr != NULL) *alf_handle_ptr = ALF_NULL_HANDLE;
 
  _ALF_API_STD_EXIT(rtn);
  
}
//---------------------------------------------------------------------------------------------------
// alf_query_system_info
//---------------------------------------------------------------------------------------------------

int alf_query_system_info(alf_handle_t alf_handle, ALF_QUERY_SYS_INFO_T query_info, ALF_ACCEL_TYPE_T accel_type
                          __attribute__ ((unused)), unsigned int *p_query_result)
{
  int rtn = 0;
  alf_instance_t *alf_instance;
  alf_api_t *alf_api_handle;

  _ALF_API_STD_ENTRY();

  //API :alf_query_system_info DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_QUERY_SYSINFO, trace_token, 1, alf_handle, query_info, accel_type, p_query_result);
    
  if (ALF_NULL_HANDLE == alf_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL alf_handle\n");
    goto label_alf_query_system_info_err;
  }

  alf_api_handle = ALF_API_ALF_HANDLE_HASH_ACQUIRE(alf_handle);
  if (NULL == alf_api_handle) {
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Invalid alf_handle\n");
    goto label_alf_query_system_info_err;
  }

  if (query_info < ALF_QUERY_NUM_ACCEL || query_info > ALF_QUERY_ACCEL_ENDIANNESS) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "invalid query info\n");
    goto label_alf_query_system_info_err;
  }


  /* ++++++++++++++++++++++  lock the alf handle data */
  pthread_mutex_lock(&alf_api_handle->lock);
  alf_instance = alf_api_handle->instance;
  switch(query_info) {
    case ALF_QUERY_NUM_ACCEL:     // number of accelerators in total
	  if (accel_type == ALF_ACCEL_TYPE_EDP)
		  query_info = ALF_PAL_Q_NUM_ACCELS_EDP;
	  rtn = alf_pal_query(alf_instance->platform_handle, query_info, p_query_result);
      break;
    case ALF_QUERY_AVAIL_ACCEL:   // number of free available accelerators
      rtn = alf_pal_query(alf_instance->platform_handle, query_info, p_query_result);
      break;
    case ALF_QUERY_USED_ACCEL:    // number of accelerators been used by the runtime
      rtn = alf_pal_query(alf_instance->platform_handle, query_info, p_query_result);
      break;
    case ALF_QUERY_HOST_MEM_SIZE:   // host memory size in 1KB (2^10)
      rtn = alf_pal_query(alf_instance->platform_handle, query_info, p_query_result);
      break;
    case ALF_QUERY_HOST_MEM_SIZE_EXT:    // host memory size in 4TB (2^42)
      rtn = alf_pal_query(alf_instance->platform_handle, query_info, p_query_result);
      break;
    case ALF_QUERY_ACCEL_MEM_SIZE:       // accelerator memory size in 1KB (2^10)
      rtn = alf_pal_query(alf_instance->platform_handle, query_info, p_query_result);
      break;
    case ALF_QUERY_ACCEL_MEM_SIZE_EXT:   // accelerator memory size in 4TB (2^42)
      rtn = alf_pal_query(alf_instance->platform_handle, query_info, p_query_result);
      break;
    case ALF_QUERY_HOST_ADDR_ALIGN:      // memory addr align on host, in exp of 2
      rtn = alf_pal_query(alf_instance->platform_handle, query_info, p_query_result);
      break;
    case ALF_QUERY_ACCEL_ADDR_ALIGN:     // memory addr align on accel, in exp of 2
      rtn = alf_pal_query(alf_instance->platform_handle, query_info, p_query_result);
      break;
    case ALF_QUERY_DTL_ADDR_ALIGN:       // DTL addr align, in exp of 2
      rtn = alf_pal_query(alf_instance->platform_handle, query_info, p_query_result);
      break;
    case ALF_QUERY_HOST_ENDIANNESS:      // 1: big,  0: little
      rtn = alf_pal_query(alf_instance->platform_handle, query_info, p_query_result);
      break;
    case ALF_QUERY_ACCEL_ENDIANNESS:     // 1: big,  0: little
      rtn = alf_pal_query(alf_instance->platform_handle, query_info, p_query_result);
      break;
    default:
      rtn = -ALF_ERR_INVAL;
  }
  /* --------------------  unlock the alf handle data */
  pthread_mutex_unlock(&alf_api_handle->lock);
  if (rtn != 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "invalid query info or alf pal query failed\n");
    goto label_alf_query_system_info_err;
  }

  //API :alf_query_system_info DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_QUERY_SYSINFO, trace_token, 1, *p_query_result, rtn);

  _ALF_API_STD_EXIT(rtn);
label_alf_query_system_info_err:

  //API :alf_query_system_info DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_QUERY_SYSINFO, trace_token, 1, NULL, rtn);

  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_register_error_handler
//---------------------------------------------------------------------------------------------------

int alf_error_handler_register(alf_handle_t alf_handle ,
                               alf_error_handler_t error_handler_function ,
                               void *p_context )
{
  int rtn = 0;                  //-ALF_E_NOSYS;
  alf_api_t *alf_api_handle;

  _ALF_API_STD_ENTRY();

  //API :alf_register_error_handler DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_REGISTER_ERROR_HANDLER, trace_token, 1, alf_handle, error_handler_function, p_context);
  if (ALF_NULL_HANDLE == alf_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL alf_handle\n");
    goto label_alf_register_error_handler_err;
  }

  alf_api_handle = ALF_API_ALF_HANDLE_HASH_ACQUIRE(alf_handle);
  if (NULL == alf_api_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Invalid alf_handle\n");
    goto label_alf_register_error_handler_err;
  }

  pthread_mutex_lock(&alf_api_handle->lock);
  if( NULL == error_handler_function )
  {
    alf_api_handle->err_handler = (alf_error_handler_t)alf_err_default_error_handler;
    alf_api_handle->err_handler_data_ptr = NULL;
  } 
  else
  {
    alf_api_handle->err_handler = error_handler_function;
    alf_api_handle->err_handler_data_ptr = p_context;
  }
  pthread_mutex_unlock(&alf_api_handle->lock);

  //API :alf_register_error_handler DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_REGISTER_ERROR_HANDLER, trace_token, 1, rtn);

  _ALF_API_STD_EXIT(rtn);
label_alf_register_error_handler_err:
  TRACE_POINT_EXIT(_ALF_REGISTER_ERROR_HANDLER, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_exit
//---------------------------------------------------------------------------------------------------

int alf_exit(alf_handle_t alf_handle, ALF_EXIT_POLICY_T exit_policy, int timeout)
{
  int rtn = 0;
  struct timeval now;
  struct timespec wait_time;

  ALF_API_HANDLE_TYPE_T alf_type;
  alf_instance_t *alf_instance;
  alf_api_t *alf_api_handle;

  _ALF_API_STD_ENTRY();

  //API :alf_exit DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_EXIT, trace_token, 1, alf_handle, exit_policy, timeout);

  if (ALF_NULL_HANDLE == alf_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL alf_handle\n");
    goto label_alf_exit_err;
  }

  alf_api_handle = ALF_API_ALF_HANDLE_HASH_ACQUIRE(alf_handle);
  if (NULL == alf_api_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Invalid alf_handle\n");
    goto label_alf_exit_err;
  }

  if (exit_policy != ALF_EXIT_POLICY_FORCE &&
      exit_policy != ALF_EXIT_POLICY_TRY &&
      exit_policy != ALF_EXIT_POLICY_WAIT ) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "invalid exit policy\n");
    goto label_alf_exit_err;
  }

  pthread_mutex_lock(&alf_api_handle->lock);

  //notify scheduler thread to exit
  if (alf_api_handle->state == ALF_API_STATUS_RUNNING) {
    alf_api_handle->state = ALF_API_STATUS_EXITING;
    alf_api_handle->exit_policy = exit_policy;
  }
  alf_instance = alf_api_handle->instance;
  alf_type = alf_api_handle->type;
  pthread_mutex_unlock(&alf_api_handle->lock);
  
  pthread_mutex_lock(&alf_instance->lock);
  alf_instance->gc_flag = 1;
  pthread_mutex_unlock(&alf_instance->lock);

  if (exit_policy == ALF_EXIT_POLICY_WAIT ) {
    _ALF_API_STD_COND_WAIT(alf_api_handle->lock,
                           alf_api_handle->cond,
                           wait_time, now, timeout, 
                           alf_api_handle->task_unfinished != 0, 
                           rtn);
  }

  //if policy is force, we destory all unfinished tasks
  //then we wait for alf handle signal
  if (exit_policy == ALF_EXIT_POLICY_FORCE ) {
    //destroy alf tasks
    rtn = alf_api_task_cancel(alf_api_handle);
    //wait for scheduler to process destroyed tasks
    _ALF_API_STD_COND_WAIT(alf_api_handle->lock,
                           alf_api_handle->cond,
                           wait_time, now, -1, 
                           alf_api_handle->task_unfinished != 0 || 
                           alf_api_handle->task_handle_num != 0,
                           rtn);
  }

  //remove alf handle from list when it's finished
  if (alf_api_handle->task_unfinished == 0 || exit_policy == ALF_EXIT_POLICY_FORCE) {
    // wait the scheduler to leave
    _ALF_API_STD_COND_WAIT(alf_api_handle->lock,
                           alf_api_handle->cond,
                           wait_time, now, -1,
                           alf_api_handle->task_handle_num != 0,
                           rtn);

    alf_arraylist_remove(alf_instance->alf_handle_list, alf_api_handle);
    alf_api_handle_destroy(alf_api_handle);
  } else {
    if (exit_policy == ALF_EXIT_POLICY_WAIT && timeout > 0) {
      rtn = -ALF_ERR_TIME;
    } else
      rtn = -ALF_ERR_BUSY;
    return rtn;
  }
  
  if(alf_type == ALF_API_HANDLE_SHARED)
  {
    pthread_mutex_lock(&g_alf_shared_instance_lock);
    if(g_alf_shared_instance != NULL)
    {  
      alf_instance = g_alf_shared_instance;
      if (alf_arraylist_get_length(alf_instance->alf_handle_list) == 0) {
        //no alf handle left for this alf instance
        //notify scheduler thread to exit
        //the alf_api_scheduler thread may be waiting for a signal if there are no tasks pending
        _ALF_API_STD_COND_SIG(alf_instance->lock, alf_instance->task_cond, 
                              alf_instance->state = ALF_API_STATUS_EXITING)
        pthread_join(alf_instance->scheduler, NULL);
 
        alf_api_instance_destroy(alf_instance);
        g_alf_shared_instance = NULL;
      }
      // shared alf_instance, change gc_flag here
      alf_instance->gc_flag = 0;
    }
    pthread_mutex_unlock(&g_alf_shared_instance_lock);
  }
  else
  {
    //notify scheduler thread to exit
    //the alf_api_scheduler thread may be waiting for a signal if there are no tasks pending
    _ALF_API_STD_COND_SIG(alf_instance->lock, alf_instance->task_cond, 
                             alf_instance->state = ALF_API_STATUS_EXITING)
    pthread_join(alf_instance->scheduler, NULL);
    alf_api_instance_destroy(alf_instance);
  }
  
  //API :alf_exit DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_EXIT, trace_token, 1, rtn);
 
  //STP exit
  ALF_STP_PROF_DUMP(-1,NULL);
  ALF_STP_DEINIT();
 
ALF_END_TIMER(alf_timer);
ALF_PRINT_TIMER(alf_timer);
#ifdef _ALF_PLATFORM_HYBRID_
ALF_SET_TIMER(alf_only_timer, alf_timer);
ALF_SUBTRACT_TIMER(alf_only_timer, dacs_timer);
ALF_PRINT_TIMER(alf_only_timer);
#endif

  _ALF_API_STD_EXIT(rtn);
label_alf_exit_err:

  //API :alf_exit DEBUG trace exit point
  TRACE_HOST_TIMERS_TRACE_POINT;
  TRACE_HOST_COUNTERS_TRACE_POINT;
  TRACE_POINT_EXIT(_ALF_EXIT, trace_token, 1, rtn);

  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_num_instances_set
//---------------------------------------------------------------------------------------------------

int alf_num_instances_set(alf_handle_t alf_handle, unsigned int number_of_instances)
{
  int rtn = 0;

  //API :alf_num_instances_set DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_NUM_INSTANCES_SET, trace_token, 1, alf_handle, number_of_instances);

  alf_api_t *alf_api_handle;
  alf_instance_t *alf_instance;

  if (ALF_NULL_HANDLE == alf_handle) {
    rtn = -ALF_ERR_BADF;
    goto label_alf_num_instances_set_err;
  }

  alf_api_handle = ALF_API_ALF_HANDLE_HASH_ACQUIRE(alf_handle);
  if (NULL == alf_api_handle) {
    rtn = -ALF_ERR_PERM;
    goto label_alf_num_instances_set_err;
  }

  alf_instance = alf_api_handle->instance;
  if (number_of_instances > alf_instance->max_thread_num)
  {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "instance number exceed\n");
    goto label_alf_num_instances_set_err;
  }
  else if( number_of_instances == 0)
  {
    number_of_instances = alf_instance->max_thread_num;
  }
  
  pthread_mutex_lock(&alf_instance->lock);

  //do not allow number change for isolated
  if(alf_api_handle->type == ALF_API_HANDLE_ISOLATED && alf_thread_mgr_num_get(alf_instance))
  {
    rtn = -ALF_ERR_PERM;
    pthread_mutex_unlock(&alf_instance->lock);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf thread number already set\n");
    goto label_alf_num_instances_set_err;
  }

  rtn = alf_thread_mgr_num_set(alf_instance, number_of_instances);

  if (rtn < 0)                  // failure
  {
    pthread_mutex_unlock(&alf_instance->lock);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf threadpool allocate failed\n");
    goto label_alf_num_instances_set_err;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf threadpool allocate succeed\n");

  pthread_mutex_unlock(&alf_instance->lock);

  //API :alf_num_instances_set DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_NUM_INSTANCES_SET, trace_token, 1, alf_instance->accel_num);

  return alf_instance->threadpool.num_threads;

label_alf_num_instances_set_err:

  //API :alf_num_instances_set DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_NUM_INSTANCES_SET, trace_token, 1, rtn);

  _ALF_API_STD_EXIT(rtn);
  return rtn;

}

/*
 ************************************************************
 * Task Management
 ************************************************************
 */

//---------------------------------------------------------------------------------------------------
// alf_task_desc_create
//---------------------------------------------------------------------------------------------------

/*
 * a task info describes all the relevant task information. However, it does not
 * contain any actual data for task_context.
 */
int alf_task_desc_create(alf_handle_t alf_handle, ALF_ACCEL_TYPE_T accel_type
                         __attribute__ ((unused)), alf_task_desc_handle_t * task_desc_handle_ptr)
{
  int rtn = 0;
  alf_api_task_info_t *task_info = NULL;
  alf_instance_t * alf_instance;
  alf_api_t * alf_api_handle;

  _ALF_API_STD_ENTRY();

  //API :alf_task_desc_create DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_TASK_DESC_CREATE, trace_token, 1, alf_handle, accel_type, task_desc_handle_ptr);

  if (ALF_NULL_HANDLE == alf_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL alf handle\n");
    goto label_alf_task_desc_create_err;
  }

  alf_api_handle = ALF_API_ALF_HANDLE_HASH_ACQUIRE(alf_handle);
  if (NULL == alf_api_handle) {
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Invalid alf handle\n");
    goto label_alf_task_desc_create_err;
  }

  if (NULL == task_desc_handle_ptr) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL task info handle ptr\n");
    goto label_alf_task_desc_create_err;
  }

  task_info = (alf_api_task_info_t *) calloc(1, sizeof(alf_api_task_info_t));
  if (task_info == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task info allocate memory failed\n");
    goto label_alf_task_desc_create_err;
  }

  pthread_mutex_lock(&alf_api_handle->lock);
  task_info->alf_handle = (alf_api_t *) alf_api_handle;
  alf_instance = alf_api_handle->instance;
  //query accel memory size for later error checking
  rtn = alf_pal_query(alf_instance->platform_handle, ALF_PAL_Q_ACCEL_MEM_SIZE, 
                      &task_info->accel_mem_size);
  if (rtn < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf pal query accel mem size failed\n");
    pthread_mutex_unlock(&alf_api_handle->lock);
    goto label_alf_task_desc_create_err;
  }
  //from K bytes to bytes
  task_info->accel_mem_size *= 1024;

  //query accel addr alignment for later memory allocation
  rtn = alf_pal_query(alf_instance->platform_handle, ALF_PAL_Q_ACCEL_ADDR_ALIGN, 
                      &task_info->accel_align);
  if (rtn < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "alf pal query accel align failed\n");
    pthread_mutex_unlock(&alf_api_handle->lock);
    goto label_alf_task_desc_create_err;
  }
  pthread_mutex_unlock(&alf_api_handle->lock);

  //alignment should be no less than default size
  //to achieve peak performance for data movement
  if(task_info->accel_align < _ALF_API_ACCEL_DEFAULT_ALIGN)
  {
    task_info->accel_align = _ALF_API_ACCEL_DEFAULT_ALIGN;    
  } 
 
  task_info->pal.context_desc = (alf_pal_data_entry_desc_t *) malloc(_ALF_API_TASK_CTX_DESC_NUM*
                                sizeof(alf_pal_data_entry_desc_t));
  if (task_info->pal.context_desc == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task ctx desc allocate memory failed\n");
    goto label_alf_task_desc_create_err;
  }
  task_info->max_context_desc_num = _ALF_API_TASK_CTX_DESC_NUM;

  //set default accel stack size in case user does not set it 
  task_info->pal.stack_size = _ALF_API_ACCEL_DEFAULT_STACK_SIZE; 
  rtn = pthread_mutex_init(&task_info->lock, NULL);
  if (rtn != 0) {
    rtn = -ALF_ERR_GENERIC;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task desc lock init failed\n");
    goto label_alf_task_desc_create_err;
  }
  
  //set default dt list entries in case user does not set it
  task_info->pal.dt_list_entries = _ALF_DMA_DEFAULT_ELEMENT_NUM;
  
  //set default dt list num in case user does not set it
  task_info->pal.dt_list_num = _ALF_DMA_DEFAULT_LIST_NUM;
 
  //store it in list so that if user do not destroy it explicitly
  //it can be destroyed when alf exit 
  if(NULL == alf_arraylist_enqueue(alf_api_handle->task_info_list,task_info))
  {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "add to tasl info list failed\n");
    goto label_alf_task_desc_create_err;
  }

  *task_desc_handle_ptr = task_info;

  //API :alf_task_desc_create DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_DESC_CREATE, trace_token, 1, *task_desc_handle_ptr, rtn);
  _ALF_API_STD_EXIT(rtn);
label_alf_task_desc_create_err:
  alf_int_task_info_destroy(task_info);

  //API :alf_task_desc_create DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_DESC_CREATE, trace_token, 1, NULL, rtn);
  _ALF_API_STD_EXIT(rtn);
}


//---------------------------------------------------------------------------------------------------
// alf_task_desc_destroy
//---------------------------------------------------------------------------------------------------

int alf_task_desc_destroy(alf_task_desc_handle_t task_desc_handle)
{
  int rtn = 0;
  alf_api_task_info_t *task_info;

  _ALF_API_STD_ENTRY();

  //API :alf_task_desc_destroy DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_TASK_DESC_DESTROY, trace_token, 1, task_desc_handle);

  if (NULL == task_desc_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL task info handle \n");
    goto label_alf_task_desc_destroy_err;
  }

  task_info = (alf_api_task_info_t*) task_desc_handle;
  //search the task info in the list and destroy it
  alf_api_t* alf_handle = task_info->alf_handle;
  pthread_mutex_lock(&alf_handle->lock);
  unsigned int task_info_num = alf_arraylist_get_length(alf_handle->task_info_list);
  unsigned int i;
  for (i = 0; i < task_info_num; i++) {
    
    task_info = (alf_api_task_info_t *) alf_arraylist_dequeue(alf_handle->task_info_list);
    if( task_info == task_desc_handle)
    {
      alf_int_task_info_destroy(task_info);
      break;
    }
    else 
    {
      if(NULL == alf_arraylist_enqueue(alf_handle->task_info_list, task_info))
      {
        pthread_mutex_unlock(&alf_handle->lock);
        rtn = -ALF_ERR_NOMEM;
        _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "add task info to list failed\n");
        goto label_alf_task_desc_destroy_err;
      }
    }
  }
  pthread_mutex_unlock(&alf_handle->lock);

  //API :alf_task_desc_destroy DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_DESC_DESTROY, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
label_alf_task_desc_destroy_err:

  //API :alf_task_desc_destroy DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_DESC_DESTROY, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_task_desc_set_int32
//---------------------------------------------------------------------------------------------------

int alf_task_desc_set_int32(alf_task_desc_handle_t task_desc_handle, ALF_TASK_DESC_FIELD_T field, unsigned int value)
{
  int rtn = 0;
  alf_api_task_info_t *task_info;
  unsigned int total_size;

  _ALF_API_STD_ENTRY();

  //API :alf_task_desc_set_int32 DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_TASK_DESC_SET_INT32, trace_token, 1, task_desc_handle, field, value);

  if (NULL == task_desc_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL task info handle \n");
    goto label_alf_task_desc_set_int_err;
  }

  task_info = (alf_api_task_info_t *) task_desc_handle;
  pthread_mutex_lock(&task_info->lock);
  total_size = _ALF_SIZE_ALIGN_(task_info->pal.parm_ctx_buffer_size, task_info->accel_align) + 
               _ALF_SIZE_ALIGN_(task_info->pal.input_buffer_size, task_info->accel_align) + 
               _ALF_SIZE_ALIGN_(task_info->pal.output_buffer_size, task_info->accel_align) +
               _ALF_SIZE_ALIGN_(task_info->pal.overlapped_buffer_size, task_info->accel_align) + 
               _ALF_SIZE_ALIGN_(task_info->pal.task_context_size, task_info->accel_align) +
               _ALF_SIZE_ALIGN_(task_info->pal.stack_size, task_info->accel_align);
  //for field related to buffer size or stack size
  //check if new size of the field or new size of all buffer and stack exceed accel mem size 
  switch (field) {
  case ALF_TASK_DESC_TASK_TYPE:
  	if (value > ALF_TASK_TYPE_LIGHTWEIGHT)
  	{
  	  rtn = -ALF_ERR_RANGE;
	  _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "field value too big\n");
	  break;
  	}
	task_info->pal.task_type = value;
	break;

  case ALF_TASK_DESC_WB_PARM_CTX_BUF_SIZE:
    if( value > task_info->accel_mem_size ||
        total_size + value - task_info->pal.parm_ctx_buffer_size > task_info->accel_mem_size )
    {
      rtn = -ALF_ERR_RANGE; 
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "field value too big\n");
      break;
    }
    task_info->pal.parm_ctx_buffer_size = value;
    break;
  case ALF_TASK_DESC_WB_IN_BUF_SIZE:
    if( value > task_info->accel_mem_size ||
        total_size + value - task_info->pal.input_buffer_size > task_info->accel_mem_size )
    {
      rtn = -ALF_ERR_RANGE; 
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "field value too big\n");
      break;
    }
    task_info->pal.input_buffer_size = value;
    break;
  case ALF_TASK_DESC_WB_OUT_BUF_SIZE:
    if( value > task_info->accel_mem_size ||
        total_size + value - task_info->pal.output_buffer_size > task_info->accel_mem_size )
    {
      rtn = -ALF_ERR_RANGE; 
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "field value too big\n");
      break;
    }
    task_info->pal.output_buffer_size = value;
    break;
  case ALF_TASK_DESC_WB_INOUT_BUF_SIZE:
    if( value > task_info->accel_mem_size ||
        total_size + value - task_info->pal.overlapped_buffer_size > task_info->accel_mem_size )
    {
      rtn = -ALF_ERR_RANGE; 
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "field value too big\n");
      break;
    }
    task_info->pal.overlapped_buffer_size = value;
    break;
  case ALF_TASK_DESC_NUM_DTL_ENTRIES:
    task_info->pal.dt_list_entries = value;
    break;
  case ALF_TASK_DESC_NUM_DTL:
    if (value > _ALF_MAX_DTL_NUM) {
      rtn = -ALF_ERR_RANGE; 
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "field value too big\n");
      break;
    }
    task_info->pal.dt_list_num = value;
    break;
  case ALF_TASK_DESC_TSK_CTX_SIZE:
    if( value > task_info->accel_mem_size ||
        total_size + value - task_info->pal.task_context_size > task_info->accel_mem_size )
    {
      rtn = -ALF_ERR_RANGE; 
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "field value too big\n");
      break;
    }
    //entries already added can not be shrinked
    else if( value < task_info->ctx_entry_size ) 
    {
      rtn = -ALF_ERR_PERM; 
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task ctx entry can not shrink\n");
      break;
    }
    task_info->pal.task_context_size = value;
    break;
  case ALF_TASK_DESC_PARTITION_ON_ACCEL:
    task_info->pal.task_attr = value;
    break;
  case ALF_TASK_DESC_MAX_STACK_SIZE:
    if( value > task_info->accel_mem_size ||
        total_size + value - task_info->pal.stack_size > task_info->accel_mem_size )
    {
      rtn = -ALF_ERR_RANGE; 
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "field value too big\n");
      break;
    }
    task_info->pal.stack_size = value;
    break;
  default:
    rtn = -ALF_ERR_NOSYS;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "invalid desc field \n");
  }
  pthread_mutex_unlock(&task_info->lock);
  if (0 != rtn) {
    goto label_alf_task_desc_set_int_err;
  }

  //API :alf_task_desc_set_int32 DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_DESC_SET_INT32, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
label_alf_task_desc_set_int_err:

  //API :alf_task_desc_set_int32 DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_DESC_SET_INT32, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_task_desc_set_int64
//---------------------------------------------------------------------------------------------------

int alf_task_desc_set_int64(alf_task_desc_handle_t task_desc_handle,
                            ALF_TASK_DESC_FIELD_T field, unsigned long long value)
{
  int rtn = 0;
  alf_api_task_info_t *task_info;

  _ALF_API_STD_ENTRY();

  //API :alf_task_desc_set_int64 DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_TASK_DESC_SET_INT64, trace_token, 1, task_desc_handle, field, value);

  if (NULL == task_desc_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL task info handle \n");
    goto label_alf_task_desc_set_long_err;
  }
 
  if ( 0 == value && field != ALF_TASK_DESC_ACCEL_LIBRARY_REF_L) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "value is zero \n");
    goto label_alf_task_desc_set_long_err;
  }

  task_info = (alf_api_task_info_t *) task_desc_handle;
  pthread_mutex_lock(&task_info->lock);
  switch (field) {
  case ALF_TASK_DESC_ACCEL_LIBRARY_REF_L:
    if(value != 0)
    {
#ifdef _ALF_64B_
      strncpy(task_info->pal.api_str[ALF_API_KERNEL_LIBRARY], (char *) value, ALF_STRING_TOKEN_MAX);
#else
      strncpy(task_info->pal.api_str[ALF_API_KERNEL_LIBRARY], (char *) (unsigned int) value, ALF_STRING_TOKEN_MAX);
#endif
      task_info->pal.api_str[ALF_API_KERNEL_LIBRARY][ALF_STRING_TOKEN_MAX] = 0;
    }
    else
    {
      task_info->pal.api_str[ALF_API_KERNEL_LIBRARY][0] = 0;
    }  
    break;

  case ALF_TASK_DESC_ACCEL_IMAGE_REF_L:
#ifdef _ALF_64B_
    strncpy(task_info->pal.api_str[ALF_API_KERNEL_IMAGE], (char *) value, ALF_STRING_TOKEN_MAX);
#else
    strncpy(task_info->pal.api_str[ALF_API_KERNEL_IMAGE], (char *) (unsigned int) value, ALF_STRING_TOKEN_MAX);
#endif
    task_info->pal.api_str[ALF_API_KERNEL_IMAGE][ALF_STRING_TOKEN_MAX] = 0;
    break;

  case ALF_TASK_DESC_ACCEL_KERNEL_REF_L:
  case ALF_TASK_DESC_ACCEL_LTS_MAIN_REF_L:
#ifdef _ALF_64B_
    strncpy(task_info->pal.api_str[ALF_API_KERNEL_COMP_KERNEL], (char *) value, ALF_STRING_TOKEN_MAX);
#else
    strncpy(task_info->pal.api_str[ALF_API_KERNEL_COMP_KERNEL], (char *) (unsigned int) value, ALF_STRING_TOKEN_MAX);
#endif
    task_info->pal.api_str[ALF_API_KERNEL_COMP_KERNEL][ALF_STRING_TOKEN_MAX] = 0;
    break;

  case ALF_TASK_DESC_ACCEL_INPUT_DTL_REF_L:
#ifdef _ALF_64B_
    strncpy(task_info->pal.api_str[ALF_API_KERNEL_PREP_INPUT], (char *) value, ALF_STRING_TOKEN_MAX);
#else
    strncpy(task_info->pal.api_str[ALF_API_KERNEL_PREP_INPUT], (char *) (unsigned int) value, ALF_STRING_TOKEN_MAX);
#endif
    task_info->pal.api_str[ALF_API_KERNEL_PREP_INPUT][ALF_STRING_TOKEN_MAX] = 0;
    break;

  case ALF_TASK_DESC_ACCEL_OUTPUT_DTL_REF_L:
#ifdef _ALF_64B_
    strncpy(task_info->pal.api_str[ALF_API_KERNEL_PREP_OUTPUT], (char *) value, ALF_STRING_TOKEN_MAX);
#else
    strncpy(task_info->pal.api_str[ALF_API_KERNEL_PREP_OUTPUT], (char *) (unsigned int) value, ALF_STRING_TOKEN_MAX);
#endif
    task_info->pal.api_str[ALF_API_KERNEL_PREP_OUTPUT][ALF_STRING_TOKEN_MAX] = 0;
    break;

  case ALF_TASK_DESC_ACCEL_CTX_SETUP_REF_L:
#ifdef _ALF_64B_
    strncpy(task_info->pal.api_str[ALF_API_KERNEL_CTX_SETUP], (char *) value, ALF_STRING_TOKEN_MAX);
#else
    strncpy(task_info->pal.api_str[ALF_API_KERNEL_CTX_SETUP], (char *) (unsigned int) value, ALF_STRING_TOKEN_MAX);
#endif
    task_info->pal.api_str[ALF_API_KERNEL_CTX_SETUP][ALF_STRING_TOKEN_MAX] = 0;
    break;

  case ALF_TASK_DESC_ACCEL_CTX_MERGE_REF_L:
#ifdef _ALF_64B_
    strncpy(task_info->pal.api_str[ALF_API_KERNEL_CTX_MERGE], (char *) value, ALF_STRING_TOKEN_MAX);
#else
    strncpy(task_info->pal.api_str[ALF_API_KERNEL_CTX_MERGE], (char *) (unsigned int) value, ALF_STRING_TOKEN_MAX);
#endif
    task_info->pal.api_str[ALF_API_KERNEL_CTX_MERGE][ALF_STRING_TOKEN_MAX] = 0;
    break;


  default:
    rtn = -ALF_ERR_NOSYS;
  }
  pthread_mutex_unlock(&task_info->lock);

  if (0 != rtn) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "invalid desc field \n");
    goto label_alf_task_desc_set_long_err;
  }

  //API :alf_task_desc_set_int64 DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_DESC_SET_INT64, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
label_alf_task_desc_set_long_err:

  //API :alf_task_desc_set_int64 DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_DESC_SET_INT64, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_task_desc_add_ctx_entry
//---------------------------------------------------------------------------------------------------

int alf_task_desc_ctx_entry_add(alf_task_desc_handle_t task_desc_handle ,
                                ALF_DATA_TYPE_T data_type ,
                                unsigned int size )
{
  int rtn = 0;
  alf_api_task_info_t * task_info = task_desc_handle;
  int size_of_data = 0;
  //debug hook
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_TASK_DESC_CTX_ENTRY_ADD,trace_token,1, task_desc_handle, data_type ,size);

  _ALF_API_STD_ENTRY();

  if (NULL == task_desc_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL task info handle \n");
    goto label_alf_task_desc_ctx_entry_add;
  }
 
  _ALF_API_CHECK_DATA_TYPE_SIZE(data_type, size, rtn);
  if ( rtn < 0) {
    //invalid data type should return nosys in this API
    if( size != 0 )
      rtn = -ALF_ERR_NOSYS;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "invalid data type\n");
    goto label_alf_task_desc_ctx_entry_add;
  }

  pthread_mutex_lock(&task_info->lock);
  //get size of data by fetch the last byte of data type
  size_of_data  = size * (ALF_GET_SIZE_OF_TYPE(data_type));
  if( task_info->ctx_entry_size + size_of_data > task_info->pal.task_context_size )
  {
    rtn = -ALF_ERR_NOBUFS;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "context size exceed\n");
    pthread_mutex_unlock(&task_info->lock);
    goto label_alf_task_desc_ctx_entry_add;
  }

  //current capacity exceed, realloc for more memory 
  if(task_info->pal.context_desc_num + 1 > task_info->max_context_desc_num)
  {
    if ( NULL == realloc(task_info->pal.context_desc,
                 (task_info->max_context_desc_num + _ALF_API_TASK_CTX_DESC_NUM)
                 *sizeof(alf_pal_data_entry_desc_t) ) ) {
       rtn = -ALF_ERR_NOMEM;
       _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task info ctx desc realloc failed\n");
       pthread_mutex_unlock(&task_info->lock);
       goto label_alf_task_desc_ctx_entry_add;
    }
    task_info->max_context_desc_num += _ALF_API_TASK_CTX_DESC_NUM; 
  } 
  
  task_info->pal.context_desc[task_info->pal.context_desc_num].size = size;
  task_info->pal.context_desc[task_info->pal.context_desc_num].data_type = data_type;
  task_info->pal.context_desc_num++;

  task_info->ctx_entry_size += size_of_data;
  pthread_mutex_unlock(&task_info->lock);
	
 //API :alf_task_create DEBUG trace exit point
   TRACE_POINT_EXIT(_ALF_TASK_DESC_CTX_ENTRY_ADD,trace_token,1,rtn);
  _ALF_API_STD_EXIT(rtn);
label_alf_task_desc_ctx_entry_add:
 //API :alf_task_create DEBUG trace exit point
   TRACE_POINT_EXIT(_ALF_TASK_DESC_CTX_ENTRY_ADD,trace_token,1,rtn);
  _ALF_API_STD_EXIT(rtn);

}

//---------------------------------------------------------------------------------------------------
// alf_task_create
//---------------------------------------------------------------------------------------------------

/*
 * provides the data for task context
 *  ALF_TASK_MAPPING_ATTR_T can be a bit-wise or of:
 *
 *     ALF_TASK_MAPPING_ATTR_FIXED
 *     ALF_TASK_MAPPING_ATTR_WB_CYCLIC
 *
 */

int alf_task_create(alf_task_desc_handle_t task_desc_handle,
                    void *p_task_context_data,
                    unsigned int num_accelerators,
                    unsigned int tsk_attr, unsigned int wb_dist_size, alf_task_handle_t * p_task_handle)
{
  int rtn = 0;
  alf_instance_t *alf_instance;
  alf_api_t *alf_handle;
  alf_api_task_t *task_handle = NULL;
  alf_api_task_info_t *task_info;

  _ALF_API_STD_ENTRY();

  //API :alf_task_create DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_TASK_CREATE,trace_token,1, task_desc_handle,p_task_context_data,num_accelerators,tsk_attr,wb_dist_size,p_task_handle);

  // check for arg errors
  if (ALF_NULL_HANDLE == p_task_handle) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL task handle ptr\n");
    goto label_alf_task_create_err0;
  }

  if (NULL == task_desc_handle) {
    rtn = -ALF_ERR_NOEXEC;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL task desc handle\n");
    goto label_alf_task_create_err0;
  }
  // check for attribute errors
  if (tsk_attr & ALF_TASK_ATTR_SCHED_FIXED) {
    if (num_accelerators == 0) {
      rtn = -ALF_ERR_INVAL;     // not supported number of accels
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "num accel can not be zero with fixed map\n");
      goto label_alf_task_create_err0;
    }
  } else if (tsk_attr & ALF_TASK_ATTR_WB_CYCLIC) {
    rtn = -ALF_ERR_INVAL;       // not supported number of accels
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "cyclic wb dist must be used with fixed map\n");
    goto label_alf_task_create_err0;
  }

  task_info = (alf_api_task_info_t*)task_desc_handle;

  // lock to make sure the task info is not changed during the call
  // TODO:  move these locks to debug check build version in the future
  pthread_mutex_lock(&task_info->lock);

  // get alf handle  
  alf_handle = task_info->alf_handle;

  // then check if the alf handle init is complete, if it is not, just do it
  alf_instance = alf_handle->instance;
  pthread_mutex_lock(&alf_instance->lock);
  if (alf_thread_mgr_num_get(alf_instance) == 0)       // we have not set the thread number yet
  {
    rtn = alf_thread_mgr_num_set(alf_instance, alf_instance->max_thread_num);
    if (rtn < 0)                // failure
    {
      pthread_mutex_unlock(&alf_instance->lock);
      goto label_alf_task_create_err0;
    }
    else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "alf threadpool allocate succeed\n");
  }                             // if
  pthread_mutex_unlock(&alf_instance->lock);


  // and again check for the num accel requirements for the fixed map case
  if (tsk_attr & ALF_TASK_ATTR_SCHED_FIXED && num_accelerators > alf_thread_mgr_num_get(alf_instance) ) // not allowed
  {
    pthread_mutex_unlock(&task_info->lock);
    rtn = -ALF_ERR_BADR;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "the number of requested accelerators can not be satisfied\n");
    goto label_alf_task_create_err0;
  }
  // for others, if the programmer does not give the number, we just consider it to be max
  if (0 == num_accelerators)
    num_accelerators = alf_thread_mgr_num_get(alf_instance);

  // then try to create the task handle and duplicate the task info
  task_handle = (void *) calloc(1, sizeof(alf_api_task_t));
  if (task_handle == NULL) {
    pthread_mutex_unlock(&task_info->lock);
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task handle allocate memory failed\n");
    goto label_alf_task_create_err;
  }
  else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task handle allocate succeed\n");

  ALF_STP_PROF_CREATE("TASK_DISPATCH",task_handle->dis_time);
  ALF_STP_PROF_CREATE("TASK_GARBAGE", task_handle->gar_time);
  ALF_STP_PROF_CREATE("TASK_WAIT",    task_handle->wait_time);
  ALF_STP_PROF_CREATE("TASK_MERGE",   task_handle->mer_time);
  ALF_STP_PROF_CREATE("TASK_FEED",    task_handle->feed_time);
  ALF_STP_PROF_CREATE("TASK_QUERY",   task_handle->query_time);


  // setup the attributes  
  task_handle->num_accel_req = num_accelerators;        // required
  task_handle->num_accels = 0;  // we have not started yet
  task_handle->attr = tsk_attr;
  if (wb_dist_size == 0)
    task_handle->wb_dist_size = 1;
  else
    task_handle->wb_dist_size = wb_dist_size;
  
  // copy the content of task info and also each piece of memory it point to
  rtn = alf_api_task_info_copy(task_handle, task_desc_handle, p_task_context_data);
  if( rtn < 0 )
  {
    goto label_alf_task_create_err;
  }

  //FIXME should be actual accel number instead of required number
  task_handle->task_info->pal.accels = task_handle->num_accel_req;

  rtn = alf_pal_task_info_check(alf_handle->config_handle, &task_handle->task_info->pal);
  if (rtn < 0) {
    goto label_alf_task_create_err;
  }

  // we can now unlock the task info and check return of info copy 
  pthread_mutex_unlock(&task_info->lock);
  // link back to alf handle
  task_handle->alf_handle = alf_handle;

  //create wb pool
  //wb header and wb parm combined together
  task_handle->wb_pool = alf_wbpool_create(sizeof(alf_api_wb_t)+
                                        task_handle->task_info->pal.parm_ctx_buffer_size,
                                        task_handle->task_info->accel_align);
  if( NULL == task_handle->wb_pool) {
    rtn = -ALF_ERR_NOMEM;
    goto label_alf_task_create_err;
  }
  else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task wb pool allocate succeed\n");

  // create a list for child tasks
  task_handle->child_tasks = alf_arraylist_create(_ALF_API_TASK_DEP_NUM);
  if (NULL == task_handle->child_tasks) {
    rtn = -ALF_ERR_NOMEM;
    goto label_alf_task_create_err;
  }
  else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task child list allocate succeed\n");

  // work block queue
  rtn = alf_api_task_wbq_create(task_handle);
  if (rtn != 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task wbq create failed\n");
    goto label_alf_task_create_err;
  }

  // create the thread array
  task_handle->p_task_threads = (alf_task_thread_t *) calloc(task_handle->num_accel_req, sizeof(alf_task_thread_t));
  if (task_handle->p_task_threads == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task threads allocate memory failed\n");
    goto label_alf_task_create_err;
  }
  else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task thread ptr allocate succeed\n");

#ifdef _ALF_STP_ENABLE_HOST
  unsigned int i;
  for(i=0;i<task_handle->num_accel_req;i++)
  {
    ALF_STP_PROF_CREATE("THREAD_START",task_handle->p_task_threads[i].start_time);
  }
#endif

  //add perfomance hook of ALF_TASK_BEFORE_EXEC_INTERVAL
  TRACE_INTERVAL_BEGIN(_ALF_TASK_BEFORE_EXEC_INTERVAL,task_handle->task_before_exec_token,1);

  task_handle->state = ALF_API_TASK_STATUS_INIT;

  // misc inits for the task
  rtn = pthread_mutex_init(&task_handle->lock, NULL);
  if (rtn != 0) {
    rtn = -ALF_ERR_GENERIC;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task handle lock init failed\n");
    goto label_alf_task_create_err;
  }
  else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task lock init succeed\n");

  // misc inits for the task
  rtn = pthread_mutex_init(&task_handle->gc_lock, NULL);
  if (rtn != 0) {
    rtn = -ALF_ERR_GENERIC;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task handle lock init failed\n");
    goto label_alf_task_create_err;
  }
  else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task lock init succeed\n");

  rtn = pthread_cond_init(&task_handle->cond, NULL);
  if (rtn != 0) {
    rtn = -ALF_ERR_GENERIC;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task handle cond init failed\n");
    goto label_alf_task_create_err;
  }
  else _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task cond init succeed\n");

  pthread_mutex_lock(&alf_handle->lock);
  //enqueue to alf instance task init list
  if (NULL == alf_arraylist_enqueue(alf_instance->init_task_list, task_handle))
  {
    rtn = -ALF_ERR_NOMEM;
    pthread_mutex_unlock(&alf_handle->lock);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task enqueue to init list failed\n");
    goto label_alf_task_create_err;
  }
  //always keep the task handle in ref list until alf instance exit
  if(NULL == alf_arraylist_enqueue(alf_instance->ref_task_list, task_handle))
  {
    rtn = -ALF_ERR_NOMEM;
    pthread_mutex_unlock(&alf_handle->lock);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task enqueue to ref list failed\n");
    goto label_alf_task_create_err;
  }
  //enqueue to alf handle task list
  if(NULL == alf_arraylist_enqueue(alf_handle->task_list, task_handle))
  {
    rtn = -ALF_ERR_NOMEM;
    pthread_mutex_unlock(&alf_handle->lock);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task enqueue to alf task list failed\n");
    goto label_alf_task_create_err;
  }
  
  _ALF_API_INC_TASK_COUNT(alf_handle);
  //the alf_api_scheduler thread may be waiting for a signal if there are no tasks pending
  //so tell it that there is a new task to process
  pthread_mutex_lock(&alf_instance->lock);
  pthread_cond_signal(&alf_instance->task_cond);
  pthread_mutex_unlock(&alf_instance->lock);
  
  pthread_mutex_unlock(&alf_handle->lock);

  // operation of task handle hash table
  // also set task_handle->self, task_handle->next_ptr
  alf_task_handle_t l_task_handle;  
  rtn = ALF_API_TASK_HASH_INSERT(alf_handle, task_handle, &l_task_handle);
  if (rtn < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task enqueue to alf task list failed\n");
    goto label_alf_task_create_err;
  } 
	
  *p_task_handle = l_task_handle;

  //for DEBUG trace 
  PTR_TO_ADDR64(task_handle, task_handle->task_info->pal.task_handle_ea );

  //API :alf_task_create DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_CREATE,trace_token,1, *p_task_handle,rtn);
  //API :alf_task_creates profile counter
  TRACE_HOST_COUNTER_INCREMENT(alf_task_creates,1);

  _ALF_API_STD_EXIT(rtn);


label_alf_task_create_err:
  alf_int_task_res_destroy(task_handle, 0);   
  *p_task_handle = 0;

label_alf_task_create_err0:
  //API :alf_task_create DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_CREATE,trace_token,1,NULL,rtn);
  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_task_event_handler_register
//---------------------------------------------------------------------------------------------------

int alf_task_event_handler_register(alf_task_handle_t task_handle,
                                    int (*task_event_handler) (alf_task_handle_t task_handle,
                                                               ALF_TASK_EVENT_TYPE_T event, void *p_data),
                                    void *p_data, unsigned int data_size, unsigned int event_mask)
{
  int rtn = 0;
  alf_api_task_t *task_api_handle;

  _ALF_API_STD_ENTRY();

  //API :alf_task_event_handler_register DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_TASK_EVENT_HANDLER_REGISTER, trace_token, 1,task_handle, task_event_handler, p_data, data_size, event_mask);
  
  if (ALF_NULL_HANDLE == task_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL task handle\n");
    goto label_alf_task_event_handler_register_err0;
  }

  ALF_API_TASK_HASH_ACQUIRE(task_handle, &task_api_handle);
  if (NULL == task_api_handle) {
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Invalid task handle\n");
    goto label_alf_task_event_handler_register_err0;
  }

  pthread_mutex_lock(&task_api_handle->lock);

  if ( task_api_handle->finalized_flag )
    rtn = -ALF_ERR_PERM;
  else if (task_api_handle->state >= ALF_API_TASK_STATUS_DESTROY)
    rtn = -ALF_ERR_BADF;
	
  if(rtn < 0)
  {
    pthread_mutex_unlock(&task_api_handle->lock);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "event handler register not permitted\n");
    goto label_alf_task_event_handler_register_err;
  }

  task_api_handle->event_handler.callback_func = task_event_handler;
  task_api_handle->event_handler.event_mask = event_mask;

  //copy event handler data for user
  if (data_size > 0) {

    task_api_handle->event_handler.p_data = malloc(data_size);

    if (task_api_handle->event_handler.p_data == NULL) {
      pthread_mutex_unlock(&task_api_handle->lock);
      rtn = -ALF_ERR_NOMEM;
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task event handler data memory allocation failed\n");
      goto label_alf_task_event_handler_register_err;
    } else
      _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task event handler data allocat succeed\n");
    
    task_api_handle->event_handler.data_size = data_size;
    memcpy(task_api_handle->event_handler.p_data, p_data, data_size);
  }

  pthread_mutex_unlock(&task_api_handle->lock);
  ALF_API_TASK_HASH_RESTORE(task_api_handle);

  //API :alf_task_event_handler_register DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_EVENT_HANDLER_REGISTER, trace_token, 1,rtn);
  _ALF_API_STD_EXIT(rtn);
	
label_alf_task_event_handler_register_err:
  if (task_api_handle != NULL && task_api_handle->event_handler.p_data) {
    free(task_api_handle->event_handler.p_data);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task event handler data allocate succeed\n");
  }

  ALF_API_TASK_HASH_RESTORE(task_api_handle);

label_alf_task_event_handler_register_err0:
  //API :alf_task_event_handler_register DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_EVENT_HANDLER_REGISTER, trace_token, 1,rtn);

  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_task_finalize
//---------------------------------------------------------------------------------------------------

int alf_task_finalize(alf_task_handle_t task_handle)
{
  int rtn = 0;
  alf_api_task_t *task_api_handle;
  _ALF_API_STD_ENTRY();

  //API :alf_task_finalize DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_TASK_FINALIZE, trace_token, 1, task_handle);
	
  if (ALF_NULL_HANDLE == task_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL task handle\n");
    goto label_alf_task_finalize_err0;
  }

  ALF_API_TASK_HASH_ACQUIRE(task_handle, &task_api_handle);
  if (NULL == task_api_handle) {
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Invalid task handle\n");
    goto label_alf_task_finalize_err0;
  }
  
  pthread_mutex_lock(&task_api_handle->lock);
  //task is inited, pending, running and not finalized before
  if (task_api_handle->state <= ALF_API_TASK_STATUS_EXEC && !task_api_handle->finalized_flag) {
    task_api_handle->finalized_flag = 1;
    alf_int_task_call_event_handler(task_api_handle, ALF_TASK_EVENT_FINALIZED);
  } else {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task handle already finalized or destroyed\n");
    if(task_api_handle->state >= ALF_API_TASK_STATUS_DESTROY)
      rtn = -ALF_ERR_BADF;
    else if(task_api_handle->finalized_flag)
      rtn = -ALF_ERR_SRCH; 
    pthread_mutex_unlock(&task_api_handle->lock);
    goto label_alf_task_finalize_err;
  }
  pthread_mutex_unlock(&task_api_handle->lock);
	
  ALF_API_TASK_HASH_RESTORE(task_api_handle);
	
  //API :alf_task_finalize DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_FINALIZE, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
	
label_alf_task_finalize_err:
  ALF_API_TASK_HASH_RESTORE(task_api_handle);

label_alf_task_finalize_err0:
  //API :alf_task_finalize DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_FINALIZE, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);

}

//---------------------------------------------------------------------------------------------------
// alf_task_destroy
//---------------------------------------------------------------------------------------------------

int alf_task_destroy(alf_task_handle_t task_handle)
{
  int rtn = 0;
  alf_api_task_t *task_api_handle;

  _ALF_API_STD_ENTRY();

  //API :alf_task_destroy DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_TASK_DESTROY, trace_token, 1, task_handle);

  if (ALF_NULL_HANDLE == task_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL task handle\n");
    goto label_alf_task_destroy_err0;
  }

  rtn = ALF_API_TASK_HASH_ACQUIRE(task_handle, &task_api_handle);
  if (rtn == -ALF_ERR_RANGE) { // invalid task_handle
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Invalid task handle\n");
    goto label_alf_task_destroy_err0;
  }else if(rtn == -ALF_ERR_NODATA) { // task finished
    rtn = 0;
    TRACE_POINT_EXIT(_ALF_TASK_DESTROY, trace_token, 1, rtn);
    _ALF_API_STD_EXIT(rtn);
    return 0;
  }

#ifdef _ALF_PLATFORM_HYBRID_
  // exec_tasks queue works for the tasks which begin to exection.
  //
  // these tasks may have a reference of dataset, then the invocation of alf_dataset_destroy 
  //   following the alf_task_destroy may cause segmentation fault. in this case, the task is marked
  //   by alf_task_destroy at API layer with ALF_API_TASK_STATUS_DESTROY while the Scheduler is executing it.
  //
  // the policy in Hybrid system of alf_task_destroy is that, the tasks with state of ALF_API_TASK_STATUS_EXEC
  //   must firstly enqueue exec_tasks queue, and wait for state changed to ALF_API_TASK_STATUS_DESTROYED marked 
  //   by the Scheduler before the alf_dataset_destroy is invoked. 
  //   if the task has the state with none of ALF_API_TASK_STATUS_EXEC, the task has no chance to reference,
  //   then, the alf_task_destroy is free to leave. 
  //
  // exec_tasks enqueue operation happens in alf_api_task_offspring_destroy
  alf_arraylist_t* exec_tasks;
  exec_tasks = alf_arraylist_create(16);
  if (NULL == exec_tasks) {
    ALF_API_TASK_HASH_RESTORE(task_api_handle);
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "No memory\n");
    TRACE_POINT_EXIT(_ALF_TASK_DESTROY, trace_token, 1, rtn);
    _ALF_API_STD_EXIT(rtn);
  }

  // mark all related tasks with ALF_API_TASK_STATUS_DESTROY
  // and enqueue all tasks with ALF_API_TASK_STATUS_EXEC into exec_tasks.
  rtn = alf_api_task_offspring_destroy(task_api_handle, exec_tasks);

  // wait all related tasks processed by Scheduler
  alf_api_task_t *p_task;
  while ((p_task = (alf_api_task_t*)alf_arraylist_dequeue(exec_tasks)) != NULL) {
    pthread_mutex_lock(&p_task->lock);
    while (p_task->state != ALF_API_TASK_STATUS_DESTROYED && p_task->state != ALF_API_TASK_STATUS_FINISH)
      pthread_cond_wait(&p_task->cond, &p_task->lock);
    pthread_mutex_unlock(&p_task->lock);
  }
  alf_arraylist_destroy(exec_tasks);
#else
  rtn = alf_api_task_offspring_destroy(task_api_handle, NULL);
#endif

  ALF_API_TASK_HASH_RESTORE(task_api_handle);
	
  //API :alf_task_destroy DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_DESTROY, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);

label_alf_task_destroy_err0:
  //API :alf_task_destroy DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_DESTROY, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_task_wait
//---------------------------------------------------------------------------------------------------

int alf_task_wait(alf_task_handle_t task_handle, int time_out)
{
  int rtn = 0;
  struct timeval now;
  struct timespec wait_time;
  alf_api_task_t *task_api_handle;

  _ALF_API_STD_ENTRY();

  //API :alf_task_wait DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_TASK_WAIT, trace_token, 1, task_handle, time_out);

  if (ALF_NULL_HANDLE == task_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Invalid task handle\n");
    goto label_alf_task_wait_err0;	
  }

  rtn = ALF_API_TASK_HASH_ACQUIRE(task_handle, &task_api_handle);
  if (rtn == -ALF_ERR_RANGE) { // Invalid task handle key
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Invalid task handle\n");
    goto label_alf_task_wait_err0;	
  }else if(rtn == -ALF_ERR_NODATA) { // finished task handle
    rtn = 0;
    TRACE_POINT_EXIT(_ALF_TASK_WAIT, trace_token, 1, rtn);
    _ALF_API_STD_EXIT(rtn);
    return rtn;
  }

  if(!task_api_handle->finalized_flag  && task_api_handle->state < ALF_API_TASK_STATUS_DESTROY)
  {
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task not finalized\n");
    goto label_alf_task_wait_err;
  }

#ifdef _ALF_PLATFORM_HYBRID_
  _ALF_API_STD_COND_WAIT(task_api_handle->lock,
                         task_api_handle->cond,
                         wait_time, now,
                         time_out,
                         task_api_handle->state != ALF_API_TASK_STATUS_DESTROYED
                         && task_api_handle->state != ALF_API_TASK_STATUS_FINISH, rtn);
#else
  _ALF_API_STD_COND_WAIT(task_api_handle->lock,
                         task_api_handle->cond,
                         wait_time, now,
                         time_out,
                         task_api_handle->state < ALF_API_TASK_STATUS_FINISH, 
                         rtn);
#endif
 
#ifdef _ALF_PLATFORM_HYBRID_ 
  if(task_api_handle->state >= ALF_API_TASK_STATUS_DESTROYED)
#else
  if(task_api_handle->state >= ALF_API_TASK_STATUS_DESTROY)
#endif
  {
    rtn = -ALF_ERR_NODATA;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task destroyed\n");
    goto label_alf_task_wait_err;
  }
  
  if(task_api_handle->state != ALF_API_TASK_STATUS_FINISH)
  {
    rtn = -ALF_ERR_TIME;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task wait time out\n");
    goto label_alf_task_wait_err;
  }
  //task finished
  else rtn = 0; 

#ifdef _ALF_PLATFORM_HYBRID_  
  // Get dataset, if one has been associated to this task and ALF_TASK_EVENT_FINISHED is not registered,
  // if ALF_TASK_EVENT_FINISHED is registered the dataset will be retrieved by alf_sched_task_stop 
  if (task_api_handle->dataset != NULL && !(task_api_handle->event_handler.event_mask & ALF_TASK_EVENT_FINISHED)) {
    alf_pal_dataset_get_and_wait(task_api_handle->dataset->pal_dataset);
    if (!task_api_handle->dataset_dec) {
      _ALF_API_DEC_DATASET_TASK_COUNT(task_api_handle);
      task_api_handle->dataset_dec = 1;
    }
  }
#endif

  ALF_API_TASK_HASH_RESTORE(task_api_handle);

  //API :alf_task_wait DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_WAIT, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);

label_alf_task_wait_err:
  ALF_API_TASK_HASH_RESTORE(task_api_handle);

label_alf_task_wait_err0:
  //API :alf_task_wait DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_WAIT, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_task_query
//---------------------------------------------------------------------------------------------------

int alf_task_query(alf_task_handle_t task_handle, unsigned int *p_unfinished_wbs, unsigned int *p_total_wbs)
{
  int rtn = 0;
  alf_api_task_t *task_api_handle;

  _ALF_API_STD_ENTRY();

  //API :alf_task_query DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_TASK_QUERY, trace_token, 1, task_handle, p_unfinished_wbs, p_total_wbs);

  if (task_handle == ALF_NULL_HANDLE) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL task handle\n");
    goto label_alf_task_query_err;
  }

  rtn = ALF_API_TASK_HASH_ACQUIRE(task_handle, &task_api_handle);
  if (rtn == -ALF_ERR_RANGE) { // Invalid task handle
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL task handle\n");
    goto label_alf_task_query_err;
  }else if (rtn == -ALF_ERR_NODATA) {// task handle is finished
    rtn = ALF_API_TASK_QUERY_STATUS_FINISHED;
    *p_unfinished_wbs = 0;
    *p_total_wbs = 0;
    return rtn;
  }
  //  Yield the scheduler to prevent starvation if the user thread
  //  is in a tight loop.  (i.e.  while(!done) { alf_task_query() };
  sched_yield();

  pthread_mutex_lock(&task_api_handle->lock);
  if (task_api_handle->state >= ALF_API_TASK_STATUS_DESTROY)
    rtn = -ALF_ERR_NODATA;
  else if (task_api_handle->state == ALF_API_TASK_STATUS_FINISH)
    rtn = ALF_API_TASK_QUERY_STATUS_FINISHED;
  else if (task_api_handle->state < ALF_API_TASK_STATUS_EXEC)
    rtn = ALF_API_TASK_QUERY_STATUS_PENDING;
  else
    rtn = ALF_API_TASK_QUERY_STATUS_RUNNING;

  if(NULL != p_unfinished_wbs)
    *p_unfinished_wbs = task_api_handle->num_wb_pending;
  if(NULL != p_total_wbs)
    *p_total_wbs = task_api_handle->num_wb;

  pthread_mutex_unlock(&task_api_handle->lock);

  ALF_API_TASK_HASH_RESTORE(task_api_handle);	
	
  //API :alf_task_query DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_QUERY, trace_token, 1, *p_unfinished_wbs, *p_total_wbs, rtn);
  _ALF_API_STD_EXIT(rtn);

label_alf_task_query_err:
  //API :alf_task_query DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_QUERY, trace_token, 1, 0, 0, rtn);
  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_task_depends_on
//---------------------------------------------------------------------------------------------------

int alf_task_depends_on(alf_task_handle_t task_handle_dependent, alf_task_handle_t task_handle)
{
  int rtn = 0;
  alf_api_task_t *child = NULL;
  alf_api_task_t *parent = NULL;

  _ALF_API_STD_ENTRY();

  //API :alf_task_depends_on DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_TASK_DEPENDS_ON, trace_token, 1, task_handle_dependent, task_handle);

  if (ALF_NULL_HANDLE == task_handle|| ALF_NULL_HANDLE == task_handle_dependent) {
    rtn = -ALF_ERR_BADF;
    goto label_alf_task_depends_on_err0;
  }

  if (task_handle_dependent == task_handle) {
    rtn = -ALF_ERR_PERM;
    goto label_alf_task_depends_on_err0;
  }

  ALF_API_TASK_HASH_ACQUIRE(task_handle_dependent, &child);
  if (NULL == child) {
    rtn = -ALF_ERR_BADF;
    goto label_alf_task_depends_on_err0;
  }

  // return 0 if parent has been finished.
  rtn = ALF_API_TASK_HASH_ACQUIRE(task_handle, &parent);
  if (rtn == -ALF_ERR_NODATA) { // finished task handle
    rtn = 0;
    ALF_API_TASK_HASH_RESTORE(child);
    TRACE_POINT_EXIT(_ALF_TASK_DEPENDS_ON, trace_token, 1, rtn);
    _ALF_API_STD_EXIT(rtn);
    return 0;
  }else if(rtn == -ALF_ERR_RANGE) {
    rtn = -ALF_ERR_BADF;        // Invalid task handle
    ALF_API_TASK_HASH_RESTORE(child);
    goto label_alf_task_depends_on_err0;
  }

  // TODO: loop check in debug mode
  // now only check for depends on itself
  if ( task_handle == task_handle_dependent )
  {
    rtn = -ALF_ERR_PERM;
    goto label_alf_task_depends_on_err;
  }

  pthread_mutex_lock(&child->lock);
  if (child->state == ALF_API_TASK_STATUS_INIT)
    //only add dependency before child task's first work block enqueued
  {
    pthread_mutex_lock(&parent->lock);
    //add dependency if parent task will not be destroyed
    if (parent->state < ALF_API_TASK_STATUS_DESTROY) {
      //no need to add child and record parent count for finished task
      if(parent->state != ALF_API_TASK_STATUS_FINISH)
      {
        if( NULL != alf_arraylist_enqueue(parent->child_tasks, child) )
        { 
          child->parent_count++;
        }
        else
        {
          rtn = -ALF_ERR_NOMEM;
        }
      }
    }
    else
    {
      rtn = -ALF_ERR_BADF;
    }
    pthread_mutex_unlock(&parent->lock);
  }
  else
  {
    rtn = -ALF_ERR_PERM;
  }
  pthread_mutex_unlock(&child->lock);
  if( rtn < 0 )
  {
    goto label_alf_task_depends_on_err;
  }
	
  ALF_API_TASK_HASH_RESTORE(child);
  ALF_API_TASK_HASH_RESTORE(parent);	
	
  //API :alf_task_depends_on DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_DEPENDS_ON, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);

label_alf_task_depends_on_err:
  ALF_API_TASK_HASH_RESTORE(child);
  ALF_API_TASK_HASH_RESTORE(parent);	
	  
label_alf_task_depends_on_err0:
  //API :alf_task_depends_on DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_TASK_DEPENDS_ON, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);

}

/*
 ************************************************************
 * Work Block Management
 ************************************************************
 */

//---------------------------------------------------------------------------------------------------
// alf_wb_create
//---------------------------------------------------------------------------------------------------

int alf_wb_create(alf_task_handle_t task_handle,
                  ALF_WORK_BLOCK_TYPE_T work_block_type, unsigned int repeat_count, alf_wb_handle_t * p_wb_handle)
{
  int rtn = 0;
  alf_api_t *alf_handle;
  alf_api_task_t *p_task;
  alf_api_wb_t *wb = NULL;
  alf_pal_wb_host_data_t *pal_wb = NULL;
  alf_pal_dataset_handle pal_dataset = NULL;

  _ALF_API_STD_ENTRY();

  //API :alf_wb_create DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_WB_CREATE, trace_token, 1, task_handle, work_block_type, repeat_count, p_wb_handle);

  if (NULL == p_wb_handle) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL wb handle ptr\n");
    goto label_alf_wb_create_err0;
  }

  if (ALF_NULL_HANDLE == task_handle) 
  {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL task handle\n");
    goto label_alf_wb_create_err0;
  }
  
  ALF_API_TASK_HASH_ACQUIRE(task_handle, &p_task);
  if (NULL == p_task)
  {
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Task handle has been destroyed or finished\n");
    goto label_alf_wb_create_err0;
  }
  
  _ALF_API_WB_TASK_CHECK(p_task,rtn);
  if(rtn < 0)
  {
    //should return badf for destroyed task in this API
    if(p_task->state >= ALF_API_TASK_STATUS_DESTROY )
      rtn = -ALF_ERR_BADF; 
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task destroyed or finalized\n");
    goto label_alf_wb_create_err;
  }

  if (p_task->task_info->pal.task_type == ALF_TASK_TYPE_LIGHTWEIGHT)
  {
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "lightweight task can't have work block\n");
    goto label_alf_wb_create_err;
  }

  if ( work_block_type != ALF_WB_SINGLE && work_block_type != ALF_WB_MULTI )
  {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "invalid work block type\n");
    goto label_alf_wb_create_err;
  }

  alf_handle = p_task->alf_handle;

  //calloc will ensure wb->status is init
  wb = alf_wbpool_alloc_wb(p_task->wb_pool);
  if (wb == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "wb handle allocation failed\n");
    goto label_alf_wb_create_err;
  } else
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "wb handle allocate succeed\n");
  
  wb->task = task_handle;

  pal_wb = (alf_pal_wb_host_data_t *) (&wb->pal);
  pal_wb->p_task_info = &p_task->task_info->pal;
  pal_wb->dataset = NULL;
  /* get PAL dataset associated with this task, if any */
  if (p_task->dataset != NULL) {
  	pal_dataset = p_task->dataset->pal_dataset;
        pal_wb->dataset = p_task->dataset->pal_dataset;
  }
  
  //create dtl group if partition on host 
  if(!pal_wb->p_task_info->task_attr) 
  {
    //multi-use wb not permitted  
    if(ALF_WB_MULTI == work_block_type)
    {
      rtn = -ALF_ERR_PERM;
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "invalid wb type\n");
      goto label_alf_wb_create_err;
    } 
    wb->dtl = alf_api_dtl_alloc(alf_handle->dtl_pool);
    if(wb->dtl == NULL)
    {
      rtn = -ALF_ERR_NOMEM;
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "allocate wb dtl failed\n");
      goto label_alf_wb_create_err;
    } 
  }

  if (ALF_WB_SINGLE == work_block_type)
    pal_wb->total_count = 1;
  else {
    if (repeat_count < 1) {
      rtn = -ALF_ERR_INVAL;
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "invalid repeat count\n");
      goto label_alf_wb_create_err;
    }
    pal_wb->total_count = repeat_count;
  }

  *p_wb_handle = wb;
  ALF_API_TASK_HASH_RESTORE(p_task);

  //API :alf_wb_create DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_WB_CREATE, trace_token, 1, *p_wb_handle, rtn);
  _ALF_API_STD_EXIT(rtn);
	
label_alf_wb_create_err:
  alf_int_wb_handle_destroy(wb, p_task);
  ALF_API_TASK_HASH_RESTORE(p_task);
	
label_alf_wb_create_err0:
  //API :alf_wb_create DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_WB_CREATE, trace_token, 1, NULL, rtn);
  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_wb_enqueue
//---------------------------------------------------------------------------------------------------

int alf_wb_enqueue(alf_wb_handle_t wb_handle)
{
  int rtn = 0;
  alf_api_wb_t *wb = wb_handle;
  alf_task_handle_t task_handle;
  alf_api_task_t *task;
  unsigned int usize;

  _ALF_API_STD_ENTRY();

  //API :alf_wb_enqueue DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_WB_ENQUEUE, trace_token, 1, wb_handle);

  if (NULL == wb_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL wb handle\n");
    goto label_alf_wb_enqueue_err0;
  }
  
  if( wb->status != _ALF_API_WB_STATUS_INIT)
  {
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "wb not in init state\n");
    goto label_alf_wb_enqueue_err0;
  }

  task_handle = wb->task;
  ALF_API_TASK_HASH_ACQUIRE(task_handle, &task);
  if (task == NULL) {
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "invalid task_handle!\n");
    goto label_alf_wb_enqueue_err0;
  }
  // I will not enable checking of cur_dtl close as in either way the wb is ok, so better save the extra checks
#if 0
  {
    alf_api_wb_t *wb = (alf_api_wb_t *) wb_handle;

    if ((alf_pal_dtl_handle) (-1) != wb->cur_dtl)       // check if it is an invalid value
    {
      rtn = -ALF_ERR_PERM;
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "A dtl is not finished\n");
      goto label_alf_wb_enqueue_err;
    }
  }
#endif

#ifdef _ALF_PLATFORM_HYBRID_
  /* If accelerator data partitioning, then task must have an associated data set */
  if (task->task_info->pal.task_attr && task->dataset == NULL) {
      rtn = -ALF_ERR_PERM;
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "accelerator partitioning specified and no dataset associated to task\n");
      goto label_alf_wb_enqueue_err;
  }
#endif

  if(wb->dtl != NULL)
  {
    alf_api_dtl_end(wb);
    rtn = alf_pal_wb_setup(&wb->pal, wb->dtl); 
    if (rtn < 0) {
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "pal wb setup failed\n");
      goto label_alf_wb_enqueue_err;
    }
    //should be done before enqueue 
    alf_api_dtl_free(task->alf_handle->dtl_pool,wb->dtl);

    wb->dtl = NULL;

  }

  pthread_mutex_lock(&task->lock);

  if (task->state <= ALF_API_TASK_STATUS_EXEC && !task->finalized_flag) {
    //enlarge to aligned size for dma transfer
    usize = wb->pal.hostdata.parm_size;
    wb->pal.hostdata.parm_size = _ALF_SIZE_ALIGN_(usize, task->task_info->accel_align); 
    
    rtn = alf_api_task_wb_enqueue(task, wb);
    if (rtn < 0) {
      //restore to un-aligned size if enqueue failed
      pthread_mutex_unlock(&task->lock);
      wb->pal.hostdata.parm_size = usize; 
      goto label_alf_wb_enqueue_err;
    }

    if (task->state == ALF_API_TASK_STATUS_INIT)
      task->state = ALF_API_TASK_STATUS_PENDING;
    task->num_wb++;
    task->num_wb_pending++;
  }
  else
  {
    rtn = -ALF_ERR_PERM;
    pthread_mutex_unlock(&task->lock);
    goto label_alf_wb_enqueue_err;
  }
  pthread_mutex_unlock(&task->lock);

  wb->status = _ALF_API_WB_STATUS_ENQ;
 
  ALF_API_TASK_HASH_RESTORE(task);  
	
  //API :alf_wb_enqueue DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_WB_ENQUEUE, trace_token, 1, rtn);
	
  //API :alf_wb_enqueues profile counter
  TRACE_HOST_COUNTER_INCREMENT(alf_wb_enqueues,1);
	
  _ALF_API_STD_EXIT(rtn);
	
label_alf_wb_enqueue_err:
    ALF_API_TASK_HASH_RESTORE(task);

label_alf_wb_enqueue_err0:
  //API :alf_wb_enqueue DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_WB_ENQUEUE, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_wb_parm_add
//---------------------------------------------------------------------------------------------------

int alf_wb_parm_add(alf_wb_handle_t wb_handle,
                    void *pdata, unsigned int size_of_data, ALF_DATA_TYPE_T data_type, unsigned int address_alignment)
{
  int rtn = 0;
  alf_api_wb_t *wb = wb_handle;
  int data_type_size;
  int offset;
  unsigned char *parm_ptr;

  _ALF_API_STD_ENTRY();

  //API :alf_wb_parm_add DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_WB_PARM_ADD, trace_token, 1, wb_handle, pdata, size_of_data, data_type, address_alignment);

  if (NULL == wb_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL wb handle\n");
    goto label_alf_wb_add_parm_err0;
  }

  if (NULL == pdata) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL parm data\n");
    goto label_alf_wb_add_parm_err0;
  }
  
  if( wb->status != _ALF_API_WB_STATUS_INIT)
  {
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "wb not in init state\n");
    goto label_alf_wb_add_parm_err0;
  }
  
  _ALF_API_CHECK_DATA_TYPE_SIZE(data_type, size_of_data, rtn);
  if ( rtn < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "invalid data type or size\n");
    goto label_alf_wb_add_parm_err0;
  }

  if(address_alignment > _ALF_API_WB_PARM_MAX_ALIGN )
  {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "addr alignment too big\n");
    goto label_alf_wb_add_parm_err0;
  }

  alf_api_task_t *p_task;
  ALF_API_TASK_HASH_ACQUIRE((wb->task), &p_task);
  if(p_task == NULL) { 
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "invalid task handle\n");
    goto label_alf_wb_add_parm_err0;
  }
  
  _ALF_API_WB_TASK_CHECK(p_task, rtn);
  if(rtn < 0)
  {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task destroyed or finalized\n");
    goto label_alf_wb_add_parm_err;
  }

  //last byte of data type indicate the type size 
  data_type_size = ALF_GET_SIZE_OF_TYPE(data_type);

  size_of_data *= data_type_size;

  //start from aligned address
  offset = _ALF_SIZE_ALIGN_(wb->pal.hostdata.parm_size, address_alignment) ;

  parm_ptr = wb->pal.parm;

  if(offset + size_of_data > wb->pal.hostdata.p_task_info->parm_ctx_buffer_size )
  {  
    rtn = -ALF_ERR_NOBUFS;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "parm size exceed\n");
    goto label_alf_wb_add_parm_err;
  }
#ifdef _ALF_PLATFORM_HYBRID_
  unsigned int i;
  //do endianness conversion if type is larger than byte
  if(data_type != ALF_DATA_BYTE)
  {
    switch (data_type) 
    {
      case ALF_DATA_BYTE:
        break;
      case ALF_DATA_INT16:
        for(i=0;i<size_of_data/data_type_size;i++)
        {
           *(alf_data_uint16_t*)(parm_ptr+offset+data_type_size*i) = 
           BSWAP_16(*( (alf_data_uint16_t*)pdata+i ) ); 
        }
        break; 
      case ALF_DATA_INT32: 
      case ALF_DATA_FLOAT: 
      case ALF_DATA_ADDR32: 
        for(i=0;i<size_of_data/data_type_size;i++)
        {
           *(alf_data_uint32_t*)(parm_ptr+offset+data_type_size*i) = 
           BSWAP_32(*( (alf_data_uint32_t*)pdata+i ) ); 
        }
        break; 
      case ALF_DATA_INT64: 
      case ALF_DATA_DOUBLE: 
      case ALF_DATA_ADDR64: 
        for(i=0;i<size_of_data/data_type_size;i++)
        {
           *(alf_data_uint64_t*)(parm_ptr+offset+data_type_size*i) = 
           BSWAP_64(*( (alf_data_uint64_t*)pdata+i ) ); 
        }
        break; 
    }
  }
  //copy directly if type is byte
  else
  {
    memcpy(&(parm_ptr)[offset], pdata, size_of_data);
  }
#else //copy directly for ALF Cell
  memcpy(&(parm_ptr)[offset], pdata, size_of_data);
#endif
  wb->pal.hostdata.parm_size = (offset + size_of_data);

  ALF_API_TASK_HASH_RESTORE(p_task);

  //API :alf_wb_parm_add DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_WB_PARM_ADD, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);

label_alf_wb_add_parm_err:
  ALF_API_TASK_HASH_RESTORE(p_task);

label_alf_wb_add_parm_err0:
  //API :alf_wb_parm_add DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_WB_PARM_ADD, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_wb_dtl_begin
//---------------------------------------------------------------------------------------------------

int alf_wb_dtl_begin(alf_wb_handle_t wb_handle, ALF_BUF_TYPE_T buffer_type, unsigned int offset_to_the_local_buffer)
{
  int rtn = 0;

  _ALF_API_STD_ENTRY();

  //API :alf_wb_dtl_begin DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_WB_DTL_SET_BEGIN, trace_token, 1, wb_handle, buffer_type, offset_to_the_local_buffer);

  if (NULL == wb_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL wb handle\n");
    goto label_alf_wb_io_container_begin_err0;
  }
  alf_api_wb_t *wb = (alf_api_wb_t *) wb_handle;
  alf_pal_wb_host_data_t *pal_wb = (alf_pal_wb_host_data_t *)&wb->pal;

  if( wb->status != _ALF_API_WB_STATUS_INIT)
  {
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "wb not in init state\n");
    goto label_alf_wb_io_container_begin_err0;
  }

  alf_api_task_t* p_task;
  ALF_API_TASK_HASH_ACQUIRE(wb->task, &p_task);
  if( p_task == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Invalid task handle\n");
    goto label_alf_wb_io_container_begin_err0;
  }
 
  _ALF_API_WB_TASK_CHECK(p_task, rtn);
  if(rtn < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task detroyed or finalized\n");
    goto label_alf_wb_io_container_begin_err;
  }
  
  //this API is not allowed to use if partition on accel
  if( pal_wb->p_task_info->task_attr )
  {
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "not allowed if partition on accel\n");
    goto label_alf_wb_io_container_begin_err;
  }
  //-1 stands for no opened dtl
  if (NULL != wb->cur_dtl) 
  {
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Another dtl is not finished\n");
    goto label_alf_wb_io_container_begin_err;
  } else {
    switch (buffer_type) {
    case ALF_BUF_IN:
      if(pal_wb->p_task_info->input_buffer_size == 0)
      {
        rtn = -ALF_ERR_BADR;
        goto label_alf_wb_io_container_begin_err;
      }
      if(offset_to_the_local_buffer >= pal_wb->p_task_info->input_buffer_size)
      {
        rtn = -ALF_ERR_2BIG;
        goto label_alf_wb_io_container_begin_err;
      }
      rtn = alf_api_dtl_begin(wb, buffer_type, offset_to_the_local_buffer);
      if(rtn < 0)
        goto label_alf_wb_io_container_begin_err;
      break;

    case ALF_BUF_OUT:
      if(pal_wb->p_task_info->output_buffer_size == 0)
      {
        rtn = -ALF_ERR_BADR;
        goto label_alf_wb_io_container_begin_err;
      }
      if(offset_to_the_local_buffer >= pal_wb->p_task_info->output_buffer_size)
      {
        rtn = -ALF_ERR_2BIG;
        goto label_alf_wb_io_container_begin_err;
      }
      rtn = alf_api_dtl_begin(wb, buffer_type, offset_to_the_local_buffer);
      if(rtn < 0)
        goto label_alf_wb_io_container_begin_err;
      break;

    case ALF_BUF_OVL_IN:
      if(pal_wb->p_task_info->overlapped_buffer_size == 0)
      {
        rtn = -ALF_ERR_BADR;
        goto label_alf_wb_io_container_begin_err;
      }
      if(offset_to_the_local_buffer >= pal_wb->p_task_info->overlapped_buffer_size)
      {
        rtn = -ALF_ERR_2BIG;
        goto label_alf_wb_io_container_begin_err;
      }
      rtn = alf_api_dtl_begin(wb, buffer_type, offset_to_the_local_buffer);
      if(rtn < 0)
        goto label_alf_wb_io_container_begin_err;
      break;

    case ALF_BUF_OVL_OUT:
      if(pal_wb->p_task_info->overlapped_buffer_size == 0)
      {
        rtn = -ALF_ERR_BADR;
        goto label_alf_wb_io_container_begin_err;
      }
      if(offset_to_the_local_buffer >= pal_wb->p_task_info->overlapped_buffer_size)
      {
        rtn = -ALF_ERR_2BIG;
        goto label_alf_wb_io_container_begin_err;
      }
      rtn = alf_api_dtl_begin(wb, buffer_type, offset_to_the_local_buffer);
      if(rtn < 0)
        goto label_alf_wb_io_container_begin_err;
      break;

    case ALF_BUF_OVL_INOUT:
      if(pal_wb->p_task_info->overlapped_buffer_size == 0)
      {
        rtn = -ALF_ERR_BADR;
        goto label_alf_wb_io_container_begin_err;
      }
      if(offset_to_the_local_buffer >= pal_wb->p_task_info->overlapped_buffer_size)
      {
        rtn = -ALF_ERR_2BIG;
        goto label_alf_wb_io_container_begin_err;
      }
      rtn = alf_api_dtl_begin(wb, buffer_type, offset_to_the_local_buffer);
      if(rtn < 0)
        goto label_alf_wb_io_container_begin_err;
      break;

    default:
      rtn = -ALF_ERR_INVAL;
      goto label_alf_wb_io_container_begin_err;
    }
    wb->cur_dtl_buffer_type = buffer_type;
    wb->cur_dtl_offset = offset_to_the_local_buffer;
    wb->cur_dtl_size = 0;
  }

  ALF_API_TASK_HASH_RESTORE(p_task);
	
  //API :alf_wb_dtl_begin DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_WB_DTL_SET_BEGIN, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);

label_alf_wb_io_container_begin_err:
  ALF_API_TASK_HASH_RESTORE(p_task);

label_alf_wb_io_container_begin_err0:
  //API :alf_wb_dtl_begin DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_WB_DTL_SET_BEGIN, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_wb_dtl_entry_add
//---------------------------------------------------------------------------------------------------

int alf_wb_dtl_entry_add(alf_wb_handle_t wb_handle, void *p_address, unsigned int size_of_data,
                         ALF_DATA_TYPE_T data_type)
{
  int rtn = 0;
  unsigned int size_in_bytes;

  _ALF_API_STD_ENTRY();

  //API :alf_wb_dtl_entry_add DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_WB_DTL_SET_ENTRY_ADD, trace_token, 1, wb_handle, p_address, size_of_data, data_type);

  if (NULL == wb_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL wb handle\n");
    goto label_alf_wb_dtl_entry_add_err0;
  }

  if (NULL == p_address) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL dtl entry address\n");
    goto label_alf_wb_dtl_entry_add_err0;
  }
  
  alf_api_wb_t *wb = wb_handle;
  alf_pal_wb_host_data_t *pal_wb = (alf_pal_wb_host_data_t *)&wb->pal;

  if( wb->status != _ALF_API_WB_STATUS_INIT)
  {
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "wb not in init state\n");
    goto label_alf_wb_dtl_entry_add_err0;
  }

  if (NULL == wb->cur_dtl) 
  {
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "No dtl is open for adding data\n");
    goto label_alf_wb_dtl_entry_add_err0;
  }

  alf_api_task_t* p_task;

  ALF_API_TASK_HASH_ACQUIRE(wb->task, &p_task);
  if (p_task == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task destroyed or finalized\n");
    goto label_alf_wb_dtl_entry_add_err0;
  }

  _ALF_API_WB_TASK_CHECK(p_task,rtn);
  if(rtn < 0)
  {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task destroyed or finalized\n");
    goto label_alf_wb_dtl_entry_add_err;
  }
  _ALF_API_CHECK_DATA_TYPE_SIZE(data_type, size_of_data, rtn);
  if ( rtn < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "invalid data type or size\n");
    goto label_alf_wb_dtl_entry_add_err;
  }

  size_in_bytes = size_of_data * (ALF_GET_SIZE_OF_TYPE(data_type) );

  alf_data_addr64_t addr;
  PTR_TO_ADDR64(p_address, addr);

  _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "Entering dataset check\n");
    
  unsigned int i;

  _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task->dataset=%p\n",p_task->dataset);

  /* Is there an associated dataset to compare with this work block */
  if (p_task->dataset != NULL) {

    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "task->dataset != NULL\n");
    
    /* Get data set handle */
    alf_api_dataset_t *dataset = p_task->dataset;

    /* Get size in bytes of the data */
    unsigned int size = size_of_data * (ALF_GET_SIZE_OF_TYPE(data_type));

    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "size=%d, size_of_data=%d, data_type=%d\n",size, size_of_data, data_type);

    /* Get current DTL buffer type and find out R,W,RW */
    ALF_DATASET_ACCESS_MODE_T access_mode;
    switch (wb->cur_dtl_buffer_type) {
    case ALF_BUF_IN:
    case ALF_BUF_OVL_IN:
      access_mode = ALF_DATASET_READ_ONLY;
      break;
    case ALF_BUF_OUT:
    case ALF_BUF_OVL_OUT:
      access_mode = ALF_DATASET_WRITE_ONLY;
      break;
    case ALF_BUF_OVL_INOUT:
    default:
      access_mode = ALF_DATASET_READ_WRITE;
      break;
    }

    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "access_mode=%d\n", access_mode);
    
    /*        |      Dataset       |        */
    /*        |  R   |  W   |  RW  | !RW  | */
    /*        +------+------+------+------+ */
    /* i  R   |  OK  | ERR  |  OK  |  OK  | */
    /* n      +------+------+------+------+ */
    /* p  W   | ERR  |  OK  |  OK  |  OK  | */
    /* u      +------+------+------+------+ */
    /* t  RW  | ERR  | ERR  |  OK  |  OK  | */
    /*        +------+------+------+------+ */
    unsigned char access_mode_valid[] = { 1, 0, 1, 1, /* input r */ 0, 1, 1, 1, /* input w */ 0, 0, 1, 1 /* input rw */ };

    /* Lock the data set before accessing it so it can't change */
    pthread_mutex_lock(&dataset->lock);

    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "dataset->state=%d\n", dataset->state);
    
    /* Check state of the data set */
    switch (dataset->state) {

    case ALF_API_DATASET_STATUS_OPEN:
    case ALF_API_DATASET_STATUS_CLOSED:

      /* For all buffers within this data set */
      for (i = 0; i < alf_arraylist_get_length(dataset->buffers); i++) {

        _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "buffer %d\n", i);
        
        /* Get data set buffer address */
        alf_api_dataset_buffer_t
            * dataset_buffer = (alf_api_dataset_buffer_t *) alf_arraylist_get_element(dataset->buffers, i);

        /* check if the input access_mode is compliant the dataset access_mode */
        int index = access_mode * 4 + dataset_buffer->access_mode;
        _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "access_mode=%d, dataset_buffer->access_mode=%d, index=%d\n", access_mode,
                     dataset_buffer->access_mode, index);
        if (!access_mode_valid[index]) {
          /* Skip this one, and go on to the next */
          _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "continue\n");
          continue;
        }

        /* check if the address and size is in the dataset address and size range */
        _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_,
                     "addr=0x%016llx, size=0x%08x, dataset_buffer->addr=0x%016llx, dataset_buffer->size=0x%016llx\n",
                     addr, size, dataset_buffer->addr, dataset_buffer->size);
        if ((addr >= dataset_buffer->addr && addr <= dataset_buffer->addr + dataset_buffer->size)
            && (addr + size >= dataset_buffer->addr && addr + size <= dataset_buffer->addr + dataset_buffer->size)) {
          /* mark this entry with which buffer it is in */
          _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "success\n");
          goto label_alf_api_dataset_check_success;
        }

      }

      _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "failure\n");

      /* Unlock data set object */
      pthread_mutex_unlock(&dataset->lock);

      /* Failure: Return to the caller */
      rtn = -ALF_ERR_PERM;
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Invalid access_mode, address or address plus size compared to PAL data set\n");
      goto label_alf_wb_dtl_entry_add_err;

    case ALF_API_DATASET_STATUS_ERROR:

      /* Unlock data set object */
      pthread_mutex_unlock(&dataset->lock);

      rtn = -ALF_ERR_INVAL;
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Erroneous data set\n");
      goto label_alf_wb_dtl_entry_add_err;

    default:

      /* Unlock data set object */
      pthread_mutex_unlock(&dataset->lock);

      rtn = -ALF_ERR_GENERIC;
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Internal PAL error\n");
      goto label_alf_wb_dtl_entry_add_err;
    }

    /* handle success here */
  label_alf_api_dataset_check_success:;
  
    /* Unlock data set object */
    pthread_mutex_unlock(&dataset->lock);

  }

  _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "Exiting dataset check\n");
    
  switch (wb->cur_dtl_buffer_type) {
    case ALF_BUF_IN:
      if ( wb->cur_dtl_size + wb->cur_dtl_offset + size_in_bytes > pal_wb->p_task_info->input_buffer_size )
      {
        rtn = -ALF_ERR_NOBUFS;
        _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "buffer size exceed\n");
        goto label_alf_wb_dtl_entry_add_err;
      }
      rtn = alf_api_dtl_entry_add(wb, size_of_data, addr, data_type);
      if ( rtn < 0) {
        _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "pal dtl entry add failed\n");
        goto label_alf_wb_dtl_entry_add_err;
      }
      wb->cur_dtl_size += size_in_bytes;
      break;

    case ALF_BUF_OUT:
      if ( wb->cur_dtl_size + wb->cur_dtl_offset + size_in_bytes > pal_wb->p_task_info->output_buffer_size )
      {
        rtn = -ALF_ERR_NOBUFS;
        _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "buffer size exceed\n");
        goto label_alf_wb_dtl_entry_add_err;
      }
      rtn = alf_api_dtl_entry_add(wb, size_of_data, addr, data_type);
      if ( rtn < 0) {
        _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "pal dtl entry add failed\n");
        goto label_alf_wb_dtl_entry_add_err;
      }
      wb->cur_dtl_size += size_in_bytes;
      break;

    case ALF_BUF_OVL_IN:
      if ( wb->cur_dtl_size + wb->cur_dtl_offset + size_in_bytes > pal_wb->p_task_info->overlapped_buffer_size )
      {
        rtn = -ALF_ERR_NOBUFS;
        _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "buffer size exceed\n");
        goto label_alf_wb_dtl_entry_add_err;
      }
      rtn = alf_api_dtl_entry_add(wb, size_of_data, addr, data_type);
      if ( rtn < 0) {
        _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "pal dtl entry add failed\n");
        goto label_alf_wb_dtl_entry_add_err;
      }
      wb->cur_dtl_size += size_in_bytes;
      break;

    case ALF_BUF_OVL_OUT:
      if ( wb->cur_dtl_size + wb->cur_dtl_offset + size_in_bytes > pal_wb->p_task_info->overlapped_buffer_size )
      {
        rtn = -ALF_ERR_NOBUFS;
        _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "buffer size exceed\n");
        goto label_alf_wb_dtl_entry_add_err;
      }
      rtn = alf_api_dtl_entry_add(wb, size_of_data, addr, data_type);
      if ( rtn < 0) {
        _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "pal dtl entry add failed\n");
        goto label_alf_wb_dtl_entry_add_err;
      }
      wb->cur_dtl_size += size_in_bytes;
      break;

    case ALF_BUF_OVL_INOUT:
      if ( wb->cur_dtl_size + wb->cur_dtl_offset + size_in_bytes > pal_wb->p_task_info->overlapped_buffer_size )
      {
        rtn = -ALF_ERR_NOBUFS;
        _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "buffer size exceed\n");
        goto label_alf_wb_dtl_entry_add_err;
      }
      rtn = alf_api_dtl_entry_add(wb, size_of_data, addr, data_type);
      if ( rtn < 0) {
        _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "pal dtl entry add failed\n");
        goto label_alf_wb_dtl_entry_add_err;
      }
      wb->cur_dtl_size += size_in_bytes;
      break;

    default:
      rtn = -ALF_ERR_INVAL;
      goto label_alf_wb_dtl_entry_add_err;
  }

  ALF_API_TASK_HASH_RESTORE(p_task);
	
  //API :alf_wb_dtl_entry_add DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_WB_DTL_SET_ENTRY_ADD, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
	
label_alf_wb_dtl_entry_add_err:
  ALF_API_TASK_HASH_RESTORE(p_task);

label_alf_wb_dtl_entry_add_err0:
  //API :alf_wb_dtl_entry_add DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_WB_DTL_SET_ENTRY_ADD, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_wb_dtl_end
//---------------------------------------------------------------------------------------------------

int alf_wb_dtl_end(alf_wb_handle_t wb_handle)
{
  int rtn = 0;
  alf_api_task_t *task;

  _ALF_API_STD_ENTRY();

  //API :alf_wb_dtl_end DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_WB_DTL_SET_END, trace_token, 1, wb_handle);

  if (NULL == wb_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL wb handle\n");
    goto label_alf_wb_io_container_end_err0;
  }
  alf_api_wb_t *wb = wb_handle;

  if( wb->status != _ALF_API_WB_STATUS_INIT)
  {
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "wb not in init state\n");
    goto label_alf_wb_io_container_end_err0;
  }

  ALF_API_TASK_HASH_ACQUIRE(wb->task, &task);
  if (task == NULL) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task destroyed or finalized\n");
    goto label_alf_wb_io_container_end_err0;
  }

  _ALF_API_WB_TASK_CHECK(task,rtn);
  if(rtn < 0)
  {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task destroyed or finalized\n");
    goto label_alf_wb_io_container_end_err;
  }

  if (NULL != wb->cur_dtl)
  {
    alf_api_dtl_end(wb);
    wb->cur_dtl = NULL;    // set to an invalid value
  }
  else {
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "No dtl is open for closing\n");
    goto label_alf_wb_io_container_end_err;
  }

  ALF_API_TASK_HASH_RESTORE(task);

  //API :alf_wb_dtl_end DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_WB_DTL_SET_END, trace_token, 1, rtn);

  _ALF_API_STD_EXIT(rtn);
label_alf_wb_io_container_end_err:
  ALF_API_TASK_HASH_RESTORE(task);

label_alf_wb_io_container_end_err0:
  //API :alf_wb_dtl_end DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_WB_DTL_SET_END, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_dataset_create
//---------------------------------------------------------------------------------------------------

int alf_dataset_create(alf_handle_t alf_handle, alf_dataset_handle_t * p_dataset_handle)
{
  int rtn = 0;
  alf_instance_t *alf_instance;
  alf_api_t *handle = NULL;
  alf_api_dataset_t *dataset = NULL;

  /* Standard entry */
  _ALF_API_STD_ENTRY();

  //API :alf_dataset_create DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_DATASET_CREATE, trace_token, 1, alf_handle, p_dataset_handle);

  if (ALF_NULL_HANDLE == alf_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL alf handle\n");
    goto label_alf_dataset_create_err0;
  }

  handle = ALF_API_ALF_HANDLE_HASH_ACQUIRE(alf_handle);
  /* Check ALF runtime object */
  if (NULL == handle) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL alf handle\n");
    goto label_alf_dataset_create_err0;
  }

  /* Check data set handle pointer */
  if (NULL == p_dataset_handle) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL data set handle ptr\n");
    goto label_alf_dataset_create_err0;
  }

  /* Allocate data set object */
  dataset = (alf_api_dataset_t *) calloc(1, sizeof(alf_api_dataset_t));
  if (dataset == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "dataset allocate memory failed\n");
    goto label_alf_dataset_create_err0;
  }

  /* Initialize data set object */
  rtn = pthread_mutex_init(&dataset->lock, NULL);
  if (rtn != 0) {
    rtn = -ALF_ERR_GENERIC;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "data set lock init failed\n");
    goto label_alf_dataset_create_err1;
  }

  dataset->api_handle = handle;
  dataset->state = ALF_API_DATASET_STATUS_OPEN;
  dataset->buffers = alf_arraylist_create(16);
  if (dataset->buffers == NULL) {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "data set buffers array list create failed\n");
    goto label_alf_dataset_create_err2;
  }

  // task_count
  dataset->task_count = 0;

  /* Add data set to ALF api's list of data sets */
  pthread_mutex_lock(&handle->lock);
  alf_arraylist_enqueue(handle->datasets, dataset);
  pthread_mutex_unlock(&handle->lock);

  alf_instance = handle->instance;
  /* Invoke PAL data set create */
  if ((rtn = alf_pal_dataset_create(alf_instance->platform_handle, &dataset->pal_dataset)) < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Internal PAL error\n");
    goto label_alf_dataset_create_err4;
  }

  /* Set data set handle ptr to data set object address */
  *p_dataset_handle = dataset;  // return address of data set

  //API :alf_dataset_create DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_DATASET_CREATE, trace_token, 1, *p_dataset_handle, rtn);
  _ALF_API_STD_EXIT(rtn);
  
label_alf_dataset_create_err4:
  /* Remove dataset from ALF api's list of data sets */
  alf_arraylist_remove(handle->datasets, dataset);
  /* Free buffer list */
  alf_arraylist_destroy(dataset->buffers);
  
label_alf_dataset_create_err2:
  /* Destroy data set mutex */
  pthread_mutex_destroy(&dataset->lock);

label_alf_dataset_create_err1:
  /* Free data set object */
  if (dataset)
    free(dataset);

label_alf_dataset_create_err0:
  /* Set data set handle ptr to NULL */
  *p_dataset_handle = NULL;
  //API :alf_dataset_create DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_DATASET_CREATE, trace_token, 1, NULL, rtn);
  _ALF_API_STD_EXIT(rtn);

}

//---------------------------------------------------------------------------------------------------
// alf_dataset_buffer_add
//---------------------------------------------------------------------------------------------------

int alf_dataset_buffer_add(alf_dataset_handle_t dataset_handle, void *addr, unsigned long long size,
                           ALF_DATASET_ACCESS_MODE_T access_mode)
{
  int rtn = 0;
  alf_api_dataset_t *dataset = NULL;
  alf_api_dataset_buffer_t *dataset_buffer = NULL;
  unsigned int i;

  /* Standard entry */
  _ALF_API_STD_ENTRY();

  //API :alf_dataset_buffer_add DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_DATASET_BUFFER_ADD, trace_token, 1, dataset_handle, addr, size, access_mode);

  /* Check data set handle */
  if (NULL == dataset_handle) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL data set handle\n");
    goto label_alf_dataset_buffer_add_err0;
  }

  /* Set internal data set object pointer */
  dataset = (alf_api_dataset_t *) dataset_handle;

  /* For all existing buffers within this data set - find if any overlap */
  for (i = 0; i < alf_arraylist_get_length(dataset->buffers); i++) {

    /* Get data set buffer address */
    dataset_buffer = (alf_api_dataset_buffer_t *) alf_arraylist_get_element(dataset->buffers, i);

    /* check if the address and size overlaps an existing buffer's address and size */
    alf_data_addr64_t adr;
    PTR_TO_ADDR64(addr, adr);

    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_,
                 "%d addr=0x%016llx, size=0x%016llx, dataset_buffer->addr=0x%016llx, dataset_buffer->size=0x%016llx\n",
                 i, adr, size, dataset_buffer->addr, dataset_buffer->size);
//    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "adr < dataset_buffer->addr = %d\n", (adr < dataset_buffer->addr));
//    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "adr + size > dataset_buffer->addr = %d\n", (adr + size > dataset_buffer->addr));
//    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "adr < dataset_buffer->addr + dataset_buffer->size = %d\n", (adr < dataset_buffer->addr + dataset_buffer->size));
//    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "adr + size > dataset_buffer->addr + dataset_buffer->size = %d\n", (adr + size > dataset_buffer->addr + dataset_buffer->size));

    if ((adr < dataset_buffer->addr && adr + size > dataset_buffer->addr)
        || (adr < dataset_buffer->addr + dataset_buffer->size
            && adr + size > dataset_buffer->addr + dataset_buffer->size)) {
      rtn = -ALF_ERR_INVAL;
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "address and size overlaps an existing buffer's address and size\n");
      goto label_alf_dataset_buffer_add_err0;

    }
  }

  /* Check state of the data set, can a buffer be added? */
  switch (dataset->state) {

  case ALF_API_DATASET_STATUS_OPEN:

    /* Allocate data set buffer object */
    dataset_buffer = (alf_api_dataset_buffer_t *) calloc(1, sizeof(alf_api_dataset_buffer_t));
    if (dataset_buffer == NULL) {
      rtn = -ALF_ERR_NOMEM;
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "dataset buffer allocate memory failed\n");
      goto label_alf_dataset_buffer_add_err0;
    }

    /* Initialize data set buffer */
    PTR_TO_ADDR64(addr, dataset_buffer->addr);
    dataset_buffer->size = size;
    dataset_buffer->access_mode = access_mode;

    /* Add data set buffer to list of data set buffers */
    pthread_mutex_lock(&dataset->lock);
    alf_arraylist_enqueue(dataset->buffers, dataset_buffer);
    pthread_mutex_unlock(&dataset->lock);

    /* Invoke PAL data set buffer add */
    if ((rtn =
         alf_pal_dataset_buffer_add(dataset->pal_dataset, dataset_buffer->addr, dataset_buffer->size,
                                    dataset_buffer->access_mode)) < 0) {
      /* TODO: Clean up previously allocated and acquired resources here! */
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Internal PAL error\n");
      goto label_alf_dataset_buffer_add_err1;

    }

    break;

  case ALF_API_DATASET_STATUS_CLOSED:
  case ALF_API_DATASET_STATUS_ERROR:

    /* Issue error */
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Cannot add additional buffers\n");
    goto label_alf_dataset_buffer_add_err0;

  default:
    rtn = -ALF_ERR_GENERIC;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Internal API error\n");
    goto label_alf_dataset_buffer_add_err0;

  }

  //API :alf_dataset_buffer_add DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_DATASET_BUFFER_ADD, trace_token, 1, rtn);

  _ALF_API_STD_EXIT(rtn);

label_alf_dataset_buffer_add_err1:

  /* Remove data set buffer from list of data set buffers */
  alf_arraylist_remove(dataset->buffers, dataset_buffer);

  /* Free data set buffer object */
  if (dataset_buffer)
    free(dataset_buffer);

label_alf_dataset_buffer_add_err0:

  /* Set the state to ERROR */
  dataset->state = ALF_API_DATASET_STATUS_ERROR;

  //API :alf_dataset_buffer_add DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_DATASET_BUFFER_ADD, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_task_dataset_associate
//---------------------------------------------------------------------------------------------------

int alf_task_dataset_associate(alf_task_handle_t task_handle, alf_dataset_handle_t dataset_handle)
{
  int rtn = 0;
  alf_api_task_t *task = NULL;
  alf_api_dataset_t *dataset = NULL;

  /* Standard entry */
  _ALF_API_STD_ENTRY();

  //API :alf_task_dataset_associate DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_DATASET_ASSOCIATE, trace_token, 1, task_handle, dataset_handle);

  if (ALF_NULL_HANDLE == task_handle) {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL task handle\n");
    goto label_alf_task_dataset_associate_err0;
  }
 

  ALF_API_TASK_HASH_ACQUIRE(task_handle, &task);
  /* Check data set handle */
  if (NULL == task) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Invalid task handle\n");
    goto label_alf_task_dataset_associate_err0;
  }

  /* Check data set handle */
  if (NULL == dataset_handle) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL data set handle\n");
    goto label_alf_task_dataset_associate_err;
  }

  /* Set internal data set object pointer */
  dataset = (alf_api_dataset_t *) dataset_handle;

  /* Check if task already has a data set associate with it */
  if (task->dataset != NULL) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Task already associated to data set\n");
    goto label_alf_task_dataset_associate_err;
  }

  /* Check if task is in a state to allow association, that is, no workblocks have been enqueued on for this task */
  if (task->state != ALF_API_TASK_STATUS_INIT) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Task already has workblocks enqueued\n");
    goto label_alf_task_dataset_associate_err;
  }

  /* Lock the data set before updating and accessing it */
  pthread_mutex_lock(&dataset->lock);

  /* Check state of the data set */
  switch (dataset->state) {

  case ALF_API_DATASET_STATUS_OPEN:
    /* Set the state to closed, so no more buffers can be added */
    dataset->state = ALF_API_DATASET_STATUS_CLOSED;
    
    /* Indicate to PAL dataset that all buffers have ended */
    alf_pal_dataset_close(dataset->pal_dataset);

#ifdef ASSOCIATE_DATASET_TO_ALL_MIDS
    /* Put the PAL dataset to the accelerators */
    alf_pal_dataset_put_no_wait(dataset->pal_dataset);
#endif    

    /* drop down through to closed state */

  case ALF_API_DATASET_STATUS_CLOSED:
    _ALF_API_INC_DATASET_TASK_COUNT(dataset);
    break;

  case ALF_API_DATASET_STATUS_ERROR:
    /* Unlock data set object */
    pthread_mutex_unlock(&dataset->lock);

    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Erroneous data set\n");
    goto label_alf_task_dataset_associate_err;

  default:
    /* Unlock data set object */
    pthread_mutex_unlock(&dataset->lock);

    rtn = -ALF_ERR_GENERIC;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Internal PAL error\n");
    goto label_alf_task_dataset_associate_err;

  }

  /* Unlock data set object */
  pthread_mutex_unlock(&dataset->lock);
  /* Lock task to prevent scheduler from colliding these task updates */
  pthread_mutex_lock(&task->lock);

  /* Set task to point to data set */
  task->dataset = dataset;

  /* Unlock task to allow scheduler access to task */
  pthread_mutex_unlock(&task->lock);
 
  ALF_API_TASK_HASH_RESTORE(task);
	
  //API :alf_task_dataset_associate DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_DATASET_ASSOCIATE, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
	
label_alf_task_dataset_associate_err:
  ALF_API_TASK_HASH_RESTORE(task);

label_alf_task_dataset_associate_err0:
  //API :alf_task_dataset_associate DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_DATASET_ASSOCIATE, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
}

//---------------------------------------------------------------------------------------------------
// alf_dataset_destroy
//---------------------------------------------------------------------------------------------------

int alf_dataset_destroy(alf_dataset_handle_t dataset_handle)
{
  int rtn = 0;
  alf_api_dataset_t *dataset = NULL;
  unsigned int i;
  void *rtne;

  /* Standard entry */
  _ALF_API_STD_ENTRY();

  //API :alf_dataset_destroy DEBUG trace entry point
  TRACE_INTERVAL_TOKEN_ARGUMENT(trace_token);
  TRACE_POINT_ENTRY(_ALF_DATASET_DESTROY, trace_token, 1, dataset_handle);

  /* Check data set handle */
  if (NULL == dataset_handle) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL data set handle\n");
    goto label_alf_dataset_destroy_err0;
  }

  /* Set internal data set object pointer */
  dataset = (alf_api_dataset_t *) dataset_handle;

#ifdef _ALF_PLATFORM_HYBRID_
  /* Lock the data set before updating and accessing it */
  pthread_mutex_lock(&dataset->lock);
  if ((int)dataset->task_count > 0) {
    pthread_mutex_unlock(&dataset->lock);
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Dataset should not be destroyed\n");
    goto label_alf_dataset_destroy_err0;
  }
  /* Unlock data set object */
  pthread_mutex_unlock(&dataset->lock);
#endif

  /* Remove data set from api's list of data sets */
  pthread_mutex_lock(&dataset->api_handle->lock);
  if ((rtne = alf_arraylist_remove(dataset->api_handle->datasets, dataset)) == NULL) {
    pthread_mutex_unlock(&dataset->api_handle->lock);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Internal API error\n");
    goto label_alf_dataset_destroy_err0;
  }
  pthread_mutex_unlock(&dataset->api_handle->lock);

  /* Invoke PAL data set destroy */
  if ((rtn = alf_pal_dataset_destroy(dataset->pal_dataset)) < 0) {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Internal API error\n");
    goto label_alf_dataset_destroy_err0;
  }

  /* Set the PAL data set address to NULL, that is, it is not in use */
  dataset->pal_dataset = NULL;

  /* For all buffers within this data set */
  for (i = 0; i < alf_arraylist_get_length(dataset->buffers); i++) {

    /* Get data set buffer address */
    alf_api_dataset_buffer_t *dataset_buffer =
        (alf_api_dataset_buffer_t *) alf_arraylist_get_element(dataset->buffers, i);

    /* Free data set buffer */
    free(dataset_buffer);
  }
  alf_arraylist_destroy(dataset->buffers);

  /* Free data set object */
  free(dataset);

  //API :alf_dataset_destroy DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_DATASET_DESTROY, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);
 
label_alf_dataset_destroy_err0:
  //API :alf_dataset_destroy DEBUG trace exit point
  TRACE_POINT_EXIT(_ALF_DATASET_DESTROY, trace_token, 1, rtn);
  _ALF_API_STD_EXIT(rtn);

}
/*
 * alf_wb_sync
 */
int alf_wb_sync (alf_task_handle_t task_handle_ptr, 
                 ALF_SYNC_TYPE_T sync_type, 
                 int (*sync_callback_func)( alf_wb_sync_handle_t sync_handle, void* p_context), 
                 void* p_context, 
                 unsigned int context_size,
                 alf_wb_sync_handle_t  *p_sync_handle) 
{
  alf_api_task_t* task_handle;
  alf_wb_sync_t *sync_wb  = NULL;
  alf_api_wb_t *wb = NULL;
  int rtn;
  
  if (ALF_NULL_HANDLE == task_handle_ptr) 
  {
    rtn = -ALF_ERR_BADF;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL task handle\n");
    goto label_alf_wb_sync_err0;
  }

  if (NULL == p_sync_handle) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL sync handle\n");
    goto label_alf_wb_sync_err0;
  }
 
  ALF_API_TASK_HASH_ACQUIRE(task_handle_ptr, &task_handle);
  if (NULL == task_handle) 
  {
    rtn = -ALF_ERR_PERM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "Invalid task handle\n");
    goto label_alf_wb_sync_err0;
  }

  if(sync_type != ALF_SYNC_BARRIER &&
     sync_type != ALF_SYNC_NOTIFY )   
  {
    rtn = -ALF_ERR_INVAL; 
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_,"Invalid sync type\n");
    goto label_alf_wb_sync_err;
  }

  if(sync_callback_func != NULL)
  {
    if(context_size > 0 && p_context == NULL)
    {
      rtn = -ALF_ERR_INVAL;
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_,"Invalid context size\n");
      goto label_alf_wb_sync_err;
    }  
  }

  wb = calloc(1,sizeof(alf_api_wb_t));

  if (wb == NULL)
  {
    rtn = -ALF_ERR_NOMEM;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_,"wb allocation failed\n");
    goto label_alf_wb_sync_err;
  }

  wb->type = _ALF_WB_SYNC;
  //we use pal as place holder of sync wb
  sync_wb = (alf_wb_sync_t *)&wb->pal; 
  if ((rtn = pthread_mutex_init(&sync_wb->_cond_lock, NULL)) != 0)
  {
    rtn = -ALF_ERR_GENERIC;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_,"sync mutex init failed\n");
    goto label_alf_wb_sync_err;
  }

  if ((rtn = pthread_cond_init(&sync_wb->_cond, NULL)) != 0)
  {
    rtn = -ALF_ERR_GENERIC;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_,"sync cond init failed\n");
    goto label_alf_wb_sync_err;
  }

  sync_wb->type = sync_type;
  sync_wb->callback_func = sync_callback_func;

  if( sync_callback_func != NULL && context_size > 0)
  {
    sync_wb->context_size = context_size;
    sync_wb->p_context = malloc(context_size);
    if (sync_wb->p_context == NULL)
    {
      rtn = -ALF_ERR_NOMEM;
      _ALF_DPRINTF(_ALF_ERR_LEVEL_API_,"sync context allocation failed\n");
      goto label_alf_wb_sync_err;
    }
    memcpy(sync_wb->p_context,p_context,context_size);
  }
  
  sync_wb->state = _ALF_SYNC_UNFINISHED;

  pthread_mutex_lock(&task_handle->lock);

  if (task_handle->state <= ALF_API_TASK_STATUS_EXEC && !task_handle->finalized_flag) {
    
    rtn = alf_api_task_sync_wb_enqueue(task_handle, wb);
    if (rtn < 0) {
      pthread_mutex_unlock(&task_handle->lock);
      goto label_alf_wb_sync_err;
    }
    if (task_handle->state == ALF_API_TASK_STATUS_INIT)
      task_handle->state = ALF_API_TASK_STATUS_PENDING;
  }
  else
  {
    if(task_handle->state >= ALF_API_TASK_STATUS_DESTROY )
      rtn = -ALF_ERR_BADF; 
    else
      rtn = -ALF_ERR_PERM;
    pthread_mutex_unlock(&task_handle->lock);
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "task destroyed or finalized\n");
    goto label_alf_wb_sync_err;
  }
  pthread_mutex_unlock(&task_handle->lock);

  //FIXME store wb somewhere for garbage collection
  if(NULL == alf_arraylist_enqueue(task_handle->alf_handle->sync_wbq,wb))
  {
    _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "sync wb enqueue to garbage queue failed\n");
    rtn = -ALF_ERR_NOMEM;
    goto label_alf_wb_sync_err;
  }
  _ALF_DPRINTF(_ALF_ERR_LEVEL_TRACE_, "sync wb enqueued to garbage queue\n");
  
  *p_sync_handle = sync_wb;
  
  ALF_API_TASK_HASH_RESTORE(task_handle);
	
  return 0;

label_alf_wb_sync_err:
  ALF_API_TASK_HASH_RESTORE(task_handle);
	
label_alf_wb_sync_err0:
  if(wb)
  {
    pthread_mutex_destroy((void*)&sync_wb->_cond_lock);
    pthread_cond_destroy((void*)&sync_wb->_cond);
    if(sync_wb->p_context)
    {
      free(sync_wb->p_context);
    }
    free(wb);
  }

  if(p_sync_handle != NULL)
  {
    *p_sync_handle = NULL;
  }

  return rtn;
}

/* 
 * alf_wb_sync_wait
 */
int alf_wb_sync_wait (alf_wb_sync_handle_t sync_handle, int time_out)
{
  int rtn=0;
  struct timeval now;
  struct timespec wait_time;

  if (NULL == sync_handle) {
    rtn = -ALF_ERR_INVAL;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "NULL sync handle\n");
    goto label_alf_wb_sync_wait_err;
  }
  
  alf_wb_sync_t *sync_wb = sync_handle;

  _ALF_API_STD_COND_WAIT(sync_wb->_cond_lock,
                         sync_wb->_cond,
                         wait_time, now,
                         time_out,
                         sync_wb->state != _ALF_SYNC_FINISHED, rtn);
  
  if(sync_wb->state != _ALF_SYNC_FINISHED)
  {
    rtn = -ALF_ERR_TIME;
    _ALF_DPRINTF(_ALF_ERR_LEVEL_API_, "sync wait time out\n");
    goto label_alf_wb_sync_wait_err;
  }
  //task finished
  else rtn = 0; 

label_alf_wb_sync_wait_err:
  return rtn;
}

const char* alf_strerror(int error_code)
{
  error_code = -error_code;
  
  switch (error_code)
  {
  case 0:
  	return "OK";
	
  case ALF_ERR_PERM:
  	return "No permission";
	
  case ALF_ERR_SRCH:
  	return "No such task";
	
  case ALF_ERR_2BIG:
  	return "I/O buffer request exceeds limitations";
	
  case ALF_ERR_NOEXEC:
  	return "Cannot execute task";
	
  case ALF_ERR_BADF:
  	return "Bad handle";
	
  case ALF_ERR_AGAIN:
  	return "Try again";
	
  case ALF_ERR_NOMEM:
  	return "Out of memory";
	
  case ALF_ERR_FAULT:
  	return "Invalid address";
	
  case ALF_ERR_BUSY:
  	return "Resource busy";
	
  case ALF_ERR_INVAL:
  	return "Invalid argument";
	
  case ALF_ERR_RANGE:
  	return "Out of range";
	
  case ALF_ERR_NOSYS:
  	return "Function not implemented";
	
  case ALF_ERR_BADR:
  	return "Resource request cannot be fulfilled";
	
  case ALF_ERR_NODATA:
  	return "No more data available";
	
  case ALF_ERR_TIME:
  	return "Time out";
	
  case ALF_ERR_COMM:
  	return "Communications error";
	
  case ALF_ERR_PROTO:
  	return "Internal protocol error";
	
  case ALF_ERR_BADMSG:
  	return "Unrecognized message";
	
  case ALF_ERR_OVERFLOW:
  	return "Overflow";

  case ALF_ERR_INCOMPAT:
  	return "Accelerator incompatibility";
	
  case ALF_ERR_NOBUFS:
  	return "No buffer space available";
	
  case ALF_ERR_ACCEL:
  	return "Generic accelerator error";

  default:
  	return "Unrecognized error code";
  }
}

//---------------------------------------------------------------------------------------------------
// alf_num_instances_query
//---------------------------------------------------------------------------------------------------

int alf_num_instances_query(alf_handle_t alf_handle)
{
  int rtn = 0;

  /* Standard entry */
  _ALF_API_STD_ENTRY();

  alf_api_t *alf_api_handle;
  alf_instance_t *alf_instance;

  if (ALF_NULL_HANDLE == alf_handle) {
    rtn = -ALF_ERR_BADF;
    goto label_alf_num_instances_query_err;
  }
  
  alf_api_handle = ALF_API_ALF_HANDLE_HASH_ACQUIRE(alf_handle);
  if (NULL == alf_api_handle) {
    rtn = -ALF_ERR_PERM;
    goto label_alf_num_instances_query_err;
  }

  alf_instance = alf_api_handle->instance;

  return alf_thread_mgr_num_get(alf_instance);

label_alf_num_instances_query_err:

  _ALF_API_STD_EXIT(rtn);
  return rtn;

}
