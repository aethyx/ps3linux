/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef __ALF_ARRAYLIST_H_INC__
#define __ALF_ARRAYLIST_H_INC__

#include <pthread.h>
#include "alf_common.h"

//********************************************************
// Data Structures
//********************************************************

/**
 * alf_arraylist_t
 *
 * This data structure is a loop arraylist container, which also provides thread-safe
 * support by mutex.
 *
 * lock:        Pthread lock of the queue
 * length:      Length of the array list
 * front_index: Index of from of the loop arraylist.
 * rear_index:  Rear of the loop arraylist.
 * capacity:    Capacity of the loop arraylist.
 * data_ptr:    Effective address of the data pointer array which contains the
                arraylist element pointer.
 */
typedef struct alf_arraylist {
  pthread_mutex_t lock;
  volatile unsigned int length; // cached value
  volatile unsigned int front_index;
  volatile unsigned int rear_index;
  volatile unsigned int capacity;
  void **data_ptr;
  struct alf_arraylist *next;
} alf_arraylist_t;

typedef struct alf_arraylist_nl {

  pthread_mutex_t lock;
  volatile unsigned int capacity;
#ifdef _ALF_64B_
  char _pad_1_[4]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif
  alf_arraylist_t *head;
  alf_arraylist_t *tail;
  alf_arraylist_t *free;
/*#ifdef _ALF_64B_
  char _pad_2_[8]; //pad inserted to prevent automatic compiler padding to maintain binary compatibility
#endif*/

} alf_arraylist_nl_t;
//********************************************************
// APIs
//********************************************************

/**
 * Arraylist create routine.
 *
 * This function creates an arraylist with "capacity" number elements.
 *
 * Parameters:
 * capacity[IN]: Expected capacity of the arraylist.
 * 
 * Return Values:
 * The address of the resulting arraylist is returned.
 */

alf_arraylist_t *alf_arraylist_create(unsigned int capacity);
alf_arraylist_nl_t *alf_arraylist_create_nl(unsigned int capacity);

/**
 * Arraylist enqueue element at the end routine.
 *
 * This function adds a data element into the end of the arraylist, and returns
 * the data element after insertion. If there are insufficient space to
 * add this data element to the arraylist then the arraylist is doubled in size
 * before inserting the data element.
 *
 * Parameters:
 * al[IN]: Pointer to a arraylist.
 * data[IN]: Pointer to data element which needed to be enqueued.
 *
 * Return Values:
 * Address to data element which was enqueued. NULL is returned if any errors are encountered
 *
 */

void *alf_arraylist_enqueue(alf_arraylist_t * al, void *data);
void *alf_arraylist_enqueue_nl(alf_arraylist_nl_t * al_nl, void *data);

/**
 * Arraylist dequeue element from the front routine.
 *
 * This function removes the first data element from arraylist, and return it.
 *
 * Parameter:
 * al[IN]: Pointer to the arraylist.
 *
 * Return Values:
 * Address of the first data element. NULL is returned if the is empty.
 *
 */

void *alf_arraylist_dequeue(alf_arraylist_t * al);
void *alf_arraylist_dequeue_nl(alf_arraylist_nl_t * al_nl);

/**
 * Arraylist dequeue element from the end routine.
 *
 * This function removes the last data element from arraylist, and return it.
 *
 * Parameter:
 * al[IN]: Pointer to the arraylist.
 *
 * Return Values:
 * Address of the last data element. NULL is returned if the arraylist is empty.
 *
 */

void *alf_arraylist_dequeue_from_end(alf_arraylist_t * al);

/**
 * Arraylist remove element by value routine.
 * 
 * This function removes an data element from the arraylist, and returns it.
 * 
 * Parameter:
 * al[IN]: Pointer to the arraylist
 * data[IN]: Pointer to the data element to be removed
 * 
 * Return Values:
 * Address of the data element that was removed. NULL is returned if the data element is not found in the arraylist.
 * 
 */

void *alf_arraylist_remove(alf_arraylist_t * al, void *data);

/**
 * Arraylist remove element by index routine.
 * 
 * This function removes an data element from the arraylist at a specific index, and returns it.
 * 
 * Parameter:
 * al[IN]: Pointer to the arraylist
 * index[IN]: Index for the expected data element from 0 to length-1.
 * 
 * Return Values:
 * Address of the data element that was removed. NULL is returned if any errors are encountered.
 * 
 */

void *alf_arraylist_remove_element(alf_arraylist_t * al, unsigned int index);

/**
 * Arraylist get front element routine
 * 
 * This function gets the data element from the arraylist at the front and returns it.
 * This is equivlaent to arraylist dequeue, but the element is not removed from the list.
 * Since the arraylist is not modified, no locks are used.
 * 
 * Parameters:
 * al[IN]: Pointer to the arraylist.
 * 
 * Return value:
 * Address of the expected data element. NULL is returns for a empty list.
 */
void *alf_arraylist_get_front(alf_arraylist_t * al);
void *alf_arraylist_get_front_nl(alf_arraylist_nl_t * al);

/**
 * Arraylist get rear element routine
 * 
 * This function gets the data element from the arraylist at the rear and returns it.
 * This is equivlaent to arraylist dequeue_from_end, but the element is not removed from the list.
 * Since the arraylist is not modified, no locks are used.
 * 
 * Parameters:
 * al[IN]: Pointer to the arraylist.
 * 
 * Return value:
 * Address of the expected data element. NULL is returns for a empty list.
 */
void *alf_arraylist_get_rear(alf_arraylist_t * al);

/** 
 * Arraylist get data element routine
 *
 * This function gets the data element from the arraylist at a specific index and returns it.
 *
 * Parameters:
 * al[IN]: Pointer of the arraylist.
 * index[IN]: Index for the expected data element from 0 to length-1.
 *
 * Return Value:
 * Address of the indexed data element. NULL is returned if any errors are encountered.
 */
void *alf_arraylist_get_element(alf_arraylist_t * al, unsigned int index);

/**
 * Arraylist get length routine
 *
 * This function return the length of the arraylist, that is, the current number of elements in the arraylist.
 *
 * Parameters:
 * al[IN]: Pointer to the arraylist.
 *
 * Return Values:
 * Length of the arraylist.
 */
static inline unsigned int alf_arraylist_get_length(alf_arraylist_t * al)
{
  /* Return the length */
  return al->length;
}


/**
 * Arraylist query if empty routine.
 *
 * This function checks whether the arraylist is empty.
 *
 * Parameters:
 * al[IN]: Pointer to the arraylist.
 *
 * Return Values:
 * ==1 Arraylist is empty. 
 * ==0 Arraylist is not empty.
 */
static inline int alf_arraylist_is_empty(alf_arraylist_t * al)
{
  /* If the arraylist indices are the same, then the arraylist is empty */
  return  (al->front_index == al->rear_index) ? 1 : 0;
}
static inline int alf_arraylist_is_empty_nl(alf_arraylist_nl_t * al_nl)
{
  /* If the arraylist indices are the same, then the arraylist is empty */
  alf_arraylist_t* al = al_nl->head;

  if(al->front_index == al->rear_index)
  {
    if(al->next != NULL)
    {
      al_nl->head = al->next;
      al = al_nl->head;
      if(al->front_index == al->rear_index)
        return 1;
      else return 0;
    }
    else return 1;
  }
  else return 0;
}


/**
 * Arraylist query if full routine.
 *
 * This function checks whether the arraylist is full.
 *
 * Parameters:
 *   al[IN]: Pointer to the arraylist.
 *
 * Return Values:
 * ==1 Arraylist is full. 
 * ==0 Arraylist is not full.
 */
static inline int alf_arraylist_is_full(alf_arraylist_t * al)
{
  /* if the next arraylist rear index is the same as the front, then the arraylist is full */
  return ((al->rear_index + 1) % al->capacity) == al->front_index;
}


/**
 * Arraylist get capacity routine
 *
 * This function return the capacity of the arraylist.
 *
 * Parameters:
 * al[IN]: Pointer to the arraylist.
 *
 * Return Values:
 * Capacity of the arraylist.
 */

static inline unsigned int alf_arraylist_get_capacity(alf_arraylist_t * al)
{
  /* Return the capacity */
  return al->capacity;
}


/**
 * Arraylist contains data element routine.
 * 
 * This function queries if an data element is contained in the arraylist.
 * 
 * Parameter:
 * al[IN]: Pointer to the arraylist
 * data[IN]: Pointer to the data element to be queried
 * 
 * Return Values:
 * ==1 Arraylist contains the data element 
 * ==0 Arraylist does not contains the data element 
 */

int alf_arraylist_contains(alf_arraylist_t * al, void *data);

/**
 * Arraylist print routine.
 *
 * This function prints the internal contents of the arraylist.
 *
 * Parameters:
 *   al[IN]: Pointer to the arraylist.
 *
 * Return Values:
 * None.
 */

void alf_arraylist_print(alf_arraylist_t * al);

/**
 * Arraylist destroy routine.
 *
 * This function free the resouces allocated for arraylist.
 *
 * Parameters:
 *   al[IN]: Pointer to the arraylist.
 *
 * Return Values:
 * None.
 */

void alf_arraylist_destroy(alf_arraylist_t * al);
void alf_arraylist_destroy_nl(alf_arraylist_nl_t *al_nl);
#endif /* __ALF_ARRAYLIST_H_INC__ */
