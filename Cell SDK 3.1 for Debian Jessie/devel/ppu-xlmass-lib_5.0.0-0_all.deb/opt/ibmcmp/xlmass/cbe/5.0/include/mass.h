/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. 2007.                                        */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

/*-----------------------------------------------------------------*/
/* C/C++ declarations for the scalar MASS functions not in math.h  */
/*-----------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __THROW
# define __THROW_M __THROW
#else
# define __THROW_M
#endif

#ifdef __cplusplus
#else
#include <complex.h>
#endif

double _Complex cosisin(double) __THROW_M;
double dnint (double) __THROW_M;
float anint (float) __THROW_M;
double rsqrt (double) __THROW_M;
void sincos (double, double *, double *) __THROW_M;

#undef __THROW_M
#ifdef __cplusplus
}
#endif

