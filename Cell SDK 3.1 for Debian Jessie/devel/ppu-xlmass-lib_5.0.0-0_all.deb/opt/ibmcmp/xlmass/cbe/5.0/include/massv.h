/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. 2007.                                        */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

/*----------------------------------------------------*/
/* C/C++ declarations for the vector MASS functions   */
/*----------------------------------------------------*/

#ifdef __cplusplus
  extern "C" {
#endif

#ifdef __cplusplus
#else
  #include <complex.h>
#endif

void vacos    (double *, double *, int *);
void vacosh   (double *, double *, int *);
void vasin    (double *, double *, int *);
void vasinh   (double *, double *, int *);
void vatan2   (double *, double *, double *, int *);
void vatanh   (double *, double *, int *);
void vcbrt    (double *, double *, int *);
void vcos     (double *, double *, int *);
void vcosh    (double *, double *, int *);
void vcosisin (double _Complex *, double *, int *);
void vdint    (double *, double *, int *);
void vdiv     (double *, double *, double *, int *);
void vdnint   (double *, double *, int *);
void vexp     (double *, double *, int *);
void vexpm1   (double *, double *, int *);
void vlog     (double *, double *, int *);
void vlog10   (double *, double *, int *);
void vlog1p   (double *, double *, int *);
void vpow     (double *, double *, double *, int *);
void vqdrt    (double *, double *, int *);
void vrcbrt   (double *, double *, int *);
void vrec     (double *, double *, int *);
void vrqdrt   (double *, double *, int *);
void vrsqrt   (double *, double *, int *);
void vsin     (double *, double *, int *);
void vsincos  (double *, double *, double *, int *);
void vsinh    (double *, double *, int *);
void vsqrt    (double *, double *, int *);
void vtan     (double *, double *, int *);
void vtanh    (double *, double *, int *);

void vsacos   (float *, float *, int *);
void vsacosh  (float *, float *, int *);
void vsasin   (float *, float *, int *);
void vsasinh  (float *, float *, int *);
void vsatan2  (float *, float *, float *, int *);
void vsatanh  (float *, float *, int *);
void vscbrt   (float *, float *, int *);
void vscos    (float *, float *, int *);
void vscosh   (float *, float *, int *);
void vscosisin(float _Complex *, float *, int *);  
void vsdiv    (float *, float *, float *, int *);
void vsexp    (float *, float *, int *);
void vsexpm1  (float *, float *, int *);
void vslog    (float *, float *, int *);
void vslog10  (float *, float *, int *);
void vslog1p  (float *, float *, int *);
void vspow    (float *, float *, float *, int *);
void vsqdrt   (float *, float *, int *);
void vsrcbrt  (float *, float *, int *);
void vsrec    (float *, float *, int *);
void vsrqdrt  (float *, float *, int *);
void vsrsqrt  (float *, float *, int *);
void vssin    (float *, float *, int *);
void vssincos (float *, float *, float *, int *);
void vssinh   (float *, float *, int *);
void vssqrt   (float *, float *, int *);
void vstan    (float *, float *, int *);
void vstanh   (float *, float *, int *);

unsigned int vpopcnt4 (void *, int *);
unsigned int vpopcnt8 (void *, int *);

#ifdef __cplusplus
}
#endif

