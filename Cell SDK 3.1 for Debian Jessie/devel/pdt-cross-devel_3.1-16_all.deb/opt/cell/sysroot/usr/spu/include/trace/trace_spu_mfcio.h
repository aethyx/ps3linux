/* ------------------------------------------------------------ */
/* (C) Copyright 2007					*/
/* International Business Machines Corporation,	*/
/*								*/
/* All Rights Reserved.					*/
/* ------------------------------------------------------------ */

/* trace_spu_mfcio.h for sdk 3.0, May 2007	*/
/* trace intervals interface implementation  	*/

#ifndef __TRACE_SPU_MFCIO_H__
#define __TRACE_SPU_MFCIO_H__

#include <trace_events.h>
#include <pdt_mfcio.h>
#include <spu_intrinsics.h>

/* Global vars for tracing */
volatile unsigned int _current_mask;
volatile unsigned int _update_type;

static inline unsigned int trace_mfc_read_tag_status(void)
{
	unsigned int tag_status;
		
	TRACE_SPE_MFC_READ_TAG_STATUS_ENTRY(interval);
	spu_writech(MFC_WrTagMask, _current_mask);
	spu_writech(MFC_WrTagUpdate, _update_type);
	tag_status = spu_readch(MFC_RdTagStat);
	TRACE_SPE_MFC_READ_TAG_STATUS_EXIT(interval,_update_type,_current_mask,tag_status);
	return tag_status;
}

static inline unsigned int trace_mfc_read_list_stall_status(void)
{
	unsigned int stall_status;

	TRACE_SPE_MFC_READ_LIST_STALL_STATUS_ENTRY(interval);
	stall_status = spu_readch(MFC_RdListStallStat);
	TRACE_SPE_MFC_READ_LIST_STALL_STATUS_EXIT(interval, stall_status);
	return stall_status;
}

static inline unsigned int trace_spu_read_signal1(void)
{
	unsigned int signal;

	TRACE_SPE_READ_SIGNAL1_ENTRY(interval);
	signal = spu_readch(SPU_RdSigNotify1);
	TRACE_SPE_READ_SIGNAL1_EXIT(interval, signal);
	return signal;
}

static inline unsigned int trace_spu_read_signal2(void)
{
	unsigned int signal;
	
	TRACE_SPE_READ_SIGNAL2_ENTRY(interval);
	signal = spu_readch(SPU_RdSigNotify2);
	TRACE_SPE_READ_SIGNAL2_EXIT(interval, signal);
	return signal;
}

static inline unsigned int trace_spu_read_in_mbox(void)
{
	unsigned int mail;
	
	TRACE_SPE_READ_IN_MBOX_ENTRY(interval);
	mail = spu_readch(SPU_RdInMbox);
	TRACE_SPE_READ_IN_MBOX_EXIT(interval, mail);
	return mail;
}

static inline void trace_spu_write_out_mbox(unsigned int mail)
{
	TRACE_SPE_WRITE_OUT_MBOX_ENTRY(interval);
	spu_writech(SPU_WrOutMbox,mail);
	TRACE_SPE_WRITE_OUT_MBOX_EXIT(interval, mail);
	return;
}

static inline void trace_spu_write_out_intr_mbox(unsigned int mail)
{
	TRACE_SPE_WRITE_OUT_INTR_MBOX_ENTRY(interval);
	spu_writech(SPU_WrOutIntrMbox,mail);
	TRACE_SPE_WRITE_OUT_INTR_MBOX_EXIT(interval, mail);
	return;
}

static inline unsigned int trace_spu_read_event_status(void)
{
	unsigned int event_status;
		
	TRACE_SPE_READ_EVENT_STATUS_ENTRY(interval);
	event_status = spu_readch(SPU_RdEventStat);
	TRACE_SPE_READ_EVENT_STATUS_EXIT(interval, event_status);
	return event_status;
}

#endif
