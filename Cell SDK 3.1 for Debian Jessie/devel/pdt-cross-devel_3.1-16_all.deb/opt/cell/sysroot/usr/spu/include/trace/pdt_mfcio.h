#ifndef __SPE_MFCIO_TRACEHOOKS_H__
#define __SPE_MFCIO_TRACEHOOKS_H__

#include <trace_events.h>

#include <trace_basic_defs.h>


#define TRACE_EVENT_SPE_MFC_PUT 0x0002

#define TRACE_SPE_MFC_PUT(ea,ls,size,tagid,tid,rid) { \
  trace_payload_t payload; \
  payload.dword[0]=(unsigned long)ea; \
  payload.word[2]=(unsigned int)ls; \
  payload.word[3]=(unsigned int)size; \
  payload.word[4]=(unsigned int)tagid; \
  payload.word[5]=(unsigned int)tid; \
  payload.word[6]=(unsigned int)rid; \
  trace_event(TRACE_EVENT_SPE_MFC_PUT, 6, (void *) payload.word, "Event=%d, ea=0x%x, ls=0x%x, size=%d, tagid=0x%x, tid=0x%x, rid=0x%x",0); \
}

#define TRACE_EVENT_SPE_MFC_PUTF 0x0102

#define TRACE_SPE_MFC_PUTF(ea,ls,size,tagid,tid,rid) { \
  trace_payload_t payload; \
  payload.dword[0]=(unsigned long)ea; \
  payload.word[2]=(unsigned int)ls; \
  payload.word[3]=(unsigned int)size; \
  payload.word[4]=(unsigned int)tagid; \
  payload.word[5]=(unsigned int)tid; \
  payload.word[6]=(unsigned int)rid; \
  trace_event(TRACE_EVENT_SPE_MFC_PUTF, 6, (void *) payload.word, "Event=%d, ea=0x%x, ls=0x%x, size=%d, tagid=0x%x, tid=0x%x, rid=0x%x",0); \
}

#define TRACE_EVENT_SPE_MFC_PUTB 0x0202

#define TRACE_SPE_MFC_PUTB(ea,ls,size,tagid,tid,rid) { \
  trace_payload_t payload; \
  payload.dword[0]=(unsigned long)ea; \
  payload.word[2]=(unsigned int)ls; \
  payload.word[3]=(unsigned int)size; \
  payload.word[4]=(unsigned int)tagid; \
  payload.word[5]=(unsigned int)tid; \
  payload.word[6]=(unsigned int)rid; \
  trace_event(TRACE_EVENT_SPE_MFC_PUTB, 6, (void *) payload.word, "Event=%d, ea=0x%x, ls=0x%x, size=%d, tagid=0x%x, tid=0x%x, rid=0x%x",0); \
}

#define TRACE_EVENT_SPE_MFC_GET 0x0302

#define TRACE_SPE_MFC_GET(ea,ls,size,tagid,tid,rid) { \
  trace_payload_t payload; \
  payload.dword[0]=(unsigned long)ea; \
  payload.word[2]=(unsigned int)ls; \
  payload.word[3]=(unsigned int)size; \
  payload.word[4]=(unsigned int)tagid; \
  payload.word[5]=(unsigned int)tid; \
  payload.word[6]=(unsigned int)rid; \
  trace_event(TRACE_EVENT_SPE_MFC_GET, 6, (void *) payload.word, "Event=%d, ea=0x%x, ls=0x%x, size=%d, tagid=0x%x, tid=0x%x, rid=0x%x",0); \
}

#define TRACE_EVENT_SPE_MFC_GETF 0x0402

#define TRACE_SPE_MFC_GETF(ea,ls,size,tagid,tid,rid) { \
  trace_payload_t payload; \
  payload.dword[0]=(unsigned long)ea; \
  payload.word[2]=(unsigned int)ls; \
  payload.word[3]=(unsigned int)size; \
  payload.word[4]=(unsigned int)tagid; \
  payload.word[5]=(unsigned int)tid; \
  payload.word[6]=(unsigned int)rid; \
  trace_event(TRACE_EVENT_SPE_MFC_GETF, 6, (void *) payload.word, "Event=%d, ea=0x%x, ls=0x%x, size=%d, tagid=0x%x, tid=0x%x, rid=0x%x",0); \
}

#define TRACE_EVENT_SPE_MFC_GETB 0x0502

#define TRACE_SPE_MFC_GETB(ea,ls,size,tagid,tid,rid) { \
  trace_payload_t payload; \
  payload.dword[0]=(unsigned long)ea; \
  payload.word[2]=(unsigned int)ls; \
  payload.word[3]=(unsigned int)size; \
  payload.word[4]=(unsigned int)tagid; \
  payload.word[5]=(unsigned int)tid; \
  payload.word[6]=(unsigned int)rid; \
  trace_event(TRACE_EVENT_SPE_MFC_GETB, 6, (void *) payload.word, "Event=%d, ea=0x%x, ls=0x%x, size=%d, tagid=0x%x, tid=0x%x, rid=0x%x",0); \
}

#define TRACE_EVENT_SPE_MFC_PUTL 0x0602

#define TRACE_SPE_MFC_PUTL(ea,ls,listp,size,tagid,tid,rid) { \
  trace_payload_t payload; \
  payload.dword[0]=(unsigned long)ea; \
  payload.word[2]=(unsigned int)ls; \
  payload.word[3]=(unsigned int)listp; \
  payload.word[4]=(unsigned int)size; \
  payload.word[5]=(unsigned int)tagid; \
  payload.word[6]=(unsigned int)tid; \
  payload.word[7]=(unsigned int)rid; \
  trace_event(TRACE_EVENT_SPE_MFC_PUTL, 7, (void *) payload.word, "Event=%d, ea=0x%x, ls=0x%x, listp=0x%x, size=%d, tagid=0x%x, tid=0x%x, rid=0x%x",0); \
}

#define TRACE_EVENT_SPE_MFC_PUTLF 0x0702

#define TRACE_SPE_MFC_PUTLF(ea,ls,listp,size,tagid,tid,rid) { \
  trace_payload_t payload; \
  payload.dword[0]=(unsigned long)ea; \
  payload.word[2]=(unsigned int)ls; \
  payload.word[3]=(unsigned int)listp; \
  payload.word[4]=(unsigned int)size; \
  payload.word[5]=(unsigned int)tagid; \
  payload.word[6]=(unsigned int)tid; \
  payload.word[7]=(unsigned int)rid; \
  trace_event(TRACE_EVENT_SPE_MFC_PUTLF, 7, (void *) payload.word, "Event=%d, ea=0x%x, ls=0x%x, listp=0x%x, size=%d, tagid=0x%x, tid=0x%x, rid=0x%x",0); \
}

#define TRACE_EVENT_SPE_MFC_PUTLB 0x0802

#define TRACE_SPE_MFC_PUTLB(ea,ls,listp,size,tagid,tid,rid) { \
  trace_payload_t payload; \
  payload.dword[0]=(unsigned long)ea; \
  payload.word[2]=(unsigned int)ls; \
  payload.word[3]=(unsigned int)listp; \
  payload.word[4]=(unsigned int)size; \
  payload.word[5]=(unsigned int)tagid; \
  payload.word[6]=(unsigned int)tid; \
  payload.word[7]=(unsigned int)rid; \
  trace_event(TRACE_EVENT_SPE_MFC_PUTLB, 7, (void *) payload.word, "Event=%d, ea=0x%x, ls=0x%x, listp=0x%x, size=%d, tagid=0x%x, tid=0x%x, rid=0x%x",0); \
}

#define TRACE_EVENT_SPE_MFC_GETL 0x0902

#define TRACE_SPE_MFC_GETL(ea,ls,listp,size,tagid,tid,rid) { \
  trace_payload_t payload; \
  payload.dword[0]=(unsigned long)ea; \
  payload.word[2]=(unsigned int)ls; \
  payload.word[3]=(unsigned int)listp; \
  payload.word[4]=(unsigned int)size; \
  payload.word[5]=(unsigned int)tagid; \
  payload.word[6]=(unsigned int)tid; \
  payload.word[7]=(unsigned int)rid; \
  trace_event(TRACE_EVENT_SPE_MFC_GETL, 7, (void *) payload.word, "Event=%d, ea=0x%x, ls=0x%x, listp=0x%x, size=%d, tagid=0x%x, tid=0x%x, rid=0x%x",0); \
}

#define TRACE_EVENT_SPE_MFC_GETLF 0x0A02

#define TRACE_SPE_MFC_GETLF(ea,ls,listp,size,tagid,tid,rid) { \
  trace_payload_t payload; \
  payload.dword[0]=(unsigned long)ea; \
  payload.word[2]=(unsigned int)ls; \
  payload.word[3]=(unsigned int)listp; \
  payload.word[4]=(unsigned int)size; \
  payload.word[5]=(unsigned int)tagid; \
  payload.word[6]=(unsigned int)tid; \
  payload.word[7]=(unsigned int)rid; \
  trace_event(TRACE_EVENT_SPE_MFC_GETLF, 7, (void *) payload.word, "Event=%d, ea=0x%x, ls=0x%x, listp=0x%x, size=%d, tagid=0x%x, tid=0x%x, rid=0x%x",0); \
}

#define TRACE_EVENT_SPE_MFC_GETLB 0x0B02

#define TRACE_SPE_MFC_GETLB(ea,ls,listp,size,tagid,tid,rid) { \
  trace_payload_t payload; \
  payload.dword[0]=(unsigned long)ea; \
  payload.word[2]=(unsigned int)ls; \
  payload.word[3]=(unsigned int)listp; \
  payload.word[4]=(unsigned int)size; \
  payload.word[5]=(unsigned int)tagid; \
  payload.word[6]=(unsigned int)tid; \
  payload.word[7]=(unsigned int)rid; \
  trace_event(TRACE_EVENT_SPE_MFC_GETLB, 7, (void *) payload.word, "Event=%d, ea=0x%x, ls=0x%x, listp=0x%x, size=%d, tagid=0x%x, tid=0x%x, rid=0x%x",0); \
}

#define TRACE_EVENT_SPE_SNDSIG 0x0C02

#define TRACE_SPE_MFC_SNDSIG(ea,ls,tagid,tid,rid) { \
  trace_payload_t payload; \
  payload.dword[0]=(unsigned long)ea; \
  payload.word[2]=(unsigned int)ls; \
  payload.word[3]=(unsigned int)tagid; \
  payload.word[4]=(unsigned int)tid; \
  payload.word[5]=(unsigned int)rid; \
  trace_event(TRACE_EVENT_SPE_SNDSIG, 5, (void *) payload.word, "Event=%d, ea=0x%x, ls=0x%x, tagid=0x%x, tid=0x%x, rid=0x%x",0); \
}

#define TRACE_EVENT_SPE_SNDSIGF 0x0D02

#define TRACE_SPE_MFC_SNDSIGF(ea,ls,tagid,tid,rid) { \
  trace_payload_t payload; \
  payload.dword[0]=(unsigned long)ea; \
  payload.word[2]=(unsigned int)ls; \
  payload.word[3]=(unsigned int)tagid; \
  payload.word[4]=(unsigned int)tid; \
  payload.word[5]=(unsigned int)rid; \
  trace_event(TRACE_EVENT_SPE_SNDSIGF, 5, (void *) payload.word, "Event=%d, ea=0x%x, ls=0x%x, tagid=0x%x, tid=0x%x, rid=0x%x",0); \
}

#define TRACE_EVENT_SPE_SNDSIGB 0x0E02

#define TRACE_SPE_MFC_SNDSIGB(ea,ls,tagid,tid,rid) { \
  trace_payload_t payload; \
  payload.dword[0]=(unsigned long)ea; \
  payload.word[2]=(unsigned int)ls; \
  payload.word[3]=(unsigned int)tagid; \
  payload.word[4]=(unsigned int)tid; \
  payload.word[5]=(unsigned int)rid; \
  trace_event(TRACE_EVENT_SPE_SNDSIGB, 5, (void *) payload.word, "Event=%d, ea=0x%x, ls=0x%x, tagid=0x%x, tid=0x%x, rid=0x%x",0); \
}

#define TRACE_EVENT_SPE_MFC_BARRIER 0x0F02

#define TRACE_SPE_MFC_BARRIER(tagid) { \
  trace_payload_t payload; \
  payload.word[0]=(unsigned int)tagid; \
  trace_event(TRACE_EVENT_SPE_MFC_BARRIER, 1, (void *) payload.word, "Event=%d, tagid=0x%x",0); \
}

#define TRACE_EVENT_SPE_MFC_EIEIO 0x1002

#define TRACE_SPE_MFC_EIEIO(tagid,tid,rid) { \
  trace_payload_t payload; \
  payload.word[0]=(unsigned int)tagid; \
  payload.word[1]=(unsigned int)tid; \
  payload.word[2]=(unsigned int)rid; \
  trace_event(TRACE_EVENT_SPE_MFC_EIEIO, 3, (void *) payload.word, "Event=%d, tagid=0x%x, tid=0x%x, rid=0x%x",0); \
}

#define TRACE_EVENT_SPE_MFC_SYNC 0x1102

#define TRACE_SPE_MFC_SYNC(tagid) { \
  trace_payload_t payload; \
  payload.word[0]=(unsigned int)tagid; \
  trace_event(TRACE_EVENT_SPE_MFC_SYNC, 1, (void *) payload.word, "Event=%d, tagid=0x%x",0); \
}

#define TRACE_EVENT_SPE_MFC_READ_TAG_STATUS 0x1202

#define TRACE_SPE_MFC_READ_TAG_STATUS_ENTRY(_INTERVAL) \
trace_interval_p _INTERVAL = trace_interval_entry(TRACE_EVENT_SPE_MFC_READ_TAG_STATUS, 0)

#define TRACE_SPE_MFC_READ_TAG_STATUS_EXIT(_INTERVAL,_update_type,_current_mask,tag_status) { \
  trace_payload_t payload; \
  payload.word[0]=(unsigned int)_update_type; \
  payload.word[1]=(unsigned int)_current_mask; \
  payload.word[2]=(unsigned int)tag_status; \
  trace_interval_exit(_INTERVAL, 3,  (void *) payload.word, "Event=%d, _update_type=0x%x, _current_mask=0x%x, tag_status=0x%x"); \
}

#define TRACE_EVENT_SPE_MFC_READ_LIST_STALL_STATUS 0x1302

#define TRACE_SPE_MFC_READ_LIST_STALL_STATUS_ENTRY(_INTERVAL) \
trace_interval_p _INTERVAL = trace_interval_entry(TRACE_EVENT_SPE_MFC_READ_LIST_STALL_STATUS, 0)

#define TRACE_SPE_MFC_READ_LIST_STALL_STATUS_EXIT(_INTERVAL,stall_status) { \
  trace_payload_t payload; \
  payload.word[0]=(unsigned int)stall_status; \
  trace_interval_exit(_INTERVAL, 1,  (void *) payload.word, "Event=%d, stall_status=0x%x"); \
}

#define TRACE_EVENT_SPE_READ_EVENT_STATUS 0x1402

#define TRACE_SPE_READ_EVENT_STATUS_ENTRY(_INTERVAL) \
trace_interval_p _INTERVAL = trace_interval_entry(TRACE_EVENT_SPE_READ_EVENT_STATUS, 0)

#define TRACE_SPE_READ_EVENT_STATUS_EXIT(_INTERVAL,event_status) { \
  trace_payload_t payload; \
  payload.word[0]=(unsigned int)event_status; \
  trace_interval_exit(_INTERVAL, 1,  (void *) payload.word, "Event=%d, event_status=0x%x"); \
}

#define TRACE_EVENT_SPE_READ_SIGNAL1 0x1502

#define TRACE_SPE_READ_SIGNAL1_ENTRY(_INTERVAL) \
trace_interval_p _INTERVAL = trace_interval_entry(TRACE_EVENT_SPE_READ_SIGNAL1, 0)

#define TRACE_SPE_READ_SIGNAL1_EXIT(_INTERVAL,signal) { \
  trace_payload_t payload; \
  payload.word[0]=(unsigned int)signal; \
  trace_interval_exit(_INTERVAL, 1,  (void *) payload.word, "Event=%d, signal=0x%x"); \
}

#define TRACE_EVENT_SPE_READ_SIGNAL2 0x1602

#define TRACE_SPE_READ_SIGNAL2_ENTRY(_INTERVAL) \
trace_interval_p _INTERVAL = trace_interval_entry(TRACE_EVENT_SPE_READ_SIGNAL2, 0)

#define TRACE_SPE_READ_SIGNAL2_EXIT(_INTERVAL,signal) { \
  trace_payload_t payload; \
  payload.word[0]=(unsigned int)signal; \
  trace_interval_exit(_INTERVAL, 1,  (void *) payload.word, "Event=%d, signal=0x%x"); \
}

#define TRACE_EVENT_SPE_READ_IN_MBOX 0x1702

#define TRACE_SPE_READ_IN_MBOX_ENTRY(_INTERVAL) \
trace_interval_p _INTERVAL = trace_interval_entry(TRACE_EVENT_SPE_READ_IN_MBOX, 0)

#define TRACE_SPE_READ_IN_MBOX_EXIT(_INTERVAL,mail) { \
  trace_payload_t payload; \
  payload.word[0]=(unsigned int)mail; \
  trace_interval_exit(_INTERVAL, 1,  (void *) payload.word, "Event=%d, mail=0x%x"); \
}

#define TRACE_EVENT_SPE_WRITE_OUT_MBOX 0x1802

#define TRACE_SPE_WRITE_OUT_MBOX_ENTRY(_INTERVAL) \
trace_interval_p _INTERVAL = trace_interval_entry(TRACE_EVENT_SPE_WRITE_OUT_MBOX, 0)

#define TRACE_SPE_WRITE_OUT_MBOX_EXIT(_INTERVAL,mail) { \
  trace_payload_t payload; \
  payload.word[0]=(unsigned int)mail; \
  trace_interval_exit(_INTERVAL, 1,  (void *) payload.word, "Event=%d, mail=0x%x"); \
}

#define TRACE_EVENT_SPE_WRITE_OUT_INTR_MBOX 0x1902

#define TRACE_SPE_WRITE_OUT_INTR_MBOX_ENTRY(_INTERVAL) \
trace_interval_p _INTERVAL = trace_interval_entry(TRACE_EVENT_SPE_WRITE_OUT_INTR_MBOX, 0)

#define TRACE_SPE_WRITE_OUT_INTR_MBOX_EXIT(_INTERVAL,mail) { \
  trace_payload_t payload; \
  payload.word[0]=(unsigned int)mail; \
  trace_interval_exit(_INTERVAL, 1,  (void *) payload.word, "Event=%d, mail=0x%x"); \
}

#endif  //__SPE_MFCIO_TRACEHOOKS_H__
