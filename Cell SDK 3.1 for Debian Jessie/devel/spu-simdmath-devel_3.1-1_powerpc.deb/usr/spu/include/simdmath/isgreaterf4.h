/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _ISGREATERF4_H_
#define _ISGREATERF4_H_ 1

#include <spu_intrinsics.h>

/*
 * FUNCTION
 *      vector unsigned int _isgreaterf4(vector float x, vector float y)
 *
 * DESCRIPTION
 *      The _isgreaterf4 function returns a vector in which each element 
 *      indicates if the corresponding element of x is greater than the 
 *      corresponding element of y. Denormals (subnormals) are also correctly
 *      compared.
 * 
 * RETURNS
 *      UINT_MAX  (0xFFFFFFFF) if the element of x is greater than the element 
 *                             of y.
 *      0         (0x00000000) otherwise
 *
 */
static __inline vector unsigned int _isgreaterf4(vector float x, vector float y)
{

  vec_uint4 sign = spu_splats((unsigned int)0x80000000);
  vec_uint4 xneg, yneg;
  vec_uint4 xabs, yabs;
  vec_uint4 xsel, ysel;

  xsel = spu_rlmaska((vec_uint4)x, -31);
  ysel = spu_rlmaska((vec_uint4)y, -31);
  xabs = spu_andc((vec_uint4)x, sign);
  yabs = spu_andc((vec_uint4)y, sign);
  xneg = spu_sub(0, xabs);
  yneg = spu_sub(0, yabs);

  return (spu_cmpgt((vec_int4)spu_sel(xabs, xneg, xsel),
		    (vec_int4)spu_sel(yabs, yneg, ysel)));
}
#endif /* _ISGREATERF4_H_ */
#endif /* __SPU__ */
