/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__

#ifndef _ILOGBD2_H_
#define _ILOGBD2_H_	1

#include <spu_intrinsics.h>
#include <limits.h>

#define FP_ILOGB0	INT_MIN
#define FP_ILOGBNAN	INT_MAX

/* 
 * FUNCTION
 *      vector signed long long _ilogbd2(vector double x)
 *
 * DESCRIPTION
 *      The _ilogbd2 function returns the signed exponent in the floating-point
 *      input. Special numbers include:
 *
 *         Input     Output
 *         =====    =====================
 *         INF     FP_ILOGBNAN (INT_MAX)
 *         NAN     FP_ILOGBNAN (INT_MAX)
 *         denorm  exponent - leading zeros
 *         0       FP_ILOGB0 (INT_MIN)
 *         else    signed exponent
 *
 *      The two results are returned in the corresponding elements of the 
 *      returned vector.
 */
static __inline vector signed long long _ilogbd2(vector double x)
{
  vec_uchar16 hi_2_lo = ((vec_uchar16){0x80, 0x80, 0x80, 0x80, 0, 1, 2, 3,
                                       0x80, 0x80, 0x80, 0x80, 8, 9, 10, 11});
  vec_uint4 v, exp, exp_0, mant, mask, count;
  vec_uint4 flg_exp_0, flg_exp_max;
  vec_int4 result;

  mask = spu_splats((unsigned int)0x7FF);

  /* Extract the exponent and mantissa.
   */
  v = (vec_uint4)x;

  exp = spu_and(spu_rlmask(v, -20), mask);

  mant = spu_and(v, ((vec_uint4) { 0x000FFFFF, 0xFFFFFFFF, 0x000FFFFF, 0xFFFFFFFF }));

  /* Count the leading zeros in the mantissa for denorm handling
   * and zero identification.
   */
  count = spu_cntlz(mant);
  count = spu_add(count, spu_and(spu_rlqwbyte(count, 4), spu_cmpeq(count, 32)));

  flg_exp_0 = spu_cmpeq(exp, 0);
  flg_exp_max = spu_cmpeq(exp, mask);

  exp = spu_add(exp, -1023);

  /* Determine the exponent if the input is a denorm or zero.
   */
  exp_0 = spu_sel(spu_sub(spu_add(exp, 12), count), spu_splats((unsigned int)FP_ILOGB0), spu_cmpeq(count, 64));

  exp = spu_sel(spu_sel(exp, spu_splats((unsigned int)FP_ILOGBNAN), flg_exp_max), exp_0, flg_exp_0);

  result = ((vec_int4)spu_and(exp, ((vec_uint4) { -1, 0, -1, 0})));
  result = spu_shuffle(result, result, hi_2_lo);

  return spu_extend(result);
}

#endif /* _ILOGBD2_H_ */
#endif /* __SPU__ */
