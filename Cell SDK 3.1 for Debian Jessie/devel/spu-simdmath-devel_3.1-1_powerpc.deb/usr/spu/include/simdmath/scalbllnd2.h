/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _SCALBLLND2_H_
#define _SCALBLLND2_H_	1

#include <spu_intrinsics.h>

/*
 * FUNCTION
 *      vector double _scalbllnd2(vector double x, vector signed long long n)
 *
 * DESCRIPTION
 *      The _scalbllnd2 function returns a vector containing each element of x 
 *      multiplied by 2^n computed efficiently.  This function is computed 
 *      without the assistance of any floating point operations and as such
 *      does not set any floating point exceptions.
 *
 *      Special Cases:
 *	  - if the exponent is 0, then x is either 0 or a subnormal, and 
 *          the result will be returned as 0.
 *        - if the result underflows, it will be returned as 0.
 *        - if the result overflows, it will be returned as HUGE_VAL with
 *          the sign of x preserved.
 *          (Note that HUGE_VAL currently is +infinite. This is different than 
 *          single-precision, where HUGE_VALF is 0x7FFFFFFF.)
 *
 */
static __inline vector double _scalbllnd2(vector double x, vector signed long long n)
{
  vec_uint4   exp_mask   = spu_splats((unsigned int)0x7FF00000);
  vec_ullong2 exp_maskl  = spu_splats(0x7FF0000000000000ull);
  vec_ullong2 sign_maskl = spu_splats(0x8000000000000000ull);
  vec_uchar16 swap_lo    = (vec_uchar16) { 4,5,6,7, 0x80,0x80,0x80,0x80, 12,13,14,15, 0x80,0x80,0x80,0x80 };
  vec_uchar16 dup_hi     = (vec_uchar16) { 0,1,2,3, 0,1,2,3, 8,9,10,11, 8,9,10,11 };
  vec_uchar16 dup_lo     = (vec_uchar16) { 4,5,6,7, 4,5,6,7, 12,13,14,15, 12,13,14,15 };
  vec_uchar16 dup_lo_16  = (vec_uchar16) { 4,5,4,5, 4,5,4,5, 12,13,12,13, 12,13,12,13 };

  vec_int4  x_exp, x_hi, n_lo;
  vec_int4  exp_scaled;
  vec_int4  new_x;
  vec_int4  scale_top, scale_mid;
  vec_uint4 zero, big;
  vec_uint4 overflow, underflow, flowed;
  vec_uint4 assume_underflow, assume_overflow;
  vec_uint4 shft, shfl;

  /* The basic idea here is to add the scale to the exponent
   * and return the result. However there are serveral error
   * conditions to worry about. The magnitude of the scale could
   * be too large, resulting in overflow or underflow.
   * Also, the addition of the scale to the exponent of x
   * could result in under/overflow.
   */

  /* First, make sure upper 48 bits of scale are reasonable.
   */
  scale_top = (vec_int4)spu_shuffle(n, n, dup_hi);
  scale_mid = (vec_int4)spu_shuffle(n, n, dup_lo_16);

  /* Assume under/overflow, depending on sign.
   */
  assume_underflow = (vec_uint4)spu_rlmaska(scale_top, -31);
  assume_overflow  = (vec_uint4)spu_xor(assume_underflow, -1);

  /* The only good cases for the upper 48 bits of the scale
   * are 0 and -1.
   */
  flowed = spu_nor(
    spu_and(spu_cmpeq(scale_top, 0), 
	    spu_cmpeq(scale_mid,   0)),
    spu_and(spu_cmpeq(scale_top, -1), 
	    spu_cmpeq(scale_mid,   -1)));

  /* Now, correct the under/overflow assumptions.
   */
  overflow  = spu_and(assume_overflow,  flowed);
  underflow = spu_and(assume_underflow, flowed);

  /* If the upper 48 bits of the scale were OK, we should
   * be able to add the scale to the exponent and then
   * check for under/overflow in the lower word only.
   * So scale the input value, and check for various
   * overflow/underflow conditions.
   */ 
  x_hi = (vec_int4)spu_shuffle((vec_uint4)x, (vec_uint4)x, dup_hi);
  n_lo = (vec_int4)spu_shuffle( (vec_int4)n,  (vec_int4)n, dup_lo);

  /* Extract exponent from x. If the exponent is 0, then
   * x is either 0 or a denorm and x*2^exp is a zero.
   */
  x_exp = (vec_int4)spu_rlmask(spu_and((vec_uint4)x_hi, exp_mask), -20);
  zero  = spu_cmpeq(x_exp, 0);

  /* Compute the expected exponent and determine if the 
   * result is within range.
   */
  exp_scaled = spu_add(x_exp, (vec_int4)n_lo);
  zero = spu_orc(zero, spu_cmpgt(exp_scaled, 0));
  big  = spu_cmpgt(exp_scaled, 0x7FF);

  /* If we haven't already over/underflowed, update
   * these flags based on the result of addition above.
   * If we already over/underflowed, then the above 
   * addition produced garbage.
   */
  overflow  = spu_or(overflow,  spu_andc(big,  flowed));
  underflow = spu_or(underflow, spu_andc(zero, flowed));

  /* Reconstruct the scaled number.
   */
  shft = (vec_uint4)spu_sl(exp_scaled, 20);
  shfl = spu_shuffle(shft, shft, swap_lo);
  new_x = (vec_int4)spu_sel((vec_ullong2)x, (vec_ullong2)shfl, (vec_ullong2)exp_maskl);

  /* Now adjust final value based on over/underflow.
   */
  new_x = (vec_int4)spu_andc((vec_uint4)new_x, (vec_uint4)underflow);
  new_x = (vec_int4)spu_sel((vec_ullong2)new_x, (vec_ullong2)exp_maskl, (vec_ullong2)overflow);

  /* Preserve the sign of x
   */
  new_x = (vec_int4)spu_sel((vec_ullong2)new_x, (vec_ullong2)x, (vec_ullong2)sign_maskl);

  return (vec_double2)new_x;
}

#endif /* _SCALBLLND2_H_ */
#endif /* __SPU__ */
