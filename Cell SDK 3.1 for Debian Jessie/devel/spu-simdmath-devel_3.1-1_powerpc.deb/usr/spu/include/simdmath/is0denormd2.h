/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _IS0DENORMD2_H_
#define _IS0DENORMD2_H_	1

#include <spu_intrinsics.h>

/*
 * FUNCTION
 *	vector unsigned long long is0denormd2(vector double x)
 *
 * DESCRIPTION
 *      The is0denorm functions return a vector in which each element 
 *      indicates if the corresponding element of x is in the set containing:
 *      denormalized (subnormal) values, +0, and -0.
 *
 *      The function is0denormd2 returns an unsigned long long vector in which 
 *      each element is defined as:
 *   
 *      - ULLONG_MAX  if the element of x is either a denormalized value or 0.
 *      - 0           otherwise
 *
 */
static __inline vector unsigned long long _is0denormd2(vector double x)
{

#ifndef __SPU_EDP__

  vec_uchar16 propagate = (vec_uchar16) { 0,1,2,3, 0,1,2,3, 8,9,10,11, 8,9,10,11 };
	
  // Add a sign bit
  vec_uint4 a = spu_or((vec_uint4)x,0x80000000);
	
  // Check if the high word not the zero/subnorm exp
  a = spu_cmpgt(a,0x800FFFFF);
	
  // Promote the high result to the low slots
  vec_uint4 r = spu_shuffle(a,a,propagate);

  // Invert and return	
  return (vec_ullong2)spu_nand(r,r);

#else

  return spu_testsv(x, SPU_SV_NEG_ZERO   | SPU_SV_POS_ZERO | 
                       SPU_SV_NEG_DENORM | SPU_SV_POS_DENORM);

#endif /* __SPU_EDP__ */

}

#endif // _IS0DENORMD2_H_
#endif /* __SPU__ */
