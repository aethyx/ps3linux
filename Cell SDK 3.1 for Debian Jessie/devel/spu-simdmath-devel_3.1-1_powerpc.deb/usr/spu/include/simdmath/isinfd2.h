/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _ISINFD2_H_
#define _ISINFD2_H_	1

#include <spu_intrinsics.h>

/*
 * FUNCTION
 *	vector unsigned long long _isinfd2(vector double x)
 *
 * DESCRIPTION
 *      The _isinfd2 function returns a vector in which each element indicates
 *      if the corresponding element of x is an infinity (positive or 
 *      negative).  
 *
 * RETURNS
 *      The function _isinfd2 returns an unsigned long long vector in which 
 *      each element is defined as:
 *
 *        - ULLONG_MAX   if the element of x is either +inf or -inf
 *        - 0            otherwise
 *
 */
static __inline vector unsigned long long _isinfd2(vector double x)
{

#ifndef __SPU_EDP__

  vec_uchar16 swap  = (vec_uchar16) { 0,1,2,3, 0,1,2,3, 8,9,10,11, 8,9,10,11 };

  //  Check the low word
  vec_uint4 lo = spu_cmpeq((vec_uint4)x,0x00000000);
	
  //  Rotate into hi slot
  lo = spu_rlqwbyte(lo,4);
	
  // remove the sign bit
  vec_uint4 hi = spu_and((vec_uint4)x,0x7FFFFFFF);

  // check for equality to inf high word
  hi = spu_cmpeq(hi,0x7FF00000);
	
  // combine the checks
  vec_uint4 y = spu_and(hi,lo);
	
  // propagate the result
  y = spu_shuffle(y,y,swap);

  return (vec_ullong2)y;

#else

  return spu_testsv(x, SPU_SV_NEG_INFINITY | SPU_SV_POS_INFINITY);

#endif /* __SPU_EDP__ */
}

#endif // _ISINFD2_H_
#endif /* __SPU__ */
