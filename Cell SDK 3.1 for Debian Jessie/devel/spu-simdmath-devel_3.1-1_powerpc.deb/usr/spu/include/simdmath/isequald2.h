/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _ISEQUALD2_H_
#define _ISEQUALD2_H_ 1

#include <spu_intrinsics.h>

/*
 * FUNCTION
 *      vector unsigned long long _isequald2(vector double x, vector double y)
 * 
 * DESCRIPTION
 *      The _isequald2 function returns a vector in which each element 
 *      indicates if the corresponding element of x is equal to the 
 *      corresponding element of y.
 *
 *      - The values +0 and -0 are considered equal.
 *      - If both inputs are infinity with the same sign, the comparison is 
 *        equal.
 *      - If either input is NaN, the comparison is false.
 *      - Denormals (subnormals) are compared correctly.
 *
 *     Returns:
 *       ULLONG_MAX (0xFFFFFFFFFFFFFFFF)  if the element of x is equal to the 
 *                                        element of y.
 *       0          (0x0000000000000000)  otherwise
 */
static __inline vector unsigned long long _isequald2(vector double x, vector double y) 
{
#ifndef __SPU_EDP__
  vec_uint4 sign_mask= (vec_uint4) { 0x7FFFFFFF, 0xFFFFFFFF, 0x7FFFFFFF, 0xFFFFFFFF };
  vec_uint4 nan_mask = (vec_uint4) { 0x7FF00000, 0x00000000, 0x7FF00000, 0x00000000 };
  vec_uchar16 hihi_promote = (vec_uchar16) { 0,1,2,3,  16,17,18,19,  8,9,10,11, 24,25,26,27};

  vec_uint4 biteq;
  vec_uint4 xabs;
  vec_uint4 yabs;
  vec_uint4 x_gt;
  vec_uint4 xhi_inf;
  vec_uint4 xnan;
  vec_uint4 iszero;
  vec_uint4 result;
	
  /*  A)  Check for bit equality, store in high word */
  biteq = spu_cmpeq((vec_uint4)x,(vec_uint4)y);
  biteq = spu_and(biteq,spu_rlqwbyte(biteq,4));

	
  /*  Mask out sign bits */
  xabs = spu_and((vec_uint4)x,sign_mask);
  yabs = spu_and((vec_uint4)y,sign_mask);
	
  /*  
      B)  Check if x is NaN, store in high word
	
      B1) If the high word is greater than max_exp (indicates a NaN)
      B2) If the low word is greater than 0 
  */
  x_gt = spu_cmpgt(xabs,nan_mask);

  /*  B3) Check if the high word is equal to the inf exponent */
  xhi_inf = spu_cmpeq(xabs,nan_mask);
	
  /*  xnan = B1[hi] or (B2[lo] and B3[hi]) */
  xnan = spu_or(x_gt,spu_and(spu_rlqwbyte(x_gt,4),xhi_inf));
	
  /*  C)  Check for 0 = -0 special case */
  iszero = spu_cmpeq(spu_or(xabs,yabs),0);
  iszero = spu_and(iszero,spu_rlqwbyte(iszero,4));
	
  /*  result = (A or C) and not B  */
  result = spu_or(biteq,iszero);
  result = spu_andc(result, xnan);
	
  /*  Promote high words to 64 bits and return  */
  result = spu_shuffle(result,result,hihi_promote);

  return (vec_ullong2) result;

#else

  return spu_cmpeq(x, y);

#endif

}
#endif /* _ISEQUALD2_H_ */
#endif /* __SPU__ */
