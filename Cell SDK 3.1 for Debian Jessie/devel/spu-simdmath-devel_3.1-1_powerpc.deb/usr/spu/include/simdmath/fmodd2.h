/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _FMODD2_H_
#define _FMODD2_H_	1

#include <spu_intrinsics.h>


/*
 * FUNCTION
 *	vector double _fmodd2(vector double x, vector double y)
 *
 * DESCRIPTION
 *	    The _fmodd2 function computes the fixed point remainder of the elements 
 *      of x modulus y.
 *  
 */
static __inline vector double _fmodd2(vector double x, vector double y)
{
  int shift0, shift1;
  vec_uchar16 propagate = (vec_uchar16) { 4,5,6,7, 192,192,192,192, 12,13,14,15, 192,192,192,192};
  vec_uchar16 splat_hi = (vec_uchar16) { 0,1,2,3, 0,1,2,3, 8,9,10,11, 8,9,10,11};
  vec_uchar16 merge = (vec_uchar16) { 8,9,10,11, 12,13,14,15, 24,25,26,27, 28,29,30,31};
  vec_uchar16 swap_hilo = (vec_uchar16) { 4,5,6,7, 0,1,2,3, 12,13,14,15, 8,9,10,11 };
  vec_int4 n, shift;
  vec_uint4 z;
  vec_uint4 x_hi, y_hi;
  vec_uint4 abs_x, abs_y;
  vec_uint4 exp_x, exp_y;
  vec_uint4 zero_x, zero_y;
  vec_uint4 logb_x, logb_y;
  vec_uint4 mant_x, mant_y, mant_x0, mant_x1;
  vec_uint4 normal, norm, denorm, norm0, norm1, denorm0, denorm1;
  vec_uint4 result, resultx, cnt, sign_x, borrow, mask;
  vec_uint4 lsb       = (vec_uint4)(spu_splats(0x0000000000000001ULL));
  vec_uint4 sign_mask = (vec_uint4)(spu_splats(0x8000000000000000ULL));
  vec_uint4 implied_1 = (vec_uint4)(spu_splats(0x0010000000000000ULL));
  vec_uint4 mant_mask = (vec_uint4)(spu_splats(0x000FFFFFFFFFFFFFULL));
  vec_uint4 snan_mask = (vec_uint4)(spu_splats(0x7FF8000000000000ULL));
  vec_uint4 inf = (vec_uint4) { 0x7FF00000, 0x00000000, 0x7FF00000, 0x00000000 };

  //  Extract the sign of x
  sign_x = spu_and((vec_uint4)x, sign_mask);

  //  Determing absolute values of inputes
  abs_x = spu_andc((vec_uint4)x, sign_mask);
  abs_y = spu_andc((vec_uint4)y, sign_mask);

  vec_uint4 eq = spu_cmpeq(abs_x,abs_y);
  eq = spu_and(eq,spu_shuffle(eq,eq,swap_hilo));

  //  Extract the exponents and shift them
  x_hi = spu_shuffle(abs_x, abs_x, splat_hi);
  y_hi = spu_shuffle(abs_y, abs_y, splat_hi);
  exp_x  = spu_rlmask(x_hi, -20);
  exp_y  = spu_rlmask(y_hi, -20);

  //  Set resultx is y>x
  resultx = spu_cmpgt(y_hi, x_hi);

  //  Check if either x or y is denormal
  zero_x = spu_cmpeq(exp_x, 0);
  zero_y = spu_cmpeq(exp_y, 0);

  //  Force denormals to zeros (x needs to preserve sign)
  x = (vec_double2)spu_or(spu_andc((vec_uint4)x,zero_x),sign_x);
  y = (vec_double2)spu_andc((vec_uint4)y,zero_y);

  //  Check if the high word is equal to the max_exp
  vec_uint4 x2 = spu_cmpeq(abs_x,inf);
  vec_uint4 y2 = spu_cmpeq(abs_y,inf);
	
  //  Check if the high word is greater than the max_exp, or the low word is non-zero
  vec_uint4 x1 = spu_cmpgt(abs_x,inf);
  vec_uint4 y1 = spu_cmpgt(abs_y,inf);
	
  //  This could be optimized better...
  vec_uint4 exp_and_lw_x = spu_and(spu_rlqwbyte(x1,4),x2);
  vec_uint4 exp_and_lw_y = spu_and(spu_rlqwbyte(y1,4),y2);
	

  vec_uint4 x_inf = spu_and(spu_rlqwbyte(x2,4),x2);
  vec_uint4 x_nan = spu_or(x1,exp_and_lw_x);
  vec_uint4 y_nan = spu_or(y1,exp_and_lw_y);
	
  //  And then promote the resulting high word to 64 bit length
  x_nan = spu_shuffle(x_nan,x_nan,splat_hi);
  y_nan = spu_shuffle(y_nan,y_nan,splat_hi);

  //  Compute the logb of x and y
  logb_x = spu_add(exp_x, -1023);
  logb_y = spu_add(exp_y, -1023);

  //  Extract the mantissas with the addition of an implied 1
  mant_x = spu_andc(spu_sel(implied_1, abs_x, mant_mask), zero_x);
  mant_y = spu_andc(spu_sel(implied_1, abs_y, mant_mask), zero_y);

  //  Determine how much we need to shift the elements by
  //  And then align them and subtract to perform a fixed-point mod
  n = spu_sub((vec_int4)logb_x, (vec_int4)logb_y);
  mask = spu_cmpgt(n, 0);

  while (spu_extract(spu_gather(mask), 0)) {
    borrow = spu_genb(mant_x, mant_y);
    borrow = spu_shuffle(borrow, borrow, propagate);
    z = spu_subx(mant_x, mant_y, borrow);

    mant_x = spu_sel(mant_x, 
		     spu_sel(spu_slqw(mant_x, 1), spu_andc(spu_slqw(z, 1), lsb), spu_cmpgt((vec_int4)spu_shuffle(z, z, splat_hi), -1)),
		     mask);

    n = spu_add(n, -1);														   
    mask = spu_cmpgt(n, 0);
  }

  borrow = spu_genb(mant_x, mant_y);
  borrow = spu_shuffle(borrow, borrow, propagate);
  z = spu_subx(mant_x, mant_y, borrow);
  mant_x = spu_sel(mant_x, z, spu_cmpgt((vec_int4)spu_shuffle(z, z, splat_hi), -1));

  /* Convert the result back to floating point and restore
   * the sign. If we flagged the result to be zero (result0),
   * zero it. If we flagged the result to equal its input x,
   * (resultx) then return x.
   *
   * Double precision generates a denorm for an output.
   */
  cnt = spu_cntlz(mant_x);
  cnt = spu_add(cnt, spu_and(spu_rlqwbyte(cnt, 4), spu_cmpeq(cnt, 32)));
  cnt = spu_add(spu_shuffle(cnt, cnt, splat_hi), -11);

  mant_x0 = spu_rlmaskqwbyte(mant_x, -8);
  mant_x1 = mant_x;

  shift = spu_add((vec_int4)exp_y, -1);
  shift0 = spu_extract(shift, 0);
  shift1 = spu_extract(shift, 2);

  denorm0 = spu_slqwbytebc(spu_slqw(mant_x0, shift0), shift0);
  denorm1 = spu_slqwbytebc(spu_slqw(mant_x1, shift1), shift1);

  exp_y = spu_sub(exp_y, cnt);

  normal = spu_cmpgt((vec_int4)exp_y, 0);

  /* Normalize normal results, denormalize denorm results.
   */
  shift0 = spu_extract(cnt, 0);			    
  shift1 = spu_extract(cnt, 2);			    

  norm0 = spu_slqwbytebc(spu_slqw(spu_andc(mant_x0, implied_1), shift0), shift0);
  norm1 = spu_slqwbytebc(spu_slqw(spu_andc(mant_x1, implied_1), shift1), shift1);

  denorm = spu_shuffle(denorm0, denorm1, merge);
  norm   = spu_shuffle(norm0,     norm1, merge);

  mant_x = spu_sel(denorm, norm, normal);

  exp_y = spu_and(spu_rl(exp_y, 20), normal);

  result = spu_sel(exp_y, spu_or(sign_x, mant_x), ((vec_uint4) { 0x800FFFFF, -1, 0x800FFFFF, -1 }));

  result = spu_sel(result,(vec_uint4)x, resultx);


  //  If x is zero, or |x| == |y|, force result to properly signed zero
  result = spu_sel(result,sign_x,spu_or(zero_x,eq));

  //  If y is zero or NaN, force result to sNaN
  result = spu_sel(result,spu_or((vec_uint4)y,snan_mask),spu_or(zero_y,y_nan));

  //  If x is infinite or NaN return x
  result = spu_sel(result,spu_or((vec_uint4)x,snan_mask),spu_or(x_nan,x_inf));

  return ((vec_double2)result);
}

#endif /* _FMODD2_H_ */
#endif /* __SPU__ */
