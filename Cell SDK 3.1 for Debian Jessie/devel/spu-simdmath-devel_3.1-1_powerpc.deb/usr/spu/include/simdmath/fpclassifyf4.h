/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _FPCLASSIFYF4_H_
#define _FPCLASSIFYF4_H_	1

#include <math.h>
#include <spu_intrinsics.h>

/*
 * FUNCTION
 *  vector signed int _fpclassifyf4(vector float x)
 *
 * DESCRIPTION
 *  The fpclassifyf4 function returns a vector containing the floating-
 *  point classifications for the corresponding elements of the input
 *  vector. The classifications are defined in math.h.
 *
 *  Special Cases:
 *	- Infinity and NaN are not supported in single precision on the SPU.
 *	  Therefore Infinity and NaNs are classified as Normal numbers.
 *	- Note that on the SPU, single-precision subnormal intrinsic argument
 *	  values are treated as 0, but this function will correctly classify
 *	  them as subnormal.
 *
 */

static __inline vector signed int _fpclassifyf4(vector float x)
{
    vec_uint4 signmask = {0x7FFFFFFF, 0x7FFFFFFF, 0x7FFFFFFF, 0x7FFFFFFF};
    vec_uint4 maxsnorm = {0x007FFFFF, 0x007FFFFF, 0x007FFFFF, 0x007FFFFF};
    vec_int4  fpzero  = {FP_ZERO,      FP_ZERO,      FP_ZERO,      FP_ZERO};
    vec_int4  fpsnorm = {FP_SUBNORMAL, FP_SUBNORMAL, FP_SUBNORMAL, FP_SUBNORMAL};
    vec_int4  fpnorm  = {FP_NORMAL,    FP_NORMAL,    FP_NORMAL,    FP_NORMAL};
    vec_uint4 gtsnorm;
    vec_uint4 gt0;
    vec_uint4 xabs;
    vec_int4  result;

    xabs = spu_and((vec_uint4)x, signmask);

    gt0     = spu_cmpgt(xabs, 0);
    gtsnorm = spu_cmpgt(xabs, maxsnorm);

    /* We assume it's zero. Then if x > 0, assume it's a subnormal. 
     * Then if x > largest subnormal, it's a normal.
     */
    result = spu_sel(fpzero, fpsnorm, gt0);
    result = spu_sel(result, fpnorm,  gtsnorm);
    
    return result;
}

#endif /* _FPCLASSIFYF4_H_ */
#endif /* __SPU__ */
