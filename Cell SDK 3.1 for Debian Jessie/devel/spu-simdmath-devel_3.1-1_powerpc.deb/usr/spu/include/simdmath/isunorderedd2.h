/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _ISUNORDEREDD2_H_
#define _ISUNORDEREDD2_H_	1

#include <spu_intrinsics.h>

/*
 * FUNCTION
 *	vector unsigned long long isunorderedd2(vector double x, vector double y)
 *
 * DESCRIPTION
 *  The isnormal functions return a vector in which each element indicates if 
 *  the corresponding element of either x or y is unordered (NaN).
 *
 * RETURNS
 *  The function isunorderedd2 returns an unsigned long long vector in which 
 *  each element is defined as:
 *    -  ULLONG_MAX if the element of either x or y is NaN
 *    -  0 otherwise.
 */
static __inline vector unsigned long long _isunorderedd2(vector double x, vector double y)
{
    
#ifndef __SPU_EDP__

  vec_uchar16 hi_shufp = (vec_uchar16) { 0,1,2,3,  16,17,18,19,  8,9,10,11,  24,25,26,27 };
  vec_uchar16 lo_shufp = (vec_uchar16) { 4,5,6,7,  20,21,22,23, 12,13,14,15, 28,29,30,31 };

  //  Pattern to swap high and low words of doubleword vector
  vec_uchar16 hilo_shufp = (vec_uchar16) { 4,5,6,7,  0,1,2,3,  12,13,14,15,  8,9,10,11 } ;

  //  Separate high words and low words
  vec_uint4 hi_words = spu_shuffle((vec_uint4)x,(vec_uint4)y,hi_shufp);
  vec_uint4 lo_words = spu_shuffle((vec_uint4)x,(vec_uint4)y,lo_shufp);
	
  //  Remove the sign bits from the high words
  hi_words = spu_and(hi_words,0x7FFFFFFF);
	
  //  Check if any high words are greater than zero
  vec_uint4 exp_gt = spu_cmpgt(hi_words,0x7FF00000);
	
  //  Check if any high words are equal to the max exponent
  vec_uint4 exp_eq = spu_cmpeq(hi_words,0x7FF00000);
	
  //  Check if any low words have bits
  vec_uint4 man_nz = spu_cmpgt(lo_words,0x00000000);
	
  //  If ( exp_gt || ( exp == max_exp && low word > 0 ))
  vec_uint4 result = spu_or(exp_gt,spu_and(exp_eq,man_nz));
	
  //  Swap the high and low words
  vec_uint4 result_flipped = spu_shuffle(result,result,hilo_shufp);
	
  result = spu_or(result,result_flipped);
	
  return (vec_ullong2) result;	

#else

  return spu_or(spu_testsv(x, SPU_SV_NAN), spu_testsv(y, SPU_SV_NAN));

#endif /* __SPU_EDP__ */

}


#endif // _ISUNORDEREDD2_H_
#endif /* __SPU__ */
