/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _FPCLASSIFYD2_H_
#define _FPCLASSIFYD2_H_	1

#include <math.h>
#include <spu_intrinsics.h>

/*
 * FUNCTION
 *  vector signed long long _fpclassifyd2(vector double x)
 *
 * DESCRIPTION
 *  The fpclassifyd2 function returns a vector containing the floating-
 *  point classifications for the corresponding elements of the input
 *  vector. The classifications are defined in math.h.
 *
 *  Special Cases:
 *  - None
 *
 */

static __inline vector signed long long _fpclassifyd2(vector double x)
{
    vec_llong2  fpzero  = {(long long)FP_ZERO,      (long long)FP_ZERO};
    vec_llong2  fpsnorm = {(long long)FP_SUBNORMAL, (long long)FP_SUBNORMAL};
    vec_llong2  fpnorm  = {(long long)FP_NORMAL,    (long long)FP_NORMAL};
    vec_llong2  fpinf   = {(long long)FP_INFINITE,  (long long)FP_INFINITE};
    vec_llong2  fpnan   = {(long long)FP_NAN,       (long long)FP_NAN};

    vector signed long long result;
    vec_uchar16 dup_even  = ((vec_uchar16) {0,1,2,3, 0,1,2,3,  8,9,10,11,  8,9,10,11});
    vec_uchar16 swapword  = ((vec_uchar16) {4,5,6,7, 0,1,2,3, 12,13,14,15, 8,9,10,11});
    vec_ullong2 expmask   = {0x7FF0000000000000ull, 0x7FF0000000000000ull};
    vec_ullong2 manmask   = {0x000FFFFFFFFFFFFFull, 0x000FFFFFFFFFFFFFull};

    /*
     * This is setup work to determine characteristics of the exponent and
     * mantissa.
     */
    vec_ullong2 exp = spu_and((vec_ullong2)x, expmask);
    exp = spu_shuffle(exp, exp, dup_even);
    vec_ullong2 exp0   = (vec_ullong2)spu_cmpeq((vec_uint4)exp, 0);
    vec_ullong2 expmax = (vec_ullong2)spu_cmpeq((vec_uint4)exp, spu_splats(0x7FF00000u));

    vec_ullong2 man     = spu_and((vec_ullong2)x, manmask);
    vec_ullong2 manswap = spu_shuffle(man, man, swapword);
    man = spu_or(man, manswap);
    vec_ullong2 mangt0 = (vec_ullong2)spu_cmpgt((vec_uint4)man, 0);

    /*
     * Now we do the classification.
     * First we use the presence of a non-zero mantissa to limit
     * choice of type. If mantissa != 0, we know we don't have
     * zero or infinity.
     */
    vec_llong2 pos1 = spu_sel(fpzero, fpsnorm, mangt0);
    vec_llong2 pos2 = spu_sel(fpinf,  fpnan,   mangt0);

    /*
     * Now, assume that we have a normal number. Then use the exponent 
     * along with the earlier mantissa comparison to determine the
     * correct classification.
     */ 
    result = spu_sel(fpnorm, pos1, exp0);
    result = spu_sel(result, pos2, expmax);

    return result;
}

#endif /* _FPCLASSIFYD2_H_ */
#endif /* __SPU__ */
