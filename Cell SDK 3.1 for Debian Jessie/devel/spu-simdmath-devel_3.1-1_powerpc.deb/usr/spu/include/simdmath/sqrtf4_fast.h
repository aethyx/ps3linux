/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _SQRTF4_FAST_H_
#define _SQRTF4_FAST_H_	1

#include <spu_intrinsics.h>

/*
 * FUNCTION
 *	vector float _sqrtf4_fast(vector float in)
 *
 * DESCRIPTION
 *	The _sqrtf4_fast function computes the square root of the vector 
 *      input "in" and returns the result. 
 *
 * This fast version that is up to 3 ulp (units of least
 *          position off). Over the input range 1.0 to 3.9999...
 *          this implementation has a histogram of error of:
 *           ulp error   count
 *           =========   =====
 *		 -3      0
 *		 -2      68
 *		 -1      384895
 *		  0      5985155
 *		  1      8611186
 *		  2      1752588
 *		  3      43324
 *
 */
static __inline vector float _sqrtf4_fast(vector float in) 
{

  vec_float4 y0, out;
  
  /* Perform one iteration of the Newton-Raphsom method in single precision
   * arithmetic.
   */
  y0 = spu_rsqrte(in);
  out = spu_mul(spu_nmsub(in, spu_mul(y0, y0), (vec_float4)(spu_splats(0x40400001))), 
		spu_mul(y0, spu_mul(in, spu_splats(0.5f))));

  out = spu_andc(out, (vec_float4)spu_cmpeq(in, spu_splats(0.0f)));

  return out;
}

#endif /* _SQRTF4_FAST_H_ */
#endif /* __SPU__ */
