/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _DIVI4_H_
#define _DIVI4_H_	1

#include <spu_intrinsics.h>
#include "simdmath.h"
#include "divu4.h"

/*
 * FUNCTION
 * 	vector signed int _divi4(vector signed int dividend, 
 *				      vector signed int divisor)
 * 
 * DESCRIPTION
 *	The _divi4 subroutine computes 4 simultaneous signed integer
 *	quotients of by dividing each component of the vector dividend  
 *	by the correspoding component of the vector divisor. If the divisor
 *	is 0, then a quotient of 0 is produced.
 *
 *	Zero is also produced when 0x80000000 is divided by -1. 
 *
 */
static __inline divi4_t _divi4(vector signed int dividend, vector signed int divisor)
{
  vector signed int sign, sign1, sign2;
  divu4_t uresult;
  divi4_t result;

  sign1 = spu_rlmaska(dividend, -31);
  sign2 = spu_rlmaska(divisor,  -31);
  sign  = spu_xor(sign1, sign2);

  /* Compute the absolute value of the dividends and divisors
   */
  dividend = spu_sub(spu_xor(dividend, sign1), sign1);
  divisor  = spu_sub(spu_xor(divisor,  sign2), sign2);

  uresult = _divu4((vec_uint4)dividend, (vec_uint4)divisor);

  /* Convert the result to the correct sign. The sign of the remainder must equal
   * the sign of the dividend.
   */
  result.quot = spu_sub(spu_xor((vec_int4)uresult.quot, sign), sign);
  result.rem  = spu_sub(spu_xor((vec_int4)uresult.rem,  sign1), sign1);

  return result;
}

#endif /* _DIVI4_H_ */
#endif /* __SPU__ */
