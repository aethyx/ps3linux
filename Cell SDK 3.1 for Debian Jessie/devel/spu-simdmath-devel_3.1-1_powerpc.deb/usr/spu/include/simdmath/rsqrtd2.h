/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _RSQRTD2_H_
#define _RSQRTD2_H_	1

#include <spu_intrinsics.h>

/*
 * FUNCTION
 *	vector double _rsqrtd2(vector double value_d)
 *
 * DESCRIPTION
 *	The _rsqrtd2 function computes 1 over the square root of the vector 
 *      input "value_d" and returns the result. Computation is performed using 
 *      the floating-point reciprocal square root estimate and interpolate 
 *      instructions to produce a 12 bit accurate estimate. One iteration of a 
 *      single precision Newton-Raphson is performed to improve accuracy to
 *      single precision floating point. Two more double precision iterations
 *      are performed in order to achieve full double precision.
 *
 *	The Newton-Raphson iteration is of the form:
 *		X[i+1] = 0.5 * X[i] * (3.0 - b * X[i] * X[i]) 
 *	where b is the input value to be inverted
 *
 */
static __inline vector double _rsqrtd2(vector double value_d)
{
  vector unsigned long long mask = spu_splats(0x7FE0000000000000ULL);
  vector unsigned long long mask2 = spu_splats(0x7FF0000000000000ULL);
  vector unsigned long long addend = spu_splats(0x2000000000000000ULL);
  vector float value, x0;
  vector double x1;
  vector double x2, x3;
  vector double half  = spu_splats(0.5);
  vector double three = spu_splats(3.0);
  vector double bias;

  /* Bias the divisor to correct for double precision floating
   * point exponents that are out of single precision range.
   */
  bias = spu_xor(spu_and(value_d, (vector double)mask), (vector double)mask2);
  value = spu_roundtf(spu_mul(value_d, bias));
  x0 = spu_rsqrte(value);
  
  bias = (vector double)(spu_add(spu_and(spu_rlmask((vector unsigned int)(bias), -1), (vector unsigned int)(mask2)), 
				 (vector unsigned int)(addend)));

  x1 = spu_extend(spu_mul(spu_mul(spu_splats(0.5f), x0),
			  spu_nmsub(value, spu_mul(x0, x0), spu_splats(3.0f))));
  x1 = spu_mul(x1, bias);
  x2 = spu_mul(spu_mul(half, x1), spu_nmsub(value_d, spu_mul(x1, x1), three));
  x3 = spu_mul(spu_mul(half, x2), spu_nmsub(value_d, spu_mul(x2, x2), three));

  return (x3);
}
#endif /* _RSQRTD2_H_ */
#endif /* __SPU__ */
