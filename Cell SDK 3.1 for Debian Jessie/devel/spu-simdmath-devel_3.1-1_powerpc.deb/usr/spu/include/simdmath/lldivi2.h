/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _LLDIVI2_H_
#define _LLDIVI2_H_	1

#include <spu_intrinsics.h>
#include <simdmath.h>

#include "lldivu2.h"

/*
 * FUNCTION
 *  lldivi2_t _lldivi2(vector float x)
 *
 * DESCRIPTION
 *  The lldivi2 function computes 2 simultaneous signed integer
 *	quotients and remainders by dividing each component of the vector dividend  
 *	by the correspoding component of the vector divisor. If the divisor
 *	is 0, then a quotient of 0 is produced.
 *
 */

static __inline lldivi2_t _lldivi2(vector signed long long dividend, vector signed long long divisor)
{
  lldivu2_t uresult;
  lldivi2_t result;
  vector unsigned int sign, sign1, sign2, overflow;
  vector signed long long quotient;
  vector unsigned int zero = spu_splats(0u);
  vector unsigned char sign_repl = (vector unsigned char) {0, 0, 0, 0,  0, 0, 0, 0, 
                                                           8, 8, 8, 8,  8, 8, 8, 8};
  vector unsigned int borrow;
  vector unsigned char borrow_shuffle = (vector unsigned char) { 4,5,6,7,    192,192,192,192, 
                                                                12,13,14,15, 192,192,192,192};

  sign1 = spu_rlmaska((vector unsigned int)dividend, -31);
  sign2 = spu_rlmaska((vector unsigned int)divisor,  -31);

  sign1 = spu_shuffle(sign1, sign1, sign_repl);
  sign2 = spu_shuffle(sign2, sign2, sign_repl);
  sign  = spu_xor(sign1, sign2);

  /* Compute the absolute value of the dividends and divisors
   */
  borrow   = spu_genb(zero, (vector unsigned int)(dividend));
  borrow   = spu_shuffle(borrow, borrow, borrow_shuffle);
  dividend = (vector signed long long)spu_sel((vector unsigned int)(dividend), 
					      spu_subx(zero, (vector unsigned int)(dividend), borrow), 
					      sign1);

  borrow   = spu_genb(zero, (vector unsigned int)(divisor));
  borrow   = spu_shuffle(borrow, borrow, borrow_shuffle);
  divisor  = (vector signed long long)spu_sel((vector unsigned int)(divisor), 
					      spu_subx(zero, (vector unsigned int)(divisor), borrow), 
					      sign2);

  uresult = _lldivu2((vector unsigned long long)dividend, (vector unsigned long long)divisor);

  quotient = (vector signed long long)uresult.quot;

  /* Convert the result to the correct sign while also handling overflow */
  overflow = spu_rlmaska((vector unsigned int)quotient, -31);
  overflow = spu_shuffle(overflow, overflow, sign_repl);

  borrow   = spu_genb(zero, (vector unsigned int)(quotient));
  borrow   = spu_shuffle(borrow, borrow, borrow_shuffle);
  quotient = (vector signed long long)spu_sel((vector unsigned int)(quotient),
					      spu_subx(zero, (vector unsigned int)(quotient), borrow),
					      sign);
  result.quot = (vector signed long long)spu_andc((vector unsigned int)(quotient), spu_andc(overflow, sign));


  /* Remainder has the same sign as dividend */
  borrow   = spu_genb(zero, (vector unsigned int)(uresult.rem));
  borrow   = spu_shuffle(borrow, borrow, borrow_shuffle);
  result.rem = (vector signed long long)spu_sel((vector unsigned int)(uresult.rem),
					      spu_subx(zero, (vector unsigned int)(uresult.rem), borrow),
					      sign1);

  return (result);
}

#endif /* _LLDIVI2_H_ */
#endif /* __SPU__ */
