/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _FMAXD2_H_
#define _FMAXD2_H_	1

#include <spu_intrinsics.h>

#ifdef __SPU_EDP__
#include "isnand2.h"
#endif

/*
 * FUNCTION
 *	vector double _fmaxd2(vector double x, vector double y)
 *
 * DESCRIPTION
 *	_fmaxd2 returns the maximum numeric value of each element of
 *      x and y.  If one argument is a NaN, _fmaxd2 returns the other
 *      value.  If both are NaNs, then a NaN is returned.
 *
 * Notes:
 * 1) Double precision denorms equate to zero so two denorms compare
 *    equal thereby making the following true for two denorm inputs
 *		fmax(a, b) != fmax(b, a);
 */
static __inline vector double _fmaxd2(vector double x, vector double y)
{

#ifndef __SPU_EDP__
  vec_uint4 nan_x, selector, abs_x, gt, eq;
  vec_uint4 sign = (vec_uint4) { 0x80000000, 0, 0x80000000, 0 };
  vec_uint4 infinity = (vec_uint4) { 0x7FF00000, 0, 0x7FF00000, 0 };
  vec_double2 diff, max;

  /* If x is a NaN, then select y as max
   */
  abs_x = spu_andc((vec_uint4)x, sign);
  gt = spu_cmpgt(abs_x, infinity);
  eq = spu_cmpeq(abs_x, infinity);

  nan_x = spu_or(gt, spu_and(eq, spu_rlqwbyte(gt, 4)));

  diff = spu_sub(x, y);
  selector = spu_orc(nan_x, spu_cmpgt((vec_int4)diff, -1));

  selector = spu_shuffle(selector, selector, ((vec_uchar16) { 0,1,2,3, 0,1,2,3, 8,9,10,11, 8,9,10,11 }));

  max = spu_sel(x, y, (vec_ullong2)selector);

  return (max);

#else

  return spu_sel(y, x, spu_or(spu_cmpgt(x,y), _isnand2(y)));

#endif  /* __SPU_EDP__ */


}

#endif /* _FMAXD2_H_ */
#endif /* __SPU__ */
