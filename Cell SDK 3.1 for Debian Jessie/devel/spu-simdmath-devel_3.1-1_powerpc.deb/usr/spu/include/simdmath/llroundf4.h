/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _LLROUNDF4_H_
#define _LLROUNDF4_H_	1

#include <simdmath.h>
#include <spu_intrinsics.h>

/*
 * FUNCTION
 *	llroundf4_t _llroundf4(vector float x)
 *
 * DESCRIPTION
 * 	The _llroundf4 function rounds element of the vector of floats to the 
 *      nearest long long integer value, and returns the results in a 
 *      llroundf4_t structure.  This function is similiar to _llrintf4, but it 
 *      rounds to nearest, rather than truncates.
 *
 *	- the SPU does not support INF (infinities)
 *      - the SPU does not support NaNs (Not a Number)
 *
 */
static __inline llroundf4_t _llroundf4 (vector float x)
{
  vec_float4 xabs;
  vec_float4 two_pow_32 = (vec_float4) spu_splats ((unsigned int) 0x4F800000);
  vec_float4 two_pow_minus32 =
    (vec_float4) spu_splats ((unsigned int) 0x2F800000);
  vec_uint4 msw, lsw, neg, neg_msw, neg_lsw;
  vec_uint4 zero = (vec_uint4) { 0 };
  vec_uint4 sign = spu_splats ((unsigned int) 0x80000000);
  vec_uchar16 shuf0 = ((vec_uchar16) {
			 0, 1, 2, 3, 16, 17, 18, 19, 4, 5, 6, 7, 20, 21,
			   22,
			   23
			   });
  vec_uchar16 shuf1 = spu_or (shuf0, 8);
  llroundf4_t r;

  // xabs = |x|
  xabs = spu_andc (x, (vec_float4) sign);

  // Add 0.5 to emulate correct rounding
  xabs = spu_add (xabs, spu_splats (0.5f));

  // msw = (unsigned int)(xabs * 2^-32)
  msw = spu_convtu (spu_mul (xabs, two_pow_minus32), 0);

  // lsw = (unsigned int)(xabs - (float)msb * 2^32)
  lsw = spu_convtu (spu_nmsub (spu_convtf (msw, 0), two_pow_32, xabs), 0);
  neg = spu_cmpgt ((vec_uint4) x, sign);

  // compute the negative of msw,lsw
  neg_lsw = spu_sub (zero, lsw);
  neg_msw = spu_subx (zero, msw, spu_genb (zero, lsw));

  // select between the msw,lsw and its negation
  msw = spu_sel (msw, neg_msw, neg);
  lsw = spu_sel (lsw, neg_lsw, neg);

  // merge the result into the pair of signed long long vectors
  r.vll[0] = (vec_llong2) spu_shuffle (msw, lsw, shuf0);
  r.vll[1] = (vec_llong2) spu_shuffle (msw, lsw, shuf1);
  return (r);
}


#endif /* _LLROUNDF4_H_ */
#endif /* __SPU__ */
