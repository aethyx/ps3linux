/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifdef __SPU__
#ifndef _LLABSI2_H_
#define _LLABSI2_H_	1

#include <spu_intrinsics.h>

/*
 * FUNCTION
 *	vector signed long long _llabsi2(vector signed long long x)
 *
 * DESCRIPTION
 *	The _llabsi2 routine returns the absolute values of the elements of the
 *  	input vector of 2 signed long long integers. 
 *
 */
static __inline vector signed long long _llabsi2(vector signed long long x) 
{
  vec_llong2 neg_x;
  vec_ullong2 select;
  vec_uint4 gt_unsigned_0, ge_signed_0;
  vec_uchar16 shift_4_bytes = ((vec_uchar16){4,5,6,7, 128,128,128,128, 12,13,14,15, 128,128,128,128});
  vec_uchar16 splat_hi = ((vec_uchar16){0,1,2,3, 0,1,2,3, 8,9,10,11, 8,9,10,11});

  gt_unsigned_0 = spu_cmpgt((vec_uint4)x, 0);
  ge_signed_0   = (vec_uint4)spu_xor(spu_rlmaska((vec_int4)x, 31), spu_splats(-1));

  // Construct a selection mask. All 1's if x >= 0. Otherwise 
  // all 0's.
  select = (vec_ullong2)spu_shuffle(ge_signed_0, ge_signed_0, splat_hi);

  // Compute the negation of x
  neg_x = (vec_llong2)spu_add((vec_uint4)spu_sub(0, (vec_int4)x), spu_shuffle(gt_unsigned_0, gt_unsigned_0, shift_4_bytes));

  //  Select and return
  return spu_sel(neg_x, x, select);
}

#endif /* _LLABSI2_H_ */
#endif /* __SPU__ */
