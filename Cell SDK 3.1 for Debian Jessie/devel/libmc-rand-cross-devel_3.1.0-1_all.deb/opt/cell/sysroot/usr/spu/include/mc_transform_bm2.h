/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2007,2008, All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

// Prototypes for Box-Muller Sine/Cosine Transform

#ifndef _MC_TRANSFORM_BM2_H_
#define _MC_TRANSFORM_BM2_H_

//
//  C++ interface
//
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

// These two APIs are the improved Box-Muller algorithm, which uses
// sine and cosine to generate two transformed numbers from two inputs.
// These APIs transform pairs of vectors, so the count parameter is
// expected to be an even number.  If the count is odd, the last vector
// is not transformed.  s_array points to an array of random numbers to
// be transformed.  t_array points to the transformed results.
//
//  The transformation formula is:
//
//	t1 = sqrt(-2*ln(s1)) * cos(2*PI*s2)
//	t2 = sqrt(-2*ln(s1)) * sin(2+PI+s2)
//
//      vector s_array[0]		vector s_array[1]
// +---------------------------+     +---------------------------+
// | s1-1 | s1-2 | s1-3 | s1-4 |     | s2-1 | s2-2 | s2-3 | s2-4 |
// +---------------------------+     +---------------------------+
// transforms to:
// 	vector t_array[0]		vector t_array[1]
// +---------------------------+     +---------------------------+
// | t1-1 | t1-2 | t1-3 | t1-4 |     | t2-1 | t2-2 | t2-3 | t2-4 |
// +---------------------------+     +---------------------------+
//
//
// Parameters:
// count	The number of values to transform
// s_array	Pointer to input array of random numbers
// t_array	Pointer to output array of transformed numbers

void mc_transform_bm2_array_f4( unsigned int count, vector float *s_array, vector float *t_array );
void mc_transform_bm2_array_d2( unsigned int count, vector double *s_array, vector double *t_array );

//
//  C++ interface
//
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* _MC_TRANSFORM_BM2_H_ */
