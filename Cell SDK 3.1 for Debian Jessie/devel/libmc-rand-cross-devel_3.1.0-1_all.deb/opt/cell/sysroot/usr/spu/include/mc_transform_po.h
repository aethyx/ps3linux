/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2007,2008, All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

// Prototypes for Box-Muller polar form transform

#ifndef _MC_TRANSFORM_PO_H_
#define _MC_TRANSFORM_PO_H_

//
//  C++ interface
//
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

// Single vectors
//__inline vector float _transform_po_f4(vector float (*p_rng)());
vector float mc_transform_po_f4(vector float (*p_rng)());
vector double mc_transform_po_d2(vector double (*p_rng)());

// More than one vector
void mc_transform_po_array_f4( unsigned int count, vector float *s_array, vector float *t_array, vector float (*p_rng)() ) ;
unsigned int mc_transform_reject_po_array_f4( unsigned int count, vector float *s_array, vector float *t_array ) ;
void mc_transform_po_array_d2( unsigned int count, vector double *s_array, vector double *t_array, vector double (*p_rng)() ) ;
unsigned int mc_transform_reject_po_array_d2( unsigned int count, vector double *s_array, vector double *t_array ) ;

//
//  C++ interface
//
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* _MC_TRANSFORM_PO_H_ */
