/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2008       All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

// Prototypes for Box-Muller Transform

#ifndef _MC_TRANSFORM_BM_H_
#define _MC_TRANSFORM_BM_H_

//
//  C++ interface
//
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

vector float mc_transform_bm_f4(vector float src);
vector double mc_transform_bm_d2(vector double src);

void mc_transform_bm_array_f4( unsigned int count, vector float *s_array, vector float *t_array );
void mc_transform_bm_array_d2( unsigned int count, vector double *s_array, vector double *t_array ) ;

//
//  C++ interface
//
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* _MC_TRANSFORM_BM_H_ */
