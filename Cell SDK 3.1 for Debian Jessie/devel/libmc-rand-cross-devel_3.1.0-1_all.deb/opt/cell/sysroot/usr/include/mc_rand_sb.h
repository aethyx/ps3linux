/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2007,2008, All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

#ifndef _MC_RAND_SB_H_
#define _MC_RAND_SB_H_

#ifdef __SPU__
#include <spu_intrinsics.h>
#endif

//
//  C++ interface
//
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

	// >> define sobol control block for 32 bit only
        typedef struct
        {
                vector unsigned int * pu32_vecDirection;      // pointer to init table for sobol RNs -> u32TableBitCount = 32
                unsigned int u32sizeofTable;                  // size of table in bytes
                unsigned int u32TableDimension;               // max dimension supported by this table
                unsigned int u32TableBitCount;                // max bit count this table can hold  >= (u32MaxBitCount+3)&0xFFFFFFFC
                unsigned int u32MaxBitCount;                  // max bit count this table supports
                unsigned int u32Seed;                         // index where RNG will start to generate RNs
        } sobol_cntrlblck_t;
	// define sobol control block for 32 bit only <<


	// >> define sobol control block with 64 bit support
        typedef struct
        {
                unsigned long long ptr_vecDirection;      // pointer to init table for sobol RNs -> u32TableBitCount = 32
                unsigned int u32sizeofTable;                  // size of table in bytes
                unsigned int u32TableDimension;               // max dimension supported by this table
                unsigned int u32TableBitCount;                // max bit count this table can hold  >= (u32MaxBitCount+3)&0xFFFFFFFC
                unsigned int u32MaxBitCount;                  // max bit count this table supports
        } sobol_1_cntrlblck_t;
	// define sobol control block with 64 bit support <<

    // for use on SPU only
    #ifdef __SPU__

	#define SOBOL_DIMENSION 40
	#define SOBOL_RUNS 112
	#define SOBOL_VECTOR_ARRAY_SIZE ((SOBOL_RUNS + 76) * SOBOL_DIMENSION + 8)

	// Initialization routines
	unsigned int mc_rand_sb_init( sobol_cntrlblck_t * s_CB, unsigned int u32MaxArrayLen, unsigned int dimension, vector unsigned char * memory, unsigned int size_of_memory);
	unsigned int mc_rand_sb1_init( sobol_1_cntrlblck_t * s_CB, unsigned int u32MaxArrayLen, unsigned int dimension, vector unsigned char * memory, unsigned int size_of_memory);
	void mc_rand_sb_seed(unsigned int seed);

	// Return single vectors of RNGs
	vector float mc_rand_sb_0_to_1_f4(void);
	vector float mc_rand_sb_minus1_to_1_f4(void);
	vector double mc_rand_sb_0_to_1_d2(void);
	vector double mc_rand_sb_minus1_to_1_d2(void);
	vector unsigned int mc_rand_sb_u4(void);

	// Return more than one vector of RNGs
	vector float * mc_rand_sb_0_to_1_array_f4(unsigned int u32ArrayLen);
	vector float * mc_rand_sb_minus1_to_1_array_f4(unsigned int u32ArrayLen);
	vector double * mc_rand_sb_0_to_1_array_d2(unsigned int u32ArrayLen);
	vector double * mc_rand_sb_minus1_to_1_array_d2(unsigned int u32ArrayLen);
	vector unsigned int * mc_rand_sb_array_u4(unsigned int u32ArrayLen);

   #endif

//
//  C++ interface
//
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* _MC_RAND_SB_H_ */

