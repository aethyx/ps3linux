/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2008       All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

#ifndef _MC_RAND_HDSB_H_
#define _MC_RAND_HDSB_H_

#ifdef __SPU__
#include <spu_intrinsics.h>
#endif

//
//  C++ interface
//
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

        typedef struct
        {
//            unsigned long long ptr_swap_memory;
            unsigned long long ptr_rn_memory;
            unsigned long long size_rn_memory;
            unsigned long long ptr_rn_array;
            unsigned long long size_rn_array;

            unsigned long long ptr_direction_table;      // pointer to init table for sobol RNs -> u32TableBitCount = 32

            unsigned int dimension;
            unsigned int runs;
            unsigned int seed;
           
            unsigned int u32sizeofTable;                  // size of table in bytes
            unsigned int u32TableDimension;               // max dimension supported by this table
            unsigned int u32TableBitCount;                // max bit count this table can hold  >= (u32MaxBitCount+3)&0xFFFFFFFC
            unsigned int u32MaxBitCount;                  // max bit count this table supports

//            unsigned char u8NodeSwap;
            unsigned char u8NodeRnArray;

        } mc_rand_hdsb_cntrlblck_t;

    // for use on SPU only
    #ifdef __SPU__

	// Initialization routines
        unsigned int mc_rand_sb2_init(mc_rand_hdsb_cntrlblck_t *pCB, unsigned int runs, unsigned int dim, unsigned long long ptr_rn_array, unsigned long long rn_array_size);
        void mc_rand_sb2_seed(unsigned int);
        void  mc_rand_sb2_terminate(void);

	// Return single vectors of RNGs
	vector unsigned int mc_rand_sb2_u4(void);
	vector float  mc_rand_sb2_0_to_1_f4(void);
	vector float  mc_rand_sb2_minus1_to_1_f4(void);
	vector double mc_rand_sb2_0_to_1_d2(void);
	vector double mc_rand_sb2_minus1_to_1_d2(void);

	// Return more than one vector of RNGs
        unsigned long long mc_rand_sb2_array_u4(unsigned int number_of_random_numbers);
        unsigned long long mc_rand_sb2_0_to_1_array_f4(unsigned int number_of_random_numbers);
        unsigned long long mc_rand_sb2_minus1_to_1_array_f4(unsigned int number_of_random_numbers);
        unsigned long long mc_rand_sb2_0_to_1_array_d2(unsigned int number_of_random_numbers);
        unsigned long long mc_rand_sb2_minus1_to_1_array_d2(unsigned int number_of_random_numbers);
   #endif

//
//  C++ interface
//
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* _MC_RAND_SB_H_ */

