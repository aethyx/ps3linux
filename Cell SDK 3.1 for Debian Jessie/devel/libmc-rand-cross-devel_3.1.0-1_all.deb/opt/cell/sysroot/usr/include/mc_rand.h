/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2008       All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
/*
 */
#ifndef MC_RAND_H_INCLUDED
#define MC_RAND_H_INCLUDED

/*
 * C++
 */
#ifdef __cplusplus
extern "C" {
#endif

#include <mc_rand_sb2.h>

/**
 * @file
 * @brief Monte Carlo PPE API
 */

/**
 * @brief Operation types
 */
typedef enum
{
    MC_RAND_NONE    = 0,

    MC_RAND_MT      = 0x10,     /**< Mersenne Twister */
    MC_RAND_DCMT    = 0x20,     /**< Dynamic Creator Mersenne Twister */
    MC_RAND_SFMT    = 0x30,     /**< SIMD Fast Mersenne Twister */
    MC_RAND_KS      = 0x40,     /**< Kirkpatric-Stoll */
    MC_RAND_SB      = 0x50,     /**< Sobol */
    MC_RAND_SB_HD   = 0x60,     /**< High-Dimensional Sobol*/
    MC_RAND_HW      = 0x70,     /**< Hardware-generated */

    MC_RAND_PO      = 0x100,    /**< Polar Method */
    MC_RAND_BM      = 0x200,    /**< Box-Muller Sine only */
    MC_RAND_BM2     = 0x300,    /**< Box-Muller Sine-Cosine */
    MC_RAND_MI      = 0x400,    /**< Moro's Inversion */
    MC_RAND_ICDF    = 0x500,    /**< Inverse Cumulative Distribution Function */

} mc_rand_operation_t;

/**
 * @brief Random number generator datatypes
 */
typedef enum
{
    MC_RAND_U4                  = 0x1,      /**< 32-bit unsigned int RNs*/
    MC_RAND_0_TO_1_F4           = 0x2,      /**< float RNs in ]0,1[ with 32-bit  */
    MC_RAND_MINUS1_TO_1_F4      = 0x3,      /**< float RNs in ]-1,1[ with 32-bit */
    MC_RAND_0_TO_1_D2           = 0x4,      /**< double RNs in ]0,1[ with 32-bit */
    MC_RAND_MINUS1_TO_1_D2      = 0x5,      /**< double RNs in ]-1,1[ with 32-bit */
    MC_RAND_0_TO_1_D2_EXT       = 0x6,      /**< double RNs in ]0,1[ with 64-bit */
    MC_RAND_MINUS1_TO_1_D2_EXT  = 0x7,      /**< double RNs in ]-1,1[ with 64-bit */

} mc_rand_datatype_t;


typedef struct
{
    unsigned int        u32Seed;
} mc_rand_ks_parameters_t;

typedef struct
{
    unsigned int        u32Seed;
} mc_rand_mt_parameters_t;

typedef struct
{
    unsigned int        u32Seed;
    unsigned int        u32mExp;
    unsigned int        u32Line;
} mc_rand_sfmt_parameters_t;

typedef struct
{
    unsigned int        u32Seed;
    unsigned int        u32mExp;
    unsigned int        u32Line;
} mc_rand_dcmt_parameters_t;

typedef struct
{
    /* sobol table data */
    unsigned long long      pu32_vecDirections;
    unsigned int            u32sizeofTable;
    unsigned int            u32TableDimension;
    unsigned int            u32TableBitCount;
    unsigned int            u32MaxBitCount;

    /* data to configure the state */
    unsigned int            u32Seed;
    unsigned int            u32Dimensions;
} mc_rand_sb_parameters_t;

typedef mc_rand_hdsb_cntrlblck_t mc_rand_sb2_parameters_t;

struct mc_rand_handle_s;
typedef struct mc_rand_handle_s* mc_rand_handle_t;

typedef enum
{
    MC_RAND_OK                  =  0,
    MC_RAND_INVALID_PARAMETER   = -1,
    MC_RAND_OUT_OF_MEMORY       = -2,
    MC_RAND_INVALID_HANDLE      = -3,
    MC_RAND_INVALID_OPERATION   = -4,
    MC_RAND_NO_MEMORY           = -5,
    MC_RAND_NO_ALIGNMENT        = -6,
    MC_RAND_FAILURE             = -7,
    MC_RAND_INVALID_COMBINATION = -8,

} mc_rand_error_t;

/**
 * @brief Initialization function
 * 
 * @param handle        (out) Context handle
 * @param datatype      (in) Random number generator datatype
 * @param spes          (in) Maximum number of SPEs to use
 */

int mc_rand_initialize ( mc_rand_handle_t *handle,
                        mc_rand_datatype_t datatype,
                        unsigned int spes );


/**
 * @brief Add operation function
 *
 * @param handle            (int/out) Context handle
 * @param operation         (in) Type of operation
 * @param parameters        (in) Operation parameters (structure array)
 * @param parameter_count   (in) Number of elements in parameters structure array
 */

int mc_rand_add_operation ( mc_rand_handle_t handle,
                            mc_rand_operation_t operation,
                            void *parameters,
                            unsigned int parameter_count );

/**
 * @brief Random number generation and transform function
 *
 * @param handle        (in/out) Context handle
 * @param output        (out) Array where the created RNs will be stored
 * @param vector_count  (in) Number of RNs to be created in terms of vectors (data type vector)
 */
int mc_rand_perform (  mc_rand_handle_t handle,
                        void *output,
                        unsigned int vector_count );


/**
 * @brief Terminate function
 *
 * Destroy then handle and free resources associated with it
 * @param handle    (in/out) Context handle
 */

int mc_rand_terminate ( mc_rand_handle_t handle );

/*
 * C++
 */
#ifdef __cplusplus
}
#endif

#endif /* MC_RAND_H_INCLUDED */
