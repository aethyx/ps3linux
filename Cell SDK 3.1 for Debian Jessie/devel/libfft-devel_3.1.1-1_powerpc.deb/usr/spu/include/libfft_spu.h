/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2007,2008, All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */


#ifndef FFT_1D_SPU_H
#define FFT_1D_SPU_H

//#include "libfft.h"
#define FFT_DOUBLE_PRECISION    0x001
#define FFT_INPUT_REAL          0x002
#define FFT_OUTPUT_REAL         0x004
#define FFT_TILED               0x008
#define FFT_TILE_TO_RECTANGULAR 0x010

#define FFT_TYPE_C2C            0x020
#define FFT_TYPE_R2C            0x040
#define FFT_TYPE_C2R            0x080

#define FFT_ARRAY_OF_ROWS       0x100

#define FFT_RC_SUCCESS        0
#define FFT_RC_NO_SPUS       -1
#define FFT_RC_BAD_DIMENSION -2
#define FFT_RC_NO_INVERSE    -3
#define FFT_RC_BAD_PARM      -4
#define FFT_RC_FAILED        -5
#define FFT_RC_NOT_IMPLEMENTED -6
#define        MAXINT          INT_MAX
#define E_TAG_RESERVE -7

// FFT batch mode SPU-only function prototypes
int fft_1d_c2c_spu(unsigned int num_elems, vector float* srcAddr, vector float* dstAddr, unsigned int inverse_flag);
int fft_1d_c2r_spu(unsigned int num_elems, vector float* srcAddr, vector float* dstAddr, unsigned int inverse_flag);
int fft_1d_r2c_spu(unsigned int num_elems, vector float* srcAddr, vector float* dstAddr, unsigned int inverse_flag);

#endif
