/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2008       All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

// Prototypes for Inverse CDF transform

#ifndef _MC_TRANSFORM_ICDF_H_
#define _MC_TRANSFORM_ICDF_H_

vector float mc_transform_icdf_f4(  vector float x );
vector double mc_transform_icdf_d2(  vector double x );

void mc_transform_icdf_array_f4( unsigned int n, vector float *source, vector float *dest );
void mc_transform_icdf_array_d2( unsigned int n, vector double *source, vector double *dest );

#endif
