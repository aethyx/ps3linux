/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2007,2008, All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

// Prototypes for Moro's Inversion transform

#ifndef _MC_TRANSFORM_MI_H_
#define _MC_TRANSFORM_MI_H_

//
//  C++ interface
//
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

// Single vectors
vector float  mc_transform_mi_f4(vector float);
vector double mc_transform_mi_d2(vector double);

// More than one vector
void mc_transform_mi_array_f4(unsigned int, vector float *, vector float *);
void mc_transform_mi_array_d2(unsigned int, vector double *, vector double *);

//
//  C++ interface
//
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* _MC_TRANSFORM_MI_H_ */
