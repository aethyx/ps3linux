/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */


/* **********************************************************************

   -- Purpose   :Prototypes for kernel routines 
                  
************************************************************************* */

#ifndef __BLAS_S_H__

#define __BLAS_S_H__

/* BLAS level 1 routines */

void saxpy_spu( float *x, float *y, float alpha, int len ) ;
void scopy_spu ( float *x, float *y, int len ) ;
float sdot_spu( float *x, float *y, int len ) ;
void sscal_spu( float *x, float alpha, int len ) ;
int isamax_spu( float *x, int len ) ;
double dasum_spu( double *x, int len ) ;
void daxpy_spu( double *x, double *y, double alpha, int len ) ;
void dcopy_spu ( double *x, double *y, int len ) ;
double ddot_spu( double *x, double *y, int len ) ;
double dnrm2_spu(int, double*);
double dnrm2_edp_spu(int, double*);
void drot_spu(int n, double *dx, double *dy, double c, double s);
void dscal_spu( double *x, double alpha, int len ) ;
int idamax_spu( double *x,  int len );
int idamax_edp_spu( double *x,  int len );

/* BLAS level 2 routines */

void sgemv_spu(int m, int n, float alpha, float *a, float *x, float *y); 
void sgemv_t_spu(int m, int n, float alpha, float *a, float *x, float *y);
void dgemv_spu(int m, int n, double alpha, double *a, double *x, double *y);
void dgemv_t_spu(int m, int n, double alpha, double *a, double *x, double *y);
void dger_spu( unsigned int P, unsigned int Q, double alpha, double *x,
                    double *y, double *A, unsigned int ldA, double beta );
void dger_op_spu( unsigned int P, unsigned int Q, double alpha, double *x,
                    double *y, double *A, unsigned int ldA );
void  dsymv_spu_lower( unsigned int N, double alpha, double *A, int ldA, double *X, double *Y );
void  dtrsv_spu_upper( unsigned int N, double *blkA, int lda, double *blkX) ;
void  dtrsv_spu_lower( unsigned int N, double *A, int ldA, double *X );
void sger_spu( unsigned int P, unsigned int Q, float alpha, float *x,
                    float *y, float *A, unsigned int ldA, float beta );
void sger_op_spu( unsigned int P, unsigned int Q, float alpha, float *x,
                    float *y, float *A, unsigned int ldA );
void  strsv_spu_upper( unsigned int N, float *A, int lda, float *X);
void  strsv_spu_lower( unsigned int N, float *A, int ldA, float *X);

/* BLAS level 3 routines */

void sgemm_spu( int M, int N, int K, float *A, float *B, float *C );
void strsm_spu(int m, int n, float *aa, float *bb);
void strsm_64x64( float* A, float* B);
void strsm_spu_upper(unsigned int n, unsigned int m, float *aa,
               float *bb, unsigned int lda, unsigned int ldb);
void ssyrk_64x64(float *blkA, float *blkC, float *Alpha) ;
void ssyrk_spu(float *blkA, float *blkC, float Alpha, unsigned int P, unsigned int Q,
                    unsigned int lda, unsigned int ldc);
void dgemm_64x64( double *C, double *A, double *B );
void dgemm_spu( int M, int N, int K, double *A, double *B, double *C );
void dsyr2k_64x64_lower(double *blkA, double *blkB, double *blkC) ;
void dsyr2k_spu_lower(unsigned int n, unsigned int k, double *blkA, double *blkB, double *blkC) ;
void dsyrk_64x64(double *blkA, double *blkC, double Alpha) ;
void dsyrk_spu(double *blkA, double *blkC, double Alpha, unsigned int P,
                 unsigned int Q, unsigned int lda, unsigned int ldc) ;
void dtrmm_64x64_upper_trans_left(double *a, double *b) ;
void dtrmm_spu_upper_trans_left( int P, int Q, double *a, double *b) ;
void dtrmm_64x64_upper_left(double *a, double *b) ;
void dtrmm_spu_upper_left( int P, int Q, double *a, double *b) ;
void dtrsm_spu_upper(unsigned int n, unsigned int m, double *aa,
               double *bb, unsigned int lda, unsigned int ldb);
void dtrsm_spu_lower(unsigned int m, unsigned int n, double *aa,
               double *bb, unsigned int lda, unsigned int ldb);
void dtrsm64x64_upper( double *aa, double *bb);
void dtrsm64x64_lower( double *aa, double *bb);
void ssyr2k_spu_lower(unsigned int n, unsigned int k, float *A, float *B, float *C);
void ssyr2k_64x64_lower(float *A, float *B, float *C);
void strmm_64x64_upper_trans_left(float *a, float *b) ;
void strmm_spu_upper_trans_left( int P, int Q, float *a, float *b) ;
void strmm_64x64_upper_left(float *a, float *b) ;
void strmm_spu_upper_left( int P, int Q, float *a, float *b) ;

#endif
