/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

/* *****************************************************************************
 * Purpose : Prototypes for BLAS functions   
 *     
 **************************************************************************** */

#ifndef __BLAS_H__
#define __BLAS_H__

#ifdef __cplusplus
extern "C"
{
#endif

typedef struct { float r, i; } complex;
typedef struct { double r, i; } doublecomplex;


    // SP level 1 //
    extern double snrm2_(int *, float *, int *);
    extern double sasum_(int *, float *, int *);
    extern int sswap_(int *, float *, int *, float *, int *);
    extern int srot_(int *, float *, int *, float *, int *, float *, float *);
    extern int srotg_(float *, float *, float *, float *);
    extern int sscal_(int *, float *, float *, int *);
    extern int isamax_(int *, float *, int *);
    extern double sdot_(int *, float *, int *, float *, int *);
    extern int scopy_(int *, float *, int *, float *, int *);
    extern int saxpy_(int *, float *, float *, int *, float *, int *) ;

    // DP level 1 //
    extern int drotg_(double *, double *, double *, double *);
    extern double dnrm2_(int *, double *, int *);
    extern double dasum_(int *, double *, int *);
    extern int dswap_(int *, double *, int *, double *, int *);
    extern int drot_(int *, double *, int *, double *, int *, double *, double *);
    extern int idamax_(int *, double *, int *);
    extern int dscal_(int *, double *, double *, int *);
    extern double ddot_(int *, double *, int *, double *, int *);
    extern int dcopy_(int *, double *, int *, double *, int *);
    extern int daxpy_(int *, double *, double *, int *, double *, int *); 


    // SP level 2 //
    extern int sgbmv_(char *, int *, int *, int * , int *, float *, float *, int *, float *, int *, float *, float *, int *);
    extern int sspmv_(char *, int *, float *, float *, float *, int *, float *, float *, int *);
    extern int ssymv_(char *, int *, float *, float *, int *, float *, int *, float *, float *, int *);
    extern int sgemv_(char *, int *, int * , float *, float *, int *, float *, int *, float *, float *, int *);
    extern int ssbmv_(char *, int *, int *, float *, float *, int *, float *, int *, float *, float *, int *);
    extern int stpmv_(char *, char *, char *, int *, float *, float *, int *);
    extern int strmv_(char *, char *, char *, int *, float *, int *, float *, int *);
    extern int stpsv_(char *, char *, char *, int *, float *, float *, int *);
    extern int strsv_(char *, char *, char *, int *, float *, int *, float *, int *);
    extern int stbmv_(char *, char *, char *, int *, int *, float *, int *, float *, int *);
    extern int stbsv_(char *, char *, char *, int *, int *, float *, int *, float *, int *);
    extern int sger_(int *, int *, float *, float *, int *, float *, int *, float *, int *);
    extern int sspr_(char *, int *, float *, float *, int *, float *);
    extern int ssyr_(char *, int *, float *, float *, int *, float *, int *);
    extern int ssyr2_(char *, int *, float *, float *, int *, float *, int *, float *, int *);
    extern int sspr2_(char *, int *, float *, float *, int *, float *, int *, float *);

    // DP level 2 //
    extern int dgbmv_(char *, int *, int *, int * , int *, double *, double *, int *, double *, int *, double *, double *, int *);
    extern int dgemv_(char *, int *, int *, double *, double *, int *, double *, int *, double *, double *, int *);
    extern int dsymv_(char *, int *, double *, double *, int *, double *, int *, double *, double *, int *);
    extern int dsbmv_(char *, int *, int *, double *, double *, int *, double *, int *, double *, double *, int *);
    extern int dspmv_(char *, int *, double *, double *, double *, int *, double *, double *, int *);
    extern int dtpmv_(char *, char *, char *, int *, double *, double *, int *);
    extern int dtrmv_(char *, char *, char *, int *, double *, int *, double *, int *);
    extern int dtpsv_(char *, char *, char *, int *, double *, double *, int *);
    extern int dtbmv_(char *, char *, char *, int *, int *, double *, int *, double *, int *);
    extern int dtrsv_(char *, char *, char *, int *, double *, int *, double *, int *);
    extern int dtbsv_(char *, char *, char *, int *, int *, double *, int *, double *, int *);
    extern int dger_(int *, int *, double *, double *, int *, double *, int *, double *, int *);
    extern int dsyr_(char *, int *, double *, double *, int *, double *, int *);
    extern int dspr_(char *, int *, double *, double *, int *, double *);
    extern int dspr2_(char *, int *, double *, double *, int *, double *, int *, double *);
    extern int dsyr2_(char *, int *, double *, double *, int *, double *, int *, double *, int *);

    // SP level 3 //
    extern int sgemm_(char *, char *, int *, int *, int *, float *, float *, 
                      int *, float *, int *, float *, float *, int *);
    extern int ssyrk_(char *, char *, int *, int *, float *, float *, int *, 
                      float *, float *, int *);
    extern int strsm_(char *, char *, char *, char *, int *, int *, float *, 
                      float *, int *, float *, int *);
    extern int strmm_(char *, char *, char *, char *, int *, int *, float *, 
                      float *, int *, float *, int *);
    extern int ssymm_(char *, char *, int *, int *, float *, float *, int *, 
                      float *, int *, float *, float *, int *);
    extern int ssyr2k_(char *, char *, int *, int *, float *, float *, int *,
                       float *, int *, float *, float *, int *);

    //DP level 3 //
    extern int dgemm_(char *, char *, int *, int *, int *, double *, double *, 
                      int *, double *, int *, double *, double *, int *); 
    extern int dsyrk_(char *, char *, int *, int *,
                      double *, double *, int *, double *, double *, int *);
    extern int dtrsm_(char *, char *, char *, char *, int *, int *,
                      double *, double *, int *, double *, int *);
    extern int dtrmm_(char *, char *, char *, char *, int *, int *,
                      double *, double *, int *, double *, int *);
    extern int dsyr2k_(char *, char *, int *, int *, double *, double *, 
                       int *, double *, int *, double *, double *, int *);
    extern int dsymm_(char *, char *, int *, int *, double *, double *, int *, double *, int *,
                      double *, double *, int *);
                      
    /*Complex Routines*/
    extern void 
    cdotu_(complex* retval,
           int* N, 
           complex* X, int* incX, 
           complex* Y, int* incY);
    
    extern void
    cdotc_(complex* retval,
           int* N, 
           complex* X, int* incX, 
           complex* Y, int* incY);
    
    extern int
    icamax_(int* N,
            complex* X, int* incX);
    
    extern int
    cswap_(int* N,
           complex* X, int* incX,
           complex* Y, int* incY);
    
    extern int
    ccopy_(int* N,
           complex* X, int* incX,
           complex* Y, int* incY);
    
    extern int
    caxpy_(int* N,
          complex* alpha,
          complex* X, int* incX,
          complex* Y, int* incY);
    
    extern int 
    csrot_(int* N, 
           complex* X, 
           int* incX,
            complex* Y,
            int* incY,
             float* c,
             float* s);
    extern int
    cscal_(int* N,
           complex* alpha,
           complex* X, int* incX);
    extern int
    csscal_(int* N,
            float* alpha,
            complex* X, int* incX);
    extern int
    cgemv_(char* trans, int* M, int* N,
           complex* alpha,
           complex* A, int* lda,
           complex* X, int* incX,
           complex* beta,
           complex* Y, int* incY);
    
    extern int 
    cgbmv_(char *trans, int *M, int *N, int *KL, int *KU, 
           complex *alpha, 
           complex *A, int *lda, 
           complex *X, int *incX, 
           complex *beta, 
           complex *Y, int *incY);
    
    extern int 
    ctrmv_(char* uplo, char *trans, char* diag, int *N,  
           complex *A, int *lda, 
           complex *X, int *incX);
    
    extern int
    ctbmv_(char* uplo, char* trans, char* diag, int* N, int* K,
           complex* A, int* lda,
           complex* X, int* incX);
    
    extern int
    ctpmv_(char* uplo, char* trans, char* diag, int* N, 
           complex* Ap, 
           complex* X, int* incX);
    
    extern int
    ctrsv_(char* uplo, char* trans, char* diag, int* N,
           complex* A, int* lda,
           complex* X, int* incX);
    
    extern int
    ctbsv_(char* uplo, char* trans, char* diag, int* N, int* K,
           complex* A, int* lda, 
           complex* X, int* incX);
    
    extern int
    ctpsv_(char* uplo, char* trans, char* diag, int* N, 
           complex* Ap, 
           complex* X, int* incX);
    extern int
    chemv_(char* uplo, int* N,
           complex* alpha,
           complex* A, int* lda,
           complex* X, int* incX,
           complex* beta,
           complex* Y, int* incY);
    
    extern int
    chbmv_(char* uplo, int* N, int* K,
           complex* alpha,
           complex* A, int* lda,
           complex* X, int* incX,
           complex* beta,
           complex* Y, int* incY);
    
    extern int
    chpmv_(char* uplo, int* N, 
           complex* alpha,
           complex* Ap, 
           complex* X, int* incX,
           complex* beta,
           complex* Y, int* incY);
    
    extern int
    cgeru_(int* M, int* N,
           complex* alpha,
           complex* X, int* incX,
           complex* Y, int* incY,
           complex* A, int* lda);
    
    extern int
    cgerc_(int* M, int* N,
           complex* alpha,
           complex* X, int* incX,
           complex* Y, int* incY,
           complex* A, int* lda);
    
    extern int
    cher_(char* uplo, int* N,
          float* alpha,
          complex* X, int* incX,
          complex* A, int* lda);
    
    extern int
    chpr_(char* uplo, int* N,
          float* alpha,
          complex* X, int* incX,
          complex* Ap);
    
    extern int
    cher2_(char* uplo, int* N,
           complex* alpha,
           complex* X, int* incX,
           complex* Y, int* incY,
           complex* A, int* lda);
    
    extern int
    chpr2_(char* uplo, int* N,
           complex* alpha,
           complex* X, int* incX,
           complex* Y, int* incY,
           complex* Ap);
    extern int
    cgemm_(char* transA, char* transB, int* M, int* N, int* K,
           complex* alpha,
           complex* A, int* lda,
           complex* B, int* ldb,
           complex* beta,
           complex* C, int* ldc);
    
    extern int
    csymm_(char* side, char* uplo, int* M, int* N,
           complex* alpha,
           complex* A, int* lda,
           complex* B, int* ldb,
           complex* beta,
           complex* C, int* ldc);
    
    extern int
    csyrk_(char* uplo, char* trans, int* N, int* K,
           complex* alpha,
           complex* A, int* lda,
           complex* beta,
           complex* C, int* ldc);
    
    extern int
    csyr2k_(char* uplo, char* trans, int* N, int* K,
            complex* alpha,
            complex* A, int* lda,
            complex* B, int* ldb,
            complex* beta,
            complex* C, int* ldc);
    
    extern int
    ctrmm_(char* side, char* uplo, char* trans, char* diag, 
           int* M, int* N,
           complex* alpha,
           complex* A, int* lda,
           complex* B, int* ldb);
    
    extern int 
    ctrsm_(char* side, char* uplo, char* trans, char* diag,
           int* M, int* N,
           complex* alpha,
           complex* A, int* lda,
           complex* B, int* ldb);
    extern int
    chemm_(char* side, char* uplo, int* M, int* N,
           complex* alpha,
           complex* A, int* lda,
           complex* B, int* ldb,
           complex* beta,
           complex* C, int* ldc);
    
    extern int
    cherk_(char* uplo, char* trans, int* N, int* K,
           float* alpha,
           complex* A, int* lda,
           float* beta,
           complex* C, int* ldc);
    
    extern int
    cher2k_(char* uplo, char* trans, int* N, int* K,
            complex* alpha,
            complex* A, int* lda,
            complex* B, int* ldb,
            float* beta,
            complex* C, int* ldc);
    
    /* Double Complex Routines */
    
    extern void
    zdotu_(doublecomplex* retval,
           int* N, 
           doublecomplex* X, int* incX, 
           doublecomplex* Y, int* incY);
    
    extern void
    zdotc_(doublecomplex* retval,
           int* N, 
           doublecomplex* X, int* incX, 
           doublecomplex* Y, int* incY);
    extern double 
    dznrm2_(int* N, 
            doublecomplex* X, int* incX);
    
    extern double
    dzasum_(int* N, 
            doublecomplex* X, int* incX);
    extern int
    izamax_(int* N,
            doublecomplex* X, int* incX);
    
    extern int
    zswap_(int* N,
           doublecomplex* X, int* incX,
           doublecomplex* Y, int* incY);
    
    extern int
    zcopy_(int* N,
           doublecomplex* X, int* incX,
           doublecomplex* Y, int* incY);
    
    extern int
    zaxpy_(int* N,
           doublecomplex* alpha,
           doublecomplex* X, int* incX,
           doublecomplex* Y, int* incY);
    
    extern int  
    zdrot_(int* N, 
           doublecomplex* X, 
           int* incX,
           doublecomplex* Y,
           int* incY,
           double* c,
           double* s);
    
    extern int
    zscal_(int* N,
           doublecomplex* alpha,
           doublecomplex* X, int* incX);
    
    extern int
    zdscal_(int* N,
            double* alpha,
            doublecomplex* X, int* incX);
    
    extern int
    zgemv_(char* trans, int* M, int* N,
           doublecomplex* alpha,
           doublecomplex* A, int* lda,
           doublecomplex* X, int* incX,
           doublecomplex* beta,
           doublecomplex* Y, int* incY);
    
    extern int 
    zgbmv_(char *trans, int *M, int *N, int *KL, int *KU, 
           doublecomplex *alpha, 
           doublecomplex *A, int *lda, 
           doublecomplex *X, int *incX, 
           doublecomplex *beta, 
           doublecomplex *Y, int *incY);
    
    extern int 
    ztrmv_(char* uplo, char *trans, char* diag, int *N,  
           doublecomplex *A, int *lda, 
           doublecomplex *X, int *incX);
    
    extern int
    ztbmv_(char* uplo, char* trans, char* diag, int* N, int* K,
           doublecomplex* A, int* lda,
           doublecomplex* X, int* incX);
    
    extern void  
    ztpmv_(char* uplo, char* trans, char* diag, int* N, 
          doublecomplex* Ap, 
          doublecomplex* X, int* incX);
    
    extern int
    ztrsv_(char* uplo, char* trans, char* diag, int* N,
           doublecomplex* A, int* lda,
           doublecomplex* X, int* incX);
    
    extern int
    ztbsv_(char* uplo, char* trans, char* diag, int* N, int* K,
           doublecomplex* A, int* lda, 
           doublecomplex* X, int* incX);
    
    extern int
    ztpsv_(char* uplo, char* trans, char* diag, int* N, 
           doublecomplex* Ap, 
           doublecomplex* X, int* incX);
    
    extern int
    zhemv_(char* uplo, int* N,
           doublecomplex* alpha,
           doublecomplex* A, int* lda,
           doublecomplex* X, int* incX,
           doublecomplex* beta,
           doublecomplex* Y, int* incY);
    
    extern int
    zhbmv_(char* uplo, int* N, int* K,
           doublecomplex* alpha,
           doublecomplex* A, int* lda,
           doublecomplex* X, int* incX,
           doublecomplex* beta,
           doublecomplex* Y, int* incY);
    
    extern int
    zhpmv_(char* uplo, int* N, 
           doublecomplex* alpha,
           doublecomplex* Ap, 
           doublecomplex* X, int* incX,
           doublecomplex* beta,
           doublecomplex* Y, int* incY);
    
    extern int
    zgeru_(int* M, int* N,
           doublecomplex* alpha,
           doublecomplex* X, int* incX,
           doublecomplex* Y, int* incY,
           doublecomplex* A, int* lda);
    
    extern int
    zgerc_(int* M, int* N,
           doublecomplex* alpha,
           doublecomplex* X, int* incX,
           doublecomplex* Y, int* incY,
           doublecomplex* A, int* lda);
    
    extern int
    zher_(char* uplo, int* N,
          double* alpha,
          doublecomplex* X, int* incX,
          doublecomplex* A, int* lda);
    
    extern int
    zhpr_(char* uplo, int* N,
          double* alpha,
          doublecomplex* X, int* incX,
          doublecomplex* Ap);
    
    extern int
    zher2_(char* uplo, int* N,
           doublecomplex* alpha,
           doublecomplex* X, int* incX,
           doublecomplex* Y, int* incY,
           doublecomplex* A, int* lda);
    
    extern int
    zhpr2_(char* uplo, int* N,
           doublecomplex* alpha,
           doublecomplex* X, int* incX,
           doublecomplex* Y, int* incY,
           doublecomplex* Ap);
    
    extern int
    zgemm_(char* transA, char* transB, int* M, int* N, int* K,
           doublecomplex* alpha,
           doublecomplex* A, int* lda,
           doublecomplex* B, int* ldb,
           doublecomplex* beta,
           doublecomplex* C, int* ldc);
    
    extern int
    zsymm_(char* side, char* uplo, int* M, int* N,
           doublecomplex* alpha,
           doublecomplex* A, int* lda,
           doublecomplex* B, int* ldb,
           doublecomplex* beta,
           doublecomplex* C, int* ldc);
    
    extern int
    zsyrk_(char* uplo, char* trans, int* N, int* K,
           doublecomplex* alpha,
           doublecomplex* A, int* lda,
           doublecomplex* beta,
           doublecomplex* C, int* ldc);
    
    extern int
    zsyr2k_(char* uplo, char* trans, int* N, int* K,
            doublecomplex* alpha,
            doublecomplex* A, int* lda,
            doublecomplex* B, int* ldb,
            doublecomplex* beta,
            doublecomplex* C, int* ldc);
    
    extern int
    ztrmm_(char* side, char* uplo, char* trans, char* diag, 
           int* M, int* N,
           doublecomplex* alpha,
           doublecomplex* A, int* lda,
           doublecomplex* B, int* ldb);
    
    extern int 
    ztrsm_(char* side, char* uplo, char* trans, char* diag,
           int* M, int* N,
           doublecomplex* alpha,
           doublecomplex* A, int* lda,
           doublecomplex* B, int* ldb);
    
    extern int
    zhemm_(char* side, char* uplo, int* M, int* N,
           doublecomplex* alpha,
           doublecomplex* A, int* lda,
           doublecomplex* B, int* ldb,
           doublecomplex* beta,
           doublecomplex* C, int* ldc);
    
    extern int
    zherk_(char* uplo, char* trans, int* N, int* K,
           double* alpha,
           doublecomplex* A, int* lda,
           double* beta,
           doublecomplex* C, int* ldc);
    
    extern int
    zher2k_(char* uplo, char* trans, int* N, int* K,
            doublecomplex* alpha,
            doublecomplex* A, int* lda,
            doublecomplex* B, int* ldb,
            double* beta,
            doublecomplex* C, int* ldc);
     
#ifdef __cplusplus
}
#endif                                

#endif
