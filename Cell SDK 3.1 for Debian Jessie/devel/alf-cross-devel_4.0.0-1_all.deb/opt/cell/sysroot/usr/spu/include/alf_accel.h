/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef __ALF_ACCEL_H_
#define __ALF_ACCEL_H_

#include <alf_config.h>
#include <alf_def.h>

#ifdef _ALF_PLATFORM_CELL_
#include <arch/cell/alf_accel_cell.h>
#elif _ALF_PLATFORM_HYBRID_
#include <arch/hybrid/alf_accel_hybrid.h>
#else
#error "No ALF platform configured."
#endif

#ifdef __cplusplus
extern "C" {
#endif

/**
 * This is the entry point to the computational kernel. 
 * The ALF runtime shall move in the user data and input data before invoking 
 * this call.
 *
 * p_task_context:  Pointer to the task context in local memory.
 * p_parm_context:	Pointer to the work block parameter context in local memory.
 * p_input_buffer:	Pointer to the input data in local memory.
 * p_output_buffer:	Pointer to the output data in local memory.
 * p_inout_buffer:  Pointer to the inout data in local memory.
 * current_count:   Current iteration count of multi-use work block. 
 *                  For single use work block, it is always 0.
 * total_count:     Total iteration count of multi-use work block.
 *                  For Single use work block, it is always 1.
 *
 * Return Values:
 *   == 0  Success
 *   < 0   An error happened during the computation. The error code shall be passed back 
 *         to the library developer to be handled.
 */
  typedef int (*alf_accel_comp_kernel) (void *p_task_context, void *p_parm_context,
                                        void *p_input_buffer, void *p_output_buffer, void *p_inout_buffer,
                                        unsigned int current_count, unsigned int total_count);

/**
 * This function is called by the ALF runtime when it will need the 
 * accelerator side to define the partition of input data. 
 *
 * p_task_context:  Pointer to the task context in local memory.
 * p_parm_context:  Pointer to the work block parameter context in local memory.
 * p_dtl:           Pointer to the data transfer list in local memory.
 * current_count:   Current iteration count of multi-use work block. 
 *                  For single use work block, it is always 0.
 * total_count:     Total iteration count of multi-use work block. 
 *                  For single use work block, it is always 1.
 * Return Values:
 *   == 0   Success
 *   < 0   Error
 */
  typedef int (*alf_accel_input_list_prepare) (void *p_task_context, void *p_parm_context, void *p_dtl,
                                               unsigned int current_count, unsigned int total_count);

/**
 * This function is called by the ALF runtime when it will need the 
 * accelerator side to define the partition of output data. 
 *
 * p_task_context:  Pointer to the task context in local memory.
 * p_parm_context:  Pointer to the work block parameter context in local memory.
 * p_dtl:           Pointer to the data transfer list in local memory.
 * current_count:   Current iteration count of multi-use work block. 
 *                  For single use work block, it is always 0.
 * total_count:     Total iteration count of multi-use work block. 
 *                  For single use work block, it is always 1.
 *
 * Return Values:
 *   == 0   Success
 *   < 0   Error
 */
  typedef int (*alf_accel_output_list_prepare) (void *p_task_context, void *p_parm_context, void *p_dtl,
                                                unsigned int current_count, unsigned int total_count);


/**
 * This function is called by the ALF runtime when a task starts executing on an accelerator.
 * The runtime will load the initial task context to the local memory and call this function 
 * to do some task instance specific initialization.
 *
 * p_task_context: Pointer to the task context in local memory.
 *
 * Return Values:
 *   == 0 Success
 *   <  0 Error
 */
  typedef int (*alf_accel_task_context_setup) (void *p_task_context);


/**
 * This function is called by the ALF runtime when a task stops executing on an accelerator.  
 * The runtime will load the corresponding task context to the memory of an accelerator 
 * that is executing this task and call this function to do the context merge.
 *
 * p_task_context_to_be_merged:  Pointer to the task context to be merged in local memory.
 * p_task_context:      Pointer to the task context in local memory.
 *
 * Return Values:
 *   == 0 Success
 *   <  0 Error
 */
  typedef int (*alf_accel_task_context_merge) (void *p_task_context_to_be_merged, void *p_task_context);


/**
 * Get the number of accelerators which are executing this task.
 * Return Values:
 *     Number of accelerators executing this task.
 */
  int alf_accel_num_instances(void);

/**
 * Get the accelarator id.
 * Return Values:
 *     Accelerator id.
 */
  int alf_accel_instance_id(void);

  void ALF_ACCEL_DTL_BEGIN(void *p_dtl, ALF_BUF_TYPE_T buf_type, unsigned int offset);
  void ALF_ACCEL_DTL_ENTRY_ADD(void *p_dtl, unsigned int data_size,
                               ALF_DATA_TYPE_T data_type, alf_data_addr64_t p_host_addr);
  void ALF_ACCEL_DTL_END(void *p_dtl);

  typedef int (*alf_accel_lts_main)(void *p_task_ctx, int instance_id, int number_of_instance);
  void alf_accel_instance_exit_if_canceled(void);
  alf_data_addr64_t alf_accel_instance_cbea_local_store_ea_get(int instance_id);
  alf_data_addr64_t alf_accel_instance_cbea_ps_get_sig_notify1(int instance_id);
  alf_data_addr64_t alf_accel_instance_cbea_ps_get_sig_notify2(int instance_id);

#ifdef __cplusplus
}
#endif
#endif
