/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2007.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

#ifndef MASS_RCBRT_H
#define MASS_RCBRT_H 1
#include <spu_intrinsics.h>
static __inline vector float _rcbrtf4(vector float var1){
    vector float var10;
    vector float var11;
    vector float var12;
    vector float var13;
    vector float var14;
    vector float var15;
    vector float var16;
    vector float var17;
    vector float var18;
    vector float var19;
    vector float var2;
    vector float var20;
    vector float var21;
    vector float var22;
    vector float var23;
    vector float var24;
    vector float var25;
    vector float var26;
    vector float var27;
    vector float var28;
    vector float var29;
    vector float var3;
    vector float var30;
    vector float var31;
    vector float var32;
    vector float var33;
    vector float var34;
    vector float var35;
    vector float var36;
    vector float var37;
    vector float var38;
    vector float var39;
    vector float var4;
    vector float var40;
    vector float var41;
    vector float var42;
    vector float var43;
    vector float var44;
    vector float var45;
    vector float var46;
    vector float var47;
    vector float var48;
    vector float var49;
    vector float var5;
    vector float var50;
    vector float var51;
    vector float var52;
    vector float var53;
    vector float var54;
    vector float var6;
    vector float var7;
    vector float var8;
    vector float var9;
    var10=(vector float)(vector unsigned char){128,128,128,2,128,128,128,6,128,128,128,10,128,128,128,14};
    var14=(vector float)(vector unsigned char){63,203,47,245,63,203,47,245,63,203,47,245,63,203,47,245};
    var17=(vector float)(vector unsigned char){0,17,18,19,4,21,22,23,8,25,26,27,12,29,30,31};
    var2=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var20=(vector float)(vector unsigned char){127,128,0,0,127,128,0,0,127,128,0,0,127,128,0,0};
    var22=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var23=(vector float)(vector unsigned char){0,127,255,255,0,127,255,255,0,127,255,255,0,127,255,255};
    var25=(vector float)(vector unsigned char){61,61,60,60,60,60,60,60,87,32,245,192,153,122,79,45};
    var26=(vector float)(vector unsigned char){166,50,66,106,251,211,72,120,138,105,171,208,153,71,156,184};
    var27=(vector float)(vector unsigned char){0,8,16,24,0,8,16,24,0,8,16,24,0,8,16,24};
    var29=(vector float)(vector unsigned char){0,0,0,0,4,4,4,4,8,8,8,8,12,12,12,12};
    var3=(vector float)(vector unsigned char){63,161,69,24,63,161,69,24,63,161,69,24,63,161,69,24};
    var31=(vector float)(vector unsigned char){7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7};
    var34=(vector float)(vector unsigned char){190,190,190,190,190,189,189,189,137,100,65,37,16,253,225,201};
    var35=(vector float)(vector unsigned char){105,52,22,232,85,233,97,163,52,97,223,203,182,15,80,55};
    var38=(vector float)(vector unsigned char){63,63,63,63,63,63,62,62,54,41,30,20,12,5,255,244};
    var39=(vector float)(vector unsigned char){78,60,74,247,228,215,55,25,59,100,69,133,16,73,108,146};
    var4=(vector float)(vector unsigned char){0,0,85,86,0,0,85,86,0,0,85,86,0,0,85,86};
    var42=(vector float)(vector unsigned char){63,63,63,63,63,63,63,63,0,5,10,14,18,22,26,29};
    var43=(vector float)(vector unsigned char){235,207,92,160,168,120,26,147,247,86,108,101,149,242,169,35};
    var47=(vector float)(vector unsigned char){0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    var52=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var6=(vector float)(vector unsigned char){128,128,128,0,128,128,128,4,128,128,128,8,128,128,128,12};
    var8=(vector float)(vector unsigned char){0,84,170,170,0,84,170,170,0,84,170,170,0,84,170,170};
    var28=(vector float)si_roti((qword)var1,(int)4);
    var30=(vector float)si_shufb((qword)var28,(qword)var28,(qword)var29);
    var32=(vector float)si_selb((qword)var27,(qword)var30,(qword)var31);
    var44=(vector float)si_shufb((qword)var42,(qword)var43,(qword)var32);
    var40=(vector float)si_shufb((qword)var38,(qword)var39,(qword)var32);
    var36=(vector float)si_shufb((qword)var34,(qword)var35,(qword)var32);
    var33=(vector float)si_shufb((qword)var25,(qword)var26,(qword)var32);
    var24=(vector float)si_selb((qword)var22,(qword)var1,(qword)var23);
    var37=(vector float)si_fma((qword)var24,(qword)var33,(qword)var36);
    var41=(vector float)si_fma((qword)var24,(qword)var37,(qword)var40);
    var45=(vector float)si_fma((qword)var24,(qword)var41,(qword)var44);
    var5=(vector float)si_rotqbii((qword)var1,(int)1);
    var7=(vector float)si_shufb((qword)var5,(qword)var5,(qword)var6);
    var48=(vector float)si_ceqi((qword)var7,(int)0);
    var9=(vector float)si_mpya((qword)var4,(qword)var7,(qword)var8);
    var19=(vector float)si_shli((qword)var9,(int)7);
    var11=(vector float)si_shufb((qword)var9,(qword)var9,(qword)var10);
    var15=(vector float)si_cgti((qword)var11,(int)128);
    var12=(vector float)si_cgti((qword)var11,(int)64);
    var13=(vector float)si_selb((qword)var2,(qword)var3,(qword)var12);
    var16=(vector float)si_selb((qword)var13,(qword)var14,(qword)var15);
    var18=(vector float)si_shufb((qword)var1,(qword)var16,(qword)var17);
    var21=(vector float)si_selb((qword)var18,(qword)var19,(qword)var20);
    var46=(vector float)si_fm((qword)var21,(qword)var45);
    var49=(vector float)si_selb((qword)var46,(qword)var47,(qword)var48);
    var50=(vector float)si_frest((qword)var49);
    var51=(vector float)si_fi((qword)var49,(qword)var50);
    var53=(vector float)si_fnms((qword)var49,(qword)var51,(qword)var52);
    var54=(vector float)si_fma((qword)var53,(qword)var51,(qword)var51);
    return var54;
}

#endif /* MASS_RCBRT_H */
