/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2007.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

#ifndef MASS_SINH_H
#define MASS_SINH_H 1
#include <spu_intrinsics.h>
static __inline vector float _sinhf4(vector float var1){
    vector float var10;
    vector float var11;
    vector float var12;
    vector float var13;
    vector float var14;
    vector float var15;
    vector float var16;
    vector float var17;
    vector float var18;
    vector float var19;
    vector float var2;
    vector float var20;
    vector float var21;
    vector float var22;
    vector float var23;
    vector float var24;
    vector float var25;
    vector float var26;
    vector float var27;
    vector float var28;
    vector float var29;
    vector float var3;
    vector float var30;
    vector float var31;
    vector float var32;
    vector float var33;
    vector float var34;
    vector float var35;
    vector float var36;
    vector float var37;
    vector float var38;
    vector float var39;
    vector float var4;
    vector float var40;
    vector float var41;
    vector float var42;
    vector float var43;
    vector float var44;
    vector float var45;
    vector float var46;
    vector float var47;
    vector float var48;
    vector float var49;
    vector float var5;
    vector float var50;
    vector float var51;
    vector float var52;
    vector float var53;
    vector float var54;
    vector float var55;
    vector float var56;
    vector float var57;
    vector float var58;
    vector float var59;
    vector float var6;
    vector float var60;
    vector float var61;
    vector float var62;
    vector float var63;
    vector float var64;
    vector float var65;
    vector float var66;
    vector float var67;
    vector float var68;
    vector float var69;
    vector float var7;
    vector float var70;
    vector float var8;
    vector float var9;
    var10=(vector float)(vector unsigned char){0,31,255,255,0,31,255,255,0,31,255,255,0,31,255,255};
    var12=(vector float)(vector unsigned char){0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
    var13=(vector float)(vector unsigned char){13,0,0,0,13,0,0,0,13,0,0,0,13,0,0,0};
    var14=(vector float)(vector unsigned char){15,240,0,0,15,240,0,0,15,240,0,0,15,240,0,0};
    var16=(vector float)(vector unsigned char){0,0,0,0,4,4,4,4,8,8,8,8,12,12,12,12};
    var18=(vector float)(vector unsigned char){16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16};
    var21=(vector float)(vector unsigned char){57,85,172,46,57,98,68,73,57,110,209,7,57,124,1,35};
    var22=(vector float)(vector unsigned char){60,171,235,213,60,204,115,48,60,243,34,34,61,16,145,101};
    var26=(vector float)(vector unsigned char){1,1,1,1,5,5,5,5,9,9,9,9,13,13,13,13};
    var28=(vector float)(vector unsigned char){12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12};
    var3=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var31=(vector float)(vector unsigned char){60,8,123,112,60,7,227,78,60,6,179,8,60,4,213,254};
    var32=(vector float)(vector unsigned char){60,218,129,79,61,1,236,134,61,26,129,166,61,55,189,124};
    var35=(vector float)(vector unsigned char){62,42,170,205,62,42,180,209,62,42,219,159,62,43,53,231};
    var36=(vector float)(vector unsigned char){62,140,145,219,62,167,42,163,62,198,203,176,62,236,104,194};
    var39=(vector float)(vector unsigned char){63,128,0,0,63,127,255,23,63,127,248,109,63,127,225,139};
    var4=(vector float)(vector unsigned char){128,0,0,0,128,0,0,0,128,0,0,0,128,0,0,0};
    var40=(vector float)(vector unsigned char){63,44,88,170,63,76,244,155,63,115,188,10,63,144,236,232};
    var44=(vector float)(vector unsigned char){51,128,0,0,51,128,0,0,51,128,0,0,51,128,0,0};
    var46=(vector float)(vector unsigned char){0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    var47=(vector float)(vector unsigned char){63,128,149,129,63,152,233,187,63,181,216,98,63,216,64,108};
    var51=(vector float)(vector unsigned char){62,128,0,1,62,128,0,1,62,128,0,1,62,128,0,1};
    var52=(vector float)(vector unsigned char){0,127,255,255,0,127,255,255,0,127,255,255,0,127,255,255};
    var54=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var56=(vector float)(vector unsigned char){53,0,0,0,53,0,0,0,53,0,0,0,53,0,0,0};
    var6=(vector float)(vector unsigned char){63,184,170,59,63,184,170,59,63,184,170,59,63,184,170,59};
    var61=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var66=(vector float)(vector unsigned char){127,255,255,255,127,255,255,255,127,255,255,255,127,255,255,255};
    var67=(vector float)(vector unsigned char){66,180,55,224,66,180,55,224,66,180,55,224,66,180,55,224};
    var7=(vector float)(vector unsigned char){192,0,0,0,192,0,0,0,192,0,0,0,192,0,0,0};
    var5=(vector float)si_andc((qword)var1,(qword)var4);
    var68=(vector float)si_fcmgt((qword)var5,(qword)var67);
    var45=(vector float)si_fm((qword)var5,(qword)var44);
    var8=(vector float)si_fma((qword)var5,(qword)var6,(qword)var7);
    var9=(vector float)si_cflts((qword)var8,(int)23);
    var53=(vector float)si_andc((qword)var9,(qword)var52);
    var55=(vector float)si_a((qword)var53,(qword)var54);
    var57=(vector float)si_fm((qword)var55,(qword)var56);
    var23=(vector float)si_rotqbii((qword)var9,(int)-3);
    var24=(vector float)si_rotqbyi((qword)var23,(int)15);
    var11=(vector float)si_selb((qword)var3,(qword)var9,(qword)var10);
    var2=(vector float)si_fm((qword)var1,(qword)var1);
    var15=(vector float)si_fma((qword)var2,(qword)var13,(qword)var14);
    var17=(vector float)si_shufb((qword)var15,(qword)var15,(qword)var16);
    var19=(vector float)si_selb((qword)var12,(qword)var17,(qword)var18);
    var43=(vector float)si_shufb((qword)var5,(qword)var11,(qword)var19);
    var25=(vector float)si_shufb((qword)var15,(qword)var24,(qword)var19);
    var27=(vector float)si_shufb((qword)var25,(qword)var25,(qword)var26);
    var29=(vector float)si_selb((qword)var19,(qword)var27,(qword)var28);
    var48=(vector float)si_shufb((qword)var46,(qword)var47,(qword)var29);
    var49=(vector float)si_shufb((qword)var45,(qword)var48,(qword)var19);
    var41=(vector float)si_shufb((qword)var39,(qword)var40,(qword)var29);
    var37=(vector float)si_shufb((qword)var35,(qword)var36,(qword)var29);
    var33=(vector float)si_shufb((qword)var31,(qword)var32,(qword)var29);
    var30=(vector float)si_shufb((qword)var21,(qword)var22,(qword)var29);
    var20=(vector float)si_shufb((qword)var2,(qword)var11,(qword)var19);
    var34=(vector float)si_fma((qword)var20,(qword)var30,(qword)var33);
    var38=(vector float)si_fma((qword)var20,(qword)var34,(qword)var37);
    var42=(vector float)si_fma((qword)var20,(qword)var38,(qword)var41);
    var50=(vector float)si_fma((qword)var42,(qword)var43,(qword)var49);
    var58=(vector float)si_fma((qword)var55,(qword)var50,(qword)var57);
    var59=(vector float)si_frest((qword)var58);
    var60=(vector float)si_fi((qword)var58,(qword)var59);
    var62=(vector float)si_fnms((qword)var58,(qword)var60,(qword)var61);
    var63=(vector float)si_fma((qword)var62,(qword)var60,(qword)var60);
    var64=(vector float)si_fnms((qword)var51,(qword)var63,(qword)var58);
    var65=(vector float)si_shufb((qword)var50,(qword)var64,(qword)var19);
    var69=(vector float)si_selb((qword)var65,(qword)var66,(qword)var68);
    var70=(vector float)si_selb((qword)var69,(qword)var1,(qword)var4);
    return var70;
}

#endif /* MASS_SINH_H */
