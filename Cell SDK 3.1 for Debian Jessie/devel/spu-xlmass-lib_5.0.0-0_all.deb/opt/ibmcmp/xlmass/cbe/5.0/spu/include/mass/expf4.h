/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2007.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

#ifndef MASS_EXP_H
#define MASS_EXP_H 1
#include <spu_intrinsics.h>
static __inline vector float _expf4(vector float var1){
    vector float var10;
    vector float var11;
    vector float var12;
    vector float var13;
    vector float var14;
    vector float var15;
    vector float var16;
    vector float var17;
    vector float var18;
    vector float var19;
    vector float var2;
    vector float var20;
    vector float var21;
    vector float var22;
    vector float var23;
    vector float var24;
    vector float var25;
    vector float var26;
    vector float var27;
    vector float var28;
    vector float var29;
    vector float var3;
    vector float var30;
    vector float var31;
    vector float var32;
    vector float var33;
    vector float var34;
    vector float var35;
    vector float var36;
    vector float var37;
    vector float var38;
    vector float var39;
    vector float var4;
    vector float var5;
    vector float var6;
    vector float var7;
    vector float var8;
    vector float var9;
    var10=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var12=(vector float)(vector unsigned char){0,15,255,255,0,15,255,255,0,15,255,255,0,15,255,255};
    var14=(vector float)(vector unsigned char){61,61,61,61,61,61,61,61,109,129,141,153,167,183,199,217};
    var15=(vector float)(vector unsigned char){113,119,47,246,229,24,170,188,148,146,82,146,229,23,96,159};
    var16=(vector float)(vector unsigned char){0,8,16,24,0,8,16,24,0,8,16,24,0,8,16,24};
    var18=(vector float)(vector unsigned char){0,0,0,0,4,4,4,4,8,8,8,8,12,12,12,12};
    var2=(vector float)(vector unsigned char){63,184,170,60,63,184,170,60,63,184,170,60,63,184,170,60};
    var20=(vector float)(vector unsigned char){7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7};
    var23=(vector float)(vector unsigned char){61,61,61,61,61,61,61,61,135,147,161,175,191,208,227,248};
    var24=(vector float)(vector unsigned char){107,173,10,158,131,216,191,92,159,79,251,87,107,200,194,179};
    var27=(vector float)(vector unsigned char){62,62,62,63,63,63,63,63,198,216,235,0,12,24,38,53};
    var28=(vector float)(vector unsigned char){36,19,161,122,27,201,157,178,109,97,217,185,150,225,253,129};
    var31=(vector float)(vector unsigned char){62,63,63,63,63,63,63,63,250,8,20,34,49,65,82,101};
    var32=(vector float)(vector unsigned char){82,125,215,80,1,6,126,139,121,55,170,87,38,87,184,227};
    var36=(vector float)(vector unsigned char){127,255,255,255,127,255,255,255,127,255,255,255,127,255,255,255};
    var37=(vector float)(vector unsigned char){67,0,255,255,67,0,255,255,67,0,255,255,67,0,255,255};
    var4=(vector float)(vector unsigned char){194,254,0,0,194,254,0,0,194,254,0,0,194,254,0,0};
    var8=(vector float)(vector unsigned char){255,128,0,0,255,128,0,0,255,128,0,0,255,128,0,0};
    var3=(vector float)si_fm((qword)var1,(qword)var2);
    var38=(vector float)si_fcgt((qword)var3,(qword)var37);
    var5=(vector float)si_fcgt((qword)var4,(qword)var3);
    var6=(vector float)si_selb((qword)var3,(qword)var4,(qword)var5);
    var7=(vector float)si_cflts((qword)var6,(int)23);
    var17=(vector float)si_roti((qword)var7,(int)4);
    var19=(vector float)si_shufb((qword)var17,(qword)var17,(qword)var18);
    var21=(vector float)si_selb((qword)var16,(qword)var19,(qword)var20);
    var33=(vector float)si_shufb((qword)var31,(qword)var32,(qword)var21);
    var29=(vector float)si_shufb((qword)var27,(qword)var28,(qword)var21);
    var25=(vector float)si_shufb((qword)var23,(qword)var24,(qword)var21);
    var22=(vector float)si_shufb((qword)var14,(qword)var15,(qword)var21);
    var13=(vector float)si_selb((qword)var10,(qword)var7,(qword)var12);
    var26=(vector float)si_fma((qword)var13,(qword)var22,(qword)var25);
    var30=(vector float)si_fma((qword)var13,(qword)var26,(qword)var29);
    var34=(vector float)si_fma((qword)var13,(qword)var30,(qword)var33);
    var9=(vector float)si_and((qword)var7,(qword)var8);
    var11=(vector float)si_a((qword)var9,(qword)var10);
    var35=(vector float)si_fm((qword)var11,(qword)var34);
    var39=(vector float)si_selb((qword)var35,(qword)var36,(qword)var38);
    return var39;
}

#endif /* MASS_EXP_H */
