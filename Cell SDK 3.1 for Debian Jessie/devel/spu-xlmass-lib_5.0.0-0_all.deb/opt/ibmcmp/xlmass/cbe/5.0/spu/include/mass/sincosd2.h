/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2008.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/
#ifndef MASS_SINCOS_H
#define MASS_SINCOS_H
#include <spu_intrinsics.h>
static __inline void _sincosd2(vector double var46In,vector double* var93,vector double* var95){
    vector unsigned char var46;
    vector unsigned char var47;
    vector unsigned char var48;
    vector unsigned char var49;
    vector unsigned char var50;
    vector unsigned char var51;
    vector unsigned char var52;
    vector unsigned char var53;
    vector unsigned char var54;
    vector unsigned char var55;
    vector unsigned char var56;
    vector unsigned char var57;
    vector unsigned char var58;
    vector unsigned char var59;
    vector unsigned char var60;
    vector unsigned char var61;
    vector unsigned char var62;
    vector unsigned char var63;
    vector unsigned char var64;
    vector unsigned char var65;
    vector unsigned char var66;
    vector unsigned char var67;
    vector unsigned char var68;
    static const union {const vector unsigned char v[128];const char c[128*16];} var69= 
        {(vector unsigned char){63,240,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
        ,(vector unsigned char){63,239,246,33,227,121,109,126,63,169,31,101,241,13,216,20}
        ,(vector unsigned char){63,239,216,141,163,209,37,38,63,185,23,166,188,41,180,44}
        ,(vector unsigned char){63,239,167,85,127,8,165,23,63,194,200,16,110,142,97,58}
        ,(vector unsigned char){63,239,98,151,207,247,92,176,63,200,248,184,60,105,166,11}
        ,(vector unsigned char){63,239,10,126,251,146,48,215,63,207,25,249,123,33,95,27}
        ,(vector unsigned char){63,238,159,65,86,198,45,218,63,210,148,6,46,213,159,6}
        ,(vector unsigned char){63,238,33,33,4,246,134,229,63,213,143,154,117,171,31,221}
        ,(vector unsigned char){63,237,144,107,207,50,141,70,63,216,125,226,166,174,169,99}
        ,(vector unsigned char){63,236,237,122,244,60,199,115,63,219,93,16,9,225,92,192}
        ,(vector unsigned char){63,236,56,178,241,128,189,177,63,222,43,93,56,6,246,59}
        ,(vector unsigned char){63,235,114,131,69,25,110,62,63,224,115,135,153,34,255,238}
        ,(vector unsigned char){63,234,155,102,41,14,161,163,63,225,199,59,57,174,104,200}
        ,(vector unsigned char){63,233,179,224,71,243,135,65,63,227,15,247,252,225,112,53}
        ,(vector unsigned char){63,232,188,128,107,21,23,65,63,228,76,243,37,9,29,214}
        ,(vector unsigned char){63,231,181,223,34,106,175,175,63,229,125,105,52,140,236,160}
        ,(vector unsigned char){63,230,160,158,102,127,59,205,63,230,160,158,102,127,59,205}
        ,(vector unsigned char){63,229,125,105,52,140,236,160,63,231,181,223,34,106,175,175}
        ,(vector unsigned char){63,228,76,243,37,9,29,214,63,232,188,128,107,21,23,65}
        ,(vector unsigned char){63,227,15,247,252,225,112,53,63,233,179,224,71,243,135,65}
        ,(vector unsigned char){63,225,199,59,57,174,104,200,63,234,155,102,41,14,161,163}
        ,(vector unsigned char){63,224,115,135,153,34,255,238,63,235,114,131,69,25,110,62}
        ,(vector unsigned char){63,222,43,93,56,6,246,59,63,236,56,178,241,128,189,177}
        ,(vector unsigned char){63,219,93,16,9,225,92,192,63,236,237,122,244,60,199,115}
        ,(vector unsigned char){63,216,125,226,166,174,169,99,63,237,144,107,207,50,141,70}
        ,(vector unsigned char){63,213,143,154,117,171,31,221,63,238,33,33,4,246,134,229}
        ,(vector unsigned char){63,210,148,6,46,213,159,6,63,238,159,65,86,198,45,218}
        ,(vector unsigned char){63,207,25,249,123,33,95,27,63,239,10,126,251,146,48,215}
        ,(vector unsigned char){63,200,248,184,60,105,166,11,63,239,98,151,207,247,92,176}
        ,(vector unsigned char){63,194,200,16,110,142,97,58,63,239,167,85,127,8,165,23}
        ,(vector unsigned char){63,185,23,166,188,41,180,44,63,239,216,141,163,209,37,38}
        ,(vector unsigned char){63,169,31,101,241,13,216,20,63,239,246,33,227,121,109,126}
        ,(vector unsigned char){0,0,0,0,0,0,0,0,63,240,0,0,0,0,0,0}
        ,(vector unsigned char){191,169,31,101,241,13,216,20,63,239,246,33,227,121,109,126}
        ,(vector unsigned char){191,185,23,166,188,41,180,44,63,239,216,141,163,209,37,38}
        ,(vector unsigned char){191,194,200,16,110,142,97,58,63,239,167,85,127,8,165,23}
        ,(vector unsigned char){191,200,248,184,60,105,166,11,63,239,98,151,207,247,92,176}
        ,(vector unsigned char){191,207,25,249,123,33,95,27,63,239,10,126,251,146,48,215}
        ,(vector unsigned char){191,210,148,6,46,213,159,6,63,238,159,65,86,198,45,218}
        ,(vector unsigned char){191,213,143,154,117,171,31,221,63,238,33,33,4,246,134,229}
        ,(vector unsigned char){191,216,125,226,166,174,169,99,63,237,144,107,207,50,141,70}
        ,(vector unsigned char){191,219,93,16,9,225,92,192,63,236,237,122,244,60,199,115}
        ,(vector unsigned char){191,222,43,93,56,6,246,59,63,236,56,178,241,128,189,177}
        ,(vector unsigned char){191,224,115,135,153,34,255,238,63,235,114,131,69,25,110,62}
        ,(vector unsigned char){191,225,199,59,57,174,104,200,63,234,155,102,41,14,161,163}
        ,(vector unsigned char){191,227,15,247,252,225,112,53,63,233,179,224,71,243,135,65}
        ,(vector unsigned char){191,228,76,243,37,9,29,214,63,232,188,128,107,21,23,65}
        ,(vector unsigned char){191,229,125,105,52,140,236,160,63,231,181,223,34,106,175,175}
        ,(vector unsigned char){191,230,160,158,102,127,59,205,63,230,160,158,102,127,59,205}
        ,(vector unsigned char){191,231,181,223,34,106,175,175,63,229,125,105,52,140,236,160}
        ,(vector unsigned char){191,232,188,128,107,21,23,65,63,228,76,243,37,9,29,214}
        ,(vector unsigned char){191,233,179,224,71,243,135,65,63,227,15,247,252,225,112,53}
        ,(vector unsigned char){191,234,155,102,41,14,161,163,63,225,199,59,57,174,104,200}
        ,(vector unsigned char){191,235,114,131,69,25,110,62,63,224,115,135,153,34,255,238}
        ,(vector unsigned char){191,236,56,178,241,128,189,177,63,222,43,93,56,6,246,59}
        ,(vector unsigned char){191,236,237,122,244,60,199,115,63,219,93,16,9,225,92,192}
        ,(vector unsigned char){191,237,144,107,207,50,141,70,63,216,125,226,166,174,169,99}
        ,(vector unsigned char){191,238,33,33,4,246,134,229,63,213,143,154,117,171,31,221}
        ,(vector unsigned char){191,238,159,65,86,198,45,218,63,210,148,6,46,213,159,6}
        ,(vector unsigned char){191,239,10,126,251,146,48,215,63,207,25,249,123,33,95,27}
        ,(vector unsigned char){191,239,98,151,207,247,92,176,63,200,248,184,60,105,166,11}
        ,(vector unsigned char){191,239,167,85,127,8,165,23,63,194,200,16,110,142,97,58}
        ,(vector unsigned char){191,239,216,141,163,209,37,38,63,185,23,166,188,41,180,44}
        ,(vector unsigned char){191,239,246,33,227,121,109,126,63,169,31,101,241,13,216,20}
        ,(vector unsigned char){191,240,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
        ,(vector unsigned char){191,239,246,33,227,121,109,126,191,169,31,101,241,13,216,20}
        ,(vector unsigned char){191,239,216,141,163,209,37,38,191,185,23,166,188,41,180,44}
        ,(vector unsigned char){191,239,167,85,127,8,165,23,191,194,200,16,110,142,97,58}
        ,(vector unsigned char){191,239,98,151,207,247,92,176,191,200,248,184,60,105,166,11}
        ,(vector unsigned char){191,239,10,126,251,146,48,215,191,207,25,249,123,33,95,27}
        ,(vector unsigned char){191,238,159,65,86,198,45,218,191,210,148,6,46,213,159,6}
        ,(vector unsigned char){191,238,33,33,4,246,134,229,191,213,143,154,117,171,31,221}
        ,(vector unsigned char){191,237,144,107,207,50,141,70,191,216,125,226,166,174,169,99}
        ,(vector unsigned char){191,236,237,122,244,60,199,115,191,219,93,16,9,225,92,192}
        ,(vector unsigned char){191,236,56,178,241,128,189,177,191,222,43,93,56,6,246,59}
        ,(vector unsigned char){191,235,114,131,69,25,110,62,191,224,115,135,153,34,255,238}
        ,(vector unsigned char){191,234,155,102,41,14,161,163,191,225,199,59,57,174,104,200}
        ,(vector unsigned char){191,233,179,224,71,243,135,65,191,227,15,247,252,225,112,53}
        ,(vector unsigned char){191,232,188,128,107,21,23,65,191,228,76,243,37,9,29,214}
        ,(vector unsigned char){191,231,181,223,34,106,175,175,191,229,125,105,52,140,236,160}
        ,(vector unsigned char){191,230,160,158,102,127,59,205,191,230,160,158,102,127,59,205}
        ,(vector unsigned char){191,229,125,105,52,140,236,160,191,231,181,223,34,106,175,175}
        ,(vector unsigned char){191,228,76,243,37,9,29,214,191,232,188,128,107,21,23,65}
        ,(vector unsigned char){191,227,15,247,252,225,112,53,191,233,179,224,71,243,135,65}
        ,(vector unsigned char){191,225,199,59,57,174,104,200,191,234,155,102,41,14,161,163}
        ,(vector unsigned char){191,224,115,135,153,34,255,238,191,235,114,131,69,25,110,62}
        ,(vector unsigned char){191,222,43,93,56,6,246,59,191,236,56,178,241,128,189,177}
        ,(vector unsigned char){191,219,93,16,9,225,92,192,191,236,237,122,244,60,199,115}
        ,(vector unsigned char){191,216,125,226,166,174,169,99,191,237,144,107,207,50,141,70}
        ,(vector unsigned char){191,213,143,154,117,171,31,221,191,238,33,33,4,246,134,229}
        ,(vector unsigned char){191,210,148,6,46,213,159,6,191,238,159,65,86,198,45,218}
        ,(vector unsigned char){191,207,25,249,123,33,95,27,191,239,10,126,251,146,48,215}
        ,(vector unsigned char){191,200,248,184,60,105,166,11,191,239,98,151,207,247,92,176}
        ,(vector unsigned char){191,194,200,16,110,142,97,58,191,239,167,85,127,8,165,23}
        ,(vector unsigned char){191,185,23,166,188,41,180,44,191,239,216,141,163,209,37,38}
        ,(vector unsigned char){191,169,31,101,241,13,216,20,191,239,246,33,227,121,109,126}
        ,(vector unsigned char){0,0,0,0,0,0,0,0,191,240,0,0,0,0,0,0}
        ,(vector unsigned char){63,169,31,101,241,13,216,20,191,239,246,33,227,121,109,126}
        ,(vector unsigned char){63,185,23,166,188,41,180,44,191,239,216,141,163,209,37,38}
        ,(vector unsigned char){63,194,200,16,110,142,97,58,191,239,167,85,127,8,165,23}
        ,(vector unsigned char){63,200,248,184,60,105,166,11,191,239,98,151,207,247,92,176}
        ,(vector unsigned char){63,207,25,249,123,33,95,27,191,239,10,126,251,146,48,215}
        ,(vector unsigned char){63,210,148,6,46,213,159,6,191,238,159,65,86,198,45,218}
        ,(vector unsigned char){63,213,143,154,117,171,31,221,191,238,33,33,4,246,134,229}
        ,(vector unsigned char){63,216,125,226,166,174,169,99,191,237,144,107,207,50,141,70}
        ,(vector unsigned char){63,219,93,16,9,225,92,192,191,236,237,122,244,60,199,115}
        ,(vector unsigned char){63,222,43,93,56,6,246,59,191,236,56,178,241,128,189,177}
        ,(vector unsigned char){63,224,115,135,153,34,255,238,191,235,114,131,69,25,110,62}
        ,(vector unsigned char){63,225,199,59,57,174,104,200,191,234,155,102,41,14,161,163}
        ,(vector unsigned char){63,227,15,247,252,225,112,53,191,233,179,224,71,243,135,65}
        ,(vector unsigned char){63,228,76,243,37,9,29,214,191,232,188,128,107,21,23,65}
        ,(vector unsigned char){63,229,125,105,52,140,236,160,191,231,181,223,34,106,175,175}
        ,(vector unsigned char){63,230,160,158,102,127,59,205,191,230,160,158,102,127,59,205}
        ,(vector unsigned char){63,231,181,223,34,106,175,175,191,229,125,105,52,140,236,160}
        ,(vector unsigned char){63,232,188,128,107,21,23,65,191,228,76,243,37,9,29,214}
        ,(vector unsigned char){63,233,179,224,71,243,135,65,191,227,15,247,252,225,112,53}
        ,(vector unsigned char){63,234,155,102,41,14,161,163,191,225,199,59,57,174,104,200}
        ,(vector unsigned char){63,235,114,131,69,25,110,62,191,224,115,135,153,34,255,238}
        ,(vector unsigned char){63,236,56,178,241,128,189,177,191,222,43,93,56,6,246,59}
        ,(vector unsigned char){63,236,237,122,244,60,199,115,191,219,93,16,9,225,92,192}
        ,(vector unsigned char){63,237,144,107,207,50,141,70,191,216,125,226,166,174,169,99}
        ,(vector unsigned char){63,238,33,33,4,246,134,229,191,213,143,154,117,171,31,221}
        ,(vector unsigned char){63,238,159,65,86,198,45,218,191,210,148,6,46,213,159,6}
        ,(vector unsigned char){63,239,10,126,251,146,48,215,191,207,25,249,123,33,95,27}
        ,(vector unsigned char){63,239,98,151,207,247,92,176,191,200,248,184,60,105,166,11}
        ,(vector unsigned char){63,239,167,85,127,8,165,23,191,194,200,16,110,142,97,58}
        ,(vector unsigned char){63,239,216,141,163,209,37,38,191,185,23,166,188,41,180,44}
        ,(vector unsigned char){63,239,246,33,227,121,109,126,191,169,31,101,241,13,216,20}
        };
    vector unsigned char var70;
    vector unsigned char var71;
    vector unsigned char var72;
    vector unsigned char var73;
    vector unsigned char var74;
    vector unsigned char var75;
    vector unsigned char var76;
    vector unsigned char var77;
    vector unsigned char var78;
    vector unsigned char var79;
    vector unsigned char var80;
    vector unsigned char var81;
    vector unsigned char var82;
    vector unsigned char var83;
    vector unsigned char var84;
    vector unsigned char var85;
    vector unsigned char var86;
    vector unsigned char var87;
    vector unsigned char var88;
    vector unsigned char var89;
    vector unsigned char var90;
    vector unsigned char var91;
    vector unsigned char var92;
    vector unsigned char var94;
    var47=(vector unsigned char){128,0,0,0,0,0,0,0,128,0,0,0,0,0,0,0};
    var49=(vector unsigned char){188,214,176,30,197,65,112,86,188,214,176,30,197,65,112,86};
    var50=(vector unsigned char){64,52,95,48,109,201,200,131,64,52,95,48,109,201,200,131};
    var54=(vector unsigned char){67,48,0,0,0,0,0,0,67,48,0,0,0,0,0,0};
    var60=(vector unsigned char){60,206,31,80,148,242,25,119,60,206,31,80,148,242,25,119};
    var61=(vector unsigned char){189,181,93,60,185,226,33,218,189,181,93,60,185,226,33,218};
    var63=(vector unsigned char){62,144,60,31,8,27,90,135,62,144,60,31,8,27,90,135};
    var65=(vector unsigned char){191,83,189,60,201,190,68,0,191,83,189,60,201,190,68,0};
    var67=(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0};
    var71=(vector unsigned char){128,128,128,3,128,128,128,7,128,128,128,11,128,128,128,15};
    var78=(vector unsigned char){8,9,10,11,12,13,14,15,24,25,26,27,28,29,30,31};
    var80=(vector unsigned char){189,67,45,44,240,116,158,54,189,67,45,44,240,116,158,54};
    var81=(vector unsigned char){62,36,102,188,103,117,170,196,62,36,102,188,103,117,170,196};
    var83=(vector unsigned char){190,244,171,188,230,37,189,202,190,244,171,188,230,37,189,202};
    var85=(vector unsigned char){63,169,33,251,84,68,45,24,63,169,33,251,84,68,45,24};
    var88=(vector unsigned char){0,1,2,3,4,5,6,7,16,17,18,19,20,21,22,23};
    var46=(vector unsigned char)var46In;
    var92=(vector unsigned char)si_and((qword)var46,(qword)var47);
    var48=(vector unsigned char)si_andc((qword)var46,(qword)var47);
    var55=(vector unsigned char)si_dfma((qword)var48,(qword)var50,(qword)var54);
    var70=(vector unsigned char)si_andbi((qword)var55,(int)127);
    var72=(vector unsigned char)si_shufb((qword)var70,(qword)var70,(qword)var71);
    var73=(vector unsigned char)si_rotqbii((qword)var72,(int)4);
    var76=(vector unsigned char)si_rotqbyi((qword)var73,(int)12);
    var77=*(vector unsigned char*)(var69.c+spu_extract((vector signed int)var76,0));
    var74=(vector unsigned char)si_rotqbyi((qword)var73,(int)4);
    var75=*(vector unsigned char*)(var69.c+spu_extract((vector signed int)var74,0));
    var89=(vector unsigned char)si_shufb((qword)var75,(qword)var77,(qword)var88);
    var79=(vector unsigned char)si_shufb((qword)var75,(qword)var77,(qword)var78);
    var56=(vector unsigned char)si_dfs((qword)var55,(qword)var54);
    var51=(vector unsigned char)si_dfm((qword)var48,(qword)var50);
    var57=(vector unsigned char)si_dfs((qword)var51,(qword)var56);
    var52=(vector unsigned char)si_dfms((qword)var48,(qword)var50,(qword)var51);
    var53=(vector unsigned char)si_dfma((qword)var48,(qword)var49,(qword)var52);
    var58=(vector unsigned char)si_dfa((qword)var53,(qword)var57);
    var59=(vector unsigned char)si_dfm((qword)var58,(qword)var58);
    var82=(vector unsigned char)si_dfma((qword)var59,(qword)var80,(qword)var81);
    var84=(vector unsigned char)si_dfma((qword)var59,(qword)var82,(qword)var83);
    var86=(vector unsigned char)si_dfma((qword)var59,(qword)var84,(qword)var85);
    var87=(vector unsigned char)si_dfm((qword)var58,(qword)var86);
    var94=(vector unsigned char)si_dfm((qword)var87,(qword)var79);
    var90=(vector unsigned char)si_dfm((qword)var87,(qword)var89);
    var62=(vector unsigned char)si_dfma((qword)var59,(qword)var60,(qword)var61);
    var64=(vector unsigned char)si_dfma((qword)var59,(qword)var62,(qword)var63);
    var66=(vector unsigned char)si_dfma((qword)var59,(qword)var64,(qword)var65);
    var68=(vector unsigned char)si_dfma((qword)var59,(qword)var66,(qword)var67);
    *var95=(vector double)si_dfms((qword)var68,(qword)var89,(qword)var94);
    var91=(vector unsigned char)si_dfma((qword)var68,(qword)var79,(qword)var90);
    *var93=(vector double)si_xor((qword)var91,(qword)var92);}

#endif /* MASS_SINCOS_H */
