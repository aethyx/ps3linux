/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2007.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

#ifndef MASS_TANH_H
#define MASS_TANH_H 1
#include <spu_intrinsics.h>
static __inline vector float _tanhf4(vector float var1){
    vector float var10;
    vector float var11;
    vector float var12;
    vector float var13;
    vector float var14;
    vector float var15;
    vector float var16;
    vector float var17;
    vector float var18;
    vector float var19;
    vector float var2;
    vector float var20;
    vector float var21;
    vector float var22;
    vector float var23;
    vector float var24;
    vector float var25;
    vector float var26;
    vector float var27;
    vector float var28;
    vector float var29;
    vector float var3;
    vector float var30;
    vector float var31;
    vector float var32;
    vector float var33;
    vector float var34;
    vector float var35;
    vector float var36;
    vector float var37;
    vector float var38;
    vector float var39;
    vector float var4;
    vector float var40;
    vector float var41;
    vector float var42;
    vector float var43;
    vector float var44;
    vector float var45;
    vector float var46;
    vector float var47;
    vector float var48;
    vector float var49;
    vector float var5;
    vector float var50;
    vector float var51;
    vector float var52;
    vector float var53;
    vector float var54;
    vector float var55;
    vector float var56;
    vector float var57;
    vector float var58;
    vector float var59;
    vector float var6;
    vector float var60;
    vector float var61;
    vector float var62;
    vector float var63;
    vector float var64;
    vector float var65;
    vector float var7;
    vector float var8;
    vector float var9;
    var11=(vector float)(vector unsigned char){0,0,4,4,8,8,12,12,16,16,20,20,24,24,28,28};
    var13=(vector float)(vector unsigned char){30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30};
    var16=(vector float)(vector unsigned char){30,241,157,78,137,254,8,18,114,132,52,83,137,170,54,76};
    var17=(vector float)(vector unsigned char){157,89,25,13,25,6,114,169,203,67,104,209,176,187,199,210};
    var19=(vector float)(vector unsigned char){0,1,16,17,2,3,18,19,4,5,20,21,6,7,22,23};
    var2=(vector float)(vector unsigned char){128,0,0,0,128,0,0,0,128,0,0,0,128,0,0,0};
    var21=(vector float)(vector unsigned char){185,192,184,7,182,54,57,15,60,135,61,204,62,105,62,165};
    var22=(vector float)(vector unsigned char){62,155,61,236,188,188,189,132,189,75,188,163,187,218,187,9};
    var24=(vector float)(vector unsigned char){207,96,47,113,230,238,133,245,114,22,59,140,231,221,72,117};
    var25=(vector float)(vector unsigned char){49,46,135,125,200,26,2,174,29,121,162,140,147,92,2,126};
    var29=(vector float)(vector unsigned char){59,142,57,244,56,67,190,170,190,172,190,194,190,249,191,24};
    var30=(vector float)(vector unsigned char){191,14,190,26,62,109,62,190,62,156,62,21,61,105,60,168};
    var32=(vector float)(vector unsigned char){99,69,3,229,34,189,171,59,175,23,201,241,62,172,8,54};
    var33=(vector float)(vector unsigned char){57,144,5,80,208,46,76,159,63,49,39,171,204,250,191,50};
    var37=(vector float)(vector unsigned char){188,211,187,93,185,208,51,41,57,255,60,67,61,102,61,240};
    var38=(vector float)(vector unsigned char){61,166,190,183,191,99,191,143,191,121,191,11,190,126,189,210};
    var4=(vector float)(vector unsigned char){55,82,53,112,51,137,62,7,61,210,61,24,188,210,189,114};
    var40=(vector float)(vector unsigned char){203,210,62,115,220,9,71,152,248,196,102,129,123,50,40,42};
    var41=(vector float)(vector unsigned char){210,240,100,145,101,54,202,139,133,186,47,133,40,96,78,215};
    var45=(vector float)(vector unsigned char){61,158,60,73,58,224,63,128,63,127,63,127,63,125,63,120};
    var46=(vector float)(vector unsigned char){63,124,63,157,63,204,63,229,63,208,63,133,63,12,62,132};
    var48=(vector float)(vector unsigned char){216,218,170,228,94,10,0,0,254,0,152,231,53,207,190,10};
    var49=(vector float)(vector unsigned char){234,55,35,132,71,190,176,238,110,28,166,78,217,245,230,84};
    var5=(vector float)(vector unsigned char){189,98,188,167,185,144,59,152,59,89,58,146,57,165,56,179};
    var53=(vector float)(vector unsigned char){63,103,63,123,63,127,0,0,53,77,56,178,58,101,59,60};
    var54=(vector float)(vector unsigned char){183,247,189,87,190,30,190,99,190,23,62,45,63,0,63,59};
    var56=(vector float)(vector unsigned char){239,38,96,67,62,98,0,0,204,121,186,136,166,156,235,164};
    var57=(vector float)(vector unsigned char){157,212,61,18,243,163,186,143,190,186,178,204,40,42,176,49};
    var6=(vector float)(vector unsigned char){0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1};
    var61=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var62=(vector float)(vector unsigned char){65,16,45,179,65,16,45,179,65,16,45,179,65,16,45,179};
    var7=(vector float)(vector unsigned char){64,186,111,127,64,186,111,127,64,186,111,127,64,186,111,127};
    var8=(vector float)(vector unsigned char){64,96,0,0,64,96,0,0,64,96,0,0,64,96,0,0};
    var3=(vector float)si_andc((qword)var1,(qword)var2);
    var63=(vector float)si_fcmgt((qword)var3,(qword)var62);
    var9=(vector float)si_fma((qword)var3,(qword)var7,(qword)var8);
    var10=(vector float)si_roti((qword)var9,(int)4);
    var12=(vector float)si_shufb((qword)var10,(qword)var10,(qword)var11);
    var14=(vector float)si_selb((qword)var6,(qword)var12,(qword)var13);
    var58=(vector float)si_shufb((qword)var56,(qword)var57,(qword)var14);
    var55=(vector float)si_shufb((qword)var53,(qword)var54,(qword)var14);
    var59=(vector float)si_shufb((qword)var55,(qword)var58,(qword)var19);
    var50=(vector float)si_shufb((qword)var48,(qword)var49,(qword)var14);
    var47=(vector float)si_shufb((qword)var45,(qword)var46,(qword)var14);
    var51=(vector float)si_shufb((qword)var47,(qword)var50,(qword)var19);
    var42=(vector float)si_shufb((qword)var40,(qword)var41,(qword)var14);
    var39=(vector float)si_shufb((qword)var37,(qword)var38,(qword)var14);
    var43=(vector float)si_shufb((qword)var39,(qword)var42,(qword)var19);
    var34=(vector float)si_shufb((qword)var32,(qword)var33,(qword)var14);
    var31=(vector float)si_shufb((qword)var29,(qword)var30,(qword)var14);
    var35=(vector float)si_shufb((qword)var31,(qword)var34,(qword)var19);
    var26=(vector float)si_shufb((qword)var24,(qword)var25,(qword)var14);
    var23=(vector float)si_shufb((qword)var21,(qword)var22,(qword)var14);
    var27=(vector float)si_shufb((qword)var23,(qword)var26,(qword)var19);
    var18=(vector float)si_shufb((qword)var16,(qword)var17,(qword)var14);
    var15=(vector float)si_shufb((qword)var4,(qword)var5,(qword)var14);
    var20=(vector float)si_shufb((qword)var15,(qword)var18,(qword)var19);
    var28=(vector float)si_fma((qword)var3,(qword)var20,(qword)var27);
    var36=(vector float)si_fma((qword)var3,(qword)var28,(qword)var35);
    var44=(vector float)si_fma((qword)var3,(qword)var36,(qword)var43);
    var52=(vector float)si_fma((qword)var3,(qword)var44,(qword)var51);
    var60=(vector float)si_fma((qword)var3,(qword)var52,(qword)var59);
    var64=(vector float)si_selb((qword)var60,(qword)var61,(qword)var63);
    var65=(vector float)si_selb((qword)var64,(qword)var1,(qword)var2);
    return var65;
}

#endif /* MASS_TANH_H */
