/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2008.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/
#ifndef MASS_TAN_H
#define MASS_TAN_H
#include <spu_intrinsics.h>
static __inline vector double _tand2(vector double var2570In){
    vector unsigned char var2570;
    vector unsigned char var2571;
    vector unsigned char var2572;
    vector unsigned char var2573;
    vector unsigned char var2574;
    vector unsigned char var2575;
    vector unsigned char var2576;
    vector unsigned char var2577;
    vector unsigned char var2578;
    vector unsigned char var2579;
    vector unsigned char var2580;
    vector unsigned char var2581;
    vector unsigned char var2582;
    vector unsigned char var2583;
    vector unsigned char var2584;
    vector unsigned char var2585;
    vector unsigned char var2586;
    vector unsigned char var2587;
    vector unsigned char var2588;
    vector unsigned char var2589;
    vector unsigned char var2590;
    vector unsigned char var2591;
    vector unsigned char var2592;
    static const union {const vector unsigned char v[128];const char c[128*16];} var2593= 
        {(vector unsigned char){63,240,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
        ,(vector unsigned char){63,239,246,33,227,121,109,126,63,169,31,101,241,13,216,20}
        ,(vector unsigned char){63,239,216,141,163,209,37,38,63,185,23,166,188,41,180,44}
        ,(vector unsigned char){63,239,167,85,127,8,165,23,63,194,200,16,110,142,97,58}
        ,(vector unsigned char){63,239,98,151,207,247,92,176,63,200,248,184,60,105,166,11}
        ,(vector unsigned char){63,239,10,126,251,146,48,215,63,207,25,249,123,33,95,27}
        ,(vector unsigned char){63,238,159,65,86,198,45,218,63,210,148,6,46,213,159,6}
        ,(vector unsigned char){63,238,33,33,4,246,134,229,63,213,143,154,117,171,31,221}
        ,(vector unsigned char){63,237,144,107,207,50,141,70,63,216,125,226,166,174,169,99}
        ,(vector unsigned char){63,236,237,122,244,60,199,115,63,219,93,16,9,225,92,192}
        ,(vector unsigned char){63,236,56,178,241,128,189,177,63,222,43,93,56,6,246,59}
        ,(vector unsigned char){63,235,114,131,69,25,110,62,63,224,115,135,153,34,255,238}
        ,(vector unsigned char){63,234,155,102,41,14,161,163,63,225,199,59,57,174,104,200}
        ,(vector unsigned char){63,233,179,224,71,243,135,65,63,227,15,247,252,225,112,53}
        ,(vector unsigned char){63,232,188,128,107,21,23,65,63,228,76,243,37,9,29,214}
        ,(vector unsigned char){63,231,181,223,34,106,175,175,63,229,125,105,52,140,236,160}
        ,(vector unsigned char){63,230,160,158,102,127,59,205,63,230,160,158,102,127,59,205}
        ,(vector unsigned char){63,229,125,105,52,140,236,160,63,231,181,223,34,106,175,175}
        ,(vector unsigned char){63,228,76,243,37,9,29,214,63,232,188,128,107,21,23,65}
        ,(vector unsigned char){63,227,15,247,252,225,112,53,63,233,179,224,71,243,135,65}
        ,(vector unsigned char){63,225,199,59,57,174,104,200,63,234,155,102,41,14,161,163}
        ,(vector unsigned char){63,224,115,135,153,34,255,238,63,235,114,131,69,25,110,62}
        ,(vector unsigned char){63,222,43,93,56,6,246,59,63,236,56,178,241,128,189,177}
        ,(vector unsigned char){63,219,93,16,9,225,92,192,63,236,237,122,244,60,199,115}
        ,(vector unsigned char){63,216,125,226,166,174,169,99,63,237,144,107,207,50,141,70}
        ,(vector unsigned char){63,213,143,154,117,171,31,221,63,238,33,33,4,246,134,229}
        ,(vector unsigned char){63,210,148,6,46,213,159,6,63,238,159,65,86,198,45,218}
        ,(vector unsigned char){63,207,25,249,123,33,95,27,63,239,10,126,251,146,48,215}
        ,(vector unsigned char){63,200,248,184,60,105,166,11,63,239,98,151,207,247,92,176}
        ,(vector unsigned char){63,194,200,16,110,142,97,58,63,239,167,85,127,8,165,23}
        ,(vector unsigned char){63,185,23,166,188,41,180,44,63,239,216,141,163,209,37,38}
        ,(vector unsigned char){63,169,31,101,241,13,216,20,63,239,246,33,227,121,109,126}
        ,(vector unsigned char){0,0,0,0,0,0,0,0,63,240,0,0,0,0,0,0}
        ,(vector unsigned char){191,169,31,101,241,13,216,20,63,239,246,33,227,121,109,126}
        ,(vector unsigned char){191,185,23,166,188,41,180,44,63,239,216,141,163,209,37,38}
        ,(vector unsigned char){191,194,200,16,110,142,97,58,63,239,167,85,127,8,165,23}
        ,(vector unsigned char){191,200,248,184,60,105,166,11,63,239,98,151,207,247,92,176}
        ,(vector unsigned char){191,207,25,249,123,33,95,27,63,239,10,126,251,146,48,215}
        ,(vector unsigned char){191,210,148,6,46,213,159,6,63,238,159,65,86,198,45,218}
        ,(vector unsigned char){191,213,143,154,117,171,31,221,63,238,33,33,4,246,134,229}
        ,(vector unsigned char){191,216,125,226,166,174,169,99,63,237,144,107,207,50,141,70}
        ,(vector unsigned char){191,219,93,16,9,225,92,192,63,236,237,122,244,60,199,115}
        ,(vector unsigned char){191,222,43,93,56,6,246,59,63,236,56,178,241,128,189,177}
        ,(vector unsigned char){191,224,115,135,153,34,255,238,63,235,114,131,69,25,110,62}
        ,(vector unsigned char){191,225,199,59,57,174,104,200,63,234,155,102,41,14,161,163}
        ,(vector unsigned char){191,227,15,247,252,225,112,53,63,233,179,224,71,243,135,65}
        ,(vector unsigned char){191,228,76,243,37,9,29,214,63,232,188,128,107,21,23,65}
        ,(vector unsigned char){191,229,125,105,52,140,236,160,63,231,181,223,34,106,175,175}
        ,(vector unsigned char){191,230,160,158,102,127,59,205,63,230,160,158,102,127,59,205}
        ,(vector unsigned char){191,231,181,223,34,106,175,175,63,229,125,105,52,140,236,160}
        ,(vector unsigned char){191,232,188,128,107,21,23,65,63,228,76,243,37,9,29,214}
        ,(vector unsigned char){191,233,179,224,71,243,135,65,63,227,15,247,252,225,112,53}
        ,(vector unsigned char){191,234,155,102,41,14,161,163,63,225,199,59,57,174,104,200}
        ,(vector unsigned char){191,235,114,131,69,25,110,62,63,224,115,135,153,34,255,238}
        ,(vector unsigned char){191,236,56,178,241,128,189,177,63,222,43,93,56,6,246,59}
        ,(vector unsigned char){191,236,237,122,244,60,199,115,63,219,93,16,9,225,92,192}
        ,(vector unsigned char){191,237,144,107,207,50,141,70,63,216,125,226,166,174,169,99}
        ,(vector unsigned char){191,238,33,33,4,246,134,229,63,213,143,154,117,171,31,221}
        ,(vector unsigned char){191,238,159,65,86,198,45,218,63,210,148,6,46,213,159,6}
        ,(vector unsigned char){191,239,10,126,251,146,48,215,63,207,25,249,123,33,95,27}
        ,(vector unsigned char){191,239,98,151,207,247,92,176,63,200,248,184,60,105,166,11}
        ,(vector unsigned char){191,239,167,85,127,8,165,23,63,194,200,16,110,142,97,58}
        ,(vector unsigned char){191,239,216,141,163,209,37,38,63,185,23,166,188,41,180,44}
        ,(vector unsigned char){191,239,246,33,227,121,109,126,63,169,31,101,241,13,216,20}
        ,(vector unsigned char){191,240,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
        ,(vector unsigned char){191,239,246,33,227,121,109,126,191,169,31,101,241,13,216,20}
        ,(vector unsigned char){191,239,216,141,163,209,37,38,191,185,23,166,188,41,180,44}
        ,(vector unsigned char){191,239,167,85,127,8,165,23,191,194,200,16,110,142,97,58}
        ,(vector unsigned char){191,239,98,151,207,247,92,176,191,200,248,184,60,105,166,11}
        ,(vector unsigned char){191,239,10,126,251,146,48,215,191,207,25,249,123,33,95,27}
        ,(vector unsigned char){191,238,159,65,86,198,45,218,191,210,148,6,46,213,159,6}
        ,(vector unsigned char){191,238,33,33,4,246,134,229,191,213,143,154,117,171,31,221}
        ,(vector unsigned char){191,237,144,107,207,50,141,70,191,216,125,226,166,174,169,99}
        ,(vector unsigned char){191,236,237,122,244,60,199,115,191,219,93,16,9,225,92,192}
        ,(vector unsigned char){191,236,56,178,241,128,189,177,191,222,43,93,56,6,246,59}
        ,(vector unsigned char){191,235,114,131,69,25,110,62,191,224,115,135,153,34,255,238}
        ,(vector unsigned char){191,234,155,102,41,14,161,163,191,225,199,59,57,174,104,200}
        ,(vector unsigned char){191,233,179,224,71,243,135,65,191,227,15,247,252,225,112,53}
        ,(vector unsigned char){191,232,188,128,107,21,23,65,191,228,76,243,37,9,29,214}
        ,(vector unsigned char){191,231,181,223,34,106,175,175,191,229,125,105,52,140,236,160}
        ,(vector unsigned char){191,230,160,158,102,127,59,205,191,230,160,158,102,127,59,205}
        ,(vector unsigned char){191,229,125,105,52,140,236,160,191,231,181,223,34,106,175,175}
        ,(vector unsigned char){191,228,76,243,37,9,29,214,191,232,188,128,107,21,23,65}
        ,(vector unsigned char){191,227,15,247,252,225,112,53,191,233,179,224,71,243,135,65}
        ,(vector unsigned char){191,225,199,59,57,174,104,200,191,234,155,102,41,14,161,163}
        ,(vector unsigned char){191,224,115,135,153,34,255,238,191,235,114,131,69,25,110,62}
        ,(vector unsigned char){191,222,43,93,56,6,246,59,191,236,56,178,241,128,189,177}
        ,(vector unsigned char){191,219,93,16,9,225,92,192,191,236,237,122,244,60,199,115}
        ,(vector unsigned char){191,216,125,226,166,174,169,99,191,237,144,107,207,50,141,70}
        ,(vector unsigned char){191,213,143,154,117,171,31,221,191,238,33,33,4,246,134,229}
        ,(vector unsigned char){191,210,148,6,46,213,159,6,191,238,159,65,86,198,45,218}
        ,(vector unsigned char){191,207,25,249,123,33,95,27,191,239,10,126,251,146,48,215}
        ,(vector unsigned char){191,200,248,184,60,105,166,11,191,239,98,151,207,247,92,176}
        ,(vector unsigned char){191,194,200,16,110,142,97,58,191,239,167,85,127,8,165,23}
        ,(vector unsigned char){191,185,23,166,188,41,180,44,191,239,216,141,163,209,37,38}
        ,(vector unsigned char){191,169,31,101,241,13,216,20,191,239,246,33,227,121,109,126}
        ,(vector unsigned char){0,0,0,0,0,0,0,0,191,240,0,0,0,0,0,0}
        ,(vector unsigned char){63,169,31,101,241,13,216,20,191,239,246,33,227,121,109,126}
        ,(vector unsigned char){63,185,23,166,188,41,180,44,191,239,216,141,163,209,37,38}
        ,(vector unsigned char){63,194,200,16,110,142,97,58,191,239,167,85,127,8,165,23}
        ,(vector unsigned char){63,200,248,184,60,105,166,11,191,239,98,151,207,247,92,176}
        ,(vector unsigned char){63,207,25,249,123,33,95,27,191,239,10,126,251,146,48,215}
        ,(vector unsigned char){63,210,148,6,46,213,159,6,191,238,159,65,86,198,45,218}
        ,(vector unsigned char){63,213,143,154,117,171,31,221,191,238,33,33,4,246,134,229}
        ,(vector unsigned char){63,216,125,226,166,174,169,99,191,237,144,107,207,50,141,70}
        ,(vector unsigned char){63,219,93,16,9,225,92,192,191,236,237,122,244,60,199,115}
        ,(vector unsigned char){63,222,43,93,56,6,246,59,191,236,56,178,241,128,189,177}
        ,(vector unsigned char){63,224,115,135,153,34,255,238,191,235,114,131,69,25,110,62}
        ,(vector unsigned char){63,225,199,59,57,174,104,200,191,234,155,102,41,14,161,163}
        ,(vector unsigned char){63,227,15,247,252,225,112,53,191,233,179,224,71,243,135,65}
        ,(vector unsigned char){63,228,76,243,37,9,29,214,191,232,188,128,107,21,23,65}
        ,(vector unsigned char){63,229,125,105,52,140,236,160,191,231,181,223,34,106,175,175}
        ,(vector unsigned char){63,230,160,158,102,127,59,205,191,230,160,158,102,127,59,205}
        ,(vector unsigned char){63,231,181,223,34,106,175,175,191,229,125,105,52,140,236,160}
        ,(vector unsigned char){63,232,188,128,107,21,23,65,191,228,76,243,37,9,29,214}
        ,(vector unsigned char){63,233,179,224,71,243,135,65,191,227,15,247,252,225,112,53}
        ,(vector unsigned char){63,234,155,102,41,14,161,163,191,225,199,59,57,174,104,200}
        ,(vector unsigned char){63,235,114,131,69,25,110,62,191,224,115,135,153,34,255,238}
        ,(vector unsigned char){63,236,56,178,241,128,189,177,191,222,43,93,56,6,246,59}
        ,(vector unsigned char){63,236,237,122,244,60,199,115,191,219,93,16,9,225,92,192}
        ,(vector unsigned char){63,237,144,107,207,50,141,70,191,216,125,226,166,174,169,99}
        ,(vector unsigned char){63,238,33,33,4,246,134,229,191,213,143,154,117,171,31,221}
        ,(vector unsigned char){63,238,159,65,86,198,45,218,191,210,148,6,46,213,159,6}
        ,(vector unsigned char){63,239,10,126,251,146,48,215,191,207,25,249,123,33,95,27}
        ,(vector unsigned char){63,239,98,151,207,247,92,176,191,200,248,184,60,105,166,11}
        ,(vector unsigned char){63,239,167,85,127,8,165,23,191,194,200,16,110,142,97,58}
        ,(vector unsigned char){63,239,216,141,163,209,37,38,191,185,23,166,188,41,180,44}
        ,(vector unsigned char){63,239,246,33,227,121,109,126,191,169,31,101,241,13,216,20}
        };
    vector unsigned char var2594;
    vector unsigned char var2595;
    vector unsigned char var2596;
    vector unsigned char var2597;
    vector unsigned char var2598;
    vector unsigned char var2599;
    vector unsigned char var2600;
    vector unsigned char var2601;
    vector unsigned char var2602;
    vector unsigned char var2603;
    vector unsigned char var2604;
    vector unsigned char var2605;
    vector unsigned char var2606;
    vector unsigned char var2607;
    vector unsigned char var2608;
    vector unsigned char var2609;
    vector unsigned char var2610;
    vector unsigned char var2611;
    vector unsigned char var2612;
    vector unsigned char var2613;
    vector unsigned char var2614;
    vector unsigned char var2615;
    vector unsigned char var2616;
    vector unsigned char var2617;
    vector unsigned char var2618;
    vector unsigned char var2619;
    vector unsigned char var2620;
    vector unsigned char var2621;
    vector unsigned char var2622;
    vector unsigned char var2623;
    vector unsigned char var2675;
    vector unsigned char var2676;
    vector unsigned char var2677;
    vector unsigned char var2678;
    vector unsigned char var2679;
    vector unsigned char var2680;
    vector unsigned char var2681;
    vector unsigned char var2682;
    vector unsigned char var2683;
    vector unsigned char var2684;
    vector unsigned char var2685;
    vector unsigned char var2686;
    vector unsigned char var2687;
    vector unsigned char var2688;
    vector unsigned char var2689;
    vector unsigned char var2690;
    vector unsigned char var2691;
    vector unsigned char var2692;
    vector unsigned char var2694;
    vector unsigned char var2695;
    vector unsigned char var2696;
    vector unsigned char var2697;
    vector unsigned char var2698;
    vector unsigned char var2699;
    vector unsigned char var2700;
    vector unsigned char var2701;
    vector unsigned char var2703;
    vector unsigned char var2704;
    vector unsigned char var2705;
    vector unsigned char var2706;
    vector unsigned char var2707;
    vector unsigned char var2708;
    vector unsigned char var2709;
    vector unsigned char var2711;
    vector double var2712;
    var2571=(vector unsigned char){128,0,0,0,0,0,0,0,128,0,0,0,0,0,0,0};
    var2573=(vector unsigned char){188,214,176,30,197,65,112,86,188,214,176,30,197,65,112,86};
    var2574=(vector unsigned char){64,52,95,48,109,201,200,131,64,52,95,48,109,201,200,131};
    var2578=(vector unsigned char){67,48,0,0,0,0,0,0,67,48,0,0,0,0,0,0};
    var2584=(vector unsigned char){60,206,31,80,148,242,25,119,60,206,31,80,148,242,25,119};
    var2585=(vector unsigned char){189,181,93,60,185,226,33,218,189,181,93,60,185,226,33,218};
    var2587=(vector unsigned char){62,144,60,31,8,27,90,135,62,144,60,31,8,27,90,135};
    var2589=(vector unsigned char){191,83,189,60,201,190,68,0,191,83,189,60,201,190,68,0};
    var2591=(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0};
    var2595=(vector unsigned char){128,128,128,3,128,128,128,7,128,128,128,11,128,128,128,15};
    var2602=(vector unsigned char){0,1,2,3,4,5,6,7,16,17,18,19,20,21,22,23};
    var2604=(vector unsigned char){189,67,45,44,240,116,158,54,189,67,45,44,240,116,158,54};
    var2605=(vector unsigned char){62,36,102,188,103,117,170,196,62,36,102,188,103,117,170,196};
    var2607=(vector unsigned char){190,244,171,188,230,37,189,202,190,244,171,188,230,37,189,202};
    var2609=(vector unsigned char){63,169,33,251,84,68,45,24,63,169,33,251,84,68,45,24};
    var2612=(vector unsigned char){8,9,10,11,12,13,14,15,24,25,26,27,28,29,30,31};
    var2616=(vector unsigned char){75,16,0,0,0,0,0,0,75,16,0,0,0,0,0,0};
    var2618=(vector unsigned char){0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
    var2619=(vector unsigned char){8,0,0,0,0,0,0,0,8,0,0,0,0,0,0,0};
    var2621=(vector unsigned char){16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16};
    var2675=(vector unsigned char){0,1,2,3,16,17,18,19,8,9,10,11,24,25,26,27};
    var2677=(vector unsigned char){128,0,0,0,128,0,0,0,128,0,0,0,128,0,0,0};
    var2679=(vector unsigned char){0,128,128,128,4,128,128,128,8,128,128,128,12,128,128,128};
    var2681=(vector unsigned char){128,1,2,3,128,5,6,7,128,9,10,11,128,13,14,15};
    var2684=(vector unsigned char){98,0,0,0,98,0,0,0,98,0,0,0,98,0,0,0};
    var2688=(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var2695=(vector unsigned char){0,1,2,3,128,128,128,128,8,9,10,11,128,128,128,128};
    var2697=(vector unsigned char){60,48,0,0,0,0,0,0,60,48,0,0,0,0,0,0};
    var2699=(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0};
    var2570=(vector unsigned char)var2570In;
    var2707=(vector unsigned char)si_and((qword)var2570,(qword)var2571);
    var2572=(vector unsigned char)si_andc((qword)var2570,(qword)var2571);
    var2579=(vector unsigned char)si_dfma((qword)var2572,(qword)var2574,(qword)var2578);
    var2594=(vector unsigned char)si_andbi((qword)var2579,(int)127);
    var2596=(vector unsigned char)si_shufb((qword)var2594,(qword)var2594,(qword)var2595);
    var2597=(vector unsigned char)si_rotqbii((qword)var2596,(int)4);
    var2600=(vector unsigned char)si_rotqbyi((qword)var2597,(int)12);
    var2601=*(vector unsigned char*)(var2593.c+spu_extract((vector signed int)var2600,0));
    var2598=(vector unsigned char)si_rotqbyi((qword)var2597,(int)4);
    var2599=*(vector unsigned char*)(var2593.c+spu_extract((vector signed int)var2598,0));
    var2613=(vector unsigned char)si_shufb((qword)var2599,(qword)var2601,(qword)var2612);
    var2603=(vector unsigned char)si_shufb((qword)var2599,(qword)var2601,(qword)var2602);
    var2580=(vector unsigned char)si_dfs((qword)var2579,(qword)var2578);
    var2575=(vector unsigned char)si_dfm((qword)var2572,(qword)var2574);
    var2581=(vector unsigned char)si_dfs((qword)var2575,(qword)var2580);
    var2576=(vector unsigned char)si_dfms((qword)var2572,(qword)var2574,(qword)var2575);
    var2577=(vector unsigned char)si_dfma((qword)var2572,(qword)var2573,(qword)var2576);
    var2582=(vector unsigned char)si_dfa((qword)var2577,(qword)var2581);
    var2583=(vector unsigned char)si_dfm((qword)var2582,(qword)var2582);
    var2606=(vector unsigned char)si_dfma((qword)var2583,(qword)var2604,(qword)var2605);
    var2608=(vector unsigned char)si_dfma((qword)var2583,(qword)var2606,(qword)var2607);
    var2610=(vector unsigned char)si_dfma((qword)var2583,(qword)var2608,(qword)var2609);
    var2611=(vector unsigned char)si_dfm((qword)var2582,(qword)var2610);
    var2705=(vector unsigned char)si_dfm((qword)var2611,(qword)var2603);
    var2614=(vector unsigned char)si_dfm((qword)var2611,(qword)var2613);
    var2586=(vector unsigned char)si_dfma((qword)var2583,(qword)var2584,(qword)var2585);
    var2588=(vector unsigned char)si_dfma((qword)var2583,(qword)var2586,(qword)var2587);
    var2590=(vector unsigned char)si_dfma((qword)var2583,(qword)var2588,(qword)var2589);
    var2592=(vector unsigned char)si_dfma((qword)var2583,(qword)var2590,(qword)var2591);
    var2706=(vector unsigned char)si_dfma((qword)var2592,(qword)var2613,(qword)var2705);
    var2708=(vector unsigned char)si_xor((qword)var2706,(qword)var2707);
    var2615=(vector unsigned char)si_dfms((qword)var2592,(qword)var2603,(qword)var2614);
    var2620=(vector unsigned char)si_dfcmgt((qword)var2619,(qword)var2615);
    var2622=(vector unsigned char)si_selb((qword)var2618,(qword)var2620,(qword)var2621);
    var2617=(vector unsigned char)si_dfm((qword)var2615,(qword)var2616);
    var2623=(vector unsigned char)si_shufb((qword)var2615,(qword)var2617,(qword)var2622);
    var2676=(vector unsigned char)si_shufb((qword)var2623,(qword)var2623,(qword)var2675);
    var2678=(vector unsigned char)si_andc((qword)var2676,(qword)var2677);
    var2682=(vector unsigned char)si_shufb((qword)var2678,(qword)var2678,(qword)var2681);
    var2683=(vector unsigned char)si_rotqbii((qword)var2682,(int)3);
    var2685=(vector unsigned char)si_a((qword)var2683,(qword)var2684);
    var2686=(vector unsigned char)si_frest((qword)var2685);
    var2687=(vector unsigned char)si_fi((qword)var2685,(qword)var2686);
    var2689=(vector unsigned char)si_fnms((qword)var2685,(qword)var2687,(qword)var2688);
    var2690=(vector unsigned char)si_fma((qword)var2689,(qword)var2687,(qword)var2687);
    var2691=(vector unsigned char)si_rotmi((qword)var2690,(int)-3);
    var2680=(vector unsigned char)si_shufb((qword)var2678,(qword)var2678,(qword)var2679);
    var2692=(vector unsigned char)si_sf((qword)var2680,(qword)var2691);
    var2694=(vector unsigned char)si_selb((qword)var2692,(qword)var2676,(qword)var2677);
    var2696=(vector unsigned char)si_shufb((qword)var2694,(qword)var2694,(qword)var2695);
    var2698=(vector unsigned char)si_dfm((qword)var2696,(qword)var2697);
    var2700=(vector unsigned char)si_dfnms((qword)var2623,(qword)var2698,(qword)var2699);
    var2701=(vector unsigned char)si_dfma((qword)var2700,(qword)var2698,(qword)var2698);
    var2703=(vector unsigned char)si_dfnms((qword)var2623,(qword)var2701,(qword)var2699);
    var2704=(vector unsigned char)si_dfma((qword)var2703,(qword)var2701,(qword)var2701);
    var2709=(vector unsigned char)si_dfm((qword)var2704,(qword)var2708);
    var2711=(vector unsigned char)si_dfm((qword)var2709,(qword)var2616);
    var2712=(vector double)si_shufb((qword)var2709,(qword)var2711,(qword)var2622);
    return var2712;}

#endif /* MASS_TAN_H */
