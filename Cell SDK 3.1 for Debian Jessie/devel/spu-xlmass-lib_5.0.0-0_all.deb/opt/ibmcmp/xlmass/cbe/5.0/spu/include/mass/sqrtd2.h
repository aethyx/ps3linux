/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2008.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/
#ifndef MASS_SQRT_H
#define MASS_SQRT_H
#include <spu_intrinsics.h>
static __inline vector double _sqrtd2(vector double var166In){
    vector unsigned char var166;
    vector unsigned char var167;
    vector unsigned char var168;
    vector unsigned char var169;
    vector unsigned char var170;
    vector unsigned char var174;
    vector unsigned char var175;
    vector unsigned char var176;
    vector unsigned char var177;
    vector unsigned char var178;
    vector unsigned char var179;
    vector unsigned char var180;
    vector unsigned char var181;
    vector unsigned char var182;
    vector unsigned char var183;
    vector unsigned char var184;
    vector unsigned char var185;
    vector unsigned char var186;
    vector unsigned char var187;
    vector unsigned char var188;
    vector unsigned char var189;
    vector unsigned char var190;
    vector unsigned char var191;
    vector unsigned char var192;
    vector unsigned char var193;
    vector unsigned char var194;
    vector unsigned char var195;
    vector unsigned char var196;
    vector unsigned char var197;
    vector unsigned char var198;
    vector unsigned char var199;
    vector unsigned char var200;
    vector unsigned char var202;
    vector unsigned char var204;
    vector unsigned char var205;
    vector unsigned char var206;
    vector unsigned char var208;
    vector unsigned char var210;
    vector unsigned char var211;
    vector unsigned char var212;
    vector unsigned char var213;
    vector unsigned char var214;
    vector unsigned char var215;
    vector unsigned char var216;
    vector unsigned char var217;
    vector unsigned char var218;
    vector unsigned char var219;
    vector unsigned char var220;
    vector unsigned char var221;
    vector unsigned char var222;
    vector unsigned char var223;
    vector unsigned char var225;
    vector double var226;
    var167=(vector unsigned char){67,240,0,0,0,0,0,0,67,240,0,0,0,0,0,0};
    var174=(vector unsigned char){0,1,2,3,16,17,18,19,8,9,10,11,24,25,26,27};
    var176=(vector unsigned char){255,240,0,0,255,240,0,0,255,240,0,0,255,240,0,0};
    var178=(vector unsigned char){128,0,128,128,128,4,128,128,128,8,128,128,128,12,128,128};
    var181=(vector unsigned char){128,1,2,3,128,5,6,7,128,9,10,11,128,13,14,15};
    var184=(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var190=(vector unsigned char){87,240,0,0,87,240,0,0,87,240,0,0,87,240,0,0};
    var192=(vector unsigned char){0,1,2,3,128,128,128,128,8,9,10,11,128,128,128,128};
    var195=(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0};
    var197=(vector unsigned char){63,224,0,0,0,0,0,0,63,224,0,0,0,0,0,0};
    var213=(vector unsigned char){61,240,0,0,0,0,0,0,61,240,0,0,0,0,0,0};
    var216=(vector unsigned char){127,240,0,0,0,0,0,0,127,240,0,0,0,0,0,0};
    var217=(vector unsigned char){127,239,255,255,255,255,255,255,127,239,255,255,255,255,255,255};
    var220=(vector unsigned char){0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1};
    var223=(vector unsigned char){0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    var166=(vector unsigned char)var166In;
    var225=(vector unsigned char)si_dfceq((qword)var166,(qword)var223);
    var221=(vector unsigned char)si_dfcgt((qword)var220,(qword)var166);
    var218=(vector unsigned char)si_dfcmgt((qword)var166,(qword)var217);
    var169=(vector unsigned char)si_dftsv((qword)var166,(int)3);
    var168=(vector unsigned char)si_dfm((qword)var166,(qword)var167);
    var170=(vector unsigned char)si_selb((qword)var166,(qword)var168,(qword)var169);
    var175=(vector unsigned char)si_shufb((qword)var170,(qword)var170,(qword)var174);
    var177=(vector unsigned char)si_a((qword)var175,(qword)var176);
    var182=(vector unsigned char)si_shufb((qword)var177,(qword)var177,(qword)var181);
    var183=(vector unsigned char)si_rotqbii((qword)var182,(int)3);
    var185=(vector unsigned char)si_a((qword)var183,(qword)var184);
    var186=(vector unsigned char)si_frsqest((qword)var185);
    var187=(vector unsigned char)si_fi((qword)var185,(qword)var186);
    var188=(vector unsigned char)si_rotmi((qword)var187,(int)-3);
    var179=(vector unsigned char)si_shufb((qword)var177,(qword)var177,(qword)var178);
    var180=(vector unsigned char)si_rotqbii((qword)var179,(int)7);
    var189=(vector unsigned char)si_sf((qword)var180,(qword)var188);
    var191=(vector unsigned char)si_a((qword)var189,(qword)var190);
    var193=(vector unsigned char)si_shufb((qword)var191,(qword)var191,(qword)var192);
    var198=(vector unsigned char)si_dfm((qword)var193,(qword)var197);
    var194=(vector unsigned char)si_dfm((qword)var170,(qword)var193);
    var196=(vector unsigned char)si_dfnms((qword)var194,(qword)var193,(qword)var195);
    var199=(vector unsigned char)si_dfma((qword)var196,(qword)var198,(qword)var193);
    var204=(vector unsigned char)si_dfm((qword)var199,(qword)var197);
    var200=(vector unsigned char)si_dfm((qword)var170,(qword)var199);
    var202=(vector unsigned char)si_dfnms((qword)var200,(qword)var199,(qword)var195);
    var205=(vector unsigned char)si_dfma((qword)var202,(qword)var204,(qword)var199);
    var210=(vector unsigned char)si_dfm((qword)var205,(qword)var197);
    var206=(vector unsigned char)si_dfm((qword)var170,(qword)var205);
    var208=(vector unsigned char)si_dfnms((qword)var206,(qword)var205,(qword)var195);
    var211=(vector unsigned char)si_dfma((qword)var208,(qword)var210,(qword)var205);
    var212=(vector unsigned char)si_dfm((qword)var211,(qword)var170);
    var214=(vector unsigned char)si_dfm((qword)var212,(qword)var213);
    var215=(vector unsigned char)si_selb((qword)var212,(qword)var214,(qword)var169);
    var219=(vector unsigned char)si_selb((qword)var215,(qword)var216,(qword)var218);
    var222=(vector unsigned char)si_or((qword)var219,(qword)var221);
    var226=(vector double)si_selb((qword)var222,(qword)var223,(qword)var225);
    return var226;}

#endif /* MASS_SQRT_H */
