/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2008.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/
#ifndef MASS_QDRT_H
#define MASS_QDRT_H
#include <spu_intrinsics.h>
static __inline vector double _qdrtd2(vector double var3476In){
    vector unsigned char var3476;
    vector unsigned char var3477;
    vector unsigned char var3478;
    vector unsigned char var3479;
    vector unsigned char var3480;
    vector unsigned char var3481;
    vector unsigned char var3485;
    vector unsigned char var3486;
    vector unsigned char var3487;
    vector unsigned char var3488;
    vector unsigned char var3489;
    vector unsigned char var3490;
    vector unsigned char var3491;
    vector unsigned char var3492;
    vector unsigned char var3493;
    vector unsigned char var3494;
    vector unsigned char var3495;
    vector unsigned char var3496;
    vector unsigned char var3497;
    vector unsigned char var3498;
    vector unsigned char var3499;
    vector unsigned char var3500;
    vector unsigned char var3501;
    vector unsigned char var3502;
    vector unsigned char var3503;
    vector unsigned char var3504;
    vector unsigned char var3505;
    vector unsigned char var3506;
    vector unsigned char var3507;
    vector unsigned char var3508;
    vector unsigned char var3509;
    vector unsigned char var3510;
    vector unsigned char var3511;
    vector unsigned char var3513;
    vector unsigned char var3515;
    vector unsigned char var3516;
    vector unsigned char var3517;
    vector unsigned char var3519;
    vector unsigned char var3521;
    vector unsigned char var3522;
    vector unsigned char var3523;
    vector unsigned char var3524;
    vector unsigned char var3525;
    vector unsigned char var3526;
    vector unsigned char var3527;
    vector unsigned char var3528;
    vector unsigned char var3529;
    vector unsigned char var3530;
    vector unsigned char var3531;
    vector unsigned char var3533;
    vector unsigned char var3534;
    vector unsigned char var3535;
    vector unsigned char var3536;
    vector unsigned char var3537;
    vector unsigned char var3538;
    vector unsigned char var3539;
    vector unsigned char var3540;
    vector unsigned char var3541;
    vector unsigned char var3542;
    vector unsigned char var3544;
    vector unsigned char var3546;
    vector unsigned char var3547;
    vector unsigned char var3548;
    vector unsigned char var3549;
    vector unsigned char var3551;
    vector unsigned char var3553;
    vector unsigned char var3554;
    vector unsigned char var3555;
    vector unsigned char var3556;
    vector unsigned char var3557;
    vector unsigned char var3558;
    vector unsigned char var3559;
    vector unsigned char var3560;
    vector unsigned char var3561;
    vector unsigned char var3562;
    vector unsigned char var3563;
    vector unsigned char var3564;
    vector unsigned char var3565;
    vector unsigned char var3566;
    vector unsigned char var3568;
    vector double var3569;
    var3477=(vector unsigned char){67,240,0,0,0,0,0,0,67,240,0,0,0,0,0,0};
    var3479=(vector unsigned char){0,48,0,0,0,0,0,0,0,48,0,0,0,0,0,0};
    var3485=(vector unsigned char){0,1,2,3,16,17,18,19,8,9,10,11,24,25,26,27};
    var3487=(vector unsigned char){255,208,0,0,255,208,0,0,255,208,0,0,255,208,0,0};
    var3489=(vector unsigned char){128,0,128,128,128,4,128,128,128,8,128,128,128,12,128,128};
    var3492=(vector unsigned char){128,1,2,3,128,5,6,7,128,9,10,11,128,13,14,15};
    var3495=(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var3501=(vector unsigned char){87,224,0,0,87,224,0,0,87,224,0,0,87,224,0,0};
    var3503=(vector unsigned char){0,1,2,3,128,128,128,128,8,9,10,11,128,128,128,128};
    var3506=(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0};
    var3508=(vector unsigned char){63,224,0,0,0,0,0,0,63,224,0,0,0,0,0,0};
    var3530=(vector unsigned char){71,240,0,0,71,240,0,0,71,240,0,0,71,240,0,0};
    var3536=(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0};
    var3538=(vector unsigned char){63,208,0,0,0,0,0,0,63,208,0,0,0,0,0,0};
    var3556=(vector unsigned char){62,240,0,0,0,0,0,0,62,240,0,0,0,0,0,0};
    var3559=(vector unsigned char){127,240,0,0,0,0,0,0,127,240,0,0,0,0,0,0};
    var3560=(vector unsigned char){127,239,255,255,255,255,255,255,127,239,255,255,255,255,255,255};
    var3563=(vector unsigned char){0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1};
    var3566=(vector unsigned char){0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    var3476=(vector unsigned char)var3476In;
    var3568=(vector unsigned char)si_dfceq((qword)var3476,(qword)var3566);
    var3564=(vector unsigned char)si_dfcgt((qword)var3563,(qword)var3476);
    var3561=(vector unsigned char)si_dfcmgt((qword)var3476,(qword)var3560);
    var3480=(vector unsigned char)si_dfcmgt((qword)var3479,(qword)var3476);
    var3478=(vector unsigned char)si_dfm((qword)var3476,(qword)var3477);
    var3481=(vector unsigned char)si_selb((qword)var3476,(qword)var3478,(qword)var3480);
    var3486=(vector unsigned char)si_shufb((qword)var3481,(qword)var3481,(qword)var3485);
    var3488=(vector unsigned char)si_a((qword)var3486,(qword)var3487);
    var3493=(vector unsigned char)si_shufb((qword)var3488,(qword)var3488,(qword)var3492);
    var3494=(vector unsigned char)si_rotqbii((qword)var3493,(int)3);
    var3496=(vector unsigned char)si_a((qword)var3494,(qword)var3495);
    var3497=(vector unsigned char)si_frsqest((qword)var3496);
    var3498=(vector unsigned char)si_fi((qword)var3496,(qword)var3497);
    var3525=(vector unsigned char)si_fm((qword)var3496,(qword)var3498);
    var3526=(vector unsigned char)si_frsqest((qword)var3525);
    var3527=(vector unsigned char)si_fi((qword)var3525,(qword)var3526);
    var3528=(vector unsigned char)si_rotmi((qword)var3527,(int)-3);
    var3499=(vector unsigned char)si_rotmi((qword)var3498,(int)-3);
    var3490=(vector unsigned char)si_shufb((qword)var3488,(qword)var3488,(qword)var3489);
    var3524=(vector unsigned char)si_rotqbii((qword)var3490,(int)6);
    var3529=(vector unsigned char)si_sf((qword)var3524,(qword)var3528);
    var3531=(vector unsigned char)si_a((qword)var3529,(qword)var3530);
    var3533=(vector unsigned char)si_shufb((qword)var3531,(qword)var3531,(qword)var3503);
    var3539=(vector unsigned char)si_dfm((qword)var3533,(qword)var3538);
    var3534=(vector unsigned char)si_dfm((qword)var3533,(qword)var3533);
    var3535=(vector unsigned char)si_dfm((qword)var3534,(qword)var3534);
    var3537=(vector unsigned char)si_dfnms((qword)var3535,(qword)var3481,(qword)var3536);
    var3540=(vector unsigned char)si_dfma((qword)var3537,(qword)var3539,(qword)var3533);
    var3546=(vector unsigned char)si_dfm((qword)var3540,(qword)var3538);
    var3541=(vector unsigned char)si_dfm((qword)var3540,(qword)var3540);
    var3542=(vector unsigned char)si_dfm((qword)var3541,(qword)var3541);
    var3544=(vector unsigned char)si_dfnms((qword)var3542,(qword)var3481,(qword)var3536);
    var3547=(vector unsigned char)si_dfma((qword)var3544,(qword)var3546,(qword)var3540);
    var3553=(vector unsigned char)si_dfm((qword)var3547,(qword)var3538);
    var3548=(vector unsigned char)si_dfm((qword)var3547,(qword)var3547);
    var3549=(vector unsigned char)si_dfm((qword)var3548,(qword)var3548);
    var3551=(vector unsigned char)si_dfnms((qword)var3549,(qword)var3481,(qword)var3536);
    var3554=(vector unsigned char)si_dfma((qword)var3551,(qword)var3553,(qword)var3547);
    var3491=(vector unsigned char)si_rotqbii((qword)var3490,(int)7);
    var3500=(vector unsigned char)si_sf((qword)var3491,(qword)var3499);
    var3502=(vector unsigned char)si_a((qword)var3500,(qword)var3501);
    var3504=(vector unsigned char)si_shufb((qword)var3502,(qword)var3502,(qword)var3503);
    var3509=(vector unsigned char)si_dfm((qword)var3504,(qword)var3508);
    var3505=(vector unsigned char)si_dfm((qword)var3481,(qword)var3504);
    var3507=(vector unsigned char)si_dfnms((qword)var3505,(qword)var3504,(qword)var3506);
    var3510=(vector unsigned char)si_dfma((qword)var3507,(qword)var3509,(qword)var3504);
    var3515=(vector unsigned char)si_dfm((qword)var3510,(qword)var3508);
    var3511=(vector unsigned char)si_dfm((qword)var3481,(qword)var3510);
    var3513=(vector unsigned char)si_dfnms((qword)var3511,(qword)var3510,(qword)var3506);
    var3516=(vector unsigned char)si_dfma((qword)var3513,(qword)var3515,(qword)var3510);
    var3521=(vector unsigned char)si_dfm((qword)var3516,(qword)var3508);
    var3517=(vector unsigned char)si_dfm((qword)var3481,(qword)var3516);
    var3519=(vector unsigned char)si_dfnms((qword)var3517,(qword)var3516,(qword)var3506);
    var3522=(vector unsigned char)si_dfma((qword)var3519,(qword)var3521,(qword)var3516);
    var3523=(vector unsigned char)si_dfm((qword)var3522,(qword)var3481);
    var3555=(vector unsigned char)si_dfm((qword)var3523,(qword)var3554);
    var3557=(vector unsigned char)si_dfm((qword)var3555,(qword)var3556);
    var3558=(vector unsigned char)si_selb((qword)var3555,(qword)var3557,(qword)var3480);
    var3562=(vector unsigned char)si_selb((qword)var3558,(qword)var3559,(qword)var3561);
    var3565=(vector unsigned char)si_or((qword)var3562,(qword)var3564);
    var3569=(vector double)si_selb((qword)var3565,(qword)var3566,(qword)var3568);
    return var3569;}

#endif /* MASS_QDRT_H */
