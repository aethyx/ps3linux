/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2008.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/
#ifndef MASS_SINH_H
#define MASS_SINH_H
#include <spu_intrinsics.h>
static __inline vector double _sinhd2(vector double var3244In){
    vector unsigned char var3244;
    vector unsigned char var3245;
    vector unsigned char var3246;
    vector unsigned char var3247;
    vector unsigned char var3248;
    vector unsigned char var3249;
    vector unsigned char var3251;
    vector unsigned char var3252;
    vector unsigned char var3253;
    vector unsigned char var3254;
    vector unsigned char var3255;
    vector unsigned char var3256;
    vector unsigned char var3257;
    vector unsigned char var3258;
    vector unsigned char var3260;
    vector unsigned char var3261;
    vector unsigned char var3262;
    vector unsigned char var3263;
    vector unsigned char var3264;
    vector unsigned char var3265;
    vector unsigned char var3267;
    vector unsigned char var3268;
    vector unsigned char var3269;
    vector unsigned char var3270;
    vector unsigned char var3271;
    vector unsigned char var3273;
    vector unsigned char var3274;
    vector unsigned char var3275;
    vector unsigned char var3278;
    vector unsigned char var3279;
    vector unsigned char var3280;
    vector unsigned char var3281;
    vector unsigned char var3282;
    vector unsigned char var3283;
    vector unsigned char var3284;
    vector unsigned char var3285;
    vector unsigned char var3289;
    vector unsigned char var3292;
    vector unsigned char var3294;
    vector unsigned char var3295;
    vector unsigned char var3296;
    vector unsigned char var3297;
    vector unsigned char var3307;
    vector unsigned char var3308;
    vector unsigned char var3310;
    vector unsigned char var3311;
    vector unsigned char var3313;
    vector unsigned char var3314;
    vector unsigned char var3315;
    vector unsigned char var3316;
    vector unsigned char var3317;
    vector unsigned char var3318;
    vector unsigned char var3319;
    vector unsigned char var3320;
    vector unsigned char var3321;
    vector unsigned char var3322;
    vector unsigned char var3323;
    vector unsigned char var3324;
    vector unsigned char var3325;
    vector unsigned char var3326;
    vector unsigned char var3327;
    vector unsigned char var3328;
    vector unsigned char var3329;
    vector unsigned char var3330;
    vector unsigned char var3331;
    vector unsigned char var3332;
    vector unsigned char var3333;
    vector unsigned char var3334;
    vector unsigned char var3336;
    vector unsigned char var3337;
    vector unsigned char var3339;
    vector unsigned char var3340;
    vector unsigned char var3341;
    vector unsigned char var3343;
    vector unsigned char var3344;
    vector unsigned char var3345;
    vector unsigned char var3347;
    vector unsigned char var3348;
    vector unsigned char var3351;
    vector unsigned char var3352;
    vector unsigned char var3353;
    vector unsigned char var3354;
    vector unsigned char var3355;
    vector unsigned char var3356;
    vector unsigned char var3357;
    vector unsigned char var3358;
    vector unsigned char var3360;
    vector unsigned char var3362;
    vector unsigned char var3363;
    static const union {const vector unsigned char v[256];const char c[256*16];} var3364= 
        {(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0}
        ,(vector unsigned char){63,240,11,26,250,90,188,191,63,240,11,26,250,90,188,191}
        ,(vector unsigned char){63,240,22,61,169,251,51,53,63,240,22,61,169,251,51,53}
        ,(vector unsigned char){63,240,33,104,20,59,2,129,63,240,33,104,20,59,2,129}
        ,(vector unsigned char){63,240,44,154,62,119,128,97,63,240,44,154,62,119,128,97}
        ,(vector unsigned char){63,240,55,212,46,17,187,204,63,240,55,212,46,17,187,204}
        ,(vector unsigned char){63,240,67,21,232,110,127,133,63,240,67,21,232,110,127,133}
        ,(vector unsigned char){63,240,78,95,114,246,84,177,63,240,78,95,114,246,84,177}
        ,(vector unsigned char){63,240,89,176,211,21,133,116,63,240,89,176,211,21,133,116}
        ,(vector unsigned char){63,240,101,10,14,60,31,137,63,240,101,10,14,60,31,137}
        ,(vector unsigned char){63,240,112,107,41,221,246,222,63,240,112,107,41,221,246,222}
        ,(vector unsigned char){63,240,123,212,43,114,168,54,63,240,123,212,43,114,168,54}
        ,(vector unsigned char){63,240,135,69,24,117,155,200,63,240,135,69,24,117,155,200}
        ,(vector unsigned char){63,240,146,189,246,102,7,224,63,240,146,189,246,102,7,224}
        ,(vector unsigned char){63,240,158,62,202,198,243,131,63,240,158,62,202,198,243,131}
        ,(vector unsigned char){63,240,169,199,155,31,57,25,63,240,169,199,155,31,57,25}
        ,(vector unsigned char){63,240,181,88,108,249,137,15,63,240,181,88,108,249,137,15}
        ,(vector unsigned char){63,240,192,241,69,228,108,133,63,240,192,241,69,228,108,133}
        ,(vector unsigned char){63,240,204,146,43,114,71,247,63,240,204,146,43,114,71,247}
        ,(vector unsigned char){63,240,216,59,35,57,93,236,63,240,216,59,35,57,93,236}
        ,(vector unsigned char){63,240,227,236,50,211,209,162,63,240,227,236,50,211,209,162}
        ,(vector unsigned char){63,240,239,165,95,223,169,197,63,240,239,165,95,223,169,197}
        ,(vector unsigned char){63,240,251,102,175,254,211,27,63,240,251,102,175,254,211,27}
        ,(vector unsigned char){63,241,7,48,40,215,35,62,63,241,7,48,40,215,35,62}
        ,(vector unsigned char){63,241,19,1,208,18,91,81,63,241,19,1,208,18,91,81}
        ,(vector unsigned char){63,241,30,219,171,94,42,182,63,241,30,219,171,94,42,182}
        ,(vector unsigned char){63,241,42,189,192,108,49,204,63,241,42,189,192,108,49,204}
        ,(vector unsigned char){63,241,54,168,20,242,4,171,63,241,54,168,20,242,4,171}
        ,(vector unsigned char){63,241,66,154,174,169,45,224,63,241,66,154,174,169,45,224}
        ,(vector unsigned char){63,241,78,149,147,79,49,46,63,241,78,149,147,79,49,46}
        ,(vector unsigned char){63,241,90,152,200,165,142,81,63,241,90,152,200,165,142,81}
        ,(vector unsigned char){63,241,102,164,84,113,195,194,63,241,102,164,84,113,195,194}
        ,(vector unsigned char){63,241,114,184,60,125,81,123,63,241,114,184,60,125,81,123}
        ,(vector unsigned char){63,241,126,212,134,149,187,192,63,241,126,212,134,149,187,192}
        ,(vector unsigned char){63,241,138,249,56,140,141,234,63,241,138,249,56,140,141,234}
        ,(vector unsigned char){63,241,151,38,88,55,93,47,63,241,151,38,88,55,93,47}
        ,(vector unsigned char){63,241,163,91,235,111,203,117,63,241,163,91,235,111,203,117}
        ,(vector unsigned char){63,241,175,153,248,19,138,28,63,241,175,153,248,19,138,28}
        ,(vector unsigned char){63,241,187,224,132,4,92,212,63,241,187,224,132,4,92,212}
        ,(vector unsigned char){63,241,200,47,149,40,28,107,63,241,200,47,149,40,28,107}
        ,(vector unsigned char){63,241,212,135,49,104,185,170,63,241,212,135,49,104,185,170}
        ,(vector unsigned char){63,241,224,231,94,180,64,39,63,241,224,231,94,180,64,39}
        ,(vector unsigned char){63,241,237,80,34,252,217,29,63,241,237,80,34,252,217,29}
        ,(vector unsigned char){63,241,249,193,132,56,206,77,63,241,249,193,132,56,206,77}
        ,(vector unsigned char){63,242,6,59,136,98,140,214,63,242,6,59,136,98,140,214}
        ,(vector unsigned char){63,242,18,190,53,120,168,25,63,242,18,190,53,120,168,25}
        ,(vector unsigned char){63,242,31,73,145,125,220,150,63,242,31,73,145,125,220,150}
        ,(vector unsigned char){63,242,43,221,162,121,18,209,63,242,43,221,162,121,18,209}
        ,(vector unsigned char){63,242,56,122,110,117,98,56,63,242,56,122,110,117,98,56}
        ,(vector unsigned char){63,242,69,31,251,130,20,10,63,242,69,31,251,130,20,10}
        ,(vector unsigned char){63,242,81,206,79,178,166,63,63,242,81,206,79,178,166,63}
        ,(vector unsigned char){63,242,94,133,113,30,206,117,63,242,94,133,113,30,206,117}
        ,(vector unsigned char){63,242,107,69,101,226,124,221,63,242,107,69,101,226,124,221}
        ,(vector unsigned char){63,242,120,14,52,29,223,41,63,242,120,14,52,29,223,41}
        ,(vector unsigned char){63,242,132,223,225,245,99,129,63,242,132,223,225,245,99,129}
        ,(vector unsigned char){63,242,145,186,117,145,187,112,63,242,145,186,117,145,187,112}
        ,(vector unsigned char){63,242,158,157,245,31,222,225,63,242,158,157,245,31,222,225}
        ,(vector unsigned char){63,242,171,138,102,209,15,19,63,242,171,138,102,209,15,19}
        ,(vector unsigned char){63,242,184,127,208,218,217,144,63,242,184,127,208,218,217,144}
        ,(vector unsigned char){63,242,197,126,57,119,27,47,63,242,197,126,57,119,27,47}
        ,(vector unsigned char){63,242,210,133,166,228,3,11,63,242,210,133,166,228,3,11}
        ,(vector unsigned char){63,242,223,150,31,100,21,137,63,242,223,150,31,100,21,137}
        ,(vector unsigned char){63,242,236,175,169,62,47,86,63,242,236,175,169,62,47,86}
        ,(vector unsigned char){63,242,249,210,74,189,136,107,63,242,249,210,74,189,136,107}
        ,(vector unsigned char){63,243,6,254,10,49,183,21,63,243,6,254,10,49,183,21}
        ,(vector unsigned char){63,243,20,50,237,238,178,253,63,243,20,50,237,238,178,253}
        ,(vector unsigned char){63,243,33,112,252,76,216,49,63,243,33,112,252,76,216,49}
        ,(vector unsigned char){63,243,46,184,59,168,234,50,63,243,46,184,59,168,234,50}
        ,(vector unsigned char){63,243,60,8,178,100,22,255,63,243,60,8,178,100,22,255}
        ,(vector unsigned char){63,243,73,98,102,227,250,45,63,243,73,98,102,227,250,45}
        ,(vector unsigned char){63,243,86,197,95,146,159,241,63,243,86,197,95,146,159,241}
        ,(vector unsigned char){63,243,100,49,162,222,136,59,63,243,100,49,162,222,136,59}
        ,(vector unsigned char){63,243,113,167,55,58,169,203,63,243,113,167,55,58,169,203}
        ,(vector unsigned char){63,243,127,38,35,30,117,74,63,243,127,38,35,30,117,74}
        ,(vector unsigned char){63,243,140,174,109,5,216,102,63,243,140,174,109,5,216,102}
        ,(vector unsigned char){63,243,154,64,27,113,64,239,63,243,154,64,27,113,64,239}
        ,(vector unsigned char){63,243,167,219,52,229,159,247,63,243,167,219,52,229,159,247}
        ,(vector unsigned char){63,243,181,127,191,236,108,244,63,243,181,127,191,236,108,244}
        ,(vector unsigned char){63,243,195,45,195,19,168,229,63,243,195,45,195,19,168,229}
        ,(vector unsigned char){63,243,208,229,68,237,225,115,63,243,208,229,68,237,225,115}
        ,(vector unsigned char){63,243,222,166,76,18,52,34,63,243,222,166,76,18,52,34}
        ,(vector unsigned char){63,243,236,112,223,28,81,117,63,243,236,112,223,28,81,117}
        ,(vector unsigned char){63,243,250,69,4,172,128,28,63,243,250,69,4,172,128,28}
        ,(vector unsigned char){63,244,8,34,195,103,160,36,63,244,8,34,195,103,160,36}
        ,(vector unsigned char){63,244,22,10,33,247,46,42,63,244,22,10,33,247,46,42}
        ,(vector unsigned char){63,244,35,251,39,9,70,138,63,244,35,251,39,9,70,138}
        ,(vector unsigned char){63,244,49,245,217,80,168,151,63,244,49,245,217,80,168,151}
        ,(vector unsigned char){63,244,63,250,63,132,185,212,63,244,63,250,63,132,185,212}
        ,(vector unsigned char){63,244,78,8,96,97,137,45,63,244,78,8,96,97,137,45}
        ,(vector unsigned char){63,244,92,32,66,167,210,50,63,244,92,32,66,167,210,50}
        ,(vector unsigned char){63,244,106,65,237,29,0,87,63,244,106,65,237,29,0,87}
        ,(vector unsigned char){63,244,120,109,102,139,50,55,63,244,120,109,102,139,50,55}
        ,(vector unsigned char){63,244,134,162,181,193,60,208,63,244,134,162,181,193,60,208}
        ,(vector unsigned char){63,244,148,225,225,146,174,210,63,244,148,225,225,146,174,210}
        ,(vector unsigned char){63,244,163,42,240,215,211,222,63,244,163,42,240,215,211,222}
        ,(vector unsigned char){63,244,177,125,234,109,183,215,63,244,177,125,234,109,183,215}
        ,(vector unsigned char){63,244,191,218,213,54,42,39,63,244,191,218,213,54,42,39}
        ,(vector unsigned char){63,244,206,65,184,23,193,20,63,244,206,65,184,23,193,20}
        ,(vector unsigned char){63,244,220,178,153,253,221,13,63,244,220,178,153,253,221,13}
        ,(vector unsigned char){63,244,235,45,129,216,171,255,63,244,235,45,129,216,171,255}
        ,(vector unsigned char){63,244,249,178,118,157,44,167,63,244,249,178,118,157,44,167}
        ,(vector unsigned char){63,245,8,65,127,69,49,238,63,245,8,65,127,69,49,238}
        ,(vector unsigned char){63,245,22,218,162,207,102,66,63,245,22,218,162,207,102,66}
        ,(vector unsigned char){63,245,37,125,232,63,78,239,63,245,37,125,232,63,78,239}
        ,(vector unsigned char){63,245,52,43,86,157,79,130,63,245,52,43,86,157,79,130}
        ,(vector unsigned char){63,245,66,226,244,246,173,39,63,245,66,226,244,246,173,39}
        ,(vector unsigned char){63,245,81,164,202,93,146,15,63,245,81,164,202,93,146,15}
        ,(vector unsigned char){63,245,96,112,221,233,16,210,63,245,96,112,221,233,16,210}
        ,(vector unsigned char){63,245,111,71,54,181,39,218,63,245,111,71,54,181,39,218}
        ,(vector unsigned char){63,245,126,39,219,226,196,207,63,245,126,39,219,226,196,207}
        ,(vector unsigned char){63,245,141,18,212,151,199,253,63,245,141,18,212,151,199,253}
        ,(vector unsigned char){63,245,156,8,39,255,7,204,63,245,156,8,39,255,7,204}
        ,(vector unsigned char){63,245,171,7,221,72,84,41,63,245,171,7,221,72,84,41}
        ,(vector unsigned char){63,245,186,17,251,168,122,3,63,245,186,17,251,168,122,3}
        ,(vector unsigned char){63,245,201,38,138,89,70,183,63,245,201,38,138,89,70,183}
        ,(vector unsigned char){63,245,216,69,144,153,139,147,63,245,216,69,144,153,139,147}
        ,(vector unsigned char){63,245,231,111,21,173,33,72,63,245,231,111,21,173,33,72}
        ,(vector unsigned char){63,245,246,163,32,220,235,113,63,245,246,163,32,220,235,113}
        ,(vector unsigned char){63,246,5,225,185,118,220,9,63,246,5,225,185,118,220,9}
        ,(vector unsigned char){63,246,21,42,230,205,246,244,63,246,21,42,230,205,246,244}
        ,(vector unsigned char){63,246,36,126,176,58,85,133,63,246,36,126,176,58,85,133}
        ,(vector unsigned char){63,246,51,221,29,25,41,253,63,246,51,221,29,25,41,253}
        ,(vector unsigned char){63,246,67,70,52,204,195,32,63,246,67,70,52,204,195,32}
        ,(vector unsigned char){63,246,82,185,254,188,143,183,63,246,82,185,254,188,143,183}
        ,(vector unsigned char){63,246,98,56,130,85,34,37,63,246,98,56,130,85,34,37}
        ,(vector unsigned char){63,246,113,193,199,8,51,246,63,246,113,193,199,8,51,246}
        ,(vector unsigned char){63,246,129,85,212,76,169,115,63,246,129,85,212,76,169,115}
        ,(vector unsigned char){63,246,144,244,177,158,149,56,63,246,144,244,177,158,149,56}
        ,(vector unsigned char){63,246,160,158,102,127,59,205,63,246,160,158,102,127,59,205}
        ,(vector unsigned char){63,246,176,82,250,117,23,62,63,246,176,82,250,117,23,62}
        ,(vector unsigned char){63,246,192,18,117,11,218,191,63,246,192,18,117,11,218,191}
        ,(vector unsigned char){63,246,207,220,221,212,118,69,63,246,207,220,221,212,118,69}
        ,(vector unsigned char){63,246,223,178,60,101,26,47,63,246,223,178,60,101,26,47}
        ,(vector unsigned char){63,246,239,146,152,89,58,229,63,246,239,146,152,89,58,229}
        ,(vector unsigned char){63,246,255,125,249,81,148,132,63,246,255,125,249,81,148,132}
        ,(vector unsigned char){63,247,15,116,102,244,46,135,63,247,15,116,102,244,46,135}
        ,(vector unsigned char){63,247,31,117,232,236,95,116,63,247,31,117,232,236,95,116}
        ,(vector unsigned char){63,247,47,130,134,234,208,138,63,247,47,130,134,234,208,138}
        ,(vector unsigned char){63,247,63,154,72,165,129,116,63,247,63,154,72,165,129,116}
        ,(vector unsigned char){63,247,79,189,53,215,203,253,63,247,79,189,53,215,203,253}
        ,(vector unsigned char){63,247,95,235,86,66,103,201,63,247,95,235,86,66,103,201}
        ,(vector unsigned char){63,247,112,36,177,171,110,9,63,247,112,36,177,171,110,9}
        ,(vector unsigned char){63,247,128,105,79,222,93,63,63,247,128,105,79,222,93,63}
        ,(vector unsigned char){63,247,144,185,56,172,28,246,63,247,144,185,56,172,28,246}
        ,(vector unsigned char){63,247,161,20,115,235,1,135,63,247,161,20,115,235,1,135}
        ,(vector unsigned char){63,247,177,123,9,118,207,219,63,247,177,123,9,118,207,219}
        ,(vector unsigned char){63,247,193,237,1,48,193,50,63,247,193,237,1,48,193,50}
        ,(vector unsigned char){63,247,210,106,98,255,134,240,63,247,210,106,98,255,134,240}
        ,(vector unsigned char){63,247,226,243,54,207,78,98,63,247,226,243,54,207,78,98}
        ,(vector unsigned char){63,247,243,135,132,145,196,145,63,247,243,135,132,145,196,145}
        ,(vector unsigned char){63,248,4,39,84,62,26,18,63,248,4,39,84,62,26,18}
        ,(vector unsigned char){63,248,20,210,173,209,6,217,63,248,20,210,173,209,6,217}
        ,(vector unsigned char){63,248,37,137,153,76,206,19,63,248,37,137,153,76,206,19}
        ,(vector unsigned char){63,248,54,76,30,185,65,247,63,248,54,76,30,185,65,247}
        ,(vector unsigned char){63,248,71,26,70,35,199,173,63,248,71,26,70,35,199,173}
        ,(vector unsigned char){63,248,87,244,23,159,91,33,63,248,87,244,23,159,91,33}
        ,(vector unsigned char){63,248,104,217,155,68,146,237,63,248,104,217,155,68,146,237}
        ,(vector unsigned char){63,248,121,202,217,49,164,54,63,248,121,202,217,49,164,54}
        ,(vector unsigned char){63,248,138,199,217,138,102,153,63,248,138,199,217,138,102,153}
        ,(vector unsigned char){63,248,155,208,164,120,88,15,63,248,155,208,164,120,88,15}
        ,(vector unsigned char){63,248,172,229,66,42,160,219,63,248,172,229,66,42,160,219}
        ,(vector unsigned char){63,248,190,5,186,214,23,120,63,248,190,5,186,214,23,120}
        ,(vector unsigned char){63,248,207,50,22,181,68,140,63,248,207,50,22,181,68,140}
        ,(vector unsigned char){63,248,224,106,94,8,102,217,63,248,224,106,94,8,102,217}
        ,(vector unsigned char){63,248,241,174,153,21,119,54,63,248,241,174,153,21,119,54}
        ,(vector unsigned char){63,249,2,254,208,40,44,138,63,249,2,254,208,40,44,138}
        ,(vector unsigned char){63,249,20,91,11,145,255,198,63,249,20,91,11,145,255,198}
        ,(vector unsigned char){63,249,37,195,83,170,47,226,63,249,37,195,83,170,47,226}
        ,(vector unsigned char){63,249,55,55,176,205,197,229,63,249,55,55,176,205,197,229}
        ,(vector unsigned char){63,249,72,184,43,95,152,229,63,249,72,184,43,95,152,229}
        ,(vector unsigned char){63,249,90,68,203,200,82,15,63,249,90,68,203,200,82,15}
        ,(vector unsigned char){63,249,107,221,154,118,112,179,63,249,107,221,154,118,112,179}
        ,(vector unsigned char){63,249,125,130,159,222,78,80,63,249,125,130,159,222,78,80}
        ,(vector unsigned char){63,249,143,51,228,122,34,162,63,249,143,51,228,122,34,162}
        ,(vector unsigned char){63,249,160,241,112,202,7,186,63,249,160,241,112,202,7,186}
        ,(vector unsigned char){63,249,178,187,77,83,254,13,63,249,178,187,77,83,254,13}
        ,(vector unsigned char){63,249,196,145,130,163,240,144,63,249,196,145,130,163,240,144}
        ,(vector unsigned char){63,249,214,116,25,75,184,213,63,249,214,116,25,75,184,213}
        ,(vector unsigned char){63,249,232,99,25,227,35,35,63,249,232,99,25,227,35,35}
        ,(vector unsigned char){63,249,250,94,141,7,242,158,63,249,250,94,141,7,242,158}
        ,(vector unsigned char){63,250,12,102,123,93,229,101,63,250,12,102,123,93,229,101}
        ,(vector unsigned char){63,250,30,122,237,142,184,187,63,250,30,122,237,142,184,187}
        ,(vector unsigned char){63,250,48,155,236,74,45,51,63,250,48,155,236,74,45,51}
        ,(vector unsigned char){63,250,66,201,128,70,10,216,63,250,66,201,128,70,10,216}
        ,(vector unsigned char){63,250,85,3,178,62,37,93,63,250,85,3,178,62,37,93}
        ,(vector unsigned char){63,250,103,74,138,244,96,82,63,250,103,74,138,244,96,82}
        ,(vector unsigned char){63,250,121,158,19,48,179,88,63,250,121,158,19,48,179,88}
        ,(vector unsigned char){63,250,139,254,83,193,46,89,63,250,139,254,83,193,46,89}
        ,(vector unsigned char){63,250,158,107,85,121,253,191,63,250,158,107,85,121,253,191}
        ,(vector unsigned char){63,250,176,229,33,53,110,186,63,250,176,229,33,53,110,186}
        ,(vector unsigned char){63,250,195,107,191,211,243,122,63,250,195,107,191,211,243,122}
        ,(vector unsigned char){63,250,213,255,58,60,39,116,63,250,213,255,58,60,39,116}
        ,(vector unsigned char){63,250,232,159,153,90,211,173,63,250,232,159,153,90,211,173}
        ,(vector unsigned char){63,250,251,76,230,34,242,255,63,250,251,76,230,34,242,255}
        ,(vector unsigned char){63,251,14,7,41,141,182,102,63,251,14,7,41,141,182,102}
        ,(vector unsigned char){63,251,32,206,108,154,137,82,63,251,32,206,108,154,137,82}
        ,(vector unsigned char){63,251,51,162,184,79,21,251,63,251,51,162,184,79,21,251}
        ,(vector unsigned char){63,251,70,132,21,183,73,177,63,251,70,132,21,183,73,177}
        ,(vector unsigned char){63,251,89,114,141,229,89,58,63,251,89,114,141,229,89,58}
        ,(vector unsigned char){63,251,108,110,41,241,197,42,63,251,108,110,41,241,197,42}
        ,(vector unsigned char){63,251,127,118,242,251,94,71,63,251,127,118,242,251,94,71}
        ,(vector unsigned char){63,251,146,140,242,39,73,228,63,251,146,140,242,39,73,228}
        ,(vector unsigned char){63,251,165,176,48,161,6,74,63,251,165,176,48,161,6,74}
        ,(vector unsigned char){63,251,184,224,183,154,111,31,63,251,184,224,183,154,111,31}
        ,(vector unsigned char){63,251,204,30,144,75,193,210,63,251,204,30,144,75,193,210}
        ,(vector unsigned char){63,251,223,105,195,243,162,7,63,251,223,105,195,243,162,7}
        ,(vector unsigned char){63,251,242,194,91,215,30,9,63,251,242,194,91,215,30,9}
        ,(vector unsigned char){63,252,6,40,97,65,179,61,63,252,6,40,97,65,179,61}
        ,(vector unsigned char){63,252,25,155,221,133,82,156,63,252,25,155,221,133,82,156}
        ,(vector unsigned char){63,252,45,28,217,250,101,44,63,252,45,28,217,250,101,44}
        ,(vector unsigned char){63,252,64,171,95,255,208,122,63,252,64,171,95,255,208,122}
        ,(vector unsigned char){63,252,84,71,120,250,251,34,63,252,84,71,120,250,251,34}
        ,(vector unsigned char){63,252,103,241,46,87,209,75,63,252,103,241,46,87,209,75}
        ,(vector unsigned char){63,252,123,168,137,136,201,51,63,252,123,168,137,136,201,51}
        ,(vector unsigned char){63,252,143,109,148,6,231,181,63,252,143,109,148,6,231,181}
        ,(vector unsigned char){63,252,163,64,87,81,196,219,63,252,163,64,87,81,196,219}
        ,(vector unsigned char){63,252,183,32,220,239,144,105,63,252,183,32,220,239,144,105}
        ,(vector unsigned char){63,252,203,15,46,109,22,117,63,252,203,15,46,109,22,117}
        ,(vector unsigned char){63,252,223,11,85,93,195,250,63,252,223,11,85,93,195,250}
        ,(vector unsigned char){63,252,243,21,91,91,171,116,63,252,243,21,91,91,171,116}
        ,(vector unsigned char){63,253,7,45,74,7,137,124,63,253,7,45,74,7,137,124}
        ,(vector unsigned char){63,253,27,83,43,8,201,104,63,253,27,83,43,8,201,104}
        ,(vector unsigned char){63,253,47,135,8,13,137,242,63,253,47,135,8,13,137,242}
        ,(vector unsigned char){63,253,67,200,234,202,161,214,63,253,67,200,234,202,161,214}
        ,(vector unsigned char){63,253,88,24,220,251,164,135,63,253,88,24,220,251,164,135}
        ,(vector unsigned char){63,253,108,118,232,98,230,211,63,253,108,118,232,98,230,211}
        ,(vector unsigned char){63,253,128,227,22,201,131,152,63,253,128,227,22,201,131,152}
        ,(vector unsigned char){63,253,149,93,113,255,96,117,63,253,149,93,113,255,96,117}
        ,(vector unsigned char){63,253,169,230,3,219,50,133,63,253,169,230,3,219,50,133}
        ,(vector unsigned char){63,253,190,124,214,58,131,21,63,253,190,124,214,58,131,21}
        ,(vector unsigned char){63,253,211,33,243,1,180,96,63,253,211,33,243,1,180,96}
        ,(vector unsigned char){63,253,231,213,100,28,6,88,63,253,231,213,100,28,6,88}
        ,(vector unsigned char){63,253,252,151,51,123,155,95,63,253,252,151,51,123,155,95}
        ,(vector unsigned char){63,254,17,103,107,25,125,23,63,254,17,103,107,25,125,23}
        ,(vector unsigned char){63,254,38,70,20,245,161,41,63,254,38,70,20,245,161,41}
        ,(vector unsigned char){63,254,59,51,59,22,238,18,63,254,59,51,59,22,238,18}
        ,(vector unsigned char){63,254,80,46,231,139,63,246,63,254,80,46,231,139,63,246}
        ,(vector unsigned char){63,254,101,57,36,103,109,118,63,254,101,57,36,103,109,118}
        ,(vector unsigned char){63,254,122,81,251,199,76,131,63,254,122,81,251,199,76,131}
        ,(vector unsigned char){63,254,143,121,119,205,183,64,63,254,143,121,119,205,183,64}
        ,(vector unsigned char){63,254,164,175,162,164,144,218,63,254,164,175,162,164,144,218}
        ,(vector unsigned char){63,254,185,244,134,124,202,110,63,254,185,244,134,124,202,110}
        ,(vector unsigned char){63,254,207,72,45,142,103,241,63,254,207,72,45,142,103,241}
        ,(vector unsigned char){63,254,228,170,162,24,133,16,63,254,228,170,162,24,133,16}
        ,(vector unsigned char){63,254,250,27,238,97,90,39,63,254,250,27,238,97,90,39}
        ,(vector unsigned char){63,255,15,156,28,182,65,42,63,255,15,156,28,182,65,42}
        ,(vector unsigned char){63,255,37,43,55,107,186,151,63,255,37,43,55,107,186,151}
        ,(vector unsigned char){63,255,58,201,72,221,114,116,63,255,58,201,72,221,114,116}
        ,(vector unsigned char){63,255,80,118,91,110,69,64,63,255,80,118,91,110,69,64}
        ,(vector unsigned char){63,255,102,50,121,136,68,248,63,255,102,50,121,136,68,248}
        ,(vector unsigned char){63,255,123,253,173,156,190,20,63,255,123,253,173,156,190,20}
        ,(vector unsigned char){63,255,145,216,2,36,60,137,63,255,145,216,2,36,60,137}
        ,(vector unsigned char){63,255,167,193,129,158,144,216,63,255,167,193,129,158,144,216}
        ,(vector unsigned char){63,255,189,186,54,146,213,20,63,255,189,186,54,146,213,20}
        ,(vector unsigned char){63,255,211,194,43,143,113,241,63,255,211,194,43,143,113,241}
        ,(vector unsigned char){63,255,233,217,107,42,35,217,63,255,233,217,107,42,35,217}
        };
    vector unsigned char var3365;
    vector unsigned char var3366;
    vector unsigned char var3367;
    vector unsigned char var3368;
    vector unsigned char var3369;
    vector unsigned char var3370;
    vector unsigned char var3371;
    vector unsigned char var3372;
    vector unsigned char var3373;
    vector unsigned char var3374;
    vector unsigned char var3375;
    vector unsigned char var3377;
    vector unsigned char var3378;
    vector unsigned char var3380;
    vector unsigned char var3382;
    vector unsigned char var3383;
    vector unsigned char var3386;
    vector unsigned char var3387;
    vector unsigned char var3388;
    vector unsigned char var3389;
    vector unsigned char var3390;
    vector unsigned char var3392;
    vector unsigned char var3393;
    vector unsigned char var3394;
    vector unsigned char var3395;
    vector unsigned char var3396;
    vector unsigned char var3397;
    vector unsigned char var3398;
    vector unsigned char var3399;
    vector unsigned char var3400;
    vector double var3401;
    var3246=(vector unsigned char){60,119,119,208,255,218,13,37,60,119,119,208,255,218,13,37};
    var3247=(vector unsigned char){63,247,21,71,101,43,130,254,63,247,21,71,101,43,130,254};
    var3248=(vector unsigned char){64,187,254,0,0,0,0,0,64,187,254,0,0,0,0,0};
    var3251=(vector unsigned char){0,1,2,3,16,17,18,19,8,9,10,11,24,25,26,27};
    var3253=(vector unsigned char){0,1,2,3,128,128,128,128,8,9,10,11,128,128,128,128};
    var3258=(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0};
    var3261=(vector unsigned char){192,144,200,0,192,144,200,0,192,144,200,0,192,144,200,0};
    var3263=(vector unsigned char){255,240,0,0,255,240,0,0,255,240,0,0,255,240,0,0};
    var3269=(vector unsigned char){127,240,0,0,127,240,0,0,127,240,0,0,127,240,0,0};
    var3275=(vector unsigned char){0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
    var3279=(vector unsigned char){63,240,0,0,63,240,0,0,63,240,0,0,63,240,0,0};
    var3281=(vector unsigned char){0,1,2,3,0,1,2,3,8,9,10,11,8,9,10,11};
    var3283=(vector unsigned char){16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16};
    var3316=(vector unsigned char){60,234,137,31,53,126,16,195,60,234,137,31,53,126,16,195};
    var3317=(vector unsigned char){63,131,184,34,119,255,164,239,63,131,184,34,119,255,164,239};
    var3319=(vector unsigned char){61,106,224,3,6,192,84,94,61,106,224,3,6,192,84,94};
    var3320=(vector unsigned char){63,172,107,7,252,94,100,87,63,172,107,7,252,94,100,87};
    var3323=(vector unsigned char){61,230,18,97,15,141,240,236,61,230,18,97,15,141,240,236};
    var3324=(vector unsigned char){63,206,191,189,255,141,180,166,63,206,191,189,255,141,180,166};
    var3327=(vector unsigned char){62,90,230,69,2,131,210,77,62,90,230,69,2,131,210,77};
    var3328=(vector unsigned char){63,230,46,66,254,250,57,217,63,230,46,66,254,250,57,217};
    var3331=(vector unsigned char){62,199,29,227,166,37,185,83,62,199,29,227,166,37,185,83};
    var3332=(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0};
    var3337=(vector unsigned char){63,42,1,160,26,0,1,159,63,42,1,160,26,0,1,159};
    var3341=(vector unsigned char){63,129,17,17,17,17,18,77,63,129,17,17,17,17,18,77};
    var3345=(vector unsigned char){63,197,85,85,85,85,85,85,63,197,85,85,85,85,85,85};
    var3356=(vector unsigned char){64,184,1,0,64,184,1,0,64,184,1,0,64,184,1,0};
    var3365=(vector unsigned char){128,128,128,3,128,128,128,7,128,128,128,11,128,128,128,15};
    var3371=(vector unsigned char){0,1,2,3,4,5,6,7,24,25,26,27,28,29,30,31};
    var3396=(vector unsigned char){127,240,0,0,0,0,0,0,127,240,0,0,0,0,0,0};
    var3397=(vector unsigned char){128,0,0,0,0,0,0,0,128,0,0,0,0,0,0,0};
    var3399=(vector unsigned char){64,134,51,206,143,185,248,126,64,134,51,206,143,185,248,126};
    var3244=(vector unsigned char)var3244In;
    var3400=(vector unsigned char)si_dfcmgt((qword)var3244,(qword)var3399);
    var3398=(vector unsigned char)si_selb((qword)var3396,(qword)var3244,(qword)var3397);
    var3260=(vector unsigned char)si_shufb((qword)var3244,(qword)var3244,(qword)var3251);
    var3264=(vector unsigned char)si_clgt((qword)var3260,(qword)var3263);
    var3262=(vector unsigned char)si_clgt((qword)var3260,(qword)var3261);
    var3265=(vector unsigned char)si_andc((qword)var3262,(qword)var3264);
    var3289=(vector unsigned char)si_dfnms((qword)var3244,(qword)var3247,(qword)var3248);
    var3292=(vector unsigned char)si_shufb((qword)var3289,(qword)var3289,(qword)var3251);
    var3386=(vector unsigned char)si_shufb((qword)var3292,(qword)var3292,(qword)var3365);
    var3387=(vector unsigned char)si_rotqbii((qword)var3386,(int)4);
    var3389=(vector unsigned char)si_rotqbyi((qword)var3387,(int)8);
    var3390=*(vector unsigned char*)(var3364.c+spu_extract((vector signed int)var3389,0));
    var3388=*(vector unsigned char*)(var3364.c+spu_extract((vector signed int)var3387,0));
    var3392=(vector unsigned char)si_shufb((qword)var3388,(qword)var3390,(qword)var3371);
    var3377=(vector unsigned char)si_cgt((qword)var3356,(qword)var3292);
    var3374=(vector unsigned char)si_rotqbii((qword)var3292,(int)4);
    var3375=(vector unsigned char)si_rotqbyi((qword)var3374,(int)1);
    var3378=(vector unsigned char)si_andc((qword)var3375,(qword)var3377);
    var3380=(vector unsigned char)si_and((qword)var3378,(qword)var3269);
    var3382=(vector unsigned char)si_shufb((qword)var3380,(qword)var3380,(qword)var3253);
    var3310=(vector unsigned char)si_ceq((qword)var3292,(qword)var3269);
    var3307=(vector unsigned char)si_ceq((qword)var3292,(qword)var3263);
    var3308=(vector unsigned char)si_or((qword)var3265,(qword)var3307);
    var3311=(vector unsigned char)si_or((qword)var3308,(qword)var3310);
    var3313=(vector unsigned char)si_shufb((qword)var3311,(qword)var3311,(qword)var3253);
    var3294=(vector unsigned char)si_shufb((qword)var3292,(qword)var3292,(qword)var3253);
    var3295=(vector unsigned char)si_dfs((qword)var3294,(qword)var3248);
    var3296=(vector unsigned char)si_dfnma((qword)var3244,(qword)var3247,(qword)var3295);
    var3249=(vector unsigned char)si_dfma((qword)var3244,(qword)var3247,(qword)var3248);
    var3252=(vector unsigned char)si_shufb((qword)var3249,(qword)var3249,(qword)var3251);
    var3366=(vector unsigned char)si_shufb((qword)var3252,(qword)var3252,(qword)var3365);
    var3367=(vector unsigned char)si_rotqbii((qword)var3366,(int)4);
    var3369=(vector unsigned char)si_rotqbyi((qword)var3367,(int)8);
    var3370=*(vector unsigned char*)(var3364.c+spu_extract((vector signed int)var3369,0));
    var3368=*(vector unsigned char*)(var3364.c+spu_extract((vector signed int)var3367,0));
    var3372=(vector unsigned char)si_shufb((qword)var3368,(qword)var3370,(qword)var3371);
    var3357=(vector unsigned char)si_cgt((qword)var3356,(qword)var3252);
    var3354=(vector unsigned char)si_rotqbii((qword)var3252,(int)4);
    var3355=(vector unsigned char)si_rotqbyi((qword)var3354,(int)1);
    var3358=(vector unsigned char)si_andc((qword)var3355,(qword)var3357);
    var3360=(vector unsigned char)si_and((qword)var3358,(qword)var3269);
    var3362=(vector unsigned char)si_shufb((qword)var3360,(qword)var3360,(qword)var3253);
    var3270=(vector unsigned char)si_ceq((qword)var3252,(qword)var3269);
    var3267=(vector unsigned char)si_ceq((qword)var3252,(qword)var3263);
    var3268=(vector unsigned char)si_or((qword)var3265,(qword)var3267);
    var3271=(vector unsigned char)si_or((qword)var3268,(qword)var3270);
    var3273=(vector unsigned char)si_shufb((qword)var3271,(qword)var3271,(qword)var3253);
    var3254=(vector unsigned char)si_shufb((qword)var3252,(qword)var3252,(qword)var3253);
    var3255=(vector unsigned char)si_dfs((qword)var3254,(qword)var3248);
    var3256=(vector unsigned char)si_dfms((qword)var3244,(qword)var3247,(qword)var3255);
    var3297=(vector unsigned char)si_dfma((qword)var3244,(qword)var3246,(qword)var3296);
    var3314=(vector unsigned char)si_selb((qword)var3297,(qword)var3258,(qword)var3313);
    var3257=(vector unsigned char)si_dfma((qword)var3244,(qword)var3246,(qword)var3256);
    var3274=(vector unsigned char)si_selb((qword)var3257,(qword)var3258,(qword)var3273);
    var3245=(vector unsigned char)si_dfm((qword)var3244,(qword)var3244);
    var3278=(vector unsigned char)si_shufb((qword)var3245,(qword)var3245,(qword)var3251);
    var3280=(vector unsigned char)si_cgt((qword)var3278,(qword)var3279);
    var3282=(vector unsigned char)si_shufb((qword)var3280,(qword)var3280,(qword)var3281);
    var3284=(vector unsigned char)si_selb((qword)var3275,(qword)var3282,(qword)var3283);
    var3351=(vector unsigned char)si_shufb((qword)var3332,(qword)var3332,(qword)var3284);
    var3347=(vector unsigned char)si_shufb((qword)var3345,(qword)var3328,(qword)var3284);
    var3343=(vector unsigned char)si_shufb((qword)var3341,(qword)var3324,(qword)var3284);
    var3339=(vector unsigned char)si_shufb((qword)var3337,(qword)var3320,(qword)var3284);
    var3333=(vector unsigned char)si_shufb((qword)var3331,(qword)var3332,(qword)var3284);
    var3329=(vector unsigned char)si_shufb((qword)var3327,(qword)var3328,(qword)var3284);
    var3325=(vector unsigned char)si_shufb((qword)var3323,(qword)var3324,(qword)var3284);
    var3321=(vector unsigned char)si_shufb((qword)var3319,(qword)var3320,(qword)var3284);
    var3318=(vector unsigned char)si_shufb((qword)var3316,(qword)var3317,(qword)var3284);
    var3315=(vector unsigned char)si_shufb((qword)var3245,(qword)var3314,(qword)var3284);
    var3322=(vector unsigned char)si_dfma((qword)var3315,(qword)var3318,(qword)var3321);
    var3326=(vector unsigned char)si_dfma((qword)var3315,(qword)var3322,(qword)var3325);
    var3330=(vector unsigned char)si_dfma((qword)var3315,(qword)var3326,(qword)var3329);
    var3334=(vector unsigned char)si_dfma((qword)var3315,(qword)var3330,(qword)var3333);
    var3383=(vector unsigned char)si_dfm((qword)var3334,(qword)var3382);
    var3393=(vector unsigned char)si_dfm((qword)var3383,(qword)var3392);
    var3336=(vector unsigned char)si_shufb((qword)var3334,(qword)var3317,(qword)var3284);
    var3285=(vector unsigned char)si_shufb((qword)var3245,(qword)var3274,(qword)var3284);
    var3340=(vector unsigned char)si_dfma((qword)var3285,(qword)var3336,(qword)var3339);
    var3344=(vector unsigned char)si_dfma((qword)var3285,(qword)var3340,(qword)var3343);
    var3348=(vector unsigned char)si_dfma((qword)var3285,(qword)var3344,(qword)var3347);
    var3352=(vector unsigned char)si_dfma((qword)var3285,(qword)var3348,(qword)var3351);
    var3363=(vector unsigned char)si_dfm((qword)var3352,(qword)var3362);
    var3373=(vector unsigned char)si_dfm((qword)var3363,(qword)var3372);
    var3394=(vector unsigned char)si_dfs((qword)var3373,(qword)var3393);
    var3353=(vector unsigned char)si_dfm((qword)var3244,(qword)var3352);
    var3395=(vector unsigned char)si_shufb((qword)var3353,(qword)var3394,(qword)var3284);
    var3401=(vector double)si_selb((qword)var3395,(qword)var3398,(qword)var3400);
    return var3401;}

#endif /* MASS_SINH_H */
