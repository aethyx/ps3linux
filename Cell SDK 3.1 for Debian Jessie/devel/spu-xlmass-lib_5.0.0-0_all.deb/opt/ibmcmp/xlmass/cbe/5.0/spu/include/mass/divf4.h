/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2007.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

#ifndef MASS_DIV_H
#define MASS_DIV_H 1
#include <spu_intrinsics.h>
static __inline vector float _divf4(vector float var1,vector float var2){
    vector float var10;
    vector float var11;
    vector float var3;
    vector float var4;
    vector float var5;
    vector float var6;
    vector float var7;
    vector float var8;
    vector float var9;
    var5=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var9=(vector float)(vector unsigned char){51,192,0,0,51,192,0,0,51,192,0,0,51,192,0,0};
    var3=(vector float)si_frest((qword)var2);
    var4=(vector float)si_fi((qword)var2,(qword)var3);
    var6=(vector float)si_fnms((qword)var2,(qword)var4,(qword)var5);
    var7=(vector float)si_fma((qword)var6,(qword)var4,(qword)var4);
    var8=(vector float)si_fm((qword)var1,(qword)var7);
    var10=(vector float)si_fm((qword)var8,(qword)var9);
    var11=(vector float)si_fma((qword)var1,(qword)var7,(qword)var10);
    return var11;
}

#endif /* MASS_DIV_H */
