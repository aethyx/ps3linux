/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2008.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/
#ifndef MASS_RCBRT_H
#define MASS_RCBRT_H
#include <spu_intrinsics.h>
static __inline vector double _rcbrtd2(vector double var2767In){
    vector unsigned char var2767;
    vector unsigned char var2768;
    vector unsigned char var2769;
    vector unsigned char var2770;
    vector unsigned char var2771;
    vector unsigned char var2772;
    vector unsigned char var2773;
    vector unsigned char var2774;
    vector unsigned char var2775;
    vector unsigned char var2778;
    vector unsigned char var2779;
    vector unsigned char var2780;
    vector unsigned char var2781;
    vector unsigned char var2782;
    vector unsigned char var2783;
    vector unsigned char var2784;
    vector unsigned char var2785;
    vector unsigned char var2786;
    vector unsigned char var2787;
    vector unsigned char var2788;
    vector unsigned char var2789;
    vector unsigned char var2790;
    vector unsigned char var2791;
    vector unsigned char var2792;
    vector unsigned char var2793;
    vector unsigned char var2794;
    vector unsigned char var2795;
    vector unsigned char var2796;
    vector unsigned char var2797;
    vector unsigned char var2798;
    vector unsigned char var2799;
    vector unsigned char var2800;
    vector unsigned char var2801;
    vector unsigned char var2802;
    vector unsigned char var2803;
    vector unsigned char var2805;
    vector unsigned char var2806;
    vector unsigned char var2808;
    vector unsigned char var2809;
    vector unsigned char var2810;
    vector unsigned char var2811;
    vector unsigned char var2812;
    vector unsigned char var2813;
    vector unsigned char var2814;
    vector unsigned char var2815;
    static const union {const vector unsigned char v[32];const char c[32*16];} var2816= 
        {(vector unsigned char){63,188,77,177,19,63,100,214,191,183,70,219,106,145,97,238}
        ,(vector unsigned char){63,183,69,14,78,107,177,227,191,178,96,50,91,154,173,173}
        ,(vector unsigned char){63,179,68,19,170,172,182,236,191,173,158,187,8,254,187,97}
        ,(vector unsigned char){63,176,9,208,217,91,172,158,191,168,5,33,47,178,28,12}
        ,(vector unsigned char){63,170,215,70,142,133,133,175,191,163,151,176,161,213,184,151}
        ,(vector unsigned char){63,166,145,200,153,14,196,254,191,160,17,197,0,240,204,63}
        ,(vector unsigned char){63,163,16,197,239,209,89,216,191,154,127,94,177,237,147,186}
        ,(vector unsigned char){63,160,45,25,102,253,228,107,191,149,244,115,13,95,0,177}
        ,(vector unsigned char){63,155,144,73,249,89,169,145,191,146,70,217,94,213,138,75}
        ,(vector unsigned char){63,151,147,158,230,59,179,246,191,142,144,235,16,171,10,105}
        ,(vector unsigned char){63,148,62,7,177,134,243,33,191,137,171,36,46,65,252,46}
        ,(vector unsigned char){63,145,113,32,34,139,194,12,191,133,164,183,122,237,194,0}
        ,(vector unsigned char){63,142,41,37,130,223,11,91,191,130,82,5,250,254,106,122}
        ,(vector unsigned char){63,138,41,147,190,239,35,208,191,127,33,90,155,119,213,56}
        ,(vector unsigned char){63,134,195,220,170,203,201,36,191,122,138,219,79,67,214,175}
        ,(vector unsigned char){63,131,222,65,126,143,44,9,191,118,181,36,189,166,193,76}
        ,(vector unsigned char){63,129,99,190,13,85,56,210,191,115,125,118,229,141,108,79}
        ,(vector unsigned char){63,126,134,46,198,39,227,197,191,112,199,223,41,133,182,228}
        ,(vector unsigned char){63,122,220,60,82,124,49,77,191,108,251,146,236,163,171,63}
        ,(vector unsigned char){63,119,178,49,236,152,61,156,191,105,25,199,237,223,250,129}
        ,(vector unsigned char){63,116,244,155,28,74,152,109,191,101,204,131,59,128,49,116}
        ,(vector unsigned char){63,114,147,68,123,232,208,244,191,98,251,89,135,159,235,14}
        ,(vector unsigned char){63,112,128,164,48,127,66,83,191,96,146,61,142,52,209,232}
        ,(vector unsigned char){63,109,98,192,43,18,141,72,191,93,1,81,17,148,21,177}
        ,(vector unsigned char){63,106,55,214,196,98,172,129,191,89,113,222,47,212,8,16}
        ,(vector unsigned char){63,103,112,109,226,131,190,117,191,86,95,113,196,168,3,252}
        ,(vector unsigned char){63,100,254,224,200,225,137,236,191,83,183,38,217,193,208,150}
        ,(vector unsigned char){63,98,215,154,88,137,156,211,191,81,105,52,198,246,175,89}
        ,(vector unsigned char){63,96,240,190,61,174,35,10,191,78,208,195,95,194,133,163}
        ,(vector unsigned char){63,94,131,195,18,60,83,209,191,75,83,31,228,125,162,209}
        ,(vector unsigned char){63,91,135,159,140,235,205,39,191,72,70,194,30,165,57,235}
        ,(vector unsigned char){63,88,224,180,111,234,148,135,191,69,155,211,141,8,42,88}
        };
    vector unsigned char var2817;
    vector unsigned char var2818;
    vector unsigned char var2819;
    vector unsigned char var2820;
    vector unsigned char var2821;
    vector unsigned char var2822;
    vector unsigned char var2823;
    vector unsigned char var2824;
    vector unsigned char var2825;
    vector unsigned char var2826;
    vector unsigned char var2827;
    vector unsigned char var2828;
    vector unsigned char var2829;
    static const union {const vector unsigned char v[32];const char c[32*16];} var2830= 
        {(vector unsigned char){63,194,111,170,244,165,216,84,191,191,244,54,118,40,114,13}
        ,(vector unsigned char){63,192,34,123,56,240,82,95,191,187,29,216,204,155,69,8}
        ,(vector unsigned char){63,188,90,137,182,232,208,93,191,183,32,36,123,156,244,141}
        ,(vector unsigned char){63,185,1,182,249,56,19,132,191,179,208,42,105,6,190,199}
        ,(vector unsigned char){63,182,34,12,189,210,18,228,191,177,12,157,107,39,45,89}
        ,(vector unsigned char){63,179,167,186,69,6,64,227,191,173,118,131,53,189,211,51}
        ,(vector unsigned char){63,177,130,151,27,74,181,135,191,169,142,146,29,11,1,192}
        ,(vector unsigned char){63,175,74,199,35,216,89,92,191,166,64,51,10,245,155,154}
        ,(vector unsigned char){63,172,10,104,20,131,183,119,191,163,112,189,203,50,242,86}
        ,(vector unsigned char){63,169,49,249,115,77,241,227,191,161,10,172,220,37,142,114}
        ,(vector unsigned char){63,166,178,108,117,141,229,94,191,157,249,16,114,121,124,221}
        ,(vector unsigned char){63,164,127,42,99,251,140,125,191,154,112,30,213,226,96,239}
        ,(vector unsigned char){63,162,141,161,107,130,96,184,191,151,99,38,187,198,62,0}
        ,(vector unsigned char){63,160,212,232,110,220,11,5,191,148,190,233,26,54,32,145}
        ,(vector unsigned char){63,158,154,233,188,179,121,101,191,146,115,121,240,167,60,178}
        ,(vector unsigned char){63,155,225,189,135,49,175,123,191,144,115,159,3,14,92,17}
        ,(vector unsigned char){63,153,115,96,27,127,255,235,191,141,104,159,121,225,243,123}
        ,(vector unsigned char){63,151,70,121,167,48,149,30,191,138,88,157,208,36,200,48}
        ,(vector unsigned char){63,149,83,5,130,174,80,48,191,135,167,177,58,38,127,21}
        ,(vector unsigned char){63,147,146,28,148,197,16,47,191,133,72,192,64,133,132,119}
        ,(vector unsigned char){63,145,253,201,6,107,59,59,191,131,48,180,174,132,113,76}
        ,(vector unsigned char){63,144,144,225,132,164,88,157,191,129,86,36,132,47,211,218}
        ,(vector unsigned char){63,142,141,213,83,187,85,123,191,127,98,21,205,29,249,17}
        ,(vector unsigned char){63,140,55,250,223,146,160,17,191,124,117,27,198,252,57,28}
        ,(vector unsigned char){63,138,25,99,134,37,53,158,191,121,217,157,20,183,190,114}
        ,(vector unsigned char){63,136,44,24,253,144,101,101,191,119,133,130,191,82,18,243}
        ,(vector unsigned char){63,134,106,224,113,84,18,23,191,117,112,27,50,133,209,222}
        ,(vector unsigned char){63,132,209,32,199,93,47,93,191,115,145,227,195,197,227,98}
        ,(vector unsigned char){63,131,90,204,201,49,146,230,191,113,228,91,68,109,78,125}
        ,(vector unsigned char){63,130,4,80,141,32,122,109,191,112,97,220,0,65,190,8}
        ,(vector unsigned char){63,128,202,129,152,138,228,27,191,110,10,247,178,26,123,140}
        ,(vector unsigned char){63,127,85,34,151,237,230,197,191,107,149,226,222,225,163,232}
        };
    vector unsigned char var2836;
    vector unsigned char var2838;
    vector unsigned char var2840;
    vector unsigned char var2841;
    vector unsigned char var2843;
    vector unsigned char var2844;
    static const union {const vector unsigned char v[32];const char c[32*16];} var2845= 
        {(vector unsigned char){63,204,113,199,28,113,69,225,191,198,31,154,220,56,116,111}
        ,(vector unsigned char){63,202,121,69,88,87,40,240,191,195,247,122,27,195,83,150}
        ,(vector unsigned char){63,200,177,64,252,0,122,110,191,194,19,82,179,10,237,243}
        ,(vector unsigned char){63,199,19,214,155,60,197,79,191,192,105,33,34,203,91,155}
        ,(vector unsigned char){63,197,155,253,237,25,68,130,191,189,225,44,135,155,116,214}
        ,(vector unsigned char){63,196,69,100,249,44,193,175,191,187,69,135,17,47,54,220}
        ,(vector unsigned char){63,195,12,82,63,126,210,218,191,184,243,178,24,158,60,184}
        ,(vector unsigned char){63,193,237,140,99,248,173,52,191,182,225,226,151,12,173,83}
        ,(vector unsigned char){63,192,230,70,60,83,138,232,191,181,7,206,221,227,242,161}
        ,(vector unsigned char){63,191,232,28,192,86,181,237,191,179,94,107,163,188,119,230}
        ,(vector unsigned char){63,190,41,131,23,206,27,158,191,177,223,181,250,105,140,0}
        ,(vector unsigned char){63,188,140,254,153,51,113,145,191,176,134,135,116,132,50,132}
        ,(vector unsigned char){63,187,15,65,15,147,76,73,191,174,156,228,192,118,75,198}
        ,(vector unsigned char){63,185,173,95,16,163,137,89,191,172,103,72,235,4,228,214}
        ,(vector unsigned char){63,184,100,194,149,214,109,250,191,170,101,157,98,97,54,158}
        ,(vector unsigned char){63,183,51,31,165,7,185,4,191,168,146,34,185,25,72,158}
        ,(vector unsigned char){63,182,22,106,174,119,4,191,191,166,231,214,237,84,68,156}
        ,(vector unsigned char){63,181,12,208,86,184,169,125,191,165,98,89,189,70,100,244}
        ,(vector unsigned char){63,180,20,174,112,199,33,86,191,163,253,213,124,113,235,130}
        ,(vector unsigned char){63,179,44,141,247,44,189,50,191,162,182,235,155,159,128,29}
        ,(vector unsigned char){63,178,83,29,219,236,232,73,191,161,138,164,61,125,76,199}
        ,(vector unsigned char){63,177,135,46,141,215,188,151,191,160,118,96,81,123,138,232}
        ,(vector unsigned char){63,176,199,174,23,162,242,207,191,158,239,155,143,74,151,245}
        ,(vector unsigned char){63,176,19,164,193,197,75,185,191,157,25,187,8,147,249,189}
        ,(vector unsigned char){63,174,212,100,71,182,230,110,191,155,103,117,148,206,167,241}
        ,(vector unsigned char){63,173,149,21,42,243,13,197,191,153,213,135,193,119,155,110}
        ,(vector unsigned char){63,172,103,233,225,184,205,14,191,152,97,7,127,205,132,159}
        ,(vector unsigned char){63,171,75,145,56,24,194,77,191,151,7,89,64,253,78,152}
        ,(vector unsigned char){63,170,62,215,157,137,196,194,191,149,198,38,141,236,20,118}
        ,(vector unsigned char){63,169,64,164,25,214,227,62,191,148,155,85,225,168,127,156}
        ,(vector unsigned char){63,168,79,245,157,50,126,161,191,147,133,3,150,221,137,105}
        ,(vector unsigned char){63,167,107,224,159,129,68,43,191,146,129,123,192,75,209,76}
        };
    vector unsigned char var2851;
    vector unsigned char var2853;
    vector unsigned char var2855;
    vector unsigned char var2856;
    vector unsigned char var2858;
    vector unsigned char var2859;
    static const union {const vector unsigned char v[32];const char c[32*16];} var2860= 
        {(vector unsigned char){63,240,0,0,0,0,0,0,191,213,85,85,85,85,85,80}
        ,(vector unsigned char){63,239,172,102,255,28,53,203,191,212,121,203,162,85,119,155}
        ,(vector unsigned char){63,239,92,29,168,14,191,219,191,211,173,63,200,210,9,142}
        ,(vector unsigned char){63,239,14,234,234,158,86,42,191,210,238,70,11,89,49,197}
        ,(vector unsigned char){63,238,196,155,12,24,83,243,191,210,59,158,64,14,106,100}
        ,(vector unsigned char){63,238,124,255,5,229,168,62,191,209,148,45,144,21,182,36}
        ,(vector unsigned char){63,238,55,235,250,252,100,165,191,208,246,249,64,141,177,155}
        ,(vector unsigned char){63,237,245,58,192,111,2,252,191,208,99,34,83,97,235,160}
        ,(vector unsigned char){63,237,180,199,118,11,207,242,191,207,175,195,177,29,170,103}
        ,(vector unsigned char){63,237,118,113,44,139,228,70,191,206,169,11,160,212,45,231}
        ,(vector unsigned char){63,237,58,25,151,65,220,233,191,205,176,221,11,111,155,50}
        ,(vector unsigned char){63,236,255,164,199,147,64,168,191,204,198,24,150,102,115,163}
        ,(vector unsigned char){63,236,198,248,240,208,237,117,191,203,231,187,24,16,106,12}
        ,(vector unsigned char){63,236,143,254,51,62,159,103,191,203,20,218,67,140,234,127}
        ,(vector unsigned char){63,236,90,158,109,74,116,233,191,202,76,161,201,139,141,195}
        ,(vector unsigned char){63,236,38,197,18,29,108,198,191,201,142,80,219,202,211,66}
        ,(vector unsigned char){63,235,244,95,4,206,240,185,191,200,217,56,4,70,43,67}
        ,(vector unsigned char){63,235,195,90,119,160,234,155,191,200,44,183,67,152,78,219}
        ,(vector unsigned char){63,235,147,166,206,192,179,177,191,199,136,60,108,41,143,17}
        ,(vector unsigned char){63,235,101,52,134,28,61,223,191,198,235,65,177,115,167,47}
        ,(vector unsigned char){63,235,55,245,25,234,211,187,191,198,85,76,100,8,226,56}
        ,(vector unsigned char){63,235,11,218,241,150,65,179,191,197,197,235,212,50,30,84}
        ,(vector unsigned char){63,234,224,217,76,188,152,185,191,197,60,184,85,234,89,12}
        ,(vector unsigned char){63,234,182,228,50,12,93,92,191,196,185,82,97,200,109,165}
        ,(vector unsigned char){63,234,141,240,95,197,39,121,191,196,59,97,207,16,30,16}
        ,(vector unsigned char){63,234,101,243,61,173,179,88,191,195,194,149,35,176,110,72}
        ,(vector unsigned char){63,234,62,226,208,86,95,73,191,195,78,160,247,107,173,19}
        ,(vector unsigned char){63,234,24,181,173,132,49,150,191,194,223,63,103,201,45,250}
        ,(vector unsigned char){63,233,243,98,241,164,236,35,191,194,116,47,154,196,236,46}
        ,(vector unsigned char){63,233,206,226,54,48,129,55,191,194,13,53,78,120,168,182}
        ,(vector unsigned char){63,233,171,43,136,223,135,155,191,193,170,24,116,54,186,232}
        ,(vector unsigned char){63,233,136,55,99,161,38,184,191,193,74,164,213,194,121,8}
        };
    vector unsigned char var2866;
    vector unsigned char var2868;
    vector unsigned char var2870;
    vector unsigned char var2871;
    vector unsigned char var2873;
    vector unsigned char var2874;
    vector unsigned char var2875;
    vector unsigned char var2877;
    vector unsigned char var2878;
    vector unsigned char var2881;
    vector unsigned char var2882;
    vector unsigned char var2883;
    vector unsigned char var2884;
    vector unsigned char var2885;
    vector unsigned char var2886;
    vector unsigned char var2887;
    vector double var2888;
    var2768=(vector unsigned char){63,240,0,0,63,244,40,162,63,249,101,254,63,249,101,254};
    var2769=(vector unsigned char){0,0,0,0,249,141,114,139,165,61,110,61,165,61,110,61};
    var2770=(vector unsigned char){0,1,2,3,16,17,18,19,0,1,2,3,16,17,18,19};
    var2771=(vector unsigned char){255,255,170,171,255,255,170,171,255,255,170,171,255,255,170,171};
    var2772=(vector unsigned char){0,1,2,3,16,17,18,19,8,9,10,11,24,25,26,27};
    var2774=(vector unsigned char){67,80,0,0,0,0,0,0,67,80,0,0,0,0,0,0};
    var2779=(vector unsigned char){0,32,0,0,0,32,0,0,0,32,0,0,0,32,0,0};
    var2783=(vector unsigned char){127,240,0,0,127,240,0,0,127,240,0,0,127,240,0,0};
    var2786=(vector unsigned char){85,66,0,0,85,66,0,0,85,66,0,0,85,66,0,0};
    var2788=(vector unsigned char){129,32,0,0,129,32,0,0,129,32,0,0,129,32,0,0};
    var2791=(vector unsigned char){1,1,1,1,1,1,1,1,9,9,9,9,9,9,9,9};
    var2793=(vector unsigned char){12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12};
    var2796=(vector unsigned char){16,1,2,3,4,5,6,7,24,9,10,11,12,13,14,15};
    var2798=(vector unsigned char){0,1,2,3,128,128,128,128,8,9,10,11,128,128,128,128};
    var2800=(vector unsigned char){127,240,0,0,0,0,0,0,127,240,0,0,0,0,0,0};
    var2802=(vector unsigned char){4,5,6,7,20,21,22,23,12,13,14,15,28,29,30,31};
    var2809=(vector unsigned char){63,240,0,0,63,240,0,0,63,240,0,0,63,240,0,0};
    var2810=(vector unsigned char){0,0,127,255,0,0,127,255,0,0,127,255,0,0,127,255};
    var2812=(vector unsigned char){16,17,18,19,4,5,6,7,24,25,26,27,12,13,14,15};
    var2814=(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0};
    var2819=(vector unsigned char){128,128,128,1,128,128,128,5,128,128,128,9,128,128,128,13};
    var2825=(vector unsigned char){8,9,10,11,12,13,14,15,24,25,26,27,28,29,30,31};
    var2827=(vector unsigned char){0,1,2,3,4,5,6,7,16,17,18,19,20,21,22,23};
    var2883=(vector unsigned char){0,1,2,3,20,21,22,23,8,9,10,11,28,29,30,31};
    var2886=(vector unsigned char){0,1,2,3,0,1,2,3,8,9,10,11,8,9,10,11};
    var2767=(vector unsigned char)var2767In;
    var2878=(vector unsigned char)si_dftsv((qword)var2767,(int)64);
    var2803=(vector unsigned char)si_shufb((qword)var2767,(qword)var2767,(qword)var2802);
    var2775=(vector unsigned char)si_dfm((qword)var2767,(qword)var2774);
    var2805=(vector unsigned char)si_shufb((qword)var2775,(qword)var2775,(qword)var2802);
    var2881=(vector unsigned char)si_shufb((qword)var2878,(qword)var2878,(qword)var2772);
    var2778=(vector unsigned char)si_shufb((qword)var2775,(qword)var2775,(qword)var2772);
    var2773=(vector unsigned char)si_shufb((qword)var2767,(qword)var2767,(qword)var2772);
    var2885=(vector unsigned char)si_ceq((qword)var2773,(qword)var2778);
    var2887=(vector unsigned char)si_shufb((qword)var2885,(qword)var2885,(qword)var2886);
    var2877=(vector unsigned char)si_xor((qword)var2773,(qword)var2783);
    var2882=(vector unsigned char)si_or((qword)var2877,(qword)var2881);
    var2884=(vector unsigned char)si_shufb((qword)var2882,(qword)var2767,(qword)var2883);
    var2780=(vector unsigned char)si_rotqbii((qword)var2773,(int)1);
    var2781=(vector unsigned char)si_clgt((qword)var2779,(qword)var2780);
    var2806=(vector unsigned char)si_selb((qword)var2803,(qword)var2805,(qword)var2781);
    var2782=(vector unsigned char)si_selb((qword)var2773,(qword)var2778,(qword)var2781);
    var2817=(vector unsigned char)si_rotqbii((qword)var2782,(int)1);
    var2818=(vector unsigned char)si_andbi((qword)var2817,(int)31);
    var2820=(vector unsigned char)si_shufb((qword)var2818,(qword)var2818,(qword)var2819);
    var2821=(vector unsigned char)si_rotqbii((qword)var2820,(int)4);
    var2866=*(vector unsigned char*)(var2860.c+spu_extract((vector signed int)var2821,0));
    var2851=*(vector unsigned char*)(var2845.c+spu_extract((vector signed int)var2821,0));
    var2836=*(vector unsigned char*)(var2830.c+spu_extract((vector signed int)var2821,0));
    var2823=(vector unsigned char)si_rotqbyi((qword)var2821,(int)8);
    var2868=*(vector unsigned char*)(var2860.c+spu_extract((vector signed int)var2823,0));
    var2873=(vector unsigned char)si_shufb((qword)var2866,(qword)var2868,(qword)var2827);
    var2870=(vector unsigned char)si_shufb((qword)var2866,(qword)var2868,(qword)var2825);
    var2853=*(vector unsigned char*)(var2845.c+spu_extract((vector signed int)var2823,0));
    var2858=(vector unsigned char)si_shufb((qword)var2851,(qword)var2853,(qword)var2827);
    var2855=(vector unsigned char)si_shufb((qword)var2851,(qword)var2853,(qword)var2825);
    var2838=*(vector unsigned char*)(var2830.c+spu_extract((vector signed int)var2823,0));
    var2843=(vector unsigned char)si_shufb((qword)var2836,(qword)var2838,(qword)var2827);
    var2840=(vector unsigned char)si_shufb((qword)var2836,(qword)var2838,(qword)var2825);
    var2824=*(vector unsigned char*)(var2816.c+spu_extract((vector signed int)var2823,0));
    var2822=*(vector unsigned char*)(var2816.c+spu_extract((vector signed int)var2821,0));
    var2828=(vector unsigned char)si_shufb((qword)var2822,(qword)var2824,(qword)var2827);
    var2826=(vector unsigned char)si_shufb((qword)var2822,(qword)var2824,(qword)var2825);
    var2811=(vector unsigned char)si_selb((qword)var2809,(qword)var2782,(qword)var2810);
    var2808=(vector unsigned char)si_shufb((qword)var2782,(qword)var2806,(qword)var2772);
    var2813=(vector unsigned char)si_shufb((qword)var2808,(qword)var2811,(qword)var2812);
    var2815=(vector unsigned char)si_dfs((qword)var2813,(qword)var2814);
    var2829=(vector unsigned char)si_dfma((qword)var2815,(qword)var2826,(qword)var2828);
    var2841=(vector unsigned char)si_dfma((qword)var2815,(qword)var2829,(qword)var2840);
    var2844=(vector unsigned char)si_dfma((qword)var2815,(qword)var2841,(qword)var2843);
    var2856=(vector unsigned char)si_dfma((qword)var2815,(qword)var2844,(qword)var2855);
    var2859=(vector unsigned char)si_dfma((qword)var2815,(qword)var2856,(qword)var2858);
    var2871=(vector unsigned char)si_dfma((qword)var2815,(qword)var2859,(qword)var2870);
    var2874=(vector unsigned char)si_dfma((qword)var2815,(qword)var2871,(qword)var2873);
    var2784=(vector unsigned char)si_and((qword)var2782,(qword)var2783);
    var2785=(vector unsigned char)si_rotqbyi((qword)var2784,(int)14);
    var2787=(vector unsigned char)si_mpya((qword)var2771,(qword)var2785,(qword)var2786);
    var2789=(vector unsigned char)si_a((qword)var2787,(qword)var2788);
    var2790=(vector unsigned char)si_selb((qword)var2787,(qword)var2789,(qword)var2781);
    var2799=(vector unsigned char)si_shufb((qword)var2790,(qword)var2790,(qword)var2798);
    var2792=(vector unsigned char)si_shufb((qword)var2790,(qword)var2790,(qword)var2791);
    var2794=(vector unsigned char)si_selb((qword)var2770,(qword)var2792,(qword)var2793);
    var2795=(vector unsigned char)si_shufb((qword)var2768,(qword)var2769,(qword)var2794);
    var2797=(vector unsigned char)si_shufb((qword)var2795,(qword)var2767,(qword)var2796);
    var2801=(vector unsigned char)si_selb((qword)var2797,(qword)var2799,(qword)var2800);
    var2875=(vector unsigned char)si_dfm((qword)var2801,(qword)var2874);
    var2888=(vector double)si_selb((qword)var2875,(qword)var2884,(qword)var2887);
    return var2888;}

#endif /* MASS_RCBRT_H */
