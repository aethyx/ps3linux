/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2008.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/
#ifndef MASS_LOG10_H
#define MASS_LOG10_H
#include <spu_intrinsics.h>
static __inline vector double _log10d2(vector double var3005In){
    vector unsigned char var3005;
    vector unsigned char var3006;
    vector unsigned char var3007;
    vector unsigned char var3009;
    vector unsigned char var3010;
    vector unsigned char var3011;
    vector unsigned char var3012;
    vector unsigned char var3015;
    vector unsigned char var3016;
    vector unsigned char var3017;
    vector unsigned char var3018;
    vector unsigned char var3019;
    vector unsigned char var3020;
    vector unsigned char var3021;
    vector unsigned char var3022;
    vector unsigned char var3027;
    vector unsigned char var3028;
    vector unsigned char var3029;
    vector unsigned char var3030;
    vector unsigned char var3031;
    vector unsigned char var3032;
    vector unsigned char var3033;
    vector unsigned char var3034;
    vector unsigned char var3036;
    vector unsigned char var3037;
    vector unsigned char var3038;
    vector unsigned char var3039;
    static const union {const vector unsigned char v[256];const char c[256*16];} var3040= 
        {(vector unsigned char){0,0,0,0,0,0,0,0,63,240,0,0,0,0,0,0}
        ,(vector unsigned char){63,119,9,196,109,122,172,119,63,239,224,31,224,31,224,32}
        ,(vector unsigned char){63,134,254,80,182,239,8,81,63,239,192,127,1,252,7,240}
        ,(vector unsigned char){63,145,54,49,23,169,123,12,63,239,161,28,170,1,250,18}
        ,(vector unsigned char){63,150,231,150,133,194,210,42,63,239,129,248,31,129,248,32}
        ,(vector unsigned char){63,156,147,99,186,133,15,134,63,239,99,16,172,160,219,181}
        ,(vector unsigned char){63,161,28,209,213,19,52,19,63,239,68,101,158,74,66,113}
        ,(vector unsigned char){63,163,237,48,148,104,90,38,63,239,37,246,68,35,10,181}
        ,(vector unsigned char){63,166,186,211,117,142,253,135,63,239,7,193,240,124,31,8}
        ,(vector unsigned char){63,169,133,191,195,73,81,148,63,238,233,199,248,69,142,2}
        ,(vector unsigned char){63,172,77,250,185,10,171,95,63,238,204,7,179,1,236,192}
        ,(vector unsigned char){63,175,19,137,131,50,83,160,63,238,174,128,122,186,1,235}
        ,(vector unsigned char){63,176,235,56,159,162,159,155,63,238,145,49,171,240,183,103}
        ,(vector unsigned char){63,178,75,91,126,19,90,61,63,238,116,26,165,151,80,228}
        ,(vector unsigned char){63,179,170,47,221,39,241,195,63,238,87,58,201,1,229,116}
        ,(vector unsigned char){63,181,7,184,54,3,59,183,63,238,58,145,121,220,26,115}
        ,(vector unsigned char){63,182,99,246,250,201,19,22,63,238,30,30,30,30,30,30}
        ,(vector unsigned char){63,183,190,238,150,184,162,129,63,238,1,224,30,1,224,30}
        ,(vector unsigned char){63,185,24,161,110,70,51,91,63,237,229,214,227,248,134,138}
        ,(vector unsigned char){63,186,113,17,223,52,132,148,63,237,202,1,220,160,29,202}
        ,(vector unsigned char){63,187,200,66,64,173,171,186,63,237,174,96,118,185,129,219}
        ,(vector unsigned char){63,189,30,52,227,91,130,218,63,237,146,242,35,30,127,138}
        ,(vector unsigned char){63,190,114,236,17,127,165,178,63,237,119,182,84,184,44,52}
        ,(vector unsigned char){63,191,198,106,15,11,0,165,63,237,92,172,128,117,114,178}
        ,(vector unsigned char){63,192,140,88,140,218,121,228,63,237,65,212,29,65,212,29}
        ,(vector unsigned char){63,193,52,225,180,137,6,46,63,237,39,44,163,252,91,26}
        ,(vector unsigned char){63,193,220,209,151,85,43,123,63,237,12,181,143,110,192,116}
        ,(vector unsigned char){63,194,132,41,75,7,166,64,63,236,242,110,92,68,191,198}
        ,(vector unsigned char){63,195,42,233,226,120,174,26,63,236,216,86,137,3,155,11}
        ,(vector unsigned char){63,195,209,20,109,154,138,100,63,236,190,109,150,1,203,231}
        ,(vector unsigned char){63,196,118,169,249,131,247,77,63,236,164,179,5,94,225,145}
        ,(vector unsigned char){63,197,27,171,144,122,92,138,63,236,139,38,90,251,138,66}
        ,(vector unsigned char){63,197,192,26,57,251,214,136,63,236,113,199,28,113,199,28}
        ,(vector unsigned char){63,198,99,246,250,201,19,22,63,236,88,148,209,13,73,134}
        ,(vector unsigned char){63,199,7,66,212,239,2,127,63,236,63,143,1,195,248,240}
        ,(vector unsigned char){63,199,169,254,199,208,93,223,63,236,38,181,57,46,160,28}
        ,(vector unsigned char){63,200,76,43,208,47,3,179,63,236,14,7,3,129,192,224}
        ,(vector unsigned char){63,200,237,202,232,53,43,108,63,235,245,131,238,134,141,139}
        ,(vector unsigned char){63,201,142,221,7,126,112,223,63,235,221,43,137,148,6,247}
        ,(vector unsigned char){63,202,47,99,35,32,184,107,63,235,196,253,101,136,62,123}
        ,(vector unsigned char){63,202,207,94,45,180,236,148,63,235,172,249,20,193,186,208}
        ,(vector unsigned char){63,203,110,207,23,95,149,233,63,235,149,30,43,24,255,35}
        ,(vector unsigned char){63,204,13,182,205,217,77,238,63,235,125,108,61,218,51,139}
        ,(vector unsigned char){63,204,172,22,60,119,13,201,63,235,101,226,227,190,238,5}
        ,(vector unsigned char){63,205,73,238,76,50,89,112,63,235,78,129,180,232,27,79}
        ,(vector unsigned char){63,205,231,63,227,177,72,15,63,235,55,72,74,216,6,206}
        ,(vector unsigned char){63,206,132,11,231,78,106,77,63,235,32,54,64,108,128,217}
        ,(vector unsigned char){63,207,32,83,57,32,143,39,63,235,9,75,49,217,34,164}
        ,(vector unsigned char){63,207,188,22,185,2,104,10,63,234,242,134,188,161,175,40}
        ,(vector unsigned char){63,208,43,171,162,77,6,100,63,234,219,232,127,148,144,94}
        ,(vector unsigned char){63,208,121,10,219,176,48,9,63,234,197,112,26,197,112,27}
        ,(vector unsigned char){63,208,198,41,117,84,42,143,63,234,175,29,47,135,235,253}
        ,(vector unsigned char){63,209,19,7,218,211,11,118,63,234,152,239,96,106,99,190}
        ,(vector unsigned char){63,209,95,166,118,187,8,255,63,234,130,230,81,48,225,89}
        ,(vector unsigned char){63,209,172,5,178,145,240,112,63,234,109,1,166,208,26,109}
        ,(vector unsigned char){63,209,248,37,246,216,142,19,63,234,87,65,7,104,138,74}
        ,(vector unsigned char){63,210,68,7,171,14,7,58,63,234,65,164,26,65,164,26}
        ,(vector unsigned char){63,210,143,171,53,179,38,131,63,234,44,42,135,197,28,160}
        ,(vector unsigned char){63,210,219,16,252,77,154,175,63,234,22,211,249,122,75,2}
        ,(vector unsigned char){63,211,38,57,99,107,40,54,63,234,1,160,26,1,160,26}
        ,(vector unsigned char){63,211,113,36,206,164,205,237,63,233,236,142,149,16,51,217}
        ,(vector unsigned char){63,211,187,211,160,161,220,251,63,233,215,159,23,107,104,45}
        ,(vector unsigned char){63,212,6,70,59,27,4,73,63,233,194,209,78,228,161,2}
        ,(vector unsigned char){63,212,80,124,254,221,79,196,63,233,174,36,234,85,16,218}
        ,(vector unsigned char){63,212,154,120,75,205,27,139,63,233,153,153,153,153,153,154}
        ,(vector unsigned char){63,212,228,56,128,232,251,106,63,233,133,47,13,142,192,255}
        ,(vector unsigned char){63,213,45,189,252,76,150,179,63,233,112,228,248,12,184,114}
        ,(vector unsigned char){63,213,119,9,27,51,120,203,63,233,92,187,11,227,119,174}
        ,(vector unsigned char){63,213,192,26,57,251,214,136,63,233,72,176,252,214,233,224}
        ,(vector unsigned char){63,214,8,241,180,41,72,174,63,233,52,198,127,155,44,230}
        ,(vector unsigned char){63,214,81,143,228,103,123,167,63,233,32,251,73,208,226,41}
        ,(vector unsigned char){63,214,153,245,36,140,212,184,63,233,13,79,18,1,144,213}
        ,(vector unsigned char){63,214,226,33,205,157,12,222,63,232,249,193,143,156,24,250}
        ,(vector unsigned char){63,215,42,22,55,203,193,131,63,232,230,82,122,241,55,63}
        ,(vector unsigned char){63,215,113,210,186,126,251,60,63,232,211,1,141,48,24,211}
        ,(vector unsigned char){63,215,185,87,172,81,170,196,63,232,191,206,128,98,255,58}
        ,(vector unsigned char){63,216,0,165,99,22,28,84,63,232,172,185,15,107,243,170}
        ,(vector unsigned char){63,216,71,188,51,216,97,142,63,232,153,192,246,1,137,156}
        ,(vector unsigned char){63,216,142,156,114,224,178,38,63,232,134,229,240,171,176,74}
        ,(vector unsigned char){63,216,213,70,115,181,195,114,63,232,116,39,188,192,146,185}
        ,(vector unsigned char){63,217,27,186,137,31,23,9,63,232,97,134,24,97,134,24}
        ,(vector unsigned char){63,217,97,249,5,39,64,156,63,232,79,0,194,120,6,20}
        ,(vector unsigned char){63,217,168,2,57,30,35,47,63,232,60,151,122,178,190,221}
        ,(vector unsigned char){63,217,237,214,117,155,37,224,63,232,42,74,1,130,164,160}
        ,(vector unsigned char){63,218,51,118,10,127,96,81,63,232,24,24,24,24,24,24}
        ,(vector unsigned char){63,218,120,225,70,247,190,244,63,232,6,1,128,96,24,6}
        ,(vector unsigned char){63,218,190,24,121,127,31,73,63,231,244,5,253,1,127,64}
        ,(vector unsigned char){63,219,3,27,239,224,100,52,63,231,226,37,81,90,79,29}
        ,(vector unsigned char){63,219,71,235,247,56,130,161,63,231,208,95,65,125,5,244}
        ,(vector unsigned char){63,219,140,136,219,248,134,122,63,231,190,179,146,46,1,124}
        ,(vector unsigned char){63,219,208,242,233,231,144,49,63,231,173,34,8,224,236,195}
        ,(vector unsigned char){63,220,21,42,108,36,202,230,63,231,155,170,107,182,57,139}
        ,(vector unsigned char){63,220,89,47,173,41,91,86,63,231,138,76,129,120,164,200}
        ,(vector unsigned char){63,220,157,2,246,202,71,180,63,231,121,8,17,154,198,13}
        ,(vector unsigned char){63,220,224,164,146,58,88,125,63,231,103,220,228,52,169,177}
        ,(vector unsigned char){63,221,36,20,200,11,242,125,63,231,86,202,194,1,117,109}
        ,(vector unsigned char){63,221,103,83,224,50,234,15,63,231,69,209,116,93,23,70}
        ,(vector unsigned char){63,221,170,98,34,6,79,185,63,231,52,240,197,65,254,141}
        ,(vector unsigned char){63,221,237,63,212,66,54,76,63,231,36,40,127,70,222,188}
        ,(vector unsigned char){63,222,47,237,61,9,114,152,63,231,19,120,109,156,124,9}
        ,(vector unsigned char){63,222,114,106,161,231,84,210,63,231,2,224,92,11,129,112}
        ,(vector unsigned char){63,222,180,184,71,209,91,206,63,230,242,96,22,242,96,23}
        ,(vector unsigned char){63,222,246,214,115,40,226,32,63,230,225,247,107,67,55,199}
        ,(vector unsigned char){63,223,56,197,103,188,197,65,63,230,209,166,38,129,200,97}
        ,(vector unsigned char){63,223,122,133,104,203,6,207,63,230,193,108,22,193,108,23}
        ,(vector unsigned char){63,223,188,22,185,2,104,10,63,230,177,73,10,163,26,61}
        ,(vector unsigned char){63,223,253,121,154,131,255,155,63,230,161,60,209,83,114,144}
        ,(vector unsigned char){63,224,31,87,39,114,100,224,63,230,145,71,58,136,208,192}
        ,(vector unsigned char){63,224,63,218,139,151,153,127,63,230,129,104,22,129,104,23}
        ,(vector unsigned char){63,224,96,71,25,242,78,178,63,230,113,159,54,1,103,26}
        ,(vector unsigned char){63,224,128,156,242,127,112,61,63,230,97,236,106,81,34,249}
        ,(vector unsigned char){63,224,160,220,52,248,225,252,63,230,82,79,133,59,74,163}
        ,(vector unsigned char){63,224,193,5,0,214,58,166,63,230,66,200,89,11,33,100}
        ,(vector unsigned char){63,224,225,23,117,77,124,17,63,230,51,86,184,138,192,222}
        ,(vector unsigned char){63,225,1,19,177,83,200,234,63,230,35,250,119,1,98,64}
        ,(vector unsigned char){63,225,32,249,211,158,24,7,63,230,20,179,104,49,174,148}
        ,(vector unsigned char){63,225,64,201,250,161,229,68,63,230,5,129,96,88,22,6}
        ,(vector unsigned char){63,225,96,132,68,149,224,6,63,229,246,100,52,41,45,252}
        ,(vector unsigned char){63,225,128,40,207,114,151,106,63,229,231,91,184,208,21,231}
        ,(vector unsigned char){63,225,159,183,184,243,36,33,63,229,216,103,195,236,226,165}
        ,(vector unsigned char){63,225,191,49,30,149,208,14,63,229,201,136,43,147,16,87}
        ,(vector unsigned char){63,225,222,149,29,156,187,166,63,229,186,188,198,71,250,145}
        ,(vector unsigned char){63,225,253,227,211,14,129,38,63,229,172,5,107,1,90,192}
        ,(vector unsigned char){63,226,29,29,91,182,213,154,63,229,157,97,241,35,204,170}
        ,(vector unsigned char){63,226,60,65,212,39,39,200,63,229,142,210,48,129,88,237}
        ,(vector unsigned char){63,226,91,81,88,183,61,4,63,229,128,86,1,88,5,96}
        ,(vector unsigned char){63,226,122,76,5,133,203,248,63,229,113,237,60,80,107,58}
        ,(vector unsigned char){63,226,153,49,246,121,21,96,63,229,99,151,186,124,82,226}
        ,(vector unsigned char){63,226,214,192,19,80,19,128,63,229,71,37,230,187,130,254}
        ,(vector unsigned char){63,226,245,104,117,235,63,38,63,229,57,9,72,244,15,235}
        ,(vector unsigned char){63,227,19,252,138,27,54,242,63,229,42,255,86,168,5,75}
        ,(vector unsigned char){63,227,50,124,106,180,156,167,63,229,29,7,234,226,248,21}
        ,(vector unsigned char){63,227,80,232,50,87,7,217,63,229,15,34,225,17,196,197}
        ,(vector unsigned char){63,227,111,63,251,109,145,98,63,229,1,80,21,1,80,21}
        ,(vector unsigned char){63,227,141,131,224,47,93,9,63,228,243,143,98,221,76,155}
        ,(vector unsigned char){63,227,171,179,250,160,33,103,63,228,229,224,167,47,5,57}
        ,(vector unsigned char){63,227,201,208,100,144,174,18,63,228,216,67,190,220,44,76}
        ,(vector unsigned char){63,227,231,217,55,159,112,22,63,228,202,184,135,37,175,110}
        ,(vector unsigned char){63,228,5,206,141,56,244,188,63,228,189,62,221,166,143,225}
        ,(vector unsigned char){63,228,35,176,126,152,106,169,63,228,175,214,160,82,191,91}
        ,(vector unsigned char){63,228,65,127,36,200,33,101,63,228,162,127,173,118,1,74}
        ,(vector unsigned char){63,228,95,58,152,162,7,57,63,228,149,57,227,178,208,103}
        ,(vector unsigned char){63,228,124,226,242,208,37,135,63,228,136,5,34,1,72,128}
        ,(vector unsigned char){63,228,154,120,75,205,27,139,63,228,122,225,71,174,20,123}
        ,(vector unsigned char){63,228,183,250,187,228,151,149,63,228,109,206,52,89,96,102}
        ,(vector unsigned char){63,228,213,106,91,51,206,196,63,228,96,203,199,245,207,154}
        ,(vector unsigned char){63,228,242,199,65,169,243,62,63,228,83,217,226,199,118,202}
        ,(vector unsigned char){63,229,16,17,135,8,168,249,63,228,70,248,101,98,217,251}
        ,(vector unsigned char){63,229,45,73,66,228,121,9,63,228,58,39,48,171,238,77}
        ,(vector unsigned char){63,229,74,110,140,165,67,142,63,228,45,102,37,213,31,135}
        ,(vector unsigned char){63,229,103,129,123,134,176,44,63,228,32,181,38,94,89,81}
        ,(vector unsigned char){63,229,132,130,38,152,157,52,63,228,20,20,20,20,20,20}
        ,(vector unsigned char){63,229,161,112,164,191,141,92,63,228,7,130,209,14,101,102}
        ,(vector unsigned char){63,229,190,77,12,181,20,53,63,227,251,1,63,176,19,251}
        ,(vector unsigned char){63,229,219,23,117,8,65,60,63,227,238,143,66,165,175,7}
        ,(vector unsigned char){63,229,247,207,244,30,9,175,63,227,226,44,188,228,169,2}
        ,(vector unsigned char){63,230,20,118,160,49,177,9,63,227,213,217,145,170,117,198}
        ,(vector unsigned char){63,230,49,11,143,85,48,72,63,227,201,149,164,123,171,231}
        ,(vector unsigned char){63,230,77,142,215,113,155,240,63,227,189,96,217,35,41,85}
        ,(vector unsigned char){63,230,106,0,142,71,136,204,63,227,177,59,19,177,59,20}
        ,(vector unsigned char){63,230,134,96,201,111,111,135,63,227,165,36,56,122,200,34}
        ,(vector unsigned char){63,230,162,175,158,90,15,10,63,227,153,28,44,24,127,99}
        ,(vector unsigned char){63,230,190,237,34,80,205,174,63,227,141,34,211,102,8,142}
        ,(vector unsigned char){63,230,219,25,106,118,25,74,63,227,129,56,19,129,56,20}
        ,(vector unsigned char){63,230,247,52,139,197,198,24,63,227,117,91,209,201,69,238}
        ,(vector unsigned char){63,231,19,62,155,21,108,124,63,227,105,141,243,222,7,72}
        ,(vector unsigned char){63,231,47,55,173,20,197,176,63,227,93,206,95,159,42,248}
        ,(vector unsigned char){63,231,75,31,214,78,7,84,63,227,82,28,251,43,120,193}
        ,(vector unsigned char){63,231,102,247,43,38,61,238,63,227,70,121,172,224,19,70}
        ,(vector unsigned char){63,231,130,189,191,221,166,87,63,227,58,228,91,87,188,178}
        ,(vector unsigned char){63,231,158,115,168,144,6,32,63,227,47,92,237,106,29,250}
        ,(vector unsigned char){63,231,186,24,249,53,2,228,63,227,35,227,74,43,16,191}
        ,(vector unsigned char){63,231,213,173,197,160,120,164,63,227,24,119,88,233,235,182}
        ,(vector unsigned char){63,231,241,50,33,130,207,22,63,227,13,25,1,48,209,144}
        ,(vector unsigned char){63,232,12,166,32,105,77,249,63,227,1,200,42,196,2,96}
        ,(vector unsigned char){63,232,40,9,213,190,112,115,63,226,246,132,189,161,47,104}
        ,(vector unsigned char){63,232,67,93,84,202,55,116,63,226,235,78,161,254,209,75}
        ,(vector unsigned char){63,232,94,160,176,178,123,38,63,226,224,37,192,75,128,151}
        ,(vector unsigned char){63,232,121,211,252,123,59,113,63,226,213,10,1,45,80,160}
        ,(vector unsigned char){63,232,148,247,75,6,239,139,63,226,201,251,77,129,44,160}
        ,(vector unsigned char){63,232,176,10,175,22,212,169,63,226,190,249,142,90,55,17}
        ,(vector unsigned char){63,232,203,14,59,75,59,190,63,226,180,4,173,1,43,64}
        ,(vector unsigned char){63,232,230,2,2,35,214,97,63,226,169,28,146,243,193,5}
        ,(vector unsigned char){63,233,0,230,22,0,2,205,63,226,158,65,41,228,18,158}
        ,(vector unsigned char){63,233,27,186,137,31,23,9,63,226,147,114,91,184,4,165}
        ,(vector unsigned char){63,233,54,127,109,160,171,47,63,226,136,176,18,136,176,19}
        ,(vector unsigned char){63,233,81,52,213,132,226,227,63,226,125,250,56,161,206,77}
        ,(vector unsigned char){63,233,107,218,210,172,181,246,63,226,115,80,184,129,39,53}
        ,(vector unsigned char){63,233,134,113,118,218,56,47,63,226,104,179,124,214,1,39}
        ,(vector unsigned char){63,233,160,248,211,176,224,80,63,226,94,34,112,128,146,241}
        ,(vector unsigned char){63,233,187,112,250,181,206,77,63,226,83,157,126,145,119,178}
        ,(vector unsigned char){63,233,213,217,253,80,16,179,63,226,73,36,146,73,36,146}
        ,(vector unsigned char){63,233,240,51,236,200,233,86,63,226,62,183,151,23,96,91}
        ,(vector unsigned char){63,234,10,126,218,76,17,45,63,226,52,86,120,154,188,223}
        ,(vector unsigned char){63,234,36,186,214,231,251,119,63,226,42,1,34,160,18,42}
        ,(vector unsigned char){63,234,62,231,243,142,24,31,63,226,31,183,129,33,251,120}
        ,(vector unsigned char){63,234,89,6,65,19,21,100,63,226,21,121,128,72,85,230}
        ,(vector unsigned char){63,234,115,21,208,47,32,200,63,226,11,71,12,103,192,217}
        ,(vector unsigned char){63,234,141,22,177,126,39,69,63,226,1,32,18,1,32,18}
        ,(vector unsigned char){63,234,167,8,245,128,20,211,63,225,247,4,125,193,31,112}
        ,(vector unsigned char){63,234,192,236,172,153,19,59,63,225,236,244,60,127,184,76}
        ,(vector unsigned char){63,234,218,193,231,17,200,51,63,225,226,239,59,63,184,116}
        ,(vector unsigned char){63,234,244,136,181,23,146,214,63,225,216,245,103,46,74,189}
        ,(vector unsigned char){63,235,14,65,38,188,200,108,63,225,207,6,173,162,129,29}
        ,(vector unsigned char){63,235,39,235,75,248,240,138,63,225,197,34,252,28,224,89}
        ,(vector unsigned char){63,235,65,135,52,169,0,140,63,225,187,74,64,70,237,41}
        ,(vector unsigned char){63,235,91,20,240,143,150,102,63,225,177,124,103,242,186,227}
        ,(vector unsigned char){63,235,116,148,143,85,50,218,63,225,167,185,97,26,123,150}
        ,(vector unsigned char){63,235,142,6,32,136,115,9,63,225,158,1,25,224,17,158}
        ,(vector unsigned char){63,235,167,105,179,158,73,100,63,225,148,83,128,140,162,156}
        ,(vector unsigned char){63,235,192,191,87,242,54,6,63,225,138,176,131,144,43,219}
        ,(vector unsigned char){63,235,218,7,28,198,126,110,63,225,129,24,17,129,24,18}
        ,(vector unsigned char){63,235,243,65,17,68,100,167,63,225,119,138,25,27,214,132}
        ,(vector unsigned char){63,236,12,109,68,124,93,211,63,225,110,6,137,66,115,121}
        ,(vector unsigned char){63,236,37,139,197,102,72,41,63,225,100,141,80,252,50,1}
        ,(vector unsigned char){63,236,62,156,162,225,160,85,63,225,91,30,95,117,39,13}
        ,(vector unsigned char){63,236,87,159,235,181,182,88,63,225,81,185,163,253,213,201}
        ,(vector unsigned char){63,236,112,149,174,145,225,199,63,225,72,95,14,10,205,59}
        ,(vector unsigned char){63,236,137,125,250,13,181,142,63,225,63,14,141,52,71,36}
        ,(vector unsigned char){63,236,162,88,220,169,51,22,63,225,53,200,17,53,200,17}
        ,(vector unsigned char){63,236,187,38,100,204,252,246,63,225,44,139,137,237,192,172}
        ,(vector unsigned char){63,236,211,230,160,202,137,7,63,225,35,88,231,93,48,51}
        ,(vector unsigned char){63,236,236,153,158,220,82,3,63,225,26,48,25,167,72,38}
        ,(vector unsigned char){63,237,5,63,109,38,8,150,63,225,17,17,17,17,17,17}
        ,(vector unsigned char){63,237,29,216,25,180,195,241,63,225,7,251,190,1,16,128}
        ,(vector unsigned char){63,237,54,99,178,127,49,213,63,224,254,240,16,254,240,17}
        ,(vector unsigned char){63,237,78,226,69,101,198,43,63,224,245,237,250,179,37,162}
        ,(vector unsigned char){63,237,103,83,224,50,234,15,63,224,236,245,107,230,156,144}
        ,(vector unsigned char){63,237,127,184,144,155,42,108,63,224,228,6,85,130,96,17}
        ,(vector unsigned char){63,237,152,16,100,61,102,21,63,224,219,32,168,143,70,150}
        ,(vector unsigned char){63,237,176,91,104,162,251,101,63,224,210,68,86,53,158,58}
        ,(vector unsigned char){63,237,200,153,171,63,245,108,63,224,201,113,79,188,218,59}
        ,(vector unsigned char){63,237,224,203,57,115,56,164,63,224,192,167,134,139,65,113}
        ,(vector unsigned char){63,237,248,240,32,134,175,44,63,224,183,230,236,37,157,200}
        ,(vector unsigned char){63,238,17,8,109,175,116,150,63,224,175,47,114,46,236,181}
        ,(vector unsigned char){63,238,41,20,46,14,1,64,63,224,166,129,10,104,16,167}
        ,(vector unsigned char){63,238,65,19,110,174,85,61,63,224,157,219,166,175,131,96}
        ,(vector unsigned char){63,238,89,6,60,136,34,206,63,224,149,63,57,1,9,84}
        ,(vector unsigned char){63,238,112,236,164,126,248,111,63,224,140,171,179,117,101,226}
        ,(vector unsigned char){63,238,136,198,179,98,106,115,63,224,132,33,8,66,16,132}
        ,(vector unsigned char){63,238,160,148,117,238,60,58,63,224,123,159,41,184,234,226}
        ,(vector unsigned char){63,238,184,85,248,202,136,251,63,224,115,38,10,71,247,198}
        ,(vector unsigned char){63,238,208,11,72,139,236,35,63,224,106,181,156,121,18,251}
        ,(vector unsigned char){63,238,231,180,113,179,169,80,63,224,98,77,210,241,169,252}
        ,(vector unsigned char){63,238,255,81,128,175,211,228,63,224,89,238,160,114,117,134}
        ,(vector unsigned char){63,239,22,226,129,219,118,48,63,224,81,151,247,215,52,4}
        ,(vector unsigned char){63,239,46,103,129,126,184,69,63,224,73,73,204,22,100,197}
        ,(vector unsigned char){63,239,69,224,139,207,6,85,63,224,65,4,16,65,4,16}
        ,(vector unsigned char){63,239,93,77,172,239,54,190,63,224,56,198,183,130,71,252}
        ,(vector unsigned char){63,239,116,174,240,239,175,174,63,224,48,145,181,31,94,26}
        ,(vector unsigned char){63,239,140,4,99,206,140,105,63,224,40,100,252,119,41,233}
        ,(vector unsigned char){63,239,163,78,17,119,194,51,63,224,32,64,129,2,4,8}
        ,(vector unsigned char){63,239,186,140,5,197,68,223,63,224,24,36,54,81,122,55}
        ,(vector unsigned char){63,239,209,190,76,127,42,249,63,224,16,16,16,16,16,16}
        ,(vector unsigned char){63,239,232,228,241,91,209,160,63,224,8,4,2,1,0,128}
        ,(vector unsigned char){63,240,0,0,0,0,0,0,63,224,0,0,0,0,0,0}
        };
    vector unsigned char var3041;
    vector unsigned char var3042;
    vector unsigned char var3043;
    vector unsigned char var3044;
    vector unsigned char var3045;
    vector unsigned char var3046;
    vector unsigned char var3047;
    vector unsigned char var3048;
    vector unsigned char var3049;
    vector unsigned char var3050;
    vector unsigned char var3052;
    vector unsigned char var3053;
    vector unsigned char var3054;
    vector unsigned char var3056;
    vector unsigned char var3057;
    vector unsigned char var3058;
    vector unsigned char var3061;
    vector unsigned char var3062;
    vector unsigned char var3063;
    vector unsigned char var3064;
    vector unsigned char var3065;
    vector unsigned char var3067;
    vector unsigned char var3068;
    vector unsigned char var3069;
    vector unsigned char var3070;
    vector unsigned char var3071;
    vector unsigned char var3072;
    vector unsigned char var3073;
    vector unsigned char var3074;
    vector unsigned char var3075;
    vector unsigned char var3076;
    vector unsigned char var3077;
    vector unsigned char var3078;
    vector unsigned char var3079;
    vector unsigned char var3080;
    vector unsigned char var3081;
    vector unsigned char var3082;
    vector unsigned char var3083;
    vector unsigned char var3084;
    vector unsigned char var3085;
    vector unsigned char var3086;
    vector unsigned char var3087;
    vector unsigned char var3088;
    vector unsigned char var3089;
    vector unsigned char var3090;
    vector unsigned char var3091;
    vector unsigned char var3092;
    vector unsigned char var3093;
    vector unsigned char var3094;
    vector unsigned char var3096;
    vector unsigned char var3097;
    vector unsigned char var3098;
    vector unsigned char var3099;
    vector unsigned char var3101;
    vector unsigned char var3102;
    vector unsigned char var3104;
    vector unsigned char var3105;
    vector unsigned char var3106;
    vector unsigned char var3107;
    vector unsigned char var3108;
    vector unsigned char var3109;
    vector unsigned char var3110;
    vector unsigned char var3111;
    vector unsigned char var3112;
    vector unsigned char var3113;
    vector unsigned char var3114;
    vector unsigned char var3115;
    vector unsigned char var3116;
    vector unsigned char var3117;
    vector double var3118;
    var3006=(vector unsigned char){128,0,0,0,0,0,0,1,128,0,0,0,0,0,0,1};
    var3009=(vector unsigned char){0,1,2,3,16,17,18,19,8,9,10,11,24,25,26,27};
    var3011=(vector unsigned char){0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    var3016=(vector unsigned char){16,0,0,0,20,4,0,0,24,8,0,0,28,12,0,0};
    var3018=(vector unsigned char){79,240,0,0,0,0,0,0,79,240,0,0,0,0,0,0};
    var3020=(vector unsigned char){0,16,0,0,0,0,0,0,0,16,0,0,0,0,0,0};
    var3029=(vector unsigned char){127,240,0,0,127,240,0,0,127,240,0,0,127,240,0,0};
    var3031=(vector unsigned char){0,1,16,16,4,5,20,20,8,9,24,24,12,13,28,28};
    var3033=(vector unsigned char){0,8,0,0,0,8,0,0,0,8,0,0,0,8,0,0};
    var3036=(vector unsigned char){127,247,255,255,127,247,255,255,127,247,255,255,127,247,255,255};
    var3038=(vector unsigned char){0,1,2,3,128,128,128,128,8,9,10,11,128,128,128,128};
    var3042=(vector unsigned char){128,128,128,1,128,128,128,5,128,128,128,9,128,128,128,13};
    var3048=(vector unsigned char){8,9,10,11,12,13,14,15,24,25,26,27,28,29,30,31};
    var3050=(vector unsigned char){63,240,0,0,63,240,0,0,63,240,0,0,63,240,0,0};
    var3053=(vector unsigned char){16,17,18,19,4,5,6,7,24,25,26,27,12,13,14,15};
    var3056=(vector unsigned char){3,255,0,0,3,255,0,0,3,255,0,0,3,255,0,0};
    var3057=(vector unsigned char){16,17,1,19,20,21,5,23,24,25,9,27,28,29,13,31};
    var3062=(vector unsigned char){128,128,2,128,128,128,6,128,128,128,10,128,128,128,14,128};
    var3070=(vector unsigned char){63,210,79,219,236,237,146,47,63,210,138,182,142,167,246,240};
    var3071=(vector unsigned char){0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7};
    var3072=(vector unsigned char){1,1,1,1,1,1,1,1,9,9,9,9,9,9,9,9};
    var3074=(vector unsigned char){8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8};
    var3077=(vector unsigned char){191,215,21,35,73,169,220,21,191,215,21,62,242,149,5,214};
    var3080=(vector unsigned char){63,222,199,9,206,139,7,124,63,222,199,9,221,188,101,203};
    var3083=(vector unsigned char){191,231,21,71,101,42,147,236,191,231,21,71,101,43,118,234};
    var3086=(vector unsigned char){63,247,21,71,101,43,130,251,63,247,21,71,101,43,130,254};
    var3089=(vector unsigned char){128,192,0,1,128,192,4,5,128,192,8,9,128,192,12,13};
    var3092=(vector unsigned char){65,48,0,0,0,0,0,0,65,48,0,0,0,0,0,0};
    var3093=(vector unsigned char){16,17,1,2,16,17,5,6,16,17,9,10,16,17,13,14};
    var3097=(vector unsigned char){65,48,243,255,0,0,0,0,65,48,243,255,0,0,0,0};
    var3099=(vector unsigned char){64,112,0,0,64,112,0,0,64,112,0,0,64,112,0,0};
    var3106=(vector unsigned char){0,1,2,3,4,5,6,7,16,17,18,19,20,21,22,23};
    var3110=(vector unsigned char){63,211,68,19,80,159,121,255,63,211,68,19,80,159,121,255};
    var3111=(vector unsigned char){188,73,220,29,169,148,253,33,188,73,220,29,169,148,253,33};
    var3114=(vector unsigned char){0,255,0,0,0,255,0,0,0,255,0,0,0,255,0,0};
    var3116=(vector unsigned char){0,1,2,3,0,1,2,3,8,9,10,11,8,9,10,11};
    var3005=(vector unsigned char)var3005In;
    var3021=(vector unsigned char)si_dfcgt((qword)var3020,(qword)var3005);
    var3019=(vector unsigned char)si_dfm((qword)var3005,(qword)var3018);
    var3022=(vector unsigned char)si_selb((qword)var3005,(qword)var3019,(qword)var3021);
    var3073=(vector unsigned char)si_shufb((qword)var3022,(qword)var3022,(qword)var3072);
    var3075=(vector unsigned char)si_selb((qword)var3071,(qword)var3073,(qword)var3074);
    var3087=(vector unsigned char)si_shufb((qword)var3086,(qword)var3086,(qword)var3075);
    var3084=(vector unsigned char)si_shufb((qword)var3083,(qword)var3083,(qword)var3075);
    var3081=(vector unsigned char)si_shufb((qword)var3080,(qword)var3080,(qword)var3075);
    var3078=(vector unsigned char)si_shufb((qword)var3077,(qword)var3077,(qword)var3075);
    var3076=(vector unsigned char)si_shufb((qword)var3070,(qword)var3070,(qword)var3075);
    var3012=(vector unsigned char)si_dfceq((qword)var3005,(qword)var3011);
    var3101=(vector unsigned char)si_shufb((qword)var3021,(qword)var3021,(qword)var3009);
    var3102=(vector unsigned char)si_and((qword)var3099,(qword)var3101);
    var3104=(vector unsigned char)si_shufb((qword)var3102,(qword)var3102,(qword)var3038);
    var3027=(vector unsigned char)si_shufb((qword)var3022,(qword)var3022,(qword)var3009);
    var3090=(vector unsigned char)si_shufb((qword)var3027,(qword)var3027,(qword)var3089);
    var3091=(vector unsigned char)si_rotqbii((qword)var3090,(int)4);
    var3094=(vector unsigned char)si_shufb((qword)var3091,(qword)var3092,(qword)var3093);
    var3096=(vector unsigned char)si_shufb((qword)var3094,(qword)var3094,(qword)var3038);
    var3098=(vector unsigned char)si_dfs((qword)var3096,(qword)var3097);
    var3105=(vector unsigned char)si_dfs((qword)var3098,(qword)var3104);
    var3052=(vector unsigned char)si_selb((qword)var3027,(qword)var3050,(qword)var3029);
    var3054=(vector unsigned char)si_shufb((qword)var3022,(qword)var3052,(qword)var3053);
    var3041=(vector unsigned char)si_rotqbii((qword)var3027,(int)4);
    var3058=(vector unsigned char)si_shufb((qword)var3041,(qword)var3056,(qword)var3057);
    var3043=(vector unsigned char)si_shufb((qword)var3041,(qword)var3041,(qword)var3042);
    var3061=(vector unsigned char)si_rotqbii((qword)var3043,(int)1);
    var3063=(vector unsigned char)si_shufb((qword)var3061,(qword)var3061,(qword)var3062);
    var3064=(vector unsigned char)si_a((qword)var3058,(qword)var3063);
    var3065=(vector unsigned char)si_rotqbii((qword)var3064,(int)4);
    var3067=(vector unsigned char)si_shufb((qword)var3065,(qword)var3065,(qword)var3038);
    var3068=(vector unsigned char)si_dfs((qword)var3054,(qword)var3067);
    var3044=(vector unsigned char)si_rotqbii((qword)var3043,(int)4);
    var3046=(vector unsigned char)si_rotqbyi((qword)var3044,(int)8);
    var3047=*(vector unsigned char*)(var3040.c+spu_extract((vector signed int)var3046,0));
    var3045=*(vector unsigned char*)(var3040.c+spu_extract((vector signed int)var3044,0));
    var3107=(vector unsigned char)si_shufb((qword)var3045,(qword)var3047,(qword)var3106);
    var3108=(vector unsigned char)si_dfa((qword)var3105,(qword)var3107);
    var3049=(vector unsigned char)si_shufb((qword)var3045,(qword)var3047,(qword)var3048);
    var3069=(vector unsigned char)si_dfm((qword)var3049,(qword)var3068);
    var3079=(vector unsigned char)si_dfma((qword)var3069,(qword)var3076,(qword)var3078);
    var3082=(vector unsigned char)si_dfma((qword)var3069,(qword)var3079,(qword)var3081);
    var3085=(vector unsigned char)si_dfma((qword)var3069,(qword)var3082,(qword)var3084);
    var3088=(vector unsigned char)si_dfma((qword)var3069,(qword)var3085,(qword)var3087);
    var3109=(vector unsigned char)si_dfma((qword)var3069,(qword)var3088,(qword)var3108);
    var3112=(vector unsigned char)si_dfm((qword)var3109,(qword)var3111);
    var3113=(vector unsigned char)si_dfma((qword)var3109,(qword)var3110,(qword)var3112);
    var3015=(vector unsigned char)si_shufb((qword)var3012,(qword)var3012,(qword)var3009);
    var3007=(vector unsigned char)si_dfcgt((qword)var3005,(qword)var3006);
    var3010=(vector unsigned char)si_shufb((qword)var3007,(qword)var3007,(qword)var3009);
    var3028=(vector unsigned char)si_and((qword)var3027,(qword)var3010);
    var3030=(vector unsigned char)si_ceq((qword)var3028,(qword)var3029);
    var3017=(vector unsigned char)si_shufb((qword)var3010,(qword)var3015,(qword)var3016);
    var3032=(vector unsigned char)si_shufb((qword)var3017,(qword)var3030,(qword)var3031);
    var3115=(vector unsigned char)si_ceq((qword)var3032,(qword)var3114);
    var3117=(vector unsigned char)si_shufb((qword)var3115,(qword)var3115,(qword)var3116);
    var3034=(vector unsigned char)si_xor((qword)var3032,(qword)var3033);
    var3037=(vector unsigned char)si_selb((qword)var3034,(qword)var3029,(qword)var3036);
    var3039=(vector unsigned char)si_shufb((qword)var3037,(qword)var3037,(qword)var3038);
    var3118=(vector double)si_selb((qword)var3039,(qword)var3113,(qword)var3117);
    return var3118;}

#endif /* MASS_LOG10_H */
