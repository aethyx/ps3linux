/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2008.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/
#ifndef MASS_DIV_H
#define MASS_DIV_H
#include <spu_intrinsics.h>
static __inline vector double _divd2(vector double var4073In,vector double var4074In){
    vector unsigned char var4073;
    vector unsigned char var4074;
    vector unsigned char var4075;
    vector unsigned char var4076;
    vector unsigned char var4077;
    vector unsigned char var4078;
    vector unsigned char var4079;
    vector unsigned char var4080;
    vector unsigned char var4081;
    vector unsigned char var4082;
    vector unsigned char var4089;
    vector unsigned char var4090;
    vector unsigned char var4091;
    vector unsigned char var4092;
    vector unsigned char var4093;
    vector unsigned char var4094;
    vector unsigned char var4095;
    vector unsigned char var4096;
    vector unsigned char var4097;
    vector unsigned char var4098;
    vector unsigned char var4099;
    vector unsigned char var4100;
    vector unsigned char var4101;
    vector unsigned char var4102;
    vector unsigned char var4103;
    vector unsigned char var4104;
    vector unsigned char var4105;
    vector unsigned char var4106;
    vector unsigned char var4108;
    vector unsigned char var4109;
    vector unsigned char var4110;
    vector unsigned char var4111;
    vector unsigned char var4112;
    vector unsigned char var4113;
    vector unsigned char var4114;
    vector unsigned char var4115;
    vector unsigned char var4117;
    vector unsigned char var4118;
    vector unsigned char var4119;
    vector unsigned char var4121;
    vector unsigned char var4122;
    vector unsigned char var4123;
    vector unsigned char var4124;
    vector unsigned char var4127;
    vector unsigned char var4129;
    vector unsigned char var4131;
    vector unsigned char var4132;
    vector unsigned char var4133;
    vector unsigned char var4134;
    vector unsigned char var4135;
    vector unsigned char var4136;
    vector unsigned char var4139;
    vector unsigned char var4140;
    vector unsigned char var4141;
    vector unsigned char var4142;
    vector unsigned char var4145;
    vector unsigned char var4146;
    vector unsigned char var4149;
    vector unsigned char var4150;
    vector unsigned char var4151;
    vector unsigned char var4152;
    vector unsigned char var4153;
    vector unsigned char var4154;
    vector unsigned char var4155;
    vector unsigned char var4157;
    vector unsigned char var4158;
    vector unsigned char var4159;
    vector unsigned char var4160;
    vector unsigned char var4161;
    vector unsigned char var4162;
    vector double var4163;
    var4075=(vector unsigned char){75,16,0,0,0,0,0,0,75,16,0,0,0,0,0,0};
    var4077=(vector unsigned char){0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
    var4078=(vector unsigned char){8,0,0,0,0,0,0,0,8,0,0,0,0,0,0,0};
    var4080=(vector unsigned char){16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16};
    var4089=(vector unsigned char){0,1,2,3,16,17,18,19,8,9,10,11,24,25,26,27};
    var4091=(vector unsigned char){128,0,0,0,128,0,0,0,128,0,0,0,128,0,0,0};
    var4093=(vector unsigned char){0,128,128,128,4,128,128,128,8,128,128,128,12,128,128,128};
    var4095=(vector unsigned char){128,1,2,3,128,5,6,7,128,9,10,11,128,13,14,15};
    var4098=(vector unsigned char){98,0,0,0,98,0,0,0,98,0,0,0,98,0,0,0};
    var4102=(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var4109=(vector unsigned char){0,1,2,3,128,128,128,128,8,9,10,11,128,128,128,128};
    var4111=(vector unsigned char){60,48,0,0,0,0,0,0,60,48,0,0,0,0,0,0};
    var4113=(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0};
    var4123=(vector unsigned char){127,240,0,0,127,240,0,0,127,240,0,0,127,240,0,0};
    var4141=(vector unsigned char){0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    var4152=(vector unsigned char){0,17,18,19,4,21,22,23,8,25,26,27,12,29,30,31};
    var4154=(vector unsigned char){128,8,0,0,128,8,0,0,128,8,0,0,128,8,0,0};
    var4161=(vector unsigned char){0,1,2,3,0,1,2,3,8,9,10,11,8,9,10,11};
    var4073=(vector unsigned char)var4074In;
    var4074=(vector unsigned char)var4073In;
    var4146=(vector unsigned char)si_dfceq((qword)var4074,(qword)var4141);
    var4142=(vector unsigned char)si_dfceq((qword)var4073,(qword)var4141);
    var4136=(vector unsigned char)si_dftsv((qword)var4074,(int)48);
    var4124=(vector unsigned char)si_dftsv((qword)var4073,(int)48);
    var4149=(vector unsigned char)si_shufb((qword)var4146,(qword)var4146,(qword)var4089);
    var4145=(vector unsigned char)si_shufb((qword)var4142,(qword)var4142,(qword)var4089);
    var4150=(vector unsigned char)si_and((qword)var4145,(qword)var4149);
    var4139=(vector unsigned char)si_shufb((qword)var4136,(qword)var4136,(qword)var4089);
    var4129=(vector unsigned char)si_shufb((qword)var4074,(qword)var4074,(qword)var4089);
    var4131=(vector unsigned char)si_and((qword)var4129,(qword)var4123);
    var4132=(vector unsigned char)si_ceq((qword)var4131,(qword)var4123);
    var4158=(vector unsigned char)si_andc((qword)var4145,(qword)var4132);
    var4127=(vector unsigned char)si_shufb((qword)var4124,(qword)var4124,(qword)var4089);
    var4140=(vector unsigned char)si_and((qword)var4127,(qword)var4139);
    var4151=(vector unsigned char)si_or((qword)var4140,(qword)var4150);
    var4159=(vector unsigned char)si_or((qword)var4158,(qword)var4151);
    var4133=(vector unsigned char)si_andc((qword)var4127,(qword)var4132);
    var4160=(vector unsigned char)si_or((qword)var4159,(qword)var4133);
    var4162=(vector unsigned char)si_shufb((qword)var4160,(qword)var4160,(qword)var4161);
    var4134=(vector unsigned char)si_andc((qword)var4123,(qword)var4133);
    var4079=(vector unsigned char)si_dfcmgt((qword)var4078,(qword)var4073);
    var4081=(vector unsigned char)si_selb((qword)var4077,(qword)var4079,(qword)var4080);
    var4076=(vector unsigned char)si_dfm((qword)var4073,(qword)var4075);
    var4082=(vector unsigned char)si_shufb((qword)var4073,(qword)var4076,(qword)var4081);
    var4090=(vector unsigned char)si_shufb((qword)var4082,(qword)var4082,(qword)var4089);
    var4135=(vector unsigned char)si_xor((qword)var4090,(qword)var4129);
    var4153=(vector unsigned char)si_shufb((qword)var4135,(qword)var4151,(qword)var4152);
    var4155=(vector unsigned char)si_selb((qword)var4134,(qword)var4153,(qword)var4154);
    var4157=(vector unsigned char)si_shufb((qword)var4155,(qword)var4155,(qword)var4109);
    var4092=(vector unsigned char)si_andc((qword)var4090,(qword)var4091);
    var4096=(vector unsigned char)si_shufb((qword)var4092,(qword)var4092,(qword)var4095);
    var4097=(vector unsigned char)si_rotqbii((qword)var4096,(int)3);
    var4099=(vector unsigned char)si_a((qword)var4097,(qword)var4098);
    var4100=(vector unsigned char)si_frest((qword)var4099);
    var4101=(vector unsigned char)si_fi((qword)var4099,(qword)var4100);
    var4103=(vector unsigned char)si_fnms((qword)var4099,(qword)var4101,(qword)var4102);
    var4104=(vector unsigned char)si_fma((qword)var4103,(qword)var4101,(qword)var4101);
    var4105=(vector unsigned char)si_rotmi((qword)var4104,(int)-3);
    var4094=(vector unsigned char)si_shufb((qword)var4092,(qword)var4092,(qword)var4093);
    var4106=(vector unsigned char)si_sf((qword)var4094,(qword)var4105);
    var4108=(vector unsigned char)si_selb((qword)var4106,(qword)var4090,(qword)var4091);
    var4110=(vector unsigned char)si_shufb((qword)var4108,(qword)var4108,(qword)var4109);
    var4112=(vector unsigned char)si_dfm((qword)var4110,(qword)var4111);
    var4114=(vector unsigned char)si_dfnms((qword)var4082,(qword)var4112,(qword)var4113);
    var4115=(vector unsigned char)si_dfma((qword)var4114,(qword)var4112,(qword)var4112);
    var4117=(vector unsigned char)si_dfnms((qword)var4082,(qword)var4115,(qword)var4113);
    var4118=(vector unsigned char)si_dfma((qword)var4117,(qword)var4115,(qword)var4115);
    var4119=(vector unsigned char)si_dfm((qword)var4118,(qword)var4074);
    var4121=(vector unsigned char)si_dfm((qword)var4119,(qword)var4075);
    var4122=(vector unsigned char)si_shufb((qword)var4119,(qword)var4121,(qword)var4081);
    var4163=(vector double)si_selb((qword)var4122,(qword)var4157,(qword)var4162);
    return var4163;}

#endif /* MASS_DIV_H */
