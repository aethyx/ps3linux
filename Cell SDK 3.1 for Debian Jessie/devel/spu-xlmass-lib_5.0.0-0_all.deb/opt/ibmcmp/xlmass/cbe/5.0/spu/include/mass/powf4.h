/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2007.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

#ifndef MASS_POW_H
#define MASS_POW_H 1
#include <spu_intrinsics.h>
static __inline vector float _powf4(vector float var1,vector float var2){
    vector float var10;
    vector float var11;
    vector float var12;
    vector float var13;
    vector float var14;
    vector float var15;
    vector float var16;
    vector float var17;
    vector float var18;
    vector float var19;
    vector float var20;
    vector float var21;
    vector float var22;
    vector float var23;
    vector float var24;
    vector float var25;
    vector float var26;
    vector float var27;
    vector float var28;
    vector float var29;
    vector float var3;
    vector float var30;
    vector float var31;
    vector float var32;
    vector float var33;
    vector float var34;
    vector float var35;
    vector float var36;
    vector float var37;
    vector float var38;
    vector float var39;
    vector float var4;
    vector float var40;
    vector float var41;
    vector float var42;
    vector float var43;
    vector float var44;
    vector float var45;
    vector float var46;
    vector float var47;
    vector float var48;
    vector float var49;
    vector float var5;
    vector float var50;
    vector float var51;
    vector float var52;
    vector float var53;
    vector float var54;
    vector float var55;
    vector float var56;
    vector float var57;
    vector float var58;
    vector float var59;
    vector float var6;
    vector float var60;
    vector float var61;
    vector float var62;
    vector float var63;
    vector float var64;
    vector float var65;
    vector float var66;
    vector float var67;
    vector float var68;
    vector float var69;
    vector float var7;
    vector float var70;
    vector float var71;
    vector float var72;
    vector float var73;
    vector float var74;
    vector float var75;
    vector float var76;
    vector float var77;
    vector float var78;
    vector float var79;
    vector float var8;
    vector float var80;
    vector float var81;
    vector float var82;
    vector float var83;
    vector float var84;
    vector float var85;
    vector float var86;
    vector float var87;
    vector float var9;
    var11=(vector float)(vector unsigned char){0,0,0,0,4,4,4,4,8,8,8,8,12,12,12,12};
    var13=(vector float)(vector unsigned char){7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7};
    var17=(vector float)(vector unsigned char){62,61,61,61,60,60,60,60,99,253,153,66,255,173,115,43};
    var18=(vector float)(vector unsigned char){113,34,63,68,215,253,72,137,21,116,241,0,34,126,116,137};
    var20=(vector float)(vector unsigned char){190,190,190,189,189,189,189,188,180,97,20,203,144,81,28,183};
    var21=(vector float)(vector unsigned char){236,201,174,169,28,156,13,24,181,242,17,200,10,152,208,222};
    var24=(vector float)(vector unsigned char){62,62,62,62,62,61,61,61,246,172,123,61,17,229,183,118};
    var25=(vector float)(vector unsigned char){10,200,248,86,218,115,185,67,223,200,245,142,133,243,37,176};
    var28=(vector float)(vector unsigned char){191,191,190,190,190,190,190,190,56,17,236,195,164,139,113,56};
    var29=(vector float)(vector unsigned char){169,231,94,88,37,221,49,170,213,250,120,202,89,55,200,43};
    var3=(vector float)(vector unsigned char){0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    var32=(vector float)(vector unsigned char){63,63,63,63,63,63,63,63,184,164,147,134,118,99,83,56};
    var33=(vector float)(vector unsigned char){170,37,187,77,56,71,11,170,60,138,99,67,80,172,178,60};
    var37=(vector float)(vector unsigned char){128,128,128,0,128,128,128,4,128,128,128,8,128,128,128,12};
    var4=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var41=(vector float)(vector unsigned char){0,62,62,62,63,63,63,63,0,46,164,235,21,51,78,128};
    var42=(vector float)(vector unsigned char){0,0,211,58,192,80,174,0,0,210,195,160,27,5,208,0};
    var47=(vector float)(vector unsigned char){51,128,0,0,51,128,0,0,51,128,0,0,51,128,0,0};
    var5=(vector float)(vector unsigned char){0,127,255,255,0,127,255,255,0,127,255,255,0,127,255,255};
    var50=(vector float)(vector unsigned char){194,254,0,0,194,254,0,0,194,254,0,0,194,254,0,0};
    var54=(vector float)(vector unsigned char){255,128,0,0,255,128,0,0,255,128,0,0,255,128,0,0};
    var57=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var58=(vector float)(vector unsigned char){0,15,255,255,0,15,255,255,0,15,255,255,0,15,255,255};
    var60=(vector float)(vector unsigned char){61,61,61,61,61,61,61,61,109,129,141,153,167,183,199,217};
    var61=(vector float)(vector unsigned char){113,119,47,246,229,24,170,188,149,147,83,147,230,23,97,160};
    var66=(vector float)(vector unsigned char){61,61,61,61,61,61,61,61,135,147,161,175,191,208,227,248};
    var67=(vector float)(vector unsigned char){107,173,10,158,131,216,191,92,159,79,252,88,108,200,194,179};
    var7=(vector float)(vector unsigned char){63,63,63,63,63,63,63,64,128,144,160,176,192,208,224,0};
    var70=(vector float)(vector unsigned char){62,62,62,63,63,63,63,63,198,216,235,0,12,24,38,53};
    var71=(vector float)(vector unsigned char){36,19,161,122,27,201,157,178,110,98,218,185,150,226,253,130};
    var74=(vector float)(vector unsigned char){62,63,63,63,63,63,63,63,250,8,20,34,49,65,82,101};
    var75=(vector float)(vector unsigned char){82,125,215,80,1,6,126,139,121,55,171,88,39,88,185,227};
    var8=(vector float)(vector unsigned char){0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    var80=(vector float)(vector unsigned char){127,255,255,255,127,255,255,255,127,255,255,255,127,255,255,255};
    var81=(vector float)(vector unsigned char){67,0,255,255,67,0,255,255,67,0,255,255,67,0,255,255};
    var84=(vector float)(vector unsigned char){0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    var85=(vector float)(vector unsigned char){0,128,0,0,0,128,0,0,0,128,0,0,0,128,0,0};
    var9=(vector float)(vector unsigned char){0,8,16,24,0,8,16,24,0,8,16,24,0,8,16,24};
    var86=(vector float)si_fcgt((qword)var85,(qword)var1);
    var36=(vector float)si_shli((qword)var1,(int)1);
    var38=(vector float)si_shufb((qword)var36,(qword)var36,(qword)var37);
    var39=(vector float)si_ai((qword)var38,(int)-127);
    var40=(vector float)si_csflt((qword)var39,(int)0);
    var10=(vector float)si_roti((qword)var1,(int)4);
    var12=(vector float)si_shufb((qword)var10,(qword)var10,(qword)var11);
    var14=(vector float)si_selb((qword)var9,(qword)var12,(qword)var13);
    var43=(vector float)si_shufb((qword)var41,(qword)var42,(qword)var14);
    var44=(vector float)si_fa((qword)var40,(qword)var43);
    var34=(vector float)si_shufb((qword)var32,(qword)var33,(qword)var14);
    var30=(vector float)si_shufb((qword)var28,(qword)var29,(qword)var14);
    var26=(vector float)si_shufb((qword)var24,(qword)var25,(qword)var14);
    var22=(vector float)si_shufb((qword)var20,(qword)var21,(qword)var14);
    var19=(vector float)si_shufb((qword)var17,(qword)var18,(qword)var14);
    var15=(vector float)si_shufb((qword)var7,(qword)var8,(qword)var14);
    var6=(vector float)si_selb((qword)var4,(qword)var1,(qword)var5);
    var16=(vector float)si_fs((qword)var6,(qword)var15);
    var23=(vector float)si_fma((qword)var16,(qword)var19,(qword)var22);
    var27=(vector float)si_fma((qword)var16,(qword)var23,(qword)var26);
    var31=(vector float)si_fma((qword)var16,(qword)var27,(qword)var30);
    var35=(vector float)si_fma((qword)var16,(qword)var31,(qword)var34);
    var45=(vector float)si_fma((qword)var16,(qword)var35,(qword)var44);
    var46=(vector float)si_fm((qword)var2,(qword)var45);
    var48=(vector float)si_fm((qword)var46,(qword)var47);
    var49=(vector float)si_fma((qword)var2,(qword)var45,(qword)var48);
    var82=(vector float)si_fcgt((qword)var49,(qword)var81);
    var51=(vector float)si_fcgt((qword)var50,(qword)var49);
    var52=(vector float)si_selb((qword)var49,(qword)var50,(qword)var51);
    var53=(vector float)si_cflts((qword)var52,(int)23);
    var62=(vector float)si_roti((qword)var53,(int)4);
    var63=(vector float)si_shufb((qword)var62,(qword)var62,(qword)var11);
    var64=(vector float)si_selb((qword)var9,(qword)var63,(qword)var13);
    var76=(vector float)si_shufb((qword)var74,(qword)var75,(qword)var64);
    var72=(vector float)si_shufb((qword)var70,(qword)var71,(qword)var64);
    var68=(vector float)si_shufb((qword)var66,(qword)var67,(qword)var64);
    var65=(vector float)si_shufb((qword)var60,(qword)var61,(qword)var64);
    var59=(vector float)si_selb((qword)var57,(qword)var53,(qword)var58);
    var69=(vector float)si_fma((qword)var59,(qword)var65,(qword)var68);
    var73=(vector float)si_fma((qword)var59,(qword)var69,(qword)var72);
    var77=(vector float)si_fma((qword)var59,(qword)var73,(qword)var76);
    var55=(vector float)si_selb((qword)var3,(qword)var53,(qword)var54);
    var56=(vector float)si_a((qword)var55,(qword)var4);
    var78=(vector float)si_fm((qword)var56,(qword)var47);
    var79=(vector float)si_fma((qword)var56,(qword)var77,(qword)var78);
    var83=(vector float)si_selb((qword)var79,(qword)var80,(qword)var82);
    var87=(vector float)si_selb((qword)var83,(qword)var84,(qword)var86);
    return var87;
}

#endif /* MASS_POW_H */
