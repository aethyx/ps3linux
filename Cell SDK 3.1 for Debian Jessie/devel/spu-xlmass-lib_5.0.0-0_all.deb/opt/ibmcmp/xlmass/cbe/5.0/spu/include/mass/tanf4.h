/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2007.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

#ifndef MASS_TAN_H
#define MASS_TAN_H 1
#include <spu_intrinsics.h>
static __inline vector float _tanf4(vector float var1){
    vector float var10;
    vector float var11;
    vector float var12;
    vector float var13;
    vector float var14;
    vector float var15;
    vector float var16;
    vector float var17;
    vector float var18;
    vector float var19;
    vector float var2;
    vector float var20;
    vector float var21;
    vector float var22;
    vector float var23;
    vector float var24;
    vector float var25;
    vector float var26;
    vector float var27;
    vector float var28;
    vector float var29;
    vector float var3;
    vector float var30;
    vector float var31;
    vector float var32;
    vector float var33;
    vector float var34;
    vector float var35;
    vector float var36;
    vector float var37;
    vector float var38;
    vector float var39;
    vector float var4;
    vector float var40;
    vector float var41;
    vector float var42;
    vector float var43;
    vector float var44;
    vector float var45;
    vector float var46;
    vector float var47;
    vector float var48;
    vector float var49;
    vector float var5;
    vector float var50;
    vector float var51;
    vector float var52;
    vector float var53;
    vector float var54;
    vector float var55;
    vector float var56;
    vector float var57;
    vector float var58;
    vector float var6;
    vector float var7;
    vector float var8;
    vector float var9;
    var10=(vector float)(vector unsigned char){58,126,0,0,58,126,0,0,58,126,0,0,58,126,0,0};
    var11=(vector float)(vector unsigned char){64,73,0,0,64,73,0,0,64,73,0,0,64,73,0,0};
    var15=(vector float)(vector unsigned char){192,29,233,230,192,29,233,230,192,29,233,230,192,29,233,230};
    var19=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var2=(vector float)(vector unsigned char){181,171,187,211,181,171,187,211,181,171,187,211,181,171,187,211};
    var24=(vector float)(vector unsigned char){57,52,247,69,57,55,106,15,57,60,111,91,57,68,76,128};
    var25=(vector float)(vector unsigned char){57,79,114,238,57,94,141,132,57,114,150,31,57,134,124,15};
    var26=(vector float)(vector unsigned char){0,1,2,3,0,1,2,3,0,1,2,3,0,1,2,3};
    var3=(vector float)(vector unsigned char){62,162,249,131,62,162,249,131,62,162,249,131,62,162,249,131};
    var30=(vector float)(vector unsigned char){2,2,2,2,6,6,6,6,10,10,10,10,14,14,14,14};
    var32=(vector float)(vector unsigned char){28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28};
    var35=(vector float)(vector unsigned char){59,142,109,34,59,142,105,233,59,142,85,80,59,142,16,139};
    var36=(vector float)(vector unsigned char){59,141,102,148,59,140,2,38,59,137,92,202,59,132,162,77};
    var39=(vector float)(vector unsigned char){62,53,203,51,62,53,203,53,62,53,203,82,62,53,204,29};
    var40=(vector float)(vector unsigned char){62,53,207,133,62,53,218,138,62,53,248,124,62,54,65,6};
    var43=(vector float)(vector unsigned char){192,29,233,230,192,29,233,230,192,29,233,230,192,29,233,232};
    var44=(vector float)(vector unsigned char){192,29,233,243,192,29,234,46,192,29,235,17,192,29,237,249};
    var47=(vector float)(vector unsigned char){51,128,0,0,51,140,96,188,51,165,157,11,51,216,113,27};
    var48=(vector float)(vector unsigned char){52,34,12,139,52,149,233,29,53,86,150,104,53,86,150,104};
    var50=(vector float)(vector unsigned char){0,0,0,0,176,147,198,83,177,199,22,49,178,171,69,129};
    var51=(vector float)(vector unsigned char){179,128,110,20,180,73,63,222,181,89,165,21,181,89,165,21};
    var53=(vector float)(vector unsigned char){2,128,128,128,6,128,128,128,10,128,128,128,14,128,128,128};
    var6=(vector float)(vector unsigned char){0,0,32,0,0,0,32,0,0,0,32,0,0,0,32,0};
    var4=(vector float)si_fm((qword)var1,(qword)var3);
    var5=(vector float)si_cflts((qword)var4,(int)14);
    var7=(vector float)si_a((qword)var5,(qword)var6);
    var27=(vector float)si_rotqbii((qword)var7,(int)2);
    var28=(vector float)si_cgtbi((qword)var27,(int)-1);
    var54=(vector float)si_shufb((qword)var28,(qword)var28,(qword)var53);
    var55=(vector float)si_andbi((qword)var54,(int)128);
    var29=(vector float)si_xor((qword)var7,(qword)var28);
    var31=(vector float)si_shufb((qword)var29,(qword)var29,(qword)var30);
    var33=(vector float)si_selb((qword)var26,(qword)var31,(qword)var32);
    var52=(vector float)si_shufb((qword)var50,(qword)var51,(qword)var33);
    var56=(vector float)si_xor((qword)var52,(qword)var55);
    var49=(vector float)si_shufb((qword)var47,(qword)var48,(qword)var33);
    var45=(vector float)si_shufb((qword)var43,(qword)var44,(qword)var33);
    var41=(vector float)si_shufb((qword)var39,(qword)var40,(qword)var33);
    var37=(vector float)si_shufb((qword)var35,(qword)var36,(qword)var33);
    var34=(vector float)si_shufb((qword)var24,(qword)var25,(qword)var33);
    var8=(vector float)si_rotmai((qword)var7,(int)-14);
    var9=(vector float)si_csflt((qword)var8,(int)0);
    var12=(vector float)si_fnms((qword)var11,(qword)var9,(qword)var1);
    var13=(vector float)si_fnms((qword)var10,(qword)var9,(qword)var12);
    var14=(vector float)si_fnms((qword)var2,(qword)var9,(qword)var13);
    var57=(vector float)si_fma((qword)var14,(qword)var49,(qword)var56);
    var23=(vector float)si_fm((qword)var14,(qword)var14);
    var38=(vector float)si_fma((qword)var23,(qword)var34,(qword)var37);
    var42=(vector float)si_fma((qword)var23,(qword)var38,(qword)var41);
    var46=(vector float)si_fma((qword)var23,(qword)var42,(qword)var45);
    var16=(vector float)si_fma((qword)var14,(qword)var14,(qword)var15);
    var17=(vector float)si_frest((qword)var16);
    var18=(vector float)si_fi((qword)var16,(qword)var17);
    var20=(vector float)si_fnms((qword)var16,(qword)var18,(qword)var19);
    var21=(vector float)si_fma((qword)var20,(qword)var18,(qword)var18);
    var22=(vector float)si_fm((qword)var21,(qword)var14);
    var58=(vector float)si_fma((qword)var22,(qword)var46,(qword)var57);
    return var58;
}

#endif /* MASS_TAN_H */
