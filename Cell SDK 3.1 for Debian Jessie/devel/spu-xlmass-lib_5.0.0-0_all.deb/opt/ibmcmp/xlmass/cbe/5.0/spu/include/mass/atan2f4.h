/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2007.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

#ifndef MASS_ATAN2_H
#define MASS_ATAN2_H 1
#include <spu_intrinsics.h>
static __inline vector float _atan2f4(vector float var1,vector float var2){
    vector float var10;
    vector float var11;
    vector float var12;
    vector float var13;
    vector float var14;
    vector float var15;
    vector float var16;
    vector float var17;
    vector float var18;
    vector float var19;
    vector float var20;
    vector float var21;
    vector float var22;
    vector float var23;
    vector float var24;
    vector float var25;
    vector float var26;
    vector float var27;
    vector float var28;
    vector float var29;
    vector float var3;
    vector float var30;
    vector float var31;
    vector float var32;
    vector float var33;
    vector float var34;
    vector float var35;
    vector float var36;
    vector float var37;
    vector float var38;
    vector float var39;
    vector float var4;
    vector float var40;
    vector float var41;
    vector float var42;
    vector float var43;
    vector float var44;
    vector float var45;
    vector float var46;
    vector float var47;
    vector float var48;
    vector float var49;
    vector float var5;
    vector float var50;
    vector float var51;
    vector float var52;
    vector float var53;
    vector float var54;
    vector float var55;
    vector float var56;
    vector float var6;
    vector float var7;
    vector float var8;
    vector float var9;
    var11=(vector float)(vector unsigned char){0,0,0,8,0,0,0,8,0,0,0,8,0,0,0,8};
    var13=(vector float)(vector unsigned char){15,15,15,15,3,3,3,3,7,7,7,7,11,11,11,11};
    var15=(vector float)(vector unsigned char){12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12};
    var22=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var26=(vector float)(vector unsigned char){128,0,0,0,128,0,0,0,128,0,0,0,128,0,0,0};
    var28=(vector float)(vector unsigned char){61,115,79,219,62,8,107,57,62,54,107,131,62,60,148,18};
    var29=(vector float)(vector unsigned char){62,38,51,92,62,2,182,174,61,187,240,104,61,121,52,94};
    var3=(vector float)(vector unsigned char){191,128,0,0,63,128,0,0,63,128,0,0,191,128,0,0};
    var30=(vector float)(vector unsigned char){63,127,255,255,63,127,255,255,63,127,255,255,63,127,255,255};
    var31=(vector float)(vector unsigned char){68,128,0,0,68,128,0,0,68,128,0,0,68,128,0,0};
    var33=(vector float)(vector unsigned char){2,2,2,2,6,6,6,6,10,10,10,10,14,14,14,14};
    var35=(vector float)(vector unsigned char){28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28};
    var38=(vector float)(vector unsigned char){190,173,209,87,190,188,118,140,190,205,57,198,190,208,39,235};
    var39=(vector float)(vector unsigned char){190,191,6,192,190,157,159,42,190,104,149,182,190,21,155,58};
    var4=(vector float)(vector unsigned char){63,128,0,0,191,128,0,0,191,128,0,0,63,128,0,0};
    var42=(vector float)(vector unsigned char){57,132,89,20,59,133,29,158,60,70,22,123,60,99,3,138};
    var43=(vector float)(vector unsigned char){187,85,37,50,189,53,75,122,189,214,193,7,190,51,233,140};
    var46=(vector float)(vector unsigned char){63,127,255,203,63,127,244,104,63,127,200,251,63,127,189,144};
    var47=(vector float)(vector unsigned char){63,128,62,133,63,129,88,132,63,131,73,252,63,133,238,228};
    var50=(vector float)(vector unsigned char){51,128,0,0,51,128,0,0,51,128,0,0,51,128,0,0};
    var53=(vector float)(vector unsigned char){63,201,15,218,63,201,15,218,191,201,15,218,191,201,15,218};
    var54=(vector float)(vector unsigned char){0,0,0,0,64,73,15,218,0,0,0,0,192,73,15,218};
    var6=(vector float)(vector unsigned char){0,1,2,3,0,1,2,3,0,1,2,3,0,1,2,3};
    var7=(vector float)(vector unsigned char){239,239,239,239,239,239,239,239,239,239,239,239,239,239,239,239};
    var10=(vector float)si_rotqbii((qword)var1,(int)4);
    var9=(vector float)si_rotqbii((qword)var2,(int)3);
    var12=(vector float)si_selb((qword)var9,(qword)var10,(qword)var11);
    var14=(vector float)si_shufb((qword)var12,(qword)var12,(qword)var13);
    var5=(vector float)si_fcmgt((qword)var2,(qword)var1);
    var19=(vector float)si_selb((qword)var1,(qword)var2,(qword)var5);
    var20=(vector float)si_frest((qword)var19);
    var21=(vector float)si_fi((qword)var19,(qword)var20);
    var23=(vector float)si_fnms((qword)var19,(qword)var21,(qword)var22);
    var24=(vector float)si_fma((qword)var23,(qword)var21,(qword)var21);
    var18=(vector float)si_selb((qword)var2,(qword)var1,(qword)var5);
    var25=(vector float)si_fm((qword)var18,(qword)var24);
    var27=(vector float)si_andc((qword)var25,(qword)var26);
    var51=(vector float)si_fm((qword)var27,(qword)var50);
    var32=(vector float)si_fma((qword)var27,(qword)var30,(qword)var31);
    var34=(vector float)si_shufb((qword)var32,(qword)var32,(qword)var33);
    var36=(vector float)si_selb((qword)var6,(qword)var34,(qword)var35);
    var48=(vector float)si_shufb((qword)var46,(qword)var47,(qword)var36);
    var44=(vector float)si_shufb((qword)var42,(qword)var43,(qword)var36);
    var40=(vector float)si_shufb((qword)var38,(qword)var39,(qword)var36);
    var37=(vector float)si_shufb((qword)var28,(qword)var29,(qword)var36);
    var41=(vector float)si_fma((qword)var27,(qword)var37,(qword)var40);
    var45=(vector float)si_fma((qword)var27,(qword)var41,(qword)var44);
    var49=(vector float)si_fma((qword)var27,(qword)var45,(qword)var48);
    var52=(vector float)si_fma((qword)var27,(qword)var49,(qword)var51);
    var8=(vector float)si_selb((qword)var5,(qword)var6,(qword)var7);
    var16=(vector float)si_selb((qword)var8,(qword)var14,(qword)var15);
    var55=(vector float)si_shufb((qword)var53,(qword)var54,(qword)var16);
    var17=(vector float)si_shufb((qword)var3,(qword)var4,(qword)var16);
    var56=(vector float)si_fma((qword)var17,(qword)var52,(qword)var55);
    return var56;
}

#endif /* MASS_ATAN2_H */
