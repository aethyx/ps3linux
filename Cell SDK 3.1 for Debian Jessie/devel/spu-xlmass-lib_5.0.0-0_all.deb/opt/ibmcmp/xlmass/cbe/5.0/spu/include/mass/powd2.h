/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2008.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/
#ifndef MASS_POW_H
#define MASS_POW_H
#include <spu_intrinsics.h>
static __inline vector double _powd2(vector double var942In,vector double var943In){
    vector unsigned char var1000;
    vector unsigned char var1001;
    vector unsigned char var1002;
    vector unsigned char var1003;
    vector unsigned char var1004;
    vector unsigned char var1005;
    vector unsigned char var1006;
    vector unsigned char var1007;
    vector unsigned char var1008;
    vector unsigned char var1009;
    vector unsigned char var1010;
    vector unsigned char var1011;
    vector unsigned char var1013;
    vector unsigned char var1014;
    vector unsigned char var1015;
    vector unsigned char var1016;
    vector unsigned char var1018;
    vector unsigned char var1019;
    vector unsigned char var1021;
    vector unsigned char var1022;
    vector unsigned char var1023;
    vector unsigned char var1024;
    vector unsigned char var1025;
    vector unsigned char var1026;
    vector unsigned char var1027;
    vector unsigned char var1028;
    vector unsigned char var1029;
    vector unsigned char var1030;
    vector unsigned char var1031;
    vector unsigned char var1032;
    vector unsigned char var1033;
    vector unsigned char var1035;
    vector unsigned char var1036;
    vector unsigned char var1037;
    vector unsigned char var1038;
    vector unsigned char var1039;
    vector unsigned char var1040;
    vector unsigned char var1041;
    vector unsigned char var1046;
    vector unsigned char var1048;
    vector unsigned char var1050;
    vector unsigned char var1052;
    vector unsigned char var1054;
    vector unsigned char var1055;
    vector unsigned char var1057;
    vector unsigned char var1058;
    vector unsigned char var1060;
    vector unsigned char var1061;
    vector unsigned char var1062;
    vector unsigned char var1063;
    vector unsigned char var1064;
    vector unsigned char var1066;
    vector unsigned char var1068;
    vector unsigned char var1069;
    vector unsigned char var1070;
    vector unsigned char var1071;
    vector unsigned char var1073;
    vector unsigned char var1074;
    vector unsigned char var1075;
    vector unsigned char var1076;
    vector unsigned char var1077;
    vector unsigned char var1078;
    vector unsigned char var1080;
    vector unsigned char var1081;
    vector unsigned char var1083;
    vector unsigned char var1084;
    vector unsigned char var1086;
    vector unsigned char var1087;
    vector unsigned char var1088;
    vector unsigned char var1089;
    vector unsigned char var1090;
    vector unsigned char var1091;
    vector unsigned char var1092;
    vector unsigned char var1093;
    vector unsigned char var1094;
    vector unsigned char var1095;
    vector unsigned char var1096;
    vector unsigned char var1097;
    vector unsigned char var1098;
    vector unsigned char var1099;
    vector unsigned char var1100;
    vector unsigned char var1101;
    vector unsigned char var1102;
    vector unsigned char var1103;
    vector unsigned char var1104;
    vector unsigned char var1105;
    vector unsigned char var1107;
    vector unsigned char var1109;
    vector unsigned char var1110;
    static const union {const vector unsigned char v[256];const char c[256*16];} var1111= 
        {(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0}
        ,(vector unsigned char){63,240,11,26,250,90,188,191,63,240,11,26,250,90,188,191}
        ,(vector unsigned char){63,240,22,61,169,251,51,53,63,240,22,61,169,251,51,53}
        ,(vector unsigned char){63,240,33,104,20,59,2,129,63,240,33,104,20,59,2,129}
        ,(vector unsigned char){63,240,44,154,62,119,128,97,63,240,44,154,62,119,128,97}
        ,(vector unsigned char){63,240,55,212,46,17,187,204,63,240,55,212,46,17,187,204}
        ,(vector unsigned char){63,240,67,21,232,110,127,133,63,240,67,21,232,110,127,133}
        ,(vector unsigned char){63,240,78,95,114,246,84,177,63,240,78,95,114,246,84,177}
        ,(vector unsigned char){63,240,89,176,211,21,133,116,63,240,89,176,211,21,133,116}
        ,(vector unsigned char){63,240,101,10,14,60,31,137,63,240,101,10,14,60,31,137}
        ,(vector unsigned char){63,240,112,107,41,221,246,222,63,240,112,107,41,221,246,222}
        ,(vector unsigned char){63,240,123,212,43,114,168,54,63,240,123,212,43,114,168,54}
        ,(vector unsigned char){63,240,135,69,24,117,155,200,63,240,135,69,24,117,155,200}
        ,(vector unsigned char){63,240,146,189,246,102,7,224,63,240,146,189,246,102,7,224}
        ,(vector unsigned char){63,240,158,62,202,198,243,131,63,240,158,62,202,198,243,131}
        ,(vector unsigned char){63,240,169,199,155,31,57,25,63,240,169,199,155,31,57,25}
        ,(vector unsigned char){63,240,181,88,108,249,137,15,63,240,181,88,108,249,137,15}
        ,(vector unsigned char){63,240,192,241,69,228,108,133,63,240,192,241,69,228,108,133}
        ,(vector unsigned char){63,240,204,146,43,114,71,247,63,240,204,146,43,114,71,247}
        ,(vector unsigned char){63,240,216,59,35,57,93,236,63,240,216,59,35,57,93,236}
        ,(vector unsigned char){63,240,227,236,50,211,209,162,63,240,227,236,50,211,209,162}
        ,(vector unsigned char){63,240,239,165,95,223,169,197,63,240,239,165,95,223,169,197}
        ,(vector unsigned char){63,240,251,102,175,254,211,27,63,240,251,102,175,254,211,27}
        ,(vector unsigned char){63,241,7,48,40,215,35,62,63,241,7,48,40,215,35,62}
        ,(vector unsigned char){63,241,19,1,208,18,91,81,63,241,19,1,208,18,91,81}
        ,(vector unsigned char){63,241,30,219,171,94,42,182,63,241,30,219,171,94,42,182}
        ,(vector unsigned char){63,241,42,189,192,108,49,204,63,241,42,189,192,108,49,204}
        ,(vector unsigned char){63,241,54,168,20,242,4,171,63,241,54,168,20,242,4,171}
        ,(vector unsigned char){63,241,66,154,174,169,45,224,63,241,66,154,174,169,45,224}
        ,(vector unsigned char){63,241,78,149,147,79,49,46,63,241,78,149,147,79,49,46}
        ,(vector unsigned char){63,241,90,152,200,165,142,81,63,241,90,152,200,165,142,81}
        ,(vector unsigned char){63,241,102,164,84,113,195,194,63,241,102,164,84,113,195,194}
        ,(vector unsigned char){63,241,114,184,60,125,81,123,63,241,114,184,60,125,81,123}
        ,(vector unsigned char){63,241,126,212,134,149,187,192,63,241,126,212,134,149,187,192}
        ,(vector unsigned char){63,241,138,249,56,140,141,234,63,241,138,249,56,140,141,234}
        ,(vector unsigned char){63,241,151,38,88,55,93,47,63,241,151,38,88,55,93,47}
        ,(vector unsigned char){63,241,163,91,235,111,203,117,63,241,163,91,235,111,203,117}
        ,(vector unsigned char){63,241,175,153,248,19,138,28,63,241,175,153,248,19,138,28}
        ,(vector unsigned char){63,241,187,224,132,4,92,212,63,241,187,224,132,4,92,212}
        ,(vector unsigned char){63,241,200,47,149,40,28,107,63,241,200,47,149,40,28,107}
        ,(vector unsigned char){63,241,212,135,49,104,185,170,63,241,212,135,49,104,185,170}
        ,(vector unsigned char){63,241,224,231,94,180,64,39,63,241,224,231,94,180,64,39}
        ,(vector unsigned char){63,241,237,80,34,252,217,29,63,241,237,80,34,252,217,29}
        ,(vector unsigned char){63,241,249,193,132,56,206,77,63,241,249,193,132,56,206,77}
        ,(vector unsigned char){63,242,6,59,136,98,140,214,63,242,6,59,136,98,140,214}
        ,(vector unsigned char){63,242,18,190,53,120,168,25,63,242,18,190,53,120,168,25}
        ,(vector unsigned char){63,242,31,73,145,125,220,150,63,242,31,73,145,125,220,150}
        ,(vector unsigned char){63,242,43,221,162,121,18,209,63,242,43,221,162,121,18,209}
        ,(vector unsigned char){63,242,56,122,110,117,98,56,63,242,56,122,110,117,98,56}
        ,(vector unsigned char){63,242,69,31,251,130,20,10,63,242,69,31,251,130,20,10}
        ,(vector unsigned char){63,242,81,206,79,178,166,63,63,242,81,206,79,178,166,63}
        ,(vector unsigned char){63,242,94,133,113,30,206,117,63,242,94,133,113,30,206,117}
        ,(vector unsigned char){63,242,107,69,101,226,124,221,63,242,107,69,101,226,124,221}
        ,(vector unsigned char){63,242,120,14,52,29,223,41,63,242,120,14,52,29,223,41}
        ,(vector unsigned char){63,242,132,223,225,245,99,129,63,242,132,223,225,245,99,129}
        ,(vector unsigned char){63,242,145,186,117,145,187,112,63,242,145,186,117,145,187,112}
        ,(vector unsigned char){63,242,158,157,245,31,222,225,63,242,158,157,245,31,222,225}
        ,(vector unsigned char){63,242,171,138,102,209,15,19,63,242,171,138,102,209,15,19}
        ,(vector unsigned char){63,242,184,127,208,218,217,144,63,242,184,127,208,218,217,144}
        ,(vector unsigned char){63,242,197,126,57,119,27,47,63,242,197,126,57,119,27,47}
        ,(vector unsigned char){63,242,210,133,166,228,3,11,63,242,210,133,166,228,3,11}
        ,(vector unsigned char){63,242,223,150,31,100,21,137,63,242,223,150,31,100,21,137}
        ,(vector unsigned char){63,242,236,175,169,62,47,86,63,242,236,175,169,62,47,86}
        ,(vector unsigned char){63,242,249,210,74,189,136,107,63,242,249,210,74,189,136,107}
        ,(vector unsigned char){63,243,6,254,10,49,183,21,63,243,6,254,10,49,183,21}
        ,(vector unsigned char){63,243,20,50,237,238,178,253,63,243,20,50,237,238,178,253}
        ,(vector unsigned char){63,243,33,112,252,76,216,49,63,243,33,112,252,76,216,49}
        ,(vector unsigned char){63,243,46,184,59,168,234,50,63,243,46,184,59,168,234,50}
        ,(vector unsigned char){63,243,60,8,178,100,22,255,63,243,60,8,178,100,22,255}
        ,(vector unsigned char){63,243,73,98,102,227,250,45,63,243,73,98,102,227,250,45}
        ,(vector unsigned char){63,243,86,197,95,146,159,241,63,243,86,197,95,146,159,241}
        ,(vector unsigned char){63,243,100,49,162,222,136,59,63,243,100,49,162,222,136,59}
        ,(vector unsigned char){63,243,113,167,55,58,169,203,63,243,113,167,55,58,169,203}
        ,(vector unsigned char){63,243,127,38,35,30,117,74,63,243,127,38,35,30,117,74}
        ,(vector unsigned char){63,243,140,174,109,5,216,102,63,243,140,174,109,5,216,102}
        ,(vector unsigned char){63,243,154,64,27,113,64,239,63,243,154,64,27,113,64,239}
        ,(vector unsigned char){63,243,167,219,52,229,159,247,63,243,167,219,52,229,159,247}
        ,(vector unsigned char){63,243,181,127,191,236,108,244,63,243,181,127,191,236,108,244}
        ,(vector unsigned char){63,243,195,45,195,19,168,229,63,243,195,45,195,19,168,229}
        ,(vector unsigned char){63,243,208,229,68,237,225,115,63,243,208,229,68,237,225,115}
        ,(vector unsigned char){63,243,222,166,76,18,52,34,63,243,222,166,76,18,52,34}
        ,(vector unsigned char){63,243,236,112,223,28,81,117,63,243,236,112,223,28,81,117}
        ,(vector unsigned char){63,243,250,69,4,172,128,28,63,243,250,69,4,172,128,28}
        ,(vector unsigned char){63,244,8,34,195,103,160,36,63,244,8,34,195,103,160,36}
        ,(vector unsigned char){63,244,22,10,33,247,46,42,63,244,22,10,33,247,46,42}
        ,(vector unsigned char){63,244,35,251,39,9,70,138,63,244,35,251,39,9,70,138}
        ,(vector unsigned char){63,244,49,245,217,80,168,151,63,244,49,245,217,80,168,151}
        ,(vector unsigned char){63,244,63,250,63,132,185,212,63,244,63,250,63,132,185,212}
        ,(vector unsigned char){63,244,78,8,96,97,137,45,63,244,78,8,96,97,137,45}
        ,(vector unsigned char){63,244,92,32,66,167,210,50,63,244,92,32,66,167,210,50}
        ,(vector unsigned char){63,244,106,65,237,29,0,87,63,244,106,65,237,29,0,87}
        ,(vector unsigned char){63,244,120,109,102,139,50,55,63,244,120,109,102,139,50,55}
        ,(vector unsigned char){63,244,134,162,181,193,60,208,63,244,134,162,181,193,60,208}
        ,(vector unsigned char){63,244,148,225,225,146,174,210,63,244,148,225,225,146,174,210}
        ,(vector unsigned char){63,244,163,42,240,215,211,222,63,244,163,42,240,215,211,222}
        ,(vector unsigned char){63,244,177,125,234,109,183,215,63,244,177,125,234,109,183,215}
        ,(vector unsigned char){63,244,191,218,213,54,42,39,63,244,191,218,213,54,42,39}
        ,(vector unsigned char){63,244,206,65,184,23,193,20,63,244,206,65,184,23,193,20}
        ,(vector unsigned char){63,244,220,178,153,253,221,13,63,244,220,178,153,253,221,13}
        ,(vector unsigned char){63,244,235,45,129,216,171,255,63,244,235,45,129,216,171,255}
        ,(vector unsigned char){63,244,249,178,118,157,44,167,63,244,249,178,118,157,44,167}
        ,(vector unsigned char){63,245,8,65,127,69,49,238,63,245,8,65,127,69,49,238}
        ,(vector unsigned char){63,245,22,218,162,207,102,66,63,245,22,218,162,207,102,66}
        ,(vector unsigned char){63,245,37,125,232,63,78,239,63,245,37,125,232,63,78,239}
        ,(vector unsigned char){63,245,52,43,86,157,79,130,63,245,52,43,86,157,79,130}
        ,(vector unsigned char){63,245,66,226,244,246,173,39,63,245,66,226,244,246,173,39}
        ,(vector unsigned char){63,245,81,164,202,93,146,15,63,245,81,164,202,93,146,15}
        ,(vector unsigned char){63,245,96,112,221,233,16,210,63,245,96,112,221,233,16,210}
        ,(vector unsigned char){63,245,111,71,54,181,39,218,63,245,111,71,54,181,39,218}
        ,(vector unsigned char){63,245,126,39,219,226,196,207,63,245,126,39,219,226,196,207}
        ,(vector unsigned char){63,245,141,18,212,151,199,253,63,245,141,18,212,151,199,253}
        ,(vector unsigned char){63,245,156,8,39,255,7,204,63,245,156,8,39,255,7,204}
        ,(vector unsigned char){63,245,171,7,221,72,84,41,63,245,171,7,221,72,84,41}
        ,(vector unsigned char){63,245,186,17,251,168,122,3,63,245,186,17,251,168,122,3}
        ,(vector unsigned char){63,245,201,38,138,89,70,183,63,245,201,38,138,89,70,183}
        ,(vector unsigned char){63,245,216,69,144,153,139,147,63,245,216,69,144,153,139,147}
        ,(vector unsigned char){63,245,231,111,21,173,33,72,63,245,231,111,21,173,33,72}
        ,(vector unsigned char){63,245,246,163,32,220,235,113,63,245,246,163,32,220,235,113}
        ,(vector unsigned char){63,246,5,225,185,118,220,9,63,246,5,225,185,118,220,9}
        ,(vector unsigned char){63,246,21,42,230,205,246,244,63,246,21,42,230,205,246,244}
        ,(vector unsigned char){63,246,36,126,176,58,85,133,63,246,36,126,176,58,85,133}
        ,(vector unsigned char){63,246,51,221,29,25,41,253,63,246,51,221,29,25,41,253}
        ,(vector unsigned char){63,246,67,70,52,204,195,32,63,246,67,70,52,204,195,32}
        ,(vector unsigned char){63,246,82,185,254,188,143,183,63,246,82,185,254,188,143,183}
        ,(vector unsigned char){63,246,98,56,130,85,34,37,63,246,98,56,130,85,34,37}
        ,(vector unsigned char){63,246,113,193,199,8,51,246,63,246,113,193,199,8,51,246}
        ,(vector unsigned char){63,246,129,85,212,76,169,115,63,246,129,85,212,76,169,115}
        ,(vector unsigned char){63,246,144,244,177,158,149,56,63,246,144,244,177,158,149,56}
        ,(vector unsigned char){63,246,160,158,102,127,59,205,63,246,160,158,102,127,59,205}
        ,(vector unsigned char){63,246,176,82,250,117,23,62,63,246,176,82,250,117,23,62}
        ,(vector unsigned char){63,246,192,18,117,11,218,191,63,246,192,18,117,11,218,191}
        ,(vector unsigned char){63,246,207,220,221,212,118,69,63,246,207,220,221,212,118,69}
        ,(vector unsigned char){63,246,223,178,60,101,26,47,63,246,223,178,60,101,26,47}
        ,(vector unsigned char){63,246,239,146,152,89,58,229,63,246,239,146,152,89,58,229}
        ,(vector unsigned char){63,246,255,125,249,81,148,132,63,246,255,125,249,81,148,132}
        ,(vector unsigned char){63,247,15,116,102,244,46,135,63,247,15,116,102,244,46,135}
        ,(vector unsigned char){63,247,31,117,232,236,95,116,63,247,31,117,232,236,95,116}
        ,(vector unsigned char){63,247,47,130,134,234,208,138,63,247,47,130,134,234,208,138}
        ,(vector unsigned char){63,247,63,154,72,165,129,116,63,247,63,154,72,165,129,116}
        ,(vector unsigned char){63,247,79,189,53,215,203,253,63,247,79,189,53,215,203,253}
        ,(vector unsigned char){63,247,95,235,86,66,103,201,63,247,95,235,86,66,103,201}
        ,(vector unsigned char){63,247,112,36,177,171,110,9,63,247,112,36,177,171,110,9}
        ,(vector unsigned char){63,247,128,105,79,222,93,63,63,247,128,105,79,222,93,63}
        ,(vector unsigned char){63,247,144,185,56,172,28,246,63,247,144,185,56,172,28,246}
        ,(vector unsigned char){63,247,161,20,115,235,1,135,63,247,161,20,115,235,1,135}
        ,(vector unsigned char){63,247,177,123,9,118,207,219,63,247,177,123,9,118,207,219}
        ,(vector unsigned char){63,247,193,237,1,48,193,50,63,247,193,237,1,48,193,50}
        ,(vector unsigned char){63,247,210,106,98,255,134,240,63,247,210,106,98,255,134,240}
        ,(vector unsigned char){63,247,226,243,54,207,78,98,63,247,226,243,54,207,78,98}
        ,(vector unsigned char){63,247,243,135,132,145,196,145,63,247,243,135,132,145,196,145}
        ,(vector unsigned char){63,248,4,39,84,62,26,18,63,248,4,39,84,62,26,18}
        ,(vector unsigned char){63,248,20,210,173,209,6,217,63,248,20,210,173,209,6,217}
        ,(vector unsigned char){63,248,37,137,153,76,206,19,63,248,37,137,153,76,206,19}
        ,(vector unsigned char){63,248,54,76,30,185,65,247,63,248,54,76,30,185,65,247}
        ,(vector unsigned char){63,248,71,26,70,35,199,173,63,248,71,26,70,35,199,173}
        ,(vector unsigned char){63,248,87,244,23,159,91,33,63,248,87,244,23,159,91,33}
        ,(vector unsigned char){63,248,104,217,155,68,146,237,63,248,104,217,155,68,146,237}
        ,(vector unsigned char){63,248,121,202,217,49,164,54,63,248,121,202,217,49,164,54}
        ,(vector unsigned char){63,248,138,199,217,138,102,153,63,248,138,199,217,138,102,153}
        ,(vector unsigned char){63,248,155,208,164,120,88,15,63,248,155,208,164,120,88,15}
        ,(vector unsigned char){63,248,172,229,66,42,160,219,63,248,172,229,66,42,160,219}
        ,(vector unsigned char){63,248,190,5,186,214,23,120,63,248,190,5,186,214,23,120}
        ,(vector unsigned char){63,248,207,50,22,181,68,140,63,248,207,50,22,181,68,140}
        ,(vector unsigned char){63,248,224,106,94,8,102,217,63,248,224,106,94,8,102,217}
        ,(vector unsigned char){63,248,241,174,153,21,119,54,63,248,241,174,153,21,119,54}
        ,(vector unsigned char){63,249,2,254,208,40,44,138,63,249,2,254,208,40,44,138}
        ,(vector unsigned char){63,249,20,91,11,145,255,198,63,249,20,91,11,145,255,198}
        ,(vector unsigned char){63,249,37,195,83,170,47,226,63,249,37,195,83,170,47,226}
        ,(vector unsigned char){63,249,55,55,176,205,197,229,63,249,55,55,176,205,197,229}
        ,(vector unsigned char){63,249,72,184,43,95,152,229,63,249,72,184,43,95,152,229}
        ,(vector unsigned char){63,249,90,68,203,200,82,15,63,249,90,68,203,200,82,15}
        ,(vector unsigned char){63,249,107,221,154,118,112,179,63,249,107,221,154,118,112,179}
        ,(vector unsigned char){63,249,125,130,159,222,78,80,63,249,125,130,159,222,78,80}
        ,(vector unsigned char){63,249,143,51,228,122,34,162,63,249,143,51,228,122,34,162}
        ,(vector unsigned char){63,249,160,241,112,202,7,186,63,249,160,241,112,202,7,186}
        ,(vector unsigned char){63,249,178,187,77,83,254,13,63,249,178,187,77,83,254,13}
        ,(vector unsigned char){63,249,196,145,130,163,240,144,63,249,196,145,130,163,240,144}
        ,(vector unsigned char){63,249,214,116,25,75,184,213,63,249,214,116,25,75,184,213}
        ,(vector unsigned char){63,249,232,99,25,227,35,35,63,249,232,99,25,227,35,35}
        ,(vector unsigned char){63,249,250,94,141,7,242,158,63,249,250,94,141,7,242,158}
        ,(vector unsigned char){63,250,12,102,123,93,229,101,63,250,12,102,123,93,229,101}
        ,(vector unsigned char){63,250,30,122,237,142,184,187,63,250,30,122,237,142,184,187}
        ,(vector unsigned char){63,250,48,155,236,74,45,51,63,250,48,155,236,74,45,51}
        ,(vector unsigned char){63,250,66,201,128,70,10,216,63,250,66,201,128,70,10,216}
        ,(vector unsigned char){63,250,85,3,178,62,37,93,63,250,85,3,178,62,37,93}
        ,(vector unsigned char){63,250,103,74,138,244,96,82,63,250,103,74,138,244,96,82}
        ,(vector unsigned char){63,250,121,158,19,48,179,88,63,250,121,158,19,48,179,88}
        ,(vector unsigned char){63,250,139,254,83,193,46,89,63,250,139,254,83,193,46,89}
        ,(vector unsigned char){63,250,158,107,85,121,253,191,63,250,158,107,85,121,253,191}
        ,(vector unsigned char){63,250,176,229,33,53,110,186,63,250,176,229,33,53,110,186}
        ,(vector unsigned char){63,250,195,107,191,211,243,122,63,250,195,107,191,211,243,122}
        ,(vector unsigned char){63,250,213,255,58,60,39,116,63,250,213,255,58,60,39,116}
        ,(vector unsigned char){63,250,232,159,153,90,211,173,63,250,232,159,153,90,211,173}
        ,(vector unsigned char){63,250,251,76,230,34,242,255,63,250,251,76,230,34,242,255}
        ,(vector unsigned char){63,251,14,7,41,141,182,102,63,251,14,7,41,141,182,102}
        ,(vector unsigned char){63,251,32,206,108,154,137,82,63,251,32,206,108,154,137,82}
        ,(vector unsigned char){63,251,51,162,184,79,21,251,63,251,51,162,184,79,21,251}
        ,(vector unsigned char){63,251,70,132,21,183,73,177,63,251,70,132,21,183,73,177}
        ,(vector unsigned char){63,251,89,114,141,229,89,58,63,251,89,114,141,229,89,58}
        ,(vector unsigned char){63,251,108,110,41,241,197,42,63,251,108,110,41,241,197,42}
        ,(vector unsigned char){63,251,127,118,242,251,94,71,63,251,127,118,242,251,94,71}
        ,(vector unsigned char){63,251,146,140,242,39,73,228,63,251,146,140,242,39,73,228}
        ,(vector unsigned char){63,251,165,176,48,161,6,74,63,251,165,176,48,161,6,74}
        ,(vector unsigned char){63,251,184,224,183,154,111,31,63,251,184,224,183,154,111,31}
        ,(vector unsigned char){63,251,204,30,144,75,193,210,63,251,204,30,144,75,193,210}
        ,(vector unsigned char){63,251,223,105,195,243,162,7,63,251,223,105,195,243,162,7}
        ,(vector unsigned char){63,251,242,194,91,215,30,9,63,251,242,194,91,215,30,9}
        ,(vector unsigned char){63,252,6,40,97,65,179,61,63,252,6,40,97,65,179,61}
        ,(vector unsigned char){63,252,25,155,221,133,82,156,63,252,25,155,221,133,82,156}
        ,(vector unsigned char){63,252,45,28,217,250,101,44,63,252,45,28,217,250,101,44}
        ,(vector unsigned char){63,252,64,171,95,255,208,122,63,252,64,171,95,255,208,122}
        ,(vector unsigned char){63,252,84,71,120,250,251,34,63,252,84,71,120,250,251,34}
        ,(vector unsigned char){63,252,103,241,46,87,209,75,63,252,103,241,46,87,209,75}
        ,(vector unsigned char){63,252,123,168,137,136,201,51,63,252,123,168,137,136,201,51}
        ,(vector unsigned char){63,252,143,109,148,6,231,181,63,252,143,109,148,6,231,181}
        ,(vector unsigned char){63,252,163,64,87,81,196,219,63,252,163,64,87,81,196,219}
        ,(vector unsigned char){63,252,183,32,220,239,144,105,63,252,183,32,220,239,144,105}
        ,(vector unsigned char){63,252,203,15,46,109,22,117,63,252,203,15,46,109,22,117}
        ,(vector unsigned char){63,252,223,11,85,93,195,250,63,252,223,11,85,93,195,250}
        ,(vector unsigned char){63,252,243,21,91,91,171,116,63,252,243,21,91,91,171,116}
        ,(vector unsigned char){63,253,7,45,74,7,137,124,63,253,7,45,74,7,137,124}
        ,(vector unsigned char){63,253,27,83,43,8,201,104,63,253,27,83,43,8,201,104}
        ,(vector unsigned char){63,253,47,135,8,13,137,242,63,253,47,135,8,13,137,242}
        ,(vector unsigned char){63,253,67,200,234,202,161,214,63,253,67,200,234,202,161,214}
        ,(vector unsigned char){63,253,88,24,220,251,164,135,63,253,88,24,220,251,164,135}
        ,(vector unsigned char){63,253,108,118,232,98,230,211,63,253,108,118,232,98,230,211}
        ,(vector unsigned char){63,253,128,227,22,201,131,152,63,253,128,227,22,201,131,152}
        ,(vector unsigned char){63,253,149,93,113,255,96,117,63,253,149,93,113,255,96,117}
        ,(vector unsigned char){63,253,169,230,3,219,50,133,63,253,169,230,3,219,50,133}
        ,(vector unsigned char){63,253,190,124,214,58,131,21,63,253,190,124,214,58,131,21}
        ,(vector unsigned char){63,253,211,33,243,1,180,96,63,253,211,33,243,1,180,96}
        ,(vector unsigned char){63,253,231,213,100,28,6,88,63,253,231,213,100,28,6,88}
        ,(vector unsigned char){63,253,252,151,51,123,155,95,63,253,252,151,51,123,155,95}
        ,(vector unsigned char){63,254,17,103,107,25,125,23,63,254,17,103,107,25,125,23}
        ,(vector unsigned char){63,254,38,70,20,245,161,41,63,254,38,70,20,245,161,41}
        ,(vector unsigned char){63,254,59,51,59,22,238,18,63,254,59,51,59,22,238,18}
        ,(vector unsigned char){63,254,80,46,231,139,63,246,63,254,80,46,231,139,63,246}
        ,(vector unsigned char){63,254,101,57,36,103,109,118,63,254,101,57,36,103,109,118}
        ,(vector unsigned char){63,254,122,81,251,199,76,131,63,254,122,81,251,199,76,131}
        ,(vector unsigned char){63,254,143,121,119,205,183,64,63,254,143,121,119,205,183,64}
        ,(vector unsigned char){63,254,164,175,162,164,144,218,63,254,164,175,162,164,144,218}
        ,(vector unsigned char){63,254,185,244,134,124,202,110,63,254,185,244,134,124,202,110}
        ,(vector unsigned char){63,254,207,72,45,142,103,241,63,254,207,72,45,142,103,241}
        ,(vector unsigned char){63,254,228,170,162,24,133,16,63,254,228,170,162,24,133,16}
        ,(vector unsigned char){63,254,250,27,238,97,90,39,63,254,250,27,238,97,90,39}
        ,(vector unsigned char){63,255,15,156,28,182,65,42,63,255,15,156,28,182,65,42}
        ,(vector unsigned char){63,255,37,43,55,107,186,151,63,255,37,43,55,107,186,151}
        ,(vector unsigned char){63,255,58,201,72,221,114,116,63,255,58,201,72,221,114,116}
        ,(vector unsigned char){63,255,80,118,91,110,69,64,63,255,80,118,91,110,69,64}
        ,(vector unsigned char){63,255,102,50,121,136,68,248,63,255,102,50,121,136,68,248}
        ,(vector unsigned char){63,255,123,253,173,156,190,20,63,255,123,253,173,156,190,20}
        ,(vector unsigned char){63,255,145,216,2,36,60,137,63,255,145,216,2,36,60,137}
        ,(vector unsigned char){63,255,167,193,129,158,144,216,63,255,167,193,129,158,144,216}
        ,(vector unsigned char){63,255,189,186,54,146,213,20,63,255,189,186,54,146,213,20}
        ,(vector unsigned char){63,255,211,194,43,143,113,241,63,255,211,194,43,143,113,241}
        ,(vector unsigned char){63,255,233,217,107,42,35,217,63,255,233,217,107,42,35,217}
        };
    vector unsigned char var1112;
    vector unsigned char var1113;
    vector unsigned char var1114;
    vector unsigned char var1115;
    vector unsigned char var1116;
    vector unsigned char var1117;
    vector unsigned char var1118;
    vector unsigned char var1119;
    vector unsigned char var1120;
    vector unsigned char var1122;
    vector unsigned char var1123;
    vector unsigned char var1124;
    vector unsigned char var1125;
    vector unsigned char var1126;
    vector unsigned char var1127;
    vector unsigned char var1129;
    vector unsigned char var1130;
    vector unsigned char var1131;
    vector unsigned char var1133;
    vector unsigned char var1134;
    vector unsigned char var1135;
    vector unsigned char var1136;
    vector unsigned char var1137;
    vector unsigned char var1138;
    vector unsigned char var1139;
    vector unsigned char var1140;
    vector unsigned char var1141;
    vector unsigned char var1144;
    vector unsigned char var1145;
    vector unsigned char var1148;
    vector unsigned char var1150;
    vector unsigned char var1151;
    vector unsigned char var1152;
    vector unsigned char var1153;
    vector unsigned char var1154;
    vector unsigned char var1155;
    vector unsigned char var1156;
    vector unsigned char var1163;
    vector unsigned char var1164;
    vector unsigned char var1165;
    vector unsigned char var1166;
    vector unsigned char var1167;
    vector unsigned char var1169;
    vector unsigned char var1172;
    vector unsigned char var1174;
    vector unsigned char var1176;
    vector unsigned char var1177;
    vector unsigned char var1178;
    vector unsigned char var1181;
    vector unsigned char var1182;
    vector unsigned char var1183;
    vector unsigned char var1184;
    vector unsigned char var1187;
    vector unsigned char var1190;
    vector unsigned char var1192;
    vector unsigned char var1195;
    vector unsigned char var1196;
    vector unsigned char var1197;
    vector unsigned char var1199;
    vector unsigned char var1200;
    vector unsigned char var1201;
    vector unsigned char var1202;
    vector unsigned char var1203;
    vector unsigned char var1204;
    vector unsigned char var1205;
    vector unsigned char var1206;
    vector unsigned char var1207;
    vector double var1208;
    vector unsigned char var942;
    vector unsigned char var943;
    static const union {const vector unsigned char v[256];const char c[256*16];} var944= 
        {(vector unsigned char){0,0,0,0,0,0,0,0,63,240,0,0,0,0,0,0}
        ,(vector unsigned char){63,119,9,196,109,122,172,119,63,239,224,31,224,31,224,32}
        ,(vector unsigned char){63,134,254,80,182,239,8,81,63,239,192,127,1,252,7,240}
        ,(vector unsigned char){63,145,54,49,23,169,123,12,63,239,161,28,170,1,250,18}
        ,(vector unsigned char){63,150,231,150,133,194,210,42,63,239,129,248,31,129,248,32}
        ,(vector unsigned char){63,156,147,99,186,133,15,134,63,239,99,16,172,160,219,181}
        ,(vector unsigned char){63,161,28,209,213,19,52,19,63,239,68,101,158,74,66,113}
        ,(vector unsigned char){63,163,237,48,148,104,90,38,63,239,37,246,68,35,10,181}
        ,(vector unsigned char){63,166,186,211,117,142,253,135,63,239,7,193,240,124,31,8}
        ,(vector unsigned char){63,169,133,191,195,73,81,148,63,238,233,199,248,69,142,2}
        ,(vector unsigned char){63,172,77,250,185,10,171,95,63,238,204,7,179,1,236,192}
        ,(vector unsigned char){63,175,19,137,131,50,83,160,63,238,174,128,122,186,1,235}
        ,(vector unsigned char){63,176,235,56,159,162,159,155,63,238,145,49,171,240,183,103}
        ,(vector unsigned char){63,178,75,91,126,19,90,61,63,238,116,26,165,151,80,228}
        ,(vector unsigned char){63,179,170,47,221,39,241,195,63,238,87,58,201,1,229,116}
        ,(vector unsigned char){63,181,7,184,54,3,59,183,63,238,58,145,121,220,26,115}
        ,(vector unsigned char){63,182,99,246,250,201,19,22,63,238,30,30,30,30,30,30}
        ,(vector unsigned char){63,183,190,238,150,184,162,129,63,238,1,224,30,1,224,30}
        ,(vector unsigned char){63,185,24,161,110,70,51,91,63,237,229,214,227,248,134,138}
        ,(vector unsigned char){63,186,113,17,223,52,132,148,63,237,202,1,220,160,29,202}
        ,(vector unsigned char){63,187,200,66,64,173,171,186,63,237,174,96,118,185,129,219}
        ,(vector unsigned char){63,189,30,52,227,91,130,218,63,237,146,242,35,30,127,138}
        ,(vector unsigned char){63,190,114,236,17,127,165,178,63,237,119,182,84,184,44,52}
        ,(vector unsigned char){63,191,198,106,15,11,0,165,63,237,92,172,128,117,114,178}
        ,(vector unsigned char){63,192,140,88,140,218,121,228,63,237,65,212,29,65,212,29}
        ,(vector unsigned char){63,193,52,225,180,137,6,46,63,237,39,44,163,252,91,26}
        ,(vector unsigned char){63,193,220,209,151,85,43,123,63,237,12,181,143,110,192,116}
        ,(vector unsigned char){63,194,132,41,75,7,166,64,63,236,242,110,92,68,191,198}
        ,(vector unsigned char){63,195,42,233,226,120,174,26,63,236,216,86,137,3,155,11}
        ,(vector unsigned char){63,195,209,20,109,154,138,100,63,236,190,109,150,1,203,231}
        ,(vector unsigned char){63,196,118,169,249,131,247,77,63,236,164,179,5,94,225,145}
        ,(vector unsigned char){63,197,27,171,144,122,92,138,63,236,139,38,90,251,138,66}
        ,(vector unsigned char){63,197,192,26,57,251,214,136,63,236,113,199,28,113,199,28}
        ,(vector unsigned char){63,198,99,246,250,201,19,22,63,236,88,148,209,13,73,134}
        ,(vector unsigned char){63,199,7,66,212,239,2,127,63,236,63,143,1,195,248,240}
        ,(vector unsigned char){63,199,169,254,199,208,93,223,63,236,38,181,57,46,160,28}
        ,(vector unsigned char){63,200,76,43,208,47,3,179,63,236,14,7,3,129,192,224}
        ,(vector unsigned char){63,200,237,202,232,53,43,108,63,235,245,131,238,134,141,139}
        ,(vector unsigned char){63,201,142,221,7,126,112,223,63,235,221,43,137,148,6,247}
        ,(vector unsigned char){63,202,47,99,35,32,184,107,63,235,196,253,101,136,62,123}
        ,(vector unsigned char){63,202,207,94,45,180,236,148,63,235,172,249,20,193,186,208}
        ,(vector unsigned char){63,203,110,207,23,95,149,233,63,235,149,30,43,24,255,35}
        ,(vector unsigned char){63,204,13,182,205,217,77,238,63,235,125,108,61,218,51,139}
        ,(vector unsigned char){63,204,172,22,60,119,13,201,63,235,101,226,227,190,238,5}
        ,(vector unsigned char){63,205,73,238,76,50,89,112,63,235,78,129,180,232,27,79}
        ,(vector unsigned char){63,205,231,63,227,177,72,15,63,235,55,72,74,216,6,206}
        ,(vector unsigned char){63,206,132,11,231,78,106,77,63,235,32,54,64,108,128,217}
        ,(vector unsigned char){63,207,32,83,57,32,143,39,63,235,9,75,49,217,34,164}
        ,(vector unsigned char){63,207,188,22,185,2,104,10,63,234,242,134,188,161,175,40}
        ,(vector unsigned char){63,208,43,171,162,77,6,100,63,234,219,232,127,148,144,94}
        ,(vector unsigned char){63,208,121,10,219,176,48,9,63,234,197,112,26,197,112,27}
        ,(vector unsigned char){63,208,198,41,117,84,42,143,63,234,175,29,47,135,235,253}
        ,(vector unsigned char){63,209,19,7,218,211,11,118,63,234,152,239,96,106,99,190}
        ,(vector unsigned char){63,209,95,166,118,187,8,255,63,234,130,230,81,48,225,89}
        ,(vector unsigned char){63,209,172,5,178,145,240,112,63,234,109,1,166,208,26,109}
        ,(vector unsigned char){63,209,248,37,246,216,142,19,63,234,87,65,7,104,138,74}
        ,(vector unsigned char){63,210,68,7,171,14,7,58,63,234,65,164,26,65,164,26}
        ,(vector unsigned char){63,210,143,171,53,179,38,131,63,234,44,42,135,197,28,160}
        ,(vector unsigned char){63,210,219,16,252,77,154,175,63,234,22,211,249,122,75,2}
        ,(vector unsigned char){63,211,38,57,99,107,40,54,63,234,1,160,26,1,160,26}
        ,(vector unsigned char){63,211,113,36,206,164,205,237,63,233,236,142,149,16,51,217}
        ,(vector unsigned char){63,211,187,211,160,161,220,251,63,233,215,159,23,107,104,45}
        ,(vector unsigned char){63,212,6,70,59,27,4,73,63,233,194,209,78,228,161,2}
        ,(vector unsigned char){63,212,80,124,254,221,79,196,63,233,174,36,234,85,16,218}
        ,(vector unsigned char){63,212,154,120,75,205,27,139,63,233,153,153,153,153,153,154}
        ,(vector unsigned char){63,212,228,56,128,232,251,106,63,233,133,47,13,142,192,255}
        ,(vector unsigned char){63,213,45,189,252,76,150,179,63,233,112,228,248,12,184,114}
        ,(vector unsigned char){63,213,119,9,27,51,120,203,63,233,92,187,11,227,119,174}
        ,(vector unsigned char){63,213,192,26,57,251,214,136,63,233,72,176,252,214,233,224}
        ,(vector unsigned char){63,214,8,241,180,41,72,174,63,233,52,198,127,155,44,230}
        ,(vector unsigned char){63,214,81,143,228,103,123,167,63,233,32,251,73,208,226,41}
        ,(vector unsigned char){63,214,153,245,36,140,212,184,63,233,13,79,18,1,144,213}
        ,(vector unsigned char){63,214,226,33,205,157,12,222,63,232,249,193,143,156,24,250}
        ,(vector unsigned char){63,215,42,22,55,203,193,131,63,232,230,82,122,241,55,63}
        ,(vector unsigned char){63,215,113,210,186,126,251,60,63,232,211,1,141,48,24,211}
        ,(vector unsigned char){63,215,185,87,172,81,170,196,63,232,191,206,128,98,255,58}
        ,(vector unsigned char){63,216,0,165,99,22,28,84,63,232,172,185,15,107,243,170}
        ,(vector unsigned char){63,216,71,188,51,216,97,142,63,232,153,192,246,1,137,156}
        ,(vector unsigned char){63,216,142,156,114,224,178,38,63,232,134,229,240,171,176,74}
        ,(vector unsigned char){63,216,213,70,115,181,195,114,63,232,116,39,188,192,146,185}
        ,(vector unsigned char){63,217,27,186,137,31,23,9,63,232,97,134,24,97,134,24}
        ,(vector unsigned char){63,217,97,249,5,39,64,156,63,232,79,0,194,120,6,20}
        ,(vector unsigned char){63,217,168,2,57,30,35,47,63,232,60,151,122,178,190,221}
        ,(vector unsigned char){63,217,237,214,117,155,37,224,63,232,42,74,1,130,164,160}
        ,(vector unsigned char){63,218,51,118,10,127,96,81,63,232,24,24,24,24,24,24}
        ,(vector unsigned char){63,218,120,225,70,247,190,244,63,232,6,1,128,96,24,6}
        ,(vector unsigned char){63,218,190,24,121,127,31,73,63,231,244,5,253,1,127,64}
        ,(vector unsigned char){63,219,3,27,239,224,100,52,63,231,226,37,81,90,79,29}
        ,(vector unsigned char){63,219,71,235,247,56,130,161,63,231,208,95,65,125,5,244}
        ,(vector unsigned char){63,219,140,136,219,248,134,122,63,231,190,179,146,46,1,124}
        ,(vector unsigned char){63,219,208,242,233,231,144,49,63,231,173,34,8,224,236,195}
        ,(vector unsigned char){63,220,21,42,108,36,202,230,63,231,155,170,107,182,57,139}
        ,(vector unsigned char){63,220,89,47,173,41,91,86,63,231,138,76,129,120,164,200}
        ,(vector unsigned char){63,220,157,2,246,202,71,180,63,231,121,8,17,154,198,13}
        ,(vector unsigned char){63,220,224,164,146,58,88,125,63,231,103,220,228,52,169,177}
        ,(vector unsigned char){63,221,36,20,200,11,242,125,63,231,86,202,194,1,117,109}
        ,(vector unsigned char){63,221,103,83,224,50,234,15,63,231,69,209,116,93,23,70}
        ,(vector unsigned char){63,221,170,98,34,6,79,185,63,231,52,240,197,65,254,141}
        ,(vector unsigned char){63,221,237,63,212,66,54,76,63,231,36,40,127,70,222,188}
        ,(vector unsigned char){63,222,47,237,61,9,114,152,63,231,19,120,109,156,124,9}
        ,(vector unsigned char){63,222,114,106,161,231,84,210,63,231,2,224,92,11,129,112}
        ,(vector unsigned char){63,222,180,184,71,209,91,206,63,230,242,96,22,242,96,23}
        ,(vector unsigned char){63,222,246,214,115,40,226,32,63,230,225,247,107,67,55,199}
        ,(vector unsigned char){63,223,56,197,103,188,197,65,63,230,209,166,38,129,200,97}
        ,(vector unsigned char){63,223,122,133,104,203,6,207,63,230,193,108,22,193,108,23}
        ,(vector unsigned char){63,223,188,22,185,2,104,10,63,230,177,73,10,163,26,61}
        ,(vector unsigned char){63,223,253,121,154,131,255,155,63,230,161,60,209,83,114,144}
        ,(vector unsigned char){63,224,31,87,39,114,100,224,63,230,145,71,58,136,208,192}
        ,(vector unsigned char){63,224,63,218,139,151,153,127,63,230,129,104,22,129,104,23}
        ,(vector unsigned char){63,224,96,71,25,242,78,178,63,230,113,159,54,1,103,26}
        ,(vector unsigned char){63,224,128,156,242,127,112,61,63,230,97,236,106,81,34,249}
        ,(vector unsigned char){63,224,160,220,52,248,225,252,63,230,82,79,133,59,74,163}
        ,(vector unsigned char){63,224,193,5,0,214,58,166,63,230,66,200,89,11,33,100}
        ,(vector unsigned char){63,224,225,23,117,77,124,17,63,230,51,86,184,138,192,222}
        ,(vector unsigned char){63,225,1,19,177,83,200,234,63,230,35,250,119,1,98,64}
        ,(vector unsigned char){63,225,32,249,211,158,24,7,63,230,20,179,104,49,174,148}
        ,(vector unsigned char){63,225,64,201,250,161,229,68,63,230,5,129,96,88,22,6}
        ,(vector unsigned char){63,225,96,132,68,149,224,6,63,229,246,100,52,41,45,252}
        ,(vector unsigned char){63,225,128,40,207,114,151,106,63,229,231,91,184,208,21,231}
        ,(vector unsigned char){63,225,159,183,184,243,36,33,63,229,216,103,195,236,226,165}
        ,(vector unsigned char){63,225,191,49,30,149,208,14,63,229,201,136,43,147,16,87}
        ,(vector unsigned char){63,225,222,149,29,156,187,166,63,229,186,188,198,71,250,145}
        ,(vector unsigned char){63,225,253,227,211,14,129,38,63,229,172,5,107,1,90,192}
        ,(vector unsigned char){63,226,29,29,91,182,213,154,63,229,157,97,241,35,204,170}
        ,(vector unsigned char){63,226,60,65,212,39,39,200,63,229,142,210,48,129,88,237}
        ,(vector unsigned char){63,226,91,81,88,183,61,4,63,229,128,86,1,88,5,96}
        ,(vector unsigned char){63,226,122,76,5,133,203,248,63,229,113,237,60,80,107,58}
        ,(vector unsigned char){63,226,153,49,246,121,21,96,63,229,99,151,186,124,82,226}
        ,(vector unsigned char){63,226,214,192,19,80,19,128,63,229,71,37,230,187,130,254}
        ,(vector unsigned char){63,226,245,104,117,235,63,38,63,229,57,9,72,244,15,235}
        ,(vector unsigned char){63,227,19,252,138,27,54,242,63,229,42,255,86,168,5,75}
        ,(vector unsigned char){63,227,50,124,106,180,156,167,63,229,29,7,234,226,248,21}
        ,(vector unsigned char){63,227,80,232,50,87,7,217,63,229,15,34,225,17,196,197}
        ,(vector unsigned char){63,227,111,63,251,109,145,98,63,229,1,80,21,1,80,21}
        ,(vector unsigned char){63,227,141,131,224,47,93,9,63,228,243,143,98,221,76,155}
        ,(vector unsigned char){63,227,171,179,250,160,33,103,63,228,229,224,167,47,5,57}
        ,(vector unsigned char){63,227,201,208,100,144,174,18,63,228,216,67,190,220,44,76}
        ,(vector unsigned char){63,227,231,217,55,159,112,22,63,228,202,184,135,37,175,110}
        ,(vector unsigned char){63,228,5,206,141,56,244,188,63,228,189,62,221,166,143,225}
        ,(vector unsigned char){63,228,35,176,126,152,106,169,63,228,175,214,160,82,191,91}
        ,(vector unsigned char){63,228,65,127,36,200,33,101,63,228,162,127,173,118,1,74}
        ,(vector unsigned char){63,228,95,58,152,162,7,57,63,228,149,57,227,178,208,103}
        ,(vector unsigned char){63,228,124,226,242,208,37,135,63,228,136,5,34,1,72,128}
        ,(vector unsigned char){63,228,154,120,75,205,27,139,63,228,122,225,71,174,20,123}
        ,(vector unsigned char){63,228,183,250,187,228,151,149,63,228,109,206,52,89,96,102}
        ,(vector unsigned char){63,228,213,106,91,51,206,196,63,228,96,203,199,245,207,154}
        ,(vector unsigned char){63,228,242,199,65,169,243,62,63,228,83,217,226,199,118,202}
        ,(vector unsigned char){63,229,16,17,135,8,168,249,63,228,70,248,101,98,217,251}
        ,(vector unsigned char){63,229,45,73,66,228,121,9,63,228,58,39,48,171,238,77}
        ,(vector unsigned char){63,229,74,110,140,165,67,142,63,228,45,102,37,213,31,135}
        ,(vector unsigned char){63,229,103,129,123,134,176,44,63,228,32,181,38,94,89,81}
        ,(vector unsigned char){63,229,132,130,38,152,157,52,63,228,20,20,20,20,20,20}
        ,(vector unsigned char){63,229,161,112,164,191,141,92,63,228,7,130,209,14,101,102}
        ,(vector unsigned char){63,229,190,77,12,181,20,53,63,227,251,1,63,176,19,251}
        ,(vector unsigned char){63,229,219,23,117,8,65,60,63,227,238,143,66,165,175,7}
        ,(vector unsigned char){63,229,247,207,244,30,9,175,63,227,226,44,188,228,169,2}
        ,(vector unsigned char){63,230,20,118,160,49,177,9,63,227,213,217,145,170,117,198}
        ,(vector unsigned char){63,230,49,11,143,85,48,72,63,227,201,149,164,123,171,231}
        ,(vector unsigned char){63,230,77,142,215,113,155,240,63,227,189,96,217,35,41,85}
        ,(vector unsigned char){63,230,106,0,142,71,136,204,63,227,177,59,19,177,59,20}
        ,(vector unsigned char){63,230,134,96,201,111,111,135,63,227,165,36,56,122,200,34}
        ,(vector unsigned char){63,230,162,175,158,90,15,10,63,227,153,28,44,24,127,99}
        ,(vector unsigned char){63,230,190,237,34,80,205,174,63,227,141,34,211,102,8,142}
        ,(vector unsigned char){63,230,219,25,106,118,25,74,63,227,129,56,19,129,56,20}
        ,(vector unsigned char){63,230,247,52,139,197,198,24,63,227,117,91,209,201,69,238}
        ,(vector unsigned char){63,231,19,62,155,21,108,124,63,227,105,141,243,222,7,72}
        ,(vector unsigned char){63,231,47,55,173,20,197,176,63,227,93,206,95,159,42,248}
        ,(vector unsigned char){63,231,75,31,214,78,7,84,63,227,82,28,251,43,120,193}
        ,(vector unsigned char){63,231,102,247,43,38,61,238,63,227,70,121,172,224,19,70}
        ,(vector unsigned char){63,231,130,189,191,221,166,87,63,227,58,228,91,87,188,178}
        ,(vector unsigned char){63,231,158,115,168,144,6,32,63,227,47,92,237,106,29,250}
        ,(vector unsigned char){63,231,186,24,249,53,2,228,63,227,35,227,74,43,16,191}
        ,(vector unsigned char){63,231,213,173,197,160,120,164,63,227,24,119,88,233,235,182}
        ,(vector unsigned char){63,231,241,50,33,130,207,22,63,227,13,25,1,48,209,144}
        ,(vector unsigned char){63,232,12,166,32,105,77,249,63,227,1,200,42,196,2,96}
        ,(vector unsigned char){63,232,40,9,213,190,112,115,63,226,246,132,189,161,47,104}
        ,(vector unsigned char){63,232,67,93,84,202,55,116,63,226,235,78,161,254,209,75}
        ,(vector unsigned char){63,232,94,160,176,178,123,38,63,226,224,37,192,75,128,151}
        ,(vector unsigned char){63,232,121,211,252,123,59,113,63,226,213,10,1,45,80,160}
        ,(vector unsigned char){63,232,148,247,75,6,239,139,63,226,201,251,77,129,44,160}
        ,(vector unsigned char){63,232,176,10,175,22,212,169,63,226,190,249,142,90,55,17}
        ,(vector unsigned char){63,232,203,14,59,75,59,190,63,226,180,4,173,1,43,64}
        ,(vector unsigned char){63,232,230,2,2,35,214,97,63,226,169,28,146,243,193,5}
        ,(vector unsigned char){63,233,0,230,22,0,2,205,63,226,158,65,41,228,18,158}
        ,(vector unsigned char){63,233,27,186,137,31,23,9,63,226,147,114,91,184,4,165}
        ,(vector unsigned char){63,233,54,127,109,160,171,47,63,226,136,176,18,136,176,19}
        ,(vector unsigned char){63,233,81,52,213,132,226,227,63,226,125,250,56,161,206,77}
        ,(vector unsigned char){63,233,107,218,210,172,181,246,63,226,115,80,184,129,39,53}
        ,(vector unsigned char){63,233,134,113,118,218,56,47,63,226,104,179,124,214,1,39}
        ,(vector unsigned char){63,233,160,248,211,176,224,80,63,226,94,34,112,128,146,241}
        ,(vector unsigned char){63,233,187,112,250,181,206,77,63,226,83,157,126,145,119,178}
        ,(vector unsigned char){63,233,213,217,253,80,16,179,63,226,73,36,146,73,36,146}
        ,(vector unsigned char){63,233,240,51,236,200,233,86,63,226,62,183,151,23,96,91}
        ,(vector unsigned char){63,234,10,126,218,76,17,45,63,226,52,86,120,154,188,223}
        ,(vector unsigned char){63,234,36,186,214,231,251,119,63,226,42,1,34,160,18,42}
        ,(vector unsigned char){63,234,62,231,243,142,24,31,63,226,31,183,129,33,251,120}
        ,(vector unsigned char){63,234,89,6,65,19,21,100,63,226,21,121,128,72,85,230}
        ,(vector unsigned char){63,234,115,21,208,47,32,200,63,226,11,71,12,103,192,217}
        ,(vector unsigned char){63,234,141,22,177,126,39,69,63,226,1,32,18,1,32,18}
        ,(vector unsigned char){63,234,167,8,245,128,20,211,63,225,247,4,125,193,31,112}
        ,(vector unsigned char){63,234,192,236,172,153,19,59,63,225,236,244,60,127,184,76}
        ,(vector unsigned char){63,234,218,193,231,17,200,51,63,225,226,239,59,63,184,116}
        ,(vector unsigned char){63,234,244,136,181,23,146,214,63,225,216,245,103,46,74,189}
        ,(vector unsigned char){63,235,14,65,38,188,200,108,63,225,207,6,173,162,129,29}
        ,(vector unsigned char){63,235,39,235,75,248,240,138,63,225,197,34,252,28,224,89}
        ,(vector unsigned char){63,235,65,135,52,169,0,140,63,225,187,74,64,70,237,41}
        ,(vector unsigned char){63,235,91,20,240,143,150,102,63,225,177,124,103,242,186,227}
        ,(vector unsigned char){63,235,116,148,143,85,50,218,63,225,167,185,97,26,123,150}
        ,(vector unsigned char){63,235,142,6,32,136,115,9,63,225,158,1,25,224,17,158}
        ,(vector unsigned char){63,235,167,105,179,158,73,100,63,225,148,83,128,140,162,156}
        ,(vector unsigned char){63,235,192,191,87,242,54,6,63,225,138,176,131,144,43,219}
        ,(vector unsigned char){63,235,218,7,28,198,126,110,63,225,129,24,17,129,24,18}
        ,(vector unsigned char){63,235,243,65,17,68,100,167,63,225,119,138,25,27,214,132}
        ,(vector unsigned char){63,236,12,109,68,124,93,211,63,225,110,6,137,66,115,121}
        ,(vector unsigned char){63,236,37,139,197,102,72,41,63,225,100,141,80,252,50,1}
        ,(vector unsigned char){63,236,62,156,162,225,160,85,63,225,91,30,95,117,39,13}
        ,(vector unsigned char){63,236,87,159,235,181,182,88,63,225,81,185,163,253,213,201}
        ,(vector unsigned char){63,236,112,149,174,145,225,199,63,225,72,95,14,10,205,59}
        ,(vector unsigned char){63,236,137,125,250,13,181,142,63,225,63,14,141,52,71,36}
        ,(vector unsigned char){63,236,162,88,220,169,51,22,63,225,53,200,17,53,200,17}
        ,(vector unsigned char){63,236,187,38,100,204,252,246,63,225,44,139,137,237,192,172}
        ,(vector unsigned char){63,236,211,230,160,202,137,7,63,225,35,88,231,93,48,51}
        ,(vector unsigned char){63,236,236,153,158,220,82,3,63,225,26,48,25,167,72,38}
        ,(vector unsigned char){63,237,5,63,109,38,8,150,63,225,17,17,17,17,17,17}
        ,(vector unsigned char){63,237,29,216,25,180,195,241,63,225,7,251,190,1,16,128}
        ,(vector unsigned char){63,237,54,99,178,127,49,213,63,224,254,240,16,254,240,17}
        ,(vector unsigned char){63,237,78,226,69,101,198,43,63,224,245,237,250,179,37,162}
        ,(vector unsigned char){63,237,103,83,224,50,234,15,63,224,236,245,107,230,156,144}
        ,(vector unsigned char){63,237,127,184,144,155,42,108,63,224,228,6,85,130,96,17}
        ,(vector unsigned char){63,237,152,16,100,61,102,21,63,224,219,32,168,143,70,150}
        ,(vector unsigned char){63,237,176,91,104,162,251,101,63,224,210,68,86,53,158,58}
        ,(vector unsigned char){63,237,200,153,171,63,245,108,63,224,201,113,79,188,218,59}
        ,(vector unsigned char){63,237,224,203,57,115,56,164,63,224,192,167,134,139,65,113}
        ,(vector unsigned char){63,237,248,240,32,134,175,44,63,224,183,230,236,37,157,200}
        ,(vector unsigned char){63,238,17,8,109,175,116,150,63,224,175,47,114,46,236,181}
        ,(vector unsigned char){63,238,41,20,46,14,1,64,63,224,166,129,10,104,16,167}
        ,(vector unsigned char){63,238,65,19,110,174,85,61,63,224,157,219,166,175,131,96}
        ,(vector unsigned char){63,238,89,6,60,136,34,206,63,224,149,63,57,1,9,84}
        ,(vector unsigned char){63,238,112,236,164,126,248,111,63,224,140,171,179,117,101,226}
        ,(vector unsigned char){63,238,136,198,179,98,106,115,63,224,132,33,8,66,16,132}
        ,(vector unsigned char){63,238,160,148,117,238,60,58,63,224,123,159,41,184,234,226}
        ,(vector unsigned char){63,238,184,85,248,202,136,251,63,224,115,38,10,71,247,198}
        ,(vector unsigned char){63,238,208,11,72,139,236,35,63,224,106,181,156,121,18,251}
        ,(vector unsigned char){63,238,231,180,113,179,169,80,63,224,98,77,210,241,169,252}
        ,(vector unsigned char){63,238,255,81,128,175,211,228,63,224,89,238,160,114,117,134}
        ,(vector unsigned char){63,239,22,226,129,219,118,48,63,224,81,151,247,215,52,4}
        ,(vector unsigned char){63,239,46,103,129,126,184,69,63,224,73,73,204,22,100,197}
        ,(vector unsigned char){63,239,69,224,139,207,6,85,63,224,65,4,16,65,4,16}
        ,(vector unsigned char){63,239,93,77,172,239,54,190,63,224,56,198,183,130,71,252}
        ,(vector unsigned char){63,239,116,174,240,239,175,174,63,224,48,145,181,31,94,26}
        ,(vector unsigned char){63,239,140,4,99,206,140,105,63,224,40,100,252,119,41,233}
        ,(vector unsigned char){63,239,163,78,17,119,194,51,63,224,32,64,129,2,4,8}
        ,(vector unsigned char){63,239,186,140,5,197,68,223,63,224,24,36,54,81,122,55}
        ,(vector unsigned char){63,239,209,190,76,127,42,249,63,224,16,16,16,16,16,16}
        ,(vector unsigned char){63,239,232,228,241,91,209,160,63,224,8,4,2,1,0,128}
        ,(vector unsigned char){63,240,0,0,0,0,0,0,63,224,0,0,0,0,0,0}
        };
    vector unsigned char var945;
    vector unsigned char var946;
    vector unsigned char var947;
    vector unsigned char var948;
    vector unsigned char var949;
    vector unsigned char var950;
    vector unsigned char var951;
    vector unsigned char var956;
    vector unsigned char var957;
    vector unsigned char var958;
    vector unsigned char var959;
    vector unsigned char var960;
    vector unsigned char var961;
    vector unsigned char var962;
    vector unsigned char var963;
    vector unsigned char var964;
    vector unsigned char var965;
    vector unsigned char var966;
    vector unsigned char var967;
    vector unsigned char var968;
    vector unsigned char var969;
    vector unsigned char var970;
    vector unsigned char var971;
    vector unsigned char var973;
    vector unsigned char var974;
    vector unsigned char var975;
    vector unsigned char var978;
    vector unsigned char var979;
    vector unsigned char var980;
    vector unsigned char var981;
    vector unsigned char var982;
    vector unsigned char var983;
    vector unsigned char var984;
    vector unsigned char var985;
    vector unsigned char var986;
    vector unsigned char var987;
    vector unsigned char var988;
    vector unsigned char var989;
    vector unsigned char var990;
    vector unsigned char var991;
    vector unsigned char var992;
    vector unsigned char var993;
    vector unsigned char var994;
    vector unsigned char var995;
    vector unsigned char var996;
    vector unsigned char var997;
    vector unsigned char var998;
    vector unsigned char var999;
    var1000=(vector unsigned char){191,231,21,71,101,42,147,236,191,231,21,71,101,43,118,234};
    var1003=(vector unsigned char){63,247,21,71,101,43,130,251,63,247,21,71,101,43,130,254};
    var1006=(vector unsigned char){128,192,0,1,128,192,4,5,128,192,8,9,128,192,12,13};
    var1009=(vector unsigned char){65,48,0,0,0,0,0,0,65,48,0,0,0,0,0,0};
    var1010=(vector unsigned char){16,17,1,2,16,17,5,6,16,17,9,10,16,17,13,14};
    var1014=(vector unsigned char){65,48,243,255,0,0,0,0,65,48,243,255,0,0,0,0};
    var1016=(vector unsigned char){64,112,0,0,64,112,0,0,64,112,0,0,64,112,0,0};
    var1023=(vector unsigned char){0,1,2,3,4,5,6,7,16,17,18,19,20,21,22,23};
    var1028=(vector unsigned char){64,187,255,0,0,0,0,0,64,187,255,0,0,0,0,0};
    var1036=(vector unsigned char){20,21,22,23,4,5,6,7,28,29,30,31,12,13,14,15};
    var1038=(vector unsigned char){4,5,6,7,128,128,128,128,12,13,14,15,128,128,128,128};
    var1071=(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0};
    var1074=(vector unsigned char){192,144,200,0,192,144,200,0,192,144,200,0,192,144,200,0};
    var1076=(vector unsigned char){255,240,0,0,255,240,0,0,255,240,0,0,255,240,0,0};
    var1088=(vector unsigned char){63,131,184,34,119,255,164,239,63,131,184,34,119,255,164,239};
    var1089=(vector unsigned char){63,172,107,7,252,94,100,87,63,172,107,7,252,94,100,87};
    var1091=(vector unsigned char){63,206,191,189,255,141,180,166,63,206,191,189,255,141,180,166};
    var1093=(vector unsigned char){63,230,46,66,254,250,57,217,63,230,46,66,254,250,57,217};
    var1095=(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0};
    var1099=(vector unsigned char){0,16,0,0,0,16,0,0,0,16,0,0,0,16,0,0};
    var1100=(vector unsigned char){64,184,1,0,64,184,1,0,64,184,1,0,64,184,1,0};
    var1102=(vector unsigned char){64,191,255,0,64,191,255,0,64,191,255,0,64,191,255,0};
    var1112=(vector unsigned char){128,128,128,3,128,128,128,7,128,128,128,11,128,128,128,15};
    var1118=(vector unsigned char){0,1,2,3,4,5,6,7,24,25,26,27,28,29,30,31};
    var1122=(vector unsigned char){63,224,0,0,63,224,0,0,63,224,0,0,63,224,0,0};
    var1131=(vector unsigned char){67,48,0,0,0,0,0,0,67,48,0,0,0,0,0,0};
    var1139=(vector unsigned char){0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    var1140=(vector unsigned char){127,248,0,0,127,248,0,0,127,248,0,0,127,248,0,0};
    var1151=(vector unsigned char){127,255,255,255,127,255,255,255,127,255,255,255,127,255,255,255};
    var1155=(vector unsigned char){0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    var1206=(vector unsigned char){0,1,2,3,0,1,2,3,8,9,10,11,8,9,10,11};
    var945=(vector unsigned char){128,0,0,0,0,0,0,0,128,0,0,0,0,0,0,0};
    var947=(vector unsigned char){79,240,0,0,0,0,0,0,79,240,0,0,0,0,0,0};
    var949=(vector unsigned char){0,16,0,0,0,0,0,0,0,16,0,0,0,0,0,0};
    var956=(vector unsigned char){0,1,2,3,16,17,18,19,8,9,10,11,24,25,26,27};
    var959=(vector unsigned char){128,128,128,1,128,128,128,5,128,128,128,9,128,128,128,13};
    var965=(vector unsigned char){8,9,10,11,12,13,14,15,24,25,26,27,28,29,30,31};
    var967=(vector unsigned char){63,240,0,0,63,240,0,0,63,240,0,0,63,240,0,0};
    var968=(vector unsigned char){127,240,0,0,127,240,0,0,127,240,0,0,127,240,0,0};
    var970=(vector unsigned char){16,17,18,19,4,5,6,7,24,25,26,27,12,13,14,15};
    var973=(vector unsigned char){3,255,0,0,3,255,0,0,3,255,0,0,3,255,0,0};
    var974=(vector unsigned char){16,17,1,19,20,21,5,23,24,25,9,27,28,29,13,31};
    var979=(vector unsigned char){128,128,2,128,128,128,6,128,128,128,10,128,128,128,14,128};
    var983=(vector unsigned char){0,1,2,3,128,128,128,128,8,9,10,11,128,128,128,128};
    var987=(vector unsigned char){63,210,79,219,236,237,146,47,63,210,138,182,142,167,246,240};
    var988=(vector unsigned char){0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7};
    var989=(vector unsigned char){1,1,1,1,1,1,1,1,9,9,9,9,9,9,9,9};
    var991=(vector unsigned char){8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8};
    var994=(vector unsigned char){191,215,21,35,73,169,220,21,191,215,21,62,242,149,5,214};
    var997=(vector unsigned char){63,222,199,9,206,139,7,124,63,222,199,9,221,188,101,203};
    var942=(vector unsigned char)var942In;
    var943=(vector unsigned char)var943In;
    var1178=(vector unsigned char)si_dftsv((qword)var942,(int)48);
    var1169=(vector unsigned char)si_dftsv((qword)var942,(int)12);
    var1192=(vector unsigned char)si_dfceq((qword)var943,(qword)var1155);
    var1145=(vector unsigned char)si_dftsv((qword)var943,(int)64);
    var1141=(vector unsigned char)si_dftsv((qword)var942,(int)64);
    var1187=(vector unsigned char)si_dfceq((qword)var942,(qword)var1071);
    var1195=(vector unsigned char)si_shufb((qword)var1192,(qword)var1192,(qword)var956);
    var1190=(vector unsigned char)si_shufb((qword)var1187,(qword)var1187,(qword)var956);
    var1196=(vector unsigned char)si_or((qword)var1190,(qword)var1195);
    var1181=(vector unsigned char)si_shufb((qword)var1178,(qword)var1178,(qword)var956);
    var1174=(vector unsigned char)si_shufb((qword)var943,(qword)var943,(qword)var956);
    var1176=(vector unsigned char)si_clgt((qword)var1174,(qword)var1151);
    var1201=(vector unsigned char)si_and((qword)var1181,(qword)var1176);
    var1182=(vector unsigned char)si_andc((qword)var1181,(qword)var1176);
    var1172=(vector unsigned char)si_shufb((qword)var1169,(qword)var1169,(qword)var956);
    var1200=(vector unsigned char)si_andc((qword)var1172,(qword)var1176);
    var1202=(vector unsigned char)si_or((qword)var1200,(qword)var1201);
    var1177=(vector unsigned char)si_and((qword)var1172,(qword)var1176);
    var1183=(vector unsigned char)si_or((qword)var1177,(qword)var1182);
    var1150=(vector unsigned char)si_shufb((qword)var942,(qword)var942,(qword)var956);
    var1152=(vector unsigned char)si_clgt((qword)var1150,(qword)var1151);
    var1148=(vector unsigned char)si_shufb((qword)var1145,(qword)var1145,(qword)var956);
    var1144=(vector unsigned char)si_shufb((qword)var1141,(qword)var1141,(qword)var956);
    var1133=(vector unsigned char)si_selb((qword)var1131,(qword)var943,(qword)var945);
    var1134=(vector unsigned char)si_dfa((qword)var943,(qword)var1133);
    var1153=(vector unsigned char)si_dfs((qword)var1134,(qword)var1133);
    var1154=(vector unsigned char)si_dfs((qword)var943,(qword)var1153);
    var1156=(vector unsigned char)si_dfceq((qword)var1154,(qword)var1155);
    var1163=(vector unsigned char)si_shufb((qword)var1156,(qword)var1156,(qword)var956);
    var1164=(vector unsigned char)si_andc((qword)var1152,(qword)var1163);
    var1165=(vector unsigned char)si_or((qword)var1148,(qword)var1164);
    var1166=(vector unsigned char)si_or((qword)var1144,(qword)var1165);
    var1203=(vector unsigned char)si_or((qword)var1196,(qword)var1166);
    var1204=(vector unsigned char)si_or((qword)var1202,(qword)var1203);
    var1205=(vector unsigned char)si_or((qword)var1183,(qword)var1204);
    var1207=(vector unsigned char)si_shufb((qword)var1205,(qword)var1205,(qword)var1206);
    var1167=(vector unsigned char)si_selb((qword)var1139,(qword)var1140,(qword)var1166);
    var1184=(vector unsigned char)si_selb((qword)var1167,(qword)var968,(qword)var1183);
    var1197=(vector unsigned char)si_selb((qword)var1184,(qword)var967,(qword)var1196);
    var1199=(vector unsigned char)si_shufb((qword)var1197,(qword)var1197,(qword)var983);
    var1135=(vector unsigned char)si_rotqbyi((qword)var1134,(int)7);
    var1136=(vector unsigned char)si_rotqbii((qword)var1135,(int)63);
    var1137=(vector unsigned char)si_and((qword)var1136,(qword)var942);
    var946=(vector unsigned char)si_andc((qword)var942,(qword)var945);
    var950=(vector unsigned char)si_dfcgt((qword)var949,(qword)var946);
    var1018=(vector unsigned char)si_shufb((qword)var950,(qword)var950,(qword)var956);
    var1019=(vector unsigned char)si_and((qword)var1016,(qword)var1018);
    var1057=(vector unsigned char)si_shufb((qword)var1019,(qword)var1019,(qword)var1038);
    var1021=(vector unsigned char)si_shufb((qword)var1019,(qword)var1019,(qword)var983);
    var948=(vector unsigned char)si_dfm((qword)var946,(qword)var947);
    var951=(vector unsigned char)si_selb((qword)var946,(qword)var948,(qword)var950);
    var990=(vector unsigned char)si_shufb((qword)var951,(qword)var951,(qword)var989);
    var992=(vector unsigned char)si_selb((qword)var988,(qword)var990,(qword)var991);
    var1004=(vector unsigned char)si_shufb((qword)var1003,(qword)var1003,(qword)var992);
    var1001=(vector unsigned char)si_shufb((qword)var1000,(qword)var1000,(qword)var992);
    var998=(vector unsigned char)si_shufb((qword)var997,(qword)var997,(qword)var992);
    var995=(vector unsigned char)si_shufb((qword)var994,(qword)var994,(qword)var992);
    var993=(vector unsigned char)si_shufb((qword)var987,(qword)var987,(qword)var992);
    var957=(vector unsigned char)si_shufb((qword)var951,(qword)var951,(qword)var956);
    var1007=(vector unsigned char)si_shufb((qword)var957,(qword)var957,(qword)var1006);
    var1008=(vector unsigned char)si_rotqbii((qword)var1007,(int)4);
    var1011=(vector unsigned char)si_shufb((qword)var1008,(qword)var1009,(qword)var1010);
    var1054=(vector unsigned char)si_shufb((qword)var1011,(qword)var1011,(qword)var1038);
    var1055=(vector unsigned char)si_dfs((qword)var1054,(qword)var1014);
    var1058=(vector unsigned char)si_dfs((qword)var1055,(qword)var1057);
    var1013=(vector unsigned char)si_shufb((qword)var1011,(qword)var1011,(qword)var983);
    var1015=(vector unsigned char)si_dfs((qword)var1013,(qword)var1014);
    var1022=(vector unsigned char)si_dfs((qword)var1015,(qword)var1021);
    var969=(vector unsigned char)si_selb((qword)var957,(qword)var967,(qword)var968);
    var1037=(vector unsigned char)si_shufb((qword)var951,(qword)var969,(qword)var1036);
    var971=(vector unsigned char)si_shufb((qword)var951,(qword)var969,(qword)var970);
    var958=(vector unsigned char)si_rotqbii((qword)var957,(int)4);
    var975=(vector unsigned char)si_shufb((qword)var958,(qword)var973,(qword)var974);
    var960=(vector unsigned char)si_shufb((qword)var958,(qword)var958,(qword)var959);
    var978=(vector unsigned char)si_rotqbii((qword)var960,(int)1);
    var980=(vector unsigned char)si_shufb((qword)var978,(qword)var978,(qword)var979);
    var981=(vector unsigned char)si_a((qword)var975,(qword)var980);
    var982=(vector unsigned char)si_rotqbii((qword)var981,(int)4);
    var1039=(vector unsigned char)si_shufb((qword)var982,(qword)var982,(qword)var1038);
    var1040=(vector unsigned char)si_dfs((qword)var1037,(qword)var1039);
    var984=(vector unsigned char)si_shufb((qword)var982,(qword)var982,(qword)var983);
    var985=(vector unsigned char)si_dfs((qword)var971,(qword)var984);
    var961=(vector unsigned char)si_rotqbii((qword)var960,(int)4);
    var1032=(vector unsigned char)si_rotqbyi((qword)var961,(int)12);
    var1030=(vector unsigned char)si_rotqbyi((qword)var961,(int)4);
    var963=(vector unsigned char)si_rotqbyi((qword)var961,(int)8);
    var1033=*(vector unsigned char*)(var944.c+spu_extract((vector signed int)var1032,0));
    var1031=*(vector unsigned char*)(var944.c+spu_extract((vector signed int)var1030,0));
    var1060=(vector unsigned char)si_shufb((qword)var1031,(qword)var1033,(qword)var1023);
    var1061=(vector unsigned char)si_dfa((qword)var1058,(qword)var1060);
    var1035=(vector unsigned char)si_shufb((qword)var1031,(qword)var1033,(qword)var965);
    var1041=(vector unsigned char)si_dfm((qword)var1035,(qword)var1040);
    var1046=(vector unsigned char)si_dfma((qword)var1041,(qword)var993,(qword)var995);
    var1048=(vector unsigned char)si_dfma((qword)var1041,(qword)var1046,(qword)var998);
    var1050=(vector unsigned char)si_dfma((qword)var1041,(qword)var1048,(qword)var1001);
    var1052=(vector unsigned char)si_dfma((qword)var1041,(qword)var1050,(qword)var1004);
    var1062=(vector unsigned char)si_dfma((qword)var1041,(qword)var1052,(qword)var1061);
    var1063=(vector unsigned char)si_dfm((qword)var943,(qword)var1062);
    var1064=(vector unsigned char)si_dfa((qword)var1063,(qword)var1028);
    var964=*(vector unsigned char*)(var944.c+spu_extract((vector signed int)var963,0));
    var962=*(vector unsigned char*)(var944.c+spu_extract((vector signed int)var961,0));
    var1024=(vector unsigned char)si_shufb((qword)var962,(qword)var964,(qword)var1023);
    var1025=(vector unsigned char)si_dfa((qword)var1022,(qword)var1024);
    var966=(vector unsigned char)si_shufb((qword)var962,(qword)var964,(qword)var965);
    var986=(vector unsigned char)si_dfm((qword)var966,(qword)var985);
    var996=(vector unsigned char)si_dfma((qword)var986,(qword)var993,(qword)var995);
    var999=(vector unsigned char)si_dfma((qword)var986,(qword)var996,(qword)var998);
    var1002=(vector unsigned char)si_dfma((qword)var986,(qword)var999,(qword)var1001);
    var1005=(vector unsigned char)si_dfma((qword)var986,(qword)var1002,(qword)var1004);
    var1026=(vector unsigned char)si_dfma((qword)var986,(qword)var1005,(qword)var1025);
    var1027=(vector unsigned char)si_dfm((qword)var943,(qword)var1026);
    var1073=(vector unsigned char)si_shufb((qword)var1027,(qword)var1063,(qword)var956);
    var1077=(vector unsigned char)si_clgt((qword)var1073,(qword)var1076);
    var1075=(vector unsigned char)si_clgt((qword)var1073,(qword)var1074);
    var1078=(vector unsigned char)si_andc((qword)var1075,(qword)var1077);
    var1029=(vector unsigned char)si_dfa((qword)var1027,(qword)var1028);
    var1066=(vector unsigned char)si_shufb((qword)var1029,(qword)var1064,(qword)var956);
    var1113=(vector unsigned char)si_shufb((qword)var1066,(qword)var1066,(qword)var1112);
    var1114=(vector unsigned char)si_rotqbii((qword)var1113,(int)4);
    var1116=(vector unsigned char)si_rotqbyi((qword)var1114,(int)8);
    var1117=*(vector unsigned char*)(var1111.c+spu_extract((vector signed int)var1116,0));
    var1115=*(vector unsigned char*)(var1111.c+spu_extract((vector signed int)var1114,0));
    var1119=(vector unsigned char)si_shufb((qword)var1115,(qword)var1117,(qword)var1118);
    var1103=(vector unsigned char)si_cgt((qword)var1102,(qword)var1066);
    var1101=(vector unsigned char)si_cgt((qword)var1100,(qword)var1066);
    var1104=(vector unsigned char)si_orc((qword)var1101,(qword)var1103);
    var1097=(vector unsigned char)si_rotqbii((qword)var1066,(int)4);
    var1098=(vector unsigned char)si_rotqbyi((qword)var1097,(int)1);
    var1123=(vector unsigned char)si_a((qword)var1122,(qword)var1098);
    var1124=(vector unsigned char)si_selb((qword)var967,(qword)var1123,(qword)var1101);
    var1125=(vector unsigned char)si_selb((qword)var968,(qword)var1124,(qword)var1103);
    var1105=(vector unsigned char)si_selb((qword)var1098,(qword)var1099,(qword)var1104);
    var1107=(vector unsigned char)si_and((qword)var1105,(qword)var968);
    var1109=(vector unsigned char)si_shufb((qword)var1107,(qword)var1107,(qword)var983);
    var1083=(vector unsigned char)si_ceq((qword)var1066,(qword)var968);
    var1080=(vector unsigned char)si_ceq((qword)var1066,(qword)var1076);
    var1081=(vector unsigned char)si_or((qword)var1078,(qword)var1080);
    var1126=(vector unsigned char)si_andc((qword)var1125,(qword)var1081);
    var1127=(vector unsigned char)si_and((qword)var1126,(qword)var968);
    var1129=(vector unsigned char)si_shufb((qword)var1127,(qword)var1127,(qword)var983);
    var1084=(vector unsigned char)si_or((qword)var1081,(qword)var1083);
    var1086=(vector unsigned char)si_shufb((qword)var1084,(qword)var1084,(qword)var983);
    var1068=(vector unsigned char)si_shufb((qword)var1066,(qword)var1066,(qword)var983);
    var1069=(vector unsigned char)si_dfs((qword)var1068,(qword)var1028);
    var1070=(vector unsigned char)si_dfs((qword)var1027,(qword)var1069);
    var1087=(vector unsigned char)si_selb((qword)var1070,(qword)var1071,(qword)var1086);
    var1090=(vector unsigned char)si_dfma((qword)var1087,(qword)var1088,(qword)var1089);
    var1092=(vector unsigned char)si_dfma((qword)var1087,(qword)var1090,(qword)var1091);
    var1094=(vector unsigned char)si_dfma((qword)var1087,(qword)var1092,(qword)var1093);
    var1096=(vector unsigned char)si_dfma((qword)var1087,(qword)var1094,(qword)var1095);
    var1110=(vector unsigned char)si_dfm((qword)var1096,(qword)var1109);
    var1120=(vector unsigned char)si_dfm((qword)var1110,(qword)var1119);
    var1130=(vector unsigned char)si_dfm((qword)var1120,(qword)var1129);
    var1138=(vector unsigned char)si_selb((qword)var1130,(qword)var1137,(qword)var945);
    var1208=(vector double)si_selb((qword)var1138,(qword)var1199,(qword)var1207);
    return var1208;}

#endif /* MASS_POW_H */
