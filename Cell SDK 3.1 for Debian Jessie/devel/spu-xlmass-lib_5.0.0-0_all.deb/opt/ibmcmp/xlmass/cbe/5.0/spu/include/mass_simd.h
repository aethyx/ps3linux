/*---------------------------------------------------------------*/
/* C declarations for the SIMD MASS functions                    */
/* that are not in SDK simdmath.h.                               */
/*---------------------------------------------------------------*/

/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2007.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

/* SCCS ID STRING    14  1.13 9/11/08 14:46:49        9/11/08 21:08:53 */

#ifdef __cplusplus
extern "C" {
#endif

vector float qdrtf4(vector float vx);
vector float rcbrtf4(vector float vx);
vector float rqdrtf4(vector float vx);

vector double rcbrtd2(vector double vx);
vector double rqdrtd2(vector double vx);
vector double qdrtd2(vector double vx);

#ifdef __cplusplus
}
#endif
