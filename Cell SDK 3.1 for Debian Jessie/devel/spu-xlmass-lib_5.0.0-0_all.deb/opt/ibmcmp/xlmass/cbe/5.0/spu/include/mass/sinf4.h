/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2007.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

#ifndef MASS_SIN_H
#define MASS_SIN_H 1
#include <spu_intrinsics.h>
static __inline vector float _sinf4(vector float var1){
    vector float var10;
    vector float var11;
    vector float var12;
    vector float var13;
    vector float var14;
    vector float var15;
    vector float var16;
    vector float var17;
    vector float var18;
    vector float var19;
    vector float var2;
    vector float var20;
    vector float var21;
    vector float var22;
    vector float var23;
    vector float var24;
    vector float var25;
    vector float var26;
    vector float var27;
    vector float var28;
    vector float var29;
    vector float var3;
    vector float var30;
    vector float var31;
    vector float var32;
    vector float var33;
    vector float var34;
    vector float var35;
    vector float var36;
    vector float var37;
    vector float var38;
    vector float var39;
    vector float var4;
    vector float var40;
    vector float var41;
    vector float var42;
    vector float var43;
    vector float var44;
    vector float var5;
    vector float var6;
    vector float var7;
    vector float var8;
    vector float var9;
    var11=(vector float)(vector unsigned char){181,171,187,211,181,171,187,211,181,171,187,211,181,171,187,211};
    var14=(vector float)(vector unsigned char){58,126,0,0,58,126,0,0,58,126,0,0,58,126,0,0};
    var15=(vector float)(vector unsigned char){64,73,0,0,64,73,0,0,64,73,0,0,64,73,0,0};
    var2=(vector float)(vector unsigned char){62,162,249,132,62,162,249,132,62,162,249,132,62,162,249,132};
    var20=(vector float)(vector unsigned char){185,80,13,5,185,78,239,206,185,77,42,181,185,74,137,57};
    var21=(vector float)(vector unsigned char){185,71,18,97,185,66,207,97,185,61,203,121,185,56,19,200};
    var22=(vector float)(vector unsigned char){0,1,2,3,0,1,2,3,0,1,2,3,0,1,2,3};
    var26=(vector float)(vector unsigned char){2,2,2,2,6,6,6,6,10,10,10,10,14,14,14,14};
    var28=(vector float)(vector unsigned char){28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28};
    var31=(vector float)(vector unsigned char){60,8,136,141,60,8,135,237,60,8,132,79,60,8,120,216};
    var32=(vector float)(vector unsigned char){60,8,94,135,60,8,44,106,60,7,215,237,60,7,85,59};
    var35=(vector float)(vector unsigned char){190,42,170,171,190,42,170,170,190,42,170,160,190,42,170,92};
    var36=(vector float)(vector unsigned char){190,42,169,79,190,42,166,57,190,42,158,199,190,42,143,43};
    var39=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,127,255,254};
    var40=(vector float)(vector unsigned char){63,127,255,240,63,127,255,174,63,127,254,206,63,127,252,79};
    var5=(vector float)(vector unsigned char){0,0,32,0,0,0,32,0,0,0,32,0,0,0,32,0};
    var9=(vector float)(vector unsigned char){2,128,128,128,6,128,128,128,10,128,128,128,14,128,128,128};
    var3=(vector float)si_fm((qword)var1,(qword)var2);
    var4=(vector float)si_cflts((qword)var3,(int)14);
    var6=(vector float)si_a((qword)var4,(qword)var5);
    var23=(vector float)si_rotqbii((qword)var6,(int)2);
    var24=(vector float)si_cgtbi((qword)var23,(int)-1);
    var25=(vector float)si_xor((qword)var6,(qword)var24);
    var27=(vector float)si_shufb((qword)var25,(qword)var25,(qword)var26);
    var29=(vector float)si_selb((qword)var22,(qword)var27,(qword)var28);
    var41=(vector float)si_shufb((qword)var39,(qword)var40,(qword)var29);
    var37=(vector float)si_shufb((qword)var35,(qword)var36,(qword)var29);
    var33=(vector float)si_shufb((qword)var31,(qword)var32,(qword)var29);
    var30=(vector float)si_shufb((qword)var20,(qword)var21,(qword)var29);
    var12=(vector float)si_rotmai((qword)var6,(int)-14);
    var13=(vector float)si_csflt((qword)var12,(int)0);
    var16=(vector float)si_fnms((qword)var15,(qword)var13,(qword)var1);
    var17=(vector float)si_fnms((qword)var14,(qword)var13,(qword)var16);
    var18=(vector float)si_fnms((qword)var11,(qword)var13,(qword)var17);
    var19=(vector float)si_fm((qword)var18,(qword)var18);
    var34=(vector float)si_fma((qword)var19,(qword)var30,(qword)var33);
    var38=(vector float)si_fma((qword)var19,(qword)var34,(qword)var37);
    var42=(vector float)si_fma((qword)var19,(qword)var38,(qword)var41);
    var43=(vector float)si_fm((qword)var18,(qword)var42);
    var7=(vector float)si_rotqbii((qword)var6,(int)1);
    var8=(vector float)si_andbi((qword)var7,(int)128);
    var10=(vector float)si_shufb((qword)var8,(qword)var8,(qword)var9);
    var44=(vector float)si_xor((qword)var10,(qword)var43);
    return var44;
}

#endif /* MASS_SIN_H */
