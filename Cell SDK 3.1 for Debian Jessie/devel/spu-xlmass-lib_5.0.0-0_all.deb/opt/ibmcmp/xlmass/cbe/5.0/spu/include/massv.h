/*-----------------------------------------------------------------*/
/* C declarations for the vector MASS functions                    */
/*-----------------------------------------------------------------*/

/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2007.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

/* SCCS ID STRING    16  1.10 8/29/08 13:59:19        9/11/08 21:08:38 */

#ifdef __cplusplus
  extern "C" {
#endif

void vsacosh(float *z, float *x, int *count);
void vsacos(float *z, float *x, int *count);
void vsasinh(float *z, float *x, int *count);
void vsasin(float *z, float *x, int *count);
void vsatan2(float *z, float *x, float *y, int *count);
void vsatanh(float *z, float *x, int *count);
void vsatan(float *z, float *x, int *count);
void vscbrt(float *z, float *x, int *count);
void vscosh(float *z, float *x, int *count);
void vscosisin(float *z, float *x, int *count);
void vscos(float *z, float *x, int *count);
void vsdiv(float *z, float *x, float *y, int *count);
void vserfc(float *z, float *x, int *count);
void vserf(float *z, float *x, int *count);
void vsexpm1(float *z, float *x, int *count);
void vsexp(float *z, float *x, int *count);
void vshypot(float *z, float *x, float *y, int *count);
void vslgamma(float *z, float *x, int *count);
void vslog10(float *z, float *x, int *count);
void vslog1p(float *z, float *x, int *count);
void vslog2(float *z, float *x, int *count);
void vslog(float *z, float *x, int *count);
void vspow(float *z, float *x, float *y, int *count);
void vsqdrt(float *z, float *x, int *count);
void vsrcbrt(float *z, float *x, int *count);
void vsrec(float *z, float *x, int *count);
void vsrqdrt(float *z, float *x, int *count);
void vsrsqrt(float *z, float *x, int *count);
void vssincos(float *zsin, float *zcos, float *x, int *count);
void vssinh(float *z, float *x, int *count);
void vssin(float *z, float *x, int *count);
void vssqrt(float *z, float *x, int *count);
void vstanh(float *z, float *x, int *count);
void vstan(float *z, float *x, int *count);

void vacos(double *z, double *x, int *count);
void vacosh(double *z, double *x, int *count);
void vasin(double *z, double *x, int *count);
void vasinh(double *z, double *x, int *count);
void vatan(double *z, double *x, int *count);
void vatan2(double *z, double *x, double *y, int *count);
void vatanh(double *z, double *x, int *count);
void vcbrt(double *z, double *x, int *count);
void vcos(double *z, double *x, int *count);
void vcosh(double *z, double *x, int *count);
void vcosisin(double *z, double *x, int *count);
void vdiv(double *z, double *x, double *y, int *count);
void verf(double *z, double *x, int *count);
void verfc(double *z, double *x, int *count);
void vexp(double *z, double *x, int *count);
void vexp2(double *z, double *x, int *count);
void vexpm1(double *z, double *x, int *count);
void vhypot(double *z, double *x, double *y, int *count);
void vlgamma(double *z, double *x, int *count);
void vlog(double *z, double *x, int *count);
void vlog10(double *z, double *x, int *count);
void vlog1p(double *z, double *x, int *count);
void vlog2(double *z, double *x, int *count);
void vpow(double *z, double *x, double *y, int *count);
void vqdrt(double *z, double *x, int *count);
void vrcbrt(double *z, double *x, int *count);
void vrec(double *z, double *x, int *count);
void vrqdrt(double *z, double *x, int *count);
void vrsqrt(double *z, double *x, int *count);
void vsin(double *z, double *x, int *count);
void vsincos(double *zsin, double *zcos, double *x, int *count);
void vsinh(double *z, double *x, int *count);
void vsqrt(double *z, double *x, int *count);
void vtan(double *z, double *x, int *count);
void vtanh(double *z, double *x, int *count);

unsigned int vpopcnt4 (void *, int *);
unsigned int vpopcnt8 (void *, int *);

#ifdef __cplusplus
}
#endif

