/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2008.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/
#ifndef MASS_RECIP_H
#define MASS_RECIP_H
#include <spu_intrinsics.h>
static __inline vector double _recipd2(vector double var2889In){
    vector unsigned char var2889;
    vector unsigned char var2890;
    vector unsigned char var2891;
    vector unsigned char var2892;
    vector unsigned char var2893;
    vector unsigned char var2894;
    vector unsigned char var2895;
    vector unsigned char var2896;
    vector unsigned char var2897;
    vector unsigned char var2904;
    vector unsigned char var2905;
    vector unsigned char var2906;
    vector unsigned char var2907;
    vector unsigned char var2908;
    vector unsigned char var2909;
    vector unsigned char var2910;
    vector unsigned char var2911;
    vector unsigned char var2912;
    vector unsigned char var2913;
    vector unsigned char var2914;
    vector unsigned char var2915;
    vector unsigned char var2916;
    vector unsigned char var2917;
    vector unsigned char var2918;
    vector unsigned char var2919;
    vector unsigned char var2920;
    vector unsigned char var2921;
    vector unsigned char var2923;
    vector unsigned char var2924;
    vector unsigned char var2925;
    vector unsigned char var2926;
    vector unsigned char var2927;
    vector unsigned char var2928;
    vector unsigned char var2929;
    vector unsigned char var2930;
    vector unsigned char var2932;
    vector unsigned char var2933;
    vector unsigned char var2935;
    vector unsigned char var2936;
    vector unsigned char var2937;
    vector unsigned char var2938;
    vector unsigned char var2939;
    vector unsigned char var2940;
    vector unsigned char var2941;
    vector unsigned char var2942;
    vector unsigned char var2943;
    vector double var2944;
    var2890=(vector unsigned char){75,16,0,0,0,0,0,0,75,16,0,0,0,0,0,0};
    var2892=(vector unsigned char){0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
    var2893=(vector unsigned char){8,0,0,0,0,0,0,0,8,0,0,0,0,0,0,0};
    var2895=(vector unsigned char){16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16};
    var2904=(vector unsigned char){0,1,2,3,16,17,18,19,8,9,10,11,24,25,26,27};
    var2906=(vector unsigned char){128,0,0,0,128,0,0,0,128,0,0,0,128,0,0,0};
    var2908=(vector unsigned char){0,128,128,128,4,128,128,128,8,128,128,128,12,128,128,128};
    var2910=(vector unsigned char){128,1,2,3,128,5,6,7,128,9,10,11,128,13,14,15};
    var2913=(vector unsigned char){98,0,0,0,98,0,0,0,98,0,0,0,98,0,0,0};
    var2917=(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var2924=(vector unsigned char){0,1,2,3,128,128,128,128,8,9,10,11,128,128,128,128};
    var2926=(vector unsigned char){60,48,0,0,0,0,0,0,60,48,0,0,0,0,0,0};
    var2928=(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0};
    var2937=(vector unsigned char){0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    var2940=(vector unsigned char){127,240,0,0,0,0,0,0,127,240,0,0,0,0,0,0};
    var2943=(vector unsigned char){128,0,0,0,0,0,0,0,128,0,0,0,0,0,0,0};
    var2889=(vector unsigned char)var2889In;
    var2938=(vector unsigned char)si_dftsv((qword)var2889,(int)48);
    var2941=(vector unsigned char)si_dfceq((qword)var2889,(qword)var2937);
    var2894=(vector unsigned char)si_dfcmgt((qword)var2893,(qword)var2889);
    var2896=(vector unsigned char)si_selb((qword)var2892,(qword)var2894,(qword)var2895);
    var2891=(vector unsigned char)si_dfm((qword)var2889,(qword)var2890);
    var2897=(vector unsigned char)si_shufb((qword)var2889,(qword)var2891,(qword)var2896);
    var2905=(vector unsigned char)si_shufb((qword)var2897,(qword)var2897,(qword)var2904);
    var2907=(vector unsigned char)si_andc((qword)var2905,(qword)var2906);
    var2911=(vector unsigned char)si_shufb((qword)var2907,(qword)var2907,(qword)var2910);
    var2912=(vector unsigned char)si_rotqbii((qword)var2911,(int)3);
    var2914=(vector unsigned char)si_a((qword)var2912,(qword)var2913);
    var2915=(vector unsigned char)si_frest((qword)var2914);
    var2916=(vector unsigned char)si_fi((qword)var2914,(qword)var2915);
    var2918=(vector unsigned char)si_fnms((qword)var2914,(qword)var2916,(qword)var2917);
    var2919=(vector unsigned char)si_fma((qword)var2918,(qword)var2916,(qword)var2916);
    var2920=(vector unsigned char)si_rotmi((qword)var2919,(int)-3);
    var2909=(vector unsigned char)si_shufb((qword)var2907,(qword)var2907,(qword)var2908);
    var2921=(vector unsigned char)si_sf((qword)var2909,(qword)var2920);
    var2923=(vector unsigned char)si_selb((qword)var2921,(qword)var2905,(qword)var2906);
    var2925=(vector unsigned char)si_shufb((qword)var2923,(qword)var2923,(qword)var2924);
    var2927=(vector unsigned char)si_dfm((qword)var2925,(qword)var2926);
    var2929=(vector unsigned char)si_dfnms((qword)var2897,(qword)var2927,(qword)var2928);
    var2930=(vector unsigned char)si_dfma((qword)var2929,(qword)var2927,(qword)var2927);
    var2932=(vector unsigned char)si_dfnms((qword)var2897,(qword)var2930,(qword)var2928);
    var2933=(vector unsigned char)si_dfma((qword)var2932,(qword)var2930,(qword)var2930);
    var2935=(vector unsigned char)si_dfm((qword)var2933,(qword)var2890);
    var2936=(vector unsigned char)si_shufb((qword)var2933,(qword)var2935,(qword)var2896);
    var2939=(vector unsigned char)si_selb((qword)var2936,(qword)var2937,(qword)var2938);
    var2942=(vector unsigned char)si_selb((qword)var2939,(qword)var2940,(qword)var2941);
    var2944=(vector double)si_selb((qword)var2942,(qword)var2889,(qword)var2943);
    return var2944;}

#endif /* MASS_RECIP_H */
