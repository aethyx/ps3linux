/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2007.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

#ifndef MASS_ACOS_H
#define MASS_ACOS_H 1
#include <spu_intrinsics.h>
static __inline vector float _acosf4(vector float var1){
    vector float var10;
    vector float var11;
    vector float var12;
    vector float var13;
    vector float var14;
    vector float var15;
    vector float var16;
    vector float var17;
    vector float var18;
    vector float var19;
    vector float var2;
    vector float var20;
    vector float var21;
    vector float var22;
    vector float var23;
    vector float var24;
    vector float var25;
    vector float var26;
    vector float var27;
    vector float var28;
    vector float var29;
    vector float var3;
    vector float var30;
    vector float var31;
    vector float var32;
    vector float var33;
    vector float var34;
    vector float var35;
    vector float var36;
    vector float var37;
    vector float var38;
    vector float var39;
    vector float var4;
    vector float var40;
    vector float var41;
    vector float var42;
    vector float var43;
    vector float var44;
    vector float var45;
    vector float var46;
    vector float var47;
    vector float var48;
    vector float var49;
    vector float var5;
    vector float var50;
    vector float var51;
    vector float var52;
    vector float var53;
    vector float var54;
    vector float var55;
    vector float var6;
    vector float var7;
    vector float var8;
    vector float var9;
    var11=(vector float)(vector unsigned char){1,1,1,1,5,5,5,5,9,9,9,9,13,13,13,13};
    var13=(vector float)(vector unsigned char){28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28};
    var17=(vector float)(vector unsigned char){61,159,178,216,61,235,7,12,62,95,218,70,63,6,5,66};
    var18=(vector float)(vector unsigned char){188,255,216,5,188,180,92,54,188,130,89,121,188,59,230,118};
    var2=(vector float)(vector unsigned char){63,201,15,219,63,201,15,219,63,201,15,219,63,201,15,219};
    var20=(vector float)(vector unsigned char){185,231,32,45,61,167,247,130,62,56,112,145,62,201,69,146};
    var21=(vector float)(vector unsigned char){61,140,200,189,61,86,61,206,61,38,52,51,60,232,217,80};
    var24=(vector float)(vector unsigned char){62,42,176,148,62,71,194,6,62,131,223,22,62,200,175,249};
    var25=(vector float)(vector unsigned char){190,43,132,20,190,12,207,62,189,234,111,217,189,182,14,228};
    var28=(vector float)(vector unsigned char){180,206,113,85,61,202,150,112,62,58,169,168,62,154,8,123};
    var29=(vector float)(vector unsigned char){62,252,251,114,62,223,213,39,62,199,188,105,62,170,170,168};
    var3=(vector float)(vector unsigned char){128,0,0,0,128,0,0,0,128,0,0,0,128,0,0,0};
    var32=(vector float)(vector unsigned char){63,128,0,1,63,130,79,166,63,134,191,159,63,142,88,138};
    var33=(vector float)(vector unsigned char){192,22,177,212,192,15,66,102,192,8,167,18,192,0,0,1};
    var36=(vector float)(vector unsigned char){0,0,0,0,62,65,36,168,62,162,185,203,62,231,215,149};
    var37=(vector float)(vector unsigned char){63,114,142,147,63,41,27,57,62,198,81,196,0,0,0,0};
    var43=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var45=(vector float)(vector unsigned char){63,0,0,0,63,0,0,0,63,0,0,0,63,0,0,0};
    var5=(vector float)(vector unsigned char){0,0,0,0,62,64,0,0,62,160,0,0,62,224,0,0};
    var50=(vector float)(vector unsigned char){0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    var51=(vector float)(vector unsigned char){255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255};
    var6=(vector float)(vector unsigned char){63,16,0,0,63,48,0,0,63,80,0,0,63,128,0,0};
    var7=(vector float)(vector unsigned char){0,1,2,3,0,1,2,3,0,1,2,3,0,1,2,3};
    var8=(vector float)(vector unsigned char){62,127,255,255,62,127,255,255,62,127,255,255,62,127,255,255};
    var9=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var4=(vector float)si_andc((qword)var1,(qword)var3);
    var10=(vector float)si_fma((qword)var8,(qword)var4,(qword)var9);
    var12=(vector float)si_shufb((qword)var10,(qword)var10,(qword)var11);
    var14=(vector float)si_selb((qword)var7,(qword)var12,(qword)var13);
    var52=(vector float)si_shufb((qword)var50,(qword)var51,(qword)var14);
    var38=(vector float)si_shufb((qword)var36,(qword)var37,(qword)var14);
    var34=(vector float)si_shufb((qword)var32,(qword)var33,(qword)var14);
    var30=(vector float)si_shufb((qword)var28,(qword)var29,(qword)var14);
    var26=(vector float)si_shufb((qword)var24,(qword)var25,(qword)var14);
    var22=(vector float)si_shufb((qword)var20,(qword)var21,(qword)var14);
    var19=(vector float)si_shufb((qword)var17,(qword)var18,(qword)var14);
    var15=(vector float)si_shufb((qword)var5,(qword)var6,(qword)var14);
    var16=(vector float)si_fs((qword)var4,(qword)var15);
    var23=(vector float)si_fma((qword)var16,(qword)var19,(qword)var22);
    var27=(vector float)si_fma((qword)var16,(qword)var23,(qword)var26);
    var31=(vector float)si_fma((qword)var16,(qword)var27,(qword)var30);
    var35=(vector float)si_fma((qword)var16,(qword)var31,(qword)var34);
    var39=(vector float)si_fma((qword)var16,(qword)var35,(qword)var38);
    var40=(vector float)si_frsqest((qword)var39);
    var41=(vector float)si_fi((qword)var39,(qword)var40);
    var46=(vector float)si_fm((qword)var41,(qword)var45);
    var42=(vector float)si_fm((qword)var39,(qword)var41);
    var44=(vector float)si_fnms((qword)var42,(qword)var41,(qword)var43);
    var47=(vector float)si_fma((qword)var44,(qword)var46,(qword)var41);
    var48=(vector float)si_fm((qword)var39,(qword)var47);
    var49=(vector float)si_fs((qword)var2,(qword)var48);
    var53=(vector float)si_selb((qword)var39,(qword)var49,(qword)var52);
    var54=(vector float)si_selb((qword)var53,(qword)var1,(qword)var3);
    var55=(vector float)si_fs((qword)var2,(qword)var54);
    return var55;
}

#endif /* MASS_ACOS_H */
