/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2008.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/
#ifndef MASS_RSQRT_H
#define MASS_RSQRT_H
#include <spu_intrinsics.h>
static __inline vector double _rsqrtd2(vector double var2945In){
    vector unsigned char var2945;
    vector unsigned char var2946;
    vector unsigned char var2947;
    vector unsigned char var2948;
    vector unsigned char var2949;
    vector unsigned char var2953;
    vector unsigned char var2954;
    vector unsigned char var2955;
    vector unsigned char var2956;
    vector unsigned char var2957;
    vector unsigned char var2958;
    vector unsigned char var2959;
    vector unsigned char var2960;
    vector unsigned char var2961;
    vector unsigned char var2962;
    vector unsigned char var2963;
    vector unsigned char var2964;
    vector unsigned char var2965;
    vector unsigned char var2966;
    vector unsigned char var2967;
    vector unsigned char var2968;
    vector unsigned char var2969;
    vector unsigned char var2970;
    vector unsigned char var2971;
    vector unsigned char var2972;
    vector unsigned char var2973;
    vector unsigned char var2974;
    vector unsigned char var2975;
    vector unsigned char var2976;
    vector unsigned char var2977;
    vector unsigned char var2978;
    vector unsigned char var2979;
    vector unsigned char var2981;
    vector unsigned char var2983;
    vector unsigned char var2984;
    vector unsigned char var2985;
    vector unsigned char var2987;
    vector unsigned char var2989;
    vector unsigned char var2990;
    vector unsigned char var2991;
    vector unsigned char var2992;
    vector unsigned char var2993;
    vector unsigned char var2994;
    vector unsigned char var2995;
    vector unsigned char var2996;
    vector unsigned char var2997;
    vector unsigned char var2998;
    vector unsigned char var2999;
    vector unsigned char var3000;
    vector unsigned char var3001;
    vector unsigned char var3003;
    vector double var3004;
    var2946=(vector unsigned char){67,240,0,0,0,0,0,0,67,240,0,0,0,0,0,0};
    var2953=(vector unsigned char){0,1,2,3,16,17,18,19,8,9,10,11,24,25,26,27};
    var2955=(vector unsigned char){255,240,0,0,255,240,0,0,255,240,0,0,255,240,0,0};
    var2957=(vector unsigned char){128,0,128,128,128,4,128,128,128,8,128,128,128,12,128,128};
    var2960=(vector unsigned char){128,1,2,3,128,5,6,7,128,9,10,11,128,13,14,15};
    var2963=(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var2969=(vector unsigned char){87,240,0,0,87,240,0,0,87,240,0,0,87,240,0,0};
    var2971=(vector unsigned char){0,1,2,3,128,128,128,128,8,9,10,11,128,128,128,128};
    var2974=(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0};
    var2976=(vector unsigned char){63,224,0,0,0,0,0,0,63,224,0,0,0,0,0,0};
    var2991=(vector unsigned char){65,240,0,0,0,0,0,0,65,240,0,0,0,0,0,0};
    var2994=(vector unsigned char){0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    var2995=(vector unsigned char){127,239,255,255,255,255,255,255,127,239,255,255,255,255,255,255};
    var2998=(vector unsigned char){0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1};
    var3001=(vector unsigned char){127,240,0,0,0,0,0,0,127,240,0,0,0,0,0,0};
    var2945=(vector unsigned char)var2945In;
    var2999=(vector unsigned char)si_dfcgt((qword)var2998,(qword)var2945);
    var2996=(vector unsigned char)si_dfcmgt((qword)var2945,(qword)var2995);
    var3003=(vector unsigned char)si_dfceq((qword)var2945,(qword)var2994);
    var2948=(vector unsigned char)si_dftsv((qword)var2945,(int)3);
    var2947=(vector unsigned char)si_dfm((qword)var2945,(qword)var2946);
    var2949=(vector unsigned char)si_selb((qword)var2945,(qword)var2947,(qword)var2948);
    var2954=(vector unsigned char)si_shufb((qword)var2949,(qword)var2949,(qword)var2953);
    var2956=(vector unsigned char)si_a((qword)var2954,(qword)var2955);
    var2961=(vector unsigned char)si_shufb((qword)var2956,(qword)var2956,(qword)var2960);
    var2962=(vector unsigned char)si_rotqbii((qword)var2961,(int)3);
    var2964=(vector unsigned char)si_a((qword)var2962,(qword)var2963);
    var2965=(vector unsigned char)si_frsqest((qword)var2964);
    var2966=(vector unsigned char)si_fi((qword)var2964,(qword)var2965);
    var2967=(vector unsigned char)si_rotmi((qword)var2966,(int)-3);
    var2958=(vector unsigned char)si_shufb((qword)var2956,(qword)var2956,(qword)var2957);
    var2959=(vector unsigned char)si_rotqbii((qword)var2958,(int)7);
    var2968=(vector unsigned char)si_sf((qword)var2959,(qword)var2967);
    var2970=(vector unsigned char)si_a((qword)var2968,(qword)var2969);
    var2972=(vector unsigned char)si_shufb((qword)var2970,(qword)var2970,(qword)var2971);
    var2977=(vector unsigned char)si_dfm((qword)var2972,(qword)var2976);
    var2973=(vector unsigned char)si_dfm((qword)var2949,(qword)var2972);
    var2975=(vector unsigned char)si_dfnms((qword)var2973,(qword)var2972,(qword)var2974);
    var2978=(vector unsigned char)si_dfma((qword)var2975,(qword)var2977,(qword)var2972);
    var2983=(vector unsigned char)si_dfm((qword)var2978,(qword)var2976);
    var2979=(vector unsigned char)si_dfm((qword)var2949,(qword)var2978);
    var2981=(vector unsigned char)si_dfnms((qword)var2979,(qword)var2978,(qword)var2974);
    var2984=(vector unsigned char)si_dfma((qword)var2981,(qword)var2983,(qword)var2978);
    var2989=(vector unsigned char)si_dfm((qword)var2984,(qword)var2976);
    var2985=(vector unsigned char)si_dfm((qword)var2949,(qword)var2984);
    var2987=(vector unsigned char)si_dfnms((qword)var2985,(qword)var2984,(qword)var2974);
    var2990=(vector unsigned char)si_dfma((qword)var2987,(qword)var2989,(qword)var2984);
    var2992=(vector unsigned char)si_dfm((qword)var2990,(qword)var2991);
    var2993=(vector unsigned char)si_selb((qword)var2990,(qword)var2992,(qword)var2948);
    var2997=(vector unsigned char)si_selb((qword)var2993,(qword)var2994,(qword)var2996);
    var3000=(vector unsigned char)si_or((qword)var2997,(qword)var2999);
    var3004=(vector double)si_selb((qword)var3000,(qword)var3001,(qword)var3003);
    return var3004;}

#endif /* MASS_RSQRT_H */
