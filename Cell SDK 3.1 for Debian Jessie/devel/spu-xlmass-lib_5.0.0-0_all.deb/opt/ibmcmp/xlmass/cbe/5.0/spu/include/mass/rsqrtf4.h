/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2007.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

#ifndef MASS_RSQRT_H
#define MASS_RSQRT_H 1
#include <spu_intrinsics.h>
static __inline vector float _rsqrtf4(vector float var1){
    vector float var2;
    vector float var3;
    vector float var4;
    vector float var5;
    vector float var6;
    vector float var7;
    vector float var8;
    vector float var9;
    var5=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var7=(vector float)(vector unsigned char){63,0,0,0,63,0,0,0,63,0,0,0,63,0,0,0};
    var2=(vector float)si_frsqest((qword)var1);
    var3=(vector float)si_fi((qword)var1,(qword)var2);
    var8=(vector float)si_fm((qword)var3,(qword)var7);
    var4=(vector float)si_fm((qword)var1,(qword)var3);
    var6=(vector float)si_fnms((qword)var4,(qword)var3,(qword)var5);
    var9=(vector float)si_fma((qword)var6,(qword)var8,(qword)var3);
    return var9;
}

#endif /* MASS_RSQRT_H */
