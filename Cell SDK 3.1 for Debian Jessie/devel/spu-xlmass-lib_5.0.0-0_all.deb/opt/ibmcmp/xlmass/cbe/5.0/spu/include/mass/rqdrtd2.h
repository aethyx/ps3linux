/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2008.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/
#ifndef MASS_RQDRT_H
#define MASS_RQDRT_H
#include <spu_intrinsics.h>
static __inline vector double _rqdrtd2(vector double var3570In){
    vector unsigned char var3570;
    vector unsigned char var3571;
    vector unsigned char var3572;
    vector unsigned char var3573;
    vector unsigned char var3574;
    vector unsigned char var3575;
    vector unsigned char var3579;
    vector unsigned char var3580;
    vector unsigned char var3581;
    vector unsigned char var3582;
    vector unsigned char var3583;
    vector unsigned char var3584;
    vector unsigned char var3585;
    vector unsigned char var3586;
    vector unsigned char var3587;
    vector unsigned char var3588;
    vector unsigned char var3589;
    vector unsigned char var3590;
    vector unsigned char var3591;
    vector unsigned char var3592;
    vector unsigned char var3593;
    vector unsigned char var3594;
    vector unsigned char var3595;
    vector unsigned char var3596;
    vector unsigned char var3597;
    vector unsigned char var3598;
    vector unsigned char var3599;
    vector unsigned char var3600;
    vector unsigned char var3601;
    vector unsigned char var3602;
    vector unsigned char var3603;
    vector unsigned char var3604;
    vector unsigned char var3605;
    vector unsigned char var3606;
    vector unsigned char var3607;
    vector unsigned char var3608;
    vector unsigned char var3609;
    vector unsigned char var3610;
    vector unsigned char var3612;
    vector unsigned char var3614;
    vector unsigned char var3615;
    vector unsigned char var3616;
    vector unsigned char var3617;
    vector unsigned char var3619;
    vector unsigned char var3621;
    vector unsigned char var3622;
    vector unsigned char var3623;
    vector unsigned char var3624;
    vector unsigned char var3625;
    vector unsigned char var3626;
    vector unsigned char var3627;
    vector unsigned char var3628;
    vector unsigned char var3629;
    vector unsigned char var3630;
    vector unsigned char var3631;
    vector unsigned char var3632;
    vector unsigned char var3633;
    vector unsigned char var3635;
    vector double var3636;
    var3571=(vector unsigned char){67,240,0,0,0,0,0,0,67,240,0,0,0,0,0,0};
    var3573=(vector unsigned char){0,48,0,0,0,0,0,0,0,48,0,0,0,0,0,0};
    var3579=(vector unsigned char){0,1,2,3,16,17,18,19,8,9,10,11,24,25,26,27};
    var3581=(vector unsigned char){255,208,0,0,255,208,0,0,255,208,0,0,255,208,0,0};
    var3583=(vector unsigned char){128,0,128,128,128,4,128,128,128,8,128,128,128,12,128,128};
    var3586=(vector unsigned char){128,1,2,3,128,5,6,7,128,9,10,11,128,13,14,15};
    var3589=(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var3598=(vector unsigned char){71,240,0,0,71,240,0,0,71,240,0,0,71,240,0,0};
    var3600=(vector unsigned char){0,1,2,3,128,128,128,128,8,9,10,11,128,128,128,128};
    var3604=(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0};
    var3606=(vector unsigned char){63,208,0,0,0,0,0,0,63,208,0,0,0,0,0,0};
    var3623=(vector unsigned char){64,240,0,0,0,0,0,0,64,240,0,0,0,0,0,0};
    var3626=(vector unsigned char){0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    var3627=(vector unsigned char){127,239,255,255,255,255,255,255,127,239,255,255,255,255,255,255};
    var3630=(vector unsigned char){0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1};
    var3633=(vector unsigned char){127,240,0,0,0,0,0,0,127,240,0,0,0,0,0,0};
    var3570=(vector unsigned char)var3570In;
    var3631=(vector unsigned char)si_dfcgt((qword)var3630,(qword)var3570);
    var3628=(vector unsigned char)si_dfcmgt((qword)var3570,(qword)var3627);
    var3635=(vector unsigned char)si_dfceq((qword)var3570,(qword)var3626);
    var3574=(vector unsigned char)si_dfcmgt((qword)var3573,(qword)var3570);
    var3572=(vector unsigned char)si_dfm((qword)var3570,(qword)var3571);
    var3575=(vector unsigned char)si_selb((qword)var3570,(qword)var3572,(qword)var3574);
    var3580=(vector unsigned char)si_shufb((qword)var3575,(qword)var3575,(qword)var3579);
    var3582=(vector unsigned char)si_a((qword)var3580,(qword)var3581);
    var3587=(vector unsigned char)si_shufb((qword)var3582,(qword)var3582,(qword)var3586);
    var3588=(vector unsigned char)si_rotqbii((qword)var3587,(int)3);
    var3590=(vector unsigned char)si_a((qword)var3588,(qword)var3589);
    var3591=(vector unsigned char)si_frsqest((qword)var3590);
    var3592=(vector unsigned char)si_fi((qword)var3590,(qword)var3591);
    var3593=(vector unsigned char)si_fm((qword)var3590,(qword)var3592);
    var3594=(vector unsigned char)si_frsqest((qword)var3593);
    var3595=(vector unsigned char)si_fi((qword)var3593,(qword)var3594);
    var3596=(vector unsigned char)si_rotmi((qword)var3595,(int)-3);
    var3584=(vector unsigned char)si_shufb((qword)var3582,(qword)var3582,(qword)var3583);
    var3585=(vector unsigned char)si_rotqbii((qword)var3584,(int)6);
    var3597=(vector unsigned char)si_sf((qword)var3585,(qword)var3596);
    var3599=(vector unsigned char)si_a((qword)var3597,(qword)var3598);
    var3601=(vector unsigned char)si_shufb((qword)var3599,(qword)var3599,(qword)var3600);
    var3607=(vector unsigned char)si_dfm((qword)var3601,(qword)var3606);
    var3602=(vector unsigned char)si_dfm((qword)var3601,(qword)var3601);
    var3603=(vector unsigned char)si_dfm((qword)var3602,(qword)var3602);
    var3605=(vector unsigned char)si_dfnms((qword)var3603,(qword)var3575,(qword)var3604);
    var3608=(vector unsigned char)si_dfma((qword)var3605,(qword)var3607,(qword)var3601);
    var3614=(vector unsigned char)si_dfm((qword)var3608,(qword)var3606);
    var3609=(vector unsigned char)si_dfm((qword)var3608,(qword)var3608);
    var3610=(vector unsigned char)si_dfm((qword)var3609,(qword)var3609);
    var3612=(vector unsigned char)si_dfnms((qword)var3610,(qword)var3575,(qword)var3604);
    var3615=(vector unsigned char)si_dfma((qword)var3612,(qword)var3614,(qword)var3608);
    var3621=(vector unsigned char)si_dfm((qword)var3615,(qword)var3606);
    var3616=(vector unsigned char)si_dfm((qword)var3615,(qword)var3615);
    var3617=(vector unsigned char)si_dfm((qword)var3616,(qword)var3616);
    var3619=(vector unsigned char)si_dfnms((qword)var3617,(qword)var3575,(qword)var3604);
    var3622=(vector unsigned char)si_dfma((qword)var3619,(qword)var3621,(qword)var3615);
    var3624=(vector unsigned char)si_dfm((qword)var3622,(qword)var3623);
    var3625=(vector unsigned char)si_selb((qword)var3622,(qword)var3624,(qword)var3574);
    var3629=(vector unsigned char)si_selb((qword)var3625,(qword)var3626,(qword)var3628);
    var3632=(vector unsigned char)si_or((qword)var3629,(qword)var3631);
    var3636=(vector double)si_selb((qword)var3632,(qword)var3633,(qword)var3635);
    return var3636;}

#endif /* MASS_RQDRT_H */
