/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2007.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

#ifndef MASS_COS_H
#define MASS_COS_H 1
#include <spu_intrinsics.h>
static __inline vector float _cosf4(vector float var1){
    vector float var10;
    vector float var11;
    vector float var12;
    vector float var13;
    vector float var14;
    vector float var15;
    vector float var16;
    vector float var17;
    vector float var18;
    vector float var19;
    vector float var2;
    vector float var20;
    vector float var21;
    vector float var22;
    vector float var23;
    vector float var24;
    vector float var25;
    vector float var26;
    vector float var27;
    vector float var28;
    vector float var29;
    vector float var3;
    vector float var30;
    vector float var31;
    vector float var32;
    vector float var33;
    vector float var34;
    vector float var35;
    vector float var36;
    vector float var37;
    vector float var38;
    vector float var39;
    vector float var4;
    vector float var40;
    vector float var41;
    vector float var42;
    vector float var43;
    vector float var44;
    vector float var45;
    vector float var46;
    vector float var47;
    vector float var48;
    vector float var49;
    vector float var5;
    vector float var50;
    vector float var51;
    vector float var52;
    vector float var53;
    vector float var54;
    vector float var55;
    vector float var56;
    vector float var57;
    vector float var6;
    vector float var7;
    vector float var8;
    vector float var9;
    var10=(vector float)(vector unsigned char){2,128,128,128,6,128,128,128,10,128,128,128,14,128,128,128};
    var12=(vector float)(vector unsigned char){181,171,187,211,181,171,187,211,181,171,187,211,181,171,187,211};
    var15=(vector float)(vector unsigned char){58,126,0,0,58,126,0,0,58,126,0,0,58,126,0,0};
    var16=(vector float)(vector unsigned char){64,73,0,0,64,73,0,0,64,73,0,0,64,73,0,0};
    var2=(vector float)(vector unsigned char){62,162,249,131,62,162,249,131,62,162,249,131,62,162,249,131};
    var20=(vector float)(vector unsigned char){63,201,15,218,63,201,15,218,63,201,15,218,63,201,15,218};
    var23=(vector float)(vector unsigned char){185,80,13,5,185,78,239,206,185,77,42,181,185,74,137,57};
    var24=(vector float)(vector unsigned char){185,71,18,97,185,66,207,97,185,61,203,121,185,56,19,200};
    var25=(vector float)(vector unsigned char){0,1,2,3,0,1,2,3,0,1,2,3,0,1,2,3};
    var29=(vector float)(vector unsigned char){2,2,2,2,6,6,6,6,10,10,10,10,14,14,14,14};
    var3=(vector float)(vector unsigned char){63,0,0,0,63,0,0,0,63,0,0,0,63,0,0,0};
    var31=(vector float)(vector unsigned char){28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28};
    var34=(vector float)(vector unsigned char){60,8,136,141,60,8,135,237,60,8,132,79,60,8,120,216};
    var35=(vector float)(vector unsigned char){60,8,94,135,60,8,44,106,60,7,215,237,60,7,85,59};
    var38=(vector float)(vector unsigned char){190,42,170,171,190,42,170,170,190,42,170,160,190,42,170,92};
    var39=(vector float)(vector unsigned char){190,42,169,79,190,42,166,57,190,42,158,199,190,42,143,43};
    var42=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,127,255,254};
    var43=(vector float)(vector unsigned char){63,127,255,240,63,127,255,174,63,127,254,206,63,127,252,79};
    var46=(vector float)(vector unsigned char){51,128,0,0,51,116,144,134,51,97,97,15,51,69,136,122};
    var47=(vector float)(vector unsigned char){51,34,24,200,50,240,221,70,50,148,71,244,49,200,1,236};
    var49=(vector float)(vector unsigned char){0,0,0,0,48,6,137,153,49,27,251,73,49,210,7,137};
    var50=(vector float)(vector unsigned char){50,88,177,59,50,190,75,107,51,21,187,174,51,89,76,241};
    var6=(vector float)(vector unsigned char){0,0,32,0,0,0,32,0,0,0,32,0,0,0,32,0};
    var4=(vector float)si_fma((qword)var1,(qword)var2,(qword)var3);
    var5=(vector float)si_cflts((qword)var4,(int)14);
    var7=(vector float)si_a((qword)var5,(qword)var6);
    var26=(vector float)si_rotqbii((qword)var7,(int)2);
    var27=(vector float)si_cgtbi((qword)var26,(int)-1);
    var52=(vector float)si_shufb((qword)var27,(qword)var27,(qword)var10);
    var53=(vector float)si_andbi((qword)var52,(int)128);
    var28=(vector float)si_xor((qword)var7,(qword)var27);
    var30=(vector float)si_shufb((qword)var28,(qword)var28,(qword)var29);
    var32=(vector float)si_selb((qword)var25,(qword)var30,(qword)var31);
    var51=(vector float)si_shufb((qword)var49,(qword)var50,(qword)var32);
    var54=(vector float)si_xor((qword)var51,(qword)var53);
    var48=(vector float)si_shufb((qword)var46,(qword)var47,(qword)var32);
    var44=(vector float)si_shufb((qword)var42,(qword)var43,(qword)var32);
    var40=(vector float)si_shufb((qword)var38,(qword)var39,(qword)var32);
    var36=(vector float)si_shufb((qword)var34,(qword)var35,(qword)var32);
    var33=(vector float)si_shufb((qword)var23,(qword)var24,(qword)var32);
    var13=(vector float)si_rotmai((qword)var7,(int)-14);
    var14=(vector float)si_csflt((qword)var13,(int)0);
    var17=(vector float)si_fnms((qword)var16,(qword)var14,(qword)var1);
    var18=(vector float)si_fnms((qword)var15,(qword)var14,(qword)var17);
    var19=(vector float)si_fnms((qword)var12,(qword)var14,(qword)var18);
    var21=(vector float)si_fa((qword)var19,(qword)var20);
    var55=(vector float)si_fma((qword)var21,(qword)var48,(qword)var54);
    var22=(vector float)si_fm((qword)var21,(qword)var21);
    var37=(vector float)si_fma((qword)var22,(qword)var33,(qword)var36);
    var41=(vector float)si_fma((qword)var22,(qword)var37,(qword)var40);
    var45=(vector float)si_fma((qword)var22,(qword)var41,(qword)var44);
    var56=(vector float)si_fma((qword)var21,(qword)var45,(qword)var55);
    var8=(vector float)si_rotqbii((qword)var7,(int)1);
    var9=(vector float)si_andbi((qword)var8,(int)128);
    var11=(vector float)si_shufb((qword)var9,(qword)var9,(qword)var10);
    var57=(vector float)si_xor((qword)var11,(qword)var56);
    return var57;
}

#endif /* MASS_COS_H */
