/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2008.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/
#ifndef MASS_COSISIN_H
#define MASS_COSISIN_H
#include <spu_intrinsics.h>
static __inline void _cosisind2(vector double var2713In,vector double* var2764,vector double* var2766){
    vector unsigned char var2713;
    vector unsigned char var2714;
    vector unsigned char var2715;
    vector unsigned char var2716;
    vector unsigned char var2717;
    vector unsigned char var2718;
    vector unsigned char var2719;
    vector unsigned char var2720;
    vector unsigned char var2721;
    vector unsigned char var2722;
    vector unsigned char var2723;
    vector unsigned char var2724;
    vector unsigned char var2725;
    vector unsigned char var2726;
    vector unsigned char var2727;
    vector unsigned char var2728;
    vector unsigned char var2729;
    vector unsigned char var2730;
    vector unsigned char var2731;
    vector unsigned char var2732;
    vector unsigned char var2733;
    vector unsigned char var2734;
    vector unsigned char var2735;
    static const union {const vector unsigned char v[128];const char c[128*16];} var2736= 
        {(vector unsigned char){63,240,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
        ,(vector unsigned char){63,239,246,33,227,121,109,126,63,169,31,101,241,13,216,20}
        ,(vector unsigned char){63,239,216,141,163,209,37,38,63,185,23,166,188,41,180,44}
        ,(vector unsigned char){63,239,167,85,127,8,165,23,63,194,200,16,110,142,97,58}
        ,(vector unsigned char){63,239,98,151,207,247,92,176,63,200,248,184,60,105,166,11}
        ,(vector unsigned char){63,239,10,126,251,146,48,215,63,207,25,249,123,33,95,27}
        ,(vector unsigned char){63,238,159,65,86,198,45,218,63,210,148,6,46,213,159,6}
        ,(vector unsigned char){63,238,33,33,4,246,134,229,63,213,143,154,117,171,31,221}
        ,(vector unsigned char){63,237,144,107,207,50,141,70,63,216,125,226,166,174,169,99}
        ,(vector unsigned char){63,236,237,122,244,60,199,115,63,219,93,16,9,225,92,192}
        ,(vector unsigned char){63,236,56,178,241,128,189,177,63,222,43,93,56,6,246,59}
        ,(vector unsigned char){63,235,114,131,69,25,110,62,63,224,115,135,153,34,255,238}
        ,(vector unsigned char){63,234,155,102,41,14,161,163,63,225,199,59,57,174,104,200}
        ,(vector unsigned char){63,233,179,224,71,243,135,65,63,227,15,247,252,225,112,53}
        ,(vector unsigned char){63,232,188,128,107,21,23,65,63,228,76,243,37,9,29,214}
        ,(vector unsigned char){63,231,181,223,34,106,175,175,63,229,125,105,52,140,236,160}
        ,(vector unsigned char){63,230,160,158,102,127,59,205,63,230,160,158,102,127,59,205}
        ,(vector unsigned char){63,229,125,105,52,140,236,160,63,231,181,223,34,106,175,175}
        ,(vector unsigned char){63,228,76,243,37,9,29,214,63,232,188,128,107,21,23,65}
        ,(vector unsigned char){63,227,15,247,252,225,112,53,63,233,179,224,71,243,135,65}
        ,(vector unsigned char){63,225,199,59,57,174,104,200,63,234,155,102,41,14,161,163}
        ,(vector unsigned char){63,224,115,135,153,34,255,238,63,235,114,131,69,25,110,62}
        ,(vector unsigned char){63,222,43,93,56,6,246,59,63,236,56,178,241,128,189,177}
        ,(vector unsigned char){63,219,93,16,9,225,92,192,63,236,237,122,244,60,199,115}
        ,(vector unsigned char){63,216,125,226,166,174,169,99,63,237,144,107,207,50,141,70}
        ,(vector unsigned char){63,213,143,154,117,171,31,221,63,238,33,33,4,246,134,229}
        ,(vector unsigned char){63,210,148,6,46,213,159,6,63,238,159,65,86,198,45,218}
        ,(vector unsigned char){63,207,25,249,123,33,95,27,63,239,10,126,251,146,48,215}
        ,(vector unsigned char){63,200,248,184,60,105,166,11,63,239,98,151,207,247,92,176}
        ,(vector unsigned char){63,194,200,16,110,142,97,58,63,239,167,85,127,8,165,23}
        ,(vector unsigned char){63,185,23,166,188,41,180,44,63,239,216,141,163,209,37,38}
        ,(vector unsigned char){63,169,31,101,241,13,216,20,63,239,246,33,227,121,109,126}
        ,(vector unsigned char){0,0,0,0,0,0,0,0,63,240,0,0,0,0,0,0}
        ,(vector unsigned char){191,169,31,101,241,13,216,20,63,239,246,33,227,121,109,126}
        ,(vector unsigned char){191,185,23,166,188,41,180,44,63,239,216,141,163,209,37,38}
        ,(vector unsigned char){191,194,200,16,110,142,97,58,63,239,167,85,127,8,165,23}
        ,(vector unsigned char){191,200,248,184,60,105,166,11,63,239,98,151,207,247,92,176}
        ,(vector unsigned char){191,207,25,249,123,33,95,27,63,239,10,126,251,146,48,215}
        ,(vector unsigned char){191,210,148,6,46,213,159,6,63,238,159,65,86,198,45,218}
        ,(vector unsigned char){191,213,143,154,117,171,31,221,63,238,33,33,4,246,134,229}
        ,(vector unsigned char){191,216,125,226,166,174,169,99,63,237,144,107,207,50,141,70}
        ,(vector unsigned char){191,219,93,16,9,225,92,192,63,236,237,122,244,60,199,115}
        ,(vector unsigned char){191,222,43,93,56,6,246,59,63,236,56,178,241,128,189,177}
        ,(vector unsigned char){191,224,115,135,153,34,255,238,63,235,114,131,69,25,110,62}
        ,(vector unsigned char){191,225,199,59,57,174,104,200,63,234,155,102,41,14,161,163}
        ,(vector unsigned char){191,227,15,247,252,225,112,53,63,233,179,224,71,243,135,65}
        ,(vector unsigned char){191,228,76,243,37,9,29,214,63,232,188,128,107,21,23,65}
        ,(vector unsigned char){191,229,125,105,52,140,236,160,63,231,181,223,34,106,175,175}
        ,(vector unsigned char){191,230,160,158,102,127,59,205,63,230,160,158,102,127,59,205}
        ,(vector unsigned char){191,231,181,223,34,106,175,175,63,229,125,105,52,140,236,160}
        ,(vector unsigned char){191,232,188,128,107,21,23,65,63,228,76,243,37,9,29,214}
        ,(vector unsigned char){191,233,179,224,71,243,135,65,63,227,15,247,252,225,112,53}
        ,(vector unsigned char){191,234,155,102,41,14,161,163,63,225,199,59,57,174,104,200}
        ,(vector unsigned char){191,235,114,131,69,25,110,62,63,224,115,135,153,34,255,238}
        ,(vector unsigned char){191,236,56,178,241,128,189,177,63,222,43,93,56,6,246,59}
        ,(vector unsigned char){191,236,237,122,244,60,199,115,63,219,93,16,9,225,92,192}
        ,(vector unsigned char){191,237,144,107,207,50,141,70,63,216,125,226,166,174,169,99}
        ,(vector unsigned char){191,238,33,33,4,246,134,229,63,213,143,154,117,171,31,221}
        ,(vector unsigned char){191,238,159,65,86,198,45,218,63,210,148,6,46,213,159,6}
        ,(vector unsigned char){191,239,10,126,251,146,48,215,63,207,25,249,123,33,95,27}
        ,(vector unsigned char){191,239,98,151,207,247,92,176,63,200,248,184,60,105,166,11}
        ,(vector unsigned char){191,239,167,85,127,8,165,23,63,194,200,16,110,142,97,58}
        ,(vector unsigned char){191,239,216,141,163,209,37,38,63,185,23,166,188,41,180,44}
        ,(vector unsigned char){191,239,246,33,227,121,109,126,63,169,31,101,241,13,216,20}
        ,(vector unsigned char){191,240,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
        ,(vector unsigned char){191,239,246,33,227,121,109,126,191,169,31,101,241,13,216,20}
        ,(vector unsigned char){191,239,216,141,163,209,37,38,191,185,23,166,188,41,180,44}
        ,(vector unsigned char){191,239,167,85,127,8,165,23,191,194,200,16,110,142,97,58}
        ,(vector unsigned char){191,239,98,151,207,247,92,176,191,200,248,184,60,105,166,11}
        ,(vector unsigned char){191,239,10,126,251,146,48,215,191,207,25,249,123,33,95,27}
        ,(vector unsigned char){191,238,159,65,86,198,45,218,191,210,148,6,46,213,159,6}
        ,(vector unsigned char){191,238,33,33,4,246,134,229,191,213,143,154,117,171,31,221}
        ,(vector unsigned char){191,237,144,107,207,50,141,70,191,216,125,226,166,174,169,99}
        ,(vector unsigned char){191,236,237,122,244,60,199,115,191,219,93,16,9,225,92,192}
        ,(vector unsigned char){191,236,56,178,241,128,189,177,191,222,43,93,56,6,246,59}
        ,(vector unsigned char){191,235,114,131,69,25,110,62,191,224,115,135,153,34,255,238}
        ,(vector unsigned char){191,234,155,102,41,14,161,163,191,225,199,59,57,174,104,200}
        ,(vector unsigned char){191,233,179,224,71,243,135,65,191,227,15,247,252,225,112,53}
        ,(vector unsigned char){191,232,188,128,107,21,23,65,191,228,76,243,37,9,29,214}
        ,(vector unsigned char){191,231,181,223,34,106,175,175,191,229,125,105,52,140,236,160}
        ,(vector unsigned char){191,230,160,158,102,127,59,205,191,230,160,158,102,127,59,205}
        ,(vector unsigned char){191,229,125,105,52,140,236,160,191,231,181,223,34,106,175,175}
        ,(vector unsigned char){191,228,76,243,37,9,29,214,191,232,188,128,107,21,23,65}
        ,(vector unsigned char){191,227,15,247,252,225,112,53,191,233,179,224,71,243,135,65}
        ,(vector unsigned char){191,225,199,59,57,174,104,200,191,234,155,102,41,14,161,163}
        ,(vector unsigned char){191,224,115,135,153,34,255,238,191,235,114,131,69,25,110,62}
        ,(vector unsigned char){191,222,43,93,56,6,246,59,191,236,56,178,241,128,189,177}
        ,(vector unsigned char){191,219,93,16,9,225,92,192,191,236,237,122,244,60,199,115}
        ,(vector unsigned char){191,216,125,226,166,174,169,99,191,237,144,107,207,50,141,70}
        ,(vector unsigned char){191,213,143,154,117,171,31,221,191,238,33,33,4,246,134,229}
        ,(vector unsigned char){191,210,148,6,46,213,159,6,191,238,159,65,86,198,45,218}
        ,(vector unsigned char){191,207,25,249,123,33,95,27,191,239,10,126,251,146,48,215}
        ,(vector unsigned char){191,200,248,184,60,105,166,11,191,239,98,151,207,247,92,176}
        ,(vector unsigned char){191,194,200,16,110,142,97,58,191,239,167,85,127,8,165,23}
        ,(vector unsigned char){191,185,23,166,188,41,180,44,191,239,216,141,163,209,37,38}
        ,(vector unsigned char){191,169,31,101,241,13,216,20,191,239,246,33,227,121,109,126}
        ,(vector unsigned char){0,0,0,0,0,0,0,0,191,240,0,0,0,0,0,0}
        ,(vector unsigned char){63,169,31,101,241,13,216,20,191,239,246,33,227,121,109,126}
        ,(vector unsigned char){63,185,23,166,188,41,180,44,191,239,216,141,163,209,37,38}
        ,(vector unsigned char){63,194,200,16,110,142,97,58,191,239,167,85,127,8,165,23}
        ,(vector unsigned char){63,200,248,184,60,105,166,11,191,239,98,151,207,247,92,176}
        ,(vector unsigned char){63,207,25,249,123,33,95,27,191,239,10,126,251,146,48,215}
        ,(vector unsigned char){63,210,148,6,46,213,159,6,191,238,159,65,86,198,45,218}
        ,(vector unsigned char){63,213,143,154,117,171,31,221,191,238,33,33,4,246,134,229}
        ,(vector unsigned char){63,216,125,226,166,174,169,99,191,237,144,107,207,50,141,70}
        ,(vector unsigned char){63,219,93,16,9,225,92,192,191,236,237,122,244,60,199,115}
        ,(vector unsigned char){63,222,43,93,56,6,246,59,191,236,56,178,241,128,189,177}
        ,(vector unsigned char){63,224,115,135,153,34,255,238,191,235,114,131,69,25,110,62}
        ,(vector unsigned char){63,225,199,59,57,174,104,200,191,234,155,102,41,14,161,163}
        ,(vector unsigned char){63,227,15,247,252,225,112,53,191,233,179,224,71,243,135,65}
        ,(vector unsigned char){63,228,76,243,37,9,29,214,191,232,188,128,107,21,23,65}
        ,(vector unsigned char){63,229,125,105,52,140,236,160,191,231,181,223,34,106,175,175}
        ,(vector unsigned char){63,230,160,158,102,127,59,205,191,230,160,158,102,127,59,205}
        ,(vector unsigned char){63,231,181,223,34,106,175,175,191,229,125,105,52,140,236,160}
        ,(vector unsigned char){63,232,188,128,107,21,23,65,191,228,76,243,37,9,29,214}
        ,(vector unsigned char){63,233,179,224,71,243,135,65,191,227,15,247,252,225,112,53}
        ,(vector unsigned char){63,234,155,102,41,14,161,163,191,225,199,59,57,174,104,200}
        ,(vector unsigned char){63,235,114,131,69,25,110,62,191,224,115,135,153,34,255,238}
        ,(vector unsigned char){63,236,56,178,241,128,189,177,191,222,43,93,56,6,246,59}
        ,(vector unsigned char){63,236,237,122,244,60,199,115,191,219,93,16,9,225,92,192}
        ,(vector unsigned char){63,237,144,107,207,50,141,70,191,216,125,226,166,174,169,99}
        ,(vector unsigned char){63,238,33,33,4,246,134,229,191,213,143,154,117,171,31,221}
        ,(vector unsigned char){63,238,159,65,86,198,45,218,191,210,148,6,46,213,159,6}
        ,(vector unsigned char){63,239,10,126,251,146,48,215,191,207,25,249,123,33,95,27}
        ,(vector unsigned char){63,239,98,151,207,247,92,176,191,200,248,184,60,105,166,11}
        ,(vector unsigned char){63,239,167,85,127,8,165,23,191,194,200,16,110,142,97,58}
        ,(vector unsigned char){63,239,216,141,163,209,37,38,191,185,23,166,188,41,180,44}
        ,(vector unsigned char){63,239,246,33,227,121,109,126,191,169,31,101,241,13,216,20}
        };
    vector unsigned char var2737;
    vector unsigned char var2738;
    vector unsigned char var2739;
    vector unsigned char var2740;
    vector unsigned char var2741;
    vector unsigned char var2742;
    vector unsigned char var2743;
    vector unsigned char var2744;
    vector unsigned char var2745;
    vector unsigned char var2746;
    vector unsigned char var2747;
    vector unsigned char var2748;
    vector unsigned char var2749;
    vector unsigned char var2750;
    vector unsigned char var2751;
    vector unsigned char var2752;
    vector unsigned char var2753;
    vector unsigned char var2754;
    vector unsigned char var2755;
    vector unsigned char var2756;
    vector unsigned char var2757;
    vector unsigned char var2758;
    vector unsigned char var2759;
    vector unsigned char var2760;
    vector unsigned char var2761;
    vector unsigned char var2762;
    vector unsigned char var2763;
    vector unsigned char var2765;
    var2714=(vector unsigned char){128,0,0,0,0,0,0,0,128,0,0,0,0,0,0,0};
    var2716=(vector unsigned char){188,214,176,30,197,65,112,86,188,214,176,30,197,65,112,86};
    var2717=(vector unsigned char){64,52,95,48,109,201,200,131,64,52,95,48,109,201,200,131};
    var2721=(vector unsigned char){67,48,0,0,0,0,0,0,67,48,0,0,0,0,0,0};
    var2727=(vector unsigned char){60,206,31,80,148,242,25,119,60,206,31,80,148,242,25,119};
    var2728=(vector unsigned char){189,181,93,60,185,226,33,218,189,181,93,60,185,226,33,218};
    var2730=(vector unsigned char){62,144,60,31,8,27,90,135,62,144,60,31,8,27,90,135};
    var2732=(vector unsigned char){191,83,189,60,201,190,68,0,191,83,189,60,201,190,68,0};
    var2734=(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0};
    var2738=(vector unsigned char){128,128,128,3,128,128,128,7,128,128,128,11,128,128,128,15};
    var2745=(vector unsigned char){8,9,10,11,12,13,14,15,24,25,26,27,28,29,30,31};
    var2747=(vector unsigned char){189,67,45,44,240,116,158,54,189,67,45,44,240,116,158,54};
    var2748=(vector unsigned char){62,36,102,188,103,117,170,196,62,36,102,188,103,117,170,196};
    var2750=(vector unsigned char){190,244,171,188,230,37,189,202,190,244,171,188,230,37,189,202};
    var2752=(vector unsigned char){63,169,33,251,84,68,45,24,63,169,33,251,84,68,45,24};
    var2755=(vector unsigned char){0,1,2,3,4,5,6,7,16,17,18,19,20,21,22,23};
    var2763=(vector unsigned char){16,17,18,19,20,21,22,23,0,1,2,3,4,5,6,7};
    var2765=(vector unsigned char){24,25,26,27,28,29,30,31,8,9,10,11,12,13,14,15};
    var2713=(vector unsigned char)var2713In;
    var2759=(vector unsigned char)si_and((qword)var2713,(qword)var2714);
    var2715=(vector unsigned char)si_andc((qword)var2713,(qword)var2714);
    var2722=(vector unsigned char)si_dfma((qword)var2715,(qword)var2717,(qword)var2721);
    var2737=(vector unsigned char)si_andbi((qword)var2722,(int)127);
    var2739=(vector unsigned char)si_shufb((qword)var2737,(qword)var2737,(qword)var2738);
    var2740=(vector unsigned char)si_rotqbii((qword)var2739,(int)4);
    var2743=(vector unsigned char)si_rotqbyi((qword)var2740,(int)12);
    var2744=*(vector unsigned char*)(var2736.c+spu_extract((vector signed int)var2743,0));
    var2741=(vector unsigned char)si_rotqbyi((qword)var2740,(int)4);
    var2742=*(vector unsigned char*)(var2736.c+spu_extract((vector signed int)var2741,0));
    var2756=(vector unsigned char)si_shufb((qword)var2742,(qword)var2744,(qword)var2755);
    var2746=(vector unsigned char)si_shufb((qword)var2742,(qword)var2744,(qword)var2745);
    var2723=(vector unsigned char)si_dfs((qword)var2722,(qword)var2721);
    var2718=(vector unsigned char)si_dfm((qword)var2715,(qword)var2717);
    var2724=(vector unsigned char)si_dfs((qword)var2718,(qword)var2723);
    var2719=(vector unsigned char)si_dfms((qword)var2715,(qword)var2717,(qword)var2718);
    var2720=(vector unsigned char)si_dfma((qword)var2715,(qword)var2716,(qword)var2719);
    var2725=(vector unsigned char)si_dfa((qword)var2720,(qword)var2724);
    var2726=(vector unsigned char)si_dfm((qword)var2725,(qword)var2725);
    var2749=(vector unsigned char)si_dfma((qword)var2726,(qword)var2747,(qword)var2748);
    var2751=(vector unsigned char)si_dfma((qword)var2726,(qword)var2749,(qword)var2750);
    var2753=(vector unsigned char)si_dfma((qword)var2726,(qword)var2751,(qword)var2752);
    var2754=(vector unsigned char)si_dfm((qword)var2725,(qword)var2753);
    var2761=(vector unsigned char)si_dfm((qword)var2754,(qword)var2746);
    var2757=(vector unsigned char)si_dfm((qword)var2754,(qword)var2756);
    var2729=(vector unsigned char)si_dfma((qword)var2726,(qword)var2727,(qword)var2728);
    var2731=(vector unsigned char)si_dfma((qword)var2726,(qword)var2729,(qword)var2730);
    var2733=(vector unsigned char)si_dfma((qword)var2726,(qword)var2731,(qword)var2732);
    var2735=(vector unsigned char)si_dfma((qword)var2726,(qword)var2733,(qword)var2734);
    var2762=(vector unsigned char)si_dfms((qword)var2735,(qword)var2756,(qword)var2761);
    var2758=(vector unsigned char)si_dfma((qword)var2735,(qword)var2746,(qword)var2757);
    var2760=(vector unsigned char)si_xor((qword)var2758,(qword)var2759);
    *var2766=(vector double)si_shufb((qword)var2760,(qword)var2762,(qword)var2765);
    *var2764=(vector double)si_shufb((qword)var2760,(qword)var2762,(qword)var2763);}

#endif /* MASS_COSISIN_H */
