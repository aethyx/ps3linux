/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2007.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

#ifndef MASS_LOG2_H
#define MASS_LOG2_H 1
#include <spu_intrinsics.h>
static __inline vector float _log2f4(vector float var1){
    vector float var10;
    vector float var11;
    vector float var12;
    vector float var13;
    vector float var14;
    vector float var15;
    vector float var16;
    vector float var17;
    vector float var18;
    vector float var19;
    vector float var2;
    vector float var20;
    vector float var21;
    vector float var22;
    vector float var23;
    vector float var24;
    vector float var25;
    vector float var26;
    vector float var27;
    vector float var28;
    vector float var29;
    vector float var3;
    vector float var30;
    vector float var31;
    vector float var32;
    vector float var33;
    vector float var34;
    vector float var35;
    vector float var36;
    vector float var37;
    vector float var38;
    vector float var39;
    vector float var4;
    vector float var40;
    vector float var41;
    vector float var42;
    vector float var43;
    vector float var5;
    vector float var6;
    vector float var7;
    vector float var8;
    vector float var9;
    var11=(vector float)(vector unsigned char){7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7};
    var15=(vector float)(vector unsigned char){62,61,61,61,60,60,60,60,99,253,153,66,255,173,115,43};
    var16=(vector float)(vector unsigned char){113,34,63,68,215,253,72,137,21,116,241,0,34,126,116,137};
    var18=(vector float)(vector unsigned char){190,190,190,189,189,189,189,188,180,97,20,203,144,81,28,183};
    var19=(vector float)(vector unsigned char){236,201,174,169,28,156,13,24,181,242,17,200,10,152,208,222};
    var2=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var22=(vector float)(vector unsigned char){62,62,62,62,62,61,61,61,246,172,123,61,17,229,183,118};
    var23=(vector float)(vector unsigned char){10,200,248,86,218,115,185,67,223,200,245,142,133,243,37,176};
    var26=(vector float)(vector unsigned char){191,191,190,190,190,190,190,190,56,17,236,195,164,139,113,56};
    var27=(vector float)(vector unsigned char){169,231,94,88,37,221,49,170,213,250,120,202,89,55,200,43};
    var3=(vector float)(vector unsigned char){0,127,255,255,0,127,255,255,0,127,255,255,0,127,255,255};
    var30=(vector float)(vector unsigned char){63,63,63,63,63,63,63,63,184,164,147,134,118,99,83,56};
    var31=(vector float)(vector unsigned char){170,37,187,77,56,71,11,170,60,138,99,67,80,172,178,60};
    var35=(vector float)(vector unsigned char){128,128,128,0,128,128,128,4,128,128,128,8,128,128,128,12};
    var39=(vector float)(vector unsigned char){0,62,62,62,63,63,63,63,0,46,164,235,21,51,78,128};
    var40=(vector float)(vector unsigned char){0,0,211,58,192,80,174,0,0,210,195,160,27,5,208,0};
    var5=(vector float)(vector unsigned char){63,63,63,63,63,63,63,64,128,144,160,176,192,208,224,0};
    var6=(vector float)(vector unsigned char){0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    var7=(vector float)(vector unsigned char){0,8,16,24,0,8,16,24,0,8,16,24,0,8,16,24};
    var9=(vector float)(vector unsigned char){0,0,0,0,4,4,4,4,8,8,8,8,12,12,12,12};
    var34=(vector float)si_shli((qword)var1,(int)1);
    var36=(vector float)si_shufb((qword)var34,(qword)var34,(qword)var35);
    var37=(vector float)si_ai((qword)var36,(int)-127);
    var38=(vector float)si_csflt((qword)var37,(int)0);
    var8=(vector float)si_roti((qword)var1,(int)4);
    var10=(vector float)si_shufb((qword)var8,(qword)var8,(qword)var9);
    var12=(vector float)si_selb((qword)var7,(qword)var10,(qword)var11);
    var41=(vector float)si_shufb((qword)var39,(qword)var40,(qword)var12);
    var42=(vector float)si_fa((qword)var38,(qword)var41);
    var32=(vector float)si_shufb((qword)var30,(qword)var31,(qword)var12);
    var28=(vector float)si_shufb((qword)var26,(qword)var27,(qword)var12);
    var24=(vector float)si_shufb((qword)var22,(qword)var23,(qword)var12);
    var20=(vector float)si_shufb((qword)var18,(qword)var19,(qword)var12);
    var17=(vector float)si_shufb((qword)var15,(qword)var16,(qword)var12);
    var13=(vector float)si_shufb((qword)var5,(qword)var6,(qword)var12);
    var4=(vector float)si_selb((qword)var2,(qword)var1,(qword)var3);
    var14=(vector float)si_fs((qword)var4,(qword)var13);
    var21=(vector float)si_fma((qword)var14,(qword)var17,(qword)var20);
    var25=(vector float)si_fma((qword)var14,(qword)var21,(qword)var24);
    var29=(vector float)si_fma((qword)var14,(qword)var25,(qword)var28);
    var33=(vector float)si_fma((qword)var14,(qword)var29,(qword)var32);
    var43=(vector float)si_fma((qword)var14,(qword)var33,(qword)var42);
    return var43;
}

#endif /* MASS_LOG2_H */
