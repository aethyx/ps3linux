/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2007.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

#ifndef MASS_RQDRT_H
#define MASS_RQDRT_H 1
#include <spu_intrinsics.h>
static __inline vector float _rqdrtf4(vector float var1){
    vector float var10;
    vector float var11;
    vector float var12;
    vector float var13;
    vector float var14;
    vector float var15;
    vector float var16;
    vector float var17;
    vector float var18;
    vector float var19;
    vector float var2;
    vector float var20;
    vector float var21;
    vector float var22;
    vector float var23;
    vector float var24;
    vector float var25;
    vector float var3;
    vector float var4;
    vector float var5;
    vector float var6;
    vector float var7;
    vector float var8;
    vector float var9;
    var13=(vector float)(vector unsigned char){190,128,0,0,190,128,0,0,190,128,0,0,190,128,0,0};
    var17=(vector float)(vector unsigned char){63,160,0,0,63,160,0,0,63,160,0,0,63,160,0,0};
    var23=(vector float)(vector unsigned char){51,128,0,0,51,128,0,0,51,128,0,0,51,128,0,0};
    var5=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var7=(vector float)(vector unsigned char){63,0,0,0,63,0,0,0,63,0,0,0,63,0,0,0};
    var14=(vector float)si_fm((qword)var13,(qword)var1);
    var2=(vector float)si_frsqest((qword)var1);
    var3=(vector float)si_fi((qword)var1,(qword)var2);
    var8=(vector float)si_fm((qword)var3,(qword)var7);
    var4=(vector float)si_fm((qword)var1,(qword)var3);
    var6=(vector float)si_fnms((qword)var4,(qword)var3,(qword)var5);
    var9=(vector float)si_fma((qword)var6,(qword)var8,(qword)var3);
    var10=(vector float)si_fm((qword)var1,(qword)var9);
    var11=(vector float)si_frsqest((qword)var10);
    var12=(vector float)si_fi((qword)var10,(qword)var11);
    var15=(vector float)si_fm((qword)var12,(qword)var12);
    var16=(vector float)si_fm((qword)var15,(qword)var15);
    var18=(vector float)si_fma((qword)var14,(qword)var16,(qword)var17);
    var19=(vector float)si_fm((qword)var12,(qword)var18);
    var24=(vector float)si_fm((qword)var19,(qword)var23);
    var20=(vector float)si_fm((qword)var19,(qword)var19);
    var21=(vector float)si_fm((qword)var20,(qword)var20);
    var22=(vector float)si_fma((qword)var14,(qword)var21,(qword)var17);
    var25=(vector float)si_fma((qword)var19,(qword)var22,(qword)var24);
    return var25;
}

#endif /* MASS_RQDRT_H */
