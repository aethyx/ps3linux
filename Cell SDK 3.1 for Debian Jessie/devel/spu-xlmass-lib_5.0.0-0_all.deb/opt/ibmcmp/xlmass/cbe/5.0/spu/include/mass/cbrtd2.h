/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2008.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/
#ifndef MASS_CBRT_H
#define MASS_CBRT_H
#include <spu_intrinsics.h>
static __inline vector double _cbrtd2(vector double var227In){
    vector unsigned char var227;
    vector unsigned char var228;
    vector unsigned char var229;
    vector unsigned char var230;
    vector unsigned char var231;
    vector unsigned char var232;
    vector unsigned char var233;
    vector unsigned char var234;
    vector unsigned char var235;
    vector unsigned char var238;
    vector unsigned char var239;
    vector unsigned char var240;
    vector unsigned char var241;
    vector unsigned char var242;
    vector unsigned char var243;
    vector unsigned char var244;
    vector unsigned char var245;
    vector unsigned char var246;
    vector unsigned char var247;
    vector unsigned char var248;
    vector unsigned char var249;
    vector unsigned char var250;
    vector unsigned char var251;
    vector unsigned char var252;
    vector unsigned char var253;
    vector unsigned char var254;
    vector unsigned char var255;
    vector unsigned char var256;
    vector unsigned char var257;
    vector unsigned char var258;
    vector unsigned char var259;
    vector unsigned char var260;
    vector unsigned char var261;
    vector unsigned char var262;
    vector unsigned char var263;
    vector unsigned char var265;
    vector unsigned char var266;
    vector unsigned char var268;
    vector unsigned char var269;
    vector unsigned char var270;
    vector unsigned char var271;
    vector unsigned char var272;
    vector unsigned char var273;
    vector unsigned char var274;
    vector unsigned char var275;
    static const union {const vector unsigned char v[64];const char c[64*16];} var276= 
        {(vector unsigned char){191,165,15,139,164,47,32,188,63,157,210,37,9,154,5,201}
        ,(vector unsigned char){191,163,229,147,177,3,90,255,63,155,188,233,75,242,159,148}
        ,(vector unsigned char){191,162,208,85,3,153,206,20,63,153,216,36,131,146,8,214}
        ,(vector unsigned char){191,161,206,2,188,253,36,199,63,152,26,250,115,251,240,178}
        ,(vector unsigned char){191,160,221,17,44,235,224,253,63,150,129,170,137,194,191,44}
        ,(vector unsigned char){191,159,248,52,59,223,16,155,63,149,8,219,97,95,209,87}
        ,(vector unsigned char){191,158,83,177,157,227,198,211,63,147,173,142,107,234,35,29}
        ,(vector unsigned char){191,156,202,76,208,90,190,218,63,146,109,21,52,135,164,17}
        ,(vector unsigned char){191,155,89,237,182,115,73,195,63,145,69,8,10,214,78,104}
        ,(vector unsigned char){191,154,0,172,64,147,95,116,63,144,51,61,223,201,198,125}
        ,(vector unsigned char){191,152,188,203,137,81,91,222,63,142,107,138,84,98,185,145}
        ,(vector unsigned char){191,151,140,181,128,91,226,220,63,140,149,187,93,28,50,121}
        ,(vector unsigned char){191,150,110,247,17,149,218,69,63,138,225,230,22,146,177,36}
        ,(vector unsigned char){191,149,98,60,185,21,210,180,63,137,77,47,221,208,221,25}
        ,(vector unsigned char){191,148,101,79,118,198,234,139,63,135,213,3,195,92,133,134}
        ,(vector unsigned char){191,147,119,18,22,43,125,55,63,134,119,11,30,175,139,2}
        ,(vector unsigned char){191,146,150,126,192,67,175,129,63,133,49,39,0,185,110,121}
        ,(vector unsigned char){191,145,194,164,206,229,11,10,63,132,1,106,104,224,216,216}
        ,(vector unsigned char){191,144,250,166,217,237,43,13,63,130,230,21,35,238,106,154}
        ,(vector unsigned char){191,144,61,184,247,174,237,198,63,129,221,143,63,166,72,131}
        ,(vector unsigned char){191,143,22,62,85,155,15,71,63,128,230,101,0,179,224,60}
        ,(vector unsigned char){191,141,196,87,240,224,67,238,63,127,254,134,149,253,250,133}
        ,(vector unsigned char){191,140,132,126,68,175,6,160,63,126,77,232,221,53,227,73}
        ,(vector unsigned char){191,139,85,137,1,210,60,149,63,124,184,186,154,156,28,136}
        ,(vector unsigned char){191,138,54,101,243,117,135,184,63,123,60,245,156,120,228,76}
        ,(vector unsigned char){191,137,38,23,31,37,60,9,63,121,216,191,45,46,5,164}
        ,(vector unsigned char){191,136,35,177,18,84,87,146,63,120,138,99,254,172,155,51}
        ,(vector unsigned char){191,135,46,89,88,165,22,172,63,119,80,84,130,15,249,55}
        ,(vector unsigned char){191,134,69,69,22,188,4,151,63,118,41,33,159,36,126,221}
        ,(vector unsigned char){191,133,103,183,197,223,120,45,63,117,19,121,193,31,217,28}
        ,(vector unsigned char){191,132,149,2,13,16,142,101,63,116,14,38,47,28,187,165}
        ,(vector unsigned char){191,131,204,128,180,168,223,26,63,115,24,8,168,13,80,86}
        ,(vector unsigned char){191,131,13,155,177,219,11,127,63,114,48,25,58,211,154,126}
        ,(vector unsigned char){191,130,87,197,71,189,84,126,63,113,85,100,84,10,234,84}
        ,(vector unsigned char){191,129,170,121,59,197,226,236,63,112,135,8,251,205,156,195}
        ,(vector unsigned char){191,129,5,60,27,217,104,148,63,111,136,110,124,213,3,251}
        ,(vector unsigned char){191,128,103,154,148,63,47,180,63,110,24,93,119,33,44,64}
        ,(vector unsigned char){191,127,162,81,167,244,187,128,63,108,188,122,175,241,247,81}
        ,(vector unsigned char){191,126,131,3,252,95,165,229,63,107,115,124,28,17,117,212}
        ,(vector unsigned char){191,125,112,143,78,198,140,241,63,106,60,47,180,143,109,251}
        ,(vector unsigned char){191,124,106,66,186,235,30,217,63,105,21,121,129,196,157,198}
        ,(vector unsigned char){191,123,111,120,114,211,216,119,63,103,254,81,211,113,139,249}
        ,(vector unsigned char){191,122,127,148,244,33,231,226,63,102,245,195,161,136,63,240}
        ,(vector unsigned char){191,121,154,6,77,156,20,23,63,101,250,235,17,169,120,236}
        ,(vector unsigned char){191,120,190,67,115,127,250,59,63,101,12,244,29,201,83,95}
        ,(vector unsigned char){191,119,235,203,161,78,96,67,63,100,43,25,88,206,107,107}
        ,(vector unsigned char){191,119,34,37,199,231,21,213,63,99,84,162,206,82,243,135}
        ,(vector unsigned char){191,118,96,224,6,229,74,68,63,98,136,228,250,250,47,130}
        ,(vector unsigned char){191,117,167,143,48,70,191,207,63,97,199,63,219,15,112,59}
        ,(vector unsigned char){191,116,245,206,85,127,43,80,63,97,15,30,13,95,5,98}
        ,(vector unsigned char){191,116,75,62,93,45,166,34,63,96,95,244,8,110,127,108}
        ,(vector unsigned char){191,115,167,133,160,188,157,230,63,95,114,126,192,209,148,108}
        ,(vector unsigned char){191,115,10,79,145,69,92,166,63,94,53,12,56,121,149,48}
        ,(vector unsigned char){191,114,115,76,99,31,77,170,63,93,6,172,49,37,166,227}
        ,(vector unsigned char){191,113,226,48,191,144,180,242,63,91,230,136,238,189,241,235}
        ,(vector unsigned char){191,113,86,181,124,34,208,69,63,90,211,218,53,232,240,153}
        ,(vector unsigned char){191,112,208,151,87,38,108,55,63,89,205,228,87,50,239,17}
        ,(vector unsigned char){191,112,79,150,184,255,252,197,63,88,211,247,77,101,84,135}
        ,(vector unsigned char){191,111,166,238,243,182,183,46,63,87,229,109,237,104,106,168}
        ,(vector unsigned char){191,110,184,1,86,223,13,228,63,87,1,173,38,49,141,38}
        ,(vector unsigned char){191,109,209,248,205,4,98,19,63,86,40,35,79,98,242,44}
        ,(vector unsigned char){191,108,244,111,55,195,104,121,63,85,88,71,133,98,1,32}
        ,(vector unsigned char){191,108,31,3,209,36,77,98,63,84,145,153,17,197,208,29}
        ,(vector unsigned char){191,107,81,90,217,223,189,92,63,83,211,158,223,25,50,200}
        };
    vector unsigned char var277;
    vector unsigned char var278;
    vector unsigned char var279;
    vector unsigned char var280;
    vector unsigned char var281;
    vector unsigned char var282;
    vector unsigned char var283;
    vector unsigned char var284;
    vector unsigned char var285;
    vector unsigned char var286;
    vector unsigned char var287;
    vector unsigned char var288;
    vector unsigned char var289;
    static const union {const vector unsigned char v[64];const char c[64*16];} var290= 
        {(vector unsigned char){191,188,113,199,26,76,60,43,63,175,154,216,122,248,155,3}
        ,(vector unsigned char){191,187,184,6,78,170,206,196,63,174,83,39,118,48,63,167}
        ,(vector unsigned char){191,187,5,189,23,174,15,176,63,173,29,112,108,224,248,74}
        ,(vector unsigned char){191,186,90,131,94,31,188,60,63,171,248,118,137,212,187,191}
        ,(vector unsigned char){191,185,181,248,38,173,65,101,63,170,227,23,85,114,193,109}
        ,(vector unsigned char){191,185,23,192,252,248,227,170,63,169,220,71,232,218,56,96}
        ,(vector unsigned char){191,184,127,137,108,251,249,26,63,168,227,18,182,58,214,43}
        ,(vector unsigned char){191,183,237,2,136,253,148,207,63,167,246,149,141,191,37,246}
        ,(vector unsigned char){191,183,95,226,122,200,86,12,63,167,21,255,215,212,8,188}
        ,(vector unsigned char){191,182,215,228,30,242,97,254,63,166,64,144,254,138,68,175}
        ,(vector unsigned char){191,182,84,198,169,45,165,153,63,165,117,151,0,158,8,37}
        ,(vector unsigned char){191,181,214,77,80,181,18,218,63,164,180,109,41,98,46,113}
        ,(vector unsigned char){191,181,92,63,4,6,67,30,63,163,252,122,233,102,77,222}
        ,(vector unsigned char){191,180,230,102,35,46,72,23,63,163,77,50,204,50,209,14}
        ,(vector unsigned char){191,180,116,144,64,4,242,27,63,162,166,17,135,232,181,219}
        ,(vector unsigned char){191,180,6,141,227,195,209,3,63,162,6,157,35,245,158,16}
        ,(vector unsigned char){191,179,156,50,89,118,8,180,63,161,110,100,52,98,222,117}
        ,(vector unsigned char){191,179,53,83,124,204,5,34,63,160,220,253,39,145,3,241}
        ,(vector unsigned char){191,178,209,201,140,234,104,200,63,160,82,5,164,114,112,229}
        ,(vector unsigned char){191,178,113,111,2,214,114,126,63,159,154,67,239,33,42,16}
        ,(vector unsigned char){191,178,20,32,107,43,186,21,63,158,155,249,26,177,248,39}
        ,(vector unsigned char){191,177,185,188,66,207,174,71,63,157,168,138,240,181,247,172}
        ,(vector unsigned char){191,177,98,34,214,94,212,189,63,156,191,100,4,137,251,24}
        ,(vector unsigned char){191,177,13,54,36,22,140,101,63,155,223,248,141,35,220,113}
        ,(vector unsigned char){191,176,186,217,192,4,20,99,63,155,9,197,171,233,212,75}
        ,(vector unsigned char){191,176,106,242,186,70,245,242,63,154,60,80,195,86,125,98}
        ,(vector unsigned char){191,176,29,103,135,57,184,126,63,153,119,38,219,231,172,64}
        ,(vector unsigned char){191,175,164,63,210,176,29,98,63,152,185,220,21,254,222,30}
        ,(vector unsigned char){191,175,18,9,185,122,255,209,63,152,4,11,39,125,243,73}
        ,(vector unsigned char){191,174,132,1,8,54,1,96,63,151,85,84,228,10,197,3}
        ,(vector unsigned char){191,173,249,252,46,10,3,228,63,150,173,95,207,0,109,41}
        ,(vector unsigned char){191,173,115,211,162,252,135,95,63,150,11,215,182,46,54,235}
        ,(vector unsigned char){191,172,241,97,201,76,107,198,63,149,112,109,84,154,140,32}
        ,(vector unsigned char){191,172,114,130,208,231,225,197,63,148,218,213,252,148,31,99}
        ,(vector unsigned char){191,171,247,20,156,209,169,41,63,148,74,203,72,109,88,241}
        ,(vector unsigned char){191,171,126,246,170,79,99,27,63,147,192,10,209,77,236,113}
        ,(vector unsigned char){191,171,10,9,249,190,11,120,63,147,58,85,235,148,175,223}
        ,(vector unsigned char){191,170,152,48,248,236,169,71,63,146,185,113,104,80,129,72}
        ,(vector unsigned char){191,170,41,79,110,223,250,157,63,146,61,37,91,98,109,90}
        ,(vector unsigned char){191,169,189,74,104,228,83,245,63,145,197,60,229,229,129,51}
        ,(vector unsigned char){191,169,84,8,40,213,36,121,63,145,81,134,4,129,224,89}
        ,(vector unsigned char){191,168,237,112,20,131,149,212,63,144,225,209,97,88,249,89}
        ,(vector unsigned char){191,168,137,106,166,39,148,147,63,144,117,242,41,64,34,3}
        ,(vector unsigned char){191,168,39,225,93,200,57,184,63,144,13,189,228,5,150,191}
        ,(vector unsigned char){191,167,200,190,179,138,19,246,63,143,82,24,159,3,197,110}
        ,(vector unsigned char){191,167,107,238,10,211,50,76,63,142,143,110,122,122,85,215}
        ,(vector unsigned char){191,167,17,91,166,54,21,169,63,141,211,52,228,233,136,39}
        ,(vector unsigned char){191,166,184,244,156,21,215,114,63,141,29,39,20,163,225,138}
        ,(vector unsigned char){191,166,98,166,203,246,225,16,63,140,109,3,180,77,93,226}
        ,(vector unsigned char){191,166,14,96,212,112,136,59,63,139,194,140,175,18,73,62}
        ,(vector unsigned char){191,165,188,18,9,180,198,54,63,139,29,135,0,83,27,19}
        ,(vector unsigned char){191,165,107,170,108,164,15,161,63,138,125,186,134,131,29,183}
        ,(vector unsigned char){191,165,29,26,162,100,16,237,63,137,226,241,216,253,38,181}
        ,(vector unsigned char){191,164,208,83,236,112,193,252,63,137,76,250,32,150,159,249}
        ,(vector unsigned char){191,164,133,72,33,31,227,243,63,136,187,162,242,189,170,165}
        ,(vector unsigned char){191,164,59,233,164,143,143,108,63,136,46,190,46,243,69,216}
        ,(vector unsigned char){191,163,244,43,97,249,0,254,63,135,166,31,222,118,40,1}
        ,(vector unsigned char){191,163,174,0,197,97,78,126,63,135,33,158,21,246,105,3}
        ,(vector unsigned char){191,163,105,93,181,162,34,126,63,134,161,16,217,45,62,220}
        ,(vector unsigned char){191,163,38,54,142,197,5,68,63,134,36,82,0,54,236,186}
        ,(vector unsigned char){191,162,228,128,28,172,28,33,63,133,171,61,30,143,163,221}
        ,(vector unsigned char){191,162,164,47,150,3,162,41,63,133,53,175,107,150,124,40}
        ,(vector unsigned char){191,162,101,58,151,119,176,141,63,132,195,135,172,123,221,67}
        ,(vector unsigned char){191,162,39,151,31,42,57,164,63,132,84,166,31,130,180,244}
        };
    vector unsigned char var296;
    vector unsigned char var298;
    vector unsigned char var300;
    vector unsigned char var301;
    vector unsigned char var303;
    vector unsigned char var304;
    static const union {const vector unsigned char v[64];const char c[64*16];} var305= 
        {(vector unsigned char){63,240,0,0,0,0,0,0,63,213,85,85,85,85,40,125}
        ,(vector unsigned char){63,240,21,57,34,29,76,152,63,213,29,44,207,147,62,54}
        ,(vector unsigned char){63,240,42,58,210,239,111,73,63,212,230,112,65,218,229,142}
        ,(vector unsigned char){63,240,63,6,119,26,46,52,63,212,177,17,38,86,174,38}
        ,(vector unsigned char){63,240,83,157,101,33,37,112,63,212,125,1,192,41,115,132}
        ,(vector unsigned char){63,240,104,0,230,41,214,114,63,212,74,53,13,206,50,174}
        ,(vector unsigned char){63,240,124,50,54,176,167,58,63,212,24,158,188,146,245,173}
        ,(vector unsigned char){63,240,144,50,135,49,222,179,63,211,232,51,29,20,41,161}
        ,(vector unsigned char){63,240,164,2,252,199,146,152,63,211,184,231,24,160,147,3}
        ,(vector unsigned char){63,240,183,164,177,189,100,172,63,211,138,176,39,112,149,15}
        ,(vector unsigned char){63,240,203,24,182,26,216,207,63,211,93,132,71,157,183,73}
        ,(vector unsigned char){63,240,222,96,16,36,251,136,63,211,49,89,244,201,72,169}
        ,(vector unsigned char){63,240,241,123,188,216,0,70,63,211,6,40,32,98,187,48}
        ,(vector unsigned char){63,241,4,108,176,89,112,1,63,210,219,230,42,127,219,245}
        ,(vector unsigned char){63,241,23,51,214,99,115,189,63,210,178,139,219,58,105,55}
        ,(vector unsigned char){63,241,41,210,18,169,186,156,63,210,138,17,92,135,191,30}
        ,(vector unsigned char){63,241,60,72,65,56,112,79,63,210,98,111,52,128,105,7}
        ,(vector unsigned char){63,241,78,151,54,205,175,57,63,210,59,158,64,14,92,222}
        ,(vector unsigned char){63,241,96,191,193,45,208,145,63,210,21,151,173,249,131,89}
        ,(vector unsigned char){63,241,114,194,167,114,245,8,63,209,240,84,250,74,246,22}
        ,(vector unsigned char){63,241,132,160,170,88,25,31,63,209,203,207,234,0,14,78}
        ,(vector unsigned char){63,241,150,90,132,128,1,211,63,209,168,2,135,6,254,93}
        ,(vector unsigned char){63,241,167,240,234,184,72,61,63,209,132,231,28,127,63,214}
        ,(vector unsigned char){63,241,185,100,140,56,197,93,63,209,98,120,51,56,160,215}
        ,(vector unsigned char){63,241,202,182,18,223,154,70,63,209,64,176,142,108,47,224}
        ,(vector unsigned char){63,241,219,230,35,106,12,69,63,209,31,139,40,170,174,85}
        ,(vector unsigned char){63,241,236,245,93,170,104,165,63,208,255,3,48,252,144,182}
        ,(vector unsigned char){63,241,253,228,92,187,31,159,63,208,223,20,8,47,233,127}
        ,(vector unsigned char){63,242,14,179,183,47,66,213,63,208,191,185,62,80,233,92}
        ,(vector unsigned char){63,242,31,99,255,64,144,67,63,208,160,238,144,73,229,188}
        ,(vector unsigned char){63,242,47,245,194,251,47,208,63,208,130,175,229,168,22,238}
        ,(vector unsigned char){63,242,64,105,140,103,70,229,63,208,100,249,78,130,120,244}
        ,(vector unsigned char){63,242,80,191,225,176,130,245,63,208,71,199,1,128,111,31}
        ,(vector unsigned char){63,242,96,249,69,75,185,156,63,208,43,21,89,253,250,171}
        ,(vector unsigned char){63,242,113,22,54,26,186,234,63,208,14,224,214,75,128,114}
        ,(vector unsigned char){63,242,129,23,47,142,112,116,63,207,230,76,44,14,131,135}
        ,(vector unsigned char){63,242,144,252,169,199,97,248,63,207,175,195,177,29,162,55}
        ,(vector unsigned char){63,242,160,199,25,180,182,209,63,207,122,33,247,13,217,86}
        ,(vector unsigned char){63,242,176,118,241,49,201,215,63,207,69,96,242,240,142,207}
        ,(vector unsigned char){63,242,192,12,159,34,99,237,63,207,17,122,208,255,202,95}
        ,(vector unsigned char){63,242,207,136,143,141,176,47,63,206,222,105,242,35,144,139}
        ,(vector unsigned char){63,242,222,235,43,183,251,121,63,206,172,40,233,153,139,221}
        ,(vector unsigned char){63,242,238,52,218,59,79,227,63,206,122,178,122,188,219,46}
        ,(vector unsigned char){63,242,253,101,255,30,251,188,63,206,74,1,150,236,3,106}
        ,(vector unsigned char){63,243,12,126,251,238,18,173,63,206,26,17,91,139,39,225}
        ,(vector unsigned char){63,243,27,128,47,204,246,162,63,205,234,221,16,32,205,164}
        ,(vector unsigned char){63,243,42,105,247,141,245,103,63,205,188,96,36,139,141,144}
        ,(vector unsigned char){63,243,57,60,173,197,7,9,63,205,142,150,47,79,53,13}
        ,(vector unsigned char){63,243,71,248,170,218,184,85,63,205,97,122,235,247,239,226}
        ,(vector unsigned char){63,243,86,158,69,30,76,43,63,205,53,10,57,146,45,225}
        ,(vector unsigned char){63,243,101,45,208,215,29,177,63,205,9,64,25,54,13,126}
        ,(vector unsigned char){63,243,115,167,160,85,76,223,63,204,222,24,172,165,41,65}
        ,(vector unsigned char){63,243,130,12,4,1,190,82,63,204,179,144,52,249,185,40}
        ,(vector unsigned char){63,243,144,91,74,109,118,206,63,204,137,163,17,102,10,215}
        ,(vector unsigned char){63,243,158,149,192,96,90,102,63,204,96,77,190,3,99,247}
        ,(vector unsigned char){63,243,172,187,176,231,86,183,63,204,55,140,210,175,113,84}
        ,(vector unsigned char){63,243,186,205,101,97,255,94,63,204,15,93,1,247,115,144}
        ,(vector unsigned char){63,243,200,203,37,143,163,65,63,203,231,187,24,16,103,71}
        ,(vector unsigned char){63,243,214,181,55,155,225,12,63,203,192,163,249,219,114,215}
        ,(vector unsigned char){63,243,228,139,224,42,192,207,63,203,154,20,163,245,239,63}
        ,(vector unsigned char){63,243,242,79,98,100,88,101,63,203,116,10,41,212,108,40}
        ,(vector unsigned char){63,244,0,0,0,0,0,0,63,203,78,129,180,232,24,236}
        ,(vector unsigned char){63,244,13,157,249,79,27,225,63,203,41,120,131,206,5,175}
        ,(vector unsigned char){63,244,27,41,141,71,128,14,63,203,4,235,233,135,184,4}
        };
    vector unsigned char var311;
    vector unsigned char var313;
    vector unsigned char var315;
    vector unsigned char var316;
    vector unsigned char var318;
    vector unsigned char var319;
    vector unsigned char var320;
    vector unsigned char var321;
    vector unsigned char var322;
    vector unsigned char var323;
    vector double var324;
    var228=(vector unsigned char){63,240,0,0,63,244,40,162,63,249,101,254,63,249,101,254};
    var229=(vector unsigned char){0,0,0,0,249,141,114,139,165,61,110,61,165,61,110,61};
    var230=(vector unsigned char){0,1,2,3,16,17,18,19,0,1,2,3,16,17,18,19};
    var231=(vector unsigned char){0,0,85,85,0,0,85,85,0,0,85,85,0,0,85,85};
    var232=(vector unsigned char){0,1,2,3,16,17,18,19,8,9,10,11,24,25,26,27};
    var234=(vector unsigned char){67,80,0,0,0,0,0,0,67,80,0,0,0,0,0,0};
    var239=(vector unsigned char){0,32,0,0,0,32,0,0,0,32,0,0,0,32,0,0};
    var243=(vector unsigned char){127,240,0,0,127,240,0,0,127,240,0,0,127,240,0,0};
    var246=(vector unsigned char){42,162,0,0,42,162,0,0,42,162,0,0,42,162,0,0};
    var248=(vector unsigned char){126,224,0,0,126,224,0,0,126,224,0,0,126,224,0,0};
    var251=(vector unsigned char){1,1,1,1,1,1,1,1,9,9,9,9,9,9,9,9};
    var253=(vector unsigned char){12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12};
    var256=(vector unsigned char){16,1,2,3,4,5,6,7,24,9,10,11,12,13,14,15};
    var258=(vector unsigned char){0,1,2,3,128,128,128,128,8,9,10,11,128,128,128,128};
    var260=(vector unsigned char){127,240,0,0,0,0,0,0,127,240,0,0,0,0,0,0};
    var262=(vector unsigned char){4,5,6,7,20,21,22,23,12,13,14,15,28,29,30,31};
    var269=(vector unsigned char){63,240,0,0,63,240,0,0,63,240,0,0,63,240,0,0};
    var270=(vector unsigned char){0,0,63,255,0,0,63,255,0,0,63,255,0,0,63,255};
    var272=(vector unsigned char){16,17,18,19,4,5,6,7,24,25,26,27,12,13,14,15};
    var274=(vector unsigned char){63,240,0,0,0,0,0,0,63,240,0,0,0,0,0,0};
    var279=(vector unsigned char){128,128,128,1,128,128,128,5,128,128,128,9,128,128,128,13};
    var285=(vector unsigned char){8,9,10,11,12,13,14,15,24,25,26,27,28,29,30,31};
    var287=(vector unsigned char){0,1,2,3,4,5,6,7,16,17,18,19,20,21,22,23};
    var322=(vector unsigned char){0,1,2,3,0,1,2,3,8,9,10,11,8,9,10,11};
    var227=(vector unsigned char)var227In;
    var263=(vector unsigned char)si_shufb((qword)var227,(qword)var227,(qword)var262);
    var235=(vector unsigned char)si_dfm((qword)var227,(qword)var234);
    var265=(vector unsigned char)si_shufb((qword)var235,(qword)var235,(qword)var262);
    var238=(vector unsigned char)si_shufb((qword)var235,(qword)var235,(qword)var232);
    var233=(vector unsigned char)si_shufb((qword)var227,(qword)var227,(qword)var232);
    var321=(vector unsigned char)si_ceq((qword)var233,(qword)var238);
    var323=(vector unsigned char)si_shufb((qword)var321,(qword)var321,(qword)var322);
    var240=(vector unsigned char)si_rotqbii((qword)var233,(int)1);
    var241=(vector unsigned char)si_clgt((qword)var239,(qword)var240);
    var266=(vector unsigned char)si_selb((qword)var263,(qword)var265,(qword)var241);
    var242=(vector unsigned char)si_selb((qword)var233,(qword)var238,(qword)var241);
    var277=(vector unsigned char)si_rotqbii((qword)var242,(int)2);
    var278=(vector unsigned char)si_andbi((qword)var277,(int)63);
    var280=(vector unsigned char)si_shufb((qword)var278,(qword)var278,(qword)var279);
    var281=(vector unsigned char)si_rotqbii((qword)var280,(int)4);
    var311=*(vector unsigned char*)(var305.c+spu_extract((vector signed int)var281,0));
    var296=*(vector unsigned char*)(var290.c+spu_extract((vector signed int)var281,0));
    var283=(vector unsigned char)si_rotqbyi((qword)var281,(int)8);
    var313=*(vector unsigned char*)(var305.c+spu_extract((vector signed int)var283,0));
    var318=(vector unsigned char)si_shufb((qword)var311,(qword)var313,(qword)var287);
    var315=(vector unsigned char)si_shufb((qword)var311,(qword)var313,(qword)var285);
    var298=*(vector unsigned char*)(var290.c+spu_extract((vector signed int)var283,0));
    var303=(vector unsigned char)si_shufb((qword)var296,(qword)var298,(qword)var287);
    var300=(vector unsigned char)si_shufb((qword)var296,(qword)var298,(qword)var285);
    var284=*(vector unsigned char*)(var276.c+spu_extract((vector signed int)var283,0));
    var282=*(vector unsigned char*)(var276.c+spu_extract((vector signed int)var281,0));
    var288=(vector unsigned char)si_shufb((qword)var282,(qword)var284,(qword)var287);
    var286=(vector unsigned char)si_shufb((qword)var282,(qword)var284,(qword)var285);
    var271=(vector unsigned char)si_selb((qword)var269,(qword)var242,(qword)var270);
    var268=(vector unsigned char)si_shufb((qword)var242,(qword)var266,(qword)var232);
    var273=(vector unsigned char)si_shufb((qword)var268,(qword)var271,(qword)var272);
    var275=(vector unsigned char)si_dfs((qword)var273,(qword)var274);
    var289=(vector unsigned char)si_dfma((qword)var275,(qword)var286,(qword)var288);
    var301=(vector unsigned char)si_dfma((qword)var275,(qword)var289,(qword)var300);
    var304=(vector unsigned char)si_dfma((qword)var275,(qword)var301,(qword)var303);
    var316=(vector unsigned char)si_dfma((qword)var275,(qword)var304,(qword)var315);
    var319=(vector unsigned char)si_dfma((qword)var275,(qword)var316,(qword)var318);
    var244=(vector unsigned char)si_and((qword)var242,(qword)var243);
    var245=(vector unsigned char)si_rotqbyi((qword)var244,(int)14);
    var247=(vector unsigned char)si_mpya((qword)var231,(qword)var245,(qword)var246);
    var249=(vector unsigned char)si_a((qword)var247,(qword)var248);
    var250=(vector unsigned char)si_selb((qword)var247,(qword)var249,(qword)var241);
    var259=(vector unsigned char)si_shufb((qword)var250,(qword)var250,(qword)var258);
    var252=(vector unsigned char)si_shufb((qword)var250,(qword)var250,(qword)var251);
    var254=(vector unsigned char)si_selb((qword)var230,(qword)var252,(qword)var253);
    var255=(vector unsigned char)si_shufb((qword)var228,(qword)var229,(qword)var254);
    var257=(vector unsigned char)si_shufb((qword)var255,(qword)var227,(qword)var256);
    var261=(vector unsigned char)si_selb((qword)var257,(qword)var259,(qword)var260);
    var320=(vector unsigned char)si_dfm((qword)var261,(qword)var319);
    var324=(vector double)si_selb((qword)var320,(qword)var227,(qword)var323);
    return var324;}

#endif /* MASS_CBRT_H */
