/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2007.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

#ifndef MASS_ERF_H
#define MASS_ERF_H 1
#include <spu_intrinsics.h>
static __inline vector float _erff4(vector float var1){
    vector float var10;
    vector float var11;
    vector float var12;
    vector float var13;
    vector float var14;
    vector float var15;
    vector float var16;
    vector float var17;
    vector float var18;
    vector float var19;
    vector float var2;
    vector float var20;
    vector float var21;
    vector float var22;
    vector float var23;
    vector float var24;
    vector float var25;
    vector float var26;
    vector float var27;
    vector float var28;
    vector float var29;
    vector float var3;
    vector float var30;
    vector float var31;
    vector float var32;
    vector float var33;
    vector float var34;
    vector float var35;
    vector float var36;
    vector float var37;
    vector float var38;
    vector float var39;
    vector float var4;
    vector float var40;
    vector float var41;
    vector float var42;
    vector float var43;
    vector float var44;
    vector float var45;
    vector float var46;
    vector float var47;
    vector float var48;
    vector float var49;
    vector float var5;
    vector float var50;
    vector float var51;
    vector float var52;
    vector float var53;
    vector float var54;
    vector float var55;
    vector float var56;
    vector float var57;
    vector float var58;
    vector float var59;
    vector float var6;
    vector float var60;
    vector float var61;
    vector float var62;
    vector float var63;
    vector float var64;
    vector float var65;
    vector float var66;
    vector float var67;
    vector float var68;
    vector float var69;
    vector float var7;
    vector float var70;
    vector float var71;
    vector float var72;
    vector float var73;
    vector float var8;
    vector float var9;
    var11=(vector float)(vector unsigned char){0,0,4,4,8,8,12,12,16,16,20,20,24,24,28,28};
    var13=(vector float)(vector unsigned char){30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30};
    var16=(vector float)(vector unsigned char){208,244,208,244,57,111,208,244,133,49,57,111,237,172,208,244};
    var17=(vector float)(vector unsigned char){43,19,133,49,223,80,57,111,147,141,237,172,0,0,208,244};
    var19=(vector float)(vector unsigned char){0,1,16,17,2,3,18,19,4,5,20,21,6,7,22,23};
    var2=(vector float)(vector unsigned char){128,0,0,0,128,0,0,0,128,0,0,0,128,0,0,0};
    var22=(vector float)(vector unsigned char){61,51,188,244,189,138,189,112,188,218,58,23,60,71,60,66};
    var23=(vector float)(vector unsigned char){59,242,59,101,58,175,57,221,56,234,55,210,61,227,61,190};
    var25=(vector float)(vector unsigned char){132,174,247,95,131,192,80,55,235,81,137,223,71,134,86,222};
    var26=(vector float)(vector unsigned char){152,240,252,17,96,18,28,64,17,198,29,30,90,144,210,53};
    var29=(vector float)(vector unsigned char){62,14,62,69,62,24,61,111,188,141,189,76,189,66,188,255};
    var30=(vector float)(vector unsigned char){188,130,187,216,187,21,186,46,185,45,184,19,57,144,61,146};
    var32=(vector float)(vector unsigned char){135,61,52,244,116,112,77,25,31,143,88,49,147,66,23,184};
    var33=(vector float)(vector unsigned char){21,18,17,188,125,247,160,2,171,96,233,232,0,73,218,5};
    var37=(vector float)(vector unsigned char){190,157,190,14,61,20,62,20,62,43,62,8,61,169,61,45};
    var38=(vector float)(vector unsigned char){60,148,59,215,59,5,58,14,57,2,55,208,190,192,190,183};
    var4=(vector float)(vector unsigned char){62,130,63,2,63,68,63,130,63,163,63,196,63,228,64,2};
    var40=(vector float)(vector unsigned char){131,157,233,161,155,115,10,49,39,245,79,196,230,81,122,210};
    var41=(vector float)(vector unsigned char){92,250,60,116,120,118,68,215,212,14,41,196,149,132,83,232};
    var45=(vector float)(vector unsigned char){190,138,190,227,190,246,190,207,190,144,190,40,189,168,189,16};
    var46=(vector float)(vector unsigned char){188,86,187,137,186,154,185,149,184,125,183,59,52,133,190,17};
    var48=(vector float)(vector unsigned char){62,135,87,77,18,202,198,28,85,181,239,230,178,119,206,147};
    var49=(vector float)(vector unsigned char){188,154,252,119,12,144,168,143,96,17,20,220,88,85,55,196};
    var5=(vector float)(vector unsigned char){64,19,64,35,64,51,64,68,64,84,64,100,0,0,62,2};
    var53=(vector float)(vector unsigned char){63,135,63,94,63,32,62,203,62,97,61,220,61,60,60,141};
    var54=(vector float)(vector unsigned char){59,186,58,216,57,219,56,195,55,153,54,82,63,144,63,142};
    var56=(vector float)(vector unsigned char){78,13,122,212,133,203,73,149,239,72,94,193,162,63,180,58};
    var57=(vector float)(vector unsigned char){214,245,50,120,139,92,167,4,4,45,10,222,110,187,24,50};
    var6=(vector float)(vector unsigned char){0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1};
    var61=(vector float)(vector unsigned char){62,144,63,7,63,56,63,90,63,109,63,120,63,125,63,127};
    var62=(vector float)(vector unsigned char){63,127,63,127,63,127,63,127,63,127,63,127,0,0,62,18};
    var64=(vector float)(vector unsigned char){117,210,181,140,188,254,4,184,223,16,71,126,19,12,4,16};
    var65=(vector float)(vector unsigned char){180,231,236,50,251,99,255,14,255,213,255,250,0,0,207,172};
    var69=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var7=(vector float)(vector unsigned char){63,122,125,33,63,122,125,33,63,122,125,33,63,122,125,33};
    var70=(vector float)(vector unsigned char){64,117,71,202,64,117,71,202,64,117,71,202,64,117,71,202};
    var8=(vector float)(vector unsigned char){64,112,0,0,64,112,0,0,64,112,0,0,64,112,0,0};
    var3=(vector float)si_andc((qword)var1,(qword)var2);
    var71=(vector float)si_fcmgt((qword)var3,(qword)var70);
    var9=(vector float)si_fma((qword)var3,(qword)var7,(qword)var8);
    var10=(vector float)si_roti((qword)var9,(int)6);
    var12=(vector float)si_shufb((qword)var10,(qword)var10,(qword)var11);
    var14=(vector float)si_selb((qword)var6,(qword)var12,(qword)var13);
    var66=(vector float)si_shufb((qword)var64,(qword)var65,(qword)var14);
    var63=(vector float)si_shufb((qword)var61,(qword)var62,(qword)var14);
    var67=(vector float)si_shufb((qword)var63,(qword)var66,(qword)var19);
    var58=(vector float)si_shufb((qword)var56,(qword)var57,(qword)var14);
    var55=(vector float)si_shufb((qword)var53,(qword)var54,(qword)var14);
    var59=(vector float)si_shufb((qword)var55,(qword)var58,(qword)var19);
    var50=(vector float)si_shufb((qword)var48,(qword)var49,(qword)var14);
    var47=(vector float)si_shufb((qword)var45,(qword)var46,(qword)var14);
    var51=(vector float)si_shufb((qword)var47,(qword)var50,(qword)var19);
    var42=(vector float)si_shufb((qword)var40,(qword)var41,(qword)var14);
    var39=(vector float)si_shufb((qword)var37,(qword)var38,(qword)var14);
    var43=(vector float)si_shufb((qword)var39,(qword)var42,(qword)var19);
    var34=(vector float)si_shufb((qword)var32,(qword)var33,(qword)var14);
    var31=(vector float)si_shufb((qword)var29,(qword)var30,(qword)var14);
    var35=(vector float)si_shufb((qword)var31,(qword)var34,(qword)var19);
    var27=(vector float)si_shufb((qword)var25,(qword)var26,(qword)var14);
    var24=(vector float)si_shufb((qword)var22,(qword)var23,(qword)var14);
    var28=(vector float)si_shufb((qword)var24,(qword)var27,(qword)var19);
    var18=(vector float)si_shufb((qword)var16,(qword)var17,(qword)var14);
    var15=(vector float)si_shufb((qword)var4,(qword)var5,(qword)var14);
    var20=(vector float)si_shufb((qword)var15,(qword)var18,(qword)var19);
    var21=(vector float)si_fs((qword)var3,(qword)var20);
    var36=(vector float)si_fma((qword)var21,(qword)var28,(qword)var35);
    var44=(vector float)si_fma((qword)var21,(qword)var36,(qword)var43);
    var52=(vector float)si_fma((qword)var21,(qword)var44,(qword)var51);
    var60=(vector float)si_fma((qword)var21,(qword)var52,(qword)var59);
    var68=(vector float)si_fma((qword)var21,(qword)var60,(qword)var67);
    var72=(vector float)si_selb((qword)var68,(qword)var69,(qword)var71);
    var73=(vector float)si_selb((qword)var72,(qword)var1,(qword)var2);
    return var73;
}

#endif /* MASS_ERF_H */
