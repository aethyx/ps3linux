/**********************************************************************/
/*                                                                    */
/*   Licensed Materials - Property of IBM.                            */
/*   5724-T42 5724-T43 5724-T44                                       */
/*   Copyright IBM Corp. and by others 2007.                          */
/*   All Rights Reserved.                                             */
/*   US Government Users Restricted Rights -                          */
/*   Use, duplication or disclosure restricted by                     */
/*   GSA ADP Schedule Contract with IBM Corp.                         */
/*                                                                    */
/**********************************************************************/

#ifndef MASS_ATAN_H
#define MASS_ATAN_H 1
#include <spu_intrinsics.h>
static __inline vector float _atanf4(vector float var1){
    vector float var10;
    vector float var11;
    vector float var12;
    vector float var13;
    vector float var14;
    vector float var15;
    vector float var16;
    vector float var17;
    vector float var18;
    vector float var19;
    vector float var2;
    vector float var20;
    vector float var21;
    vector float var22;
    vector float var23;
    vector float var24;
    vector float var25;
    vector float var26;
    vector float var27;
    vector float var28;
    vector float var29;
    vector float var3;
    vector float var30;
    vector float var31;
    vector float var32;
    vector float var33;
    vector float var34;
    vector float var35;
    vector float var36;
    vector float var37;
    vector float var38;
    vector float var39;
    vector float var4;
    vector float var40;
    vector float var5;
    vector float var6;
    vector float var7;
    vector float var8;
    vector float var9;
    var11=(vector float)(vector unsigned char){189,243,189,171,189,123,189,60,189,17,188,228,188,182,188,147};
    var12=(vector float)(vector unsigned char){14,120,180,218,12,203,189,32,63,79,3,149,12,81,125,47};
    var13=(vector float)(vector unsigned char){0,1,16,17,0,1,16,17,0,1,16,17,0,1,16,17};
    var14=(vector float)(vector unsigned char){61,255,255,255,61,255,255,255,61,255,255,255,61,255,255,255};
    var16=(vector float)(vector unsigned char){1,1,1,1,5,5,5,5,9,9,9,9,13,13,13,13};
    var18=(vector float)(vector unsigned char){14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14};
    var21=(vector float)(vector unsigned char){62,74,62,62,62,45,62,27,62,11,61,249,61,224,61,201};
    var22=(vector float)(vector unsigned char){246,52,20,57,12,210,179,224,129,203,224,121,31,209,132,130};
    var25=(vector float)(vector unsigned char){190,170,190,169,190,167,190,164,190,160,190,155,190,151,190,146};
    var26=(vector float)(vector unsigned char){164,245,213,182,184,51,124,28,116,32,234,178,26,22,43,25};
    var29=(vector float)(vector unsigned char){63,127,63,127,63,127,63,127,63,127,63,126,63,126,63,125};
    var30=(vector float)(vector unsigned char){255,255,251,119,228,206,177,23,91,62,226,123,72,169,144,193};
    var33=(vector float)(vector unsigned char){51,128,0,0,51,128,0,0,51,128,0,0,51,128,0,0};
    var36=(vector float)(vector unsigned char){63,201,15,219,63,201,15,219,63,201,15,219,63,201,15,219};
    var37=(vector float)(vector unsigned char){128,0,0,0,128,0,0,0,128,0,0,0,128,0,0,0};
    var4=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var7=(vector float)(vector unsigned char){63,128,0,0,63,128,0,0,63,128,0,0,63,128,0,0};
    var38=(vector float)si_selb((qword)var36,(qword)var1,(qword)var37);
    var8=(vector float)si_fcmgt((qword)var1,(qword)var7);
    var2=(vector float)si_frest((qword)var1);
    var3=(vector float)si_fi((qword)var1,(qword)var2);
    var5=(vector float)si_fnms((qword)var1,(qword)var3,(qword)var4);
    var6=(vector float)si_fma((qword)var5,(qword)var3,(qword)var3);
    var9=(vector float)si_selb((qword)var1,(qword)var6,(qword)var8);
    var34=(vector float)si_fm((qword)var9,(qword)var33);
    var10=(vector float)si_fm((qword)var9,(qword)var9);
    var15=(vector float)si_fma((qword)var10,(qword)var14,(qword)var7);
    var17=(vector float)si_shufb((qword)var15,(qword)var15,(qword)var16);
    var19=(vector float)si_selb((qword)var13,(qword)var17,(qword)var18);
    var31=(vector float)si_shufb((qword)var29,(qword)var30,(qword)var19);
    var27=(vector float)si_shufb((qword)var25,(qword)var26,(qword)var19);
    var23=(vector float)si_shufb((qword)var21,(qword)var22,(qword)var19);
    var20=(vector float)si_shufb((qword)var11,(qword)var12,(qword)var19);
    var24=(vector float)si_fma((qword)var10,(qword)var20,(qword)var23);
    var28=(vector float)si_fma((qword)var10,(qword)var24,(qword)var27);
    var32=(vector float)si_fma((qword)var10,(qword)var28,(qword)var31);
    var35=(vector float)si_fma((qword)var9,(qword)var32,(qword)var34);
    var39=(vector float)si_fs((qword)var38,(qword)var35);
    var40=(vector float)si_selb((qword)var35,(qword)var39,(qword)var8);
    return var40;
}

#endif /* MASS_ATAN_H */
