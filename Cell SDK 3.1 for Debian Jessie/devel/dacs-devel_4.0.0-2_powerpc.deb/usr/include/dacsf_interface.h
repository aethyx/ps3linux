!* --------------------------------------------------------------  */
!* (C)Copyright 2006,2008,                                         */
!* International Business Machines Corporation                     */
!* All Rights Reserved.                                            */
!*                                                                 */
!* Redistribution and use in source and binary forms, with or      */
!* without modification, are permitted provided that the           */
!* following conditions are met:                                   */
!*                                                                 */
!* - Redistributions of source code must retain the above copyright*/
!*   notice, this list of conditions and the following disclaimer. */
!*                                                                 */
!* - Redistributions in binary form must reproduce the above       */
!*   copyright notice, this list of conditions and the following   */
!*   disclaimer in the documentation and/or other materials        */
!*   provided with the distribution.                               */
!*                                                                 */
!* - Neither the name of IBM Corporation nor the names of its      */
!*   contributors may be used to endorse or promote products       */
!*   derived from this software without specific prior written     */
!*   permission.                                                   */
!*                                                                 */
!* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
!* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
!* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
!* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
!* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
!* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
!* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
!* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
!* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
!* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
!* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
!* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
!* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
!* --------------------------------------------------------------  */
!* PROLOG END TAG zYx                                              */
!
!*---------------------------------------------------------------------------------------------------------------------------------
!*  DaCS Fortran Binding Include file
!*  Based on the DaCS APIs defined in the C header file dacs.h  release dacs version 1.40
!*  Contains Fortran Subroutine Definitions for the DaCS APIs
!*---------------------------------------------------------------------------------------------------------------------------------

!*---------------------------------------------------------------------------------------------------------------------------------
!*  This include file is compatible with both Fortran fixed and free source forms
!*    - code must be within cols 7 - 132 inclusive
!*    - code must not contain line continuation characters
!*    - comment character is exclamation mark (!) in column 1 or following code
!*    - comments must not exceed column 132
!*---------------------------------------------------------------------------------------------------------------------------------
!*  Compile options for fixed and free form
!*  GNU: -ffree-form  or -ffixed-line-length-0
!*  PATHSCALE: -freeform or -fixedform -extend-source
!*  XLF: -qfree=f90 or -qfixed=132
!*---------------------------------------------------------------------------------------------------------------------------------

      interface

      subroutine dacsf_test(wid,rc)
        include "dacsf.h"
        integer(kind=dacs_wid_t), intent(in)  :: wid
        integer(kind=dacs_err_t), intent(out) :: rc
      end subroutine dacsf_test

      subroutine dacsf_wait(wid,rc)
        include "dacsf.h"
        integer(kind=dacs_wid_t), intent(in)  :: wid
        integer(kind=dacs_err_t), intent(out) :: rc
      end subroutine dacsf_wait

      subroutine dacsf_remote_mem_create(addr,mem_size,access_mode,mem,rc)
        include "dacsf.h"
        integer(kind=dacs_pvoid_t),              intent(in)  :: addr         ! call makevoid to create pvoid from address
        integer(kind=dacs_int64_t),              intent(in)  :: mem_size
        integer(kind=dacs_memory_access_mode_t), intent(in)  :: access_mode
        integer(kind=dacs_remote_mem_t),         intent(out) :: mem
        integer(kind=dacs_err_t),                intent(out) :: rc
      end subroutine dacsf_remote_mem_create

      subroutine dacsf_remote_mem_share(dst_de,dst_pid,mem,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t),      intent(in)  :: dst_de
        integer(kind=dacs_process_id_t), intent(in)  :: dst_pid
        integer(kind=dacs_remote_mem_t), intent(in)  :: mem
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_remote_mem_share

      subroutine dacsf_remote_mem_accept(src_de,src_pid,mem,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t),      intent(in)  :: src_de
        integer(kind=dacs_process_id_t), intent(in)  :: src_pid
        integer(kind=dacs_remote_mem_t), intent(out) :: mem
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_remote_mem_accept

      subroutine dacsf_remote_mem_release(mem,rc)
        include "dacsf.h"
        integer(kind=dacs_remote_mem_t), intent(inout) :: mem
        integer(kind=dacs_err_t),        intent(out)   :: rc
      end subroutine dacsf_remote_mem_release

      subroutine dacsf_remote_mem_destroy(mem,rc)
        include "dacsf.h"
        integer(kind=dacs_remote_mem_t), intent(inout) :: mem
        integer(kind=dacs_err_t),        intent(out)   :: rc
      end subroutine dacsf_remote_mem_destroy

      !dacsf_remote_mem_query has a subroutine for each query type (mode, size, address)
      ! DACS_REMOTE_MEM_ACCESS_MODE
      subroutine dacsf_remote_mem_query_mode(mem,mode,rc)
        include "dacsf.h"
        integer(kind=dacs_remote_mem_t),         intent(in)  :: mem
        integer(kind=dacs_memory_access_mode_t), intent(out) :: mode
        integer(kind=dacs_err_t),                intent(out) :: rc
      end subroutine dacsf_remote_mem_query_mode
      ! DACS_REMOTE_MEM_SIZE
      subroutine dacsf_remote_mem_query_size(mem,mem_size,rc)
        include "dacsf.h"
        integer(kind=dacs_remote_mem_t),         intent(in)  :: mem
        integer(kind=dacs_int64_t),              intent(out) :: mem_size
        integer(kind=dacs_err_t),                intent(out) :: rc
      end subroutine dacsf_remote_mem_query_size
      ! DACS_REMOTE_MEM_ADDR
      subroutine dacsf_remote_mem_query_addr(mem,addr,rc)
        include "dacsf.h"
        integer(kind=dacs_remote_mem_t),         intent(in)  :: mem
        integer(kind=dacs_pvoid_t),              intent(out) :: addr  ! call dacs_makeptr to get ref
        integer(kind=dacs_err_t),                intent(out) :: rc
      end subroutine dacsf_remote_mem_query_addr

      subroutine dacsf_put(dst_remote_mem,dst_remote_mem_offset,src_addr,mem_size,wid,order_attr,swap,rc)
        include "dacsf.h"
        integer(kind=dacs_remote_mem_t), intent(in)  :: dst_remote_mem
        integer(kind=dacs_int64_t),      intent(in)  :: dst_remote_mem_offset
        integer(kind=dacs_pvoid_t),      intent(in)  :: src_addr               ! call makevoid to create pvoid from address
        integer(kind=dacs_int64_t),      intent(in)  :: mem_size
        integer(kind=dacs_wid_t),        intent(in)  :: wid
        integer(kind=dacs_order_attr_t), intent(in)  :: order_attr
        integer(kind=dacs_byte_swap_t),  intent(in)  :: swap
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_put

      subroutine dacsf_get(dst_addr,src_remote_mem,src_remote_mem_offset,mem_size,wid,order_attr,swap,rc)
        include "dacsf.h"
        integer(kind=dacs_pvoid_t),      intent(in)  :: dst_addr             ! call makevoid to create pvoid from address
        integer(kind=dacs_remote_mem_t), intent(in)  :: src_remote_mem
        integer(kind=dacs_int64_t),      intent(in)  :: src_remote_mem_offset
        integer(kind=dacs_int64_t),      intent(in)  :: mem_size
        integer(kind=dacs_wid_t),        intent(in)  :: wid
        integer(kind=dacs_order_attr_t), intent(in)  :: order_attr
        integer(kind=dacs_byte_swap_t),  intent(in)  :: swap
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_get

      subroutine dacsf_put_list(dst_mem,dst_list,dst_count,src_addr,src_list,src_count,wid,order_attr,swap,rc)
        include "dacsf.h"
        integer(kind=dacs_remote_mem_t),      intent(in)  :: dst_mem
        type (dacs_dma_list_t), dimension(*), intent(in)  :: dst_list
        integer(kind=dacs_int32_t),           intent(in)  :: dst_count
        integer(kind=dacs_pvoid_t),           intent(in)  :: src_addr    ! call makevoid to create pvoid from address
        type (dacs_dma_list_t), dimension(*), intent(in)  :: src_list
        integer(kind=dacs_int32_t),           intent(in)  :: src_count
        integer(kind=dacs_wid_t),             intent(in)  :: wid
        integer(kind=dacs_order_attr_t),      intent(in)  :: order_attr
        integer(kind=dacs_byte_swap_t),       intent(in)  :: swap
        integer(kind=dacs_err_t),             intent(out) :: rc
      end subroutine dacsf_put_list

      subroutine dacsf_get_list(dst_addr,dst_list,dst_count,src_mem,src_list,src_count,wid,order_attr,swap,rc)
        include "dacsf.h"
        integer(kind=dacs_pvoid_t),           intent(in)  :: dst_addr    ! call makevoid to create pvoid from address
        type (dacs_dma_list_t), dimension(*), intent(in)  :: dst_list
        integer(kind=dacs_int32_t),           intent(in)  :: dst_count
        integer(kind=dacs_remote_mem_t),      intent(in)  :: src_mem
        type (dacs_dma_list_t), dimension(*), intent(in)  :: src_list
        integer(kind=dacs_int32_t),           intent(in)  :: src_count
        integer(kind=dacs_wid_t),             intent(in)  :: wid
        integer(kind=dacs_order_attr_t),      intent(in)  :: order_attr
        integer(kind=dacs_byte_swap_t),       intent(in)  :: swap
        integer(kind=dacs_err_t),             intent(out) :: rc
      end subroutine dacsf_get_list

      function handler(errdata) RESULT(rc)
        include "dacsf.h"
        integer(kind=dacs_pvoid_t), intent(in) :: errdata
        integer(kind=dacs_err_t) :: rc
      end function handler

      subroutine dacsf_errhandler_reg(handler,flags,rc)
        include "dacsf.h"
        external handler
        integer(kind=dacs_int32_t), intent(in)   :: flags
        integer(kind=dacs_err_t),   intent(out) :: rc
        integer(kind=dacs_err_t) handler                       ! XLF compiler looks for this definition
      end subroutine dacsf_errhandler_reg

      subroutine dacsf_strerror(errcode,errorstr)
        include "dacsf.h"
        integer(kind=dacs_err_t),           intent(in)  :: errcode
        character(len=DACS_MAX_ERRSTR_LEN), intent(out) :: errorstr
      end subroutine dacsf_strerror

      ! following take dacs_error_t as input - used in error handler
      subroutine dacsf_error_num(error,errorcode)
        include "dacsf.h"
        integer(kind=dacs_int64_t), intent(in)  :: error
        integer(kind=dacs_err_t), intent(out) :: errorcode
      end subroutine dacsf_error_num

      subroutine dacsf_error_code(error,errorcode,rc)
        include "dacsf.h"
        integer(kind=dacs_int64_t), intent(in)  :: error
        integer(kind=dacs_int32_t), intent(out) :: errorcode
        integer(kind=dacs_err_t),   intent(out) :: rc
      end subroutine dacsf_error_code

      subroutine dacsf_error_str(error,errorstr,rc)
        include "dacsf.h"
        integer(kind=dacs_int64_t),          intent(in)  :: error
        character(len=DACS_MAX_ERRSTR_LEN),  intent(out) :: errorstr
        integer(kind=dacs_err_t),            intent(out) :: rc
      end subroutine dacsf_error_str

      subroutine dacsf_error_de(error,de,rc)
        include "dacsf.h"
        integer(kind=dacs_int64_t), intent(in)  :: error
        integer(kind=dacs_de_id_t), intent(out) :: de
        integer(kind=dacs_err_t),   intent(out) :: rc
      end subroutine dacsf_error_de

      subroutine dacsf_error_pid(error,pid,rc)
        include "dacsf.h"
        integer(kind=dacs_int64_t),      intent(in)  :: error
        integer(kind=dacs_process_id_t), intent(out) :: pid
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_error_pid

      subroutine dacsf_group_init(group,flags,rc)
        include "dacsf.h"
        integer(kind=dacs_group_t), intent(out) :: group
        integer(kind=dacs_int32_t), intent(in)  :: flags
        integer(kind=dacs_err_t),   intent(out) :: rc
      end subroutine dacsf_group_init

      subroutine dacsf_group_add_member(de,pid,group,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t),      intent(in)  :: de
        integer(kind=dacs_process_id_t), intent(in)  :: pid
        integer(kind=dacs_group_t),      intent(in)  :: group
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_group_add_member

      subroutine dacsf_group_close(group,rc)
        include "dacsf.h"
        integer(kind=dacs_group_t), intent(in)  :: group
        integer(kind=dacs_err_t),   intent(out) :: rc
      end subroutine dacsf_group_close

      subroutine dacsf_group_destroy(group,rc)
        include "dacsf.h"
        integer(kind=dacs_group_t), intent(in)  :: group
        integer(kind=dacs_err_t),   intent(out) :: rc
      end subroutine dacsf_group_destroy

      subroutine dacsf_group_accept(de,pid,group,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t),      intent(in)  :: de
        integer(kind=dacs_process_id_t), intent(in)  :: pid
        integer(kind=dacs_group_t),      intent(out) :: group
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_group_accept

      subroutine dacsf_group_leave(group,rc)
        include "dacsf.h"
        integer(kind=dacs_group_t), intent(in)  :: group
        integer(kind=dacs_err_t),   intent(out) :: rc
      end subroutine dacsf_group_leave

      subroutine dacsf_mailbox_read(msg,src_de,src_pid,rc)
        include "dacsf.h"
        integer(kind=dacs_int32_t),      intent(out) :: msg
        integer(kind=dacs_de_id_t),      intent(in)  :: src_de
        integer(kind=dacs_process_id_t), intent(in)  :: src_pid
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_mailbox_read

      subroutine dacsf_mailbox_write(msg,dst_de,dst_pid,rc)
        include "dacsf.h"
        integer(kind=dacs_int32_t),      intent(in)  :: msg
        integer(kind=dacs_de_id_t),      intent(in)  :: dst_de
        integer(kind=dacs_process_id_t), intent(in)  :: dst_pid
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_mailbox_write

      subroutine dacsf_mailbox_test(rw_flag,de,pid,mbox_status,rc)
        include "dacsf.h"
        integer(kind=dacs_test_mailbox_t), intent(in)  :: rw_flag
        integer(kind=dacs_de_id_t),        intent(in)  :: de
        integer(kind=dacs_process_id_t),   intent(in)  :: pid
        integer(kind=dacs_int32_t),        intent(out) :: mbox_status
        integer(kind=dacs_err_t),          intent(out) :: rc
      end subroutine dacsf_mailbox_test


      subroutine dacsf_num_processes_supported(de,num_processes,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t), intent(in)  :: de
        integer(kind=dacs_int32_t), intent(out) :: num_processes
        integer(kind=dacs_err_t),   intent(out) :: rc
      end subroutine dacsf_num_processes_supported

      subroutine dacsf_num_processes_running(de,num_processes,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t), intent(in)  :: de
        integer(kind=dacs_int32_t), intent(out) :: num_processes
        integer(kind=dacs_err_t),   intent(out) :: rc
      end subroutine dacsf_num_processes_running

      subroutine dacsf_de_wait(de,pid,exit_status,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t),      intent(in)  :: de
        integer(kind=dacs_process_id_t), intent(in)  :: pid
        integer(kind=dacs_int32_t),      intent(out) :: exit_status
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_de_wait

      subroutine dacsf_de_test(de,pid,exit_status,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t),      intent(in)  :: de
        integer(kind=dacs_process_id_t), intent(in)  :: pid
        integer(kind=dacs_int32_t),      intent(out) :: exit_status
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_de_test

      subroutine dacsf_de_kill(de,process_id,type,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t),      intent(in)  :: de
        integer(kind=dacs_process_id_t), intent(in)  :: process_id
        integer(kind=dacs_kill_type_t),  intent(in)  :: type
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_de_kill

      subroutine dacsf_mutex_init(mutex,rc)
        include "dacsf.h"
        integer(kind=dacs_mutex_t), intent(out) :: mutex
        integer(kind=dacs_err_t),   intent(out) :: rc
      end subroutine dacsf_mutex_init

      subroutine dacsf_mutex_share(dst_de,dst_pid,mutex,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t),      intent(in)  :: dst_de
        integer(kind=dacs_process_id_t), intent(in)  :: dst_pid
        integer(kind=dacs_mutex_t),      intent(in)  :: mutex
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_mutex_share

      subroutine dacsf_mutex_accept(remote_de,remote_pid,received_mutex,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t),      intent(in)  :: remote_de
        integer(kind=dacs_process_id_t), intent(in)  :: remote_pid
        integer(kind=dacs_mutex_t),      intent(out) :: received_mutex
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_mutex_accept

      subroutine dacsf_mutex_lock(mutex,rc)
        include "dacsf.h"
        integer(kind=dacs_mutex_t), intent(in)  :: mutex
        integer(kind=dacs_err_t),   intent(out) :: rc
      end subroutine dacsf_mutex_lock

      subroutine dacsf_mutex_try_lock(mutex,rc)
        include "dacsf.h"
        integer(kind=dacs_mutex_t), intent(in)  :: mutex
        integer(kind=dacs_err_t),   intent(out) :: rc
      end subroutine dacsf_mutex_try_lock

      subroutine dacsf_mutex_unlock(mutex,rc)
        include "dacsf.h"
        integer(kind=dacs_mutex_t), intent(in)  :: mutex
        integer(kind=dacs_err_t),   intent(out) :: rc
      end subroutine dacsf_mutex_unlock

      subroutine dacsf_mutex_release(mutex,rc)
        include "dacsf.h"
        integer(kind=dacs_mutex_t), intent(in)  :: mutex
        integer(kind=dacs_err_t),   intent(out) :: rc
      end subroutine dacsf_mutex_release

      subroutine dacsf_mutex_destroy(mutex,rc)
        include "dacsf.h"
        integer(kind=dacs_mutex_t), intent(in)  :: mutex
        integer(kind=dacs_err_t),   intent(out) :: rc
      end subroutine dacsf_mutex_destroy

      subroutine dacsf_barrier_wait(group,rc)
        include "dacsf.h"
        integer(kind=dacs_group_t), intent(in)  :: group
        integer(kind=dacs_err_t),   intent(out) :: rc
      end subroutine dacsf_barrier_wait

      subroutine dacsf_runtime_init(rc)
        include "dacsf.h"
        integer(kind=dacs_err_t), intent(out) :: rc
      end subroutine dacsf_runtime_init

      subroutine dacsf_init(config_flags, rc)
        include "dacsf.h"
        integer(kind=dacs_init_flag_t), intent(in) :: config_flags
        integer(kind=dacs_err_t), intent(out)      :: rc
      end subroutine dacsf_init

      subroutine dacsf_runtime_exit(rc)
        include "dacsf.h"
        integer(kind=dacs_err_t), intent(out) :: rc
      end subroutine dacsf_runtime_exit

      subroutine dacsf_exit(rc)
        include "dacsf.h"
        integer(kind=dacs_err_t), intent(out) :: rc
      end subroutine dacsf_exit

      subroutine dacsf_recv(dst_data,len,src_de,src_pid,stream,wid,swap,rc)
        include "dacsf.h"
        integer(kind=dacs_pvoid_t),      intent(in)  ::  dst_data  ! call makevoid to create pvoid from address
        integer(kind=dacs_int32_t),      intent(in)  ::  len
        integer(kind=dacs_de_id_t),      intent(in)  ::  src_de
        integer(kind=dacs_process_id_t), intent(in)  ::  src_pid
        integer(kind=dacs_stream_t),     intent(in)  ::  stream
        integer(kind=dacs_wid_t),        intent(in)  ::  wid
        integer(kind=dacs_byte_swap_t),  intent(in)  ::  swap
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_recv

      subroutine dacsf_send(src_data,len,dst_de,dst_pid,stream,wid,swap,rc)
        include "dacsf.h"
        integer(kind=dacs_pvoid_t),      intent(in)  :: src_data   ! call makevoid to create pvoid from address
        integer(kind=dacs_int32_t),      intent(in)  :: len
        integer(kind=dacs_de_id_t),      intent(in)  :: dst_de
        integer(kind=dacs_process_id_t), intent(in)  :: dst_pid
        integer(kind=dacs_stream_t),     intent(in)  :: stream
        integer(kind=dacs_wid_t),        intent(in)  :: wid
        integer(kind=dacs_byte_swap_t),  intent(in)  :: swap
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_send

      subroutine dacsf_get_num_avail_children(type, num_children,rc)
        include "dacsf.h"
        integer(kind=dacs_de_type_t), intent(in)  :: type
        integer(kind=dacs_int32_t),   intent(out) :: num_children
        integer(kind=dacs_err_t),     intent(out) :: rc
      end subroutine dacsf_get_num_avail_children

      subroutine dacsf_reserve_children(type, num_children, de_list,rc)
        include "dacsf.h"
        integer(kind=dacs_de_type_t),        intent(in)       :: type
        integer(kind=dacs_int32_t),          intent(inout)    :: num_children
        integer(kind=dacs_de_id_t), dimension(*), intent(out) :: de_list
        integer(kind=dacs_err_t),            intent(out)      :: rc
      end subroutine dacsf_reserve_children

      subroutine dacsf_release_de_list(num_des,de_list,rc)
        include "dacsf.h"
        integer(kind=dacs_int32_t),          intent(in)      :: num_des
        integer(kind=dacs_de_id_t), dimension(*), intent(in) :: de_list
        integer(kind=dacs_err_t),            intent(out)     :: rc
      end subroutine dacsf_release_de_list

      subroutine dacsf_wid_reserve(wid,rc)
        include "dacsf.h"
        integer(kind=dacs_wid_t), intent(out) :: wid
        integer(kind=dacs_err_t), intent(out) :: rc
      end subroutine dacsf_wid_reserve

      subroutine dacsf_wid_release(wid,rc)
        include "dacsf.h"
        integer(kind=dacs_wid_t), intent(inout)  :: wid
        integer(kind=dacs_err_t), intent(out) :: rc
      end subroutine dacsf_wid_release

      subroutine dacsf_mem_create(addr,mem_size,rmt_access_mode,lcl_access_mode,mem_handle,rc)
        include "dacsf.h"
        integer(kind=dacs_pvoid_t),           intent(in)  :: addr         ! call makevoid to create pvoid from address
        integer(kind=dacs_int64_t),           intent(in)  :: mem_size
        integer(kind=dacs_mem_access_mode_t), intent(in)  :: rmt_access_mode
        integer(kind=dacs_mem_access_mode_t), intent(in)  :: lcl_access_mode
        integer(kind=dacs_mem_t),             intent(out) :: mem_handle
        integer(kind=dacs_err_t),             intent(out) :: rc
      end subroutine dacsf_mem_create

      subroutine dacsf_mem_share(dst_de,dst_pid,mem_handle,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t),      intent(in)  :: dst_de
        integer(kind=dacs_process_id_t), intent(in)  :: dst_pid
        integer(kind=dacs_mem_t),        intent(in)  :: mem_handle
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_mem_share

      subroutine dacsf_mem_register(dst_de,dst_pid,mem_handle,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t),      intent(in)  :: dst_de
        integer(kind=dacs_process_id_t), intent(in)  :: dst_pid
        integer(kind=dacs_mem_t),        intent(in)  :: mem_handle
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_mem_register

      subroutine dacsf_mem_deregister(dst_de,dst_pid,mem_handle,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t),      intent(in)  :: dst_de
        integer(kind=dacs_process_id_t), intent(in)  :: dst_pid
        integer(kind=dacs_mem_t),        intent(in)  :: mem_handle
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_mem_deregister

      subroutine dacsf_mem_accept(src_de,src_pid,mem_handle,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t),      intent(in)  :: src_de
        integer(kind=dacs_process_id_t), intent(in)  :: src_pid
        integer(kind=dacs_mem_t),        intent(in)  :: mem_handle
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_mem_accept

      subroutine dacsf_mem_release(mem_handle,rc)
        include "dacsf.h"
        integer(kind=dacs_mem_t),        intent(inout)  :: mem_handle
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_mem_release

      subroutine dacsf_mem_destroy(mem_handle,rc)
        include "dacsf.h"
        integer(kind=dacs_mem_t),        intent(inout)  :: mem_handle
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_mem_destroy

      !dacsf_mem_query has a subroutine for each query type (mode (lcl and rmt), size, address)
      ! DACS_LCL_MEM_PERM
      subroutine dacsf_mem_query_lcl_perm(mem_handle,lcl_mode,rc)
        include "dacsf.h"
        integer(kind=dacs_mem_t),             intent(in)  :: mem_handle
        integer(kind=dacs_mem_access_mode_t), intent(out) :: lcl_mode
        integer(kind=dacs_err_t),             intent(out) :: rc
      end subroutine dacsf_mem_query_lcl_perm
      ! DACS_RMT_MEM_PERM
      subroutine dacsf_mem_query_rmt_perm(mem_handle,rmt_mode,rc)
        include "dacsf.h"
        integer(kind=dacs_mem_t),             intent(in)  :: mem_handle
        integer(kind=dacs_mem_access_mode_t), intent(out) :: rmt_mode
        integer(kind=dacs_err_t),             intent(out) :: rc
      end subroutine dacsf_mem_query_rmt_perm
      ! DACS_MEM_SIZE
      subroutine dacsf_mem_query_size(mem_handle,mem_size,rc)
        include "dacsf.h"
        integer(kind=dacs_mem_t),        intent(in)  :: mem_handle
        integer(kind=dacs_int64_t),      intent(out) :: mem_size
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_mem_query_size
      ! DACS_MEM_ADDR
      subroutine dacsf_mem_query_addr(mem_handle,addr,rc)
        include "dacsf.h"
        integer(kind=dacs_mem_t),        intent(in)  :: mem_handle
        integer(kind=dacs_pvoid_t),      intent(out) :: addr  ! call dacs_makeptr to get ref
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_mem_query_addr

      subroutine dacsf_mem_limits_query(attr,tgt_de,tgt_pid,limit,rc)
        include "dacsf.h"
        integer(kind=dacs_mem_limits_t), intent(in)  :: attr
        integer(kind=dacs_de_id_t),      intent(in)  :: tgt_de
        integer(kind=dacs_process_id_t), intent(in)  :: tgt_pid
        integer(kind=dacs_int64_t),      intent(out) :: limit
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_mem_limits_query


      subroutine dacsf_mem_put(dst_remote_handle,dst_offset,src_local_handle,src_offset,mem_size,wid,order_attr,swap,rc)
        include "dacsf.h"
        integer(kind=dacs_mem_t),        intent(in)  :: dst_remote_handle
        integer(kind=dacs_int64_t),      intent(in)  :: dst_offset
        integer(kind=dacs_mem_t),        intent(in)  :: src_local_handle
        integer(kind=dacs_int64_t),      intent(in)  :: src_offset
        integer(kind=dacs_int64_t),      intent(in)  :: mem_size
        integer(kind=dacs_wid_t),        intent(in)  :: wid
        integer(kind=dacs_order_attr_t), intent(in)  :: order_attr
        integer(kind=dacs_byte_swap_t),  intent(in)  :: swap
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_mem_put

      subroutine dacsf_mem_get(dst_lcl_handle,dst_offset,src_rmt_handle,src_offset,mem_size,wid,order_attr,swap,rc)
        include "dacsf.h"
        integer(kind=dacs_mem_t),        intent(in)  :: dst_lcl_handle
        integer(kind=dacs_int64_t),      intent(in)  :: dst_offset
        integer(kind=dacs_mem_t),        intent(in)  :: src_rmt_handle
        integer(kind=dacs_int64_t),      intent(in)  :: src_offset
        integer(kind=dacs_int64_t),      intent(in)  :: mem_size
        integer(kind=dacs_wid_t),        intent(in)  :: wid
        integer(kind=dacs_order_attr_t), intent(in)  :: order_attr
        integer(kind=dacs_byte_swap_t),  intent(in)  :: swap
        integer(kind=dacs_err_t),        intent(out) :: rc
      end subroutine dacsf_mem_get

      subroutine dacsf_mem_put_list(dst_rmt_handle,dst_list,dst_count,src_lcl_handle,src_list,src_count,wid,order_attr,swap,rc)
        include "dacsf.h"
        integer(kind=dacs_mem_t),             intent(in)  :: dst_rmt_handle
        type (dacs_dma_list_t), dimension(*), intent(in)  :: dst_list
        integer(kind=dacs_int32_t),           intent(in)  :: dst_count
        integer(kind=dacs_mem_t),             intent(in)  :: src_lcl_handle
        type (dacs_dma_list_t), dimension(*), intent(in)  :: src_list
        integer(kind=dacs_int32_t),           intent(in)  :: src_count
        integer(kind=dacs_wid_t),             intent(in)  :: wid
        integer(kind=dacs_order_attr_t),      intent(in)  :: order_attr
        integer(kind=dacs_byte_swap_t),       intent(in)  :: swap
        integer(kind=dacs_err_t),             intent(out) :: rc
      end subroutine dacsf_mem_put_list

      subroutine dacsf_mem_get_list(dst_lcl_handle,dst_list,dst_count,src_rmt_handle,src_list,src_count,wid,order_attr,swap,rc)
        include "dacsf.h"
        integer(kind=dacs_mem_t),             intent(in)  :: dst_lcl_handle
        type (dacs_dma_list_t), dimension(*), intent(in)  :: dst_list
        integer(kind=dacs_int32_t),           intent(in)  :: dst_count
        integer(kind=dacs_mem_t),             intent(in)  :: src_rmt_handle
        type (dacs_dma_list_t), dimension(*), intent(in)  :: src_list
        integer(kind=dacs_int32_t),           intent(in)  :: src_count
        integer(kind=dacs_wid_t),             intent(in)  :: wid
        integer(kind=dacs_order_attr_t),      intent(in)  :: order_attr
        integer(kind=dacs_byte_swap_t),       intent(in)  :: swap
        integer(kind=dacs_err_t),             intent(out) :: rc
      end subroutine dacsf_mem_get_list
      end interface

!     the dacsf_de_start interface allows reference either the generic dacsf_de_start or the specific subroutine
      interface dacsf_de_start
      subroutine dacsf_de_start_std_file(de,prog,argv,argv_size,envv,envv_size,creation_flags,pid,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t),               intent(in)  :: de
        character(len=*),                         intent(in)  :: prog
        character(len=*), dimension(*),           intent(in)  :: argv
        integer,                                  intent(in)  :: argv_size
        character(len=*), dimension(*),           intent(in)  :: envv
        integer,                                  intent(in)  :: envv_size
        integer(kind=dacs_proc_creation_flag_t),  intent(in)  :: creation_flags
        integer(kind=dacs_process_id_t),          intent(out) :: pid
        integer(kind=dacs_err_t),                 intent(out) :: rc
      end subroutine dacsf_de_start_std_file

      subroutine dacsf_de_start_std_embedded(de,prog,argv,argv_size,envv,envv_size,pid,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t),               intent(in)  :: de
        external                                              :: prog
        character(len=*), dimension(*),           intent(in)  :: argv
        integer,                                  intent(in)  :: argv_size
        character(len=*), dimension(*),           intent(in)  :: envv
        integer,                                  intent(in)  :: envv_size
        integer(kind=dacs_process_id_t),          intent(out) :: pid
        integer(kind=dacs_err_t),                 intent(out) :: rc
      end subroutine dacsf_de_start_std_embedded

      subroutine dacsf_de_start_ptr_file(de,prog,argv,envv,creation_flags,pid,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t),              intent(in)  :: de
        character(len=*),                        intent(in)  :: prog
        integer(kind=dacs_pvoid_t),              intent(in)  :: argv           ! call makevoid to create pvoid from address
        integer(kind=dacs_pvoid_t),              intent(in)  :: envv           ! call makevoid to create pvoid from address
        integer(kind=dacs_proc_creation_flag_t), intent(in)  :: creation_flags
        integer(kind=dacs_process_id_t),         intent(out) :: pid
        integer(kind=dacs_err_t),                intent(out) :: rc
      end subroutine dacsf_de_start_ptr_file

      subroutine dacsf_de_start_ptr_embedded(de,prog,argv,envv,pid,rc)
        include "dacsf.h"
        integer(kind=dacs_de_id_t),              intent(in)  :: de
        external                                             :: prog
        integer(kind=dacs_pvoid_t),              intent(in)  :: argv   ! call makevoid to create pvoid from address
        integer(kind=dacs_pvoid_t),              intent(in)  :: envv   ! call makevoid to create pvoid from address
        integer(kind=dacs_process_id_t),         intent(out) :: pid
        integer(kind=dacs_err_t),                intent(out) :: rc
      end subroutine dacsf_de_start_ptr_embedded
      end interface dacsf_de_start
