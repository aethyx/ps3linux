/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#if defined(__VEC__) || defined(__ALTIVEC__)
#ifndef _SCALBNF4_H_
#define _SCALBNF4_H_	1

#include <altivec.h>
#include <vec_types.h>

/*
 * FUNCTION
 *	vector float _scalbnf4(vector float x, vector signed int exp)
 *
 * DESCRIPTION
 *      The _scalbnf4 function returns a vector containing each element of x 
 *      multiplied by 2^n computed efficiently.  This function is computed 
 *      without the assistance of any floating point operations and as such 
 *      does not set any floating point exceptions.
 *
 *      Special Cases:
 *	  - if the exponent is 0, then x is either 0 or a subnormal, and the
 *          result will be returned as 0.
 *        - if the result if underflows, it will be returned as 0.
 *        - if the result overflows, it will be returned as FLT_MAX.
 *
 */
static __inline vector float _scalbnf4(vector float x, vector signed int scale)
{
  vec_int4  x_exp;
  vec_uint4 zero;
  vec_uint4 overflow;
  vec_uint4 underflow;
  vec_uint4 naninf;
  vec_int4  zeroL     = (vec_int4)  { 0, 0, 0, 0};
  vec_int4  oneL      = (vec_int4)  { 1, 1, 1, 1};
  vec_int4  exp_max   = (vec_int4)  {0xFE, 0xFE, 0xFE, 0xFE};
  vec_int4  exp_ovrfl = (vec_int4)  {0xFF, 0xFF, 0xFF, 0xFF};
  vec_uint4 exp_shift = (vec_uint4) {23, 23, 23, 23};
  vec_uint4 exp_mask  = (vec_uint4) {0x7F800000, 0x7F800000, 
                                     0x7F800000, 0x7F800000};
  vec_uint4 sign_mask = (vec_uint4) {0x80000000, 0x80000000, 
                                     0x80000000, 0x80000000};
  vec_float4 out;


  x_exp = vec_sr(vec_and((vec_int4)x, (vec_int4)exp_mask), exp_shift);

  /* Check the input. If the exponent is 0, then x is either 0 
   * or a denorm and x*2^exp is a zero by spec. If input is Nan or
   * infinite, we will return it.
   */
  zero   = (vec_uint4)vec_cmpeq(x_exp, zeroL);
  naninf = (vec_uint4)vec_cmpeq(x_exp, exp_ovrfl);

  /* Compute the scaled exponent.
   */
  x_exp = vec_add(scale, x_exp);

  /* Now check the resulting exponent.
   */
  overflow = (vec_uint4)vec_cmpgt(x_exp, exp_max);
  underflow = (vec_uint4)vec_cmplt(x_exp, oneL);

  /* Merge the calculated exponent with x's mantissa.
   */
  out = vec_sel(x, (vec_float4)vec_sl(x_exp, exp_shift), exp_mask);

  /* Zero the result if underflow and force to infinite if overflow.
   * Preserve sign of x in output.
   */
  out = vec_sel(out, (vec_float4)exp_mask, overflow);
  out = vec_sel(out, (vec_float4)zeroL, vec_or(zero, underflow));
  out = vec_sel(out, x, naninf);
  out = vec_sel(out, x, sign_mask);

  return (out);
}

#endif /* _SCALBNF4_H_ */
#endif /* defined(__VEC__) || defined(__ALTIVEC__) */
