/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _POWF4_H_
#define _POWF4_H_	1


#include <altivec.h>
#include "exp2f4.h"
#include "log2f4.h"
#include <vec_types.h>

/*
 * FUNCTION
 *	vector float _powf4(vector float x, vector float y)
 *
 * DESCRIPTION
 *	The _powf4 function computes x raised to the power y for the set of 
 *	vectors. The powf4 function is computed as by decomposing 
 *	the problem into:
 *
 *		x^y = 2^(y*log2(x))
 *
 */
static __inline vector float _powf4(vector float x, vector float y)
{
  vec_int4   y_exp;
  vec_int4   x_exp;
  vec_uint4  y_mantissa;
  vec_uint4  mant_shift;
  vec_int4   mant_bias = (vector int) {-127, -127, -127, -127};
  vec_uint4  y_is_int;
  vec_uint4  y_is_odd;
  vec_uint4  x_sign_bit;
  vec_uint4  zero = (vector unsigned int) {0, 0, 0, 0};
  vec_float4 onef = (vector float) {1.0f, 1.0f, 1.0f, 1.0f};
  vec_uint4  bit0 = (vector unsigned int) {0x80000000, 0x80000000, 
		                                   0x80000000, 0x80000000};
  vec_float4 x_abs;
  vec_float4 y_abs;
  vec_uint4  exp_mask  = (vector unsigned int) {0xFF, 0xFF, 0xFF, 0xFF};
  vec_uint4  num_exp_bits = (vector unsigned int) {8, 8, 8, 8};
  vec_uint4  mant_bits = (vector unsigned int) {23, 23, 23, 23};
  vec_int4   int_exp   = (vector int) {126, 126, 126, 126};
  vec_int4   error     = (vector signed int) {-1, -1, -1, -1};

  vec_float4 out;


  x_abs = (vec_float4)vec_andc((vec_uint4)x, bit0);
  y_abs = (vec_float4)vec_andc((vec_uint4)y, bit0);

  x_exp = (vec_int4)vec_and(vec_sr((vec_uint4)x, mant_bits), exp_mask);
  y_exp = (vec_int4)vec_and(vec_sr((vec_uint4)y, mant_bits), exp_mask);

  /* Need the implied bit in the mantissa to catch 
   * y = 1 case later
   */
  y_mantissa = vec_or(vec_sl((vec_uint4)y, num_exp_bits), bit0);

  x_sign_bit = vec_and((vec_uint4)x, bit0);

  /* We are going to shift the mantissa over enough to 
   * determine if we have an integer.
   */
  mant_shift = (vec_uint4) vec_add(y_exp, mant_bias);

  /* Leave the lowest-order integer bit of mantissa on the 
   * high end so we can see if the integer is odd.
   */
  y_mantissa = vec_sl(y_mantissa, mant_shift);

  y_is_int = (vec_uint4)vec_cmpeq(vec_andc(y_mantissa, bit0), zero);
  y_is_int = vec_and(y_is_int, vec_cmpgt(y_exp, int_exp));

  y_is_odd = vec_and(vec_cmpeq(y_mantissa, bit0), y_is_int);

  out = _exp2f4(vec_madd(y, _log2f4(x_abs), (vec_float4)zero));

  /* x < 0 is only ok when y integer 
   */
  out = vec_sel(out, (vec_float4)error, 
				  vec_andc(vec_cmpeq(x_sign_bit, bit0), y_is_int));

  /* Preserve the sign of x if y is an odd integer
   */
  out = vec_sel(out, vec_or(out, (vec_float4)x_sign_bit), y_is_odd);

  /* x = anything, y = +/- 0, returns 1
   */
  out = vec_sel(out, onef, vec_cmpeq(y, (vec_float4)zero));

  return(out);
}

#endif /* _POWF4_H_ */

