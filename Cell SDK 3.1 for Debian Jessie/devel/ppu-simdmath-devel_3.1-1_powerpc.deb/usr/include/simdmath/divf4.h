/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _DIVF4_H_
#define _DIVF4_H_	1

#include <altivec.h>
#include <vec_types.h>

/*
 * FUNCTION
 * 	vector float _divf4(vector float dividend, vector float divisor)
 * 
 * DESCRIPTION
 * 	The _divf4 function divides the vector dividend by the vector divisor
 *      and returns the resulting vector quotient.
 *
 */
static __inline vector float _divf4(vector float x, vector float y)
{
  vec_float4 one = ((vec_float4) { 1.0f, 1.0f, 1.0f, 1.0f });
  vec_float4 zero = ((vec_float4) { 0.0f, 0.0f, 0.0f, 0.0f });
  vec_float4 neg_zero = (vec_float4) { -0.0f, -0.0f, -0.0f, -0.0f };
  vec_uint4 exp_mask = ((vec_uint4) { 0x7F800000, 0x7F800000, 0x7F800000, 0x7F800000 });
  vec_float4 signal_nan = (vec_float4)((vec_uint4) { 0x7FC00000, 0x7FC00000, 0x7FC00000, 0x7FC00000 });
  vec_uint4 exp_mask2 = (vec_uint4) { 0xFF800000,0xFF800000,0xFF800000,0xFF800000 };

  //  Extract and preserve the expected final sign
  vec_float4 sign = vec_and(vec_xor(x,y),neg_zero);

  //  Extract the exponents from the inputs
  vec_uint4 exp_x = vec_and((vec_uint4)x, exp_mask);
  vec_uint4 exp_y = vec_and((vec_uint4)y, exp_mask);

  vec_uint4 x_abs = (vec_uint4)vec_abs(x);
  vec_uint4 y_abs = (vec_uint4)vec_abs(y);

  vec_uint4 x_inf = (vec_uint4)vec_cmpeq(x_abs,exp_mask);
  vec_uint4 y_inf = (vec_uint4)vec_cmpeq(y_abs,exp_mask);

  vec_uint4 x_nan = (vec_uint4)vec_cmpgt(x_abs,exp_mask);
  vec_uint4 y_nan = (vec_uint4)vec_cmpgt(y_abs,exp_mask);

  vec_uint4 x_zero = (vec_uint4)vec_cmpeq(exp_x,(vec_uint4)zero);
  vec_uint4 y_zero = (vec_uint4)vec_cmpeq(exp_y,(vec_uint4)zero);


  //  Force denormal inputs to correctly signed zeros
  x = vec_sel(x,sign,x_zero);
  y = vec_sel(y,sign,y_zero);

  //  Force mantissa of divisor and dividend intp the range 1.0 <= x < 2.0
  vec_float4 mant_x = vec_sel(x, one, exp_mask);
  vec_float4 mant_y = vec_sel(y, one, exp_mask);

  //  Compute the quotient of the mantissas using a recip estimate
  //  and Newton-Raphson iterations
  vec_float4 inv_y = vec_re(mant_y);
  vec_float4 q0 = vec_madd(mant_x, inv_y, zero);
  vec_float4 e0 = vec_nmsub(mant_y,q0,mant_x);
  vec_float4 q1 = vec_madd(inv_y,e0,q0);
  e0 = vec_nmsub(mant_y,q1,mant_x);
  q1 = vec_madd(inv_y,e0,q1);


  //  Compute rough estimate of the exponent
  //  exp = (x_exp + 1.0) - y_exp
  vec_uint4 exp = vec_sub(vec_add(exp_x,(vec_uint4)one),exp_y);

  //  Add in any additional delta caused by the mantissas rolling over/under
  exp  = vec_add(exp, vec_cmpgt(vec_abs(mant_y), vec_abs(mant_x)));


  //  If result exponent has extra bit we have exceeded our bounds
  vec_uint4 oob = (vec_uint4)vec_cmple((vec_float4)exp,zero);

  vec_uint4 signed_exp = vec_and(exp,exp_mask2);

  //  Remove and extra bits accumulated along the way
  exp = vec_and(exp,exp_mask);


  //  Check for underflows.  These occur when:
  //
  //  1) we are out of bounds, and the result exponent is positive OR
  //  2) we are within bounds, and the result exponent +0 or -Inf
  vec_uint4 underflow;

  // check OOB and exp > 0
  underflow = vec_and((vec_uint4)vec_cmpge((vec_float4)exp,one),oob);

  // check exp == +0
  underflow = vec_or(underflow,vec_cmpeq(signed_exp,(vec_uint4)zero));

  // check exp == -Inf
  underflow = vec_or(underflow,vec_cmpeq(signed_exp,exp_mask2));


  //  Check for overflow.  These occur when:
  //
  //  1) we are out of bounds, but not underflowing OR
  //  2) we are within bounds, and the result exponent is -0 or +Inf
  vec_uint4 overflow;

  // check OOB and not underflowing
  overflow = vec_andc(oob,underflow);

  // check exp == -0
  overflow = vec_or(overflow,vec_cmpeq(exp,(vec_uint4)zero));

  // check exp == +Inf
  overflow = vec_or(overflow,vec_cmpeq(signed_exp,exp_mask));


  // If we overflowed, set exponent to max_exp
  exp = vec_sel(exp,exp_mask,overflow);

  // If we underflowed, set exponent to zero
  exp = vec_sel(exp,(vec_uint4)zero,underflow);


  //  Set the generated mantissa to zero if there was either an overflow or
  //  an underflow
  q1 = vec_sel(q1,zero,vec_andc(vec_or(overflow,underflow),(vec_uint4)neg_zero));

  //  Merge the exponent back into the mantissa
  q1 = vec_sel(q1,(vec_float4)exp, exp_mask);


  //
  //  Handle special cases.
  //

  // If divisor is Inf, force output to correctly signed 0
  q1 = vec_sel(q1,sign,y_inf);

  // If dividend is Inf, force output to correctly signed Inf
  q1 = vec_sel(q1,vec_or(sign,(vec_float4)exp_mask),x_inf);

  // If both dividend and divisor are Inf, force output to NaN
  q1 = vec_sel(q1,signal_nan,vec_and(x_inf,y_inf));

  //  If dividend is 0, force output to correctly signed zero
  q1 = vec_sel(q1,sign,x_zero);

  // If divisor is NaN, force output to NaN
  q1 = vec_sel(q1,vec_or(y,signal_nan),y_nan);

  // If dividend is NaN, force output to NaN
  q1 = vec_sel(q1,vec_or(x,signal_nan),x_nan);

  //  If divisor is 0, force output to signal NaN
  q1 = vec_sel(q1,signal_nan,y_zero);

  return q1;
  

}


#endif /* _DIVF4_H_ */
