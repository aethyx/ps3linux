/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _ACOSHF4_H_
#define _ACOSHF4_H_	1

#include <altivec.h>
#include <vec_types.h>

#include "logf4.h"
#include "sqrtf4.h"

/*
 * FUNCTION
 *  vector float _acoshf4(vector float x)
 *
 * DESCRIPTION
 *  The acoshf4 function returns a vector containing the hyperbolic
 *  arccosines of the corresponding elements of the input vector.
 *
 *  We are using the formula:
 *    acosh = ln(x + sqrt(x^2 - 1))
 *
 *  For x near one, we use the Taylor series:
 *
 *                infinity
 *                 ------
 *                  -   '        
 *                   -                 k
 *    acosh x =       -      C  (x - 1)
 *                   -        k
 *                  -   ,
 *                 ------
 *                 k = 0
 *
 *
 *  Special Cases:
 *	- acosh(1)        = +0
 *	- NaNs and Infinity aren't supported for single-precision on SPU.
 *
 */

/*
 * Taylor Series Coefficients 
 * for x around 1.
 */
#define ACOSH_TAY01  1.0000000000000000000000000000000000000E0f  /* 1 / 1                    */
#define ACOSH_TAY02 -8.3333333333333333333333333333333333333E-2f /* 1 / 12                   */
#define ACOSH_TAY03  1.8750000000000000000000000000000000000E-2f /* 3 / 160                  */
#define ACOSH_TAY04 -5.5803571428571428571428571428571428571E-3f /* 5 / 896                  */
#define ACOSH_TAY05  1.8988715277777777777777777777777777778E-3f /* 35 / 18432               */
#define ACOSH_TAY06 -6.9912997159090909090909090909090909091E-4f /* 63 / 90112               */
#define ACOSH_TAY07  2.7113694411057692307692307692307692308E-4f /* 231 / 851968             */
#define ACOSH_TAY08 -1.0910034179687500000000000000000000000E-4f /* 143 / 1310720            */
#define ACOSH_TAY09  4.5124222250545726102941176470588235294E-5f /* 6435 / 142606336         */
#define ACOSH_TAY10 -1.9065643611707185444078947368421052632E-5f /* 12155 / 637534208        */
#define ACOSH_TAY11  8.1936873140789213634672619047619047619E-6f /* 46189 / 5637144576       */
#define ACOSH_TAY12 -3.5705692742181860882302989130434782609E-6f /* 88179 / 24696061952      */
#define ACOSH_TAY13  1.5740259550511837005615234375000000000E-6f /* 676039 / 429496729600    */
#define ACOSH_TAY14 -7.0068819224144573564882631655092592593E-7f /* 1300075 / 1855425871872  */
#define ACOSH_TAY15  3.1453306166503321507881427633351293103E-7f /* 5014575 / 15942918602752 */


static __inline vector float _acoshf4(vector float x)
{
    vec_float4 minus_onef = ((vector float){-1.0f, -1.0f, -1.0f, -1.0f});
    vec_float4 zerof      = ((vector float){0.0f, 0.0f, 0.0f, 0.0f});
    vec_float4 twof       = ((vector float){2.0f, 2.0f, 2.0f, 2.0f});
    vec_float4 xminus1;
    /* Where we switch from taylor to formula */
    vec_float4  switch_approx = ((vector float){2.0f, 2.0f, 2.0f, 2.0f});
    vector bool int use_form;
    vec_float4 result, fresult, mresult;;


    /*
     * Formula:
     *   acosh = ln(x + sqrt(x^2 - 1))
     */
    fresult = _sqrtf4(vec_madd(x, x, minus_onef));
    fresult = vec_add(x, fresult);
    fresult = _logf4(fresult);

    /*
     * Taylor Series
     */
    xminus1 = vec_add(x, minus_onef);

    mresult = vec_madd(xminus1, ((vector float){ACOSH_TAY15, ACOSH_TAY15, ACOSH_TAY15, ACOSH_TAY15}), 
                                ((vector float){ACOSH_TAY14, ACOSH_TAY14, ACOSH_TAY14, ACOSH_TAY14}));
    mresult = vec_madd(xminus1, mresult, ((vector float){ACOSH_TAY13, ACOSH_TAY13, ACOSH_TAY13, ACOSH_TAY13}));
    mresult = vec_madd(xminus1, mresult, ((vector float){ACOSH_TAY12, ACOSH_TAY12, ACOSH_TAY12, ACOSH_TAY12}));
    mresult = vec_madd(xminus1, mresult, ((vector float){ACOSH_TAY11, ACOSH_TAY11, ACOSH_TAY11, ACOSH_TAY11}));
    mresult = vec_madd(xminus1, mresult, ((vector float){ACOSH_TAY10, ACOSH_TAY10, ACOSH_TAY10, ACOSH_TAY10}));
    mresult = vec_madd(xminus1, mresult, ((vector float){ACOSH_TAY09, ACOSH_TAY09, ACOSH_TAY09, ACOSH_TAY09}));
    mresult = vec_madd(xminus1, mresult, ((vector float){ACOSH_TAY08, ACOSH_TAY08, ACOSH_TAY08, ACOSH_TAY08}));
    mresult = vec_madd(xminus1, mresult, ((vector float){ACOSH_TAY07, ACOSH_TAY07, ACOSH_TAY07, ACOSH_TAY07}));
    mresult = vec_madd(xminus1, mresult, ((vector float){ACOSH_TAY06, ACOSH_TAY06, ACOSH_TAY06, ACOSH_TAY06}));
    mresult = vec_madd(xminus1, mresult, ((vector float){ACOSH_TAY05, ACOSH_TAY05, ACOSH_TAY05, ACOSH_TAY05}));
    mresult = vec_madd(xminus1, mresult, ((vector float){ACOSH_TAY04, ACOSH_TAY04, ACOSH_TAY04, ACOSH_TAY04}));
    mresult = vec_madd(xminus1, mresult, ((vector float){ACOSH_TAY03, ACOSH_TAY03, ACOSH_TAY03, ACOSH_TAY03}));
    mresult = vec_madd(xminus1, mresult, ((vector float){ACOSH_TAY02, ACOSH_TAY02, ACOSH_TAY02, ACOSH_TAY02}));
    mresult = vec_madd(xminus1, mresult, ((vector float){ACOSH_TAY01, ACOSH_TAY01, ACOSH_TAY01, ACOSH_TAY01}));
    
    mresult = vec_madd(mresult, _sqrtf4(vec_madd(xminus1, twof, zerof)), zerof);

    /*
     * Select series or formula
     */
    use_form = vec_cmpgt(x, switch_approx);
    result = vec_sel(mresult, fresult, use_form);

    return result;
}

#endif /* _ACOSHF4_H_ */
