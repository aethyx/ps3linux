/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _ASINHF4_H_
#define _ASINHF4_H_	1

#include <altivec.h>
#include <vec_types.h>

#include "logf4.h"
#include "sqrtf4.h"

/*
 * FUNCTION
 *  vector float _asinhf4(vector float x)
 *
 * DESCRIPTION
 *  The asinhf4 function returns a vector containing the hyperbolic
 *  arcsines of the corresponding elements of the input vector.
 *
 *  We are using the formula:
 *    asinh = ln(|x| + sqrt(x^2 + 1))
 *  and the anti-symmetry of asinh.
 *
 *  For x near zero, we use the Taylor series:
 *
 *                infinity
 *                 ------
 *                  -   '  P  (0)
 *                   -      k-1    k
 *    asinh x =       -    -----  x
 *                   -       k
 *                  -   ,
 *                 ------
 *                 k = 1
 *
 *  Special Cases:
 *   - asinh(+0)        returns +0
 *   - asinh(-0)        returns -0
 *   - Normally,  asinh(+/- infinity) returns +/- infinity,
 *	   but on the SPU, single-precision infinity is not supported,
 *	   so it is treated as a normal number here.
 *
 */

/*
 * Maclaurin Series Coefficients 
 * for x near 0.
 */
#define SDMPPU_ASINH_MAC01     1.0000000000000000000000000000000000000000000000000000000000000000000000E0
#define SDMPPU_ASINH_MAC03     -1.6666666666666666666666666666666666666666666666666666666666666666666667E-1
#define SDMPPU_ASINH_MAC05     7.5000000000000000000000000000000000000000000000000000000000000000000000E-2
#define SDMPPU_ASINH_MAC07     -4.4642857142857142857142857142857142857142857142857142857142857142857143E-2
#define SDMPPU_ASINH_MAC09     3.0381944444444444444444444444444444444444444444444444444444444444444444E-2
#define SDMPPU_ASINH_MAC11     -2.2372159090909090909090909090909090909090909090909090909090909090909091E-2
#define SDMPPU_ASINH_MAC13     1.7352764423076923076923076923076923076923076923076923076923076923076923E-2
#define SDMPPU_ASINH_MAC15     -1.3964843750000000000000000000000000000000000000000000000000000000000000E-2
#define SDMPPU_ASINH_MAC17     1.1551800896139705882352941176470588235294117647058823529411764705882353E-2
#define SDMPPU_ASINH_MAC19     -9.7616095291940789473684210526315789473684210526315789473684210526315789E-3
#define SDMPPU_ASINH_MAC21     8.3903358096168154761904761904761904761904761904761904761904761904761905E-3
#define SDMPPU_ASINH_MAC23     -7.3125258735988451086956521739130434782608695652173913043478260869565217E-3
#define SDMPPU_ASINH_MAC25     6.4472103118896484375000000000000000000000000000000000000000000000000000E-3
#define SDMPPU_ASINH_MAC27     -5.7400376708419234664351851851851851851851851851851851851851851851851852E-3
#define SDMPPU_ASINH_MAC29     5.1533096823199041958512931034482758620689655172413793103448275862068966E-3
#define SDMPPU_ASINH_MAC31     -4.6601434869150961599042338709677419354838709677419354838709677419354839E-3

#if 0
#define SDMPPU_ASINH_MAC33     4.2409070936793630773370916193181818181818181818181818181818181818181818E-3
#define SDMPPU_ASINH_MAC35     -3.8809645588376692363194056919642857142857142857142857142857142857142857E-3
#define SDMPPU_ASINH_MAC37     3.5692053938259345454138678473395270270270270270270270270270270270270270E-3
#define SDMPPU_ASINH_MAC39     -3.2970595034734847453924325796274038461538461538461538461538461538461538E-3
#define SDMPPU_ASINH_MAC41     3.0578216492580306693548109473251714939024390243902439024390243902439024E-3
#define SDMPPU_ASINH_MAC43     -2.8461784011089421678767647854117460029069767441860465116279069767441860E-3
#endif



static __inline vector float _asinhf4(vector float x)
{
    vec_float4 zerof     = (vec_float4){0.0f, 0.0f, 0.0f, 0.0f};
    vec_float4 sign_mask = (vec_float4){-0.0f, -0.0f, -0.0f, -0.0f};
    vec_float4 ln2       = (vec_float4){6.931471805599453094172321E-1f, 
                                        6.931471805599453094172321E-1f, 
                                        6.931471805599453094172321E-1f, 
                                        6.931471805599453094172321E-1f};
    vec_float4 onef      = (vec_float4){1.0f, 1.0f, 1.0f, 1.0f};
    vec_float4 largef    = (vec_float4){9.21e18f, 9.21e18f, 9.21e18f, 9.21e18f};
    vec_float4 result, fresult, mresult;;
    vec_float4 xabs, xsqu;
    /* Where we switch from maclaurin to formula */
    vec_float4  switch_approx = (vec_float4){0.74f, 0.74f, 0.74f, 0.74f};
    vec_uint4   use_form;
    vec_uint4  islarge;

   
    xabs = vec_andc(x, sign_mask);
    islarge = (vec_uint4)vec_cmpgt(xabs, largef);
    xsqu = vec_madd(x, x, zerof);

    /*
     * Formula:
     *   asinh = ln(|x| + sqrt(x^2 + 1))
     */
    vec_float4 logarg = vec_add(xabs, _sqrtf4(vec_madd(xabs, xabs, onef)));
    logarg = vec_sel(logarg, xabs, islarge);
    fresult = _logf4(logarg);
    fresult = vec_sel(fresult, vec_add(fresult, ln2), islarge);


    vec_float4 coeff31 = (vec_float4){(float)SDMPPU_ASINH_MAC31, (float)SDMPPU_ASINH_MAC31, (float)SDMPPU_ASINH_MAC31, (float)SDMPPU_ASINH_MAC31};
    vec_float4 coeff29 = (vec_float4){(float)SDMPPU_ASINH_MAC29, (float)SDMPPU_ASINH_MAC29, (float)SDMPPU_ASINH_MAC29, (float)SDMPPU_ASINH_MAC29};
    vec_float4 coeff27 = (vec_float4){(float)SDMPPU_ASINH_MAC27, (float)SDMPPU_ASINH_MAC27, (float)SDMPPU_ASINH_MAC27, (float)SDMPPU_ASINH_MAC27};
    vec_float4 coeff25 = (vec_float4){(float)SDMPPU_ASINH_MAC25, (float)SDMPPU_ASINH_MAC25, (float)SDMPPU_ASINH_MAC25, (float)SDMPPU_ASINH_MAC25};
    vec_float4 coeff23 = (vec_float4){(float)SDMPPU_ASINH_MAC23, (float)SDMPPU_ASINH_MAC23, (float)SDMPPU_ASINH_MAC23, (float)SDMPPU_ASINH_MAC23};
    vec_float4 coeff21 = (vec_float4){(float)SDMPPU_ASINH_MAC21, (float)SDMPPU_ASINH_MAC21, (float)SDMPPU_ASINH_MAC21, (float)SDMPPU_ASINH_MAC21};
    vec_float4 coeff19 = (vec_float4){(float)SDMPPU_ASINH_MAC19, (float)SDMPPU_ASINH_MAC19, (float)SDMPPU_ASINH_MAC19, (float)SDMPPU_ASINH_MAC19};
    vec_float4 coeff17 = (vec_float4){(float)SDMPPU_ASINH_MAC17, (float)SDMPPU_ASINH_MAC17, (float)SDMPPU_ASINH_MAC17, (float)SDMPPU_ASINH_MAC17};
    vec_float4 coeff15 = (vec_float4){(float)SDMPPU_ASINH_MAC15, (float)SDMPPU_ASINH_MAC15, (float)SDMPPU_ASINH_MAC15, (float)SDMPPU_ASINH_MAC15};
    vec_float4 coeff13 = (vec_float4){(float)SDMPPU_ASINH_MAC13, (float)SDMPPU_ASINH_MAC13, (float)SDMPPU_ASINH_MAC13, (float)SDMPPU_ASINH_MAC13};
    vec_float4 coeff11 = (vec_float4){(float)SDMPPU_ASINH_MAC11, (float)SDMPPU_ASINH_MAC11, (float)SDMPPU_ASINH_MAC11, (float)SDMPPU_ASINH_MAC11};
    vec_float4 coeff09 = (vec_float4){(float)SDMPPU_ASINH_MAC09, (float)SDMPPU_ASINH_MAC09, (float)SDMPPU_ASINH_MAC09, (float)SDMPPU_ASINH_MAC09};
    vec_float4 coeff07 = (vec_float4){(float)SDMPPU_ASINH_MAC07, (float)SDMPPU_ASINH_MAC07, (float)SDMPPU_ASINH_MAC07, (float)SDMPPU_ASINH_MAC07};
    vec_float4 coeff05 = (vec_float4){(float)SDMPPU_ASINH_MAC05, (float)SDMPPU_ASINH_MAC05, (float)SDMPPU_ASINH_MAC05, (float)SDMPPU_ASINH_MAC05};
    vec_float4 coeff03 = (vec_float4){(float)SDMPPU_ASINH_MAC03, (float)SDMPPU_ASINH_MAC03, (float)SDMPPU_ASINH_MAC03, (float)SDMPPU_ASINH_MAC03};
    vec_float4 coeff01 = (vec_float4){(float)SDMPPU_ASINH_MAC01, (float)SDMPPU_ASINH_MAC01, (float)SDMPPU_ASINH_MAC01, (float)SDMPPU_ASINH_MAC01};

    /*
     * Maclaurin Series
     */
    mresult = vec_madd(xsqu, coeff31, coeff29);
    mresult = vec_madd(xsqu, mresult, coeff27);
    mresult = vec_madd(xsqu, mresult, coeff25);
    mresult = vec_madd(xsqu, mresult, coeff23);
    mresult = vec_madd(xsqu, mresult, coeff21);
    mresult = vec_madd(xsqu, mresult, coeff19);
    mresult = vec_madd(xsqu, mresult, coeff17);
    mresult = vec_madd(xsqu, mresult, coeff15);
    mresult = vec_madd(xsqu, mresult, coeff13);
    mresult = vec_madd(xsqu, mresult, coeff11);
    mresult = vec_madd(xsqu, mresult, coeff09);
    mresult = vec_madd(xsqu, mresult, coeff07);
    mresult = vec_madd(xsqu, mresult, coeff05);
    mresult = vec_madd(xsqu, mresult, coeff03);
    mresult = vec_madd(xsqu, mresult, coeff01);
    mresult = vec_madd(xabs, mresult, zerof);


    /*
     * Choose between series and formula
     */
    use_form = (vec_uint4)vec_cmpgt(xabs, switch_approx);
    result = vec_sel(mresult, fresult, use_form);


    /* Preserve sign - asinh is anti-symmetric */
    result = vec_sel(result, x, (vec_uint4)sign_mask);

    return result;
}

#endif /* _ASINHF4_H_ */
