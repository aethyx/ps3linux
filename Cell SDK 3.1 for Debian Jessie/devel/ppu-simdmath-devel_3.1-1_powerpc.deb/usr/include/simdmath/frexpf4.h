/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef _FREXPF4_H_
#define _FREXPF4_H_	1

#include <altivec.h>
#include <vec_types.h>

/*
 * FUNCTION
 *	vector float _frexpd2(vector float x, vector signed int *pexp)
 *
 * DESCRIPTION
 *      The _frexpf4 function returns the normalized fraction and exponent
 *      to the number x. 
 *
 */
static __inline vector float _frexpf4(vector float x, vector signed int *pexp)
{
  vec_uint4  naninf;
  vec_float4 absx;
  vec_int4   exp;
  vec_float4 mant;
  vec_uint4  mask;
  vec_uint4  lzero    = (vector unsigned int) { 0,  0,  0,  0};
  vec_uint4  exp_shft = (vector unsigned int) {23, 23, 23, 23};
  vec_uint4  exp_mask = (vector unsigned int) {0x7F800000, 0x7F800000, 
                                               0x7F800000, 0x7F800000};
  vec_uint4  sign_mask = (vector unsigned int) {0x80000000, 0x80000000, 
                                                0x80000000, 0x80000000};
  vec_uint4  low_mask = (vector unsigned int) {0xFF, 0xFF, 0xFF, 0xFF};
  vec_int4   exp_bias = (vector signed int)   {-126, -126, -126, -126};
  vec_float4 half     = (vector float) {0.5f, 0.5f, 0.5f, 0.5f};

  /* Normalize the mantissa (fraction part).
   */
  mant = vec_sel(x, half, exp_mask);

  /* Zero the mantissa if the input is a denorm or zero
   */
  exp  = (vec_int4)vec_and(vec_sr((vec_uint4)x, exp_shft), low_mask);
  mask = (vec_uint4)vec_cmpeq(exp, (vec_int4)lzero);
  mant = vec_andc(mant, (vec_float4)mask);

  /* Zero exponent if zero or denorm input. Otherwise, compute
   * exponent by removing the bias.
   */
  exp  = vec_andc(vec_add(exp, exp_bias), (vec_int4)mask);

  /* NaN/Infinite correction. Return a NaN/Infinite in Mantissa, 
   * 0 in exponent.
   */
  absx = vec_abs(x);
  naninf = (vec_uint4)vec_or(
				  vec_cmpgt((vec_uint4)absx, exp_mask), 
				  vec_cmpeq((vec_uint4)absx, exp_mask));
  exp  = vec_sel(exp, (vec_int4)lzero, naninf);
  mant = vec_sel(mant, x, naninf);
  mant = vec_sel(mant, x, sign_mask);
		
  *pexp = exp;		

  return (mant);
}

#endif /* _FREXPF4_H_ */
