/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _SQRTF4_H_
#define _SQRTF4_H_	1

#include <altivec.h>

/*
 * FUNCTION
 *	vector float _sqrtf4(vector float x)
 *
 * DESCRIPTION
 *	The _sqrtf4 computes the square root of the vector input "in" 
 *	and returns the result. 
 *
 *	The VMX implementation computes the square root by noting 
 *      that sqrtf(x) = x / sqrtf(x). However, it does not produce 
 * 	IEEE accuracy.
 *
 */
static __inline vector float _sqrtf4(vector float in) 
{
  vector float y0, out;
  vector float zero = ((vector float) { 0.0f, 0.0f, 0.0f, 0.0f });
  
  /* Perform one iteration of the Newton-Raphsom method in single precision
   * arithmetic.
   */
  y0 = vec_rsqrte(in);
  out = vec_madd(vec_nmsub(in, vec_madd(y0, y0, zero), (vector float)(((vector unsigned int) { 0x40400001, 0x40400001, 0x40400001, 0x40400001 }))), 
		 vec_madd(y0, vec_madd(in, ((vector float) { 0.5f, 0.5f, 0.5f, 0.5f }), zero), zero),
		 zero);
  out = vec_and(out, (vector float)vec_cmpgt(in, (vector float)(((vector unsigned int) { 0x007FFFFF, 0x007FFFFF, 0x007FFFFF, 0x007FFFFF }))));

  return (out);
}

#endif /* _SQRTF4_H_ */

