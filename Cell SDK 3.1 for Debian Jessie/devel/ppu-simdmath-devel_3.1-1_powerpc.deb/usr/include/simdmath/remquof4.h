/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _REMQUOF4_H_
#define _REMQUOF4_H_	1


#include <altivec.h>
#include <vec_types.h>
#include "fmodf4.h"

/*
 * FUNCTION
 *      vector float _remquof2(vector float x, 
 *                             vector float y, 
 *                             vector signed int* quo)
 *
 * DESCRIPTION
 *      The _remquof4 function returns the same vector float result as the 
 *      remainderf4 function.  In addition a vector signed int that contains
 *      the corresponding element values whose sign is the sign of x/y and 
 *      whose magnitude is congruent modulo 2^n to the magnitude of the 
 *      intergral quotient of x/y where n is an implementation-defined integer
 *      greater than, or equal to 3.
 *
 */
static __inline vector float _remquof4(vector float x, vector float y, vector signed int *quo)
{ 
  vec_uint4 sign_mask = (vec_uint4) { 0x80000000, 0x80000000, 0x80000000, 0x80000000 };  
  vec_uint4 exp_mask = (vec_uint4) { 0x7F800000, 0x7F800000, 0x7F800000, 0x7F800000 };
  vec_uint4 snan_mask = (vec_uint4) { 0x7FC00000, 0x7FC00000, 0x7FC00000, 0x7FC00000 };
  vec_uint4 big_threshold = (vec_uint4) { 0x7E000000, 0x7E000000, 0x7E000000, 0x7E000000 };
  vec_uint4 near_denorm_threshold = (vec_uint4) { 0x01000000, 0x01000000, 0x01000000, 0x01000000 };

  vec_uint4 zero = (vec_uint4) { 0, 0, 0, 0 };

  vec_int4 one_s = (vec_int4) { 1, 1, 1, 1 };
  vec_int4 two_s = (vec_int4) { 2, 2, 2, 2 };
  vec_int4 four_s = (vec_int4) { 4, 4, 4, 4 };


  vec_float4 half = (vec_float4) { 0.5f, 0.5f, 0.5f, 0.5f };
  vec_float4 two = (vec_float4) { 2.0f, 2.0f, 2.0f, 2.0f };
  vec_float4 four = (vec_float4) { 4.0f, 4.0f, 4.0f, 4.0f };
  vec_float4 eight_float = (vec_float4) { 8.0f, 8.0f, 8.0f, 8.0f };

  
  // force denorms to zeros (faster than vec_abs, and doesn't mangle zeros)
  x = vec_add(x,(vec_float4)sign_mask);
  y = vec_add(y,(vec_float4)sign_mask);


  vec_int4 hx = (vec_int4)x;
  vec_int4 hy = (vec_int4)y;
  

  vec_int4 sign_x = (vec_int4)vec_and((vec_uint4)hx,sign_mask);
  vec_int4 sign_q = vec_xor(sign_x,vec_and(hy,(vec_int4)sign_mask));


  hx = (vec_int4)vec_andc((vec_uint4)hx,sign_mask);
  hy = (vec_int4)vec_andc((vec_uint4)hy,sign_mask);



  //  return selector for: rem = xy_div_xy, quo = undefined
  vec_uint4 hy_zero = (vec_uint4)vec_cmpeq(hy,(vec_int4)zero);
 
  //  return selector for: rem = xy_div_xy, quo = undefined
  vec_uint4 xinfnan_or_ynan = (vec_uint4)vec_or(vec_cmpgt((vec_uint4)hy,exp_mask),vec_or(vec_cmpeq((vec_uint4)hx,exp_mask),vec_cmpgt((vec_uint4)hx,exp_mask)));


  //  Examine the inputs for special cases
  vec_uint4 x_inf = (vec_uint4)vec_cmpeq((vec_uint4)hx,exp_mask);
  vec_uint4 y_inf = (vec_uint4)vec_cmpeq((vec_uint4)hy,exp_mask);

  vec_uint4 x_nan = (vec_uint4)vec_cmpgt((vec_uint4)hx,exp_mask);
  vec_uint4 y_nan = (vec_uint4)vec_cmpgt((vec_uint4)hy,exp_mask);

  vec_uint4 x_zero = (vec_uint4)vec_cmpeq((vec_uint4)hx,(vec_uint4)zero);
  vec_uint4 y_zero = (vec_uint4)vec_cmpeq((vec_uint4)hy,(vec_uint4)zero);


  vec_float4 q1;

  // If divisor is Inf, force output to correctly signed 0
  q1 = (vec_float4)sign_q;

  // If dividend is Inf, force output to sNaN
  q1 = vec_sel(q1,(vec_float4)snan_mask,x_inf);

  // If both dividend and divisor are Inf, force output to NaN
  q1 = vec_sel(q1,(vec_float4)snan_mask,vec_and(x_inf,y_inf));

  //  If dividend is 0, force output to correctly signed zero
  q1 = vec_sel(q1,(vec_float4)sign_q,x_zero);

  //  If divisor is 0, force output to signal NaN
  q1 = vec_sel(q1,(vec_float4)snan_mask,y_zero);

  // If divisor is NaN, force output to NaN
  q1 = vec_sel(q1,vec_or(y,(vec_float4)snan_mask),y_nan);

  // If dividend is NaN, force output to NaN
  q1 = vec_sel(q1,vec_or(x,(vec_float4)snan_mask),x_nan);

  
  //  return selector for:  rem = rem_close, quo = quo_close
  vec_uint4 inputs_close = (vec_uint4)vec_cmpeq((vec_uint4)vec_sub(hx,hy),zero);

  //  Reduce if possible
  vec_uint4 y_not_big = (vec_uint4)vec_cmplt((vec_uint4)hy,big_threshold);
  x = vec_sel(x,_fmodf4(x,vec_madd(y,eight_float,(vec_float4)zero)),y_not_big);
 
  //  This is what is returned if inputs are close
  vec_float4 rem_close = vec_madd(x,(vec_float4)zero,(vec_float4)zero);

  //  Convert x and y to absolute values  
  x = (vec_float4)vec_andc((vec_uint4)x,sign_mask);
  y = (vec_float4)vec_andc((vec_uint4)y,sign_mask);

  vec_int4 cquo;
  vec_uint4 sel;

  //  if x >= 4y
  sel = (vec_uint4)vec_cmpge(x,vec_madd(y,four,(vec_float4)zero));
  //  then x = x - 4y
  x = vec_sel(x,vec_nmsub(four,y,x),sel);
  //  and cquo = 4
  cquo = vec_sel((vec_int4)zero,four_s,sel);

  //  if x >= 2y 
  sel = (vec_uint4)vec_cmpge(x,vec_madd(y,two,(vec_float4)zero));
  //  x = x - 2y
  x = vec_sel(x,vec_nmsub(two,y,x),sel);
  //  and cquo += 2
  cquo = vec_sel(cquo,vec_add(cquo,two_s),sel);


  //
  //  Determines if we take the denormal branch
  //
  sel = (vec_uint4)vec_cmplt((vec_uint4)hy,near_denorm_threshold);
  vec_uint4 sub_sel;


  // First reduction in denorm branch
  sub_sel = vec_and((vec_uint4)vec_cmpgt(vec_add(x,x),y),sel);
  x = vec_sel(x,vec_sub(x,y),sub_sel);
  cquo = vec_sel(cquo,vec_add(cquo,one_s),sub_sel);
  
  // Second reduction in denorm branch (only fires if first fires)
  sub_sel = vec_and((vec_uint4)vec_cmpge(vec_add(x,x),y),sub_sel);
  x = vec_sel(x,vec_sub(x,y),sub_sel);
  cquo = vec_sel(cquo,vec_add(cquo,one_s),sub_sel);


  // First reduction in normal branch
  vec_float4 y_half = vec_madd(y,half,(vec_float4)zero);
  sub_sel = vec_andc((vec_uint4)vec_cmpgt(x,y_half),sel);
  x = vec_sel(x,vec_sub(x,y),sub_sel);
  cquo = vec_sel(cquo,vec_add(cquo,one_s),sub_sel); 

  //  Second reduction in normal branch (only fires if first fires)
  sub_sel = vec_and((vec_uint4)vec_cmpge(x,y_half),sub_sel);
  x = vec_sel(x,vec_sub(x,y),sub_sel);
  cquo = vec_sel(cquo,vec_add(cquo,one_s),sub_sel); 

  //  Correct cquo for sign
  cquo = vec_sel(cquo,vec_sub((vec_int4)zero,cquo),vec_cmpgt((vec_uint4)sign_q,zero));


  x = vec_xor(x,(vec_float4)sign_x);
  x = vec_sel(x,(vec_float4)sign_x,vec_cmpeq(x,(vec_float4)zero));


  x = vec_sel(x,rem_close,inputs_close);
 
  //  Return the low bits of quotient, unless we had a special case
  *quo = vec_sel(cquo,(vec_int4)zero,vec_or(inputs_close,vec_or(hy_zero,xinfnan_or_ynan)));

  x = vec_sel(x,q1,vec_or(xinfnan_or_ynan,hy_zero));



  return x;
}

#endif /* _REMQUOF4_H_ */
