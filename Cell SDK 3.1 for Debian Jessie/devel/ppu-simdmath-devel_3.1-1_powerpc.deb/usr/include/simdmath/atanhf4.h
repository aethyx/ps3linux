/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _ATANHF4_H_
#define _ATANHF4_H_	1

#include <altivec.h>
#include <vec_types.h>
#include "logf4.h"

/*
 * FUNCTION
 *  vector float _atanhf4(vector float x)
 *
 * DESCRIPTION
 *  The atanhf4 function returns a vector containing the hyperbolic
 *  arctangents of the corresponding elements of the input vector.
 *
 *  We are using the formula:
 *    atanh x = 1/2 * ln((1 + x)/(1 - x)) = 1/2 * [ln(1+x) - ln(1-x)]
 *  and the anti-symmetry of atanh.
 *
 *  For x near 0, we use the Taylor series:
 *    atanh x = x + x^3/3 + x^5/5 + x^7/7 + x^9/9 + ...
 *
 *  Special Cases:
 *  - atanh(1)  =  HUGE_VALF
 *  - atanh(-1) = -HUGE_VALF
 *	- The result is undefined for x outside of the domain [-1,1],
 *	  since single-precision NaN is not supported on the SPU.
 *
 */

/*
 * Maclaurin Series Coefficients 
 * for x near 0.
 */
#define ATANH_MAC01 1.0000000000000000000000000000000000000000000000000000000000000000000000E0
#define ATANH_MAC03 3.3333333333333333333333333333333333333333333333333333333333333333333333E-1
#define ATANH_MAC05 2.0000000000000000000000000000000000000000000000000000000000000000000000E-1
#define ATANH_MAC07 1.4285714285714285714285714285714285714285714285714285714285714285714286E-1


static __inline vector float _atanhf4(vector float x)
{
    vec_float4 sign_mask = (vector float){-0.0f, -0.0f, -0.0f, -0.0f};
    vec_float4 zerof     = (vector float){0.0f, 0.0f, 0.0f, 0.0f};
    vec_float4 onef      = (vector float){1.0f, 1.0f, 1.0f, 1.0f};
    vec_float4 onehalff  = (vector float){0.5f, 0.5f, 0.5f, 0.5f};
    vec_float4 result, fresult, mresult;;
    vec_float4 xabs, xsqu;
    /* Where we switch from maclaurin to formula */
    vec_float4  switch_approx = (vector float){0.165f, 0.165f, 0.165f, 0.165f};
    vector bool int use_form;

    xabs = vec_andc(x, sign_mask);
    xsqu = vec_madd(x, x, zerof);

    /*
     * Formula:
     *   atanh = 1/2 * ln((1 + x)/(1 - x)) = 1/2 * [ln(1+x) - ln(1-x)]
     */
    fresult = vec_sub(_logf4(vec_add(onef, xabs)), _logf4(vec_sub(onef, xabs)));
    fresult = vec_madd(fresult, onehalff, zerof);


    /*
     * Taylor Series
     */
    mresult = vec_madd(xsqu,  ((vector float){ATANH_MAC07, ATANH_MAC07, ATANH_MAC07, ATANH_MAC07}), 
                              ((vector float){ATANH_MAC05, ATANH_MAC05, ATANH_MAC05, ATANH_MAC05}));
    mresult = vec_madd(xsqu, mresult, ((vector float){ATANH_MAC03, ATANH_MAC03, ATANH_MAC03, ATANH_MAC03}));
    mresult = vec_madd(xsqu, mresult, ((vector float){ATANH_MAC01, ATANH_MAC01, ATANH_MAC01, ATANH_MAC01}));
    mresult = vec_madd(xabs, mresult, zerof);


    /*
     * Choose between series and formula
     */
    use_form = vec_cmpgt(xabs, switch_approx);
    result = vec_sel(mresult, fresult, use_form);


    /* Preserve sign - atanh is anti-symmetric */
    result = vec_sel(result, x, (vec_uint4)sign_mask);

    return result;
}

#endif /* _ATANHF4_H_ */
