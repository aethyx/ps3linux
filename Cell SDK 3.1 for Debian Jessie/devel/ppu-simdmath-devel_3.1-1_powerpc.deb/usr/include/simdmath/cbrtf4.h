/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _CBRTF4_H_
#define _CBRTF4_H_		1

#include <altivec.h>
#include <vec_types.h>

/*
 * FUNCTION
 *	vector float _cbrtf4(vector float x)
 *
 * DESCRIPTION
 *	The _cbrtf4 function computes the real cube roots of the elements of 
 *      the vector float x.
 *
 */
static __inline vector float _cbrtf4(vector float in)
{

  typedef union {
    unsigned int        iArray[4];
    vector unsigned int iVector;
  } vecArray;
  
  vecArray v;

  float cbrt_factors[5] = {
    0.629960524947436484311,  /* 2^(-2/3) */
    0.793700525984099680699,  /* 2^(-1/3) */
    1.0,                      /* 2^(0)    */
    1.259921049894873164666,  /* 2^(1/3)  */
    1.587401051968199583441	  /* 2^(2/3)  */
  };

  vec_int4 exp, bias;
  vec_uint4 mask, e_div_3, e_mod_3;
  vec_float4 out, mant, ym;
  vec_float4 a, b, inv_b;
  vec_float4 u, u_3;
  vec_float4 factor;
  vec_uint4 mant_mask = (vector unsigned int) {0x7FFFFF, 0x7FFFFF,
                                               0x7FFFFF, 0x7FFFFF};
  vec_float4 zerof     = (vector float){0.0f, 0.0f, 0.0f, 0.0f};
  vec_float4 half      = (vector float){0.5f, 0.5f, 0.5f, 0.5f};
  vec_float4 onef      = (vector float){1.0f, 1.0f, 1.0f, 1.0f};
  vec_float4 twof      = (vector float){2.0f, 2.0f, 2.0f, 2.0f};
  vec_int4   exp_bias  = (vector int){-126, -126, -126, -126};
  vec_uint4  exp_shift = (vector unsigned int){23, 23, 23, 23};
  vec_int4   exp_mask  = (vector int){0xFF, 0xFF, 0xFF, 0xFF};
  vec_uint4  two       = (vector unsigned int){2, 2, 2, 2};
  vec_int4   zero      = (vector int){0, 0, 0, 0};
  vec_uint4  fifteen   = (vector unsigned int) {15, 15, 15, 15};
  vec_uint4  sixteen   = (vector unsigned int) {16, 16, 16, 16};
  vec_int4   l127      = (vector int) {127, 127, 127, 127};
  vec_short8 l5556     = (vector short) {(short)0x5556, (short)0x5556, 
					 (short)0x5556, (short)0x5556,
                                         (short)0x5556, (short)0x5556,
                                         (short)0x5556, (short)0x5556};
  vec_short8 three   = (vector short) {(short)3, (short)3, (short)3, (short)3,
                                       (short)3, (short)3, (short)3, (short)3};

  /* Polynomial coefficients */
  vec_float4 c2 = (vector float){0.191502161678719066,
                                 0.191502161678719066,
                                 0.191502161678719066,
                                 0.191502161678719066};

  vec_float4 c1 = (vector float){0.697570460207922770,
                                 0.697570460207922770,
                                 0.697570460207922770,
				 0.697570460207922770};


  vec_float4 c0 = (vector float){0.492659620528969547,
                                 0.492659620528969547,
                                 0.492659620528969547,
                                 0.492659620528969547};


  /* Normalize the mantissa (fraction part) into the range [0.5, 1.0) and 
   * extract the exponent. 
   */
  mant = vec_sel(half, in, mant_mask);

  exp = vec_sr((vec_int4)in, exp_shift);
  exp = vec_and(exp, exp_mask);

  /* Generate mask used to zero result if the exponent is zero (ie, in is either
   * zero or a denorm
   */
  mask = (vec_uint4)vec_cmpeq(exp, zero);
  exp  = vec_add(exp, exp_bias);

  u = vec_madd(mant, vec_nmsub(mant, c2, c1), c0);
  u_3 = vec_madd(vec_madd(u, u, zerof), u, zerof);

  /* Compute: e_div_3 = exp/3
   *
   * Fetch:   factor = factor[2+exp%3]
   * 
   * The factors array contains 5 values: 2^(-2/3), 2^(-1/3), 2^0, 2^(1/3), 2^(2/3), 2^1.
   */

  bias = vec_sr(vec_sra(exp, fifteen), sixteen);
  e_div_3 = (vec_uint4)vec_mulo((vec_short8)exp, (vec_short8)l5556);
  e_div_3 = vec_add(e_div_3, (vec_uint4)bias);
  e_div_3 = vec_sra(e_div_3, sixteen);
  e_mod_3 = (vec_uint4)vec_sub((vec_int4)exp, vec_mulo((vec_short8)e_div_3, three));
  e_mod_3 = vec_add(e_mod_3, two);

  v.iVector = e_mod_3;
  factor = (vector float) {cbrt_factors[v.iArray[0]], 
                           cbrt_factors[v.iArray[1]], 
                           cbrt_factors[v.iArray[2]], 
                           cbrt_factors[v.iArray[3]]};

  /* Compute the estimated mantissa cube root (ym) equals:
   *       ym = (u * factor * (2.0 * mant + u3)) / (2.0 * u3 + mant);
   */
  a = vec_madd(vec_madd(factor, u, zerof), vec_madd(twof, mant, u_3), zerof);
  b = vec_madd(twof, u_3, mant);
  inv_b = vec_re(b);
  inv_b = vec_madd(vec_nmsub(b, inv_b, onef), inv_b, inv_b);
  ym    = vec_madd(a, inv_b, zerof);
  ym    = vec_madd(vec_nmsub(b, ym, a), inv_b, ym);

  exp   = vec_add((vec_int4)e_div_3, l127);
  exp = vec_sl(exp, (vec_uint4)exp_shift);

  out = vec_sel((vec_float4)exp, in,((vec_uint4) { 0x80000000, 0x80000000, 0x80000000, 0x80000000 } ));
  out = vec_madd(out, ym, zerof);
  out = vec_andc(out, (vec_float4)mask);

  return (out);
}

#endif /* _CBRTF4_H_ */
