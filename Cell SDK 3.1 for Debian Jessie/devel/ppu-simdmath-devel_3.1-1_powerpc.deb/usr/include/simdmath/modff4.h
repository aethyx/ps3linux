/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _MODFF4_H_
#define _MODFF4_H_	1

#include <altivec.h>
#include <vec_types.h>

#include "truncf4.h"

/*
 * FUNCTION
 *  vector float _modff4(vector float x, vector float *pint)
 *
 * DESCRIPTION
 *      The _modff4 function determines an integer i plus a fraction frac that 
 *      represent the value of each element of x. It returns a vector of the 
 *      values frac and stores a vector of the integers i in *pint for each 
 *      corresponding element of x, such that:
 *
 *        -  x == frac + i
 *        -  |frac| is in the interval [0,1)
 *        -  both frac and i have the same sign as the element of x.
 * 
 * RETURNS
 *      The function modff4 returns a float vector such that:
 *
 *        -  the signed fractional portion of the corresponding element of x is
 *           returned
 *        -  the integral portion of each corresponding element of x is stored 
 *           in the vector pointed to by pint.
 *
 */

static __inline vector float _modff4(vector float x, vector float *pint)
{
  vec_float4 int_part;
  vec_float4 frac_part;
	
  int_part = _truncf4(x);
  frac_part = vec_sub(x,int_part);
	
  *pint = int_part;
  return frac_part;
}

#endif /* _MODFF4_H_ */
