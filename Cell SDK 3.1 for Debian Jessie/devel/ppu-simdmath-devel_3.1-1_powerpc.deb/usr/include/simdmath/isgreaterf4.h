/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _ISGREATERF4_H_
#define _ISGREATERF4_H_	1

#include <altivec.h>

/*
 * FUNCTION
 *      vector unsigned int _isgreaterf4(vector float x, vector float y)
 *
 * DESCRIPTION
 *      The _isgreaterf4 function returns a vector in which each element 
 *      indicates if the corresponding element of x is greater than the 
 *      corresponding element of y. Denormals (subnormals) are also correctly
 *      compared.
 * 
 * RETURNS
 *      UINT_MAX  (0xFFFFFFFF) if the element of x is greater than the element 
 *                             of y.
 *      0         (0x00000000) otherwise
 *
 */
static __inline vector unsigned int _isgreaterf4(vector float x, vector float y)
{
  vector unsigned int first_denorm = (vector unsigned int) { 0x7F800001, 0x7F800001, 0x7F800001, 0x7F800001 };
  vector unsigned int sign_shift   = (vector unsigned int) { 31, 31, 31, 31 };
  vector unsigned int zero         = (vector unsigned int) { 0, 0, 0, 0 };

  vector unsigned int xabs         = (vector unsigned int) vec_abs(x);
  vector unsigned int yabs         = (vector unsigned int) vec_abs(y);
  vector unsigned int xsign        = vec_sra((vector unsigned int) x, sign_shift);
  vector unsigned int ysign        = vec_sra((vector unsigned int) y, sign_shift);

  vector unsigned int xn_yn        = vec_and(xsign,ysign); 
  vector unsigned int xp_yn        = vec_andc(ysign,xsign);
  vector unsigned int xp_yp        = vec_nor(xsign,ysign);
  vector unsigned int xy_0         = (vector unsigned int)vec_cmpeq(vec_or(xabs,yabs),zero); // true if x and y are both zeros

  vector unsigned int abs_xgty     = (vector unsigned int)vec_cmpgt((vector unsigned int) xabs, (vector unsigned int) yabs);
  vector unsigned int abs_xlty     = (vector unsigned int)vec_cmplt((vector unsigned int) xabs, (vector unsigned int) yabs);

  vector unsigned int x_not_a_nan  = (vector unsigned int)vec_cmplt(xabs,first_denorm); /* true if not a NaN */
  vector unsigned int y_not_a_nan  = (vector unsigned int)vec_cmplt(yabs,first_denorm); /* true if not a NaN */

  return 
    vec_and(vec_and(x_not_a_nan,y_not_a_nan),          /* If x and y are not NaNs AND */
	    vec_or(vec_andc(xp_yn,xy_0),               /* ((x is positive, and y is negative AND they both aren't zero) OR */
		   vec_or(vec_and(xp_yp,abs_xgty),     /*  both are positive and ||x|| > ||y|| OR */
			  vec_and(xn_yn,abs_xlty))));  /*  both are negative and ||x|| < ||y|| )*/
 
}

#endif /* _ISGREATERF4_H_ */

