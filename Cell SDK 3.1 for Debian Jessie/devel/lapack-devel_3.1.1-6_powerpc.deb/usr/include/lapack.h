/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef __LAPACK_H
#define __LAPACK_H

#include <lapack_errno.h>

#ifdef real
#undef real
#endif
#ifdef doublereal
#undef doublereal
#endif
#ifdef complex
#undef complex
#endif
#ifdef doublecomplex
#undef doublecomplex
#endif
#ifdef logical
#undef logical
#endif
#ifdef L_fp
#undef L_fp
#endif

typedef float real;
typedef double doublereal;
typedef struct { real r, i; } complex;
typedef struct { doublereal r, i; } doublecomplex;
typedef int logical;

#ifdef __cplusplus
typedef logical (*L_fp)(...);
#else
typedef logical (*L_fp)();
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* Optimized by using Cell BE acceleration */
int dbdsqr_(char *uplo, int *n, int *ncvt, int *nru, int *ncc, double *d, 
        double *e, double *vt, int *ldvt, double *u, int *ldu, double *c,
        int *ldc, double *work, int *info);

int dgeqrf_(int *m, int *n, double *a, int *lda, double *tau, 
        double *work, int *lwork, int *info);

int dgetrf_(int *m, int *n, double *a, int *lda, int *ipiv, int *info);

int dgetri_(int *n, double *a, int *lda, int *ipiv, double *work, 
        int *lwork, int *info);

int dpotrf_(char *uplo, int *n, double *a, int *lda, int *info);

int dsteqr_(char *compz, int *n, double *d__, double *e, double *z__, 
        int *ldz, double *work, int *info);

int dgetrs_(char *trans, int *n, int *nrhs, double *a, int *lda, 
        int *ipiv, double *b, int *ldb, int *info);

int dpotrs_(char *uplo, int *n, int *nrhs, double *a, int *lda, 
        double *b, int *ldb, int *info);

int dbdsdc_(char *uplo, char *compq, int *n, double *d, 
        double *e, double *u, int *ldu, double *vt, int *ldvt, 
        double *q, int *iq, double *work, int *iwork, int *info);

int dgelqf_(int *m, int *n, double *a, int *lda, 
        double *tau, double *work, int *lwork, int *info);

int dgebrd_(int *m, int *n, double *a, int *lda, double *d, 
        double *e, double *tauq, double *taup, double *work, 
        int *lwork, int *info);

int dgesdd_(char *jobz, int *m, int *n, double *a, int *lda, 
        double *s, double *u, int *ldu, double *vt, int *ldvt, 
        double *work, int *lwork, int *iwork, int *info);

int dorgbr_(char *vect, int *m, int *n, int *k, double *a, 
        int *lda, double *tau, double *work, int *lwork, int *info);

int dormbr_(char *vect, char *side, char *trans, int *m, int *n, 
        int *k, double *a, int *lda, double *tau, double *c__, 
        int *ldc, double *work, int *lwork, int *info);


/* Unoptimized functions. Just using clapack 3.1.1 */
/* Subroutine */ int cbdsqr_(char *uplo, int *n, int *ncvt, int *
	nru, int *ncc, real *d__, real *e, complex *vt, int *ldvt, 
	complex *u, int *ldu, complex *c__, int *ldc, real *rwork, 
	int *info);

/* Subroutine */ int cgbbrd_(char *vect, int *m, int *n, int *ncc,
	 int *kl, int *ku, complex *ab, int *ldab, real *d__, 
	real *e, complex *q, int *ldq, complex *pt, int *ldpt, 
	complex *c__, int *ldc, complex *work, real *rwork, int *info);

/* Subroutine */ int cgbcon_(char *norm, int *n, int *kl, int *ku,
	 complex *ab, int *ldab, int *ipiv, real *anorm, real *rcond, 
	complex *work, real *rwork, int *info);

/* Subroutine */ int cgbequ_(int *m, int *n, int *kl, int *ku,
	 complex *ab, int *ldab, real *r__, real *c__, real *rowcnd, real 
	*colcnd, real *amax, int *info);

/* Subroutine */ int cgbrfs_(char *trans, int *n, int *kl, int *
	ku, int *nrhs, complex *ab, int *ldab, complex *afb, int *
	ldafb, int *ipiv, complex *b, int *ldb, complex *x, int *
	ldx, real *ferr, real *berr, complex *work, real *rwork, int *
	info);

/* Subroutine */ int cgbsv_(int *n, int *kl, int *ku, int *
	nrhs, complex *ab, int *ldab, int *ipiv, complex *b, int *
	ldb, int *info);

/* Subroutine */ int cgbsvx_(char *fact, char *trans, int *n, int *kl,
	 int *ku, int *nrhs, complex *ab, int *ldab, complex *afb,
	 int *ldafb, int *ipiv, char *equed, real *r__, real *c__, 
	complex *b, int *ldb, complex *x, int *ldx, real *rcond, real 
	*ferr, real *berr, complex *work, real *rwork, int *info);

/* Subroutine */ int cgbtf2_(int *m, int *n, int *kl, int *ku,
	 complex *ab, int *ldab, int *ipiv, int *info);

/* Subroutine */ int cgbtrf_(int *m, int *n, int *kl, int *ku,
	 complex *ab, int *ldab, int *ipiv, int *info);

/* Subroutine */ int cgbtrs_(char *trans, int *n, int *kl, int *
	ku, int *nrhs, complex *ab, int *ldab, int *ipiv, complex 
	*b, int *ldb, int *info);

/* Subroutine */ int cgebak_(char *job, char *side, int *n, int *ilo, 
	int *ihi, real *scale, int *m, complex *v, int *ldv, 
	int *info);

/* Subroutine */ int cgebal_(char *job, int *n, complex *a, int *lda, 
	int *ilo, int *ihi, real *scale, int *info);

/* Subroutine */ int cgebd2_(int *m, int *n, complex *a, int *lda,
	 real *d__, real *e, complex *tauq, complex *taup, complex *work, 
	int *info);

/* Subroutine */ int cgebrd_(int *m, int *n, complex *a, int *lda,
	 real *d__, real *e, complex *tauq, complex *taup, complex *work, 
	int *lwork, int *info);

/* Subroutine */ int cgecon_(char *norm, int *n, complex *a, int *lda,
	 real *anorm, real *rcond, complex *work, real *rwork, int *info);

/* Subroutine */ int cgeequ_(int *m, int *n, complex *a, int *lda,
	 real *r__, real *c__, real *rowcnd, real *colcnd, real *amax, 
	int *info);

/* Subroutine */ int cgees_(char *jobvs, char *sort, L_fp select, int *n, 
	complex *a, int *lda, int *sdim, complex *w, complex *vs, 
	int *ldvs, complex *work, int *lwork, real *rwork, logical *
	bwork, int *info);

/* Subroutine */ int cgeesx_(char *jobvs, char *sort, L_fp select, char *
	sense, int *n, complex *a, int *lda, int *sdim, complex *
	w, complex *vs, int *ldvs, real *rconde, real *rcondv, complex *
	work, int *lwork, real *rwork, logical *bwork, int *info);

/* Subroutine */ int cgeev_(char *jobvl, char *jobvr, int *n, complex *a, 
	int *lda, complex *w, complex *vl, int *ldvl, complex *vr, 
	int *ldvr, complex *work, int *lwork, real *rwork, int *
	info);

/* Subroutine */ int cgeevx_(char *balanc, char *jobvl, char *jobvr, char *
	sense, int *n, complex *a, int *lda, complex *w, complex *vl, 
	int *ldvl, complex *vr, int *ldvr, int *ilo, int *ihi,
	 real *scale, real *abnrm, real *rconde, real *rcondv, complex *work,
   	int *lwork, real *rwork, int *info);

/* Subroutine */ int cgegs_(char *jobvsl, char *jobvsr, int *n, complex *
	a, int *lda, complex *b, int *ldb, complex *alpha, complex *
	beta, complex *vsl, int *ldvsl, complex *vsr, int *ldvsr,
  	complex *work, int *lwork, real *rwork, int *info);

/* Subroutine */ int cgegv_(char *jobvl, char *jobvr, int *n, complex *a, 
	int *lda, complex *b, int *ldb, complex *alpha, complex *beta,
	 complex *vl, int *ldvl, complex *vr, int *ldvr, complex *
	work, int *lwork, real *rwork, int *info);

/* Subroutine */ int cgehd2_(int *n, int *ilo, int *ihi, complex *
	a, int *lda, complex *tau, complex *work, int *info);

/* Subroutine */ int cgehrd_(int *n, int *ilo, int *ihi, complex *
	a, int *lda, complex *tau, complex *work, int *lwork, int 
	*info);

/* Subroutine */ int cgelq2_(int *m, int *n, complex *a, int *lda,
	 complex *tau, complex *work, int *info);

/* Subroutine */ int cgelqf_(int *m, int *n, complex *a, int *lda,
	 complex *tau, complex *work, int *lwork, int *info);

/* Subroutine */ int cgels_(char *trans, int *m, int *n, int *
	nrhs, complex *a, int *lda, complex *b, int *ldb, complex *
	work, int *lwork, int *info);

/* Subroutine */ int cgelsd_(int *m, int *n, int *nrhs, complex *
	a, int *lda, complex *b, int *ldb, real *s, real *rcond, 
	int *rank, complex *work, int *lwork, real *rwork, int *
	iwork, int *info);

/* Subroutine */ int cgelss_(int *m, int *n, int *nrhs, complex *
	a, int *lda, complex *b, int *ldb, real *s, real *rcond, 
	int *rank, complex *work, int *lwork, real *rwork, int *
	info);

/* Subroutine */ int cgelsx_(int *m, int *n, int *nrhs, complex *
	a, int *lda, complex *b, int *ldb, int *jpvt, real *rcond,
	 int *rank, complex *work, real *rwork, int *info);

/* Subroutine */ int cgelsy_(int *m, int *n, int *nrhs, complex *
	a, int *lda, complex *b, int *ldb, int *jpvt, real *rcond,
	 int *rank, complex *work, int *lwork, real *rwork, int *
	info);

/* Subroutine */ int cgeql2_(int *m, int *n, complex *a, int *lda,
	 complex *tau, complex *work, int *info);

/* Subroutine */ int cgeqlf_(int *m, int *n, complex *a, int *lda,
	 complex *tau, complex *work, int *lwork, int *info);

/* Subroutine */ int cgeqp3_(int *m, int *n, complex *a, int *lda,
	 int *jpvt, complex *tau, complex *work, int *lwork, real *
	rwork, int *info);

/* Subroutine */ int cgeqpf_(int *m, int *n, complex *a, int *lda,
	 int *jpvt, complex *tau, complex *work, real *rwork, int *
	info);

/* Subroutine */ int cgeqr2_(int *m, int *n, complex *a, int *lda,
	 complex *tau, complex *work, int *info);

/* Subroutine */ int cgeqrf_(int *m, int *n, complex *a, int *lda,
	 complex *tau, complex *work, int *lwork, int *info);

/* Subroutine */ int cgerfs_(char *trans, int *n, int *nrhs, complex *
	a, int *lda, complex *af, int *ldaf, int *ipiv, complex *
	b, int *ldb, complex *x, int *ldx, real *ferr, real *berr, 
	complex *work, real *rwork, int *info);

/* Subroutine */ int cgerq2_(int *m, int *n, complex *a, int *lda,
	 complex *tau, complex *work, int *info);

/* Subroutine */ int cgerqf_(int *m, int *n, complex *a, int *lda,
	 complex *tau, complex *work, int *lwork, int *info);

/* Subroutine */ int cgesc2_(int *n, complex *a, int *lda, complex *
	rhs, int *ipiv, int *jpiv, real *scale);

/* Subroutine */ int cgesdd_(char *jobz, int *m, int *n, complex *a, 
	int *lda, real *s, complex *u, int *ldu, complex *vt, int 
	*ldvt, complex *work, int *lwork, real *rwork, int *iwork, 
	int *info);

/* Subroutine */ int cgesv_(int *n, int *nrhs, complex *a, int *
	lda, int *ipiv, complex *b, int *ldb, int *info);

/* Subroutine */ int cgesvd_(char *jobu, char *jobvt, int *m, int *n, 
	complex *a, int *lda, real *s, complex *u, int *ldu, complex *
	vt, int *ldvt, complex *work, int *lwork, real *rwork, 
	int *info);

/* Subroutine */ int cgesvx_(char *fact, char *trans, int *n, int *
	nrhs, complex *a, int *lda, complex *af, int *ldaf, int *
	ipiv, char *equed, real *r__, real *c__, complex *b, int *ldb, 
	complex *x, int *ldx, real *rcond, real *ferr, real *berr, 
	complex *work, real *rwork, int *info);

/* Subroutine */ int cgetc2_(int *n, complex *a, int *lda, int *
	ipiv, int *jpiv, int *info);

/* Subroutine */ int cgetf2_(int *m, int *n, complex *a, int *lda,
	 int *ipiv, int *info);

/* Subroutine */ int cgetrf_(int *m, int *n, complex *a, int *lda,
	 int *ipiv, int *info);

/* Subroutine */ int cgetri_(int *n, complex *a, int *lda, int *
	ipiv, complex *work, int *lwork, int *info);

/* Subroutine */ int cgetrs_(char *trans, int *n, int *nrhs, complex *
	a, int *lda, int *ipiv, complex *b, int *ldb, int *
	info);

/* Subroutine */ int cggbak_(char *job, char *side, int *n, int *ilo, 
	int *ihi, real *lscale, real *rscale, int *m, complex *v, 
	int *ldv, int *info);

/* Subroutine */ int cggbal_(char *job, int *n, complex *a, int *lda, 
	complex *b, int *ldb, int *ilo, int *ihi, real *lscale, 
	real *rscale, real *work, int *info);

/* Subroutine */ int cgges_(char *jobvsl, char *jobvsr, char *sort, L_fp 
	selctg, int *n, complex *a, int *lda, complex *b, int *
	ldb, int *sdim, complex *alpha, complex *beta, complex *vsl, 
	int *ldvsl, complex *vsr, int *ldvsr, complex *work, int *
	lwork, real *rwork, logical *bwork, int *info);

/* Subroutine */ int cggesx_(char *jobvsl, char *jobvsr, char *sort, L_fp 
	selctg, char *sense, int *n, complex *a, int *lda, complex *b,
	 int *ldb, int *sdim, complex *alpha, complex *beta, complex *
	vsl, int *ldvsl, complex *vsr, int *ldvsr, real *rconde, real 
	*rcondv, complex *work, int *lwork, real *rwork, int *iwork, 
	int *liwork, logical *bwork, int *info);

/* Subroutine */ int cggev_(char *jobvl, char *jobvr, int *n, complex *a, 
	int *lda, complex *b, int *ldb, complex *alpha, complex *beta,
	 complex *vl, int *ldvl, complex *vr, int *ldvr, complex *
	work, int *lwork, real *rwork, int *info);

/* Subroutine */ int cggevx_(char *balanc, char *jobvl, char *jobvr, char *
	sense, int *n, complex *a, int *lda, complex *b, int *ldb,
	 complex *alpha, complex *beta, complex *vl, int *ldvl, complex *
	vr, int *ldvr, int *ilo, int *ihi, real *lscale, real *
	rscale, real *abnrm, real *bbnrm, real *rconde, real *rcondv, complex 
	*work, int *lwork, real *rwork, int *iwork, logical *bwork, 
	int *info);

/* Subroutine */ int cggglm_(int *n, int *m, int *p, complex *a, 
	int *lda, complex *b, int *ldb, complex *d__, complex *x, 
	complex *y, complex *work, int *lwork, int *info);

/* Subroutine */ int cgghrd_(char *compq, char *compz, int *n, int *
	ilo, int *ihi, complex *a, int *lda, complex *b, int *ldb,
	 complex *q, int *ldq, complex *z__, int *ldz, int *info);

/* Subroutine */ int cgglse_(int *m, int *n, int *p, complex *a, 
	int *lda, complex *b, int *ldb, complex *c__, complex *d__, 
	complex *x, complex *work, int *lwork, int *info);

/* Subroutine */ int cggqrf_(int *n, int *m, int *p, complex *a, 
	int *lda, complex *taua, complex *b, int *ldb, complex *taub, 
	complex *work, int *lwork, int *info);

/* Subroutine */ int cggrqf_(int *m, int *p, int *n, complex *a, 
	int *lda, complex *taua, complex *b, int *ldb, complex *taub, 
	complex *work, int *lwork, int *info);

/* Subroutine */ int cggsvd_(char *jobu, char *jobv, char *jobq, int *m, 
	int *n, int *p, int *k, int *l, complex *a, int *
	lda, complex *b, int *ldb, real *alpha, real *beta, complex *u, 
	int *ldu, complex *v, int *ldv, complex *q, int *ldq, 
	complex *work, real *rwork, int *iwork, int *info);

/* Subroutine */ int cggsvp_(char *jobu, char *jobv, char *jobq, int *m, 
	int *p, int *n, complex *a, int *lda, complex *b, int 
	*ldb, real *tola, real *tolb, int *k, int *l, complex *u, 
	int *ldu, complex *v, int *ldv, complex *q, int *ldq, 
	int *iwork, real *rwork, complex *tau, complex *work, int *
	info);

/* Subroutine */ int cgtcon_(char *norm, int *n, complex *dl, complex *
	d__, complex *du, complex *du2, int *ipiv, real *anorm, real *
	rcond, complex *work, int *info);

/* Subroutine */ int cgtrfs_(char *trans, int *n, int *nrhs, complex *
	dl, complex *d__, complex *du, complex *dlf, complex *df, complex *
	duf, complex *du2, int *ipiv, complex *b, int *ldb, complex *
	x, int *ldx, real *ferr, real *berr, complex *work, real *rwork, 
	int *info);

/* Subroutine */ int cgtsv_(int *n, int *nrhs, complex *dl, complex *
	d__, complex *du, complex *b, int *ldb, int *info);

/* Subroutine */ int cgtsvx_(char *fact, char *trans, int *n, int *
	nrhs, complex *dl, complex *d__, complex *du, complex *dlf, complex *
	df, complex *duf, complex *du2, int *ipiv, complex *b, int *
	ldb, complex *x, int *ldx, real *rcond, real *ferr, real *berr, 
	complex *work, real *rwork, int *info);

/* Subroutine */ int cgttrf_(int *n, complex *dl, complex *d__, complex *
	du, complex *du2, int *ipiv, int *info);

/* Subroutine */ int cgttrs_(char *trans, int *n, int *nrhs, complex *
	dl, complex *d__, complex *du, complex *du2, int *ipiv, complex *
	b, int *ldb, int *info);

/* Subroutine */ int cgtts2_(int *itrans, int *n, int *nrhs, 
	complex *dl, complex *d__, complex *du, complex *du2, int *ipiv, 
	complex *b, int *ldb);

/* Subroutine */ int chbev_(char *jobz, char *uplo, int *n, int *kd, 
	complex *ab, int *ldab, real *w, complex *z__, int *ldz, 
	complex *work, real *rwork, int *info);

/* Subroutine */ int chbevd_(char *jobz, char *uplo, int *n, int *kd, 
	complex *ab, int *ldab, real *w, complex *z__, int *ldz, 
	complex *work, int *lwork, real *rwork, int *lrwork, int *
	iwork, int *liwork, int *info);

/* Subroutine */ int chbevx_(char *jobz, char *range, char *uplo, int *n, 
	int *kd, complex *ab, int *ldab, complex *q, int *ldq, 
	real *vl, real *vu, int *il, int *iu, real *abstol, int *
	m, real *w, complex *z__, int *ldz, complex *work, real *rwork, 
	int *iwork, int *ifail, int *info);

/* Subroutine */ int chbgst_(char *vect, char *uplo, int *n, int *ka, 
	int *kb, complex *ab, int *ldab, complex *bb, int *ldbb, 
	complex *x, int *ldx, complex *work, real *rwork, int *info);

/* Subroutine */ int chbgv_(char *jobz, char *uplo, int *n, int *ka, 
	int *kb, complex *ab, int *ldab, complex *bb, int *ldbb, 
	real *w, complex *z__, int *ldz, complex *work, real *rwork, 
	int *info);

/* Subroutine */ int chbgvd_(char *jobz, char *uplo, int *n, int *ka, 
	int *kb, complex *ab, int *ldab, complex *bb, int *ldbb, 
	real *w, complex *z__, int *ldz, complex *work, int *lwork, 
	real *rwork, int *lrwork, int *iwork, int *liwork, 
	int *info);

/* Subroutine */ int chbgvx_(char *jobz, char *range, char *uplo, int *n, 
	int *ka, int *kb, complex *ab, int *ldab, complex *bb, 
	int *ldbb, complex *q, int *ldq, real *vl, real *vu, int *
	il, int *iu, real *abstol, int *m, real *w, complex *z__, 
	int *ldz, complex *work, real *rwork, int *iwork, int *
	ifail, int *info);

/* Subroutine */ int chbtrd_(char *vect, char *uplo, int *n, int *kd, 
	complex *ab, int *ldab, real *d__, real *e, complex *q, int *
	ldq, complex *work, int *info);

/* Subroutine */ int checon_(char *uplo, int *n, complex *a, int *lda,
	 int *ipiv, real *anorm, real *rcond, complex *work, int *
	info);

/* Subroutine */ int cheev_(char *jobz, char *uplo, int *n, complex *a, 
	int *lda, real *w, complex *work, int *lwork, real *rwork, 
	int *info);

/* Subroutine */ int cheevd_(char *jobz, char *uplo, int *n, complex *a, 
	int *lda, real *w, complex *work, int *lwork, real *rwork, 
	int *lrwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int cheevr_(char *jobz, char *range, char *uplo, int *n, 
	complex *a, int *lda, real *vl, real *vu, int *il, int *
	iu, real *abstol, int *m, real *w, complex *z__, int *ldz, 
	int *isuppz, complex *work, int *lwork, real *rwork, int *
  	lrwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int cheevx_(char *jobz, char *range, char *uplo, int *n, 
	complex *a, int *lda, real *vl, real *vu, int *il, int *
	iu, real *abstol, int *m, real *w, complex *z__, int *ldz, 
	complex *work, int *lwork, real *rwork, int *iwork, int *
 	ifail, int *info);

/* Subroutine */ int chegs2_(int *itype, char *uplo, int *n, complex *
	a, int *lda, complex *b, int *ldb, int *info);

/* Subroutine */ int chegst_(int *itype, char *uplo, int *n, complex *
 	a, int *lda, complex *b, int *ldb, int *info);

/* Subroutine */ int chegv_(int *itype, char *jobz, char *uplo, int *
	n, complex *a, int *lda, complex *b, int *ldb, real *w,
  	complex *work, int *lwork, real *rwork, int *info);

/* Subroutine */ int chegvd_(int *itype, char *jobz, char *uplo, int *
	n, complex *a, int *lda, complex *b, int *ldb, real *w, 
	complex *work, int *lwork, real *rwork, int *lrwork, int *
	iwork, int *liwork, int *info);

/* Subroutine */ int chegvx_(int *itype, char *jobz, char *range, char *
	uplo, int *n, complex *a, int *lda, complex *b, int *ldb, 
	real *vl, real *vu, int *il, int *iu, real *abstol, int *
	m, real *w, complex *z__, int *ldz, complex *work, int *lwork,
 	 real *rwork, int *iwork, int *ifail, int *info);

/* Subroutine */ int cherfs_(char *uplo, int *n, int *nrhs, complex *
	a, int *lda, complex *af, int *ldaf, int *ipiv, complex *
	b, int *ldb, complex *x, int *ldx, real *ferr, real *berr, 
	complex *work, real *rwork, int *info);

/* Subroutine */ int chesv_(char *uplo, int *n, int *nrhs, complex *a,
	 int *lda, int *ipiv, complex *b, int *ldb, complex *work,
	 int *lwork, int *info);

/* Subroutine */ int chesvx_(char *fact, char *uplo, int *n, int *
	nrhs, complex *a, int *lda, complex *af, int *ldaf, int *
	ipiv, complex *b, int *ldb, complex *x, int *ldx, real *rcond,
	 real *ferr, real *berr, complex *work, int *lwork, real *rwork, 
	int *info);

/* Subroutine */ int chetd2_(char *uplo, int *n, complex *a, int *lda,
	 real *d__, real *e, complex *tau, int *info);

/* Subroutine */ int chetf2_(char *uplo, int *n, complex *a, int *lda,
	 int *ipiv, int *info);

/* Subroutine */ int chetrd_(char *uplo, int *n, complex *a, int *lda,
	 real *d__, real *e, complex *tau, complex *work, int *lwork, 
	int *info);

/* Subroutine */ int chetrf_(char *uplo, int *n, complex *a, int *lda,
 	 int *ipiv, complex *work, int *lwork, int *info);

/* Subroutine */ int chetri_(char *uplo, int *n, complex *a, int *lda,
	 int *ipiv, complex *work, int *info);

/* Subroutine */ int chetrs_(char *uplo, int *n, int *nrhs, complex *
	a, int *lda, int *ipiv, complex *b, int *ldb, int *
	info);

/* Subroutine */ int chgeqz_(char *job, char *compq, char *compz, int *n, 
	int *ilo, int *ihi, complex *h__, int *ldh, complex *t, 
	int *ldt, complex *alpha, complex *beta, complex *q, int *ldq,
	 complex *z__, int *ldz, complex *work, int *lwork, real *
	rwork, int *info);

/* Subroutine */ int chpcon_(char *uplo, int *n, complex *ap, int *
	ipiv, real *anorm, real *rcond, complex *work, int *info);

/* Subroutine */ int chpev_(char *jobz, char *uplo, int *n, complex *ap, 
	real *w, complex *z__, int *ldz, complex *work, real *rwork, 
	int *info);

/* Subroutine */ int chpevd_(char *jobz, char *uplo, int *n, complex *ap, 
	real *w, complex *z__, int *ldz, complex *work, int *lwork, 
	real *rwork, int *lrwork, int *iwork, int *liwork, 
	int *info);

/* Subroutine */ int chpevx_(char *jobz, char *range, char *uplo, int *n, 
	complex *ap, real *vl, real *vu, int *il, int *iu, real *
	abstol, int *m, real *w, complex *z__, int *ldz, complex *
	work, real *rwork, int *iwork, int *ifail, int *info);

/* Subroutine */ int chpgst_(int *itype, char *uplo, int *n, complex *
	ap, complex *bp, int *info);

/* Subroutine */ int chpgv_(int *itype, char *jobz, char *uplo, int *
	n, complex *ap, complex *bp, real *w, complex *z__, int *ldz, 
	complex *work, real *rwork, int *info);

/* Subroutine */ int chpgvd_(int *itype, char *jobz, char *uplo, int *
	n, complex *ap, complex *bp, real *w, complex *z__, int *ldz, 
	complex *work, int *lwork, real *rwork, int *lrwork, int *
	iwork, int *liwork, int *info);

/* Subroutine */ int chpgvx_(int *itype, char *jobz, char *range, char *
	uplo, int *n, complex *ap, complex *bp, real *vl, real *vu, 
	int *il, int *iu, real *abstol, int *m, real *w, complex *
	z__, int *ldz, complex *work, real *rwork, int *iwork, 
	int *ifail, int *info);

/* Subroutine */ int chprfs_(char *uplo, int *n, int *nrhs, complex *
	ap, complex *afp, int *ipiv, complex *b, int *ldb, complex *x,
	 int *ldx, real *ferr, real *berr, complex *work, real *rwork, 
	int *info);

/* Subroutine */ int chpsv_(char *uplo, int *n, int *nrhs, complex *
	ap, int *ipiv, complex *b, int *ldb, int *info);

/* Subroutine */ int chpsvx_(char *fact, char *uplo, int *n, int *
	nrhs, complex *ap, complex *afp, int *ipiv, complex *b, int *
	ldb, complex *x, int *ldx, real *rcond, real *ferr, real *berr, 
	complex *work, real *rwork, int *info);

/* Subroutine */ int chptrd_(char *uplo, int *n, complex *ap, real *d__, 
	real *e, complex *tau, int *info);

/* Subroutine */ int chptrf_(char *uplo, int *n, complex *ap, int *
	ipiv, int *info);

/* Subroutine */ int chptri_(char *uplo, int *n, complex *ap, int *
	ipiv, complex *work, int *info);

/* Subroutine */ int chptrs_(char *uplo, int *n, int *nrhs, complex *
	ap, int *ipiv, complex *b, int *ldb, int *info);

/* Subroutine */ int chsein_(char *side, char *eigsrc, char *initv, logical *
	select, int *n, complex *h__, int *ldh, complex *w, complex *
	vl, int *ldvl, complex *vr, int *ldvr, int *mm, int *
	m, complex *work, real *rwork, int *ifaill, int *ifailr, 
	int *info);

/* Subroutine */ int chseqr_(char *job, char *compz, int *n, int *ilo,
	int *ihi, complex *h__, int *ldh, complex *w, complex *z__,
   	int *ldz, complex *work, int *lwork, int *info);

/* Subroutine */ int clabrd_(int *m, int *n, int *nb, complex *a, 
	int *lda, real *d__, real *e, complex *tauq, complex *taup, 
	complex *x, int *ldx, complex *y, int *ldy);

/* Subroutine */ int clacgv_(int *n, complex *x, int *incx);

/* Subroutine */ int clacn2_(int *n, complex *v, complex *x, real *est, 
	int *kase, int *isave);

/* Subroutine */ int clacon_(int *n, complex *v, complex *x, real *est, 
	int *kase);

/* Subroutine */ int clacp2_(char *uplo, int *m, int *n, real *a, 
	int *lda, complex *b, int *ldb);

/* Subroutine */ int clacpy_(char *uplo, int *m, int *n, complex *a, 
	int *lda, complex *b, int *ldb);

/* Subroutine */ int clacrm_(int *m, int *n, complex *a, int *lda,
	 real *b, int *ldb, complex *c__, int *ldc, real *rwork);

/* Subroutine */ int clacrt_(int *n, complex *cx, int *incx, complex *
	cy, int *incy, complex *c__, complex *s);

/* Complex */ void cladiv_(complex * ret_val, complex *x, complex *y);

/* Subroutine */ int claed0_(int *qsiz, int *n, real *d__, real *e, 
	complex *q, int *ldq, complex *qstore, int *ldqs, real *rwork,
	 int *iwork, int *info);

/* Subroutine */ int claed7_(int *n, int *cutpnt, int *qsiz, 
	int *tlvls, int *curlvl, int *curpbm, real *d__, complex *
	q, int *ldq, real *rho, int *indxq, real *qstore, int *
	qptr, int *prmptr, int *perm, int *givptr, int *
	givcol, real *givnum, complex *work, real *rwork, int *iwork, 
	int *info);

/* Subroutine */ int claed8_(int *k, int *n, int *qsiz, complex *
	q, int *ldq, real *d__, real *rho, int *cutpnt, real *z__, 
	real *dlamda, complex *q2, int *ldq2, real *w, int *indxp, 
	int *indx, int *indxq, int *perm, int *givptr, 
	int *givcol, real *givnum, int *info);

/* Subroutine */ int claein_(logical *rightv, logical *noinit, int *n, 
	complex *h__, int *ldh, complex *w, complex *v, complex *b, 
	int *ldb, real *rwork, real *eps3, real *smlnum, int *info);

/* Subroutine */ int claesy_(complex *a, complex *b, complex *c__, complex *
	rt1, complex *rt2, complex *evscal, complex *cs1, complex *sn1);

/* Subroutine */ int claev2_(complex *a, complex *b, complex *c__, real *rt1, 
	real *rt2, real *cs1, complex *sn1);

/* Subroutine */ int clag2z_(int *m, int *n, complex *sa, int *
	ldsa, doublecomplex *a, int *lda, int *info);

/* Subroutine */ int clags2_(logical *upper, real *a1, complex *a2, real *a3, 
	real *b1, complex *b2, real *b3, real *csu, complex *snu, real *csv, 
	complex *snv, real *csq, complex *snq);

/* Subroutine */ int clagtm_(char *trans, int *n, int *nrhs, real *
	alpha, complex *dl, complex *d__, complex *du, complex *x, int *
	ldx, real *beta, complex *b, int *ldb);

/* Subroutine */ int clahef_(char *uplo, int *n, int *nb, int *kb,
	 complex *a, int *lda, int *ipiv, complex *w, int *ldw, 
	int *info);

/* Subroutine */ int clahqr_(logical *wantt, logical *wantz, int *n, 
	int *ilo, int *ihi, complex *h__, int *ldh, complex *w, 
	int *iloz, int *ihiz, complex *z__, int *ldz, int *
	info);

/* Subroutine */ int clahr2_(int *n, int *k, int *nb, complex *a, 
	int *lda, complex *tau, complex *t, int *ldt, complex *y, 
	int *ldy);

/* Subroutine */ int clahrd_(int *n, int *k, int *nb, complex *a, 
	int *lda, complex *tau, complex *t, int *ldt, complex *y, 
	int *ldy);

/* Subroutine */ int claic1_(int *job, int *j, complex *x, real *sest,
	 complex *w, complex *gamma, real *sestpr, complex *s, complex *c__);

/* Subroutine */ int clals0_(int *icompq, int *nl, int *nr, 
	int *sqre, int *nrhs, complex *b, int *ldb, complex *bx, 
	int *ldbx, int *perm, int *givptr, int *givcol, 
	int *ldgcol, real *givnum, int *ldgnum, real *poles, real *
	difl, real *difr, real *z__, int *k, real *c__, real *s, real *
	rwork, int *info);

/* Subroutine */ int clalsa_(int *icompq, int *smlsiz, int *n, 
	int *nrhs, complex *b, int *ldb, complex *bx, int *ldbx, 
	real *u, int *ldu, real *vt, int *k, real *difl, real *difr, 
	real *z__, real *poles, int *givptr, int *givcol, int *
	ldgcol, int *perm, real *givnum, real *c__, real *s, real *rwork, 
	int *iwork, int *info);

/* Subroutine */ int clalsd_(char *uplo, int *smlsiz, int *n, int 
	*nrhs, real *d__, real *e, complex *b, int *ldb, real *rcond, 
	int *rank, complex *work, real *rwork, int *iwork, int *
	info);

/* Subroutine */ int clapll_(int *n, complex *x, int *incx, complex *
	y, int *incy, real *ssmin);

/* Subroutine */ int clapmt_(logical *forwrd, int *m, int *n, complex 
	*x, int *ldx, int *k);

/* Subroutine */ int claqgb_(int *m, int *n, int *kl, int *ku,
	 complex *ab, int *ldab, real *r__, real *c__, real *rowcnd, real 
	*colcnd, real *amax, char *equed);

/* Subroutine */ int claqge_(int *m, int *n, complex *a, int *lda,
	 real *r__, real *c__, real *rowcnd, real *colcnd, real *amax, char *
	equed);

/* Subroutine */ int claqhb_(char *uplo, int *n, int *kd, complex *ab,
	 int *ldab, real *s, real *scond, real *amax, char *equed  	);

/* Subroutine */ int claqhe_(char *uplo, int *n, complex *a, int *lda,
	 real *s, real *scond, real *amax, char *equed);

/* Subroutine */ int claqhp_(char *uplo, int *n, complex *ap, real *s, 
	real *scond, real *amax, char *equed  	);

/* Subroutine */ int claqp2_(int *m, int *n, int *offset, complex 
	*a, int *lda, int *jpvt, complex *tau, real *vn1, real *vn2, 
	complex *work);

/* Subroutine */ int claqps_(int *m, int *n, int *offset, int 
	*nb, int *kb, complex *a, int *lda, int *jpvt, complex *
	tau, real *vn1, real *vn2, complex *auxv, complex *f, int *ldf);

/* Subroutine */ int claqr0_(logical *wantt, logical *wantz, int *n, 
	int *ilo, int *ihi, complex *h__, int *ldh, complex *w, 
	int *iloz, int *ihiz, complex *z__, int *ldz, complex *
	work, int *lwork, int *info);

/* Subroutine */ int claqr1_(int *n, complex *h__, int *ldh, complex *
	s1, complex *s2, complex *v);

/* Subroutine */ int claqr2_(logical *wantt, logical *wantz, int *n, 
	int *ktop, int *kbot, int *nw, complex *h__, int *ldh,
	 int *iloz, int *ihiz, complex *z__, int *ldz, int *
	ns, int *nd, complex *sh, complex *v, int *ldv, int *nh, 
	complex *t, int *ldt, int *nv, complex *wv, int *ldwv, 
	complex *work, int *lwork);

/* Subroutine */ int claqr3_(logical *wantt, logical *wantz, int *n, 
	int *ktop, int *kbot, int *nw, complex *h__, int *ldh,
	 int *iloz, int *ihiz, complex *z__, int *ldz, int *
	ns, int *nd, complex *sh, complex *v, int *ldv, int *nh, 
	complex *t, int *ldt, int *nv, complex *wv, int *ldwv, 
	complex *work, int *lwork);

/* Subroutine */ int claqr4_(logical *wantt, logical *wantz, int *n, 
	int *ilo, int *ihi, complex *h__, int *ldh, complex *w, 
	int *iloz, int *ihiz, complex *z__, int *ldz, complex *
	work, int *lwork, int *info);

/* Subroutine */ int claqr5_(logical *wantt, logical *wantz, int *kacc22, 
	int *n, int *ktop, int *kbot, int *nshfts, complex *s,
	 complex *h__, int *ldh, int *iloz, int *ihiz, complex *
	z__, int *ldz, complex *v, int *ldv, complex *u, int *ldu,
	 int *nv, complex *wv, int *ldwv, int *nh, complex *wh, 
	int *ldwh);

/* Subroutine */ int claqsb_(char *uplo, int *n, int *kd, complex *ab,
	 int *ldab, real *s, real *scond, real *amax, char *equed  	);

/* Subroutine */ int claqsp_(char *uplo, int *n, complex *ap, real *s, 
	real *scond, real *amax, char *equed  	);

/* Subroutine */ int claqsy_(char *uplo, int *n, complex *a, int *lda,
	 real *s, real *scond, real *amax, char *equed);

/* Subroutine */ int clar1v_(int *n, int *b1, int *bn, real *
	lambda, real *d__, real *l, real *ld, real *lld, real *pivmin, real *
	gaptol, complex *z__, logical *wantnc, int *negcnt, real *ztz, 
	real *mingma, int *r__, int *isuppz, real *nrminv, real *
	resid, real *rqcorr, real *work);

/* Subroutine */ int clar2v_(int *n, complex *x, complex *y, complex *z__,
	 int *incx, real *c__, complex *s, int *incc);

/* Subroutine */ int clarcm_(int *m, int *n, real *a, int *lda, 
	complex *b, int *ldb, complex *c__, int *ldc, real *rwork);

/* Subroutine */ int clarf_(char *side, int *m, int *n, complex *v, 
	int *incv, complex *tau, complex *c__, int *ldc, complex *
	work);

/* Subroutine */ int clarfb_(char *side, char *trans, char *direct, char *
	storev, int *m, int *n, int *k, complex *v, int *ldv, 
	complex *t, int *ldt, complex *c__, int *ldc, complex *work, 
	int *ldwork);

/* Subroutine */ int clarfg_(int *n, complex *alpha, complex *x, int *
	incx, complex *tau);

/* Subroutine */ int clarft_(char *direct, char *storev, int *n, int *
	k, complex *v, int *ldv, complex *tau, complex *t, int *ldt);

/* Subroutine */ int clarfx_(char *side, int *m, int *n, complex *v, 
	complex *tau, complex *c__, int *ldc, complex *work  	);

/* Subroutine */ int clargv_(int *n, complex *x, int *incx, complex *
	y, int *incy, real *c__, int *incc);

/* Subroutine */ int clarnv_(int *idist, int *iseed, int *n, 
	complex *x);

/* Subroutine */ int clarrv_(int *n, real *vl, real *vu, real *d__, real *
	l, real *pivmin, int *isplit, int *m, int *dol, int *
	dou, real *minrgp, real *rtol1, real *rtol2, real *w, real *werr, 
	real *wgap, int *iblock, int *indexw, real *gers, complex *
	z__, int *ldz, int *isuppz, real *work, int *iwork, 
	int *info);

/* Subroutine */ int clartg_(complex *f, complex *g, real *cs, complex *sn, 
	complex *r__);

/* Subroutine */ int clartv_(int *n, complex *x, int *incx, complex *
	y, int *incy, real *c__, complex *s, int *incc);

/* Subroutine */ int clarz_(char *side, int *m, int *n, int *l, 
	complex *v, int *incv, complex *tau, complex *c__, int *ldc, 
	complex *work);

/* Subroutine */ int clarzb_(char *side, char *trans, char *direct, char *
	storev, int *m, int *n, int *k, int *l, complex *v, 
	int *ldv, complex *t, int *ldt, complex *c__, int *ldc, 
	complex *work, int *ldwork);

/* Subroutine */ int clarzt_(char *direct, char *storev, int *n, int *
	k, complex *v, int *ldv, complex *tau, complex *t, int *ldt);

/* Subroutine */ int clascl_(char *type__, int *kl, int *ku, real *
	cfrom, real *cto, int *m, int *n, complex *a, int *lda, 
	int *info);

/* Subroutine */ int claset_(char *uplo, int *m, int *n, complex *
	alpha, complex *beta, complex *a, int *lda);

/* Subroutine */ int clasr_(char *side, char *pivot, char *direct, int *m,
	 int *n, real *c__, real *s, complex *a, int *lda  	);

/* Subroutine */ int classq_(int *n, complex *x, int *incx, real *
	scale, real *sumsq);

/* Subroutine */ int claswp_(int *n, complex *a, int *lda, int *
	k1, int *k2, int *ipiv, int *incx);

/* Subroutine */ int clasyf_(char *uplo, int *n, int *nb, int *kb,
	 complex *a, int *lda, int *ipiv, complex *w, int *ldw, 
	int *info);

/* Subroutine */ int clatbs_(char *uplo, char *trans, char *diag, char *
	normin, int *n, int *kd, complex *ab, int *ldab, complex *
	x, real *scale, real *cnorm, int *info);

/* Subroutine */ int clatdf_(int *ijob, int *n, complex *z__, int 
	*ldz, complex *rhs, real *rdsum, real *rdscal, int *ipiv, int 
	*jpiv);

/* Subroutine */ int clatps_(char *uplo, char *trans, char *diag, char *
	normin, int *n, complex *ap, complex *x, real *scale, real *cnorm,
	 int *info);

/* Subroutine */ int clatrd_(char *uplo, int *n, int *nb, complex *a, 
	int *lda, real *e, complex *tau, complex *w, int *ldw  	);

/* Subroutine */ int clatrs_(char *uplo, char *trans, char *diag, char *
	normin, int *n, complex *a, int *lda, complex *x, real *scale,
	 real *cnorm, int *info);

/* Subroutine */ int clatrz_(int *m, int *n, int *l, complex *a, 
	int *lda, complex *tau, complex *work);

/* Subroutine */ int clatzm_(char *side, int *m, int *n, complex *v, 
	int *incv, complex *tau, complex *c1, complex *c2, int *ldc, 
	complex *work);

/* Subroutine */ int clauu2_(char *uplo, int *n, complex *a, int *lda,
	 int *info);

/* Subroutine */ int clauum_(char *uplo, int *n, complex *a, int *lda,
	 int *info);

/* Subroutine */ int cpbcon_(char *uplo, int *n, int *kd, complex *ab,
	 int *ldab, real *anorm, real *rcond, complex *work, real *rwork, 
	int *info);

/* Subroutine */ int cpbequ_(char *uplo, int *n, int *kd, complex *ab,
	 int *ldab, real *s, real *scond, real *amax, int *info);

/* Subroutine */ int cpbrfs_(char *uplo, int *n, int *kd, int *
	nrhs, complex *ab, int *ldab, complex *afb, int *ldafb, 
	complex *b, int *ldb, complex *x, int *ldx, real *ferr, real *
	berr, complex *work, real *rwork, int *info);

/* Subroutine */ int cpbstf_(char *uplo, int *n, int *kd, complex *ab,
	 int *ldab, int *info);

/* Subroutine */ int cpbsv_(char *uplo, int *n, int *kd, int *
	nrhs, complex *ab, int *ldab, complex *b, int *ldb, int *
	info);

/* Subroutine */ int cpbsvx_(char *fact, char *uplo, int *n, int *kd, 
	int *nrhs, complex *ab, int *ldab, complex *afb, int *
	ldafb, char *equed, real *s, complex *b, int *ldb, complex *x, 
	int *ldx, real *rcond, real *ferr, real *berr, complex *work, 
	real *rwork, int *info);

/* Subroutine */ int cpbtf2_(char *uplo, int *n, int *kd, complex *ab,
	 int *ldab, int *info);

/* Subroutine */ int cpbtrf_(char *uplo, int *n, int *kd, complex *ab,
	 int *ldab, int *info);

/* Subroutine */ int cpbtrs_(char *uplo, int *n, int *kd, int *
	nrhs, complex *ab, int *ldab, complex *b, int *ldb, int *
	info);

/* Subroutine */ int cpocon_(char *uplo, int *n, complex *a, int *lda,
	 real *anorm, real *rcond, complex *work, real *rwork, int *info);

/* Subroutine */ int cpoequ_(int *n, complex *a, int *lda, real *s, 
	real *scond, real *amax, int *info);

/* Subroutine */ int cporfs_(char *uplo, int *n, int *nrhs, complex *
	a, int *lda, complex *af, int *ldaf, complex *b, int *ldb,
	 complex *x, int *ldx, real *ferr, real *berr, complex *work, 
	real *rwork, int *info);

/* Subroutine */ int cposv_(char *uplo, int *n, int *nrhs, complex *a,
	 int *lda, complex *b, int *ldb, int *info);

/* Subroutine */ int cposvx_(char *fact, char *uplo, int *n, int *
	nrhs, complex *a, int *lda, complex *af, int *ldaf, char *
	equed, real *s, complex *b, int *ldb, complex *x, int *ldx, 
	real *rcond, real *ferr, real *berr, complex *work, real *rwork, 
	int *info);

/* Subroutine */ int cpotf2_(char *uplo, int *n, complex *a, int *lda,
	 int *info);

/* Subroutine */ int cpotrf_(char *uplo, int *n, complex *a, int *lda,
	 int *info);

/* Subroutine */ int cpotri_(char *uplo, int *n, complex *a, int *lda,
	 int *info);

/* Subroutine */ int cpotrs_(char *uplo, int *n, int *nrhs, complex *
	a, int *lda, complex *b, int *ldb, int *info);

/* Subroutine */ int cppcon_(char *uplo, int *n, complex *ap, real *anorm,
	 real *rcond, complex *work, real *rwork, int *info);

/* Subroutine */ int cppequ_(char *uplo, int *n, complex *ap, real *s, 
	real *scond, real *amax, int *info);

/* Subroutine */ int cpprfs_(char *uplo, int *n, int *nrhs, complex *
	ap, complex *afp, complex *b, int *ldb, complex *x, int *ldx, 
	real *ferr, real *berr, complex *work, real *rwork, int *info);

/* Subroutine */ int cppsv_(char *uplo, int *n, int *nrhs, complex *
	ap, complex *b, int *ldb, int *info);

/* Subroutine */ int cppsvx_(char *fact, char *uplo, int *n, int *
	nrhs, complex *ap, complex *afp, char *equed, real *s, complex *b, 
	int *ldb, complex *x, int *ldx, real *rcond, real *ferr, real 
	*berr, complex *work, real *rwork, int *info);

/* Subroutine */ int cpptrf_(char *uplo, int *n, complex *ap, int *
	info);

/* Subroutine */ int cpptri_(char *uplo, int *n, complex *ap, int *
	info);

/* Subroutine */ int cpptrs_(char *uplo, int *n, int *nrhs, complex *
	ap, complex *b, int *ldb, int *info);

/* Subroutine */ int cptcon_(int *n, real *d__, complex *e, real *anorm, 
	real *rcond, real *rwork, int *info);

/* Subroutine */ int cpteqr_(char *compz, int *n, real *d__, real *e, 
	complex *z__, int *ldz, real *work, int *info);

/* Subroutine */ int cptrfs_(char *uplo, int *n, int *nrhs, real *d__,
	 complex *e, real *df, complex *ef, complex *b, int *ldb, complex 
	*x, int *ldx, real *ferr, real *berr, complex *work, real *rwork, 
	int *info);

/* Subroutine */ int cptsv_(int *n, int *nrhs, real *d__, complex *e, 
	complex *b, int *ldb, int *info);

/* Subroutine */ int cptsvx_(char *fact, int *n, int *nrhs, real *d__,
	 complex *e, real *df, complex *ef, complex *b, int *ldb, complex 
	*x, int *ldx, real *rcond, real *ferr, real *berr, complex *work, 
	real *rwork, int *info);

/* Subroutine */ int cpttrf_(int *n, real *d__, complex *e, int *info);

/* Subroutine */ int cpttrs_(char *uplo, int *n, int *nrhs, real *d__,
	 complex *e, complex *b, int *ldb, int *info);

/* Subroutine */ int cptts2_(int *iuplo, int *n, int *nrhs, real *
	d__, complex *e, complex *b, int *ldb);

/* Subroutine */ int crot_(int *n, complex *cx, int *incx, complex *
	cy, int *incy, real *c__, complex *s);

/* Subroutine */ int cspcon_(char *uplo, int *n, complex *ap, int *
	ipiv, real *anorm, real *rcond, complex *work, int *info);

/* Subroutine */ int cspmv_(char *uplo, int *n, complex *alpha, complex *
	ap, complex *x, int *incx, complex *beta, complex *y, int *
	incy);

/* Subroutine */ int cspr_(char *uplo, int *n, complex *alpha, complex *x,
	 int *incx, complex *ap);

/* Subroutine */ int csprfs_(char *uplo, int *n, int *nrhs, complex *
	ap, complex *afp, int *ipiv, complex *b, int *ldb, complex *x,
	 int *ldx, real *ferr, real *berr, complex *work, real *rwork, 
	int *info);

/* Subroutine */ int cspsv_(char *uplo, int *n, int *nrhs, complex *
	ap, int *ipiv, complex *b, int *ldb, int *info);

/* Subroutine */ int cspsvx_(char *fact, char *uplo, int *n, int *
	nrhs, complex *ap, complex *afp, int *ipiv, complex *b, int *
	ldb, complex *x, int *ldx, real *rcond, real *ferr, real *berr, 
	complex *work, real *rwork, int *info);

/* Subroutine */ int csptrf_(char *uplo, int *n, complex *ap, int *
	ipiv, int *info);

/* Subroutine */ int csptri_(char *uplo, int *n, complex *ap, int *
	ipiv, complex *work, int *info);

/* Subroutine */ int csptrs_(char *uplo, int *n, int *nrhs, complex *
	ap, int *ipiv, complex *b, int *ldb, int *info);

/* Subroutine */ int csrscl_(int *n, real *sa, complex *sx, int *incx);

/* Subroutine */ int cstedc_(char *compz, int *n, real *d__, real *e, 
	complex *z__, int *ldz, complex *work, int *lwork, real *
	rwork, int *lrwork, int *iwork, int *liwork, int *
	info);

/* Subroutine */ int cstegr_(char *jobz, char *range, int *n, real *d__, 
	real *e, real *vl, real *vu, int *il, int *iu, real *abstol, 
	int *m, real *w, complex *z__, int *ldz, int *isuppz, 
	real *work, int *lwork, int *iwork, int *liwork, int *
	info);

/* Subroutine */ int cstein_(int *n, real *d__, real *e, int *m, real 
	*w, int *iblock, int *isplit, complex *z__, int *ldz, 
	real *work, int *iwork, int *ifail, int *info);

/* Subroutine */ int cstemr_(char *jobz, char *range, int *n, real *d__, 
	real *e, real *vl, real *vu, int *il, int *iu, int *m, 
	real *w, complex *z__, int *ldz, int *nzc, int *isuppz, 
	logical *tryrac, real *work, int *lwork, int *iwork, int *
	liwork, int *info);

/* Subroutine */ int csteqr_(char *compz, int *n, real *d__, real *e, 
	complex *z__, int *ldz, real *work, int *info);

/* Subroutine */ int csycon_(char *uplo, int *n, complex *a, int *lda,
	 int *ipiv, real *anorm, real *rcond, complex *work, int *
	info);

/* Subroutine */ int csymv_(char *uplo, int *n, complex *alpha, complex *
	a, int *lda, complex *x, int *incx, complex *beta, complex *y,
	 int *incy);

/* Subroutine */ int csyr_(char *uplo, int *n, complex *alpha, complex *x,
	 int *incx, complex *a, int *lda);

/* Subroutine */ int csyrfs_(char *uplo, int *n, int *nrhs, complex *
	a, int *lda, complex *af, int *ldaf, int *ipiv, complex *
	b, int *ldb, complex *x, int *ldx, real *ferr, real *berr, 
	complex *work, real *rwork, int *info);

/* Subroutine */ int csysv_(char *uplo, int *n, int *nrhs, complex *a,
	 int *lda, int *ipiv, complex *b, int *ldb, complex *work,
	 int *lwork, int *info);

/* Subroutine */ int csysvx_(char *fact, char *uplo, int *n, int *
	nrhs, complex *a, int *lda, complex *af, int *ldaf, int *
	ipiv, complex *b, int *ldb, complex *x, int *ldx, real *rcond,
	 real *ferr, real *berr, complex *work, int *lwork, real *rwork, 
	int *info);

/* Subroutine */ int csytf2_(char *uplo, int *n, complex *a, int *lda,
	 int *ipiv, int *info);

/* Subroutine */ int csytrf_(char *uplo, int *n, complex *a, int *lda,
 	 int *ipiv, complex *work, int *lwork, int *info);

/* Subroutine */ int csytri_(char *uplo, int *n, complex *a, int *lda,
	 int *ipiv, complex *work, int *info);

/* Subroutine */ int csytrs_(char *uplo, int *n, int *nrhs, complex *
	a, int *lda, int *ipiv, complex *b, int *ldb, int *
	info);

/* Subroutine */ int ctbcon_(char *norm, char *uplo, char *diag, int *n, 
	int *kd, complex *ab, int *ldab, real *rcond, complex *work, 
	real *rwork, int *info);

/* Subroutine */ int ctbrfs_(char *uplo, char *trans, char *diag, int *n, 
	int *kd, int *nrhs, complex *ab, int *ldab, complex *b, 
	int *ldb, complex *x, int *ldx, real *ferr, real *berr, 
	complex *work, real *rwork, int *info);

/* Subroutine */ int ctbtrs_(char *uplo, char *trans, char *diag, int *n, 
	int *kd, int *nrhs, complex *ab, int *ldab, complex *b, 
	int *ldb, int *info);

/* Subroutine */ int ctgevc_(char *side, char *howmny, logical *select, 
	int *n, complex *s, int *lds, complex *p, int *ldp, 
	complex *vl, int *ldvl, complex *vr, int *ldvr, int *mm, 
	int *m, complex *work, real *rwork, int *info);

/* Subroutine */ int ctgex2_(logical *wantq, logical *wantz, int *n, 
	complex *a, int *lda, complex *b, int *ldb, complex *q, 
	int *ldq, complex *z__, int *ldz, int *j1, int *info);

/* Subroutine */ int ctgexc_(logical *wantq, logical *wantz, int *n, 
	complex *a, int *lda, complex *b, int *ldb, complex *q, 
	int *ldq, complex *z__, int *ldz, int *ifst, int *
	ilst, int *info);

/* Subroutine */ int ctgsen_(int *ijob, logical *wantq, logical *wantz, 
	logical *select, int *n, complex *a, int *lda, complex *b, 
	int *ldb, complex *alpha, complex *beta, complex *q, int *ldq,
	 complex *z__, int *ldz, int *m, real *pl, real *pr, real *
	dif, complex *work, int *lwork, int *iwork, int *liwork, 
	int *info);

/* Subroutine */ int ctgsja_(char *jobu, char *jobv, char *jobq, int *m, 
	int *p, int *n, int *k, int *l, complex *a, int *
	lda, complex *b, int *ldb, real *tola, real *tolb, real *alpha, 
	real *beta, complex *u, int *ldu, complex *v, int *ldv, 
	complex *q, int *ldq, complex *work, int *ncycle, int *
	info);

/* Subroutine */ int ctgsna_(char *job, char *howmny, logical *select, 
	int *n, complex *a, int *lda, complex *b, int *ldb, 
	complex *vl, int *ldvl, complex *vr, int *ldvr, real *s, real 
	*dif, int *mm, int *m, complex *work, int *lwork, int 
	*iwork, int *info);

/* Subroutine */ int ctgsy2_(char *trans, int *ijob, int *m, int *
	n, complex *a, int *lda, complex *b, int *ldb, complex *c__, 
	int *ldc, complex *d__, int *ldd, complex *e, int *lde, 
	complex *f, int *ldf, real *scale, real *rdsum, real *rdscal, 
	int *info);

/* Subroutine */ int ctgsyl_(char *trans, int *ijob, int *m, int *
	n, complex *a, int *lda, complex *b, int *ldb, complex *c__, 
	int *ldc, complex *d__, int *ldd, complex *e, int *lde, 
	complex *f, int *ldf, real *scale, real *dif, complex *work, 
	int *lwork, int *iwork, int *info);

/* Subroutine */ int ctpcon_(char *norm, char *uplo, char *diag, int *n, 
	complex *ap, real *rcond, complex *work, real *rwork, int *info);

/* Subroutine */ int ctprfs_(char *uplo, char *trans, char *diag, int *n, 
	int *nrhs, complex *ap, complex *b, int *ldb, complex *x, 
	int *ldx, real *ferr, real *berr, complex *work, real *rwork, 
	int *info);

/* Subroutine */ int ctptri_(char *uplo, char *diag, int *n, complex *ap, 
	int *info);

/* Subroutine */ int ctptrs_(char *uplo, char *trans, char *diag, int *n, 
	int *nrhs, complex *ap, complex *b, int *ldb, int *info);

/* Subroutine */ int ctrcon_(char *norm, char *uplo, char *diag, int *n, 
	complex *a, int *lda, real *rcond, complex *work, real *rwork, 
	int *info);

/* Subroutine */ int ctrevc_(char *side, char *howmny, logical *select, 
	int *n, complex *t, int *ldt, complex *vl, int *ldvl, 
	complex *vr, int *ldvr, int *mm, int *m, complex *work, 
	real *rwork, int *info);

/* Subroutine */ int ctrexc_(char *compq, int *n, complex *t, int *
	ldt, complex *q, int *ldq, int *ifst, int *ilst, int *
	info);

/* Subroutine */ int ctrrfs_(char *uplo, char *trans, char *diag, int *n, 
	int *nrhs, complex *a, int *lda, complex *b, int *ldb, 
	complex *x, int *ldx, real *ferr, real *berr, complex *work, real 
	*rwork, int *info);

/* Subroutine */ int ctrsen_(char *job, char *compq, logical *select, int 
	*n, complex *t, int *ldt, complex *q, int *ldq, complex *w, 
	int *m, real *s, real *sep, complex *work, int *lwork, 
	int *info);

/* Subroutine */ int ctrsna_(char *job, char *howmny, logical *select, 
	int *n, complex *t, int *ldt, complex *vl, int *ldvl, 
	complex *vr, int *ldvr, real *s, real *sep, int *mm, int *
	m, complex *work, int *ldwork, real *rwork, int *info);

/* Subroutine */ int ctrsyl_(char *trana, char *tranb, int *isgn, int 
	*m, int *n, complex *a, int *lda, complex *b, int *ldb, 
	complex *c__, int *ldc, real *scale, int *info);

/* Subroutine */ int ctrti2_(char *uplo, char *diag, int *n, complex *a, 
	int *lda, int *info);

/* Subroutine */ int ctrtri_(char *uplo, char *diag, int *n, complex *a, 
	int *lda, int *info);

/* Subroutine */ int ctrtrs_(char *uplo, char *trans, char *diag, int *n, 
	int *nrhs, complex *a, int *lda, complex *b, int *ldb, 
	int *info);

/* Subroutine */ int ctzrqf_(int *m, int *n, complex *a, int *lda,
	 complex *tau, int *info);

/* Subroutine */ int ctzrzf_(int *m, int *n, complex *a, int *lda,
	 complex *tau, complex *work, int *lwork, int *info);

/* Subroutine */ int cung2l_(int *m, int *n, int *k, complex *a, 
	int *lda, complex *tau, complex *work, int *info);

/* Subroutine */ int cung2r_(int *m, int *n, int *k, complex *a, 
	int *lda, complex *tau, complex *work, int *info);

/* Subroutine */ int cungbr_(char *vect, int *m, int *n, int *k, 
	complex *a, int *lda, complex *tau, complex *work, int *lwork,
	 int *info);

/* Subroutine */ int cunghr_(int *n, int *ilo, int *ihi, complex *
	a, int *lda, complex *tau, complex *work, int *lwork, int 
	*info);

/* Subroutine */ int cungl2_(int *m, int *n, int *k, complex *a, 
	int *lda, complex *tau, complex *work, int *info);

/* Subroutine */ int cunglq_(int *m, int *n, int *k, complex *a, 
	int *lda, complex *tau, complex *work, int *lwork, int *
	info);

/* Subroutine */ int cungql_(int *m, int *n, int *k, complex *a, 
	int *lda, complex *tau, complex *work, int *lwork, int *
	info);

/* Subroutine */ int cungqr_(int *m, int *n, int *k, complex *a, 
	int *lda, complex *tau, complex *work, int *lwork, int *
	info);

/* Subroutine */ int cungr2_(int *m, int *n, int *k, complex *a, 
	int *lda, complex *tau, complex *work, int *info);

/* Subroutine */ int cungrq_(int *m, int *n, int *k, complex *a, 
	int *lda, complex *tau, complex *work, int *lwork, int *
	info);

/* Subroutine */ int cungtr_(char *uplo, int *n, complex *a, int *lda,
 	 complex *tau, complex *work, int *lwork, int *info);

/* Subroutine */ int cunm2l_(char *side, char *trans, int *m, int *n, 
	int *k, complex *a, int *lda, complex *tau, complex *c__, 
	int *ldc, complex *work, int *info);

/* Subroutine */ int cunm2r_(char *side, char *trans, int *m, int *n, 
	int *k, complex *a, int *lda, complex *tau, complex *c__, 
	int *ldc, complex *work, int *info);

/* Subroutine */ int cunmbr_(char *vect, char *side, char *trans, int *m, 
	int *n, int *k, complex *a, int *lda, complex *tau, 
	complex *c__, int *ldc, complex *work, int *lwork, int *
	info);

/* Subroutine */ int cunmhr_(char *side, char *trans, int *m, int *n, 
	int *ilo, int *ihi, complex *a, int *lda, complex *tau, 
	complex *c__, int *ldc, complex *work, int *lwork, int *
	info);

/* Subroutine */ int cunml2_(char *side, char *trans, int *m, int *n, 
	int *k, complex *a, int *lda, complex *tau, complex *c__, 
	int *ldc, complex *work, int *info);

/* Subroutine */ int cunmlq_(char *side, char *trans, int *m, int *n, 
	int *k, complex *a, int *lda, complex *tau, complex *c__,
	  	int *ldc, complex *work, int *lwork, int *info);

/* Subroutine */ int cunmql_(char *side, char *trans, int *m, int *n, 
	int *k, complex *a, int *lda, complex *tau, complex *c__,
	  	int *ldc, complex *work, int *lwork, int *info);

/* Subroutine */ int cunmqr_(char *side, char *trans, int *m, int *n, 
	int *k, complex *a, int *lda, complex *tau, complex *c__,
	  	int *ldc, complex *work, int *lwork, int *info);

/* Subroutine */ int cunmr2_(char *side, char *trans, int *m, int *n, 
	int *k, complex *a, int *lda, complex *tau, complex *c__, 
	int *ldc, complex *work, int *info);

/* Subroutine */ int cunmr3_(char *side, char *trans, int *m, int *n, 
	int *k, int *l, complex *a, int *lda, complex *tau, 
	complex *c__, int *ldc, complex *work, int *info);

/* Subroutine */ int cunmrq_(char *side, char *trans, int *m, int *n, 
	int *k, complex *a, int *lda, complex *tau, complex *c__,  	
	int *ldc, complex *work, int *lwork, int *iinfo);

/* Subroutine */ int cupgtr_(char *uplo, int *n, complex *ap, complex *
	tau, complex *q, int *ldq, complex *work, int *info);

/* Subroutine */ int cupmtr_(char *side, char *uplo, char *trans, int *m, 
	int *n, complex *ap, complex *tau, complex *c__, int *ldc, 
	complex *work, int *info);


/* Subroutine */ int ddisna_(char *job, int *m, int *n, double *
	d__, double *sep, int *info);

/* Subroutine */ int dgbbrd_(char *vect, int *m, int *n, int *ncc,
	 int *kl, int *ku, double *ab, int *ldab, double *
	d__, double *e, double *q, int *ldq, double *pt, 
	int *ldpt, double *c__, int *ldc, double *work, 
	int *info);

/* Subroutine */ int dgbcon_(char *norm, int *n, int *kl, int *ku,
	 double *ab, int *ldab, int *ipiv, double *anorm, 
	double *rcond, double *work, int *iwork, int *info);

/* Subroutine */ int dgbequ_(int *m, int *n, int *kl, int *ku,
	 double *ab, int *ldab, double *r__, double *c__, 
	double *rowcnd, double *colcnd, double *amax, int *
	info);

/* Subroutine */ int dgbrfs_(char *trans, int *n, int *kl, int *
	ku, int *nrhs, double *ab, int *ldab, double *afb, 
	int *ldafb, int *ipiv, double *b, int *ldb, 
	double *x, int *ldx, double *ferr, double *berr, 
	double *work, int *iwork, int *info);

/* Subroutine */ int dgbsv_(int *n, int *kl, int *ku, int *
	nrhs, double *ab, int *ldab, int *ipiv, double *b, 
	int *ldb, int *info);

/* Subroutine */ int dgbsvx_(char *fact, char *trans, int *n, int *kl,
	 int *ku, int *nrhs, double *ab, int *ldab, 
	double *afb, int *ldafb, int *ipiv, char *equed, 
	double *r__, double *c__, double *b, int *ldb, 
	double *x, int *ldx, double *rcond, double *ferr, 
	double *berr, double *work, int *iwork, int *info);

/* Subroutine */ int dgbtf2_(int *m, int *n, int *kl, int *ku,
	 double *ab, int *ldab, int *ipiv, int *info);

/* Subroutine */ int dgbtrf_(int *m, int *n, int *kl, int *ku,
	 double *ab, int *ldab, int *ipiv, int *info);

/* Subroutine */ int dgbtrs_(char *trans, int *n, int *kl, int *
	ku, int *nrhs, double *ab, int *ldab, int *ipiv, 
	double *b, int *ldb, int *info);

/* Subroutine */ int dgebak_(char *job, char *side, int *n, int *ilo, 
	int *ihi, double *scale, int *m, double *v, int *
	ldv, int *info);

/* Subroutine */ int dgebal_(char *job, int *n, double *a, int *
	lda, int *ilo, int *ihi, double *scale, int *info);

/* Subroutine */ int dgebd2_(int *m, int *n, double *a, int *
	lda, double *d__, double *e, double *tauq, double *
	taup, double *work, int *info);

/* Subroutine */ int dgecon_(char *norm, int *n, double *a, int *
	lda, double *anorm, double *rcond, double *work, int *
	iwork, int *info);

/* Subroutine */ int dgeequ_(int *m, int *n, double *a, int *
	lda, double *r__, double *c__, double *rowcnd, double 
	*colcnd, double *amax, int *info);

/* Subroutine */ int dgees_(char *jobvs, char *sort, L_fp select, int *n, 
	double *a, int *lda, int *sdim, double *wr, 
	double *wi, double *vs, int *ldvs, double *work, 
	int *lwork, logical *bwork, int *info);

/* Subroutine */ int dgeesx_(char *jobvs, char *sort, L_fp select, char *
	sense, int *n, double *a, int *lda, int *sdim, 
	double *wr, double *wi, double *vs, int *ldvs, 
	double *rconde, double *rcondv, double *work, int *
	lwork, int *iwork, int *liwork, logical *bwork, int *info);

/* Subroutine */ int dgeev_(char *jobvl, char *jobvr, int *n, double *
	a, int *lda, double *wr, double *wi, double *vl, 
	int *ldvl, double *vr, int *ldvr, double *work, 
	int *lwork, int *info);

/* Subroutine */ int dgeevx_(char *balanc, char *jobvl, char *jobvr, char *
	sense, int *n, double *a, int *lda, double *wr, 
	double *wi, double *vl, int *ldvl, double *vr, 
	int *ldvr, int *ilo, int *ihi, double *scale, 
	double *abnrm, double *rconde, double *rcondv, double  	
	*work, int *lwork, int *iwork, int *info);

/* Subroutine */ int dgegs_(char *jobvsl, char *jobvsr, int *n, 
	double *a, int *lda, double *b, int *ldb, double *
	alphar, double *alphai, double *beta, double *vsl, 
	int *ldvsl, double *vsr, int *ldvsr, double *work, 
	int *lwork, int *info);

/* Subroutine */ int dgegv_(char *jobvl, char *jobvr, int *n, double *
	a, int *lda, double *b, int *ldb, double *alphar, 
	double *alphai, double *beta, double *vl, int *ldvl, 
	double *vr, int *ldvr, double *work, int *lwork, 
	int *info);

/* Subroutine */ int dgehd2_(int *n, int *ilo, int *ihi, 
	double *a, int *lda, double *tau, double *work, 
	int *info);

/* Subroutine */ int dgehrd_(int *n, int *ilo, int *ihi, 
	double *a, int *lda, double *tau, double *work, 
	int *lwork, int *info);

/* Subroutine */ int dgelq2_(int *m, int *n, double *a, int *
	lda, double *tau, double *work, int *info);

/* Subroutine */ int dgels_(char *trans, int *m, int *n, int *
	nrhs, double *a, int *lda, double *b, int *ldb, 
	double *work, int *lwork, int *info);

/* Subroutine */ int dgelsd_(int *m, int *n, int *nrhs, 
	double *a, int *lda, double *b, int *ldb, double *
	s, double *rcond, int *rank, double *work, int *lwork,
	 int *iwork, int *info);

/* Subroutine */ int dgelss_(int *m, int *n, int *nrhs, 
	double *a, int *lda, double *b, int *ldb, double *
	s, double *rcond, int *rank, double *work, int *lwork,
	 int *info);

/* Subroutine */ int dgelsx_(int *m, int *n, int *nrhs, 
	double *a, int *lda, double *b, int *ldb, int *
	jpvt, double *rcond, int *rank, double *work, int *
	info);

/* Subroutine */ int dgelsy_(int *m, int *n, int *nrhs, 
	double *a, int *lda, double *b, int *ldb, int *
	jpvt, double *rcond, int *rank, double *work, int *
	lwork, int *info);

/* Subroutine */ int dgeql2_(int *m, int *n, double *a, int *
	lda, double *tau, double *work, int *info);

/* Subroutine */ int dgeqlf_(int *m, int *n, double *a, int *
	lda, double *tau, double *work, int *lwork, int *info);

/* Subroutine */ int dgeqp3_(int *m, int *n, double *a, int *
	lda, int *jpvt, double *tau, double *work, int *lwork,
	 int *info);

/* Subroutine */ int dgeqpf_(int *m, int *n, double *a, int *
	lda, int *jpvt, double *tau, double *work, int *info);

/* Subroutine */ int dgeqr2_(int *m, int *n, double *a, int *
	lda, double *tau, double *work, int *info);

/* Subroutine */ int dgerfs_(char *trans, int *n, int *nrhs, 
	double *a, int *lda, double *af, int *ldaf, int *
	ipiv, double *b, int *ldb, double *x, int *ldx, 
	double *ferr, double *berr, double *work, int *iwork, 
	int *info);

/* Subroutine */ int dgerq2_(int *m, int *n, double *a, int *
	lda, double *tau, double *work, int *info);

/* Subroutine */ int dgerqf_(int *m, int *n, double *a, int *
	lda, double *tau, double *work, int *lwork, int *info);

/* Subroutine */ int dgesc2_(int *n, double *a, int *lda, 
	double *rhs, int *ipiv, int *jpiv, double *scale);

/* Subroutine */ int dgesv_(int *n, int *nrhs, double *a, int 
	*lda, int *ipiv, double *b, int *ldb, int *info);

/* Subroutine */ int dgesvd_(char *jobu, char *jobvt, int *m, int *n, 
	double *a, int *lda, double *s, double *u, int *
	ldu, double *vt, int *ldvt, double *work, int *lwork, 
	int *info);

/* Subroutine */ int dgesvx_(char *fact, char *trans, int *n, int *
	nrhs, double *a, int *lda, double *af, int *ldaf, 
	int *ipiv, char *equed, double *r__, double *c__, 
	double *b, int *ldb, double *x, int *ldx, double *
	rcond, double *ferr, double *berr, double *work, int *
	iwork, int *info);

/* Subroutine */ int dgetc2_(int *n, double *a, int *lda, int 
	*ipiv, int *jpiv, int *info);

/* Subroutine */ int dgetf2_(int *m, int *n, double *a, int *
	lda, int *ipiv, int *info);

/* Subroutine */ int dggbak_(char *job, char *side, int *n, int *ilo, 
	int *ihi, double *lscale, double *rscale, int *m, 
	double *v, int *ldv, int *info);

/* Subroutine */ int dggbal_(char *job, int *n, double *a, int *
	lda, double *b, int *ldb, int *ilo, int *ihi, 
	double *lscale, double *rscale, double *work, int *
	info);

/* Subroutine */ int dgges_(char *jobvsl, char *jobvsr, char *sort, L_fp 
	selctg, int *n, double *a, int *lda, double *b, 
	int *ldb, int *sdim, double *alphar, double *alphai, 
	double *beta, double *vsl, int *ldvsl, double *vsr, 
	int *ldvsr, double *work, int *lwork, logical *bwork, 
	int *info);

/* Subroutine */ int dggesx_(char *jobvsl, char *jobvsr, char *sort, L_fp 
	selctg, char *sense, int *n, double *a, int *lda, 
	double *b, int *ldb, int *sdim, double *alphar, 
	double *alphai, double *beta, double *vsl, int *ldvsl,
	 double *vsr, int *ldvsr, double *rconde, double *
	rcondv, double *work, int *lwork, int *iwork, int * 	
	liwork, logical *bwork, int *info);

/* Subroutine */ int dggev_(char *jobvl, char *jobvr, int *n, double *
	a, int *lda, double *b, int *ldb, double *alphar, 
	double *alphai, double *beta, double *vl, int *ldvl, 
	double *vr, int *ldvr, double *work, int *lwork, 
	int *info);

/* Subroutine */ int dggevx_(char *balanc, char *jobvl, char *jobvr, char *
	sense, int *n, double *a, int *lda, double *b, 
	int *ldb, double *alphar, double *alphai, double *
	beta, double *vl, int *ldvl, double *vr, int *ldvr, 
	int *ilo, int *ihi, double *lscale, double *rscale, 
	double *abnrm, double *bbnrm, double *rconde, double *
	rcondv, double *work, int *lwork, int *iwork, logical * 	
	bwork, int *info);

/* Subroutine */ int dggglm_(int *n, int *m, int *p, double *
	a, int *lda, double *b, int *ldb, double *d__, 
	double *x, double *y, double *work, int *lwork, 
	int *info);

/* Subroutine */ int dgghrd_(char *compq, char *compz, int *n, int *
	ilo, int *ihi, double *a, int *lda, double *b, 
	int *ldb, double *q, int *ldq, double *z__, int *
	ldz, int *info);

/* Subroutine */ int dgglse_(int *m, int *n, int *p, double *
	a, int *lda, double *b, int *ldb, double *c__, 
	double *d__, double *x, double *work, int *lwork, 
	int *info);

/* Subroutine */ int dggqrf_(int *n, int *m, int *p, double *
	a, int *lda, double *taua, double *b, int *ldb, 
	double *taub, double *work, int *lwork, int *info);

/* Subroutine */ int dggrqf_(int *m, int *p, int *n, double *
	a, int *lda, double *taua, double *b, int *ldb, 
	double *taub, double *work, int *lwork, int *info);

/* Subroutine */ int dggsvd_(char *jobu, char *jobv, char *jobq, int *m, 
	int *n, int *p, int *k, int *l, double *a, 
	int *lda, double *b, int *ldb, double *alpha, 
	double *beta, double *u, int *ldu, double *v, int 
	*ldv, double *q, int *ldq, double *work, int *iwork, 
	int *info);

/* Subroutine */ int dggsvp_(char *jobu, char *jobv, char *jobq, int *m, 
	int *p, int *n, double *a, int *lda, double *b, 
	int *ldb, double *tola, double *tolb, int *k, int 
	*l, double *u, int *ldu, double *v, int *ldv, 
	double *q, int *ldq, int *iwork, double *tau, 
	double *work, int *info);

/* Subroutine */ int dgtcon_(char *norm, int *n, double *dl, 
	double *d__, double *du, double *du2, int *ipiv, 
	double *anorm, double *rcond, double *work, int *
	iwork, int *info);

/* Subroutine */ int dgtrfs_(char *trans, int *n, int *nrhs, 
	double *dl, double *d__, double *du, double *dlf, 
	double *df, double *duf, double *du2, int *ipiv, 
	double *b, int *ldb, double *x, int *ldx, double *
	ferr, double *berr, double *work, int *iwork, int *
	info);

/* Subroutine */ int dgtsv_(int *n, int *nrhs, double *dl, 
	double *d__, double *du, double *b, int *ldb, int 
	*info);

/* Subroutine */ int dgtsvx_(char *fact, char *trans, int *n, int *
	nrhs, double *dl, double *d__, double *du, double *
	dlf, double *df, double *duf, double *du2, int *ipiv, 
	double *b, int *ldb, double *x, int *ldx, double *
	rcond, double *ferr, double *berr, double *work, int *
	iwork, int *info);

/* Subroutine */ int dgttrf_(int *n, double *dl, double *d__, 
	double *du, double *du2, int *ipiv, int *info);

/* Subroutine */ int dgttrs_(char *trans, int *n, int *nrhs, 
	double *dl, double *d__, double *du, double *du2,  	
	int *ipiv, double *b, int *ldb, int *info);

/* Subroutine */ int dgtts2_(int *itrans, int *n, int *nrhs, 
	double *dl, double *d__, double *du, double *du2, 
	int *ipiv, double *b, int *ldb);

/* Subroutine */ int dhgeqz_(char *job, char *compq, char *compz, int *n, 
	int *ilo, int *ihi, double *h__, int *ldh, double 
	*t, int *ldt, double *alphar, double *alphai, double *
	beta, double *q, int *ldq, double *z__, int *ldz, 
	double *work, int *lwork, int *info);

/* Subroutine */ int dhsein_(char *side, char *eigsrc, char *initv, logical *
	select, int *n, double *h__, int *ldh, double *wr, 
	double *wi, double *vl, int *ldvl, double *vr, 
	int *ldvr, int *mm, int *m, double *work, int *
	ifaill, int *ifailr, int *info);

/* Subroutine */ int dhseqr_(char *job, char *compz, int *n, int *ilo,
	 int *ihi, double *h__, int *ldh, double *wr, 
	double *wi, double *z__, int *ldz, double *work, 
	int *lwork, int *info);

/* Subroutine */ int dlabad_(double *small, double *large);

/* Subroutine */ int dlabrd_(int *m, int *n, int *nb, double *
	a, int *lda, double *d__, double *e, double *tauq, 
	double *taup, double *x, int *ldx, double *y, int 
	*ldy);

/* Subroutine */ int dlacn2_(int *n, double *v, double *x, 
	int *isgn, double *est, int *kase, int *isave);

/* Subroutine */ int dlacon_(int *n, double *v, double *x, 
	int *isgn, double *est, int *kase);

/* Subroutine */ int dlacpy_(char *uplo, int *m, int *n, double *
	a, int *lda, double *b, int *ldb);

/* Subroutine */ int dladiv_(double *a, double *b, double *c__, 
	double *d__, double *p, double *q);

/* Subroutine */ int dlae2_(double *a, double *b, double *c__, 
	double *rt1, double *rt2);

/* Subroutine */ int dlaebz_(int *ijob, int *nitmax, int *n, 
	int *mmax, int *minp, int *nbmin, double *abstol, 
	double *reltol, double *pivmin, double *d__, double *
	e, double *e2, int *nval, double *ab, double *c__, 
	int *mout, int *nab, double *work, int *iwork, 
	int *info);

/* Subroutine */ int dlaed0_(int *icompq, int *qsiz, int *n, 
	double *d__, double *e, double *q, int *ldq, 
	double *qstore, int *ldqs, double *work, int *iwork, 
	int *info);

/* Subroutine */ int dlaed1_(int *n, double *d__, double *q, 
	int *ldq, int *indxq, double *rho, int *cutpnt, 
	double *work, int *iwork, int *info);

/* Subroutine */ int dlaed2_(int *k, int *n, int *n1, double *
	d__, double *q, int *ldq, int *indxq, double *rho, 
	double *z__, double *dlamda, double *w, double *q2, 
	int *indx, int *indxc, int *indxp, int *coltyp, 
	int *info);

/* Subroutine */ int dlaed3_(int *k, int *n, int *n1, double *
	d__, double *q, int *ldq, double *rho, double *dlamda,
	 double *q2, int *indx, int *ctot, double *w, 
	double *s, int *info);

/* Subroutine */ int dlaed4_(int *n, int *i__, double *d__, 
	double *z__, double *delta, double *rho, double *dlam,
	 int *info);

/* Subroutine */ int dlaed5_(int *i__, double *d__, double *z__, 
	double *delta, double *rho, double *dlam);

/* Subroutine */ int dlaed6_(int *kniter, logical *orgati, double *
	rho, double *d__, double *z__, double *finit, double *
	tau, int *info);

/* Subroutine */ int dlaed7_(int *icompq, int *n, int *qsiz, 
	int *tlvls, int *curlvl, int *curpbm, double *d__, 
	double *q, int *ldq, int *indxq, double *rho, int 
	*cutpnt, double *qstore, int *qptr, int *prmptr, int *
	perm, int *givptr, int *givcol, double *givnum, 
	double *work, int *iwork, int *info);

/* Subroutine */ int dlaed8_(int *icompq, int *k, int *n, int 
	*qsiz, double *d__, double *q, int *ldq, int *indxq, 
	double *rho, int *cutpnt, double *z__, double *dlamda,
	 double *q2, int *ldq2, double *w, int *perm, int 
	*givptr, int *givcol, double *givnum, int *indxp, int 
	*indx, int *info);

/* Subroutine */ int dlaed9_(int *k, int *kstart, int *kstop, 
	int *n, double *d__, double *q, int *ldq, double *
	rho, double *dlamda, double *w, double *s, int *lds, 
	int *info);

/* Subroutine */ int dlaeda_(int *n, int *tlvls, int *curlvl, 
	int *curpbm, int *prmptr, int *perm, int *givptr, 
	int *givcol, double *givnum, double *q, int *qptr, 
	double *z__, double *ztemp, int *info);

/* Subroutine */ int dlaein_(logical *rightv, logical *noinit, int *n, 
	double *h__, int *ldh, double *wr, double *wi, 
	double *vr, double *vi, double *b, int *ldb, 
	double *work, double *eps3, double *smlnum, double *
	bignum, int *info);

/* Subroutine */ int dlaev2_(double *a, double *b, double *c__, 
	double *rt1, double *rt2, double *cs1, double *sn1);

/* Subroutine */ int dlaexc_(logical *wantq, int *n, double *t, 
	int *ldt, double *q, int *ldq, int *j1, int *n1, 
	int *n2, double *work, int *info);

/* Subroutine */ int dlag2_(double *a, int *lda, double *b, 
	int *ldb, double *safmin, double *scale1, double *
	scale2, double *wr1, double *wr2, double *wi);

/* Subroutine */ int dlag2s_(int *m, int *n, double *a, int *
	lda, real *sa, int *ldsa, int *info);

/* Subroutine */ int dlags2_(logical *upper, double *a1, double *a2, 
	double *a3, double *b1, double *b2, double *b3, 
	double *csu, double *snu, double *csv, double *snv, 
	double *csq, double *snq);

/* Subroutine */ int dlagtf_(int *n, double *a, double *lambda, 
	double *b, double *c__, double *tol, double *d__, 
	int *in, int *info);

/* Subroutine */ int dlagtm_(char *trans, int *n, int *nrhs, 
	double *alpha, double *dl, double *d__, double *du, 
	double *x, int *ldx, double *beta, double *b, int 
	*ldb);

/* Subroutine */ int dlagts_(int *job, int *n, double *a, 
	double *b, double *c__, double *d__, int *in, 
	double *y, double *tol, int *info);

/* Subroutine */ int dlagv2_(double *a, int *lda, double *b, 
	int *ldb, double *alphar, double *alphai, double *
	beta, double *csl, double *snl, double *csr, double *
	snr);

/* Subroutine */ int dlahqr_(logical *wantt, logical *wantz, int *n, 
	int *ilo, int *ihi, double *h__, int *ldh, double 
	*wr, double *wi, int *iloz, int *ihiz, double *z__, 
	int *ldz, int *info);

/* Subroutine */ int dlahr2_(int *n, int *k, int *nb, double *
	a, int *lda, double *tau, double *t, int *ldt, 
	double *y, int *ldy);

/* Subroutine */ int dlahrd_(int *n, int *k, int *nb, double *
	a, int *lda, double *tau, double *t, int *ldt, 
	double *y, int *ldy);

/* Subroutine */ int dlaic1_(int *job, int *j, double *x, 
	double *sest, double *w, double *gamma, double *
	sestpr, double *s, double *c__);

/* Subroutine */ int dlaln2_(logical *ltrans, int *na, int *nw, 
	double *smin, double *ca, double *a, int *lda, 
	double *d1, double *d2, double *b, int *ldb, 
	double *wr, double *wi, double *x, int *ldx, 
	double *scale, double *xnorm, int *info);

/* Subroutine */ int dlals0_(int *icompq, int *nl, int *nr, 
	int *sqre, int *nrhs, double *b, int *ldb, double 
	*bx, int *ldbx, int *perm, int *givptr, int *givcol, 
	int *ldgcol, double *givnum, int *ldgnum, double *
	poles, double *difl, double *difr, double *z__, int *
	k, double *c__, double *s, double *work, int *info);

/* Subroutine */ int dlalsa_(int *icompq, int *smlsiz, int *n, 
	int *nrhs, double *b, int *ldb, double *bx, int *
	ldbx, double *u, int *ldu, double *vt, int *k, 
	double *difl, double *difr, double *z__, double *
	poles, int *givptr, int *givcol, int *ldgcol, int *
	perm, double *givnum, double *c__, double *s, double *
	work, int *iwork, int *info);

/* Subroutine */ int dlalsd_(char *uplo, int *smlsiz, int *n, int 
	*nrhs, double *d__, double *e, double *b, int *ldb, 
	double *rcond, int *rank, double *work, int *iwork, 
	int *info);

/* Subroutine */ int dlamrg_(int *n1, int *n2, double *a, int 
	*dtrd1, int *dtrd2, int *index);

/* Subroutine */ int dlanv2_(double *a, double *b, double *c__, 
	double *d__, double *rt1r, double *rt1i, double *rt2r,
	 double *rt2i, double *cs, double *sn);

/* Subroutine */ int dlapll_(int *n, double *x, int *incx, 
	double *y, int *incy, double *ssmin);

/* Subroutine */ int dlapmt_(logical *forwrd, int *m, int *n, 
	double *x, int *ldx, int *k);

/* Subroutine */ int dlaqgb_(int *m, int *n, int *kl, int *ku,
	 double *ab, int *ldab, double *r__, double *c__, 
	double *rowcnd, double *colcnd, double *amax, char *equed);

/* Subroutine */ int dlaqge_(int *m, int *n, double *a, int *
	lda, double *r__, double *c__, double *rowcnd, double 
	*colcnd, double *amax, char *equed);

/* Subroutine */ int dlaqp2_(int *m, int *n, int *offset, 
	double *a, int *lda, int *jpvt, double *tau, 
	double *vn1, double *vn2, double *work);

/* Subroutine */ int dlaqps_(int *m, int *n, int *offset, int 
	*nb, int *kb, double *a, int *lda, int *jpvt, 
	double *tau, double *vn1, double *vn2, double *auxv, 
	double *f, int *ldf);

/* Subroutine */ int dlaqr0_(logical *wantt, logical *wantz, int *n, 
	int *ilo, int *ihi, double *h__, int *ldh, double 
	*wr, double *wi, int *iloz, int *ihiz, double *z__, 
	int *ldz, double *work, int *lwork, int *info);

/* Subroutine */ int dlaqr1_(int *n, double *h__, int *ldh, 
	double *sr1, double *si1, double *sr2, double *si2, 
	double *v);

/* Subroutine */ int dlaqr2_(logical *wantt, logical *wantz, int *n, 
	int *ktop, int *kbot, int *nw, double *h__, int *
	ldh, int *iloz, int *ihiz, double *z__, int *ldz, 
	int *ns, int *nd, double *sr, double *si, double *
	v, int *ldv, int *nh, double *t, int *ldt, int *
	nv, double *wv, int *ldwv, double *work, int *lwork);

/* Subroutine */ int dlaqr3_(logical *wantt, logical *wantz, int *n, 
	int *ktop, int *kbot, int *nw, double *h__, int *
	ldh, int *iloz, int *ihiz, double *z__, int *ldz, 
	int *ns, int *nd, double *sr, double *si, double *
	v, int *ldv, int *nh, double *t, int *ldt, int *
	nv, double *wv, int *ldwv, double *work, int *lwork);

/* Subroutine */ int dlaqr4_(logical *wantt, logical *wantz, int *n, 
	int *ilo, int *ihi, double *h__, int *ldh, double 
	*wr, double *wi, int *iloz, int *ihiz, double *z__, 
	int *ldz, double *work, int *lwork, int *info);

/* Subroutine */ int dlaqr5_(logical *wantt, logical *wantz, int *kacc22, 
	int *n, int *ktop, int *kbot, int *nshfts, double 
	*sr, double *si, double *h__, int *ldh, int *iloz, 
	int *ihiz, double *z__, int *ldz, double *v, int *
	ldv, double *u, int *ldu, int *nv, double *wv, 
	int *ldwv, int *nh, double *wh, int *ldwh);

/* Subroutine */ int dlaqsb_(char *uplo, int *n, int *kd, double *
	ab, int *ldab, double *s, double *scond, double *amax,
	 char *equed);

/* Subroutine */ int dlaqsp_(char *uplo, int *n, double *ap, 
	double *s, double *scond, double *amax, char *equed);

/* Subroutine */ int dlaqsy_(char *uplo, int *n, double *a, int *
	lda, double *s, double *scond, double *amax, char *equed);

/* Subroutine */ int dlaqtr_(logical *ltran, logical *lreal, int *n, 
	double *t, int *ldt, double *b, double *w, double 
	*scale, double *x, double *work, int *info);

/* Subroutine */ int dlar1v_(int *n, int *b1, int *bn, double 
	*lambda, double *d__, double *l, double *ld, double *
	lld, double *pivmin, double *gaptol, double *z__, logical 
	*wantnc, int *negcnt, double *ztz, double *mingma, 
	int *r__, int *isuppz, double *nrminv, double *resid, 
	double *rqcorr, double *work);

/* Subroutine */ int dlar2v_(int *n, double *x, double *y, 
	double *z__, int *incx, double *c__, double *s, 
	int *incc);

/* Subroutine */ int dlarf_(char *side, int *m, int *n, double *v,
	 int *incv, double *tau, double *c__, int *ldc, 
	double *work);

/* Subroutine */ int dlarfb_(char *side, char *trans, char *direct, char *
	storev, int *m, int *n, int *k, double *v, int *
	ldv, double *t, int *ldt, double *c__, int *ldc, 
	double *work, int *ldwork);

/* Subroutine */ int dlarfg_(int *n, double *alpha, double *x, 
	int *incx, double *tau);

/* Subroutine */ int dlarft_(char *direct, char *storev, int *n, int *
	k, double *v, int *ldv, double *tau, double *t, 
	int *ldt);

/* Subroutine */ int dlarfx_(char *side, int *m, int *n, double *
	v, double *tau, double *c__, int *ldc, double *work);

/* Subroutine */ int dlargv_(int *n, double *x, int *incx, 
	double *y, int *incy, double *c__, int *incc);

/* Subroutine */ int dlarnv_(int *idist, int *iseed, int *n, 
	double *x);

/* Subroutine */ int dlarra_(int *n, double *d__, double *e, 
	double *e2, double *spltol, double *tnrm, int *nsplit,
	 int *isplit, int *info);

/* Subroutine */ int dlarrb_(int *n, double *d__, double *lld, 
	int *ifirst, int *ilast, double *rtol1, double *rtol2,
	 int *offset, double *w, double *wgap, double *werr, 
	double *work, int *iwork, double *pivmin, double *
	spdiam, int *twist, int *info);

/* Subroutine */ int dlarrc_(char *jobt, int *n, double *vl, 
	double *vu, double *d__, double *e, double *pivmin, 
	int *eigcnt, int *lcnt, int *rcnt, int *info);

/* Subroutine */ int dlarrd_(char *range, char *order, int *n, double 
	*vl, double *vu, int *il, int *iu, double *gers, 
	double *reltol, double *d__, double *e, double *e2, 
	double *pivmin, int *nsplit, int *isplit, int *m, 
	double *w, double *werr, double *wl, double *wu, 
	int *iblock, int *indexw, double *work, int *iwork, 
	int *info);

/* Subroutine */ int dlarre_(char *range, int *n, double *vl, 
	double *vu, int *il, int *iu, double *d__, double 
	*e, double *e2, double *rtol1, double *rtol2, double *
	spltol, int *nsplit, int *isplit, int *m, double *w, 
	double *werr, double *wgap, int *iblock, int *indexw, 
	double *gers, double *pivmin, double *work, int *
	iwork, int *info);

/* Subroutine */ int dlarrf_(int *n, double *d__, double *l, 
	double *ld, int *clstrt, int *clend, double *w, 
	double *wgap, double *werr, double *spdiam, double *
	clgapl, double *clgapr, double *pivmin, double *sigma, 
	double *dplus, double *lplus, double *work, int *info);

/* Subroutine */ int dlarrj_(int *n, double *d__, double *e2, 
	int *ifirst, int *ilast, double *rtol, int *offset, 
	double *w, double *werr, double *work, int *iwork, 
	double *pivmin, double *spdiam, int *info);

/* Subroutine */ int dlarrk_(int *n, int *iw, double *gl, 
	double *gu, double *d__, double *e2, double *pivmin, 
	double *reltol, double *w, double *werr, int *info);

/* Subroutine */ int dlarrr_(int *n, double *d__, double *e, 
	int *info);

/* Subroutine */ int dlarrv_(int *n, double *vl, double *vu, 
	double *d__, double *l, double *pivmin, int *isplit, 
	int *m, int *dol, int *dou, double *minrgp, 
	double *rtol1, double *rtol2, double *w, double *werr,
	 double *wgap, int *iblock, int *indexw, double *gers,
	 double *z__, int *ldz, int *isuppz, double *work, 
	int *iwork, int *info);

/* Subroutine */ int dlartg_(double *f, double *g, double *cs, 
	double *sn, double *r__);

/* Subroutine */ int dlartv_(int *n, double *x, int *incx, 
	double *y, int *incy, double *c__, double *s, int 
	*incc);

/* Subroutine */ int dlaruv_(int *iseed, int *n, double *x);

/* Subroutine */ int dlarz_(char *side, int *m, int *n, int *l, 
	double *v, int *incv, double *tau, double *c__, 
	int *ldc, double *work);

/* Subroutine */ int dlarzb_(char *side, char *trans, char *direct, char *
	storev, int *m, int *n, int *k, int *l, double *v,
	 int *ldv, double *t, int *ldt, double *c__, int *
	ldc, double *work, int *ldwork  	);

/* Subroutine */ int dlarzt_(char *direct, char *storev, int *n, int *
	k, double *v, int *ldv, double *tau, double *t, 
	int *ldt);

/* Subroutine */ int dlas2_(double *f, double *g, double *h__, 
	double *ssmin, double *ssmax);

/* Subroutine */ int dlascl_(char *type__, int *kl, int *ku, 
	double *cfrom, double *cto, int *m, int *n, 
	double *a, int *lda, int *info);

/* Subroutine */ int dlasd0_(int *n, int *sqre, double *d__, 
	double *e, double *u, int *ldu, double *vt, int *
	ldvt, int *smlsiz, int *iwork, double *work, int *
	info);

/* Subroutine */ int dlasd1_(int *nl, int *nr, int *sqre, 
	double *d__, double *alpha, double *beta, double *u, 
	int *ldu, double *vt, int *ldvt, int *idxq, int *
	iwork, double *work, int *info);

/* Subroutine */ int dlasd2_(int *nl, int *nr, int *sqre, int 
	*k, double *d__, double *z__, double *alpha, double *
	beta, double *u, int *ldu, double *vt, int *ldvt, 
	double *dsigma, double *u2, int *ldu2, double *vt2, 
	int *ldvt2, int *idxp, int *idx, int *idxc, int *
	idxq, int *coltyp, int *info);

/* Subroutine */ int dlasd3_(int *nl, int *nr, int *sqre, int 
	*k, double *d__, double *q, int *ldq, double *dsigma, 
	double *u, int *ldu, double *u2, int *ldu2, 
	double *vt, int *ldvt, double *vt2, int *ldvt2, 
	int *idxc, int *ctot, double *z__, int *info);

/* Subroutine */ int dlasd4_(int *n, int *i__, double *d__, 
	double *z__, double *delta, double *rho, double *
	sigma, double *work, int *info);

/* Subroutine */ int dlasd5_(int *i__, double *d__, double *z__, 
	double *delta, double *rho, double *dsigma, double *
	work);

/* Subroutine */ int dlasd6_(int *icompq, int *nl, int *nr, 
	int *sqre, double *d__, double *vf, double *vl, 
	double *alpha, double *beta, int *idxq, int *perm, 
	int *givptr, int *givcol, int *ldgcol, double *givnum,
	 int *ldgnum, double *poles, double *difl, double *
	difr, double *z__, int *k, double *c__, double *s, 
	double *work, int *iwork, int *info);

/* Subroutine */ int dlasd7_(int *icompq, int *nl, int *nr, 
	int *sqre, int *k, double *d__, double *z__, 
	double *zw, double *vf, double *vfw, double *vl, 
	double *vlw, double *alpha, double *beta, double *
	dsigma, int *idx, int *idxp, int *idxq, int *perm, 
	int *givptr, int *givcol, int *ldgcol, double *givnum,
	 int *ldgnum, double *c__, double *s, int *info);

/* Subroutine */ int dlasd8_(int *icompq, int *k, double *d__, 
	double *z__, double *vf, double *vl, double *difl, 
	double *difr, int *lddifr, double *dsigma, double *
	work, int *info);

/* Subroutine */ int dlasda_(int *icompq, int *smlsiz, int *n, 
	int *sqre, double *d__, double *e, double *u, int 
	*ldu, double *vt, int *k, double *difl, double *difr, 
	double *z__, double *poles, int *givptr, int *givcol, 
	int *ldgcol, int *perm, double *givnum, double *c__, 
	double *s, double *work, int *iwork, int *info);

/* Subroutine */ int dlasdq_(char *uplo, int *sqre, int *n, int *
	ncvt, int *nru, int *ncc, double *d__, double *e, 
	double *vt, int *ldvt, double *u, int *ldu, 
	double *c__, int *ldc, double *work, int *info);

/* Subroutine */ int dlasdt_(int *n, int *lvl, int *nd, int *
	inode, int *ndiml, int *ndimr, int *msub);

/* Subroutine */ int dlaset_(char *uplo, int *m, int *n, double *
	alpha, double *beta, double *a, int *lda);

/* Subroutine */ int dlasq1_(int *n, double *d__, double *e, 
	double *work, int *info);

/* Subroutine */ int dlasq2_(int *n, double *z__, int *info);

/* Subroutine */ int dlasq3_(int *i0, int *n0, double *z__, 
	int *pp, double *dmin__, double *sigma, double *desig,
	 double *qmax, int *nfail, int *iter, int *ndiv, 
	logical *ieee);

/* Subroutine */ int dlasq4_(int *i0, int *n0, double *z__, 
	int *pp, int *n0in, double *dmin__, double *dmin1, 
	double *dmin2, double *dn, double *dn1, double *dn2, 
	double *tau, int *ttype);

/* Subroutine */ int dlasq5_(int *i0, int *n0, double *z__, 
	int *pp, double *tau, double *dmin__, double *dmin1, 
	double *dmin2, double *dn, double *dnm1, double *dnm2,
	 logical *ieee);

/* Subroutine */ int dlasq6_(int *i0, int *n0, double *z__, 
	int *pp, double *dmin__, double *dmin1, double *dmin2,
	 double *dn, double *dnm1, double *dnm2);

/* Subroutine */ int dlasr_(char *side, char *pivot, char *direct, int *m,
	 int *n, double *c__, double *s, double *a, int *
	lda);

/* Subroutine */ int dlasrt_(char *id, int *n, double *d__, int *
	info);

/* Subroutine */ int dlassq_(int *n, double *x, int *incx, 
	double *scale, double *sumsq);

/* Subroutine */ int dlasv2_(double *f, double *g, double *h__, 
	double *ssmin, double *ssmax, double *snr, double *
	csr, double *snl, double *csl);

/* Subroutine */ int dlaswp_(int *n, double *a, int *lda, int 
	*k1, int *k2, int *ipiv, int *incx);

/* Subroutine */ int dlasy2_(logical *ltranl, logical *ltranr, int *isgn, 
	int *n1, int *n2, double *tl, int *ldtl, double *
	tr, int *ldtr, double *b, int *ldb, double *scale, 
	double *x, int *ldx, double *xnorm, int *info);

/* Subroutine */ int dlasyf_(char *uplo, int *n, int *nb, int *kb,
	 double *a, int *lda, int *ipiv, double *w, int *
	ldw, int *info);

/* Subroutine */ int dlatbs_(char *uplo, char *trans, char *diag, char *
	normin, int *n, int *kd, double *ab, int *ldab, 
	double *x, double *scale, double *cnorm, int *info);

/* Subroutine */ int dlatdf_(int *ijob, int *n, double *z__, 
	int *ldz, double *rhs, double *rdsum, double *rdscal, 
	int *ipiv, int *jpiv);

/* Subroutine */ int dlatps_(char *uplo, char *trans, char *diag, char *
	normin, int *n, double *ap, double *x, double *scale, 
	double *cnorm, int *info);

/* Subroutine */ int dlatrd_(char *uplo, int *n, int *nb, double *
	a, int *lda, double *e, double *tau, double *w, 
	int *ldw);

/* Subroutine */ int dlatrs_(char *uplo, char *trans, char *diag, char *
	normin, int *n, double *a, int *lda, double *x, 
	double *scale, double *cnorm, int *info);

/* Subroutine */ int dlatrz_(int *m, int *n, int *l, double *
	a, int *lda, double *tau, double *work);

/* Subroutine */ int dlatzm_(char *side, int *m, int *n, double *
	v, int *incv, double *tau, double *c1, double *c2, 
	int *ldc, double *work);

/* Subroutine */ int dlauu2_(char *uplo, int *n, double *a, int *
	lda, int *info);

/* Subroutine */ int dlauum_(char *uplo, int *n, double *a, int *
	lda, int *info);

/* Subroutine */ int dlazq3_(int *i0, int *n0, double *z__, 
	int *pp, double *dmin__, double *sigma, double *desig,
	 double *qmax, int *nfail, int *iter, int *ndiv, 
	logical *ieee, int *ttype, double *dmin1, double *dmin2, 
	double *dn, double *dn1, double *dn2, double *tau);

/* Subroutine */ int dlazq4_(int *i0, int *n0, double *z__, 
	int *pp, int *n0in, double *dmin__, double *dmin1, 
	double *dmin2, double *dn, double *dn1, double *dn2, 
	double *tau, int *ttype, double *g);

/* Subroutine */ int dopgtr_(char *uplo, int *n, double *ap, 
	double *tau, double *q, int *ldq, double *work, 
	int *info);

/* Subroutine */ int dopmtr_(char *side, char *uplo, char *trans, int *m, 
	int *n, double *ap, double *tau, double *c__, int 
	*ldc, double *work, int *info);

/* Subroutine */ int dorg2l_(int *m, int *n, int *k, double *
	a, int *lda, double *tau, double *work, int *info);

/* Subroutine */ int dorg2r_(int *m, int *n, int *k, double *
	a, int *lda, double *tau, double *work, int *info);


/* Subroutine */ int dorghr_(int *n, int *ilo, int *ihi, 
	double *a, int *lda, double *tau, double *work, 
	int *lwork, int *info);

/* Subroutine */ int dorgl2_(int *m, int *n, int *k, double *
	a, int *lda, double *tau, double *work, int *info);

/* Subroutine */ int dorglq_(int *m, int *n, int *k, double *
	a, int *lda, double *tau, double *work, int *lwork, 
	int *info);

/* Subroutine */ int dorgql_(int *m, int *n, int *k, double *
	a, int *lda, double *tau, double *work, int *lwork, 
	int *info);

/* Subroutine */ int dorgqr_(int *m, int *n, int *k, double *
	a, int *lda, double *tau, double *work, int *lwork, 
	int *info);

/* Subroutine */ int dorgr2_(int *m, int *n, int *k, double *
	a, int *lda, double *tau, double *work, int *info);

/* Subroutine */ int dorgrq_(int *m, int *n, int *k, double *
	a, int *lda, double *tau, double *work, int *lwork, 
	int *info);

/* Subroutine */ int dorgtr_(char *uplo, int *n, double *a, int *
	lda, double *tau, double *work, int *lwork, int *info);

/* Subroutine */ int dorm2l_(char *side, char *trans, int *m, int *n, 
	int *k, double *a, int *lda, double *tau, double *
	c__, int *ldc, double *work, int *info);

/* Subroutine */ int dorm2r_(char *side, char *trans, int *m, int *n, 
	int *k, double *a, int *lda, double *tau, double *
	c__, int *ldc, double *work, int *info);


/* Subroutine */ int dormhr_(char *side, char *trans, int *m, int *n, 
	int *ilo, int *ihi, double *a, int *lda, double *
	tau, double *c__, int *ldc, double *work, int *lwork, 
	int *info);

/* Subroutine */ int dorml2_(char *side, char *trans, int *m, int *n, 
	int *k, double *a, int *lda, double *tau, double *
	c__, int *ldc, double *work, int *info);

/* Subroutine */ int dormlq_(char *side, char *trans, int *m, int *n, 
	int *k, double *a, int *lda, double *tau, double *
	c__, int *ldc, double *work, int *lwork, int *info);

/* Subroutine */ int dormql_(char *side, char *trans, int *m, int *n, 
	int *k, double *a, int *lda, double *tau, double *
	c__, int *ldc, double *work, int *lwork, int *info);

/* Subroutine */ int dormqr_(char *side, char *trans, int *m, int *n, 
	int *k, double *a, int *lda, double *tau, double *
	c__, int *ldc, double *work, int *lwork, int *info);

/* Subroutine */ int dormr2_(char *side, char *trans, int *m, int *n, 
	int *k, double *a, int *lda, double *tau, double *
	c__, int *ldc, double *work, int *info);

/* Subroutine */ int dormr3_(char *side, char *trans, int *m, int *n, 
	int *k, int *l, double *a, int *lda, double *tau, 
	double *c__, int *ldc, double *work, int *info);

/* Subroutine */ int dormrq_(char *side, char *trans, int *m, int *n, 
	int *k, double *a, int *lda, double *tau, double *
	c__, int *ldc, double *work, int *lwork, int *info);

/* Subroutine */ int dormrz_(char *side, char *trans, int *m, int *n, 
	int *k, int *l, double *a, int *lda, double *tau, 
	double *c__, int *ldc, double *work, int *lwork, 
	int *info);

/* Subroutine */ int dormtr_(char *side, char *uplo, char *trans, int *m, 
	int *n, double *a, int *lda, double *tau, double *
	c__, int *ldc, double *work, int *lwork, int *info);

/* Subroutine */ int dpbcon_(char *uplo, int *n, int *kd, double *
	ab, int *ldab, double *anorm, double *rcond, double *
	work, int *iwork, int *info);

/* Subroutine */ int dpbequ_(char *uplo, int *n, int *kd, double *
	ab, int *ldab, double *s, double *scond, double *amax,
	 int *info);

/* Subroutine */ int dpbrfs_(char *uplo, int *n, int *kd, int *
	nrhs, double *ab, int *ldab, double *afb, int *ldafb, 
	double *b, int *ldb, double *x, int *ldx, double *
	ferr, double *berr, double *work, int *iwork, int *
	info);

/* Subroutine */ int dpbstf_(char *uplo, int *n, int *kd, double *
	ab, int *ldab, int *info);

/* Subroutine */ int dpbsv_(char *uplo, int *n, int *kd, int *
	nrhs, double *ab, int *ldab, double *b, int *ldb, 
	int *info);

/* Subroutine */ int dpbsvx_(char *fact, char *uplo, int *n, int *kd, 
	int *nrhs, double *ab, int *ldab, double *afb, 
	int *ldafb, char *equed, double *s, double *b, int *
	ldb, double *x, int *ldx, double *rcond, double *ferr,
	 double *berr, double *work, int *iwork, int *info);

/* Subroutine */ int dpbtf2_(char *uplo, int *n, int *kd, double *
	ab, int *ldab, int *info);

/* Subroutine */ int dpbtrf_(char *uplo, int *n, int *kd, double *
	ab, int *ldab, int *info);

/* Subroutine */ int dpbtrs_(char *uplo, int *n, int *kd, int *
	nrhs, double *ab, int *ldab, double *b, int *ldb, 
	int *info);

/* Subroutine */ int dpocon_(char *uplo, int *n, double *a, int *
	lda, double *anorm, double *rcond, double *work, int *
	iwork, int *info);

/* Subroutine */ int dpoequ_(int *n, double *a, int *lda, 
	double *s, double *scond, double *amax, int *info);

/* Subroutine */ int dporfs_(char *uplo, int *n, int *nrhs, 
	double *a, int *lda, double *af, int *ldaf, 
	double *b, int *ldb, double *x, int *ldx, double *
	ferr, double *berr, double *work, int *iwork, int *
	info);

/* Subroutine */ int dposv_(char *uplo, int *n, int *nrhs, double 
	*a, int *lda, double *b, int *ldb, int *info);

/* Subroutine */ int dposvx_(char *fact, char *uplo, int *n, int *
	nrhs, double *a, int *lda, double *af, int *ldaf, 
	char *equed, double *s, double *b, int *ldb, double *
	x, int *ldx, double *rcond, double *ferr, double *
	berr, double *work, int *iwork, int *info);

/* Subroutine */ int dpotf2_(char *uplo, int *n, double *a, int *
	lda, int *info);

/* Subroutine */ int dpotri_(char *uplo, int *n, double *a, int *
	lda, int *info);

/* Subroutine */ int dppcon_(char *uplo, int *n, double *ap, 
	double *anorm, double *rcond, double *work, int *
	iwork, int *info);

/* Subroutine */ int dppequ_(char *uplo, int *n, double *ap, 
	double *s, double *scond, double *amax, int *info);

/* Subroutine */ int dpprfs_(char *uplo, int *n, int *nrhs, 
	double *ap, double *afp, double *b, int *ldb, 
	double *x, int *ldx, double *ferr, double *berr, 
	double *work, int *iwork, int *info);

/* Subroutine */ int dppsv_(char *uplo, int *n, int *nrhs, double 
	*ap, double *b, int *ldb, int *info);

/* Subroutine */ int dppsvx_(char *fact, char *uplo, int *n, int *
	nrhs, double *ap, double *afp, char *equed, double *s, 
	double *b, int *ldb, double *x, int *ldx, double *
	rcond, double *ferr, double *berr, double *work, int *
	iwork, int *info);

/* Subroutine */ int dpptrf_(char *uplo, int *n, double *ap, int *
	info);

/* Subroutine */ int dpptri_(char *uplo, int *n, double *ap, int *
	info);

/* Subroutine */ int dpptrs_(char *uplo, int *n, int *nrhs, 
	double *ap, double *b, int *ldb, int *info);

/* Subroutine */ int dptcon_(int *n, double *d__, double *e, 
	double *anorm, double *rcond, double *work, int *info);

/* Subroutine */ int dpteqr_(char *compz, int *n, double *d__, 
	double *e, double *z__, int *ldz, double *work, 
	int *info);

/* Subroutine */ int dptrfs_(int *n, int *nrhs, double *d__, 
	double *e, double *df, double *ef, double *b, int 
	*ldb, double *x, int *ldx, double *ferr, double *berr,
	 double *work, int *info);

/* Subroutine */ int dptsv_(int *n, int *nrhs, double *d__, 
	double *e, double *b, int *ldb, int *info);

/* Subroutine */ int dptsvx_(char *fact, int *n, int *nrhs, 
	double *d__, double *e, double *df, double *ef, 
	double *b, int *ldb, double *x, int *ldx, double *
	rcond, double *ferr, double *berr, double *work, int *
	info);

/* Subroutine */ int dpttrf_(int *n, double *d__, double *e, 
	int *info);

/* Subroutine */ int dpttrs_(int *n, int *nrhs, double *d__, 
	double *e, double *b, int *ldb, int *info);

/* Subroutine */ int dptts2_(int *n, int *nrhs, double *d__, 
	double *e, double *b, int *ldb);

/* Subroutine */ int drscl_(int *n, double *sa, double *sx, 
	int *incx);

/* Subroutine */ int dsbev_(char *jobz, char *uplo, int *n, int *kd, 
	double *ab, int *ldab, double *w, double *z__, 
	int *ldz, double *work, int *info);

/* Subroutine */ int dsbevd_(char *jobz, char *uplo, int *n, int *kd, 
	double *ab, int *ldab, double *w, double *z__, 
	int *ldz, double *work, int *lwork, int *iwork, 
	int *liwork, int *info);

/* Subroutine */ int dsbevx_(char *jobz, char *range, char *uplo, int *n, 
	int *kd, double *ab, int *ldab, double *q, int *
	ldq, double *vl, double *vu, int *il, int *iu, 
	double *abstol, int *m, double *w, double *z__, 
	int *ldz, double *work, int *iwork, int *ifail, 
	int *info);

/* Subroutine */ int dsbgst_(char *vect, char *uplo, int *n, int *ka, 
	int *kb, double *ab, int *ldab, double *bb, int *
	ldbb, double *x, int *ldx, double *work, int *info);

/* Subroutine */ int dsbgv_(char *jobz, char *uplo, int *n, int *ka, 
	int *kb, double *ab, int *ldab, double *bb, int *
	ldbb, double *w, double *z__, int *ldz, double *work, 
	int *info);

/* Subroutine */ int dsbgvd_(char *jobz, char *uplo, int *n, int *ka, 
	int *kb, double *ab, int *ldab, double *bb, int *
	ldbb, double *w, double *z__, int *ldz, double *work, 
	int *lwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int dsbgvx_(char *jobz, char *range, char *uplo, int *n, 
	int *ka, int *kb, double *ab, int *ldab, double *
	bb, int *ldbb, double *q, int *ldq, double *vl, 
	double *vu, int *il, int *iu, double *abstol, int 
	*m, double *w, double *z__, int *ldz, double *work, 
	int *iwork, int *ifail, int *info);

/* Subroutine */ int dsbtrd_(char *vect, char *uplo, int *n, int *kd, 
	double *ab, int *ldab, double *d__, double *e, 
	double *q, int *ldq, double *work, int *info);

/* Subroutine */ int dsgesv_(int *n, int *nrhs, double *a, 
	int *lda, int *ipiv, double *b, int *ldb, double *
	x, int *ldx, double *work, real *swork, int *iter, 
	int *info);

/* Subroutine */ int dspcon_(char *uplo, int *n, double *ap, int *
	ipiv, double *anorm, double *rcond, double *work, int 
	*iwork, int *info);

/* Subroutine */ int dspev_(char *jobz, char *uplo, int *n, double *
	ap, double *w, double *z__, int *ldz, double *work, 
	int *info);

/* Subroutine */ int dspevd_(char *jobz, char *uplo, int *n, double *
	ap, double *w, double *z__, int *ldz, double *work, 
	int *lwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int dspevx_(char *jobz, char *range, char *uplo, int *n, 
	double *ap, double *vl, double *vu, int *il, int *
	iu, double *abstol, int *m, double *w, double *z__, 
	int *ldz, double *work, int *iwork, int *ifail, 
	int *info);

/* Subroutine */ int dspgst_(int *itype, char *uplo, int *n, 
	double *ap, double *bp, int *info);

/* Subroutine */ int dspgv_(int *itype, char *jobz, char *uplo, int *
	n, double *ap, double *bp, double *w, double *z__, 
	int *ldz, double *work, int *info);

/* Subroutine */ int dspgvd_(int *itype, char *jobz, char *uplo, int *
	n, double *ap, double *bp, double *w, double *z__, 
	int *ldz, double *work, int *lwork, int *iwork, 
	int *liwork, int *info);

/* Subroutine */ int dspgvx_(int *itype, char *jobz, char *range, char *
	uplo, int *n, double *ap, double *bp, double *vl, 
	double *vu, int *il, int *iu, double *abstol, int 
	*m, double *w, double *z__, int *ldz, double *work, 
	int *iwork, int *ifail, int *info);

/* Subroutine */ int dsprfs_(char *uplo, int *n, int *nrhs, 
	double *ap, double *afp, int *ipiv, double *b, 
	int *ldb, double *x, int *ldx, double *ferr, 
	double *berr, double *work, int *iwork, int *info);

/* Subroutine */ int dspsv_(char *uplo, int *n, int *nrhs, double 
	*ap, int *ipiv, double *b, int *ldb, int *info);

/* Subroutine */ int dspsvx_(char *fact, char *uplo, int *n, int *
	nrhs, double *ap, double *afp, int *ipiv, double *b, 
	int *ldb, double *x, int *ldx, double *rcond, 
	double *ferr, double *berr, double *work, int *iwork, 
	int *info);

/* Subroutine */ int dsptrd_(char *uplo, int *n, double *ap, 
	double *d__, double *e, double *tau, int *info);

/* Subroutine */ int dsptrf_(char *uplo, int *n, double *ap, int *
	ipiv, int *info);

/* Subroutine */ int dsptri_(char *uplo, int *n, double *ap, int *
	ipiv, double *work, int *info);

/* Subroutine */ int dsptrs_(char *uplo, int *n, int *nrhs, 
	double *ap, int *ipiv, double *b, int *ldb, int *
	info);

/* Subroutine */ int dstebz_(char *range, char *order, int *n, double 
	*vl, double *vu, int *il, int *iu, double *abstol, 
	double *d__, double *e, int *m, int *nsplit, 
	double *w, int *iblock, int *isplit, double *work, 
	int *iwork, int *info);

/* Subroutine */ int dstedc_(char *compz, int *n, double *d__, 
	double *e, double *z__, int *ldz, double *work, 
	int *lwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int dstegr_(char *jobz, char *range, int *n, double *
	d__, double *e, double *vl, double *vu, int *il, 
	int *iu, double *abstol, int *m, double *w, 
	double *z__, int *ldz, int *isuppz, double *work, 
	int *lwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int dstein_(int *n, double *d__, double *e, 
	int *m, double *w, int *iblock, int *isplit, 
	double *z__, int *ldz, double *work, int *iwork, 
	int *ifail, int *info);

/* Subroutine */ int dstemr_(char *jobz, char *range, int *n, double *
	d__, double *e, double *vl, double *vu, int *il, 
	int *iu, int *m, double *w, double *z__, int *ldz,
	 int *nzc, int *isuppz, logical *tryrac, double *work, 
	int *lwork, int *iwork, int *liwork, int *info);


/* Subroutine */ int dsterf_(int *n, double *d__, double *e, 
	int *info);

/* Subroutine */ int dstev_(char *jobz, int *n, double *d__, 
	double *e, double *z__, int *ldz, double *work, 
	int *info);

/* Subroutine */ int dstevd_(char *jobz, int *n, double *d__, 
	double *e, double *z__, int *ldz, double *work, 
	int *lwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int dstevr_(char *jobz, char *range, int *n, double *
	d__, double *e, double *vl, double *vu, int *il, 
	int *iu, double *abstol, int *m, double *w, 
	double *z__, int *ldz, int *isuppz, double *work, 
	int *lwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int dstevx_(char *jobz, char *range, int *n, double *
	d__, double *e, double *vl, double *vu, int *il, 
	int *iu, double *abstol, int *m, double *w, 
	double *z__, int *ldz, double *work, int *iwork, 
	int *ifail, int *info);

/* Subroutine */ int dsycon_(char *uplo, int *n, double *a, int *
	lda, int *ipiv, double *anorm, double *rcond, double *
	work, int *iwork, int *info);

/* Subroutine */ int dsyev_(char *jobz, char *uplo, int *n, double *a,
	 int *lda, double *w, double *work, int *lwork, 
	int *info);

/* Subroutine */ int dsyevd_(char *jobz, char *uplo, int *n, double *
	a, int *lda, double *w, double *work, int *lwork, 
	int *iwork, int *liwork, int *info);

/* Subroutine */ int dsyevr_(char *jobz, char *range, char *uplo, int *n, 
	double *a, int *lda, double *vl, double *vu, int *
	il, int *iu, double *abstol, int *m, double *w, 
	double *z__, int *ldz, int *isuppz, double *work, 
	int *lwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int dsyevx_(char *jobz, char *range, char *uplo, int *n, 
	double *a, int *lda, double *vl, double *vu, int *
	il, int *iu, double *abstol, int *m, double *w, 
	double *z__, int *ldz, double *work, int *lwork, 
	int *iwork, int *ifail, int *info);

/* Subroutine */ int dsygs2_(int *itype, char *uplo, int *n, 
	double *a, int *lda, double *b, int *ldb, int *
	info);

/* Subroutine */ int dsygst_(int *itype, char *uplo, int *n, 
	double *a, int *lda, double *b, int *ldb, int *
	info);

/* Subroutine */ int dsygv_(int *itype, char *jobz, char *uplo, int *
	n, double *a, int *lda, double *b, int *ldb, 
	double *w, double *work, int *lwork, int *info);

/* Subroutine */ int dsygvd_(int *itype, char *jobz, char *uplo, int *
	n, double *a, int *lda, double *b, int *ldb, 
	double *w, double *work, int *lwork, int *iwork, 
	int *liwork, int *info);

/* Subroutine */ int dsygvx_(int *itype, char *jobz, char *range, char *
	uplo, int *n, double *a, int *lda, double *b, int 
	*ldb, double *vl, double *vu, int *il, int *iu, 
	double *abstol, int *m, double *w, double *z__, 
	int *ldz, double *work, int *lwork, int *iwork, 
	int *ifail, int *info);

/* Subroutine */ int dsyrfs_(char *uplo, int *n, int *nrhs, 
	double *a, int *lda, double *af, int *ldaf, int *
	ipiv, double *b, int *ldb, double *x, int *ldx, 
	double *ferr, double *berr, double *work, int *iwork, 
	int *info);

/* Subroutine */ int dsysv_(char *uplo, int *n, int *nrhs, double 
	*a, int *lda, int *ipiv, double *b, int *ldb, 
	double *work, int *lwork, int *info);

/* Subroutine */ int dsysvx_(char *fact, char *uplo, int *n, int *
	nrhs, double *a, int *lda, double *af, int *ldaf, 
	int *ipiv, double *b, int *ldb, double *x, int *
	ldx, double *rcond, double *ferr, double *berr, 
	double *work, int *lwork, int *iwork, int *info);

/* Subroutine */ int dsytd2_(char *uplo, int *n, double *a, int *
	lda, double *d__, double *e, double *tau, int *info);

/* Subroutine */ int dsytf2_(char *uplo, int *n, double *a, int *
	lda, int *ipiv, int *info);

/* Subroutine */ int dsytrd_(char *uplo, int *n, double *a, int *
	lda, double *d__, double *e, double *tau, double *
	work, int *lwork, int *info);

/* Subroutine */ int dsytrf_(char *uplo, int *n, double *a, int *
	lda, int *ipiv, double *work, int *lwork, int *info);

/* Subroutine */ int dsytri_(char *uplo, int *n, double *a, int *
	lda, int *ipiv, double *work, int *info);

/* Subroutine */ int dsytrs_(char *uplo, int *n, int *nrhs, 
	double *a, int *lda, int *ipiv, double *b, int *
	ldb, int *info);

/* Subroutine */ int dtbcon_(char *norm, char *uplo, char *diag, int *n, 
	int *kd, double *ab, int *ldab, double *rcond, 
	double *work, int *iwork, int *info);

/* Subroutine */ int dtbrfs_(char *uplo, char *trans, char *diag, int *n, 
	int *kd, int *nrhs, double *ab, int *ldab, double 
	*b, int *ldb, double *x, int *ldx, double *ferr, 
	double *berr, double *work, int *iwork, int *info);

/* Subroutine */ int dtbtrs_(char *uplo, char *trans, char *diag, int *n, 
	int *kd, int *nrhs, double *ab, int *ldab, double 
	*b, int *ldb, int *info);

/* Subroutine */ int dtgevc_(char *side, char *howmny, logical *select, 
	int *n, double *s, int *lds, double *p, int *ldp, 
	double *vl, int *ldvl, double *vr, int *ldvr, int 
	*mm, int *m, double *work, int *info);

/* Subroutine */ int dtgex2_(logical *wantq, logical *wantz, int *n, 
	double *a, int *lda, double *b, int *ldb, double *
	q, int *ldq, double *z__, int *ldz, int *j1, int *
	n1, int *n2, double *work, int *lwork, int *info);

/* Subroutine */ int dtgexc_(logical *wantq, logical *wantz, int *n, 
	double *a, int *lda, double *b, int *ldb, double *
	q, int *ldq, double *z__, int *ldz, int *ifst, 
	int *ilst, double *work, int *lwork, int *info);

/* Subroutine */ int dtgsen_(int *ijob, logical *wantq, logical *wantz, 
	logical *select, int *n, double *a, int *lda, double *
	b, int *ldb, double *alphar, double *alphai, double *
	beta, double *q, int *ldq, double *z__, int *ldz, 
	int *m, double *pl, double *pr, double *dif, 
	double *work, int *lwork, int *iwork, int *liwork, 
	int *info);

/* Subroutine */ int dtgsja_(char *jobu, char *jobv, char *jobq, int *m, 
	int *p, int *n, int *k, int *l, double *a, 
	int *lda, double *b, int *ldb, double *tola, 
	double *tolb, double *alpha, double *beta, double *u, 
	int *ldu, double *v, int *ldv, double *q, int *
	ldq, double *work, int *ncycle, int *info);

/* Subroutine */ int dtgsna_(char *job, char *howmny, logical *select, 
	int *n, double *a, int *lda, double *b, int *ldb, 
	double *vl, int *ldvl, double *vr, int *ldvr, 
	double *s, double *dif, int *mm, int *m, double *
	work, int *lwork, int *iwork, int *info);

/* Subroutine */ int dtgsy2_(char *trans, int *ijob, int *m, int *
	n, double *a, int *lda, double *b, int *ldb, 
	double *c__, int *ldc, double *d__, int *ldd, 
	double *e, int *lde, double *f, int *ldf, double *
	scale, double *rdsum, double *rdscal, int *iwork, int 
	*pq, int *info);

/* Subroutine */ int dtgsyl_(char *trans, int *ijob, int *m, int *
	n, double *a, int *lda, double *b, int *ldb, 
	double *c__, int *ldc, double *d__, int *ldd, 
	double *e, int *lde, double *f, int *ldf, double *
	scale, double *dif, double *work, int *lwork, int *
	iwork, int *info);

/* Subroutine */ int dtpcon_(char *norm, char *uplo, char *diag, int *n, 
	double *ap, double *rcond, double *work, int *iwork, 
	int *info);

/* Subroutine */ int dtprfs_(char *uplo, char *trans, char *diag, int *n, 
	int *nrhs, double *ap, double *b, int *ldb, 
	double *x, int *ldx, double *ferr, double *berr, 
	double *work, int *iwork, int *info);

/* Subroutine */ int dtptri_(char *uplo, char *diag, int *n, double *
	ap, int *info);

/* Subroutine */ int dtptrs_(char *uplo, char *trans, char *diag, int *n, 
	int *nrhs, double *ap, double *b, int *ldb, int *
	info);

/* Subroutine */ int dtrcon_(char *norm, char *uplo, char *diag, int *n, 
	double *a, int *lda, double *rcond, double *work, 
	int *iwork, int *info);

/* Subroutine */ int dtrevc_(char *side, char *howmny, logical *select, 
	int *n, double *t, int *ldt, double *vl, int *
	ldvl, double *vr, int *ldvr, int *mm, int *m, 
	double *work, int *info);

/* Subroutine */ int dtrexc_(char *compq, int *n, double *t, int *
	ldt, double *q, int *ldq, int *ifst, int *ilst, 
	double *work, int *info);

/* Subroutine */ int dtrrfs_(char *uplo, char *trans, char *diag, int *n, 
	int *nrhs, double *a, int *lda, double *b, int *
	ldb, double *x, int *ldx, double *ferr, double *berr, 
	double *work, int *iwork, int *info);

/* Subroutine */ int dtrsen_(char *job, char *compq, logical *select, int 
	*n, double *t, int *ldt, double *q, int *ldq, 
	double *wr, double *wi, int *m, double *s, double 
	*sep, double *work, int *lwork, int *iwork, int *
	liwork, int *info);

/* Subroutine */ int dtrsna_(char *job, char *howmny, logical *select, 
	int *n, double *t, int *ldt, double *vl, int *
	ldvl, double *vr, int *ldvr, double *s, double *sep, 
	int *mm, int *m, double *work, int *ldwork, int *
	iwork, int *info);

/* Subroutine */ int dtrsyl_(char *trana, char *tranb, int *isgn, int 
	*m, int *n, double *a, int *lda, double *b, int *
	ldb, double *c__, int *ldc, double *scale, int *info);

/* Subroutine */ int dtrti2_(char *uplo, char *diag, int *n, double *
	a, int *lda, int *info);

/* Subroutine */ int dtrtri_(char *uplo, char *diag, int *n, double *
	a, int *lda, int *info);

/* Subroutine */ int dtrtrs_(char *uplo, char *trans, char *diag, int *n, 
	int *nrhs, double *a, int *lda, double *b, int *
	ldb, int *info);

/* Subroutine */ int dtzrqf_(int *m, int *n, double *a, int *
	lda, double *tau, int *info);

/* Subroutine */ int dtzrzf_(int *m, int *n, double *a, int *
	lda, double *tau, double *work, int *lwork, int *info);

/* Subroutine */ int ilaver_(int *vers_major__, int *vers_minor__, 
	int *vers_patch__);

/* Subroutine */ int dgesv_(int *n, int *nrhs, double *a, int 
	*lda, int *ipiv, double *b, int *ldb, int *info);

/* Subroutine */ int sbdsdc_(char *uplo, char *compq, int *n, real *d__, 
	real *e, real *u, int *ldu, real *vt, int *ldvt, real *q,  	
	int *iq, real *work, int *iwork, int *info);

/* Subroutine */ int sbdsqr_(char *uplo, int *n, int *ncvt, int *
	nru, int *ncc, real *d__, real *e, real *vt, int *ldvt, real *
	u, int *ldu, real *c__, int *ldc, real *work, int *info);

/* Subroutine */ int sdisna_(char *job, int *m, int *n, real *d__, 
	real *sep, int *info);

/* Subroutine */ int sgbbrd_(char *vect, int *m, int *n, int *ncc,
	 int *kl, int *ku, real *ab, int *ldab, real *d__, real *
	e, real *q, int *ldq, real *pt, int *ldpt, real *c__, int 
	*ldc, real *work, int *info);

/* Subroutine */ int sgbcon_(char *norm, int *n, int *kl, int *ku,
	 real *ab, int *ldab, int *ipiv, real *anorm, real *rcond, 
	real *work, int *iwork, int *info);

/* Subroutine */ int sgbequ_(int *m, int *n, int *kl, int *ku,
	 real *ab, int *ldab, real *r__, real *c__, real *rowcnd, real *
	colcnd, real *amax, int *info);

/* Subroutine */ int sgbrfs_(char *trans, int *n, int *kl, int *
	ku, int *nrhs, real *ab, int *ldab, real *afb, int *ldafb,
	 int *ipiv, real *b, int *ldb, real *x, int *ldx, real *
	ferr, real *berr, real *work, int *iwork, int *info);

/* Subroutine */ int sgbsv_(int *n, int *kl, int *ku, int *
	nrhs, real *ab, int *ldab, int *ipiv, real *b, int *ldb, 
	int *info);

/* Subroutine */ int sgbsvx_(char *fact, char *trans, int *n, int *kl,
	 int *ku, int *nrhs, real *ab, int *ldab, real *afb, 
	int *ldafb, int *ipiv, char *equed, real *r__, real *c__, 
	real *b, int *ldb, real *x, int *ldx, real *rcond, real *ferr,
	 real *berr, real *work, int *iwork, int *info);

/* Subroutine */ int sgbtf2_(int *m, int *n, int *kl, int *ku,
	 real *ab, int *ldab, int *ipiv, int *info);

/* Subroutine */ int sgbtrf_(int *m, int *n, int *kl, int *ku,
	 real *ab, int *ldab, int *ipiv, int *info);

/* Subroutine */ int sgbtrs_(char *trans, int *n, int *kl, int *
	ku, int *nrhs, real *ab, int *ldab, int *ipiv, real *b, 
	int *ldb, int *info);

/* Subroutine */ int sgebak_(char *job, char *side, int *n, int *ilo, 
	int *ihi, real *scale, int *m, real *v, int *ldv, int 
	*info);

/* Subroutine */ int sgebal_(char *job, int *n, real *a, int *lda, 
	int *ilo, int *ihi, real *scale, int *info);

/* Subroutine */ int sgebd2_(int *m, int *n, real *a, int *lda, 
	real *d__, real *e, real *tauq, real *taup, real *work, int *info);

/* Subroutine */ int sgebrd_(int *m, int *n, real *a, int *lda, 
	real *d__, real *e, real *tauq, real *taup, real *work, int *
	lwork, int *info);

/* Subroutine */ int sgecon_(char *norm, int *n, real *a, int *lda, 
	real *anorm, real *rcond, real *work, int *iwork, int *info);

/* Subroutine */ int sgeequ_(int *m, int *n, real *a, int *lda, 
	real *r__, real *c__, real *rowcnd, real *colcnd, real *amax, int 
	*info);

/* Subroutine */ int sgees_(char *jobvs, char *sort, L_fp select, int *n, 
	real *a, int *lda, int *sdim, real *wr, real *wi, real *vs, 
	int *ldvs, real *work, int *lwork, logical *bwork, int *
	info);

/* Subroutine */ int sgeesx_(char *jobvs, char *sort, L_fp select, char *
	sense, int *n, real *a, int *lda, int *sdim, real *wr, 
	real *wi, real *vs, int *ldvs, real *rconde, real *rcondv, real *
	work, int *lwork, int *iwork, int *liwork, logical *bwork,
	 int *info);

/* Subroutine */ int sgeev_(char *jobvl, char *jobvr, int *n, real *a, 
	int *lda, real *wr, real *wi, real *vl, int *ldvl, real *vr,  	
	int *ldvr, real *work, int *lwork, int *info);

/* Subroutine */ int sgeevx_(char *balanc, char *jobvl, char *jobvr, char *
	sense, int *n, real *a, int *lda, real *wr, real *wi, real *
	vl, int *ldvl, real *vr, int *ldvr, int *ilo, int *
	ihi, real *scale, real *abnrm, real *rconde, real *rcondv, real *work,
	 int *lwork, int *iwork, int *info);

/* Subroutine */ int sgegs_(char *jobvsl, char *jobvsr, int *n, real *a, 
	int *lda, real *b, int *ldb, real *alphar, real *alphai, real 
	*beta, real *vsl, int *ldvsl, real *vsr, int *ldvsr, real * 	
	work, int *lwork, int *info);

/* Subroutine */ int sgegv_(char *jobvl, char *jobvr, int *n, real *a, 
	int *lda, real *b, int *ldb, real *alphar, real *alphai, real 
	*beta, real *vl, int *ldvl, real *vr, int *ldvr, real *work, 
	int *lwork, int *info);

/* Subroutine */ int sgehd2_(int *n, int *ilo, int *ihi, real *a, 
	int *lda, real *tau, real *work, int *info);

/* Subroutine */ int sgehrd_(int *n, int *ilo, int *ihi, real *a, 
	int *lda, real *tau, real *work, int *lwork, int *info);

/* Subroutine */ int sgelq2_(int *m, int *n, real *a, int *lda, 
	real *tau, real *work, int *info);

/* Subroutine */ int sgelqf_(int *m, int *n, real *a, int *lda, 
	real *tau, real *work, int *lwork, int *info);

/* Subroutine */ int sgels_(char *trans, int *m, int *n, int *
	nrhs, real *a, int *lda, real *b, int *ldb, real *work, 
	int *lwork, int *info);

/* Subroutine */ int sgelsd_(int *m, int *n, int *nrhs, real *a, 
	int *lda, real *b, int *ldb, real *s, real *rcond, int *
	rank, real *work, int *lwork, int *iwork, int *info);

/* Subroutine */ int sgelss_(int *m, int *n, int *nrhs, real *a, 
	int *lda, real *b, int *ldb, real *s, real *rcond, int *
	rank, real *work, int *lwork, int *info);

/* Subroutine */ int sgelsx_(int *m, int *n, int *nrhs, real *a, 
	int *lda, real *b, int *ldb, int *jpvt, real *rcond, 
	int *rank, real *work, int *info);

/* Subroutine */ int sgelsy_(int *m, int *n, int *nrhs, real *a, 
	int *lda, real *b, int *ldb, int *jpvt, real *rcond, 
	int *rank, real *work, int *lwork, int *info);

/* Subroutine */ int sgeql2_(int *m, int *n, real *a, int *lda, 
	real *tau, real *work, int *info);

/* Subroutine */ int sgeqlf_(int *m, int *n, real *a, int *lda, 
	real *tau, real *work, int *lwork, int *info);

/* Subroutine */ int sgeqp3_(int *m, int *n, real *a, int *lda, 
	int *jpvt, real *tau, real *work, int *lwork, int *info);

/* Subroutine */ int sgeqpf_(int *m, int *n, real *a, int *lda, 
	int *jpvt, real *tau, real *work, int *info);

/* Subroutine */ int sgeqr2_(int *m, int *n, real *a, int *lda, 
	real *tau, real *work, int *info);

/* Subroutine */ int sgeqrf_(int *m, int *n, real *a, int *lda, 
	real *tau, real *work, int *lwork, int *info);

/* Subroutine */ int sgerfs_(char *trans, int *n, int *nrhs, real *a, 
	int *lda, real *af, int *ldaf, int *ipiv, real *b, 
	int *ldb, real *x, int *ldx, real *ferr, real *berr, real *
	work, int *iwork, int *info);

/* Subroutine */ int sgerq2_(int *m, int *n, real *a, int *lda, 
	real *tau, real *work, int *info);

/* Subroutine */ int sgerqf_(int *m, int *n, real *a, int *lda, 
	real *tau, real *work, int *lwork, int *info);

/* Subroutine */ int sgesc2_(int *n, real *a, int *lda, real *rhs, 
	int *ipiv, int *jpiv, real *scale);

/* Subroutine */ int sgesdd_(char *jobz, int *m, int *n, real *a, 
	int *lda, real *s, real *u, int *ldu, real *vt, int *ldvt, 	 
	real *work, int *lwork, int *iwork, int *info);

/* Subroutine */ int sgesv_(int *n, int *nrhs, real *a, int *lda, 
	int *ipiv, real *b, int *ldb, int *info);

/* Subroutine */ int sgesvd_(char *jobu, char *jobvt, int *m, int *n, 
	real *a, int *lda, real *s, real *u, int *ldu, real *vt,  	
	int *ldvt, real *work, int *lwork, int *info);

/* Subroutine */ int sgesvx_(char *fact, char *trans, int *n, int *
	nrhs, real *a, int *lda, real *af, int *ldaf, int *ipiv, 
	char *equed, real *r__, real *c__, real *b, int *ldb, real *x, 
	int *ldx, real *rcond, real *ferr, real *berr, real *work, 
	int *iwork, int *info);

/* Subroutine */ int sgetc2_(int *n, real *a, int *lda, int *ipiv,
	 int *jpiv, int *info);

/* Subroutine */ int sgetf2_(int *m, int *n, real *a, int *lda, 
	int *ipiv, int *info);

/* Subroutine */ int sgetrf_(int *m, int *n, real *a, int *lda, 
	int *ipiv, int *info);

/* Subroutine */ int sgetri_(int *n, real *a, int *lda, int *ipiv,
	 real *work, int *lwork, int *info);

/* Subroutine */ int sgetrs_(char *trans, int *n, int *nrhs, real *a, 
	int *lda, int *ipiv, real *b, int *ldb, int *info);

/* Subroutine */ int sggbak_(char *job, char *side, int *n, int *ilo, 
	int *ihi, real *lscale, real *rscale, int *m, real *v, 
	int *ldv, int *info);

/* Subroutine */ int sggbal_(char *job, int *n, real *a, int *lda, 
	real *b, int *ldb, int *ilo, int *ihi, real *lscale, real 
	*rscale, real *work, int *info);

/* Subroutine */ int sgges_(char *jobvsl, char *jobvsr, char *sort, L_fp 
	selctg, int *n, real *a, int *lda, real *b, int *ldb, 
	int *sdim, real *alphar, real *alphai, real *beta, real *vsl, 
	int *ldvsl, real *vsr, int *ldvsr, real *work, int *lwork,
	 logical *bwork, int *info);

/* Subroutine */ int sggesx_(char *jobvsl, char *jobvsr, char *sort, L_fp 
	selctg, char *sense, int *n, real *a, int *lda, real *b, 
	int *ldb, int *sdim, real *alphar, real *alphai, real *beta, 
	real *vsl, int *ldvsl, real *vsr, int *ldvsr, real *rconde, 
	real *rcondv, real *work, int *lwork, int *iwork, int * 	
	liwork, logical *bwork, int *info);

/* Subroutine */ int sggev_(char *jobvl, char *jobvr, int *n, real *a, 
	int *lda, real *b, int *ldb, real *alphar, real *alphai, real 
	*beta, real *vl, int *ldvl, real *vr, int *ldvr, real *work, 
	int *lwork, int *info);

/* Subroutine */ int sggevx_(char *balanc, char *jobvl, char *jobvr, char *
	sense, int *n, real *a, int *lda, real *b, int *ldb, real 
	*alphar, real *alphai, real *beta, real *vl, int *ldvl, real *vr, 
	int *ldvr, int *ilo, int *ihi, real *lscale, real *rscale,
	 real *abnrm, real *bbnrm, real *rconde, real *rcondv, real *work,  	
	int *lwork, int *iwork, logical *bwork, int *info);

/* Subroutine */ int sggglm_(int *n, int *m, int *p, real *a, 
	int *lda, real *b, int *ldb, real *d__, real *x, real *y, 
	real *work, int *lwork, int *info);

/* Subroutine */ int sgghrd_(char *compq, char *compz, int *n, int *
	ilo, int *ihi, real *a, int *lda, real *b, int *ldb, real 
	*q, int *ldq, real *z__, int *ldz, int *info);

/* Subroutine */ int sgglse_(int *m, int *n, int *p, real *a, 
	int *lda, real *b, int *ldb, real *c__, real *d__, real *x, 
	real *work, int *lwork, int *info);

/* Subroutine */ int sggqrf_(int *n, int *m, int *p, real *a, 
	int *lda, real *taua, real *b, int *ldb, real *taub, real *
	work, int *lwork, int *info);

/* Subroutine */ int sggrqf_(int *m, int *p, int *n, real *a, 
	int *lda, real *taua, real *b, int *ldb, real *taub, real *
	work, int *lwork, int *info);

/* Subroutine */ int sggsvd_(char *jobu, char *jobv, char *jobq, int *m, 
	int *n, int *p, int *k, int *l, real *a, int *lda,
	 real *b, int *ldb, real *alpha, real *beta, real *u, int *
	ldu, real *v, int *ldv, real *q, int *ldq, real *work, 
	int *iwork, int *info);

/* Subroutine */ int sggsvp_(char *jobu, char *jobv, char *jobq, int *m, 
	int *p, int *n, real *a, int *lda, real *b, int *ldb, 
	real *tola, real *tolb, int *k, int *l, real *u, int *ldu,
	 real *v, int *ldv, real *q, int *ldq, int *iwork, real *
	tau, real *work, int *info);

/* Subroutine */ int sgtcon_(char *norm, int *n, real *dl, real *d__, 
	real *du, real *du2, int *ipiv, real *anorm, real *rcond, real *
	work, int *iwork, int *info);

/* Subroutine */ int sgtrfs_(char *trans, int *n, int *nrhs, real *dl,
	 real *d__, real *du, real *dlf, real *df, real *duf, real *du2, 
	int *ipiv, real *b, int *ldb, real *x, int *ldx, real *
	ferr, real *berr, real *work, int *iwork, int *info);

/* Subroutine */ int sgtsv_(int *n, int *nrhs, real *dl, real *d__, 
	real *du, real *b, int *ldb, int *info);

/* Subroutine */ int sgtsvx_(char *fact, char *trans, int *n, int *
	nrhs, real *dl, real *d__, real *du, real *dlf, real *df, real *duf, 
	real *du2, int *ipiv, real *b, int *ldb, real *x, int *
	ldx, real *rcond, real *ferr, real *berr, real *work, int *iwork, 
	int *info);

/* Subroutine */ int sgttrf_(int *n, real *dl, real *d__, real *du, real *
	du2, int *ipiv, int *info);

/* Subroutine */ int sgttrs_(char *trans, int *n, int *nrhs, real *dl,
	 real *d__, real *du, real *du2, int *ipiv, real *b, int *ldb,
	 int *info);

/* Subroutine */ int sgtts2_(int *itrans, int *n, int *nrhs, real 
	*dl, real *d__, real *du, real *du2, int *ipiv, real *b, int *
	ldb);

/* Subroutine */ int shgeqz_(char *job, char *compq, char *compz, int *n, 
	int *ilo, int *ihi, real *h__, int *ldh, real *t, int 
	*ldt, real *alphar, real *alphai, real *beta, real *q, int *ldq, 
	real *z__, int *ldz, real *work, int *lwork, int *info);

/* Subroutine */ int shsein_(char *side, char *eigsrc, char *initv, logical *
	select, int *n, real *h__, int *ldh, real *wr, real *wi, real 
	*vl, int *ldvl, real *vr, int *ldvr, int *mm, int *m, 
	real *work, int *ifaill, int *ifailr, int *info);

/* Subroutine */ int shseqr_(char *job, char *compz, int *n, int *ilo,
	 int *ihi, real *h__, int *ldh, real *wr, real *wi, real *z__, 	 
	int *ldz, real *work, int *lwork, int *info);

/* Subroutine */ int slabad_(real *small, real *large);

/* Subroutine */ int slabrd_(int *m, int *n, int *nb, real *a, 
	int *lda, real *d__, real *e, real *tauq, real *taup, real *x, 
	int *ldx, real *y, int *ldy);

/* Subroutine */ int slacn2_(int *n, real *v, real *x, int *isgn, 
	real *est, int *kase, int *isave);

/* Subroutine */ int slacon_(int *n, real *v, real *x, int *isgn, 
	real *est, int *kase);

/* Subroutine */ int slacpy_(char *uplo, int *m, int *n, real *a, 
	int *lda, real *b, int *ldb);

/* Subroutine */ int sladiv_(real *a, real *b, real *c__, real *d__, real *p, 
	real *q);

/* Subroutine */ int slae2_(real *a, real *b, real *c__, real *rt1, real *rt2);

/* Subroutine */ int slaebz_(int *ijob, int *nitmax, int *n, 
	int *mmax, int *minp, int *nbmin, real *abstol, real *
	reltol, real *pivmin, real *d__, real *e, real *e2, int *nval, 
	real *ab, real *c__, int *mout, int *nab, real *work, int 
	*iwork, int *info);

/* Subroutine */ int slaed0_(int *icompq, int *qsiz, int *n, real 
	*d__, real *e, real *q, int *ldq, real *qstore, int *ldqs, 
	real *work, int *iwork, int *info);

/* Subroutine */ int slaed1_(int *n, real *d__, real *q, int *ldq, 
	int *indxq, real *rho, int *cutpnt, real *work, int *
	iwork, int *info);

/* Subroutine */ int slaed2_(int *k, int *n, int *n1, real *d__, 
	real *q, int *ldq, int *indxq, real *rho, real *z__, real *
	dlamda, real *w, real *q2, int *indx, int *indxc, int *
	indxp, int *coltyp, int *info);

/* Subroutine */ int slaed3_(int *k, int *n, int *n1, real *d__, 
	real *q, int *ldq, real *rho, real *dlamda, real *q2, int *
	indx, int *ctot, real *w, real *s, int *info);

/* Subroutine */ int slaed4_(int *n, int *i__, real *d__, real *z__, 
	real *delta, real *rho, real *dlam, int *info);

/* Subroutine */ int slaed5_(int *i__, real *d__, real *z__, real *delta, 
	real *rho, real *dlam);

/* Subroutine */ int slaed6_(int *kniter, logical *orgati, real *rho, 
	real *d__, real *z__, real *finit, real *tau, int *info);

/* Subroutine */ int slaed7_(int *icompq, int *n, int *qsiz, 
	int *tlvls, int *curlvl, int *curpbm, real *d__, real *q, 
	int *ldq, int *indxq, real *rho, int *cutpnt, real *
	qstore, int *qptr, int *prmptr, int *perm, int *
	givptr, int *givcol, real *givnum, real *work, int *iwork, 
	int *info);

/* Subroutine */ int slaed8_(int *icompq, int *k, int *n, int 
	*qsiz, real *d__, real *q, int *ldq, int *indxq, real *rho, 
	int *cutpnt, real *z__, real *dlamda, real *q2, int *ldq2, 
	real *w, int *perm, int *givptr, int *givcol, real *
	givnum, int *indxp, int *indx, int *info);

/* Subroutine */ int slaed9_(int *k, int *kstart, int *kstop, 
	int *n, real *d__, real *q, int *ldq, real *rho, real *dlamda,
	 real *w, real *s, int *lds, int *info);

/* Subroutine */ int slaeda_(int *n, int *tlvls, int *curlvl, 
	int *curpbm, int *prmptr, int *perm, int *givptr, 
	int *givcol, real *givnum, real *q, int *qptr, real *z__, 
	real *ztemp, int *info);

/* Subroutine */ int slaein_(logical *rightv, logical *noinit, int *n, 
	real *h__, int *ldh, real *wr, real *wi, real *vr, real *vi, real 
	*b, int *ldb, real *work, real *eps3, real *smlnum, real *bignum, 
	int *info);

/* Subroutine */ int slaev2_(real *a, real *b, real *c__, real *rt1, real *
	rt2, real *cs1, real *sn1);

/* Subroutine */ int slaexc_(logical *wantq, int *n, real *t, int *
	ldt, real *q, int *ldq, int *j1, int *n1, int *n2, 
	real *work, int *info);

/* Subroutine */ int slag2_(real *a, int *lda, real *b, int *ldb, 
	real *safmin, real *scale1, real *scale2, real *wr1, real *wr2, real *
	wi);

/* Subroutine */ int slag2d_(int *m, int *n, real *sa, int *ldsa, 
	double *a, int *lda, int *info);

/* Subroutine */ int slags2_(logical *upper, real *a1, real *a2, real *a3, 
	real *b1, real *b2, real *b3, real *csu, real *snu, real *csv, real *
	snv, real *csq, real *snq);

/* Subroutine */ int slagtf_(int *n, real *a, real *lambda, real *b, real 
	*c__, real *tol, real *d__, int *in, int *info);

/* Subroutine */ int slagtm_(char *trans, int *n, int *nrhs, real *
	alpha, real *dl, real *d__, real *du, real *x, int *ldx, real *
	beta, real *b, int *ldb);

/* Subroutine */ int slagts_(int *job, int *n, real *a, real *b, real 
	*c__, real *d__, int *in, real *y, real *tol, int *info);

/* Subroutine */ int slagv2_(real *a, int *lda, real *b, int *ldb, 
	real *alphar, real *alphai, real *beta, real *csl, real *snl, real *
	csr, real *snr);

/* Subroutine */ int slahqr_(logical *wantt, logical *wantz, int *n, 
	int *ilo, int *ihi, real *h__, int *ldh, real *wr, real *
	wi, int *iloz, int *ihiz, real *z__, int *ldz, int *
	info);

/* Subroutine */ int slahr2_(int *n, int *k, int *nb, real *a, 
	int *lda, real *tau, real *t, int *ldt, real *y, int *ldy);

/* Subroutine */ int slahrd_(int *n, int *k, int *nb, real *a, 
	int *lda, real *tau, real *t, int *ldt, real *y, int *ldy);

/* Subroutine */ int slaic1_(int *job, int *j, real *x, real *sest, 
	real *w, real *gamma, real *sestpr, real *s, real *c__);

/* Subroutine */ int slaln2_(logical *ltrans, int *na, int *nw, real *
	smin, real *ca, real *a, int *lda, real *d1, real *d2, real *b, 
	int *ldb, real *wr, real *wi, real *x, int *ldx, real *scale, 
	real *xnorm, int *info);

/* Subroutine */ int slals0_(int *icompq, int *nl, int *nr, 
	int *sqre, int *nrhs, real *b, int *ldb, real *bx, 
	int *ldbx, int *perm, int *givptr, int *givcol, 
	int *ldgcol, real *givnum, int *ldgnum, real *poles, real *
	difl, real *difr, real *z__, int *k, real *c__, real *s, real *
	work, int *info);

/* Subroutine */ int slalsa_(int *icompq, int *smlsiz, int *n, 
	int *nrhs, real *b, int *ldb, real *bx, int *ldbx, real *
	u, int *ldu, real *vt, int *k, real *difl, real *difr, real *
	z__, real *poles, int *givptr, int *givcol, int *ldgcol, 
	int *perm, real *givnum, real *c__, real *s, real *work, int *
	iwork, int *info);

/* Subroutine */ int slalsd_(char *uplo, int *smlsiz, int *n, int 
	*nrhs, real *d__, real *e, real *b, int *ldb, real *rcond, 
	int *rank, real *work, int *iwork, int *info);

/* Subroutine */ int slamrg_(int *n1, int *n2, real *a, int *
	strd1, int *strd2, int *index);

/* Subroutine */ int slanv2_(real *a, real *b, real *c__, real *d__, real *
	rt1r, real *rt1i, real *rt2r, real *rt2i, real *cs, real *sn);

/* Subroutine */ int slapll_(int *n, real *x, int *incx, real *y, 
	int *incy, real *ssmin);

/* Subroutine */ int slapmt_(logical *forwrd, int *m, int *n, real *x,
	 int *ldx, int *k);

/* Subroutine */ int slaqgb_(int *m, int *n, int *kl, int *ku,
	 real *ab, int *ldab, real *r__, real *c__, real *rowcnd, real *
	colcnd, real *amax, char *equed);

/* Subroutine */ int slaqge_(int *m, int *n, real *a, int *lda, 
	real *r__, real *c__, real *rowcnd, real *colcnd, real *amax, char *
	equed);

/* Subroutine */ int slaqp2_(int *m, int *n, int *offset, real *a,
	 int *lda, int *jpvt, real *tau, real *vn1, real *vn2, real *
	work);

/* Subroutine */ int slaqps_(int *m, int *n, int *offset, int 
	*nb, int *kb, real *a, int *lda, int *jpvt, real *tau, 
	real *vn1, real *vn2, real *auxv, real *f, int *ldf);

/* Subroutine */ int slaqr0_(logical *wantt, logical *wantz, int *n, 
	int *ilo, int *ihi, real *h__, int *ldh, real *wr, real *
	wi, int *iloz, int *ihiz, real *z__, int *ldz, real *work,
	 int *lwork, int *info);

/* Subroutine */ int slaqr1_(int *n, real *h__, int *ldh, real *sr1, 
	real *si1, real *sr2, real *si2, real *v);

/* Subroutine */ int slaqr2_(logical *wantt, logical *wantz, int *n, 
	int *ktop, int *kbot, int *nw, real *h__, int *ldh, 
	int *iloz, int *ihiz, real *z__, int *ldz, int *ns, 
	int *nd, real *sr, real *si, real *v, int *ldv, int *nh, 
	real *t, int *ldt, int *nv, real *wv, int *ldwv, real *
	work, int *lwork);

/* Subroutine */ int slaqr3_(logical *wantt, logical *wantz, int *n, 
	int *ktop, int *kbot, int *nw, real *h__, int *ldh, 
	int *iloz, int *ihiz, real *z__, int *ldz, int *ns, 
	int *nd, real *sr, real *si, real *v, int *ldv, int *nh, 
	real *t, int *ldt, int *nv, real *wv, int *ldwv, real *
	work, int *lwork);

/* Subroutine */ int slaqr4_(logical *wantt, logical *wantz, int *n, 
	int *ilo, int *ihi, real *h__, int *ldh, real *wr, real *
	wi, int *iloz, int *ihiz, real *z__, int *ldz, real *work,
	 int *lwork, int *info);

/* Subroutine */ int slaqr5_(logical *wantt, logical *wantz, int *kacc22, 
	int *n, int *ktop, int *kbot, int *nshfts, real *sr, 
	real *si, real *h__, int *ldh, int *iloz, int *ihiz, real 
	*z__, int *ldz, real *v, int *ldv, real *u, int *ldu, 
	int *nv, real *wv, int *ldwv, int *nh, real *wh, int *
	ldwh);

/* Subroutine */ int slaqsb_(char *uplo, int *n, int *kd, real *ab, 
	int *ldab, real *s, real *scond, real *amax, char *equed  	);

/* Subroutine */ int slaqsp_(char *uplo, int *n, real *ap, real *s, real *
	scond, real *amax, char *equed);

/* Subroutine */ int slaqsy_(char *uplo, int *n, real *a, int *lda, 
	real *s, real *scond, real *amax, char *equed);

/* Subroutine */ int slaqtr_(logical *ltran, logical *lreal, int *n, real 
	*t, int *ldt, real *b, real *w, real *scale, real *x, real *work, 
	int *info);

/* Subroutine */ int slar1v_(int *n, int *b1, int *bn, real *
	lambda, real *d__, real *l, real *ld, real *lld, real *pivmin, real *
	gaptol, real *z__, logical *wantnc, int *negcnt, real *ztz, real *
	mingma, int *r__, int *isuppz, real *nrminv, real *resid, 
	real *rqcorr, real *work);

/* Subroutine */ int slar2v_(int *n, real *x, real *y, real *z__, int 
	*incx, real *c__, real *s, int *incc);

/* Subroutine */ int slarf_(char *side, int *m, int *n, real *v, 
	int *incv, real *tau, real *c__, int *ldc, real *work  	);

/* Subroutine */ int slarfb_(char *side, char *trans, char *direct, char *
	storev, int *m, int *n, int *k, real *v, int *ldv, 
	real *t, int *ldt, real *c__, int *ldc, real *work, int *
	ldwork  	);

/* Subroutine */ int slarfg_(int *n, real *alpha, real *x, int *incx, 
	real *tau);

/* Subroutine */ int slarft_(char *direct, char *storev, int *n, int *
	k, real *v, int *ldv, real *tau, real *t, int *ldt  	);

/* Subroutine */ int slarfx_(char *side, int *m, int *n, real *v, 
	real *tau, real *c__, int *ldc, real *work);

/* Subroutine */ int slargv_(int *n, real *x, int *incx, real *y, 
	int *incy, real *c__, int *incc);

/* Subroutine */ int slarnv_(int *idist, int *iseed, int *n, real 
	*x);

/* Subroutine */ int slarra_(int *n, real *d__, real *e, real *e2, real *
	spltol, real *tnrm, int *nsplit, int *isplit, int *info);

/* Subroutine */ int slarrb_(int *n, real *d__, real *lld, int *
	ifirst, int *ilast, real *rtol1, real *rtol2, int *offset, 
	real *w, real *wgap, real *werr, real *work, int *iwork, real *
	pivmin, real *spdiam, int *twist, int *info);

/* Subroutine */ int slarrc_(char *jobt, int *n, real *vl, real *vu, real 
	*d__, real *e, real *pivmin, int *eigcnt, int *lcnt, int *
	rcnt, int *info);

/* Subroutine */ int slarrd_(char *range, char *order, int *n, real *vl, 
	real *vu, int *il, int *iu, real *gers, real *reltol, real *
	d__, real *e, real *e2, real *pivmin, int *nsplit, int *
	isplit, int *m, real *w, real *werr, real *wl, real *wu, int *
	iblock, int *indexw, real *work, int *iwork, int *info);

/* Subroutine */ int slarre_(char *range, int *n, real *vl, real *vu, 
	int *il, int *iu, real *d__, real *e, real *e2, real *rtol1, 
	real *rtol2, real *spltol, int *nsplit, int *isplit, int *
	m, real *w, real *werr, real *wgap, int *iblock, int *indexw, 
	real *gers, real *pivmin, real *work, int *iwork, int *info);

/* Subroutine */ int slarrf_(int *n, real *d__, real *l, real *ld, 
	int *clstrt, int *clend, real *w, real *wgap, real *werr, 
	real *spdiam, real *clgapl, real *clgapr, real *pivmin, real *sigma, 
	real *dplus, real *lplus, real *work, int *info);

/* Subroutine */ int slarrj_(int *n, real *d__, real *e2, int *ifirst,
	 int *ilast, real *rtol, int *offset, real *w, real *werr, 
	real *work, int *iwork, real *pivmin, real *spdiam, int *info);

/* Subroutine */ int slarrk_(int *n, int *iw, real *gl, real *gu, 
	real *d__, real *e2, real *pivmin, real *reltol, real *w, real *werr, 
	int *info);

/* Subroutine */ int slarrr_(int *n, real *d__, real *e, int *info);

/* Subroutine */ int slarrv_(int *n, real *vl, real *vu, real *d__, real *
	l, real *pivmin, int *isplit, int *m, int *dol, int *
	dou, real *minrgp, real *rtol1, real *rtol2, real *w, real *werr, 
	real *wgap, int *iblock, int *indexw, real *gers, real *z__, 
	int *ldz, int *isuppz, real *work, int *iwork, int *
	info);

/* Subroutine */ int slartg_(real *f, real *g, real *cs, real *sn, real *r__);

/* Subroutine */ int slartv_(int *n, real *x, int *incx, real *y, 
	int *incy, real *c__, real *s, int *incc);

/* Subroutine */ int slaruv_(int *iseed, int *n, real *x);

/* Subroutine */ int slarz_(char *side, int *m, int *n, int *l, 
	real *v, int *incv, real *tau, real *c__, int *ldc, real *
	work);

/* Subroutine */ int slarzb_(char *side, char *trans, char *direct, char *
	storev, int *m, int *n, int *k, int *l, real *v, 
	int *ldv, real *t, int *ldt, real *c__, int *ldc, real *
	work, int *ldwork  	);

/* Subroutine */ int slarzt_(char *direct, char *storev, int *n, int *
	k, real *v, int *ldv, real *tau, real *t, int *ldt  	);

/* Subroutine */ int slas2_(real *f, real *g, real *h__, real *ssmin, real *
	ssmax);

/* Subroutine */ int slascl_(char *type__, int *kl, int *ku, real *
	cfrom, real *cto, int *m, int *n, real *a, int *lda, 
	int *info);

/* Subroutine */ int slasd0_(int *n, int *sqre, real *d__, real *e, 
	real *u, int *ldu, real *vt, int *ldvt, int *smlsiz, 
	int *iwork, real *work, int *info);

/* Subroutine */ int slasd1_(int *nl, int *nr, int *sqre, real *
	d__, real *alpha, real *beta, real *u, int *ldu, real *vt, 
	int *ldvt, int *idxq, int *iwork, real *work, int *
	info);

/* Subroutine */ int slasd2_(int *nl, int *nr, int *sqre, int 
	*k, real *d__, real *z__, real *alpha, real *beta, real *u, int *
	ldu, real *vt, int *ldvt, real *dsigma, real *u2, int *ldu2, 
	real *vt2, int *ldvt2, int *idxp, int *idx, int *idxc,
	 int *idxq, int *coltyp, int *info);

/* Subroutine */ int slasd3_(int *nl, int *nr, int *sqre, int 
	*k, real *d__, real *q, int *ldq, real *dsigma, real *u, int *
	ldu, real *u2, int *ldu2, real *vt, int *ldvt, real *vt2, 
	int *ldvt2, int *idxc, int *ctot, real *z__, int *
	info);

/* Subroutine */ int slasd4_(int *n, int *i__, real *d__, real *z__, 
	real *delta, real *rho, real *sigma, real *work, int *info);

/* Subroutine */ int slasd5_(int *i__, real *d__, real *z__, real *delta, 
	real *rho, real *dsigma, real *work);

/* Subroutine */ int slasd6_(int *icompq, int *nl, int *nr, 
	int *sqre, real *d__, real *vf, real *vl, real *alpha, real *beta,
	 int *idxq, int *perm, int *givptr, int *givcol, 
	int *ldgcol, real *givnum, int *ldgnum, real *poles, real *
	difl, real *difr, real *z__, int *k, real *c__, real *s, real *
	work, int *iwork, int *info);

/* Subroutine */ int slasd7_(int *icompq, int *nl, int *nr, 
	int *sqre, int *k, real *d__, real *z__, real *zw, real *vf, 
	real *vfw, real *vl, real *vlw, real *alpha, real *beta, real *dsigma,
	 int *idx, int *idxp, int *idxq, int *perm, int *
	givptr, int *givcol, int *ldgcol, real *givnum, int *
	ldgnum, real *c__, real *s, int *info);

/* Subroutine */ int slasd8_(int *icompq, int *k, real *d__, real *
	z__, real *vf, real *vl, real *difl, real *difr, int *lddifr, 
	real *dsigma, real *work, int *info);

/* Subroutine */ int slasd9_(int *icompq, int *ldu, int *k, real *
	d__, real *z__, real *vf, real *vl, real *difl, real *difr, real *
	dsigma, real *work, int *info);

/* Subroutine */ int slasda_(int *icompq, int *smlsiz, int *n, 
	int *sqre, real *d__, real *e, real *u, int *ldu, real *vt, 
	int *k, real *difl, real *difr, real *z__, real *poles, int *
	givptr, int *givcol, int *ldgcol, int *perm, real *givnum,
	 real *c__, real *s, real *work, int *iwork, int *info);

/* Subroutine */ int slasdq_(char *uplo, int *sqre, int *n, int *
	ncvt, int *nru, int *ncc, real *d__, real *e, real *vt, 
	int *ldvt, real *u, int *ldu, real *c__, int *ldc, real *
	work, int *info);

/* Subroutine */ int slasdt_(int *n, int *lvl, int *nd, int *
	inode, int *ndiml, int *ndimr, int *msub);

/* Subroutine */ int slaset_(char *uplo, int *m, int *n, real *alpha, 
	real *beta, real *a, int *lda);

/* Subroutine */ int slasq1_(int *n, real *d__, real *e, real *work, 
	int *info);

/* Subroutine */ int slasq2_(int *n, real *z__, int *info);

/* Subroutine */ int slasq3_(int *i0, int *n0, real *z__, int *pp,
	 real *dmin__, real *sigma, real *desig, real *qmax, int *nfail, 
	int *iter, int *ndiv, logical *ieee);

/* Subroutine */ int slasq4_(int *i0, int *n0, real *z__, int *pp,
	 int *n0in, real *dmin__, real *dmin1, real *dmin2, real *dn, 
	real *dn1, real *dn2, real *tau, int *ttype);

/* Subroutine */ int slasq5_(int *i0, int *n0, real *z__, int *pp,
	 real *tau, real *dmin__, real *dmin1, real *dmin2, real *dn, real *
	dnm1, real *dnm2, logical *ieee);

/* Subroutine */ int slasq6_(int *i0, int *n0, real *z__, int *pp,
	 real *dmin__, real *dmin1, real *dmin2, real *dn, real *dnm1, real *
	dnm2);

/* Subroutine */ int slasr_(char *side, char *pivot, char *direct, int *m,
	 int *n, real *c__, real *s, real *a, int *lda  	);

/* Subroutine */ int slasrt_(char *id, int *n, real *d__, int *info);

/* Subroutine */ int slassq_(int *n, real *x, int *incx, real *scale, 
	real *sumsq);

/* Subroutine */ int slasv2_(real *f, real *g, real *h__, real *ssmin, real *
	ssmax, real *snr, real *csr, real *snl, real *csl);

/* Subroutine */ int slaswp_(int *n, real *a, int *lda, int *k1, 
	int *k2, int *ipiv, int *incx);

/* Subroutine */ int slasy2_(logical *ltranl, logical *ltranr, int *isgn, 
	int *n1, int *n2, real *tl, int *ldtl, real *tr, int *
	ldtr, real *b, int *ldb, real *scale, real *x, int *ldx, real 
	*xnorm, int *info);

/* Subroutine */ int slasyf_(char *uplo, int *n, int *nb, int *kb,
	 real *a, int *lda, int *ipiv, real *w, int *ldw, int 
	*info);

/* Subroutine */ int slatbs_(char *uplo, char *trans, char *diag, char *
	normin, int *n, int *kd, real *ab, int *ldab, real *x, 
	real *scale, real *cnorm, int *info);

/* Subroutine */ int slatdf_(int *ijob, int *n, real *z__, int *
	ldz, real *rhs, real *rdsum, real *rdscal, int *ipiv, int *
	jpiv);

/* Subroutine */ int slatps_(char *uplo, char *trans, char *diag, char *
	normin, int *n, real *ap, real *x, real *scale, real *cnorm, 
	int *info);

/* Subroutine */ int slatrd_(char *uplo, int *n, int *nb, real *a, 
	int *lda, real *e, real *tau, real *w, int *ldw  	);

/* Subroutine */ int slatrs_(char *uplo, char *trans, char *diag, char *
	normin, int *n, real *a, int *lda, real *x, real *scale, real 
	*cnorm, int *info);

/* Subroutine */ int slatrz_(int *m, int *n, int *l, real *a, 
	int *lda, real *tau, real *work);

/* Subroutine */ int slatzm_(char *side, int *m, int *n, real *v, 
	int *incv, real *tau, real *c1, real *c2, int *ldc, real *
	work);

/* Subroutine */ int slauu2_(char *uplo, int *n, real *a, int *lda, 
	int *info);

/* Subroutine */ int slauum_(char *uplo, int *n, real *a, int *lda, 
	int *info);

/* Subroutine */ int slazq3_(int *i0, int *n0, real *z__, int *pp,
	 real *dmin__, real *sigma, real *desig, real *qmax, int *nfail, 
	int *iter, int *ndiv, logical *ieee, int *ttype, real *
	dmin1, real *dmin2, real *dn, real *dn1, real *dn2, real *tau);

/* Subroutine */ int slazq4_(int *i0, int *n0, real *z__, int *pp,
	 int *n0in, real *dmin__, real *dmin1, real *dmin2, real *dn, 
	real *dn1, real *dn2, real *tau, int *ttype, real *g);

/* Subroutine */ int sopgtr_(char *uplo, int *n, real *ap, real *tau, 
	real *q, int *ldq, real *work, int *info);

/* Subroutine */ int sopmtr_(char *side, char *uplo, char *trans, int *m, 
	int *n, real *ap, real *tau, real *c__, int *ldc, real *work, 
	int *info);

/* Subroutine */ int sorg2l_(int *m, int *n, int *k, real *a, 
	int *lda, real *tau, real *work, int *info);

/* Subroutine */ int sorg2r_(int *m, int *n, int *k, real *a, 
	int *lda, real *tau, real *work, int *info);

/* Subroutine */ int sorgbr_(char *vect, int *m, int *n, int *k, 
	real *a, int *lda, real *tau, real *work, int *lwork, int 
	*info);

/* Subroutine */ int sorghr_(int *n, int *ilo, int *ihi, real *a, 
	int *lda, real *tau, real *work, int *lwork, int *info);

/* Subroutine */ int sorgl2_(int *m, int *n, int *k, real *a, 
	int *lda, real *tau, real *work, int *info);

/* Subroutine */ int sorglq_(int *m, int *n, int *k, real *a, 
	int *lda, real *tau, real *work, int *lwork, int *info);

/* Subroutine */ int sorgql_(int *m, int *n, int *k, real *a, 
	int *lda, real *tau, real *work, int *lwork, int *info);

/* Subroutine */ int sorgqr_(int *m, int *n, int *k, real *a, 
	int *lda, real *tau, real *work, int *lwork, int *info);

/* Subroutine */ int sorgr2_(int *m, int *n, int *k, real *a, 
	int *lda, real *tau, real *work, int *info);

/* Subroutine */ int sorgrq_(int *m, int *n, int *k, real *a, 
	int *lda, real *tau, real *work, int *lwork, int *info);

/* Subroutine */ int sorgtr_(char *uplo, int *n, real *a, int *lda, 
	real *tau, real *work, int *lwork, int *info);

/* Subroutine */ int sorm2l_(char *side, char *trans, int *m, int *n, 
	int *k, real *a, int *lda, real *tau, real *c__, int *ldc,
	 real *work, int *info);

/* Subroutine */ int sorm2r_(char *side, char *trans, int *m, int *n, 
	int *k, real *a, int *lda, real *tau, real *c__, int *ldc,
	 real *work, int *info);

/* Subroutine */ int sormbr_(char *vect, char *side, char *trans, int *m, 
	int *n, int *k, real *a, int *lda, real *tau, real *c__,  	
	int *ldc, real *work, int *lwork, int *info);

/* Subroutine */ int sormhr_(char *side, char *trans, int *m, int *n, 
	int *ilo, int *ihi, real *a, int *lda, real *tau, real * 	
	c__, int *ldc, real *work, int *lwork, int *info);

/* Subroutine */ int sorml2_(char *side, char *trans, int *m, int *n, 
	int *k, real *a, int *lda, real *tau, real *c__, int *ldc,
	 real *work, int *info);

/* Subroutine */ int sormlq_(char *side, char *trans, int *m, int *n, 
	int *k, real *a, int *lda, real *tau, real *c__, int *ldc, 	 
	real *work, int *lwork, int *info);

/* Subroutine */ int sormql_(char *side, char *trans, int *m, int *n, 
	int *k, real *a, int *lda, real *tau, real *c__, int *ldc, 	 
	real *work, int *lwork, int *info);

/* Subroutine */ int sormqr_(char *side, char *trans, int *m, int *n, 
	int *k, real *a, int *lda, real *tau, real *c__, int *ldc, 	 
	real *work, int *lwork, int *info);

/* Subroutine */ int sormr2_(char *side, char *trans, int *m, int *n, 
	int *k, real *a, int *lda, real *tau, real *c__, int *ldc,
	 real *work, int *info);

/* Subroutine */ int sormr3_(char *side, char *trans, int *m, int *n, 
	int *k, int *l, real *a, int *lda, real *tau, real *c__, 
	int *ldc, real *work, int *info);

/* Subroutine */ int sormrq_(char *side, char *trans, int *m, int *n, 
	int *k, real *a, int *lda, real *tau, real *c__, int *ldc, 	 
	real *work, int *lwork, int *info);

/* Subroutine */ int sormrz_(char *side, char *trans, int *m, int *n, 
	int *k, int *l, real *a, int *lda, real *tau, real *c__,  	
	int *ldc, real *work, int *lwork, int *info);

/* Subroutine */ int sormtr_(char *side, char *uplo, char *trans, int *m, 
	int *n, real *a, int *lda, real *tau, real *c__, int *ldc, 	 
	real *work, int *lwork, int *info);

/* Subroutine */ int spbcon_(char *uplo, int *n, int *kd, real *ab, 
	int *ldab, real *anorm, real *rcond, real *work, int *iwork, 
	int *info);

/* Subroutine */ int spbequ_(char *uplo, int *n, int *kd, real *ab, 
	int *ldab, real *s, real *scond, real *amax, int *info);

/* Subroutine */ int spbrfs_(char *uplo, int *n, int *kd, int *
	nrhs, real *ab, int *ldab, real *afb, int *ldafb, real *b, 
	int *ldb, real *x, int *ldx, real *ferr, real *berr, real *
	work, int *iwork, int *info);

/* Subroutine */ int spbstf_(char *uplo, int *n, int *kd, real *ab, 
	int *ldab, int *info);

/* Subroutine */ int spbsv_(char *uplo, int *n, int *kd, int *
	nrhs, real *ab, int *ldab, real *b, int *ldb, int *info);

/* Subroutine */ int spbsvx_(char *fact, char *uplo, int *n, int *kd, 
	int *nrhs, real *ab, int *ldab, real *afb, int *ldafb, 
	char *equed, real *s, real *b, int *ldb, real *x, int *ldx, 
	real *rcond, real *ferr, real *berr, real *work, int *iwork, 
	int *info);

/* Subroutine */ int spbtf2_(char *uplo, int *n, int *kd, real *ab, 
	int *ldab, int *info);

/* Subroutine */ int spbtrf_(char *uplo, int *n, int *kd, real *ab, 
	int *ldab, int *info);

/* Subroutine */ int spbtrs_(char *uplo, int *n, int *kd, int *
	nrhs, real *ab, int *ldab, real *b, int *ldb, int *info);

/* Subroutine */ int spocon_(char *uplo, int *n, real *a, int *lda, 
	real *anorm, real *rcond, real *work, int *iwork, int *info);

/* Subroutine */ int spoequ_(int *n, real *a, int *lda, real *s, real 
	*scond, real *amax, int *info);

/* Subroutine */ int sporfs_(char *uplo, int *n, int *nrhs, real *a, 
	int *lda, real *af, int *ldaf, real *b, int *ldb, real *x,
	 int *ldx, real *ferr, real *berr, real *work, int *iwork, 
	int *info);

/* Subroutine */ int sposv_(char *uplo, int *n, int *nrhs, real *a, 
	int *lda, real *b, int *ldb, int *info);

/* Subroutine */ int sposvx_(char *fact, char *uplo, int *n, int *
	nrhs, real *a, int *lda, real *af, int *ldaf, char *equed, 
	real *s, real *b, int *ldb, real *x, int *ldx, real *rcond, 
	real *ferr, real *berr, real *work, int *iwork, int *info);

/* Subroutine */ int spotf2_(char *uplo, int *n, real *a, int *lda, 
	int *info);

/* Subroutine */ int spotrf_(char *uplo, int *n, real *a, int *lda, 
	int *info);

/* Subroutine */ int spotri_(char *uplo, int *n, real *a, int *lda, 
	int *info);

/* Subroutine */ int spotrs_(char *uplo, int *n, int *nrhs, real *a, 
	int *lda, real *b, int *ldb, int *info);

/* Subroutine */ int sppcon_(char *uplo, int *n, real *ap, real *anorm, 
	real *rcond, real *work, int *iwork, int *info);

/* Subroutine */ int sppequ_(char *uplo, int *n, real *ap, real *s, real *
	scond, real *amax, int *info);

/* Subroutine */ int spprfs_(char *uplo, int *n, int *nrhs, real *ap, 
	real *afp, real *b, int *ldb, real *x, int *ldx, real *ferr, 
	real *berr, real *work, int *iwork, int *info);

/* Subroutine */ int sppsv_(char *uplo, int *n, int *nrhs, real *ap, 
	real *b, int *ldb, int *info);

/* Subroutine */ int sppsvx_(char *fact, char *uplo, int *n, int *
	nrhs, real *ap, real *afp, char *equed, real *s, real *b, int *
	ldb, real *x, int *ldx, real *rcond, real *ferr, real *berr, real 
	*work, int *iwork, int *info);

/* Subroutine */ int spptrf_(char *uplo, int *n, real *ap, int *info);

/* Subroutine */ int spptri_(char *uplo, int *n, real *ap, int *info);

/* Subroutine */ int spptrs_(char *uplo, int *n, int *nrhs, real *ap, 
	real *b, int *ldb, int *info);

/* Subroutine */ int sptcon_(int *n, real *d__, real *e, real *anorm, 
	real *rcond, real *work, int *info);

/* Subroutine */ int spteqr_(char *compz, int *n, real *d__, real *e, 
	real *z__, int *ldz, real *work, int *info);

/* Subroutine */ int sptrfs_(int *n, int *nrhs, real *d__, real *e, 
	real *df, real *ef, real *b, int *ldb, real *x, int *ldx, 
	real *ferr, real *berr, real *work, int *info);

/* Subroutine */ int sptsv_(int *n, int *nrhs, real *d__, real *e, 
	real *b, int *ldb, int *info);

/* Subroutine */ int sptsvx_(char *fact, int *n, int *nrhs, real *d__,
	 real *e, real *df, real *ef, real *b, int *ldb, real *x, int 
	*ldx, real *rcond, real *ferr, real *berr, real *work, int *info);

/* Subroutine */ int spttrf_(int *n, real *d__, real *e, int *info);

/* Subroutine */ int spttrs_(int *n, int *nrhs, real *d__, real *e, 
	real *b, int *ldb, int *info);

/* Subroutine */ int sptts2_(int *n, int *nrhs, real *d__, real *e, 
	real *b, int *ldb);

/* Subroutine */ int srscl_(int *n, real *sa, real *sx, int *incx);

/* Subroutine */ int ssbev_(char *jobz, char *uplo, int *n, int *kd, 
	real *ab, int *ldab, real *w, real *z__, int *ldz, real *work,
	 int *info);

/* Subroutine */ int ssbevd_(char *jobz, char *uplo, int *n, int *kd, 
	real *ab, int *ldab, real *w, real *z__, int *ldz, real *work,
	 int *lwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int ssbevx_(char *jobz, char *range, char *uplo, int *n, 
	int *kd, real *ab, int *ldab, real *q, int *ldq, real *vl,
	 real *vu, int *il, int *iu, real *abstol, int *m, real *
	w, real *z__, int *ldz, real *work, int *iwork, int *
	ifail, int *info);

/* Subroutine */ int ssbgst_(char *vect, char *uplo, int *n, int *ka, 
	int *kb, real *ab, int *ldab, real *bb, int *ldbb, real *
	x, int *ldx, real *work, int *info);

/* Subroutine */ int ssbgv_(char *jobz, char *uplo, int *n, int *ka, 
	int *kb, real *ab, int *ldab, real *bb, int *ldbb, real *
	w, real *z__, int *ldz, real *work, int *info);

/* Subroutine */ int ssbgvd_(char *jobz, char *uplo, int *n, int *ka, 
	int *kb, real *ab, int *ldab, real *bb, int *ldbb, real *
	w, real *z__, int *ldz, real *work, int *lwork, int *
	iwork, int *liwork, int *info);

/* Subroutine */ int ssbgvx_(char *jobz, char *range, char *uplo, int *n, 
	int *ka, int *kb, real *ab, int *ldab, real *bb, int *
	ldbb, real *q, int *ldq, real *vl, real *vu, int *il, int 
	*iu, real *abstol, int *m, real *w, real *z__, int *ldz, real 
	*work, int *iwork, int *ifail, int *info);

/* Subroutine */ int ssbtrd_(char *vect, char *uplo, int *n, int *kd, 
	real *ab, int *ldab, real *d__, real *e, real *q, int *ldq, 
	real *work, int *info);

/* Subroutine */ int sspcon_(char *uplo, int *n, real *ap, int *ipiv, 
	real *anorm, real *rcond, real *work, int *iwork, int *info);

/* Subroutine */ int sspev_(char *jobz, char *uplo, int *n, real *ap, 
	real *w, real *z__, int *ldz, real *work, int *info);

/* Subroutine */ int sspevd_(char *jobz, char *uplo, int *n, real *ap, 
	real *w, real *z__, int *ldz, real *work, int *lwork, int 
	*iwork, int *liwork, int *info);

/* Subroutine */ int sspevx_(char *jobz, char *range, char *uplo, int *n, 
	real *ap, real *vl, real *vu, int *il, int *iu, real *abstol, 
	int *m, real *w, real *z__, int *ldz, real *work, int *
	iwork, int *ifail, int *info);

/* Subroutine */ int sspgst_(int *itype, char *uplo, int *n, real *ap,
	 real *bp, int *info);

/* Subroutine */ int sspgv_(int *itype, char *jobz, char *uplo, int *
	n, real *ap, real *bp, real *w, real *z__, int *ldz, real *work, 
	int *info);

/* Subroutine */ int sspgvd_(int *itype, char *jobz, char *uplo, int *
	n, real *ap, real *bp, real *w, real *z__, int *ldz, real *work, 
	int *lwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int sspgvx_(int *itype, char *jobz, char *range, char *
	uplo, int *n, real *ap, real *bp, real *vl, real *vu, int *il,
	 int *iu, real *abstol, int *m, real *w, real *z__, int *
	ldz, real *work, int *iwork, int *ifail, int *info);

/* Subroutine */ int ssprfs_(char *uplo, int *n, int *nrhs, real *ap, 
	real *afp, int *ipiv, real *b, int *ldb, real *x, int *
	ldx, real *ferr, real *berr, real *work, int *iwork, int *
	info);

/* Subroutine */ int sspsv_(char *uplo, int *n, int *nrhs, real *ap, 
	int *ipiv, real *b, int *ldb, int *info);

/* Subroutine */ int sspsvx_(char *fact, char *uplo, int *n, int *
	nrhs, real *ap, real *afp, int *ipiv, real *b, int *ldb, real 
	*x, int *ldx, real *rcond, real *ferr, real *berr, real *work, 
	int *iwork, int *info);

/* Subroutine */ int ssptrd_(char *uplo, int *n, real *ap, real *d__, 
	real *e, real *tau, int *info);

/* Subroutine */ int ssptrf_(char *uplo, int *n, real *ap, int *ipiv, 
	int *info);

/* Subroutine */ int ssptri_(char *uplo, int *n, real *ap, int *ipiv, 
	real *work, int *info);

/* Subroutine */ int ssptrs_(char *uplo, int *n, int *nrhs, real *ap, 
	int *ipiv, real *b, int *ldb, int *info);

/* Subroutine */ int sstebz_(char *range, char *order, int *n, real *vl, 
	real *vu, int *il, int *iu, real *abstol, real *d__, real *e, 
	int *m, int *nsplit, real *w, int *iblock, int *
	isplit, real *work, int *iwork, int *info);

/* Subroutine */ int sstedc_(char *compz, int *n, real *d__, real *e, 
	real *z__, int *ldz, real *work, int *lwork, int *iwork, 
	int *liwork, int *info);

/* Subroutine */ int sstegr_(char *jobz, char *range, int *n, real *d__, 
	real *e, real *vl, real *vu, int *il, int *iu, real *abstol, 
	int *m, real *w, real *z__, int *ldz, int *isuppz, real *
	work, int *lwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int sstein_(int *n, real *d__, real *e, int *m, real 
	*w, int *iblock, int *isplit, real *z__, int *ldz, real *
	work, int *iwork, int *ifail, int *info);

/* Subroutine */ int sstemr_(char *jobz, char *range, int *n, real *d__, 
	real *e, real *vl, real *vu, int *il, int *iu, int *m, 
	real *w, real *z__, int *ldz, int *nzc, int *isuppz, 
	logical *tryrac, real *work, int *lwork, int *iwork, int *
	liwork, int *info);

/* Subroutine */ int ssteqr_(char *compz, int *n, real *d__, real *e, 
	real *z__, int *ldz, real *work, int *info);

/* Subroutine */ int ssterf_(int *n, real *d__, real *e, int *info);

/* Subroutine */ int sstev_(char *jobz, int *n, real *d__, real *e, real *
	z__, int *ldz, real *work, int *info);

/* Subroutine */ int sstevd_(char *jobz, int *n, real *d__, real *e, real 
	*z__, int *ldz, real *work, int *lwork, int *iwork, 
	int *liwork, int *info);

/* Subroutine */ int sstevr_(char *jobz, char *range, int *n, real *d__, 
	real *e, real *vl, real *vu, int *il, int *iu, real *abstol, 
	int *m, real *w, real *z__, int *ldz, int *isuppz, real *
	work, int *lwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int sstevx_(char *jobz, char *range, int *n, real *d__, 
	real *e, real *vl, real *vu, int *il, int *iu, real *abstol, 
	int *m, real *w, real *z__, int *ldz, real *work, int *
	iwork, int *ifail, int *info);

/* Subroutine */ int ssycon_(char *uplo, int *n, real *a, int *lda, 
	int *ipiv, real *anorm, real *rcond, real *work, int *iwork, 
	int *info);

/* Subroutine */ int ssyev_(char *jobz, char *uplo, int *n, real *a, 
	int *lda, real *w, real *work, int *lwork, int *info);

/* Subroutine */ int ssyevd_(char *jobz, char *uplo, int *n, real *a, 
	int *lda, real *w, real *work, int *lwork, int *iwork, 
	int *liwork, int *info);

/* Subroutine */ int ssyevr_(char *jobz, char *range, char *uplo, int *n, 
	real *a, int *lda, real *vl, real *vu, int *il, int *iu, 
	real *abstol, int *m, real *w, real *z__, int *ldz, int *
	isuppz, real *work, int *lwork, int *iwork, int *liwork, 
	int *info);

/* Subroutine */ int ssyevx_(char *jobz, char *range, char *uplo, int *n, 
	real *a, int *lda, real *vl, real *vu, int *il, int *iu, 
	real *abstol, int *m, real *w, real *z__, int *ldz, real *
	work, int *lwork, int *iwork, int *ifail, int *info);

/* Subroutine */ int ssygs2_(int *itype, char *uplo, int *n, real *a, 
	int *lda, real *b, int *ldb, int *info);

/* Subroutine */ int ssygst_(int *itype, char *uplo, int *n, real *a, 
	int *lda, real *b, int *ldb, int *info);

/* Subroutine */ int ssygv_(int *itype, char *jobz, char *uplo, int *
	n, real *a, int *lda, real *b, int *ldb, real *w, real *work, 
	int *lwork, int *info);

/* Subroutine */ int ssygvd_(int *itype, char *jobz, char *uplo, int *
	n, real *a, int *lda, real *b, int *ldb, real *w, real *work, 
	int *lwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int ssygvx_(int *itype, char *jobz, char *range, char *
	uplo, int *n, real *a, int *lda, real *b, int *ldb, real *
	vl, real *vu, int *il, int *iu, real *abstol, int *m, 
	real *w, real *z__, int *ldz, real *work, int *lwork, int  	
	*iwork, int *ifail, int *info);

/* Subroutine */ int ssyrfs_(char *uplo, int *n, int *nrhs, real *a, 
	int *lda, real *af, int *ldaf, int *ipiv, real *b, 
	int *ldb, real *x, int *ldx, real *ferr, real *berr, real *
	work, int *iwork, int *info);

/* Subroutine */ int ssysv_(char *uplo, int *n, int *nrhs, real *a, 
	int *lda, int *ipiv, real *b, int *ldb, real *work, 
	int *lwork, int *info);

/* Subroutine */ int ssysvx_(char *fact, char *uplo, int *n, int *
	nrhs, real *a, int *lda, real *af, int *ldaf, int *ipiv, 
	real *b, int *ldb, real *x, int *ldx, real *rcond, real *ferr,
	 real *berr, real *work, int *lwork, int *iwork, int *
	info);

/* Subroutine */ int ssytd2_(char *uplo, int *n, real *a, int *lda, 
	real *d__, real *e, real *tau, int *info);

/* Subroutine */ int ssytf2_(char *uplo, int *n, real *a, int *lda, 
	int *ipiv, int *info);

/* Subroutine */ int ssytrd_(char *uplo, int *n, real *a, int *lda, 
	real *d__, real *e, real *tau, real *work, int *lwork, int *
	info);

/* Subroutine */ int ssytrf_(char *uplo, int *n, real *a, int *lda,  	
    int *ipiv, real *work, int *lwork, int *info);

/* Subroutine */ int ssytri_(char *uplo, int *n, real *a, int *lda, 
	int *ipiv, real *work, int *info);

/* Subroutine */ int ssytrs_(char *uplo, int *n, int *nrhs, real *a, 
	int *lda, int *ipiv, real *b, int *ldb, int *info);

/* Subroutine */ int stbcon_(char *norm, char *uplo, char *diag, int *n, 
	int *kd, real *ab, int *ldab, real *rcond, real *work, 
	int *iwork, int *info);

/* Subroutine */ int stbrfs_(char *uplo, char *trans, char *diag, int *n, 
	int *kd, int *nrhs, real *ab, int *ldab, real *b, int 
	*ldb, real *x, int *ldx, real *ferr, real *berr, real *work, 
	int *iwork, int *info);

/* Subroutine */ int stbtrs_(char *uplo, char *trans, char *diag, int *n, 
	int *kd, int *nrhs, real *ab, int *ldab, real *b, int 
	*ldb, int *info);

/* Subroutine */ int stgevc_(char *side, char *howmny, logical *select, 
	int *n, real *s, int *lds, real *p, int *ldp, real *vl, 
	int *ldvl, real *vr, int *ldvr, int *mm, int *m, real 
	*work, int *info);

/* Subroutine */ int stgex2_(logical *wantq, logical *wantz, int *n, real 
	*a, int *lda, real *b, int *ldb, real *q, int *ldq, real *
	z__, int *ldz, int *j1, int *n1, int *n2, real *work, 
	int *lwork, int *info);

/* Subroutine */ int stgexc_(logical *wantq, logical *wantz, int *n, real 
	*a, int *lda, real *b, int *ldb, real *q, int *ldq, real *
	z__, int *ldz, int *ifst, int *ilst, real *work, int *
	lwork, int *info);

/* Subroutine */ int stgsen_(int *ijob, logical *wantq, logical *wantz, 
	logical *select, int *n, real *a, int *lda, real *b, int *
	ldb, real *alphar, real *alphai, real *beta, real *q, int *ldq, 
	real *z__, int *ldz, int *m, real *pl, real *pr, real *dif, 
	real *work, int *lwork, int *iwork, int *liwork, int *
	info);

/* Subroutine */ int stgsja_(char *jobu, char *jobv, char *jobq, int *m, 
	int *p, int *n, int *k, int *l, real *a, int *lda,
	 real *b, int *ldb, real *tola, real *tolb, real *alpha, real *
	beta, real *u, int *ldu, real *v, int *ldv, real *q, int *
	ldq, real *work, int *ncycle, int *info);

/* Subroutine */ int stgsna_(char *job, char *howmny, logical *select, 
	int *n, real *a, int *lda, real *b, int *ldb, real *vl, 
	int *ldvl, real *vr, int *ldvr, real *s, real *dif, int *
	mm, int *m, real *work, int *lwork, int *iwork, int *
	info);

/* Subroutine */ int stgsy2_(char *trans, int *ijob, int *m, int *
	n, real *a, int *lda, real *b, int *ldb, real *c__, int *
	ldc, real *d__, int *ldd, real *e, int *lde, real *f, int 
	*ldf, real *scale, real *rdsum, real *rdscal, int *iwork, int 
	*pq, int *info);

/* Subroutine */ int stgsyl_(char *trans, int *ijob, int *m, int *
	n, real *a, int *lda, real *b, int *ldb, real *c__, int *
	ldc, real *d__, int *ldd, real *e, int *lde, real *f, int 
	*ldf, real *scale, real *dif, real *work, int *lwork, int *
	iwork, int *info);

/* Subroutine */ int stpcon_(char *norm, char *uplo, char *diag, int *n, 
	real *ap, real *rcond, real *work, int *iwork, int *info);

/* Subroutine */ int stprfs_(char *uplo, char *trans, char *diag, int *n, 
	int *nrhs, real *ap, real *b, int *ldb, real *x, int *ldx,
	 real *ferr, real *berr, real *work, int *iwork, int *info);

/* Subroutine */ int stptri_(char *uplo, char *diag, int *n, real *ap, 
	int *info);

/* Subroutine */ int stptrs_(char *uplo, char *trans, char *diag, int *n, 
	int *nrhs, real *ap, real *b, int *ldb, int *info);

/* Subroutine */ int strcon_(char *norm, char *uplo, char *diag, int *n, 
	real *a, int *lda, real *rcond, real *work, int *iwork, 
	int *info);

/* Subroutine */ int strevc_(char *side, char *howmny, logical *select, 
	int *n, real *t, int *ldt, real *vl, int *ldvl, real *vr, 
	int *ldvr, int *mm, int *m, real *work, int *info);

/* Subroutine */ int strexc_(char *compq, int *n, real *t, int *ldt, 
	real *q, int *ldq, int *ifst, int *ilst, real *work, 
	int *info);

/* Subroutine */ int strrfs_(char *uplo, char *trans, char *diag, int *n, 
	int *nrhs, real *a, int *lda, real *b, int *ldb, real *x, 
	int *ldx, real *ferr, real *berr, real *work, int *iwork, 
	int *info);

/* Subroutine */ int strsen_(char *job, char *compq, logical *select, int 
	*n, real *t, int *ldt, real *q, int *ldq, real *wr, real *wi, 
	int *m, real *s, real *sep, real *work, int *lwork, int *
	iwork, int *liwork, int *info);

/* Subroutine */ int strsna_(char *job, char *howmny, logical *select, 
	int *n, real *t, int *ldt, real *vl, int *ldvl, real *vr, 
	int *ldvr, real *s, real *sep, int *mm, int *m, real *
	work, int *ldwork, int *iwork, int *info);

/* Subroutine */ int strsyl_(char *trana, char *tranb, int *isgn, int 
	*m, int *n, real *a, int *lda, real *b, int *ldb, real *
	c__, int *ldc, real *scale, int *info);

/* Subroutine */ int strti2_(char *uplo, char *diag, int *n, real *a, 
	int *lda, int *info);

/* Subroutine */ int strtri_(char *uplo, char *diag, int *n, real *a, 
	int *lda, int *info);

/* Subroutine */ int strtrs_(char *uplo, char *trans, char *diag, int *n, 
	int *nrhs, real *a, int *lda, real *b, int *ldb, int *
	info);

/* Subroutine */ int stzrqf_(int *m, int *n, real *a, int *lda, 
	real *tau, int *info);

/* Subroutine */ int stzrzf_(int *m, int *n, real *a, int *lda, 
	real *tau, real *work, int *lwork, int *info);

/* Subroutine */ int xerbla_(char *srname, int *info);

/* Subroutine */ int zbdsqr_(char *uplo, int *n, int *ncvt, int *
	nru, int *ncc, double *d__, double *e, doublecomplex *vt, 
	int *ldvt, doublecomplex *u, int *ldu, doublecomplex *c__, 
	int *ldc, double *rwork, int *info);

/* Subroutine */ int zcgesv_(int *n, int *nrhs, doublecomplex *a, 
	int *lda, int *ipiv, doublecomplex *b, int *ldb, 
	doublecomplex *x, int *ldx, doublecomplex *work, complex *swork, 
	int *iter, int *info);

/* Subroutine */ int zdrscl_(int *n, double *sa, doublecomplex *sx, 
	int *incx);

/* Subroutine */ int zgbbrd_(char *vect, int *m, int *n, int *ncc,
	 int *kl, int *ku, doublecomplex *ab, int *ldab, 
	double *d__, double *e, doublecomplex *q, int *ldq, 
	doublecomplex *pt, int *ldpt, doublecomplex *c__, int *ldc, 
	doublecomplex *work, double *rwork, int *info);

/* Subroutine */ int zgbcon_(char *norm, int *n, int *kl, int *ku,
	 doublecomplex *ab, int *ldab, int *ipiv, double *anorm, 
	double *rcond, doublecomplex *work, double *rwork, int *
	info);

/* Subroutine */ int zgbequ_(int *m, int *n, int *kl, int *ku,
	 doublecomplex *ab, int *ldab, double *r__, double *c__, 
	double *rowcnd, double *colcnd, double *amax, int *
	info);

/* Subroutine */ int zgbrfs_(char *trans, int *n, int *kl, int *
	ku, int *nrhs, doublecomplex *ab, int *ldab, doublecomplex *
	afb, int *ldafb, int *ipiv, doublecomplex *b, int *ldb, 
	doublecomplex *x, int *ldx, double *ferr, double *berr, 
	doublecomplex *work, double *rwork, int *info);

/* Subroutine */ int zgbsv_(int *n, int *kl, int *ku, int *
	nrhs, doublecomplex *ab, int *ldab, int *ipiv, doublecomplex *
	b, int *ldb, int *info);

/* Subroutine */ int zgbsvx_(char *fact, char *trans, int *n, int *kl,
	 int *ku, int *nrhs, doublecomplex *ab, int *ldab, 
	doublecomplex *afb, int *ldafb, int *ipiv, char *equed, 
	double *r__, double *c__, doublecomplex *b, int *ldb, 
	doublecomplex *x, int *ldx, double *rcond, double *ferr, 
	double *berr, doublecomplex *work, double *rwork, int *
	info);

/* Subroutine */ int zgbtf2_(int *m, int *n, int *kl, int *ku,
	 doublecomplex *ab, int *ldab, int *ipiv, int *info);

/* Subroutine */ int zgbtrf_(int *m, int *n, int *kl, int *ku,
	 doublecomplex *ab, int *ldab, int *ipiv, int *info);

/* Subroutine */ int zgbtrs_(char *trans, int *n, int *kl, int *
	ku, int *nrhs, doublecomplex *ab, int *ldab, int *ipiv, 
	doublecomplex *b, int *ldb, int *info);

/* Subroutine */ int zgebak_(char *job, char *side, int *n, int *ilo, 
	int *ihi, double *scale, int *m, doublecomplex *v, 
	int *ldv, int *info);

/* Subroutine */ int zgebal_(char *job, int *n, doublecomplex *a, int 
	*lda, int *ilo, int *ihi, double *scale, int *info);

/* Subroutine */ int zgebd2_(int *m, int *n, doublecomplex *a, 
	int *lda, double *d__, double *e, doublecomplex *tauq, 
	doublecomplex *taup, doublecomplex *work, int *info);

/* Subroutine */ int zgebrd_(int *m, int *n, doublecomplex *a, 
	int *lda, double *d__, double *e, doublecomplex *tauq, 
	doublecomplex *taup, doublecomplex *work, int *lwork, int *
	info);

/* Subroutine */ int zgecon_(char *norm, int *n, doublecomplex *a, 
	int *lda, double *anorm, double *rcond, doublecomplex *
	work, double *rwork, int *info);

/* Subroutine */ int zgeequ_(int *m, int *n, doublecomplex *a, 
	int *lda, double *r__, double *c__, double *rowcnd, 
	double *colcnd, double *amax, int *info);

/* Subroutine */ int zgees_(char *jobvs, char *sort, L_fp select, int *n, 
	doublecomplex *a, int *lda, int *sdim, doublecomplex *w, 
	doublecomplex *vs, int *ldvs, doublecomplex *work, int *lwork,
	 double *rwork, logical *bwork, int *info);

/* Subroutine */ int zgeesx_(char *jobvs, char *sort, L_fp select, char *
	sense, int *n, doublecomplex *a, int *lda, int *sdim, 
	doublecomplex *w, doublecomplex *vs, int *ldvs, double *
	rconde, double *rcondv, doublecomplex *work, int *lwork, 
	double *rwork, logical *bwork, int *info);

/* Subroutine */ int zgeev_(char *jobvl, char *jobvr, int *n, 
	doublecomplex *a, int *lda, doublecomplex *w, doublecomplex *vl, 
	int *ldvl, doublecomplex *vr, int *ldvr, doublecomplex *work, 
	int *lwork, double *rwork, int *info);

/* Subroutine */ int zgeevx_(char *balanc, char *jobvl, char *jobvr, char *
	sense, int *n, doublecomplex *a, int *lda, doublecomplex *w, 
	doublecomplex *vl, int *ldvl, doublecomplex *vr, int *ldvr, 
	int *ilo, int *ihi, double *scale, double *abnrm, 
	double *rconde, double *rcondv, doublecomplex *work, int * 	
	lwork, double *rwork, int *info);

/* Subroutine */ int zgegs_(char *jobvsl, char *jobvsr, int *n, 
	doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	doublecomplex *alpha, doublecomplex *beta, doublecomplex *vsl, 
	int *ldvsl, doublecomplex *vsr, int *ldvsr, doublecomplex * 	
	work, int *lwork, double *rwork, int *info);

/* Subroutine */ int zgegv_(char *jobvl, char *jobvr, int *n, 
	doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	doublecomplex *alpha, doublecomplex *beta, doublecomplex *vl, int 
	*ldvl, doublecomplex *vr, int *ldvr, doublecomplex *work, int 
	*lwork, double *rwork, int *info);

/* Subroutine */ int zgehd2_(int *n, int *ilo, int *ihi, 
	doublecomplex *a, int *lda, doublecomplex *tau, doublecomplex *
	work, int *info);

/* Subroutine */ int zgehrd_(int *n, int *ilo, int *ihi, 
	doublecomplex *a, int *lda, doublecomplex *tau, doublecomplex *
	work, int *lwork, int *info);

/* Subroutine */ int zgelq2_(int *m, int *n, doublecomplex *a, 
	int *lda, doublecomplex *tau, doublecomplex *work, int *info);

/* Subroutine */ int zgelqf_(int *m, int *n, doublecomplex *a, 
	int *lda, doublecomplex *tau, doublecomplex *work, int *lwork,
	 int *info);

/* Subroutine */ int zgels_(char *trans, int *m, int *n, int *
	nrhs, doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	doublecomplex *work, int *lwork, int *info);

/* Subroutine */ int zgelsd_(int *m, int *n, int *nrhs, 
	doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	double *s, double *rcond, int *rank, doublecomplex *work, 
	int *lwork, double *rwork, int *iwork, int *info);

/* Subroutine */ int zgelss_(int *m, int *n, int *nrhs, 
	doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	double *s, double *rcond, int *rank, doublecomplex *work, 
	int *lwork, double *rwork, int *info);

/* Subroutine */ int zgelsx_(int *m, int *n, int *nrhs, 
	doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	int *jpvt, double *rcond, int *rank, doublecomplex *work, 
	double *rwork, int *info);

/* Subroutine */ int zgelsy_(int *m, int *n, int *nrhs, 
	doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	int *jpvt, double *rcond, int *rank, doublecomplex *work, 
	int *lwork, double *rwork, int *info);

/* Subroutine */ int zgeql2_(int *m, int *n, doublecomplex *a, 
	int *lda, doublecomplex *tau, doublecomplex *work, int *info);

/* Subroutine */ int zgeqlf_(int *m, int *n, doublecomplex *a, 
	int *lda, doublecomplex *tau, doublecomplex *work, int *lwork,
	 int *info);

/* Subroutine */ int zgeqp3_(int *m, int *n, doublecomplex *a, 
	int *lda, int *jpvt, doublecomplex *tau, doublecomplex *work, 
	int *lwork, double *rwork, int *info);

/* Subroutine */ int zgeqpf_(int *m, int *n, doublecomplex *a, 
	int *lda, int *jpvt, doublecomplex *tau, doublecomplex *work, 
	double *rwork, int *info);

/* Subroutine */ int zgeqr2_(int *m, int *n, doublecomplex *a, 
	int *lda, doublecomplex *tau, doublecomplex *work, int *info);

/* Subroutine */ int zgeqrf_(int *m, int *n, doublecomplex *a, 
	int *lda, doublecomplex *tau, doublecomplex *work, int *lwork,
	 int *info);

/* Subroutine */ int zgerfs_(char *trans, int *n, int *nrhs, 
	doublecomplex *a, int *lda, doublecomplex *af, int *ldaf, 
	int *ipiv, doublecomplex *b, int *ldb, doublecomplex *x, 
	int *ldx, double *ferr, double *berr, doublecomplex *work,
	 double *rwork, int *info);

/* Subroutine */ int zgerq2_(int *m, int *n, doublecomplex *a, 
	int *lda, doublecomplex *tau, doublecomplex *work, int *info);

/* Subroutine */ int zgerqf_(int *m, int *n, doublecomplex *a, 
	int *lda, doublecomplex *tau, doublecomplex *work, int *lwork,
	 int *info);

/* Subroutine */ int zgesc2_(int *n, doublecomplex *a, int *lda, 
	doublecomplex *rhs, int *ipiv, int *jpiv, double *scale);

/* Subroutine */ int zgesdd_(char *jobz, int *m, int *n, 
	doublecomplex *a, int *lda, double *s, doublecomplex *u, 
	int *ldu, doublecomplex *vt, int *ldvt, doublecomplex *work, 
	int *lwork, double *rwork, int *iwork, int *info);

/* Subroutine */ int zgesv_(int *n, int *nrhs, doublecomplex *a, 
	int *lda, int *ipiv, doublecomplex *b, int *ldb, int *
	info);

/* Subroutine */ int zgesvd_(char *jobu, char *jobvt, int *m, int *n, 
	doublecomplex *a, int *lda, double *s, doublecomplex *u, 
	int *ldu, doublecomplex *vt, int *ldvt, doublecomplex *work, 
	int *lwork, double *rwork, int *info);

/* Subroutine */ int zgesvx_(char *fact, char *trans, int *n, int *
	nrhs, doublecomplex *a, int *lda, doublecomplex *af, int *
	ldaf, int *ipiv, char *equed, double *r__, double *c__, 
	doublecomplex *b, int *ldb, doublecomplex *x, int *ldx, 
	double *rcond, double *ferr, double *berr, doublecomplex *
	work, double *rwork, int *info);

/* Subroutine */ int zgetc2_(int *n, doublecomplex *a, int *lda, 
	int *ipiv, int *jpiv, int *info);

/* Subroutine */ int zgetf2_(int *m, int *n, doublecomplex *a, 
	int *lda, int *ipiv, int *info);

/* Subroutine */ int zgetrf_(int *m, int *n, doublecomplex *a, 
	int *lda, int *ipiv, int *info);

/* Subroutine */ int zgetri_(int *n, doublecomplex *a, int *lda, 
	int *ipiv, doublecomplex *work, int *lwork, int *info);

/* Subroutine */ int zgetrs_(char *trans, int *n, int *nrhs, 
	doublecomplex *a, int *lda, int *ipiv, doublecomplex *b, 
	int *ldb, int *info);

/* Subroutine */ int zggbak_(char *job, char *side, int *n, int *ilo, 
	int *ihi, double *lscale, double *rscale, int *m, 
	doublecomplex *v, int *ldv, int *info);

/* Subroutine */ int zggbal_(char *job, int *n, doublecomplex *a, int 
	*lda, doublecomplex *b, int *ldb, int *ilo, int *ihi, 
	double *lscale, double *rscale, double *work, int *
	info);

/* Subroutine */ int zgges_(char *jobvsl, char *jobvsr, char *sort, L_fp 
	selctg, int *n, doublecomplex *a, int *lda, doublecomplex *b, 
	int *ldb, int *sdim, doublecomplex *alpha, doublecomplex *
	beta, doublecomplex *vsl, int *ldvsl, doublecomplex *vsr, int 
	*ldvsr, doublecomplex *work, int *lwork, double *rwork, 
	logical *bwork, int *info);

/* Subroutine */ int zggesx_(char *jobvsl, char *jobvsr, char *sort, L_fp 
	selctg, char *sense, int *n, doublecomplex *a, int *lda, 
	doublecomplex *b, int *ldb, int *sdim, doublecomplex *alpha, 
	doublecomplex *beta, doublecomplex *vsl, int *ldvsl, 
	doublecomplex *vsr, int *ldvsr, double *rconde, double *
	rcondv, doublecomplex *work, int *lwork, double *rwork, 
	int *iwork, int *liwork, logical *bwork, int *info);

/* Subroutine */ int zggev_(char *jobvl, char *jobvr, int *n, 
	doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	doublecomplex *alpha, doublecomplex *beta, doublecomplex *vl, int 
	*ldvl, doublecomplex *vr, int *ldvr, doublecomplex *work, int
	*lwork, double *rwork, int *info);

/* Subroutine */ int zggevx_(char *balanc, char *jobvl, char *jobvr, char *
	sense, int *n, doublecomplex *a, int *lda, doublecomplex *b, 
	int *ldb, doublecomplex *alpha, doublecomplex *beta, 
	doublecomplex *vl, int *ldvl, doublecomplex *vr, int *ldvr, 
	int *ilo, int *ihi, double *lscale, double *rscale, 
	double *abnrm, double *bbnrm, double *rconde, double *
	rcondv, doublecomplex *work, int *lwork, double *rwork, 
	int *iwork, logical *bwork, int *info);

/* Subroutine */ int zggglm_(int *n, int *m, int *p, 
	doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	doublecomplex *d__, doublecomplex *x, doublecomplex *y, doublecomplex 
	*work, int *lwork, int *info);

/* Subroutine */ int zgghrd_(char *compq, char *compz, int *n, int *
	ilo, int *ihi, doublecomplex *a, int *lda, doublecomplex *b, 
	int *ldb, doublecomplex *q, int *ldq, doublecomplex *z__, 
	int *ldz, int *info);

/* Subroutine */ int zgglse_(int *m, int *n, int *p, 
	doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	doublecomplex *c__, doublecomplex *d__, doublecomplex *x, 
	doublecomplex *work, int *lwork, int *info);

/* Subroutine */ int zggqrf_(int *n, int *m, int *p, 
	doublecomplex *a, int *lda, doublecomplex *taua, doublecomplex *b,
	 int *ldb, doublecomplex *taub, doublecomplex *work, int *
	lwork, int *info);

/* Subroutine */ int zggrqf_(int *m, int *p, int *n, 
	doublecomplex *a, int *lda, doublecomplex *taua, doublecomplex *b,
	 int *ldb, doublecomplex *taub, doublecomplex *work, int *
	lwork, int *info);

/* Subroutine */ int zggsvd_(char *jobu, char *jobv, char *jobq, int *m, 
	int *n, int *p, int *k, int *l, doublecomplex *a, 
	int *lda, doublecomplex *b, int *ldb, double *alpha, 
	double *beta, doublecomplex *u, int *ldu, doublecomplex *v, 
	int *ldv, doublecomplex *q, int *ldq, doublecomplex *work, 
	double *rwork, int *iwork, int *info);

/* Subroutine */ int zggsvp_(char *jobu, char *jobv, char *jobq, int *m, 
	int *p, int *n, doublecomplex *a, int *lda, doublecomplex 
	*b, int *ldb, double *tola, double *tolb, int *k, 
	int *l, doublecomplex *u, int *ldu, doublecomplex *v, int 
	*ldv, doublecomplex *q, int *ldq, int *iwork, double *
	rwork, doublecomplex *tau, doublecomplex *work, int *info);

/* Subroutine */ int zgtcon_(char *norm, int *n, doublecomplex *dl, 
	doublecomplex *d__, doublecomplex *du, doublecomplex *du2, int *
	ipiv, double *anorm, double *rcond, doublecomplex *work, 
	int *info);

/* Subroutine */ int zgtrfs_(char *trans, int *n, int *nrhs, 
	doublecomplex *dl, doublecomplex *d__, doublecomplex *du, 
	doublecomplex *dlf, doublecomplex *df, doublecomplex *duf, 
	doublecomplex *du2, int *ipiv, doublecomplex *b, int *ldb, 
	doublecomplex *x, int *ldx, double *ferr, double *berr, 
	doublecomplex *work, double *rwork, int *info);

/* Subroutine */ int zgtsv_(int *n, int *nrhs, doublecomplex *dl, 
	doublecomplex *d__, doublecomplex *du, doublecomplex *b, int *ldb,
	 int *info);

/* Subroutine */ int zgtsvx_(char *fact, char *trans, int *n, int *
	nrhs, doublecomplex *dl, doublecomplex *d__, doublecomplex *du, 
	doublecomplex *dlf, doublecomplex *df, doublecomplex *duf, 
	doublecomplex *du2, int *ipiv, doublecomplex *b, int *ldb, 
	doublecomplex *x, int *ldx, double *rcond, double *ferr, 
	double *berr, doublecomplex *work, double *rwork, int *
	info);

/* Subroutine */ int zgttrf_(int *n, doublecomplex *dl, doublecomplex *
	d__, doublecomplex *du, doublecomplex *du2, int *ipiv, int *
	info);

/* Subroutine */ int zgttrs_(char *trans, int *n, int *nrhs, 
	doublecomplex *dl, doublecomplex *d__, doublecomplex *du, 
	doublecomplex *du2, int *ipiv, doublecomplex *b, int *ldb, 
	int *info);

/* Subroutine */ int zgtts2_(int *itrans, int *n, int *nrhs, 
	doublecomplex *dl, doublecomplex *d__, doublecomplex *du, 
	doublecomplex *du2, int *ipiv, doublecomplex *b, int *ldb);

/* Subroutine */ int zhbev_(char *jobz, char *uplo, int *n, int *kd, 
	doublecomplex *ab, int *ldab, double *w, doublecomplex *z__, 
	int *ldz, doublecomplex *work, double *rwork, int *info);

/* Subroutine */ int zhbevd_(char *jobz, char *uplo, int *n, int *kd, 
	doublecomplex *ab, int *ldab, double *w, doublecomplex *z__, 
	int *ldz, doublecomplex *work, int *lwork, double *rwork, 
	int *lrwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int zhbevx_(char *jobz, char *range, char *uplo, int *n, 
	int *kd, doublecomplex *ab, int *ldab, doublecomplex *q, 
	int *ldq, double *vl, double *vu, int *il, int *
	iu, double *abstol, int *m, double *w, doublecomplex *z__,
	 int *ldz, doublecomplex *work, double *rwork, int *iwork,
	 int *ifail, int *info);

/* Subroutine */ int zhbgst_(char *vect, char *uplo, int *n, int *ka, 
	int *kb, doublecomplex *ab, int *ldab, doublecomplex *bb, 
	int *ldbb, doublecomplex *x, int *ldx, doublecomplex *work, 
	double *rwork, int *info);

/* Subroutine */ int zhbgv_(char *jobz, char *uplo, int *n, int *ka, 
	int *kb, doublecomplex *ab, int *ldab, doublecomplex *bb, 
	int *ldbb, double *w, doublecomplex *z__, int *ldz, 
	doublecomplex *work, double *rwork, int *info);

/* Subroutine */ int zhbgvd_(char *jobz, char *uplo, int *n, int *ka, 
	int *kb, doublecomplex *ab, int *ldab, doublecomplex *bb, 
	int *ldbb, double *w, doublecomplex *z__, int *ldz, 
	doublecomplex *work, int *lwork, double *rwork, int *
	lrwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int zhbgvx_(char *jobz, char *range, char *uplo, int *n, 
	int *ka, int *kb, doublecomplex *ab, int *ldab, 
	doublecomplex *bb, int *ldbb, doublecomplex *q, int *ldq, 
	double *vl, double *vu, int *il, int *iu, double *
	abstol, int *m, double *w, doublecomplex *z__, int *ldz, 
	doublecomplex *work, double *rwork, int *iwork, int *
	ifail, int *info);

/* Subroutine */ int zhbtrd_(char *vect, char *uplo, int *n, int *kd, 
	doublecomplex *ab, int *ldab, double *d__, double *e, 
	doublecomplex *q, int *ldq, doublecomplex *work, int *info);

/* Subroutine */ int zhecon_(char *uplo, int *n, doublecomplex *a, 
	int *lda, int *ipiv, double *anorm, double *rcond, 
	doublecomplex *work, int *info);

/* Subroutine */ int zheev_(char *jobz, char *uplo, int *n, doublecomplex 
	*a, int *lda, double *w, doublecomplex *work, int *lwork, 
	double *rwork, int *info);

/* Subroutine */ int zheevd_(char *jobz, char *uplo, int *n, 
	doublecomplex *a, int *lda, double *w, doublecomplex *work, 
	int *lwork, double *rwork, int *lrwork, int *iwork, 
	int *liwork, int *info);

/* Subroutine */ int zheevr_(char *jobz, char *range, char *uplo, int *n, 
	doublecomplex *a, int *lda, double *vl, double *vu, 
	int *il, int *iu, double *abstol, int *m, double *
	w, doublecomplex *z__, int *ldz, int *isuppz, doublecomplex *
	work, int *lwork, double *rwork, int *lrwork, int *
	iwork, int *liwork, int *info);

/* Subroutine */ int zheevx_(char *jobz, char *range, char *uplo, int *n, 
	doublecomplex *a, int *lda, double *vl, double *vu, 
	int *il, int *iu, double *abstol, int *m, double *
	w, doublecomplex *z__, int *ldz, doublecomplex *work, int *
	lwork, double *rwork, int *iwork, int *ifail, int *
	info);

/* Subroutine */ int zhegs2_(int *itype, char *uplo, int *n, 
	doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	int *info);

/* Subroutine */ int zhegst_(int *itype, char *uplo, int *n, 
	doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	int *info);

/* Subroutine */ int zhegv_(int *itype, char *jobz, char *uplo, int *
	n, doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	double *w, doublecomplex *work, int *lwork, double *rwork,
	 int *info);

/* Subroutine */ int zhegvd_(int *itype, char *jobz, char *uplo, int *
	n, doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	double *w, doublecomplex *work, int *lwork, double *rwork,
	 int *lrwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int zhegvx_(int *itype, char *jobz, char *range, char *
	uplo, int *n, doublecomplex *a, int *lda, doublecomplex *b, 
	int *ldb, double *vl, double *vu, int *il, int *
	iu, double *abstol, int *m, double *w, doublecomplex *z__,
	 int *ldz, doublecomplex *work, int *lwork, double *rwork,
	 int *iwork, int *ifail, int *info);

/* Subroutine */ int zherfs_(char *uplo, int *n, int *nrhs, 
	doublecomplex *a, int *lda, doublecomplex *af, int *ldaf, 
	int *ipiv, doublecomplex *b, int *ldb, doublecomplex *x, 
	int *ldx, double *ferr, double *berr, doublecomplex *work,
	 double *rwork, int *info);

/* Subroutine */ int zhesv_(char *uplo, int *n, int *nrhs, 
	doublecomplex *a, int *lda, int *ipiv, doublecomplex *b, 
	int *ldb, doublecomplex *work, int *lwork, int *info);

/* Subroutine */ int zhesvx_(char *fact, char *uplo, int *n, int *
	nrhs, doublecomplex *a, int *lda, doublecomplex *af, int *
	ldaf, int *ipiv, doublecomplex *b, int *ldb, doublecomplex *x,
	 int *ldx, double *rcond, double *ferr, double *berr, 
	doublecomplex *work, int *lwork, double *rwork, int *info);

/* Subroutine */ int zhetd2_(char *uplo, int *n, doublecomplex *a, 
	int *lda, double *d__, double *e, doublecomplex *tau, 
	int *info);

/* Subroutine */ int zhetf2_(char *uplo, int *n, doublecomplex *a, 
	int *lda, int *ipiv, int *info);

/* Subroutine */ int zhetrd_(char *uplo, int *n, doublecomplex *a, 
	int *lda, double *d__, double *e, doublecomplex *tau, 
	doublecomplex *work, int *lwork, int *info);

/* Subroutine */ int zhetrf_(char *uplo, int *n, doublecomplex *a, 
	int *lda, int *ipiv, doublecomplex *work, int *lwork, 
	int *info);

/* Subroutine */ int zhetri_(char *uplo, int *n, doublecomplex *a, 
	int *lda, int *ipiv, doublecomplex *work, int *info);

/* Subroutine */ int zhetrs_(char *uplo, int *n, int *nrhs, 
	doublecomplex *a, int *lda, int *ipiv, doublecomplex *b, 
	int *ldb, int *info);

/* Subroutine */ int zhgeqz_(char *job, char *compq, char *compz, int *n, 
	int *ilo, int *ihi, doublecomplex *h__, int *ldh, 
	doublecomplex *t, int *ldt, doublecomplex *alpha, doublecomplex *
	beta, doublecomplex *q, int *ldq, doublecomplex *z__, int *
	ldz, doublecomplex *work, int *lwork, double *rwork, int *
	info);

/* Subroutine */ int zhpcon_(char *uplo, int *n, doublecomplex *ap, 
	int *ipiv, double *anorm, double *rcond, doublecomplex *
	work, int *info);

/* Subroutine */ int zhpev_(char *jobz, char *uplo, int *n, doublecomplex 
	*ap, double *w, doublecomplex *z__, int *ldz, doublecomplex *
	work, double *rwork, int *info);

/* Subroutine */ int zhpevd_(char *jobz, char *uplo, int *n, 
	doublecomplex *ap, double *w, doublecomplex *z__, int *ldz, 
	doublecomplex *work, int *lwork, double *rwork, int *
	lrwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int zhpevx_(char *jobz, char *range, char *uplo, int *n, 
	doublecomplex *ap, double *vl, double *vu, int *il, 
	int *iu, double *abstol, int *m, double *w, 
	doublecomplex *z__, int *ldz, doublecomplex *work, double *
	rwork, int *iwork, int *ifail, int *info);

/* Subroutine */ int zhpgst_(int *itype, char *uplo, int *n, 
	doublecomplex *ap, doublecomplex *bp, int *info);

/* Subroutine */ int zhpgv_(int *itype, char *jobz, char *uplo, int *
	n, doublecomplex *ap, doublecomplex *bp, double *w, doublecomplex 
	*z__, int *ldz, doublecomplex *work, double *rwork, int *
	info);

/* Subroutine */ int zhpgvd_(int *itype, char *jobz, char *uplo, int *
	n, doublecomplex *ap, doublecomplex *bp, double *w, doublecomplex 
	*z__, int *ldz, doublecomplex *work, int *lwork, double *
	rwork, int *lrwork, int *iwork, int *liwork, int *
	info);

/* Subroutine */ int zhpgvx_(int *itype, char *jobz, char *range, char *
	uplo, int *n, doublecomplex *ap, doublecomplex *bp, double *
	vl, double *vu, int *il, int *iu, double *abstol, 
	int *m, double *w, doublecomplex *z__, int *ldz, 
	doublecomplex *work, double *rwork, int *iwork, int *
	ifail, int *info);

/* Subroutine */ int zhprfs_(char *uplo, int *n, int *nrhs, 
	doublecomplex *ap, doublecomplex *afp, int *ipiv, doublecomplex *
	b, int *ldb, doublecomplex *x, int *ldx, double *ferr, 
	double *berr, doublecomplex *work, double *rwork, int *
	info);

/* Subroutine */ int zhpsv_(char *uplo, int *n, int *nrhs, 
	doublecomplex *ap, int *ipiv, doublecomplex *b, int *ldb, 
	int *info);

/* Subroutine */ int zhpsvx_(char *fact, char *uplo, int *n, int *
	nrhs, doublecomplex *ap, doublecomplex *afp, int *ipiv, 
	doublecomplex *b, int *ldb, doublecomplex *x, int *ldx, 
	double *rcond, double *ferr, double *berr, doublecomplex *
	work, double *rwork, int *info);

/* Subroutine */ int zhptrd_(char *uplo, int *n, doublecomplex *ap, 
	double *d__, double *e, doublecomplex *tau, int *info);

/* Subroutine */ int zhptrf_(char *uplo, int *n, doublecomplex *ap, 
	int *ipiv, int *info);

/* Subroutine */ int zhptri_(char *uplo, int *n, doublecomplex *ap, 
	int *ipiv, doublecomplex *work, int *info);

/* Subroutine */ int zhptrs_(char *uplo, int *n, int *nrhs, 
	doublecomplex *ap, int *ipiv, doublecomplex *b, int *ldb, 
	int *info);

/* Subroutine */ int zhsein_(char *side, char *eigsrc, char *initv, logical *
	select, int *n, doublecomplex *h__, int *ldh, doublecomplex *
	w, doublecomplex *vl, int *ldvl, doublecomplex *vr, int *ldvr,
	 int *mm, int *m, doublecomplex *work, double *rwork, 
	int *ifaill, int *ifailr, int *info);

/* Subroutine */ int zhseqr_(char *job, char *compz, int *n, int *ilo,
	 int *ihi, doublecomplex *h__, int *ldh, doublecomplex *w, 
	doublecomplex *z__, int *ldz, doublecomplex *work, int *lwork,
	 int *info);

/* Subroutine */ int zlabrd_(int *m, int *n, int *nb, 
	doublecomplex *a, int *lda, double *d__, double *e, 
	doublecomplex *tauq, doublecomplex *taup, doublecomplex *x, int *
	ldx, doublecomplex *y, int *ldy);

/* Subroutine */ int zlacgv_(int *n, doublecomplex *x, int *incx);

/* Subroutine */ int zlacn2_(int *n, doublecomplex *v, doublecomplex *x, 
	double *est, int *kase, int *isave);

/* Subroutine */ int zlacon_(int *n, doublecomplex *v, doublecomplex *x, 
	double *est, int *kase);

/* Subroutine */ int zlacp2_(char *uplo, int *m, int *n, double *
	a, int *lda, doublecomplex *b, int *ldb);

/* Subroutine */ int zlacpy_(char *uplo, int *m, int *n, 
	doublecomplex *a, int *lda, doublecomplex *b, int *ldb);

/* Subroutine */ int zlacrm_(int *m, int *n, doublecomplex *a, 
	int *lda, double *b, int *ldb, doublecomplex *c__, 
	int *ldc, double *rwork);

/* Subroutine */ int zlacrt_(int *n, doublecomplex *cx, int *incx, 
	doublecomplex *cy, int *incy, doublecomplex *c__, doublecomplex *
	s);

/* Double Complex */ void zladiv_(doublecomplex * ret_val, doublecomplex *x, 
	doublecomplex *y);

/* Subroutine */ int zlaed0_(int *qsiz, int *n, double *d__, 
	double *e, doublecomplex *q, int *ldq, doublecomplex *qstore, 
	int *ldqs, double *rwork, int *iwork, int *info);

/* Subroutine */ int zlaed7_(int *n, int *cutpnt, int *qsiz, 
	int *tlvls, int *curlvl, int *curpbm, double *d__, 
	doublecomplex *q, int *ldq, double *rho, int *indxq, 
	double *qstore, int *qptr, int *prmptr, int *perm, 
	int *givptr, int *givcol, double *givnum, doublecomplex *
	work, double *rwork, int *iwork, int *info);

/* Subroutine */ int zlaed8_(int *k, int *n, int *qsiz, 
	doublecomplex *q, int *ldq, double *d__, double *rho, 
	int *cutpnt, double *z__, double *dlamda, doublecomplex *
	q2, int *ldq2, double *w, int *indxp, int *indx, 
	int *indxq, int *perm, int *givptr, int *givcol, 
	double *givnum, int *info);

/* Subroutine */ int zlaein_(logical *rightv, logical *noinit, int *n, 
	doublecomplex *h__, int *ldh, doublecomplex *w, doublecomplex *v, 
	doublecomplex *b, int *ldb, double *rwork, double *eps3, 
	double *smlnum, int *info);

/* Subroutine */ int zlaesy_(doublecomplex *a, doublecomplex *b, 
	doublecomplex *c__, doublecomplex *rt1, doublecomplex *rt2, 
	doublecomplex *evscal, doublecomplex *cs1, doublecomplex *sn1);

/* Subroutine */ int zlaev2_(doublecomplex *a, doublecomplex *b, 
	doublecomplex *c__, double *rt1, double *rt2, double *cs1,
	 doublecomplex *sn1);

/* Subroutine */ int zlag2c_(int *m, int *n, doublecomplex *a, 
	int *lda, complex *sa, int *ldsa, int *info);

/* Subroutine */ int zlags2_(logical *upper, double *a1, doublecomplex *
	a2, double *a3, double *b1, doublecomplex *b2, double *b3,
	 double *csu, doublecomplex *snu, double *csv, doublecomplex *
	snv, double *csq, doublecomplex *snq);

/* Subroutine */ int zlagtm_(char *trans, int *n, int *nrhs, 
	double *alpha, doublecomplex *dl, doublecomplex *d__, 
	doublecomplex *du, doublecomplex *x, int *ldx, double *beta, 
	doublecomplex *b, int *ldb);

/* Subroutine */ int zlahef_(char *uplo, int *n, int *nb, int *kb,
	 doublecomplex *a, int *lda, int *ipiv, doublecomplex *w, 
	int *ldw, int *info);

/* Subroutine */ int zlahqr_(logical *wantt, logical *wantz, int *n, 
	int *ilo, int *ihi, doublecomplex *h__, int *ldh, 
	doublecomplex *w, int *iloz, int *ihiz, doublecomplex *z__, 
	int *ldz, int *info);

/* Subroutine */ int zlahr2_(int *n, int *k, int *nb, 
	doublecomplex *a, int *lda, doublecomplex *tau, doublecomplex *t, 
	int *ldt, doublecomplex *y, int *ldy);

/* Subroutine */ int zlahrd_(int *n, int *k, int *nb, 
	doublecomplex *a, int *lda, doublecomplex *tau, doublecomplex *t, 
	int *ldt, doublecomplex *y, int *ldy);

/* Subroutine */ int zlaic1_(int *job, int *j, doublecomplex *x, 
	double *sest, doublecomplex *w, doublecomplex *gamma, double *
	sestpr, doublecomplex *s, doublecomplex *c__);

/* Subroutine */ int zlals0_(int *icompq, int *nl, int *nr, 
	int *sqre, int *nrhs, doublecomplex *b, int *ldb, 
	doublecomplex *bx, int *ldbx, int *perm, int *givptr, 
	int *givcol, int *ldgcol, double *givnum, int *ldgnum,
	 double *poles, double *difl, double *difr, double *
	z__, int *k, double *c__, double *s, double *rwork, 
	int *info);

/* Subroutine */ int zlalsa_(int *icompq, int *smlsiz, int *n, 
	int *nrhs, doublecomplex *b, int *ldb, doublecomplex *bx, 
	int *ldbx, double *u, int *ldu, double *vt, int *
	k, double *difl, double *difr, double *z__, double *
	poles, int *givptr, int *givcol, int *ldgcol, int *
	perm, double *givnum, double *c__, double *s, double *
	rwork, int *iwork, int *info);

/* Subroutine */ int zlalsd_(char *uplo, int *smlsiz, int *n, int 
	*nrhs, double *d__, double *e, doublecomplex *b, int *ldb,
	 double *rcond, int *rank, doublecomplex *work, double *
	rwork, int *iwork, int *info);

/* Subroutine */ int zlapll_(int *n, doublecomplex *x, int *incx, 
	doublecomplex *y, int *incy, double *ssmin);

/* Subroutine */ int zlapmt_(logical *forwrd, int *m, int *n, 
	doublecomplex *x, int *ldx, int *k);

/* Subroutine */ int zlaqgb_(int *m, int *n, int *kl, int *ku,
	 doublecomplex *ab, int *ldab, double *r__, double *c__, 
	double *rowcnd, double *colcnd, double *amax, char *equed);

/* Subroutine */ int zlaqge_(int *m, int *n, doublecomplex *a, 
	int *lda, double *r__, double *c__, double *rowcnd, 
	double *colcnd, double *amax, char *equed);

/* Subroutine */ int zlaqhb_(char *uplo, int *n, int *kd, 
	doublecomplex *ab, int *ldab, double *s, double *scond, 
	double *amax, char *equed);

/* Subroutine */ int zlaqhe_(char *uplo, int *n, doublecomplex *a, 
	int *lda, double *s, double *scond, double *amax, 
	char *equed);

/* Subroutine */ int zlaqhp_(char *uplo, int *n, doublecomplex *ap, 
	double *s, double *scond, double *amax, char *equed);

/* Subroutine */ int zlaqp2_(int *m, int *n, int *offset, 
	doublecomplex *a, int *lda, int *jpvt, doublecomplex *tau, 
	double *vn1, double *vn2, doublecomplex *work);

/* Subroutine */ int zlaqps_(int *m, int *n, int *offset, int 
	*nb, int *kb, doublecomplex *a, int *lda, int *jpvt, 
	doublecomplex *tau, double *vn1, double *vn2, doublecomplex *
	auxv, doublecomplex *f, int *ldf);

/* Subroutine */ int zlaqr0_(logical *wantt, logical *wantz, int *n, 
	int *ilo, int *ihi, doublecomplex *h__, int *ldh, 
	doublecomplex *w, int *iloz, int *ihiz, doublecomplex *z__, 
	int *ldz, doublecomplex *work, int *lwork, int *info);

/* Subroutine */ int zlaqr1_(int *n, doublecomplex *h__, int *ldh, 
	doublecomplex *s1, doublecomplex *s2, doublecomplex *v);

/* Subroutine */ int zlaqr2_(logical *wantt, logical *wantz, int *n, 
	int *ktop, int *kbot, int *nw, doublecomplex *h__, 
	int *ldh, int *iloz, int *ihiz, doublecomplex *z__, 
	int *ldz, int *ns, int *nd, doublecomplex *sh, 
	doublecomplex *v, int *ldv, int *nh, doublecomplex *t, 
	int *ldt, int *nv, doublecomplex *wv, int *ldwv, 
	doublecomplex *work, int *lwork);

/* Subroutine */ int zlaqr3_(logical *wantt, logical *wantz, int *n, 
	int *ktop, int *kbot, int *nw, doublecomplex *h__, 
	int *ldh, int *iloz, int *ihiz, doublecomplex *z__, 
	int *ldz, int *ns, int *nd, doublecomplex *sh, 
	doublecomplex *v, int *ldv, int *nh, doublecomplex *t, 
	int *ldt, int *nv, doublecomplex *wv, int *ldwv, 
	doublecomplex *work, int *lwork);

/* Subroutine */ int zlaqr4_(logical *wantt, logical *wantz, int *n, 
	int *ilo, int *ihi, doublecomplex *h__, int *ldh, 
	doublecomplex *w, int *iloz, int *ihiz, doublecomplex *z__, 
	int *ldz, doublecomplex *work, int *lwork, int *info);

/* Subroutine */ int zlaqr5_(logical *wantt, logical *wantz, int *kacc22, 
	int *n, int *ktop, int *kbot, int *nshfts, 
	doublecomplex *s, doublecomplex *h__, int *ldh, int *iloz, 
	int *ihiz, doublecomplex *z__, int *ldz, doublecomplex *v, 
	int *ldv, doublecomplex *u, int *ldu, int *nv, 
	doublecomplex *wv, int *ldwv, int *nh, doublecomplex *wh, 
	int *ldwh);

/* Subroutine */ int zlaqsb_(char *uplo, int *n, int *kd, 
	doublecomplex *ab, int *ldab, double *s, double *scond, 
	double *amax, char *equed);

/* Subroutine */ int zlaqsp_(char *uplo, int *n, doublecomplex *ap, 
	double *s, double *scond, double *amax, char *equed);

/* Subroutine */ int zlaqsy_(char *uplo, int *n, doublecomplex *a, 
	int *lda, double *s, double *scond, double *amax, 
	char *equed);

/* Subroutine */ int zlar1v_(int *n, int *b1, int *bn, double 
	*lambda, double *d__, double *l, double *ld, double *
	lld, double *pivmin, double *gaptol, doublecomplex *z__, 
	logical *wantnc, int *negcnt, double *ztz, double *mingma,
	 int *r__, int *isuppz, double *nrminv, double *resid,
	 double *rqcorr, double *work);

/* Subroutine */ int zlar2v_(int *n, doublecomplex *x, doublecomplex *y, 
	doublecomplex *z__, int *incx, double *c__, doublecomplex *s, 
	int *incc);

/* Subroutine */ int zlarcm_(int *m, int *n, double *a, int *
	lda, doublecomplex *b, int *ldb, doublecomplex *c__, int *ldc,
	 double *rwork);

/* Subroutine */ int zlarf_(char *side, int *m, int *n, doublecomplex 
	*v, int *incv, doublecomplex *tau, doublecomplex *c__, int *
	ldc, doublecomplex *work);

/* Subroutine */ int zlarfb_(char *side, char *trans, char *direct, char *
	storev, int *m, int *n, int *k, doublecomplex *v, int 
	*ldv, doublecomplex *t, int *ldt, doublecomplex *c__, int *
	ldc, doublecomplex *work, int *ldwork  	);

/* Subroutine */ int zlarfg_(int *n, doublecomplex *alpha, doublecomplex *
	x, int *incx, doublecomplex *tau);

/* Subroutine */ int zlarft_(char *direct, char *storev, int *n, int *
	k, doublecomplex *v, int *ldv, doublecomplex *tau, doublecomplex *
	t, int *ldt);

/* Subroutine */ int zlarfx_(char *side, int *m, int *n, 
	doublecomplex *v, doublecomplex *tau, doublecomplex *c__, int *
	ldc, doublecomplex *work);

/* Subroutine */ int zlargv_(int *n, doublecomplex *x, int *incx, 
	doublecomplex *y, int *incy, double *c__, int *incc);

/* Subroutine */ int zlarnv_(int *idist, int *iseed, int *n, 
	doublecomplex *x);

/* Subroutine */ int zlarrv_(int *n, double *vl, double *vu, 
	double *d__, double *l, double *pivmin, int *isplit, 
	int *m, int *dol, int *dou, double *minrgp, 
	double *rtol1, double *rtol2, double *w, double *werr,
	 double *wgap, int *iblock, int *indexw, double *gers,
	 doublecomplex *z__, int *ldz, int *isuppz, double *work, 
	int *iwork, int *info);

/* Subroutine */ int zlartg_(doublecomplex *f, doublecomplex *g, double *
	cs, doublecomplex *sn, doublecomplex *r__);

/* Subroutine */ int zlartv_(int *n, doublecomplex *x, int *incx, 
	doublecomplex *y, int *incy, double *c__, doublecomplex *s, 
	int *incc);

/* Subroutine */ int zlarz_(char *side, int *m, int *n, int *l, 
	doublecomplex *v, int *incv, doublecomplex *tau, doublecomplex *
	c__, int *ldc, doublecomplex *work);

/* Subroutine */ int zlarzb_(char *side, char *trans, char *direct, char *
	storev, int *m, int *n, int *k, int *l, doublecomplex 
	*v, int *ldv, doublecomplex *t, int *ldt, doublecomplex *c__, 
	int *ldc, doublecomplex *work, int *ldwork);

/* Subroutine */ int zlarzt_(char *direct, char *storev, int *n, int *
	k, doublecomplex *v, int *ldv, doublecomplex *tau, doublecomplex *
	t, int *ldt);

/* Subroutine */ int zlascl_(char *type__, int *kl, int *ku, 
	double *cfrom, double *cto, int *m, int *n, 
	doublecomplex *a, int *lda, int *info);

/* Subroutine */ int zlaset_(char *uplo, int *m, int *n, 
	doublecomplex *alpha, doublecomplex *beta, doublecomplex *a, int *
	lda);

/* Subroutine */ int zlasr_(char *side, char *pivot, char *direct, int *m,
	 int *n, double *c__, double *s, doublecomplex *a, 
	int *lda);

/* Subroutine */ int zlassq_(int *n, doublecomplex *x, int *incx, 
	double *scale, double *sumsq);

/* Subroutine */ int zlaswp_(int *n, doublecomplex *a, int *lda, 
	int *k1, int *k2, int *ipiv, int *incx);

/* Subroutine */ int zlasyf_(char *uplo, int *n, int *nb, int *kb,
	 doublecomplex *a, int *lda, int *ipiv, doublecomplex *w, 
	int *ldw, int *info);

/* Subroutine */ int zlatbs_(char *uplo, char *trans, char *diag, char *
	normin, int *n, int *kd, doublecomplex *ab, int *ldab, 
	doublecomplex *x, double *scale, double *cnorm, int *info);

/* Subroutine */ int zlatdf_(int *ijob, int *n, doublecomplex *z__, 
	int *ldz, doublecomplex *rhs, double *rdsum, double *
	rdscal, int *ipiv, int *jpiv);

/* Subroutine */ int zlatps_(char *uplo, char *trans, char *diag, char *
	normin, int *n, doublecomplex *ap, doublecomplex *x, double *
	scale, double *cnorm, int *info);

/* Subroutine */ int zlatrd_(char *uplo, int *n, int *nb, 
	doublecomplex *a, int *lda, double *e, doublecomplex *tau, 
	doublecomplex *w, int *ldw);

/* Subroutine */ int zlatrs_(char *uplo, char *trans, char *diag, char *
	normin, int *n, doublecomplex *a, int *lda, doublecomplex *x, 
	double *scale, double *cnorm, int *info);

/* Subroutine */ int zlatrz_(int *m, int *n, int *l, 
	doublecomplex *a, int *lda, doublecomplex *tau, doublecomplex *
	work);

/* Subroutine */ int zlatzm_(char *side, int *m, int *n, 
	doublecomplex *v, int *incv, doublecomplex *tau, doublecomplex *
	c1, doublecomplex *c2, int *ldc, doublecomplex *work  	);

/* Subroutine */ int zlauu2_(char *uplo, int *n, doublecomplex *a, 
	int *lda, int *info);

/* Subroutine */ int zlauum_(char *uplo, int *n, doublecomplex *a, 
	int *lda, int *info);

/* Subroutine */ int zpbcon_(char *uplo, int *n, int *kd, 
	doublecomplex *ab, int *ldab, double *anorm, double *
	rcond, doublecomplex *work, double *rwork, int *info);

/* Subroutine */ int zpbequ_(char *uplo, int *n, int *kd, 
	doublecomplex *ab, int *ldab, double *s, double *scond, 
	double *amax, int *info);

/* Subroutine */ int zpbrfs_(char *uplo, int *n, int *kd, int *
	nrhs, doublecomplex *ab, int *ldab, doublecomplex *afb, int *
	ldafb, doublecomplex *b, int *ldb, doublecomplex *x, int *ldx,
	 double *ferr, double *berr, doublecomplex *work, double *
	rwork, int *info);

/* Subroutine */ int zpbstf_(char *uplo, int *n, int *kd, 
	doublecomplex *ab, int *ldab, int *info);

/* Subroutine */ int zpbsv_(char *uplo, int *n, int *kd, int *
	nrhs, doublecomplex *ab, int *ldab, doublecomplex *b, int *
	ldb, int *info);

/* Subroutine */ int zpbsvx_(char *fact, char *uplo, int *n, int *kd, 
	int *nrhs, doublecomplex *ab, int *ldab, doublecomplex *afb, 
	int *ldafb, char *equed, double *s, doublecomplex *b, int 
	*ldb, doublecomplex *x, int *ldx, double *rcond, double *
	ferr, double *berr, doublecomplex *work, double *rwork, 
	int *info);

/* Subroutine */ int zpbtf2_(char *uplo, int *n, int *kd, 
	doublecomplex *ab, int *ldab, int *info);

/* Subroutine */ int zpbtrf_(char *uplo, int *n, int *kd, 
	doublecomplex *ab, int *ldab, int *info);

/* Subroutine */ int zpbtrs_(char *uplo, int *n, int *kd, int *
	nrhs, doublecomplex *ab, int *ldab, doublecomplex *b, int *
	ldb, int *info);

/* Subroutine */ int zpocon_(char *uplo, int *n, doublecomplex *a, 
	int *lda, double *anorm, double *rcond, doublecomplex *
	work, double *rwork, int *info);

/* Subroutine */ int zpoequ_(int *n, doublecomplex *a, int *lda, 
	double *s, double *scond, double *amax, int *info);

/* Subroutine */ int zporfs_(char *uplo, int *n, int *nrhs, 
	doublecomplex *a, int *lda, doublecomplex *af, int *ldaf, 
	doublecomplex *b, int *ldb, doublecomplex *x, int *ldx, 
	double *ferr, double *berr, doublecomplex *work, double *
	rwork, int *info);

/* Subroutine */ int zposv_(char *uplo, int *n, int *nrhs, 
	doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	int *info);

/* Subroutine */ int zposvx_(char *fact, char *uplo, int *n, int *
	nrhs, doublecomplex *a, int *lda, doublecomplex *af, int *
	ldaf, char *equed, double *s, doublecomplex *b, int *ldb, 
	doublecomplex *x, int *ldx, double *rcond, double *ferr, 
	double *berr, doublecomplex *work, double *rwork, int *
	info);

/* Subroutine */ int zpotf2_(char *uplo, int *n, doublecomplex *a, 
	int *lda, int *info);

/* Subroutine */ int zpotrf_(char *uplo, int *n, doublecomplex *a, 
	int *lda, int *info);

/* Subroutine */ int zpotri_(char *uplo, int *n, doublecomplex *a, 
	int *lda, int *info);

/* Subroutine */ int zpotrs_(char *uplo, int *n, int *nrhs, 
	doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	int *info);

/* Subroutine */ int zppcon_(char *uplo, int *n, doublecomplex *ap, 
	double *anorm, double *rcond, doublecomplex *work, double 
	*rwork, int *info);

/* Subroutine */ int zppequ_(char *uplo, int *n, doublecomplex *ap, 
	double *s, double *scond, double *amax, int *info);

/* Subroutine */ int zpprfs_(char *uplo, int *n, int *nrhs, 
	doublecomplex *ap, doublecomplex *afp, doublecomplex *b, int *ldb,
	 doublecomplex *x, int *ldx, double *ferr, double *berr, 
	doublecomplex *work, double *rwork, int *info);

/* Subroutine */ int zppsv_(char *uplo, int *n, int *nrhs, 
	doublecomplex *ap, doublecomplex *b, int *ldb, int *info);

/* Subroutine */ int zppsvx_(char *fact, char *uplo, int *n, int *
	nrhs, doublecomplex *ap, doublecomplex *afp, char *equed, double *
	s, doublecomplex *b, int *ldb, doublecomplex *x, int *ldx, 
	double *rcond, double *ferr, double *berr, doublecomplex *
	work, double *rwork, int *info);

/* Subroutine */ int zpptrf_(char *uplo, int *n, doublecomplex *ap, 
	int *info);

/* Subroutine */ int zpptri_(char *uplo, int *n, doublecomplex *ap, 
	int *info);

/* Subroutine */ int zpptrs_(char *uplo, int *n, int *nrhs, 
	doublecomplex *ap, doublecomplex *b, int *ldb, int *info);

/* Subroutine */ int zptcon_(int *n, double *d__, doublecomplex *e, 
	double *anorm, double *rcond, double *rwork, int *
	info);

/* Subroutine */ int zpteqr_(char *compz, int *n, double *d__, 
	double *e, doublecomplex *z__, int *ldz, double *work, 
	int *info);

/* Subroutine */ int zptrfs_(char *uplo, int *n, int *nrhs, 
	double *d__, doublecomplex *e, double *df, doublecomplex *ef, 
	doublecomplex *b, int *ldb, doublecomplex *x, int *ldx, 
	double *ferr, double *berr, doublecomplex *work, double *
	rwork, int *info);

/* Subroutine */ int zptsv_(int *n, int *nrhs, double *d__, 
	doublecomplex *e, doublecomplex *b, int *ldb, int *info);

/* Subroutine */ int zptsvx_(char *fact, int *n, int *nrhs, 
	double *d__, doublecomplex *e, double *df, doublecomplex *ef, 
	doublecomplex *b, int *ldb, doublecomplex *x, int *ldx, 
	double *rcond, double *ferr, double *berr, doublecomplex *
	work, double *rwork, int *info);

/* Subroutine */ int zpttrf_(int *n, double *d__, doublecomplex *e, 
	int *info);

/* Subroutine */ int zpttrs_(char *uplo, int *n, int *nrhs, 
	double *d__, doublecomplex *e, doublecomplex *b, int *ldb, 
	int *info);

/* Subroutine */ int zptts2_(int *iuplo, int *n, int *nrhs, 
	double *d__, doublecomplex *e, doublecomplex *b, int *ldb);

/* Subroutine */ int zrot_(int *n, doublecomplex *cx, int *incx, 
	doublecomplex *cy, int *incy, double *c__, doublecomplex *s);

/* Subroutine */ int zspcon_(char *uplo, int *n, doublecomplex *ap, 
	int *ipiv, double *anorm, double *rcond, doublecomplex *
	work, int *info);

/* Subroutine */ int zspmv_(char *uplo, int *n, doublecomplex *alpha, 
	doublecomplex *ap, doublecomplex *x, int *incx, doublecomplex *
	beta, doublecomplex *y, int *incy);

/* Subroutine */ int zspr_(char *uplo, int *n, doublecomplex *alpha, 
	doublecomplex *x, int *incx, doublecomplex *ap);

/* Subroutine */ int zsprfs_(char *uplo, int *n, int *nrhs, 
	doublecomplex *ap, doublecomplex *afp, int *ipiv, doublecomplex *
	b, int *ldb, doublecomplex *x, int *ldx, double *ferr, 
	double *berr, doublecomplex *work, double *rwork, int *
	info);

/* Subroutine */ int zspsv_(char *uplo, int *n, int *nrhs, 
	doublecomplex *ap, int *ipiv, doublecomplex *b, int *ldb, 
	int *info);

/* Subroutine */ int zspsvx_(char *fact, char *uplo, int *n, int *
	nrhs, doublecomplex *ap, doublecomplex *afp, int *ipiv, 
	doublecomplex *b, int *ldb, doublecomplex *x, int *ldx, 
	double *rcond, double *ferr, double *berr, doublecomplex *
	work, double *rwork, int *info);

/* Subroutine */ int zsptrf_(char *uplo, int *n, doublecomplex *ap, 
	int *ipiv, int *info);

/* Subroutine */ int zsptri_(char *uplo, int *n, doublecomplex *ap, 
	int *ipiv, doublecomplex *work, int *info);

/* Subroutine */ int zsptrs_(char *uplo, int *n, int *nrhs, 
	doublecomplex *ap, int *ipiv, doublecomplex *b, int *ldb, 
	int *info);

/* Subroutine */ int zstedc_(char *compz, int *n, double *d__, 
	double *e, doublecomplex *z__, int *ldz, doublecomplex *work, 
	int *lwork, double *rwork, int *lrwork, int *iwork, 
	int *liwork, int *info);

/* Subroutine */ int zstegr_(char *jobz, char *range, int *n, double *
	d__, double *e, double *vl, double *vu, int *il, 
	int *iu, double *abstol, int *m, double *w, 
	doublecomplex *z__, int *ldz, int *isuppz, double *work, 
	int *lwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int zstein_(int *n, double *d__, double *e, 
	int *m, double *w, int *iblock, int *isplit, 
	doublecomplex *z__, int *ldz, double *work, int *iwork, 
	int *ifail, int *info);

/* Subroutine */ int zstemr_(char *jobz, char *range, int *n, double *
	d__, double *e, double *vl, double *vu, int *il, 
	int *iu, int *m, double *w, doublecomplex *z__, int *
	ldz, int *nzc, int *isuppz, logical *tryrac, double *work,
	 int *lwork, int *iwork, int *liwork, int *info);

/* Subroutine */ int zsteqr_(char *compz, int *n, double *d__, 
	double *e, doublecomplex *z__, int *ldz, double *work, 
	int *info);

/* Subroutine */ int zsycon_(char *uplo, int *n, doublecomplex *a, 
	int *lda, int *ipiv, double *anorm, double *rcond, 
	doublecomplex *work, int *info);

/* Subroutine */ int zsymv_(char *uplo, int *n, doublecomplex *alpha, 
	doublecomplex *a, int *lda, doublecomplex *x, int *incx, 
	doublecomplex *beta, doublecomplex *y, int *incy);

/* Subroutine */ int zsyr_(char *uplo, int *n, doublecomplex *alpha, 
	doublecomplex *x, int *incx, doublecomplex *a, int *lda);

/* Subroutine */ int zsyrfs_(char *uplo, int *n, int *nrhs, 
	doublecomplex *a, int *lda, doublecomplex *af, int *ldaf, 
	int *ipiv, doublecomplex *b, int *ldb, doublecomplex *x, 
	int *ldx, double *ferr, double *berr, doublecomplex *work,
	 double *rwork, int *info);

/* Subroutine */ int zsysv_(char *uplo, int *n, int *nrhs, 
	doublecomplex *a, int *lda, int *ipiv, doublecomplex *b, 
	int *ldb, doublecomplex *work, int *lwork, int *info);

/* Subroutine */ int zsysvx_(char *fact, char *uplo, int *n, int *
	nrhs, doublecomplex *a, int *lda, doublecomplex *af, int *
	ldaf, int *ipiv, doublecomplex *b, int *ldb, doublecomplex *x,
	 int *ldx, double *rcond, double *ferr, double *berr, 
	doublecomplex *work, int *lwork, double *rwork, int *info);

/* Subroutine */ int zsytf2_(char *uplo, int *n, doublecomplex *a, 
	int *lda, int *ipiv, int *info);

/* Subroutine */ int zsytrf_(char *uplo, int *n, doublecomplex *a, 
	int *lda, int *ipiv, doublecomplex *work, int *lwork, 
	int *info);

/* Subroutine */ int zsytri_(char *uplo, int *n, doublecomplex *a, 
	int *lda, int *ipiv, doublecomplex *work, int *info);

/* Subroutine */ int zsytrs_(char *uplo, int *n, int *nrhs, 
	doublecomplex *a, int *lda, int *ipiv, doublecomplex *b, 
	int *ldb, int *info);

/* Subroutine */ int ztbcon_(char *norm, char *uplo, char *diag, int *n, 
	int *kd, doublecomplex *ab, int *ldab, double *rcond, 
	doublecomplex *work, double *rwork, int *info);

/* Subroutine */ int ztbrfs_(char *uplo, char *trans, char *diag, int *n, 
	int *kd, int *nrhs, doublecomplex *ab, int *ldab, 
	doublecomplex *b, int *ldb, doublecomplex *x, int *ldx, 
	double *ferr, double *berr, doublecomplex *work, double *
	rwork, int *info);

/* Subroutine */ int ztbtrs_(char *uplo, char *trans, char *diag, int *n, 
	int *kd, int *nrhs, doublecomplex *ab, int *ldab, 
	doublecomplex *b, int *ldb, int *info);

/* Subroutine */ int ztgevc_(char *side, char *howmny, logical *select, 
	int *n, doublecomplex *s, int *lds, doublecomplex *p, int 
	*ldp, doublecomplex *vl, int *ldvl, doublecomplex *vr, int *
	ldvr, int *mm, int *m, doublecomplex *work, double *rwork,
	 int *info);

/* Subroutine */ int ztgex2_(logical *wantq, logical *wantz, int *n, 
	doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	doublecomplex *q, int *ldq, doublecomplex *z__, int *ldz, 
	int *j1, int *info);

/* Subroutine */ int ztgexc_(logical *wantq, logical *wantz, int *n, 
	doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	doublecomplex *q, int *ldq, doublecomplex *z__, int *ldz, 
	int *ifst, int *ilst, int *info);

/* Subroutine */ int ztgsen_(int *ijob, logical *wantq, logical *wantz, 
	logical *select, int *n, doublecomplex *a, int *lda, 
	doublecomplex *b, int *ldb, doublecomplex *alpha, doublecomplex *
	beta, doublecomplex *q, int *ldq, doublecomplex *z__, int *
	ldz, int *m, double *pl, double *pr, double *dif, 
	doublecomplex *work, int *lwork, int *iwork, int *liwork, 
	int *info);

/* Subroutine */ int ztgsja_(char *jobu, char *jobv, char *jobq, int *m, 
	int *p, int *n, int *k, int *l, doublecomplex *a, 
	int *lda, doublecomplex *b, int *ldb, double *tola, 
	double *tolb, double *alpha, double *beta, doublecomplex *
	u, int *ldu, doublecomplex *v, int *ldv, doublecomplex *q, 
	int *ldq, doublecomplex *work, int *ncycle, int *info);

/* Subroutine */ int ztgsna_(char *job, char *howmny, logical *select, 
	int *n, doublecomplex *a, int *lda, doublecomplex *b, int 
	*ldb, doublecomplex *vl, int *ldvl, doublecomplex *vr, int *
	ldvr, double *s, double *dif, int *mm, int *m, 
	doublecomplex *work, int *lwork, int *iwork, int *info);

/* Subroutine */ int ztgsy2_(char *trans, int *ijob, int *m, int *
	n, doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	doublecomplex *c__, int *ldc, doublecomplex *d__, int *ldd, 
	doublecomplex *e, int *lde, doublecomplex *f, int *ldf, 
	double *scale, double *rdsum, double *rdscal, int *
	info);

/* Subroutine */ int ztgsyl_(char *trans, int *ijob, int *m, int *
	n, doublecomplex *a, int *lda, doublecomplex *b, int *ldb, 
	doublecomplex *c__, int *ldc, doublecomplex *d__, int *ldd, 
	doublecomplex *e, int *lde, doublecomplex *f, int *ldf, 
	double *scale, double *dif, doublecomplex *work, int *
	lwork, int *iwork, int *info);

/* Subroutine */ int ztpcon_(char *norm, char *uplo, char *diag, int *n, 
	doublecomplex *ap, double *rcond, doublecomplex *work, double 
	*rwork, int *info);

/* Subroutine */ int ztprfs_(char *uplo, char *trans, char *diag, int *n, 
	int *nrhs, doublecomplex *ap, doublecomplex *b, int *ldb, 
	doublecomplex *x, int *ldx, double *ferr, double *berr, 
	doublecomplex *work, double *rwork, int *info);

/* Subroutine */ int ztptri_(char *uplo, char *diag, int *n, 
	doublecomplex *ap, int *info);

/* Subroutine */ int ztptrs_(char *uplo, char *trans, char *diag, int *n, 
	int *nrhs, doublecomplex *ap, doublecomplex *b, int *ldb, 
	int *info);

/* Subroutine */ int ztrcon_(char *norm, char *uplo, char *diag, int *n, 
	doublecomplex *a, int *lda, double *rcond, doublecomplex *
	work, double *rwork, int *info);

/* Subroutine */ int ztrevc_(char *side, char *howmny, logical *select, 
	int *n, doublecomplex *t, int *ldt, doublecomplex *vl, 
	int *ldvl, doublecomplex *vr, int *ldvr, int *mm, int 
	*m, doublecomplex *work, double *rwork, int *info);

/* Subroutine */ int ztrexc_(char *compq, int *n, doublecomplex *t, 
	int *ldt, doublecomplex *q, int *ldq, int *ifst, int *
	ilst, int *info);

/* Subroutine */ int ztrrfs_(char *uplo, char *trans, char *diag, int *n, 
	int *nrhs, doublecomplex *a, int *lda, doublecomplex *b, 
	int *ldb, doublecomplex *x, int *ldx, double *ferr, 
	double *berr, doublecomplex *work, double *rwork, int *
	info);

/* Subroutine */ int ztrsen_(char *job, char *compq, logical *select, int 
	*n, doublecomplex *t, int *ldt, doublecomplex *q, int *ldq, 
	doublecomplex *w, int *m, double *s, double *sep, 
	doublecomplex *work, int *lwork, int *info);

/* Subroutine */ int ztrsna_(char *job, char *howmny, logical *select, 
	int *n, doublecomplex *t, int *ldt, doublecomplex *vl, 
	int *ldvl, doublecomplex *vr, int *ldvr, double *s, 
	double *sep, int *mm, int *m, doublecomplex *work, 
	int *ldwork, double *rwork, int *info);

/* Subroutine */ int ztrsyl_(char *trana, char *tranb, int *isgn, int 
	*m, int *n, doublecomplex *a, int *lda, doublecomplex *b, 
	int *ldb, doublecomplex *c__, int *ldc, double *scale, 
	int *info);

/* Subroutine */ int ztrti2_(char *uplo, char *diag, int *n, 
	doublecomplex *a, int *lda, int *info);

/* Subroutine */ int ztrtri_(char *uplo, char *diag, int *n, 
	doublecomplex *a, int *lda, int *info);

/* Subroutine */ int ztrtrs_(char *uplo, char *trans, char *diag, int *n, 
	int *nrhs, doublecomplex *a, int *lda, doublecomplex *b, 
	int *ldb, int *info);

/* Subroutine */ int ztzrqf_(int *m, int *n, doublecomplex *a, 
	int *lda, doublecomplex *tau, int *info);

/* Subroutine */ int ztzrzf_(int *m, int *n, doublecomplex *a, 
	int *lda, doublecomplex *tau, doublecomplex *work, int *lwork,
	 int *info);

/* Subroutine */ int zung2l_(int *m, int *n, int *k, 
	doublecomplex *a, int *lda, doublecomplex *tau, doublecomplex *
	work, int *info);

/* Subroutine */ int zung2r_(int *m, int *n, int *k, 
	doublecomplex *a, int *lda, doublecomplex *tau, doublecomplex *
	work, int *info);

/* Subroutine */ int zungbr_(char *vect, int *m, int *n, int *k, 
	doublecomplex *a, int *lda, doublecomplex *tau, doublecomplex *
	work, int *lwork, int *info);

/* Subroutine */ int zunghr_(int *n, int *ilo, int *ihi, 
	doublecomplex *a, int *lda, doublecomplex *tau, doublecomplex *
	work, int *lwork, int *info);

/* Subroutine */ int zungl2_(int *m, int *n, int *k, 
	doublecomplex *a, int *lda, doublecomplex *tau, doublecomplex *
	work, int *info);

/* Subroutine */ int zunglq_(int *m, int *n, int *k, 
	doublecomplex *a, int *lda, doublecomplex *tau, doublecomplex *
	work, int *lwork, int *info);

/* Subroutine */ int zungql_(int *m, int *n, int *k, 
	doublecomplex *a, int *lda, doublecomplex *tau, doublecomplex *
	work, int *lwork, int *info);

/* Subroutine */ int zungqr_(int *m, int *n, int *k, 
	doublecomplex *a, int *lda, doublecomplex *tau, doublecomplex *
	work, int *lwork, int *info);

/* Subroutine */ int zungr2_(int *m, int *n, int *k, 
	doublecomplex *a, int *lda, doublecomplex *tau, doublecomplex *
	work, int *info);

/* Subroutine */ int zungrq_(int *m, int *n, int *k, 
	doublecomplex *a, int *lda, doublecomplex *tau, doublecomplex *
	work, int *lwork, int *info);

/* Subroutine */ int zungtr_(char *uplo, int *n, doublecomplex *a, 
	int *lda, doublecomplex *tau, doublecomplex *work, int *lwork,
	 int *info);

/* Subroutine */ int zunm2l_(char *side, char *trans, int *m, int *n, 
	int *k, doublecomplex *a, int *lda, doublecomplex *tau, 
	doublecomplex *c__, int *ldc, doublecomplex *work, int *info);

/* Subroutine */ int zunm2r_(char *side, char *trans, int *m, int *n, 
	int *k, doublecomplex *a, int *lda, doublecomplex *tau, 
	doublecomplex *c__, int *ldc, doublecomplex *work, int *info);

/* Subroutine */ int zunmbr_(char *vect, char *side, char *trans, int *m, 
	int *n, int *k, doublecomplex *a, int *lda, doublecomplex 
	*tau, doublecomplex *c__, int *ldc, doublecomplex *work, int * 	
	lwork, int *info);

/* Subroutine */ int zunmhr_(char *side, char *trans, int *m, int *n, 
	int *ilo, int *ihi, doublecomplex *a, int *lda, 
	doublecomplex *tau, doublecomplex *c__, int *ldc, doublecomplex * 	
	work, int *lwork, int *info);

/* Subroutine */ int zunml2_(char *side, char *trans, int *m, int *n, 
	int *k, doublecomplex *a, int *lda, doublecomplex *tau, 
	doublecomplex *c__, int *ldc, doublecomplex *work, int *info);

/* Subroutine */ int zunmlq_(char *side, char *trans, int *m, int *n, 
	int *k, doublecomplex *a, int *lda, doublecomplex *tau, 
	doublecomplex *c__, int *ldc, doublecomplex *work, int *lwork,
	 int *info);

/* Subroutine */ int zunmql_(char *side, char *trans, int *m, int *n, 
	int *k, doublecomplex *a, int *lda, doublecomplex *tau, 
	doublecomplex *c__, int *ldc, doublecomplex *work, int *lwork,
	 int *info);

/* Subroutine */ int zunmqr_(char *side, char *trans, int *m, int *n, 
	int *k, doublecomplex *a, int *lda, doublecomplex *tau, 
	doublecomplex *c__, int *ldc, doublecomplex *work, int *lwork,
	 int *info);

/* Subroutine */ int zunmr2_(char *side, char *trans, int *m, int *n, 
	int *k, doublecomplex *a, int *lda, doublecomplex *tau, 
	doublecomplex *c__, int *ldc, doublecomplex *work, int *info);

/* Subroutine */ int zunmr3_(char *side, char *trans, int *m, int *n, 
	int *k, int *l, doublecomplex *a, int *lda, doublecomplex 
	*tau, doublecomplex *c__, int *ldc, doublecomplex *work, int *
	info);

/* Subroutine */ int zunmrq_(char *side, char *trans, int *m, int *n, 
	int *k, doublecomplex *a, int *lda, doublecomplex *tau, 
	doublecomplex *c__, int *ldc, doublecomplex *work, int *lwork,
	 int *info);

/* Subroutine */ int zunmrz_(char *side, char *trans, int *m, int *n, 
	int *k, int *l, doublecomplex *a, int *lda, doublecomplex 
	*tau, doublecomplex *c__, int *ldc, doublecomplex *work, int *
	lwork, int *info);

/* Subroutine */ int zunmtr_(char *side, char *uplo, char *trans, int *m, 
	int *n, doublecomplex *a, int *lda, doublecomplex *tau, 
	doublecomplex *c__, int *ldc, doublecomplex *work, int *lwork,
	 int *info);

/* Subroutine */ int zupgtr_(char *uplo, int *n, doublecomplex *ap, 
	doublecomplex *tau, doublecomplex *q, int *ldq, doublecomplex *
	work, int *info);

/* Subroutine */ int zupmtr_(char *side, char *uplo, char *trans, int *m, 
	int *n, doublecomplex *ap, doublecomplex *tau, doublecomplex *c__,
	 int *ldc, doublecomplex *work, int *info);

#ifdef __cplusplus
}
#endif

#endif

