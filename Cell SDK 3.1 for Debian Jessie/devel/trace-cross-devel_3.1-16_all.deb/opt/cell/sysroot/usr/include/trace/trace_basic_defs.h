/*
Licensed Materials - Property of IBM
© Copyright IBM Corp. 2007  All Rights Reserved.
*/
#ifndef __TRACE_BASIC_DEFS_H__
#define __TRACE_BASIC_DEFS_H__
#include <stdint.h>

/* List of constants that will be used in the tracing facility. */
enum {
	TRACE_MAX_PAYLOADS_INT  = 20,
	TRACE_MAX_PAYLOADS_LONG = 10,
	TRACE_MAX_PAYLOADS = TRACE_MAX_PAYLOADS_INT,
	TRACE_MAX_LIBS = 32
};

/* Group ID type: symbolizes all the possible groups accepted by the trace facility. */
typedef enum {
	TRACE_FIRST_GROUP = 0,
	TRACE_GENERAL = TRACE_FIRST_GROUP,
	TRACE_LIBSPE2 = 1,
	TRACE_SPUMFCIO = 2,
	TRACE_LIBSYNC = 3,
	TRACE_DACS = 4,
	TRACE_DACS_PERF = 6,
	TRACE_DACS_DEBUG = 7,
	TRACE_DACS_2 = 10,
	TRACE_DACS_2_SPU = 11,
	TRACE_ALF = 5,
	TRACE_ALF_PERF = 8,
	TRACE_ALF_DEBUG = 9,
	TRACE_LAST_GROUP = TRACE_MAX_LIBS-1
} trace_group_t;

/* -Boolean type. */
typedef uint8_t trace_bool_t;
enum {
	trace_false = 0,
	trace_true = 1
};

/* Payload type: payload information for recording an event. */
typedef union {
	uint32_t word[TRACE_MAX_PAYLOADS_INT];
	uint64_t dword[TRACE_MAX_PAYLOADS_LONG];
} trace_payload_t;

/* -Event ID type: symbolizes one group and an event of that group. */
typedef int16_t trace_event_id_t;

/* Event type: symbolizes one event (of any group). */
typedef uint8_t trace_event_t;

/* Generates a trace_event_id type value from a given group and a event type. */
static inline trace_event_id_t trace_event2id(trace_group_t group, trace_event_t event_number)
{
	return group | (event_number << 8);
}

/* Generates a trace_event_id type value from a given group and a event type. */
static inline trace_group_t trace_eventid2group(trace_event_id_t eid)
{
	return (trace_group_t) (eid & 0x00FF);
}

/* Generates a trace_event_id type value from a given group and a event type. */
static inline trace_event_t trace_eventid2event(trace_event_id_t eid)
{
	return (eid >> 8);
}

#endif
