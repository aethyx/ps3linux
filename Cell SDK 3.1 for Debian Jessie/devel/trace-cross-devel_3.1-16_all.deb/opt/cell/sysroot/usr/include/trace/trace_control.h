/*
Licensed Materials - Property of IBM
© Copyright IBM Corp. 2007  All Rights Reserved.
*/
#ifndef __TRACE_CONTROL_H__
#define __TRACE_CONTROL_H__

#ifdef __cplusplus__
extern "C" {
#endif /* __cplusplus__ */
	
#include <trace_defs.h>

/****************************************************************************
* Trace control
*****************************************************************************/

/****************************************************************************
* Initializes the tracing at each level of hierarchy. This function should be
* called before any traced event is called. It initializes the dynamic control
* structure with the given data in the config structure.
*****************************************************************************/
extern void trace_init(void);

#ifndef __SPU__
/*Dumps the trace into a file and closes it. This enables on the fly tracing.
 This function is not available in the SPE.*/
extern void trace_dump(void);
#endif

#ifdef __cplusplus__
}
#endif /* __cplusplus__ */

#endif
