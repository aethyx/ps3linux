/*
Licensed Materials - Property of IBM
© Copyright IBM Corp. 2007  All Rights Reserved.
*/
#ifndef __TRACE_EVENTS_H__
#define __TRACE_EVENTS_H__

#ifdef __cplusplus__
extern "C" {
#endif /* __cplusplus__ */

#include <trace_defs.h>

/****************************************************************************
* Events recording:
* The following three functions are used to create a single trace
* record and to create trace records that simbolize an interval.
* Note: interrupts are disabled during the below functions.
*****************************************************************************/

/****************************************************************************
* Writes a trace record with the provided payload. The event id is combined
* from the event group and the event type; The last parameter is a pointer
* to an array of payload elements, i.e. the list of parameters to be part
* of the trace record. On the SPE this array must be aligned on 16 bytes
* boundary. The format argument should include the types of the parameters
* given as payloads, while argc defines the number of parameters in the payload.
* The last argument, level, tells the number of levels in the stack to look at
* for getting the program counter of the user code that called the traced library.
*****************************************************************************/
extern long trace_event(trace_event_id_t event_id, int argc, trace_payload_p payload, const char *format, unsigned int level);

/****************************************************************************
* Initiates an interval that terminates when trace_interval_exit() is called.
* This function does not write a trace record. The event id is combined
* from the event group and the event type. The last argument, level, tells the
* number of levels in the stack to look at for getting the program counter of
* the user code that called the traced library. The function returns a 
* trace_interval type that must be used as a parameter to the 
* trace_interval_exit function.
*****************************************************************************/
extern trace_interval_p trace_interval_entry(trace_event_id_t event_id, unsigned int level);

/****************************************************************************
* Terminates an interval that was initiated when trace_interval_entry() was
* called. The trace interval type is provided by the trace_interval_entry()
* function. The payload parameter is a pointer to an array of payload elements,
* i.e. the list of parameters to be part of the trace record. On the SPE this
* array must be aligned on 16 bytes boundary. The format argument should
* include the types of the parameters given as payloads, while argc defines the
* number of parameters in the payload.
*****************************************************************************/
extern long trace_interval_exit(trace_interval_p interval, int argc, trace_payload_p payload, const char *format);

/****************************************************************************
* Traces a string that won't enter into a record. The returned value is the
* mapping number that needs to be used to connect an event with the string.
*****************************************************************************/
#ifndef __SPU__
extern long trace_string(const char *string);
#endif

#ifdef __cplusplus__
}
#endif /* __cplusplus__ */

#endif
