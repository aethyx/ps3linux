/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _UNPACK_NORMAL16_V_H_
#define _UNPACK_NORMAL16_V_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

#include "normal16.h"

/*
 * FUNCTION
 *	vector float _unpack_normal16_v(double pack);
 * 
 * DESCRIPTION
 *	_unpack_normal16_v converts 4 signed 16-bit packed normals and expands
 *	them back into a vector of normalized -1.0 to 1.0 floating-point 
 *	normals. 
 */

static __inline vector float _unpack_normal16_v(double pack)
{

#ifdef __SPU__
  vector unsigned int work;

  /* Redistrubute the packed shorts back into the both the most and 
   * least significant 16 bits of each word.
   */
  work = (vector unsigned int)(spu_promote(pack, 0));
  work = spu_shuffle(work, work, ((vector unsigned char) { 
					     0, 1, 0x80, 0x80, 2, 3, 0x80, 0x80,
					     4, 5, 0x80, 0x80, 6, 7, 0x80, 0x80}));

  work = spu_rlmask(work, -9);
  work = spu_xor(work, spu_splats((unsigned int)0x40400000));
  return (spu_madd((vector float)(work), VECTOR_UNPACK_NORMAL_SCALE, VECTOR_UNPACK_NORMAL_BIAS));

#else
  union {
    vector signed int i;
    vector unsigned int ui;
    vector float f;
    double d[2];
  } work;

  /* Redistrubute the packed shorts back into the both the most and 
   * least significant 16 bits of each word.
   */
  work.d[0] = pack;
  work.ui = vec_perm(work.ui, ((vector unsigned int) {0,0,0,0}), ((vector unsigned char) {
							    0, 1, 0x10, 0x10, 2, 3, 0x10, 0x10,
							    4, 5, 0x10, 0x10, 6, 7, 0x10, 0x10}));
		      
  work.ui = vec_sr(work.ui, ((vector unsigned int) {9,9,9,9}));
  work.ui = vec_xor(work.ui, ((vector unsigned int) {0x40400000,0x40400000,0x40400000,0x40400000}));
  work.f = vec_madd(work.f, VECTOR_UNPACK_NORMAL_SCALE, VECTOR_UNPACK_NORMAL_BIAS);
  return (work.f);
#endif

}

#endif /* _UNPACK_NORMAL16_V_H_ */






