/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _LERP_VEC3_V_H_
#define _LERP_VEC3_V_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 * 	void _lerp_vec3_v(vector float *xout, vector float *yout, vector float *zout,
 *			  vector float x1, vector float y1, vector float z1,
 *			  vector float x2, vector float y2, vector float z2, 
 *			  vector float t)
 * 
 * DESCRIPTION
 * 	_lerp_vec3_v computes 4 3-D vertices of the linear interpolation 
 *	between 4 3-D vertex pairs for 4 interpolation factors t. The input
 *	and output vertices are expressed in parallel array format. For each
 *	component of the SIMD vectors:
 *	  *[xout,yout,zout] = (1-t)*[x1,y1,z1] + t*[x2,y2,z2]
 */

static __inline void _lerp_vec3_v(vector float *xout, vector float *yout, vector float *zout, vector float x1, vector float y1, vector float z1, vector float x2, vector float y2, vector float z2, vector float t)
{
#ifdef __SPU__
  *xout = spu_madd(t, spu_sub(x2, x1), x1);
  *yout = spu_madd(t, spu_sub(y2, y1), y1);
  *zout = spu_madd(t, spu_sub(z2, z1), z1);
#else
  *xout = vec_madd(t, vec_sub(x2, x1), x1);
  *yout = vec_madd(t, vec_sub(y2, y1), y1);
  *zout = vec_madd(t, vec_sub(z2, z1), z1);
#endif
}
#endif /* _LERP_VEC3_V_H_ */

