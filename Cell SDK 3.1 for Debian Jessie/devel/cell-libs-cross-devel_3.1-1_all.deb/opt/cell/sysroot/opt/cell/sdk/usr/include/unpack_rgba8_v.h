/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _UNPACK_RGBA8_V_H_
#define _UNPACK_RGBA8_V_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 *	float _unpack_rgba8(unsigned int rgba, int component);
 *	vector float _unpack_rgba8_v(vector unsigned int rgba, int component);
 * 
 * DESCRIPTION
 *	_unpack_rgba8 extracts a vector of 8-bit fixed point color from 
 *	vector of packed colors and returns the colors as a normalized 
 *	(0.0 to 1.0) color components. For efficiency, conversion of 0xFF 
 *	does not result in exactly 1.0,	instead it produces 1.0 - 2^-23.
 */

/* The following table, unpackRGBAShuffle, is indexed by a component number.
 * So a 32-bit word containing a RGBA (where red is the most significant byte
 * and alpha is the least significant byte), red is component 0, green is 
 * compnent 1, blue is component 2, and alpha is component 3.
 * This table is used a the shuffle selector to shuffle bytes to replicate
 * the specified component across the entire word.
 */
static vector unsigned char unpackRGBAShuffle[4] = { 
  (vector unsigned char) {
	      0x10, 0x00, 0x00, 0x00, 0x14, 0x04, 0x04, 0x04,
	      0x18, 0x08, 0x08, 0x08, 0x1C, 0x0C, 0x0C, 0x0C},
  (vector unsigned char) {
	      0x11, 0x01, 0x01, 0x01, 0x15, 0x05, 0x05, 0x05,
	      0x19, 0x09, 0x09, 0x09, 0x1D, 0x0D, 0x0D, 0x0D},
  (vector unsigned char) {
	      0x12, 0x02, 0x02, 0x02, 0x16, 0x06, 0x06, 0x06,
	      0x1A, 0x0A, 0x0A, 0x0A, 0x1E, 0x0E, 0x0E, 0x0E},
  (vector unsigned char) {
	      0x13, 0x03, 0x03, 0x03, 0x17, 0x07, 0x07, 0x07,
	      0x1B, 0x0B, 0x0B, 0x0B, 0x1F, 0x0F, 0x0F, 0x0F},
};


static __inline vector float _unpack_rgba8_v(vector unsigned int rgba, int component)
{
  vector unsigned int comp;
  vector float result;
#ifdef __SPU__
  comp = spu_shuffle(rgba, rgba, unpackRGBAShuffle[component]);
  result = spu_convtf(comp, 32);
#else
  vector unsigned int vzero = ((vector unsigned int) {0,0,0,0});

  comp = vec_perm(rgba, vzero, unpackRGBAShuffle[component]);
  result = vec_ctf(comp, 24);
#endif
  return (result);
}

#endif /* _UNPACK_RGBA8_V_H_ */
