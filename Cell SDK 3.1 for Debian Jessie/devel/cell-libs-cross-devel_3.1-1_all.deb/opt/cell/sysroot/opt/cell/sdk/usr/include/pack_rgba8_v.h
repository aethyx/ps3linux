/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _PACK_RGBA8_V_H_
#define _PACK_RGBA8_V_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 *	unsigned vector int _pack_rgba8_v(vector float red, vector float green, 
 *				          vector float blue, vector float alpha);
 * 
 * DESCRIPTION
 *	_pack_rgba8_v converts four 4 component normalized (0.0 to 1.0) 
 *	colors into a vector of packed rgba fixed-point (8 bits per component) 
 *	colors. Values outside the normalized range are clamped to the range 
 *	prior to conversion. Packed color can be unpacked (one component at a time)
 *	using the function _unpack_rgba8_v.
 */

static __inline vector unsigned int _pack_rgba8_v(vector float red, vector float green, vector float blue, vector float alpha)
{
  vector unsigned int r, g, b, a;
  vector unsigned int rg, ba;
  vector unsigned int rgba;

#ifdef __SPU__
  vector unsigned char shuffle2 = (vector unsigned char) {
					      0x00, 0x10, 0x00, 0x00, 0x04, 0x14, 0x00, 0x00,
					      0x08, 0x18, 0x00, 0x00, 0x0C, 0x1C, 0x00, 0x00};
  vector unsigned char shuffle4 = (vector unsigned char) {
					      0x00, 0x01, 0x10, 0x11, 0x04, 0x05, 0x14, 0x15,
					      0x08, 0x09, 0x18, 0x19, 0x0C, 0x0D, 0x1C, 0x1D};

				       

  r = spu_convtu(red,   32);
  g = spu_convtu(green, 32);
  b = spu_convtu(blue,  32);
  a = spu_convtu(alpha, 32);

  rg = spu_shuffle(r, g, shuffle2);
  ba = spu_shuffle(b, a, shuffle2);

  rgba = spu_shuffle(rg, ba, shuffle4);

#else
  vector unsigned char shuffle = (vector unsigned char) {
					     0x00, 0x08, 0x10, 0x18, 0x02, 0x0A, 0x12, 0x1A,
					     0x04, 0x0C, 0x14, 0x1C, 0x06, 0x0E, 0x16, 0x1E};

  r = vec_ctu(red,   16);
  g = vec_ctu(green, 16);
  b = vec_ctu(blue,  16);
  a = vec_ctu(alpha, 16);

  rg = (vector unsigned int)vec_packsu(r, g);
  ba = (vector unsigned int)vec_packsu(b, a);

  rgba = vec_perm(rg, ba, shuffle);
#endif
  return(rgba);
}

#endif /* _PACK_RGBA8_V_H_ */
