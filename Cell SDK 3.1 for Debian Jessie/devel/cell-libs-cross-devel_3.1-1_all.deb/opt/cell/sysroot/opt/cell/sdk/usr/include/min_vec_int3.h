/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _MIN_VEC_INT3_H_
#define _MIN_VEC_INT3_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif
/*
 * FUNCTION
 *      signed int _min_vec_float3(vector signed int in)
 *
 * DESCRIPTION
 *	_min_vec_int3 subroutine returns the minimum of 3 of the
 *	4 integer components of the integer SIMD vector in.
 *	The 3 components that participate in this function are the
 *	3 most significant components.
 *
 *	   msb _______________________________lsb
 *            |___X___|___X___|___X___|_______|
 */

static __inline signed int _min_vec_int3(vector signed int in) 
{
  vector signed int in_r1, in_r2;
#ifdef __SPU__
  vector unsigned int cmp;

  in_r1 = spu_rlqwbyte(in, 4);
  in_r2 = spu_rlqwbyte(in, 8);
  cmp  = spu_cmpgt(in, in_r1);
  in   = spu_sel(in, in_r1, cmp);  
  cmp  = spu_cmpgt(in, in_r2);

  return (spu_extract(spu_sel(in, in_r2, cmp), 0));  
#else
  union {
    vector signed int iv;
    signed int i[4];
  } result;

  in_r1 = vec_splat(in, 1);
  in_r2 = vec_splat(in, 2);

  result.iv = vec_min(in,        in_r1);
  result.iv = vec_min(result.iv, in_r2);

  return (result.i[0]);
#endif
}

#endif /* _MIN_VEC_INT3_H_ */
