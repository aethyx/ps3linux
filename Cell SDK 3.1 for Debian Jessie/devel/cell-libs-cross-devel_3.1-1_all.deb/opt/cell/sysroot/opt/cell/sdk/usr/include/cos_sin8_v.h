/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _COS_SIN8_V_H_
#define _COS_SIN8_V_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif


#ifndef M_1_2PI
#define M_1_2PI		0.1591549430919		/* 1/(2*pi) */ 
#endif /* M_1_2PI */

/*
 * FUNCTION
 *	vector float _cos_sin8_v(vector float angle)
 *
 * DESCRIPTION
 *	_cos_sin8_v computes the cosine of the vector of angles (expressed 
 * 	in normalized radians) to an accuracy of at least 8 bits for angle
 *	of 0.0 to 1.0. Angles outside this range are less accurate. 
 *	Normalized radians mean that an angle of 1.0 corresponds to 2*PI 
 *	radians. The cosine is computed using an 8 segment piecewise, 
 *	quadratic  approximation over the interval [0, 1) normalized 
 *	radians. The quadratic evaluation is of the form 
 *		A*x*x + B*x + C, 
 *	where x is the 1.0 plus the fractional input angle.
 */

/* Precomputed quadratic coefficients */
static vector float cos8_A_v[2] = {
  (vector float) { -18.00349, -7.457291,  7.457291, 18.00349},
  (vector float) {  18.00349,  7.457291, -7.457291,-18.00349} 
};

static vector float cos8_B_v[2] = {
  (vector float) {  35.91427, 12.05421, -25.23224, -54.10319}, 
  (vector float) { -53.91777,-19.51150,  32.68953,  72.10668}
}; 
static vector float cos8_C_v[2] = {
  (vector float) { -16.91078, -3.41575,  19.88829,  39.64692}, 
  (vector float) {  39.36879, 11.30717, -34.36873, -71.19939}
};

static __inline vector float _cos_sin8_v(vector float angle)
{
  vector float result;
  vector unsigned int idx;
  vector float a, b, c;
  vector float frac, work1, work2;

  work1  = angle;

#ifdef __SPU__
  work1 = (vector float)spu_and((vector unsigned int)work1, spu_splats((unsigned int)0x7ffffffe));
  work2 = (vector float)spu_convts(work1, 0);
  work2 = spu_convtf((vector signed int)work2, 0);
  frac  = spu_sub(work1, work2);
  frac  = spu_add(frac, spu_splats((float)1.0));

  idx = spu_rlmask((vector unsigned int)(frac), -18);
  idx = spu_shuffle(idx, idx, ((vector unsigned char) { 0x03, 0x03, 0x03, 0x03, 0x07, 0x07, 0x07, 0x07,
  							0x0b, 0x0b, 0x0b, 0x0b, 0x0f, 0x0f, 0x0f, 0x0f}));
  
  idx = spu_sel(spu_splats((unsigned int)0x00010203), idx, spu_splats((unsigned int)0x1c1c1c1c));
  
  a = spu_shuffle(cos8_A_v[0], cos8_A_v[1], (vector unsigned char)(idx));
  b = spu_shuffle(cos8_B_v[0], cos8_B_v[1], (vector unsigned char)(idx));
  c = spu_shuffle(cos8_C_v[0], cos8_C_v[1], (vector unsigned char)(idx));

  result = spu_madd(frac, a, b);
  result = spu_madd(frac, result, c);
#else
  work1 = (vector float)vec_and((vector unsigned int)work1, ((vector unsigned int) {0x7ffffffe,0x7ffffffe,0x7ffffffe,0x7ffffffe}));
  work2 = (vector float)vec_cts(work1, 0);
  work2 = vec_ctf((vector signed int)work2, 0);
  frac  = vec_sub(work1, work2);
  frac  = vec_add(frac, ((vector float) {1.0,1.0,1.0,1.0}));

  idx = vec_sr((vector unsigned int)frac, ((vector unsigned int) {18,18,18,18}));
  idx = vec_perm(idx, idx, ((vector unsigned char) { 0x03, 0x03, 0x03, 0x03, 0x07, 0x07, 0x07, 0x07,
  							0x0b, 0x0b, 0x0b, 0x0b, 0x0f, 0x0f, 0x0f, 0x0f}));

  idx = vec_sel(((vector unsigned int) {0x00010203,0x00010203,0x00010203,0x00010203}), idx,
  		((vector unsigned int) {0x1c1c1c1c,0x1c1c1c1c,0x1c1c1c1c,0x1c1c1c1c}));
  
  a = (vector float)vec_perm((vector unsigned int)(cos8_A_v[0]), (vector unsigned int)(cos8_A_v[1]), (vector unsigned char)(idx));
  b = (vector float)vec_perm((vector unsigned int)(cos8_B_v[0]), (vector unsigned int)(cos8_B_v[1]), (vector unsigned char)(idx));
  c = (vector float)vec_perm((vector unsigned int)(cos8_C_v[0]), (vector unsigned int)(cos8_C_v[1]), (vector unsigned char)(idx));

  result = vec_madd(frac, a, b);
  result = vec_madd(frac, result, c);
#endif

  return (result);
}

#endif /* _COS_SIN8_V_H_ */
