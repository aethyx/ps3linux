/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _NORMALIZE4_H_
#define _NORMALIZE4_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif
#include <simdmath/rsqrtf4.h>

/*
 * FUNCTION
 * 	vector float _normalize4(vector float in)
 * 
 * DESCRIPTION
 *	_normalize4 normalizes the input vector specified by the parameter
 *	in and return the result. The input and output vectors are assumed
 *	to be 4 compoent vectors of the form:
 *           _______________________________
 *          |___X___|___Y___|___Z___|___W___|
 *        
 *	Vector normalization is computed as follows.
 *
 *	    len = sqrt(in.x*in.x + in.y*in.y + in.z*in.z + in.w*in.w)
 *     	    result.x = in.x / len;
 *     	    result.y = in.y / len;
 *     	    result.z = in.z / len;
 *     	    result.w = in.w / len;
 *
 *	This routine contains a significant number of dependent operations.
 *	Good performance depends upon interleaving this code with other 
 *	processing.
 */

static __inline vector float _normalize4(vector float in)
{
  vector float sum, sum1, sum2;
  vector float scale;
  vector float xyzw, yzwx, zwxy, wxyz;

#ifdef __SPU__
  xyzw = spu_mul(in, in);
  yzwx = spu_rlqwbyte(xyzw, 4);
  zwxy = spu_rlqwbyte(xyzw, 8);
  wxyz = spu_rlqwbyte(xyzw, 12);

  sum1 = spu_add(xyzw, yzwx);
  sum2 = spu_add(zwxy, wxyz);
  sum  = spu_add(sum1, sum2);
  scale = _rsqrtf4(sum);
  return (spu_mul(scale, in));
#else
  vector float vzero = ((vector float) {0.0f,0.0f,0.0f,0.0f});

  xyzw = vec_madd(in, in, vzero);
  yzwx = vec_sld(xyzw, xyzw, 4);
  zwxy = vec_sld(xyzw, xyzw, 8);
  wxyz = vec_sld(xyzw, xyzw, 12);

  sum1 = vec_add(xyzw, yzwx);
  sum2 = vec_add(zwxy, wxyz);
  sum  = vec_add(sum1, sum2);
  scale = _rsqrtf4(sum);
  return (vec_madd(scale, in, vzero));
#endif

}
#endif /* _NORMALIZE4_H_ */
