/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef _XFORM_VEC_MACROS_H
#define _XFORM_VEC_MACROS_H		1

/* The vector transformation routines have been encapsulated into
 * macros so the one can easily built looping constructs that do not
 * reload the matrix elements every time through the loop.
 *
 * There are 3 basic types of macros.
 *
 * DECLARE macros : declare the local matrix variables.
 * LOAD macros    : loads the local matrix variables.
 * XFORM macros	  : performs the transformation on vectors.
 */


#ifndef _DECLARE_MATRIX_4X4_V
#define _DECLARE_MATRIX_4X4_V(_matrix)							\
vector float _##_matrix##_0,  _##_matrix##_1,  _##_matrix##_2,  _##_matrix##_3;		\
vector float _##_matrix##_4,  _##_matrix##_5,  _##_matrix##_6,  _##_matrix##_7;		\
vector float _##_matrix##_8,  _##_matrix##_9,  _##_matrix##_10, _##_matrix##_11;	\
vector float _##_matrix##_12, _##_matrix##_13, _##_matrix##_14, _##_matrix##_15;
#endif


#ifndef _DECLARE_MATRIX_3X3_V
#define _DECLARE_MATRIX_3X3_V(_matrix)					\
vector float _##_matrix##_0,  _##_matrix##_1,  _##_matrix##_2;  	\
vector float _##_matrix##_4,  _##_matrix##_5,  _##_matrix##_6;  	\
vector float _##_matrix##_8,  _##_matrix##_9,  _##_matrix##_10; 
#endif



#ifndef _LOAD_MATRIX_3X3_V
#define _LOAD_MATRIX_3X3_V(_matrix)		\
  _##_matrix##_0  = *(_matrix + 0);		\
  _##_matrix##_1  = *(_matrix + 1);		\
  _##_matrix##_2  = *(_matrix + 2);		\
  _##_matrix##_4  = *(_matrix + 4);		\
  _##_matrix##_5  = *(_matrix + 5);		\
  _##_matrix##_6  = *(_matrix + 6);		\
  _##_matrix##_8  = *(_matrix + 8);		\
  _##_matrix##_9  = *(_matrix + 9);		\
  _##_matrix##_10 = *(_matrix + 10);
#endif

#ifndef _LOAD_MATRIX_4X4_V
#define _LOAD_MATRIX_4X4_V(_matrix)		\
  _##_matrix##_0  = *(_matrix + 0);		\
  _##_matrix##_1  = *(_matrix + 1);		\
  _##_matrix##_2  = *(_matrix + 2);		\
  _##_matrix##_3  = *(_matrix + 3);		\
  _##_matrix##_4  = *(_matrix + 4);		\
  _##_matrix##_5  = *(_matrix + 5);		\
  _##_matrix##_6  = *(_matrix + 6);		\
  _##_matrix##_7  = *(_matrix + 7);		\
  _##_matrix##_8  = *(_matrix + 8);		\
  _##_matrix##_9  = *(_matrix + 9);		\
  _##_matrix##_10 = *(_matrix + 10);		\
  _##_matrix##_11 = *(_matrix + 11);		\
  _##_matrix##_12 = *(_matrix + 12);		\
  _##_matrix##_13 = *(_matrix + 13);		\
  _##_matrix##_14 = *(_matrix + 14);		\
  _##_matrix##_15 = *(_matrix + 15);
#endif





#ifdef __SPU__

#define _XFORM_VEC3_V(_xout, _yout, _zout, _wout, _xin, _yin, _zin, _matrix)	\
{										\
  vector float _inx, _iny, _inz;						\
  vector float _vx, _vy, _vz, _vw;						\
										\
  _inx = _xin;									\
  _iny = _yin;									\
  _inz = _zin;									\
										\
  _vx = spu_madd(_inx, _##_matrix##_0, _##_matrix##_12);			\
  _vy = spu_madd(_inx, _##_matrix##_1, _##_matrix##_13);			\
  _vz = spu_madd(_inx, _##_matrix##_2, _##_matrix##_14);			\
  _vw = spu_madd(_inx, _##_matrix##_3, _##_matrix##_15);			\
										\
  _vx = spu_madd(_iny, _##_matrix##_4, _vx);					\
  _vy = spu_madd(_iny, _##_matrix##_5, _vy);					\
  _vz = spu_madd(_iny, _##_matrix##_6, _vz);					\
  _vw = spu_madd(_iny, _##_matrix##_7, _vw);					\
										\
  _vx = spu_madd(_inz, _##_matrix##_8,  _vx);					\
  _vy = spu_madd(_inz, _##_matrix##_9,  _vy);					\
  _vz = spu_madd(_inz, _##_matrix##_10, _vz);					\
  _vw = spu_madd(_inz, _##_matrix##_11, _vw);					\
										\
  *_xout = _vx;									\
  *_yout = _vy;									\
  *_zout = _vz;									\
  *_wout = _vw;									\
}



#define _XFORM_VEC4_V(_xout, _yout, _zout, _wout, _xin, _yin, _zin, _win, _matrix)	\
{											\
  vector float _inx, _iny, _inz, _inw;							\
  vector float _vx, _vy, _vz, _vw;							\
											\
  _inx = _xin;										\
  _iny = _yin;										\
  _inz = _zin;										\
  _inw = _win;										\
											\
  _vx = spu_mul(_inx, _##_matrix##_0);							\
  _vy = spu_mul(_inx, _##_matrix##_1);							\
  _vz = spu_mul(_inx, _##_matrix##_2);							\
  _vw = spu_mul(_inx, _##_matrix##_3);							\
											\
  _vx = spu_madd(_iny, _##_matrix##_4, _vx);						\
  _vy = spu_madd(_iny, _##_matrix##_5, _vy);						\
  _vz = spu_madd(_iny, _##_matrix##_6, _vz);						\
  _vw = spu_madd(_iny, _##_matrix##_7, _vw);						\
											\
  _vx = spu_madd(_inz, _##_matrix##_8,  _vx);						\
  _vy = spu_madd(_inz, _##_matrix##_9,  _vy);						\
  _vz = spu_madd(_inz, _##_matrix##_10, _vz);						\
  _vw = spu_madd(_inz, _##_matrix##_11, _vw);						\
											\
  _vx = spu_madd(_inw, _##_matrix##_12, _vx);						\
  _vy = spu_madd(_inw, _##_matrix##_13, _vy);						\
  _vz = spu_madd(_inw, _##_matrix##_14, _vz);						\
  _vw = spu_madd(_inw, _##_matrix##_15, _vw);						\
											\
  *_xout = _vx;										\
  *_yout = _vy;										\
  *_zout = _vz;										\
  *_wout = _vw;										\
}


#define _XFORM_NORM3_V(_xout, _yout, _zout, _xin, _yin, _zin, _matrix)	\
{									\
  vector float _inx, _iny, _inz;					\
  vector float _vx, _vy, _vz;						\
									\
  _inx = _xin;								\
  _iny = _yin;								\
  _inz = _zin;								\
									\
  _vx = spu_mul(_inx, _##_matrix##_0);					\
  _vy = spu_mul(_inx, _##_matrix##_1);					\
  _vz = spu_mul(_inx, _##_matrix##_2);					\
									\
  _vx = spu_madd(_iny, _##_matrix##_4, _vx);				\
  _vy = spu_madd(_iny, _##_matrix##_5, _vy);				\
  _vz = spu_madd(_iny, _##_matrix##_6, _vz);				\
									\
  _vx = spu_madd(_inz, _##_matrix##_8,  _vx);				\
  _vy = spu_madd(_inz, _##_matrix##_9,  _vy);				\
  _vz = spu_madd(_inz, _##_matrix##_10, _vz);				\
									\
  *_xout = _vx;								\
  *_yout = _vy;								\
  *_zout = _vz;								\
}

#else /* PU */

#define _XFORM_VEC3_V(_xout, _yout, _zout, _wout, _xin, _yin, _zin, _matrix)	\
{										\
  vector float _inx, _iny, _inz;						\
  vector float _vx, _vy, _vz, _vw;						\
										\
  _inx = _xin;									\
  _iny = _yin;									\
  _inz = _zin;									\
										\
  _vx = vec_madd(_inx, _##_matrix##_0, _##_matrix##_12);			\
  _vy = vec_madd(_inx, _##_matrix##_1, _##_matrix##_13);			\
  _vz = vec_madd(_inx, _##_matrix##_2, _##_matrix##_14);			\
  _vw = vec_madd(_inx, _##_matrix##_3, _##_matrix##_15);			\
										\
  _vx = vec_madd(_iny, _##_matrix##_4, _vx);					\
  _vy = vec_madd(_iny, _##_matrix##_5, _vy);					\
  _vz = vec_madd(_iny, _##_matrix##_6, _vz);					\
  _vw = vec_madd(_iny, _##_matrix##_7, _vw);					\
										\
  _vx = vec_madd(_inz, _##_matrix##_8,  _vx);					\
  _vy = vec_madd(_inz, _##_matrix##_9,  _vy);					\
  _vz = vec_madd(_inz, _##_matrix##_10, _vz);					\
  _vw = vec_madd(_inz, _##_matrix##_11, _vw);					\
										\
  *_xout = _vx;									\
  *_yout = _vy;									\
  *_zout = _vz;									\
  *_wout = _vw;									\
}


#ifdef __SPU__
 #define _VZERO spu_splats((float)0.0)
#else /* !__SPU__ */
 #define _VZERO ((vector float) {0.0f,0.0f,0.0f,0.0f})
#endif /* __SPU__ */


#define _XFORM_VEC4_V(_xout, _yout, _zout, _wout, _xin, _yin, _zin, _win, _matrix)	\
{											\
  vector float _inx, _iny, _inz, _inw;							\
  vector float _vx, _vy, _vz, _vw;							\
  vector float _vzero = _VZERO;								\
											\
  _inx = _xin;										\
  _iny = _yin;										\
  _inz = _zin;										\
  _inw = _win;										\
											\
  _vx = vec_madd(_inx, _##_matrix##_0, _vzero);						\
  _vy = vec_madd(_inx, _##_matrix##_1, _vzero);						\
  _vz = vec_madd(_inx, _##_matrix##_2, _vzero);						\
  _vw = vec_madd(_inx, _##_matrix##_3, _vzero);						\
											\
  _vx = vec_madd(_iny, _##_matrix##_4, _vx);						\
  _vy = vec_madd(_iny, _##_matrix##_5, _vy);						\
  _vz = vec_madd(_iny, _##_matrix##_6, _vz);						\
  _vw = vec_madd(_iny, _##_matrix##_7, _vw);						\
											\
  _vx = vec_madd(_inz, _##_matrix##_8,  _vx);						\
  _vy = vec_madd(_inz, _##_matrix##_9,  _vy);						\
  _vz = vec_madd(_inz, _##_matrix##_10, _vz);						\
  _vw = vec_madd(_inz, _##_matrix##_11, _vw);						\
											\
  _vx = vec_madd(_inw, _##_matrix##_12, _vx);						\
  _vy = vec_madd(_inw, _##_matrix##_13, _vy);						\
  _vz = vec_madd(_inw, _##_matrix##_14, _vz);						\
  _vw = vec_madd(_inw, _##_matrix##_15, _vw);						\
											\
  *_xout = _vx;										\
  *_yout = _vy;										\
  *_zout = _vz;										\
  *_wout = _vw;										\
}



#define _XFORM_NORM3_V(_xout, _yout, _zout, _xin, _yin, _zin, _matrix)	\
{									\
  vector float _inx, _iny, _inz;					\
  vector float _vx, _vy, _vz;						\
  vector float _vzero = _VZERO;						\
									\
  _inx = _xin;								\
  _iny = _yin;								\
  _inz = _zin;								\
									\
  _vx = vec_madd(_inx, _##_matrix##_0, _vzero);				\
  _vy = vec_madd(_inx, _##_matrix##_1, _vzero);				\
  _vz = vec_madd(_inx, _##_matrix##_2, _vzero);				\
									\
  _vx = vec_madd(_iny, _##_matrix##_4, _vx);				\
  _vy = vec_madd(_iny, _##_matrix##_5, _vy);				\
  _vz = vec_madd(_iny, _##_matrix##_6, _vz);				\
									\
  _vx = vec_madd(_inz, _##_matrix##_8,  _vx);				\
  _vy = vec_madd(_inz, _##_matrix##_9,  _vy);				\
  _vz = vec_madd(_inz, _##_matrix##_10, _vz);				\
									\
  *_xout = _vx;								\
  *_yout = _vy;								\
  *_zout = _vz;								\
}

#endif /* __SPU__ */

#endif /* XFORM_VEC_MACROS_H */
