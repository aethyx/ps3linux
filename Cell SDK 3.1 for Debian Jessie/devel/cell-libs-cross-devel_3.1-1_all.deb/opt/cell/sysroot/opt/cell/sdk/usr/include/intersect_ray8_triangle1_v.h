/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _intersect_ray8_triangle1_v_h_
#define _intersect_ray8_triangle1_v_h_

#ifdef __SPU__
#include <spu_intrinsics.h>
#include <simdmath/recipf4_fast.h>
#else /* not __SPU__ */
#include <altivec.h>
#include <simdmath/recipf4.h>
#endif

#include "dot_product3_v.h"

/* function:    _intersect_ray8_triangle1_v 
 *
 * parameters:
 *   vector float hit_t[2],		  // accum nearest 't' intercept
 *   vector float hit_u[2], hit_v[2],	  // accum (u,v) coordinates
 *   vector float hit_id[2],              // accum nearest triangle id
 *   vector float rox[2], roy[2], roz[2], // 8 ray origins, SoA form
 *   vector float rdx[2], rdy[2], rdz[2], // 8 ray directions, SoA form
 *   vector float ex[2], ey[2], ez[2],    // triangle edges, SoA form
 *   vector float p0x, p0y, p0z,	  // triangle p0, SoA form
 *   vector float id[2]
 *
 * Determine if a set of 8 rays intersect the given triangle.  If so,
 * return the paramaterized (u, v) intersection coordinates, and
 * accumulate nearest triangle intercept point --assuming that more 
 * than 1 triangle will eventually be intersected with each ray.
 *
 * Per-triangle computation is to be performed by the caller, as 
 * follows:
 *
 *   ex[0] = spu_sub (p1x, p0x);	// p0, p1, p2 are in SoA form.
 *   ey[0] = spu_sub (p1y, p0y);
 *   ez[0] = spu_sub (p1z, p0z);
 *
 *   ex[1] = spu_sub (p2x, p0x);
 *   ey[1] = spu_sub (p2y, p0y);
 *   ez[1] = spu_sub (p2z, p0z);
 *
 * See also:
 *
 *   Ray Tracing on Programmable Graphics Hardware
 *   Purcell, Buck, Mark, Hanrahan
 *   Proceedings of ACM SIGGRAPH, 2002
 */

static __inline void _intersect_ray8_triangle1_v (vector float hit_t[2], vector float hit_u[2], vector float hit_v[2], vector unsigned int hit_id[2], const vector float rox[2], const vector float roy[2], const vector float roz[2], const vector float rdx[2], const vector float rdy[2], const vector float rdz[2], const vector float ex[2], const vector float ey[2], const vector float ez[2], vector float p0x, vector float p0y, vector float p0z, vector unsigned int ids[2])
{
  vector float _vzero = ((vector float) {0.0f,0.0f,0.0f,0.0f});
  vector float _vone = ((vector float) {1.0f,1.0f,1.0f,1.0f});
  vector float pvecx, tvecx, qvecx;
  vector float pvecxu, tvecxu, qvecxu;
  vector float pvecy, tvecy, qvecy;
  vector float pvecyu, tvecyu, qvecyu;
  vector float pvecz, tvecz, qvecz;
  vector float pveczu, tveczu, qveczu;
  vector float det, inv_det;
  vector float detu, inv_detu;
  vector float u, v, t;
  vector float uu, vu, tu;
  vector unsigned int u_ge_0, v_ge_0;
  vector unsigned int u_ge_0u, v_ge_0u;
  vector unsigned int uv_le_1;
  vector unsigned int uv_le_1u;
  vector unsigned int t_lt_h0;
  vector unsigned int t_lt_h0u;
  vector unsigned int t_ge_0;
  vector unsigned int t_ge_0u;
  vector unsigned int vha, vhb, validhit;
  vector unsigned int vhau, vhbu, validhitu;
  vector float ht, hu, hv;
  vector float htu, huu, hvu;
  vector unsigned int id, hid;
  vector unsigned int idu, hidu;

  ht  = hit_t[0];
  hu  = hit_u[0];
  hv  = hit_v[0];
  hid = hit_id[0];

  htu  = hit_t[1];
  huu  = hit_u[1];
  hvu  = hit_v[1];
  hidu = hit_id[1];

  id = ids[0];
  idu = ids[1];

#ifdef __SPU__

  /* pvec = rd[0] CROSS e[1] 
   * pvecu = rd[1] CROSS e[1] 
   */
  pvecx = spu_nmsub(rdz[0], ey[1], spu_madd(rdy[0], ez[1], _vzero));
  pvecy = spu_nmsub(rdx[0], ez[1], spu_madd(rdz[0], ex[1], _vzero));
  pvecz = spu_nmsub(rdy[0], ex[1], spu_madd(rdx[0], ey[1], _vzero));

  pvecxu = spu_nmsub(rdz[1], ey[1], spu_madd(rdy[1], ez[1], _vzero));
  pvecyu = spu_nmsub(rdx[1], ez[1], spu_madd(rdz[1], ex[1], _vzero));
  pveczu = spu_nmsub(rdy[1], ex[1], spu_madd(rdx[1], ey[1], _vzero));

  det = _dot_product3_v (ex[0], ey[0], ez[0], pvecx, pvecy, pvecz);
  detu = _dot_product3_v (ex[0], ey[0], ez[0], pvecxu, pvecyu, pveczu);

  inv_det = _recipf4_fast(det);
  inv_detu = _recipf4_fast(detu);

  tvecx = spu_sub (rox[0], p0x);
  tvecxu = spu_sub (rox[1], p0x);

  tvecy = spu_sub (roy[0], p0y);
  tvecyu = spu_sub (roy[1], p0y);

  tvecz = spu_sub (roz[0], p0z);
  tveczu = spu_sub (roz[1], p0z);

  u = spu_mul (_dot_product3_v (tvecx, tvecy, tvecz, pvecx, pvecy, pvecz), inv_det);
  uu = spu_mul (_dot_product3_v (tvecxu, tvecyu, tveczu, pvecxu, pvecyu, pveczu), inv_detu);

  /* qvec = tvec CROSS e[0]
   * qvecu = tvecu CROSS e[0]
   */
  qvecx = spu_nmsub(tvecz, ey[0], spu_madd(tvecy, ez[0], _vzero));
  qvecy = spu_nmsub(tvecx, ez[0], spu_madd(tvecz, ex[0], _vzero));
  qvecz = spu_nmsub(tvecy, ex[0], spu_madd(tvecx, ey[0], _vzero));

  qvecxu = spu_nmsub(tveczu, ey[0], spu_madd(tvecyu, ez[0], _vzero));
  qvecyu = spu_nmsub(tvecxu, ez[0], spu_madd(tveczu, ex[0], _vzero));
  qveczu = spu_nmsub(tvecyu, ex[0], spu_madd(tvecxu, ey[0], _vzero));

  v = spu_mul (_dot_product3_v (rdx[0], rdy[0], rdz[0], qvecx, qvecy, qvecz), inv_det);
  vu = spu_mul (_dot_product3_v (rdx[1], rdy[1], rdz[1], qvecxu, qvecyu, qveczu), inv_detu);

  t = spu_mul (_dot_product3_v (ex[1], ey[1], ez[1], qvecx, qvecy, qvecz), inv_det);
  tu = spu_mul (_dot_product3_v (ex[1], ey[1], ez[1], qvecxu, qvecyu, qveczu), inv_detu);

  u_ge_0  = (vector unsigned int)spu_xor(spu_cmpgt (_vzero, u), -1);
  u_ge_0u  = (vector unsigned int)spu_xor(spu_cmpgt (_vzero, uu), -1);

  v_ge_0  = (vector unsigned int)spu_xor(spu_cmpgt (_vzero, v), -1);
  v_ge_0u  = (vector unsigned int)spu_xor(spu_cmpgt (_vzero, vu), -1);

  uv_le_1 = (vector unsigned int)spu_xor(spu_cmpgt (spu_add(u, v), _vone), -1);
  uv_le_1u = (vector unsigned int)spu_xor(spu_cmpgt (spu_add(uu, vu), _vone), -1);

  t_lt_h0 = (vector unsigned int)spu_cmpgt (ht, t);
  t_lt_h0u = (vector unsigned int)spu_cmpgt (htu, tu);

  t_ge_0  = (vector unsigned int)spu_xor(spu_cmpgt (_vzero, t), -1);
  t_ge_0u  = (vector unsigned int)spu_xor(spu_cmpgt (_vzero, tu), -1);

  vha = spu_and (u_ge_0, v_ge_0);
  vhau = spu_and (u_ge_0u, v_ge_0u);

  vhb = spu_and (uv_le_1, t_lt_h0);
  vhbu = spu_and (uv_le_1u, t_lt_h0u);

  validhit = spu_and (spu_and (vha, vhb), t_ge_0);
  validhitu = spu_and (spu_and (vhau, vhbu), t_ge_0u);

  hit_t[0]  = spu_sel (ht, t, validhit);
  hit_u[0]  = spu_sel (hu, u, validhit);
  hit_v[0]  = spu_sel (hv, v, validhit);
  hit_id[0] = spu_sel (hid, id, validhit);

  hit_t[1] = spu_sel (htu, tu, validhitu);
  hit_u[1] = spu_sel (huu, uu, validhitu);
  hit_v[1] = spu_sel (hvu, vu, validhitu);
  hit_id[1] = spu_sel (hidu, idu, validhit);

#else /* !__SPU__ */

  /* pvec = rd[0] CROSS e[1] 
   * pvecu = rd[1] CROSS e[1] 
   */
  pvecx = vec_nmsub(rdz[0], ey[1], vec_madd(rdy[0], ez[1], _vzero));
  pvecy = vec_nmsub(rdx[0], ez[1], vec_madd(rdz[0], ex[1], _vzero));
  pvecz = vec_nmsub(rdy[0], ex[1], vec_madd(rdx[0], ey[1], _vzero));

  pvecxu = vec_nmsub(rdz[1], ey[1], vec_madd(rdy[1], ez[1], _vzero));
  pvecyu = vec_nmsub(rdx[1], ez[1], vec_madd(rdz[1], ex[1], _vzero));
  pveczu = vec_nmsub(rdy[1], ex[1], vec_madd(rdx[1], ey[1], _vzero));

  det = _dot_product3_v (ex[0], ey[0], ez[0], pvecx, pvecy, pvecz);
  detu = _dot_product3_v (ex[0], ey[0], ez[0], pvecxu, pvecyu, pveczu);

  inv_det = _recipf4(det);
  inv_detu = _recipf4(detu);

  tvecx = vec_sub (rox[0], p0x);
  tvecxu = vec_sub (rox[1], p0x);

  tvecy = vec_sub (roy[0], p0y);
  tvecyu = vec_sub (roy[1], p0y);

  tvecz = vec_sub (roz[0], p0z);
  tveczu = vec_sub (roz[1], p0z);

  u = vec_madd (_dot_product3_v (tvecx, tvecy, tvecz, pvecx, pvecy, pvecz), inv_det, _vzero);
  uu = vec_madd (_dot_product3_v (tvecxu, tvecyu, tveczu, pvecxu, pvecyu, pveczu), inv_detu, _vzero);

  /* qvec = tvec CROSS e[0]
   * qvecu = tvecu CROSS e[0]
   */
  qvecx = vec_nmsub(tvecz, ey[0], vec_madd(tvecy, ez[0], _vzero));
  qvecy = vec_nmsub(tvecx, ez[0], vec_madd(tvecz, ex[0], _vzero));
  qvecz = vec_nmsub(tvecy, ex[0], vec_madd(tvecx, ey[0], _vzero));

  qvecxu = vec_nmsub(tveczu, ey[0], vec_madd(tvecyu, ez[0], _vzero));
  qvecyu = vec_nmsub(tvecxu, ez[0], vec_madd(tveczu, ex[0], _vzero));
  qveczu = vec_nmsub(tvecyu, ex[0], vec_madd(tvecxu, ey[0], _vzero));

  v = vec_madd (_dot_product3_v (rdx[0], rdy[0], rdz[0], qvecx, qvecy, qvecz), inv_det, _vzero);
  vu = vec_madd (_dot_product3_v (rdx[1], rdy[1], rdz[1], qvecxu, qvecyu, qveczu), inv_detu, _vzero);

  t = vec_madd (_dot_product3_v (ex[1], ey[1], ez[1], qvecx, qvecy, qvecz), inv_det, _vzero);
  tu = vec_madd (_dot_product3_v (ex[1], ey[1], ez[1], qvecxu, qvecyu, qveczu), inv_detu, _vzero);

  u_ge_0  = (vector unsigned int)vec_cmpge (u, _vzero);
  u_ge_0u  = (vector unsigned int)vec_cmpge (uu, _vzero);

  v_ge_0  = (vector unsigned int)vec_cmpge (v, _vzero);
  v_ge_0u  = (vector unsigned int)vec_cmpge (vu, _vzero);

  uv_le_1 = (vector unsigned int)vec_cmple (vec_add(u, v), _vone);
  uv_le_1u = (vector unsigned int)vec_cmple (vec_add(uu, vu), _vone);

  t_lt_h0 = (vector unsigned int)vec_cmplt (t, ht);
  t_lt_h0u = (vector unsigned int)vec_cmplt (tu, htu);

  t_ge_0  = (vector unsigned int)vec_cmpge (t, _vzero);
  t_ge_0u  = (vector unsigned int)vec_cmpge (tu, _vzero);

  vha = vec_and (u_ge_0, v_ge_0);
  vhau = vec_and (u_ge_0u, v_ge_0u);

  vhb = vec_and (uv_le_1, t_lt_h0);
  vhbu = vec_and (uv_le_1u, t_lt_h0u);

  validhit = vec_and (vec_and (vha, vhb), t_ge_0);
  validhitu = vec_and (vec_and (vhau, vhbu), t_ge_0u);

  hit_t[0]  = vec_sel (ht, t, validhit);
  hit_u[0]  = vec_sel (hu, u, validhit);
  hit_v[0]  = vec_sel (hv, v, validhit);
  hit_id[0] = vec_sel (hid, id, validhit);

  hit_t[1] = vec_sel (htu, tu, validhitu);
  hit_u[1] = vec_sel (huu, uu, validhitu);
  hit_v[1] = vec_sel (hvu, vu, validhitu);
  hit_id[1] = vec_sel (hidu, idu, validhit);

#endif /* __SPU__ */
}

#endif /* _intersect_ray8_triangle1_v_h_ */
