/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef _conv3x3_4ub_h_
#define _conv3x3_4ub_h_

#include <conv_defs.h>
#include <conv_shuf.h>
#include <conv_shuf_ub.h>

/* 
NAME
 	_conv3x3_4ub - 3x3 convolution for four component unsigned byte images

SYNOPSIS
	#include <conv3x3_4ub.h>

	void _conv3x3_4ub(const unsigned int *in[3], 
			  unsigned int *out, 
			  const vec_int4 m[9], int w, 
			  unsigned short scale, 
			  unsigned int shift)

DESCRIPTION
	Compute output pixels as the weighted sum of the input images's 
 	3x3 neighborhood and the filter mask 'm'.

	The image format is four component unsigned byte, also known as
	packed integer.  The filter mask 'm' represents an arbitrary 3x3 
	kernel, where each entry has been replicated to 'vec_int4' form.

	Scaled integer arithmetic is used to compute the weighted sum.
	For masks whose components sum to zero or one (common for many 
	sharpenning or edge-detect filters), values of 1 and 0 are 
	appropriate for 'scale' and 'shift'.  For masks whose components 
	sum to a value that is an an even power of two (e.g. 8, 16, etc.), 
	the shift value should be the log2 of the sum.  For masks whose 
	components sum to a value that is not an even power of two
	(common for many blurring or averaging filters), the shift and 
	scale values may be computed as follows:

	  scale = 2**log2(sum) * 65535 / sum
	  shift = 16 + log2(sum)

	Border pixels require a policy for defining values outside the
	image.  Three compile time options are supported.  The default 
	behaviour is to use _BORDER_COLOR_UB (pre-defined to 0) for all 
	values beyond the left or right edges of the input image.  For
	values above or below the image, the caller is responsible for
	supplying scanlines cleared to the appropriate value.
	
	When _WRAP_CONV is defined, the input values are periodically 
	repeated --in other words, the input wraps from left to right 
	(and visa-versa).  The caller is responsible for managing the 
	input scanlines to support wrapping from top to bottom.

	When _CLAMP_CONV is defined, the input values are clamped to the 
	border --in other words, the right most value is repeated for 
	values beyond the right edge of the image; the left most value 
	is repeated for values beyond the left edge of the image.  The
	caller is responsible for managing the input scanlines to support
	clamping from top to bottom.

RESTRICTIONS
 	The input and output scanlines must be quad-word aligned.  The 
	scanline width 'w' must be a multiple of 8 pixels.  
 */

static __inline void _conv3x3_4ub (const unsigned int *in[3], unsigned int *out, const vec_int4 m[9], int w, unsigned short scale, unsigned int shift)
{
  const vec_uint4 *in0 = (const vec_uint4 *)in[0];
  const vec_uint4 *in1 = (const vec_uint4 *)in[1];
  const vec_uint4 *in2 = (const vec_uint4 *)in[2];
  vec_uint4 *vout = (vec_uint4 *)out;
#ifdef __SPU__
  vec_int4 vshift   = _splat_int(-((int)shift));
#else
  vec_uint4 vshift   = (vec_uint4)_splat_int((int)shift);
#endif /* __SPU__ */
  vec_ushort8 vscale = (vec_ushort8)_splat_short((short)scale);
  vec_uint4 p0, p1, p2;
  vec_uint4 prev, curr, next;
  vec_uint4 prevu, curru, nextu;
  vec_uint4 left, right;
  vec_uint4 leftu, rightu;
  vec_int4 left_p0, left_p1, left_p2, left_p3;
  vec_int4 leftu_p0, leftu_p1, leftu_p2, leftu_p3;
  vec_int4 curr_p0, curr_p1, curr_p2, curr_p3;
  vec_int4 curru_p0, curru_p1, curru_p2, curru_p3;
  vec_int4 right_p0, right_p1, right_p2, right_p3;
  vec_int4 rightu_p0, rightu_p1, rightu_p2, rightu_p3;
  vec_int4 res_p0, res_p1, res_p2, res_p3;
  vec_int4 resu_p0, resu_p1, resu_p2, resu_p3;
  vec_uint4 res_sign_p0, res_sign_p1, res_sign_p2, res_sign_p3;
  vec_uint4 resu_sign_p0, resu_sign_p1, resu_sign_p2, resu_sign_p3;
  vec_uint4 res_p01, res_p23, res_p0123;
  vec_uint4 resu_p01, resu_p23, resu_p0123;
  vec_int4 m00, m01, m02, m03, m04;
  vec_int4 m05, m06, m07, m08;
  int i0, i1, i2;

  m00 = m[0]; m01 = m[1]; m02 = m[2]; m03 = m[3]; m04 = m[4];
  m05 = m[5]; m06 = m[6]; m07 = m[7]; m08 = m[8];

#ifdef _WRAP_CONV
  p0 = in0[(w>>2)-1];
  p1 = in1[(w>>2)-1];
  p2 = in2[(w>>2)-1];
#elif defined(_CLAMP_CONV)
  p0 = in0[0];
  p1 = in1[0];
  p2 = in2[0];
#else
  p0 = _BORDER_COLOR_UB;
  p1 = _BORDER_COLOR_UB;
  p2 = _BORDER_COLOR_UB;
#endif /* _WRAP_CONV */

#define _CONV3_4ub(_m0, _m1, _m2)		\
  left = vec_perm(prev, curr, left_shuf);	\
  leftu = vec_perm(prevu, curru, left_shuf);	\
  right = vec_perm(curr, next, right_shuf);	\
  rightu = vec_perm(curru, nextu, right_shuf);	\
  _GET_PIXELS_4ub(left);			\
  _GET_PIXELS_4ub(leftu);			\
  _GET_PIXELS_4ub(curr);			\
  _GET_PIXELS_4ub(curru);			\
  _GET_PIXELS_4ub(right);			\
  _GET_PIXELS_4ub(rightu);			\
  _CALC_PIXELS_4ub(left, _m0, res);		\
  _CALC_PIXELS_4ub(leftu, _m0, resu);		\
  _CALC_PIXELS_4ub(curr, _m1, res);		\
  _CALC_PIXELS_4ub(curru, _m1, resu);		\
  _CALC_PIXELS_4ub(right, _m2, res);		\
  _CALC_PIXELS_4ub(rightu, _m2, resu)
  
  for (i0=0, i1=1, i2=2; i0<(w>>2)-2; i0+=2, i1+=2, i2+=2)
  {
#ifdef __SPU__
    res_p0 = res_p1 = res_p2 = res_p3 = spu_splats((signed int)0);
    resu_p0 = resu_p1 = resu_p2 = resu_p3 = spu_splats((signed int)0);
#else /* !__SPU__ */
    res_p0 = res_p1 = res_p2 = res_p3 = ((vector signed int) {0,0,0,0});
    resu_p0 = resu_p1 = resu_p2 = resu_p3 = ((vector signed int) {0,0,0,0});
#endif /* __SPU__ */

    _GET_SCANLINE_x2(p0, in0[i0], in0[i1], in0[i2]);
    _CONV3_4ub(m00, m01, m02);

    _GET_SCANLINE_x2(p1, in1[i0], in1[i1], in1[i2]);
    _CONV3_4ub(m03, m04, m05);

    _GET_SCANLINE_x2(p2, in2[i0], in2[i1], in2[i2]);
    _CONV3_4ub(m06, m07, m08);

    _CLAMP_PIXELS_4ub(res);
    _CLAMP_PIXELS_4ub(resu);
    _PACK_PIXELS_4ub(res);
    _PACK_PIXELS_4ub(resu);
    vout[i0] = res_p0123;
    vout[i1] = resu_p0123;
  }
#ifdef __SPU__
  res_p0 = res_p1 = res_p2 = res_p3 = spu_splats((signed int)0);
  resu_p0 = resu_p1 = resu_p2 = resu_p3 = spu_splats((signed int)0);
#else /* !__SPU__ */
  res_p0 = res_p1 = res_p2 = res_p3 = ((vector signed int) {0,0,0,0});
  resu_p0 = resu_p1 = resu_p2 = resu_p3 = ((vector signed int) {0,0,0,0});
#endif /* __SPU__ */

#ifdef _WRAP_CONV
  _GET_SCANLINE_x2(p0, in0[i0], in0[i1], in0[0]);
  _CONV3_4ub(m00, m01, m02);
 
  _GET_SCANLINE_x2(p1, in1[i0], in1[i1], in1[0]);
  _CONV3_4ub(m03, m04, m05);
 
  _GET_SCANLINE_x2(p2, in2[i0], in2[i2], in2[0]);
  _CONV3_4ub(m06, m07, m08);

#elif defined(_CLAMP_CONV)
  _GET_SCANLINE_x2(p0, in0[i0], in0[i1], in0[i1]);
  _CONV3_4ub(m00, m01, m02);

  _GET_SCANLINE_x2(p1, in1[i0], in1[i1], in1[i1]);
  _CONV3_4ub(m03, m04, m05);

  _GET_SCANLINE_x2(p2, in2[i0], in2[i2], in2[i1]);
  _CONV3_4ub(m06, m07, m08);

#else
  _GET_SCANLINE_x2(p0, in0[i0], in0[i1], _BORDER_COLOR_UB);
  _CONV3_4ub(m00, m01, m02);
 
  _GET_SCANLINE_x2(p1, in1[i0], in1[i1], _BORDER_COLOR_UB);
  _CONV3_4ub(m03, m04, m05);
 
  _GET_SCANLINE_x2(p2, in2[i0], in2[i1], _BORDER_COLOR_UB);
  _CONV3_4ub(m06, m07, m08);

#endif /* _WRAP_CONV */

  _CLAMP_PIXELS_4ub(res);
  _CLAMP_PIXELS_4ub(resu);
  _PACK_PIXELS_4ub(res);
  _PACK_PIXELS_4ub(resu);
  vout[i0] = res_p0123;
  vout[i1] = resu_p0123;
}

#endif /* _conv3x3_4ub_h_ */
