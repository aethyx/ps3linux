/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _LIB_MISC_H_
#define _LIB_MISC_H_	1

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

extern float clamp_0_to_1(float in);
extern vector float clamp_0_to_1_v(vector float in);
extern float clamp_minus1_to_1(float in);
extern vector float clamp_minus1_to_1_v(vector float in);
extern float clamp(float in, float min, float max);
extern vector float clamp_v(vector float in, vector float min, vector float max);

extern float rand_minus1_to_1(void);
extern float rand_0_to_1(void);
extern vector float rand_minus1_to_1_v(void);
extern vector float rand_0_to_1_v(void);

extern vector unsigned char load_vec_unaligned(unsigned char *ptr);
extern void store_vec_unaligned(unsigned char * ptr, vector unsigned char data);

extern float max_vec_float3(vector float in);
extern float max_vec_float4(vector float in);
extern signed int max_vec_int3(vector signed int in);
extern signed int max_vec_int4(vector signed int in);
extern float min_vec_float3(vector float in);
extern float min_vec_float4(vector float in);
extern signed int min_vec_int3(vector signed int in);
extern signed int min_vec_int4(vector signed int in);
extern vector float min_float_v(vector float in1, vector float in2);
extern vector float max_float_v(vector float in1, vector float in2);
extern vector signed int max_int_v(vector signed int in1, vector signed int in2);
extern vector signed int min_int_v(vector signed int in1, vector signed int in2);

extern void *malloc_align(size_t size, unsigned int log2_align);
extern void *calloc_align(size_t nmemb, size_t size, unsigned int log2_align);
extern void *realloc_align(void *ptr, size_t size, unsigned int log2_align);
extern void  free_align(void *ptr);

extern vector unsigned int rand_seed;
extern void srand_v(vector unsigned int seed);
extern vector signed int rand_v(void);

#ifdef __SPU__

extern size_t copy_to_ls(uint32_t to, uint64_t from, size_t n);
extern size_t copy_from_ls(uint64_t to, uint32_t from, size_t n);

#endif /* __SPU__ */

#ifdef __cplusplus
}
#endif

#endif /* _LIB_MISC_H_ */





