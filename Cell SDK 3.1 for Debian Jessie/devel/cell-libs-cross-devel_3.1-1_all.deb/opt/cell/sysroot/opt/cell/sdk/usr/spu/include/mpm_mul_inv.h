/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _MPM_MUL_INV_H_
#define _MPM_MUL_INV_H_	1

#include <spu_intrinsics.h>
#include "mpm_defines.h"
#include "mpm_macros.h"
#include "mpm_cmpge.h"
#include "mpm_sub.h"

/* mpm_mul_inv
 * -----------
 * Routine that computes the multiplicative inverse of large numbers 
 * <a> and <b> of size <size> quadwords respectively. The multiplicative 
 * inverse is the value <mi> of <size> quadwords such that
 *
 *	(mi * b) % a = 1
 *
 * If the multiplicative inverse does not exit than 0 is returned. Otherwise,
 * 1 is returns and the large number pointed to by <mi> is filled with the
 * result.
 *
 * This function assumes that a > b > 0.
 *
 * The basic algorithn is:
 *
 * 1. If the lsb of both a and b are 0, then return 0.
 * 2. u = a
 * 3. v = b
 * 4. q = 1
 * 5. r = 0
 * 6. s = 0
 * 7. t = 1
 * 8. do
 *    8.1  while the lsb of u is 0
 *         8.1.1  u >>= 1
 *         8.1.2  if lsb of q or r is 1 then
 *              8.1.2.1  q += b
 *              8.1.2.2  r -= a
 *         8.1.3  q >>= 1
 *         8.1.4  r >>= 1
 *    8.2  while the lsb of v is 0
 *         8.2.1  v >>= 1
 *         8.2.2  if lsb of s or t is 1 then
 *              8.2.2.1  s += b
 *              8.2.2.2  t -= a
 *         8.2.3  s >>= 1
 *         8.2.4  t >>= 1
 *    8.3  if (u >= v) then
 *         8.3.1  u -= v
 *         8.3.2  q -= s
 *         8.3.3  r -= t
 *         else
 *         8.3.4  v -= u
 *         8.3.5  s -= q
 *         8.3.6  t -= r
 *    while (u != 0)
 * 9. if (v == 1) then
 *    9.1  if (t < 0) 
 *         9.1.1  do
 *		  9.1.1.1  t += a
 *                while (t < 0)
 *    9.2  else 
 *	   9.2.1  while (t >= a) then
 *                9.2.1.1  t -= a
 *                endwhile
 *    9.2  mi = t
 *    9.3  return 1
 *    else
 *    9.4  return 0 	"does not exist"
 */

static __inline int _mpm_mul_inv(vector unsigned int *mi, const vector unsigned int *a, const vector unsigned int *b, int size)
{
  int i, delta;
  int uvsize;
  vector unsigned int or, or_u;
  vector unsigned int zero = spu_splats((unsigned int)0);
  vector unsigned int one  = spu_splats((unsigned int)1);
  vector unsigned int msb  = ((vector unsigned int) { 0x80000000, 0, 0, 0});
  vector unsigned int lsb  = ((vector unsigned int) { 0, 0, 0, 1});
  vector unsigned int borrow, b0, b1, b2, carry;
  vector unsigned int u0, v0, q0, r0, s0, t0;
  vector unsigned int u1, v1, q1, r1, s1, t1;
  vector unsigned int q_msw, r_msw, s_msw, t_msw;
  vector unsigned int u[MPM_MAX_SIZE];
  vector unsigned int v[MPM_MAX_SIZE];
  vector unsigned int q[MPM_MAX_SIZE];
  vector unsigned int r[MPM_MAX_SIZE];
  vector unsigned int s[MPM_MAX_SIZE];
  vector unsigned int t[MPM_MAX_SIZE];
  vector unsigned int *pu, *pv;

  /* 1. If the least significant bits of both a and b are 0, then return 0
   * indicating that the multiplication inverse does not exist.
   */
  if (spu_extract(spu_and(spu_or(a[size-1], b[size-1]), 1), 3) == 0) {
    return 0;
  }

  /* 2. u = a
   * 3. v = b
   * 4. q = 1
   * 5. r = 0
   * 6. s = 0
   * 7. t = 1
   *
   * q, r, s, and t can be up to 1 word larger than a. The extra word will be 
   * stored in element 3 of the vectors q_msw, r_msw, s_msw, t_msw.
   */
  for (i=0; i<size-1; i++) {
    u[i] = a[i];
    v[i] = b[i];
    q[i] = r[i]  = s[i] = t[i] = zero;
  }
  u[i] = a[i];
  v[i] = b[i];
  r[i] = s[i]  = zero;
  q[i] = t[i]  = lsb;

  or_u  = lsb;
  q_msw = r_msw = s_msw = t_msw = zero;

  uvsize = size;
  pu = u;
  pv = v;

  /* 8. do
   */
  do {
    /* 8.1 while the lsb of u is 0
     */
    while ((spu_extract(u[size-1], 3) & 1) == 0) {
      /* 8.1.2 if lsb of q or r is 1
       */
      or_u = zero;

      if (__builtin_expect(spu_extract(spu_or(q[size-1], r[size-1]), 3) & 1, 1)) {
	/* 8.1.2.1/8.1.3  q = (q+b) >> 1
	 * 8.1.2.2/8.1.4  r = (r-a) >> 1
	 * 8.1.1          u >>= 1
	 */
	MPM_ADD_FULL(q1, carry, q[size-1],  b[size-1], zero)
	carry = spu_rlmaskqwbyte(carry, -12);
	MPM_SUB_FULL(r1, borrow, r[size-1], a[size-1], one)

	u1 = spu_rlqw(spu_rlqwbyte(u[size-1], 15), 7);
	q1 = spu_rlqw(spu_rlqwbyte(q1, 15), 7);
	r1 = spu_rlqw(spu_rlqwbyte(r1, 15), 7);

	for (i=size-2; i>=0; i--) {
	  MPM_ADD_FULL(q0, carry, q[i],  b[i], carry)
	  carry = spu_rlmaskqwbyte(carry, -12);
	  MPM_SUB_FULL(r0, borrow, r[i], a[i], borrow)

	  u0 = spu_rlqw(spu_rlqwbyte(u[i], 15), 7);
	  q0 = spu_rlqw(spu_rlqwbyte(q0, 15), 7);
	  r0 = spu_rlqw(spu_rlqwbyte(r0, 15), 7);

	  u1 = spu_sel(u1, u0, msb);

	  u[i+1] = u1;
	  q[i+1] = spu_sel(q1, q0, msb);
	  r[i+1] = spu_sel(r1, r0, msb);

	  or_u = spu_or(or_u, u1);

	  u1 = u0;
	  q1 = q0;
	  r1 = r0;
	}
	q0 = spu_add(q_msw, carry);
	r0 = spu_subx(r_msw, zero, borrow);

	u0 = spu_sel(u1, zero, msb);
	u[0] = u0;
	q[0] = spu_sel(q1, spu_rlqwbyte(spu_rl(q0, -1), 12), msb);
	r[0] = spu_sel(r1, spu_rlqwbyte(spu_rl(r0, -1), 12), msb);
	
	or_u = spu_or(u0, or_u);

	q_msw = spu_rlmaska(q0, -1);
	r_msw = spu_rlmaska(r0, -1);

      } else {
	/* 8.1.1  u >>= 1
	 * 8.1.3  q >>= 1
	 * 8.1.4  r >>= 1
	 */
	u0 = spu_splats((unsigned int)0);
	q0 = spu_rlqwbyte(spu_rl(q_msw, -1), 12);
	r0 = spu_rlqwbyte(spu_rl(r_msw, -1), 12);
	q_msw = spu_rlmaska(q_msw, -1);
	r_msw = spu_rlmaska(r_msw, -1);
	for (i=0; i<size; i++) {
	  u1 = spu_rlqw(spu_rlqwbyte(u[i], 15), 7);
	  q1 = spu_rlqw(spu_rlqwbyte(q[i], 15), 7);
	  r1 = spu_rlqw(spu_rlqwbyte(r[i], 15), 7);

	  u0 = spu_sel(u1, u0, msb);

	  u[i] = u0;
	  q[i] = spu_sel(q1, q0, msb);
	  r[i] = spu_sel(r1, r0, msb);

	  or_u = spu_or(u0, or_u);

	  u0 = u1;
	  q0 = q1;
	  r0 = r1;
	}
      }
    }

    /* 8.2 while the lsb of v is 0
     */
    while ((spu_extract(v[size-1], 3) & 1) == 0) {
      /* 8.2.2 if lsb of s or t is 1
       */
      if (__builtin_expect(spu_extract(spu_or(s[size-1], t[size-1]), 3) & 1, 1)) {
	/* 8.2.2.1/8.2.3  s = (s+b) >> 1
	 * 8.2.2.2/8.2.4  t = (t-a) >> 1
	 * 8.2.1          v >>= 1
	 */
	MPM_ADD_FULL(s1, carry, s[size-1],  b[size-1], zero)
	carry = spu_rlmaskqwbyte(carry, -12);
	MPM_SUB_FULL(t1, borrow, t[size-1], a[size-1], one)

	v1 = spu_rlqw(spu_rlqwbyte(v[size-1], 15), 7);
	s1 = spu_rlqw(spu_rlqwbyte(s1, 15), 7);
	t1 = spu_rlqw(spu_rlqwbyte(t1, 15), 7);

	for (i=size-2; i>=0; i--) {
	  MPM_ADD_FULL(s0, carry, s[i],  b[i], carry);
	  carry = spu_rlmaskqwbyte(carry, -12);
	  MPM_SUB_FULL(t0, borrow, t[i], a[i], borrow);

	  v0 = spu_rlqw(spu_rlqwbyte(v[i], 15), 7);
	  s0 = spu_rlqw(spu_rlqwbyte(s0, 15), 7);
	  t0 = spu_rlqw(spu_rlqwbyte(t0, 15), 7);

	  v[i+1] = spu_sel(v1, v0, msb);
	  s[i+1] = spu_sel(s1, s0, msb);
	  t[i+1] = spu_sel(t1, t0, msb);

	  v1 = v0;
	  s1 = s0;
	  t1 = t0;
	}
	s0 = spu_add(s_msw, carry);
	t0 = spu_subx(t_msw, zero, borrow);

	v[0] = spu_sel(v1, zero, msb);
	s[0] = spu_sel(s1, spu_rlqwbyte(spu_rl(s0, -1), 12), msb);
	t[0] = spu_sel(t1, spu_rlqwbyte(spu_rl(t0, -1), 12), msb);
	
	s_msw = spu_rlmaska(s0, -1);
	t_msw = spu_rlmaska(t0, -1);

      } else {
	/* 8.1.1  v >>= 1
	 * 8.1.3  s >>= 1
	 * 8.1.4  t >>= 1
	 */
	v0 = spu_splats((unsigned int)0);
	s0 = spu_rlqwbyte(spu_rl(s_msw, -1), 12);
	t0 = spu_rlqwbyte(spu_rl(t_msw, -1), 12);
	s_msw = spu_rlmaska(s_msw, -1);
	t_msw = spu_rlmaska(t_msw, -1);
	for (i=0; i<size; i++) {
	  v1 = spu_rlqw(spu_rlqwbyte(v[i], 15), 7);
	  s1 = spu_rlqw(spu_rlqwbyte(s[i], 15), 7);
	  t1 = spu_rlqw(spu_rlqwbyte(t[i], 15), 7);

	  v[i] = spu_sel(v1, v0, msb);
	  s[i] = spu_sel(s1, s0, msb);
	  t[i] = spu_sel(t1, t0, msb);

	  v0 = v1;
	  s0 = s1;
	  t0 = t1;
	}
      }
    }


    /* 8.3 if (u >= v) 
     */
    if (_mpm_cmpge(pu, pv, uvsize)) {
      /* 8.3.1  u -= v
       * 8.3.2  q -= s
       * 8.3.3  r -= t
       */
      or_u = zero;

      b0 = b1 = b2 = one;
      for (i=size-1; i>=0; i--) {
	u0 = u[i]; v0 = v[i];
	q0 = q[i]; s0 = s[i];
	r0 = r[i]; t0 = t[i];

	MPM_SUB_FULL(u0,   b0, u0, v0, b0)
	MPM_SUB_FULL(q[i], b1, q0, s0, b1)
	MPM_SUB_FULL(r[i], b2, r0, t0, b2)

	or_u = spu_or(u0, or_u);
	u[i] = u0;
      }
      q_msw = spu_subx(q_msw, s_msw, b1);
      r_msw = spu_subx(r_msw, t_msw, b2);

    } else {
      /* 8.3.4  v -= u
       * 8.3.5  s -= q
       * 8.3.6  t -= r
       */
      b0 = b1 = b2 = one;
      for (i=size-1; i>=0; i--) {
	u0 = u[i]; v0 = v[i];
	q0 = q[i]; s0 = s[i];
	r0 = r[i]; t0 = t[i];
	MPM_SUB_FULL(v[i], b0, v0, u0, b0)
	MPM_SUB_FULL(s[i], b1, s0, q0, b1)
	MPM_SUB_FULL(t[i], b2, t0, r0, b2)
      }
      s_msw = spu_subx(s_msw, q_msw, b1);
      t_msw = spu_subx(t_msw, r_msw, b2);
    }

    /* Skip leading quadwords as u and v get smaller.
     */
    delta = (int)spu_extract(spu_cmpeq(spu_gather(spu_cmpeq(spu_or(*pu, *pv), 0)), 15), 0);
    pu -= delta;
    pv -= delta;
    uvsize += delta;

    /* while (u != 0) 
     */
  } while (spu_extract(spu_gather(spu_cmpeq(or_u, 0)), 0) != 15);

  /* 9. if (v == 1) then
   */
  for (i=uvsize-2, or=spu_xor(pv[uvsize-1], lsb); i>=0; i--) or = spu_or(or, pv[i]);

  if (spu_extract(spu_gather(spu_cmpeq(or, 0)), 0) != 15) {
    /* 9.4  multiplicative inverse does not exist.
     */
    return (0);
  }

  /* 9.1 if (t < 0) 
   */
  if ((signed int)(spu_extract(t_msw, 3)) < 0) {
    do {
      /* 9.1.1.1  t += a
       */
      for (i=size-1, carry=zero; i>=0; i--) {
	MPM_ADD_FULL(t[i], carry, t[i], a[i], carry)
	carry = spu_rlmaskqwbyte(carry, -12);
      }
      t_msw = spu_add(t_msw, carry);
    } while ((signed int)(spu_extract(t_msw, 3)) < 0);
  } else {
    /* 9.2.1 
     */
    while (_mpm_cmpge(t, a, size)) {
      _mpm_sub(t, t, a, size);
    }
  }

  /* 9.2 mi = t
   */
  for (i=0; i<size; i++) mi[i] = t[i];

  return (1);
}

#endif /* _MPM_MUL_INV_H_ */
