/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _MAX_VEC_FLOAT4_H_
#define _MAX_VEC_FLOAT4_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 *	float _max_vec_float4(vector float in)
 *
 * DESCRIPTION
 *	_max_vec_float4 subroutine returns the maximum of the 4 floating-point
 *	components of the floating-point vector in.
 *
 *	This function is written to minimize instructions with the 
 *	expectation that dead cycles can be filled in with other code.
 */

static __inline float _max_vec_float4(vector float in) 
{
#ifdef __SPU__
  vector float in_r;
  vector unsigned int cmp;

  in_r = spu_rlqwbyte(in, 4);
  cmp  = spu_cmpgt(in, in_r);
  in   = spu_sel(in_r, in, cmp);  
  in_r = spu_rlqwbyte(in, 8);
  cmp  = spu_cmpgt(in, in_r);
  return (spu_extract(spu_sel(in_r, in, cmp), 0));

#else
  vector float in_1, in_2, in_3;
  union {
    vector float fv;
    float f[4];
  } result;
  
  in_1 = vec_splat(in, 1);
  in_2 = vec_splat(in, 2);
  in_3 = vec_splat(in, 3);

  in_1 = vec_max(in,   in_1);
  in_2 = vec_max(in_2, in_3);
  result.fv = vec_max(in_1, in_2);

  return (result.f[0]);
#endif
}

#endif /* _MAX_VEC_FLOAT4_H_ */
