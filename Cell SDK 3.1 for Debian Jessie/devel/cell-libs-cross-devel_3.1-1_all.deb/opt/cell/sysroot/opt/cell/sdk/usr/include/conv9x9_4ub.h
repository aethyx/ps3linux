/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef _conv9x9_4ub_h_
#define _conv9x9_4ub_h_

#include <conv_defs.h>
#include <conv_shuf.h>
#include <conv_shuf_ub.h>

/* 
NAME
 	_conv9x9_4ub - 9x9 convolution for four component unsigned byte images

SYNOPSIS
	#include <conv9x9_4ub.h>

	void _conv9x9_4ub(const unsigned int *in[9], 
			  unsigned int *out, 
			  const vec_int4 m[81], int w, 
			  unsigned short scale, 
			  unsigned int shift)

DESCRIPTION
	Compute output pixels as the weighted sum of the input images's 
 	9x9 neighborhood and the filter mask 'm'.

	The image format is four component unsigned byte, also known as
	packed integer.  The filter mask 'm' represents an arbitrary 9x9 
	kernel, where each entry has been replicated to 'vec_int4' form.

	Scaled integer arithmetic is used to compute the weighted sum.
	For masks whose components sum to zero or one (common for many 
	sharpenning or edge-detect filters), values of 1 and 0 are 
	appropriate for 'scale' and 'shift'.  For masks whose components 
	sum to a value that is an an even power of two (e.g. 8, 16, etc.), 
	the shift value should be the log2 of the sum.  For masks whose 
	components sum to a value that is not an even power of two
	(common for many blurring or averaging filters), the shift and 
	scale values may be computed as follows:

	  scale = 2**log2(sum) * 65535 / sum
	  shift = 16 + log2(sum)

	Border pixels require a policy for defining values outside the
	image.  Three compile time options are supported.  The default 
	behaviour is to use _BORDER_COLOR_UB (pre-defined to 0) for all 
	values beyond the left or right edges of the input image.  For
	values above or below the image, the caller is responsible for
	supplying scanlines cleared to the appropriate value.
	
	When _WRAP_CONV is defined, the input values are periodically 
	repeated --in other words, the input wraps from left to right 
	(and visa-versa).  The caller is responsible for managing the 
	input scanlines to support wrapping from top to bottom.

	When _CLAMP_CONV is defined, the input values are clamped to the 
	border --in other words, the right most value is repeated for 
	values beyond the right edge of the image; the left most value 
	is repeated for values beyond the left edge of the image.  The
	caller is responsible for managing the input scanlines to support
	clamping from top to bottom.

RESTRICTIONS
 	The input and output scanlines must be quad-word aligned.  The 
	scanline width 'w' must be a multiple of 8 pixels.  
 */

static __inline void _conv9x9_4ub (const unsigned int *in[9], unsigned int *out, const vec_int4 m[81], int w, unsigned short scale, unsigned int shift)
{
  const vec_uint4 *in0 = (const vec_uint4 *)in[0];
  const vec_uint4 *in1 = (const vec_uint4 *)in[1];
  const vec_uint4 *in2 = (const vec_uint4 *)in[2];
  const vec_uint4 *in3 = (const vec_uint4 *)in[3];
  const vec_uint4 *in4 = (const vec_uint4 *)in[4];
  const vec_uint4 *in5 = (const vec_uint4 *)in[5];
  const vec_uint4 *in6 = (const vec_uint4 *)in[6];
  const vec_uint4 *in7 = (const vec_uint4 *)in[7];
  const vec_uint4 *in8 = (const vec_uint4 *)in[8];
  vec_uint4 *vout = (vec_uint4 *)out;
#ifdef __SPU__
  vec_int4 vshift   = _splat_int(-((int)shift));
#else
  vec_uint4 vshift   = (vec_uint4)_splat_int((int)shift);
#endif /* __SPU__ */
  vec_ushort8 vscale = (vec_ushort8)_splat_short((short)scale);
  vec_uint4 p0, p1, p2, p3, p4, p5, p6, p7, p8;
  vec_uint4 prev, curr, next;
  vec_uint4 left, right;
  vec_uint4 left2, right2;
  vec_uint4 left3, right3;
  vec_uint4 left4, right4;
  vec_int4 left4_p0, left4_p1, left4_p2, left4_p3;
  vec_int4 left3_p0, left3_p1, left3_p2, left3_p3;
  vec_int4 left2_p0, left2_p1, left2_p2, left2_p3;
  vec_int4 left_p0, left_p1, left_p2, left_p3;
  vec_int4 curr_p0, curr_p1, curr_p2, curr_p3;
  vec_int4 right_p0, right_p1, right_p2, right_p3;
  vec_int4 right2_p0, right2_p1, right2_p2, right2_p3;
  vec_int4 right3_p0, right3_p1, right3_p2, right3_p3;
  vec_int4 right4_p0, right4_p1, right4_p2, right4_p3;
  vec_int4 res_p0, res_p1, res_p2, res_p3;
  vec_uint4 res_sign_p0, res_sign_p1, res_sign_p2, res_sign_p3;
  vec_uint4 res_p01, res_p23, res_p0123;
  vec_int4 m00, m01, m02, m03, m04, m05, m06, m07, m08;
  int i0, i1;

#ifdef _WRAP_CONV
  p0 = in0[(w>>2)-1];
  p1 = in1[(w>>2)-1];
  p2 = in2[(w>>2)-1];
  p3 = in3[(w>>2)-1];
  p4 = in4[(w>>2)-1];
  p5 = in5[(w>>2)-1];
  p6 = in6[(w>>2)-1];
  p7 = in7[(w>>2)-1];
  p8 = in8[(w>>2)-1];
#elif defined(_CLAMP_CONV)
  p0 = in0[0];
  p1 = in1[0];
  p2 = in2[0];
  p3 = in3[0];
  p4 = in4[0];
  p5 = in5[0];
  p6 = in6[0];
  p7 = in7[0];
  p8 = in8[0];
#else
  p0 = _BORDER_COLOR_UB;
  p1 = _BORDER_COLOR_UB;
  p2 = _BORDER_COLOR_UB;
  p3 = _BORDER_COLOR_UB;
  p4 = _BORDER_COLOR_UB;
  p5 = _BORDER_COLOR_UB;
  p6 = _BORDER_COLOR_UB;
  p7 = _BORDER_COLOR_UB;
  p8 = _BORDER_COLOR_UB;
#endif /* _WRAP_CONV */

#define _CONV9_4ub(_i)				\
  m00 = m[_i+0]; m01 = m[_i+1];			\
  m02 = m[_i+2]; m03 = m[_i+3];			\
  m04 = m[_i+4]; m05 = m[_i+5];			\
  m06 = m[_i+6]; m07 = m[_i+7];			\
  m08 = m[_i+8];				\
  left4 = prev;					\
  left3 = vec_perm(prev, curr, left3_shuf);	\
  left2 = vec_perm(prev, curr, left2_shuf);	\
  left = vec_perm(prev, curr, left_shuf);	\
  right = vec_perm(curr, next, right_shuf);	\
  right2 = vec_perm(curr, next, right2_shuf);	\
  right3 = vec_perm(curr, next, right3_shuf);	\
  right4 = next;				\
  _GET_PIXELS_4ub(left4);			\
  _GET_PIXELS_4ub(left3);			\
  _GET_PIXELS_4ub(left2);			\
  _GET_PIXELS_4ub(left);			\
  _GET_PIXELS_4ub(curr);			\
  _GET_PIXELS_4ub(right);			\
  _GET_PIXELS_4ub(right2);			\
  _GET_PIXELS_4ub(right3);			\
  _GET_PIXELS_4ub(right4);			\
  _CALC_PIXELS_4ub(left4, m00, res);		\
  _CALC_PIXELS_4ub(left3, m01, res);		\
  _CALC_PIXELS_4ub(left2, m02, res);		\
  _CALC_PIXELS_4ub(left, m03, res);		\
  _CALC_PIXELS_4ub(curr, m04, res);		\
  _CALC_PIXELS_4ub(right, m05, res);		\
  _CALC_PIXELS_4ub(right2, m06, res);		\
  _CALC_PIXELS_4ub(right3, m07, res);		\
  _CALC_PIXELS_4ub(right4, m08, res)
  
  for (i0=0, i1=1; i0<(w>>2)-1; i0+=1, i1+=1)
  {
#ifdef __SPU__
    res_p0 = res_p1 = res_p2 = res_p3 = spu_splats((signed int)0);
#else /* !__SPU__ */
    res_p0 = res_p1 = res_p2 = res_p3 = ((vector signed int) {0,0,0,0});
#endif /* __SPU__ */

    _GET_SCANLINE(p0, in0[i0], in0[i1]);
    _CONV9_4ub(0);

    _GET_SCANLINE(p1, in1[i0], in1[i1]);
    _CONV9_4ub(9);

    _GET_SCANLINE(p2, in2[i0], in2[i1]);
    _CONV9_4ub(18);

    _GET_SCANLINE(p3, in3[i0], in3[i1]);
    _CONV9_4ub(27);

    _GET_SCANLINE(p4, in4[i0], in4[i1]);
    _CONV9_4ub(36);

    _GET_SCANLINE(p5, in5[i0], in5[i1]);
    _CONV9_4ub(45);

    _GET_SCANLINE(p6, in6[i0], in6[i1]);
    _CONV9_4ub(54);

    _GET_SCANLINE(p7, in7[i0], in7[i1]);
    _CONV9_4ub(63);

    _GET_SCANLINE(p8, in8[i0], in8[i1]);
    _CONV9_4ub(72);

    _CLAMP_PIXELS_4ub(res);
    _PACK_PIXELS_4ub(res);
    vout[i0] = res_p0123;
  }
#ifdef __SPU__
  res_p0 = res_p1 = res_p2 = res_p3 = spu_splats((signed int)0);
#else /* !__SPU__ */
  res_p0 = res_p1 = res_p2 = res_p3 = ((vector signed int) {0,0,0,0});
#endif /* __SPU__ */

#ifdef _WRAP_CONV
  _GET_SCANLINE(p0, in0[i0], in0[0]);
  _CONV9_4ub(0);
 
  _GET_SCANLINE(p1, in1[i0], in1[0]);
  _CONV9_4ub(9);
 
  _GET_SCANLINE(p2, in2[i0], in2[0]);
  _CONV9_4ub(18);

  _GET_SCANLINE(p3, in3[i0], in3[0]);
  _CONV9_4ub(27);

  _GET_SCANLINE(p4, in4[i0], in4[0]);
  _CONV9_4ub(36);

  _GET_SCANLINE(p5, in5[i0], in5[0]);
  _CONV9_4ub(45);

  _GET_SCANLINE(p6, in6[i0], in6[0]);
  _CONV9_4ub(54);

  _GET_SCANLINE(p7, in7[i0], in7[0]);
  _CONV9_4ub(63);

  _GET_SCANLINE(p8, in8[i0], in8[0]);
  _CONV9_4ub(72);

#elif defined(_CLAMP_CONV)
  _GET_SCANLINE(p0, in0[i0], in0[i0]);
  _CONV9_4ub(0);

  _GET_SCANLINE(p1, in1[i0], in1[i0]);
  _CONV9_4ub(9);

  _GET_SCANLINE(p2, in2[i0], in2[i0]);
  _CONV9_4ub(18);

  _GET_SCANLINE(p3, in3[i0], in3[i0]);
  _CONV9_4ub(27);

  _GET_SCANLINE(p4, in4[i0], in4[i0]);
  _CONV9_4ub(36);

  _GET_SCANLINE(p5, in5[i0], in5[i0]);
  _CONV9_4ub(45);

  _GET_SCANLINE(p6, in6[i0], in6[i0]);
  _CONV9_4ub(54);

  _GET_SCANLINE(p7, in7[i0], in7[i0]);
  _CONV9_4ub(63);

  _GET_SCANLINE(p8, in8[i0], in8[i0]);
  _CONV9_4ub(72);

#else
  _GET_SCANLINE(p0, in0[i0], _BORDER_COLOR_UB);
  _CONV9_4ub(0);

  _GET_SCANLINE(p1, in1[i0], _BORDER_COLOR_UB);
  _CONV9_4ub(9);

  _GET_SCANLINE(p2, in2[i0], _BORDER_COLOR_UB);
  _CONV9_4ub(18);

  _GET_SCANLINE(p3, in3[i0], _BORDER_COLOR_UB);
  _CONV9_4ub(27);

  _GET_SCANLINE(p4, in4[i0], _BORDER_COLOR_UB);
  _CONV9_4ub(36);

  _GET_SCANLINE(p5, in5[i0], _BORDER_COLOR_UB);
  _CONV9_4ub(45);

  _GET_SCANLINE(p6, in6[i0], _BORDER_COLOR_UB);
  _CONV9_4ub(54);

  _GET_SCANLINE(p7, in7[i0], _BORDER_COLOR_UB);
  _CONV9_4ub(63);

  _GET_SCANLINE(p8, in8[i0], _BORDER_COLOR_UB);
  _CONV9_4ub(72);

#endif /* _WRAP_CONV */

  _CLAMP_PIXELS_4ub(res);
  _PACK_PIXELS_4ub(res);
  vout[i0] = res_p0123;
}

#endif /* _conv9x9_4ub_h_ */
