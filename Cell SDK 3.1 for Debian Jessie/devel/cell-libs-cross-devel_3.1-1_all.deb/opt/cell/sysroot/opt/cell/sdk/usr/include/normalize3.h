/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _NORMALIZE3_H_
#define _NORMALIZE3_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif
#include <simdmath/rsqrtf4.h>

/*
 * FUNCTION
 * 	vector float _normalize3(vector float in)
 * 
 * DESCRIPTION
 *	_normalize3 normalizes the input vector specified by the parameter
 *	in and return the result. The input and output vectors are assumed
 *	to be 3 compoent vectors of the form:
 *           _______________________________
 *          |___X___|___Y___|___Z___|_______|
 *        
 *	Vector normalization is computed as follows.
 *
 *	    len = sqrt(in.x*in.x + in.y*in.y + in.z*in.z)
 *     	    result.x = in.x / len;
 *     	    result.y = in.y / len;
 *     	    result.z = in.z / len;
 *
 *	The 4th component of the result is undefined. 
 *	
 *	This routine contains a significant number of dependent operations.
 *	Good performance depends upon interleaving this code with other 
 *	processing.
 */

static __inline vector float _normalize3(vector float in)
{
  vector float sum;
  vector float scale;
  vector float x2y2z2, y2z2x2, z2x2y2;
  vector unsigned char shuffle = ((vector unsigned char) { 
					     0x04, 0x05, 0x06, 0x07,
					     0x08, 0x09, 0x0A, 0x0B,
					     0x00, 0x01, 0x02, 0x03,
					     0x00, 0x00, 0x00, 0x00});
#ifdef __SPU__
  x2y2z2 = spu_mul(in, in);
  y2z2x2 = spu_shuffle(x2y2z2, x2y2z2, shuffle);
  z2x2y2 = spu_shuffle(y2z2x2, y2z2x2, shuffle);
  sum = spu_add(x2y2z2, y2z2x2);
  sum = spu_add(sum, z2x2y2);
  scale = _rsqrtf4(sum);
  return (spu_mul(scale, in));
#else
  vector float vzero = ((vector float) {0.0f,0.0f,0.0f,0.0f});

  x2y2z2 = vec_madd(in, in, vzero);
  y2z2x2 = vec_perm(x2y2z2, x2y2z2, shuffle);
  z2x2y2 = vec_perm(y2z2x2, y2z2x2, shuffle);
  sum = vec_add(x2y2z2, y2z2x2);
  sum = vec_add(sum, z2x2y2);
  scale = _rsqrtf4(sum);
  return (vec_madd(scale, in, vzero));
#endif

}
#endif /* _NORMALIZE3_H_ */
