/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _CAST_MATRIX_4X4_TO_DBL_H_
#define _CAST_MATRIX_4X4_TO_DBL_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 * 	void _cast_matrix4x4_to_dbl(vector double *mOut, vector float *mIn)
 * 
 * DESCRIPTION
 *	_cast_matrix4x4_to_dbl converts a 4x4 single precision floating-point
 *	matrix into a double precision matrix. The input and output matrix
 *	are pointed to by mIn and mOut respectively and are 128-bit aligned.
 */
#ifdef __SPU__

static __inline void _cast_matrix4x4_to_dbl(vector double *mOut, const vector float *mIn)
{
  vector unsigned char shuffle = (vector unsigned char) {
					     0,1,2,3, 8,9,10,11, 4,5,6,7, 12,13,14,15};
  vector float m0, m1, m2, m3;

  m0 = *(mIn + 0);
  m1 = *(mIn + 1);
  m2 = *(mIn + 2);
  m3 = *(mIn + 3);

  m0 = spu_shuffle(m0, m0, shuffle);
  m1 = spu_shuffle(m1, m1, shuffle);
  m2 = spu_shuffle(m2, m2, shuffle);
  m3 = spu_shuffle(m3, m3, shuffle);

  *(mOut+0) = spu_extend(m0);
  *(mOut+1) = spu_extend(spu_rlqwbyte(m0, 4));
  *(mOut+2) = spu_extend(m1);
  *(mOut+3) = spu_extend(spu_rlqwbyte(m1, 4));
  *(mOut+4) = spu_extend(m2);
  *(mOut+5) = spu_extend(spu_rlqwbyte(m2, 4));
  *(mOut+6) = spu_extend(m3);
  *(mOut+7) = spu_extend(spu_rlqwbyte(m3, 4));
}

#endif /* __SPU__ */
#endif /* _CAST_MATRIX_4X4_TO_DBL_H_ */
