/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2008,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
/*
 * cpex.h - Copy memory to or from local storage area.
 *
 * Copy memory to or from SPU's LS.  Supports arbitrary
 * memory alignments and transfer sizes in a synchronous interface.
 *
 * This is intended primarily as an "ease of use" layer,
 * for those applications that do not wish to interact
 * directly with the MFC, but would rather prefer to use
 * memcpy() style operations.
 *
 * Synchronous interfaces are:
 *    copy_to_ls(to, from, n)
 *    copy_from_ls(to, from, n)
 *
 */

#ifndef _CPEX_H_
#define _CPEX_H_

#include <stddef.h>
#include <spu_mfcio.h>

#define CPEX_ALIGN	128
#define ARE_ALIGNED(_ea, _ls) ((uint32_t)((_ea) & (CPEX_ALIGN-1)) == ((uint32_t)(_ls) & (CPEX_ALIGN-1)))

size_t copy_from_ls_aligned(uint64_t, uint32_t, size_t);
size_t copy_from_ls(uint64_t, uint32_t, size_t);
size_t copy_to_ls_aligned(uint32_t, uint64_t, size_t );
size_t copy_to_ls(uint32_t, uint64_t, size_t );

#endif /* _CPEX_ */
