/* --------------------------------------------------------------  */
/* (C)Copyright 2006,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _RACE_CHECK_H_
#define _RACE_CHECK_H_	1

#include <stdio.h>

/* The following defines control the race checker facilities. The controlable
 * defines include:
 *
 * RACE_CHECK_DEBUG   - if set to non-zero, all race check transactions are 
 *                      emitted. Default is disabled.
 *
 * RACE_CHECK_DB_SIZE - specifies the number to entries in the race check
 *                      database. Default is 20.
 *
 * RACE_CHECK_STREAM  - specifies the default I/O stream race check info is 
 *                      written to.
 *
 * RACE_CHECK_VERBOSE - if set to non-zero, then verbose information is provided
 *                      when an error is detected. Otherwise, minimal information
 *                      is output. This option is provided to reduce the code
 *			size of the race checker for applications with minimal
 *			available local storage.
 */

#define RACE_CHECK_DEBUG	0
#define RACE_CHECK_VERBOSE	1
#define RACE_CHECK_DB_SIZE	20
#define RACE_CHECK_STREAM	stdout


/* This header specifies the set of race check functions and macros for
 * identifying DMA sequencing errors that have possible race conditions.
 */

enum access_types { RACE_CHECK_READ=1, RACE_CHECK_WRITE, RACE_CHECK_READ_WRITE };


#if RACE_CHECK_VERBOSE
#define RACE_CHECK_VERBOSE_PARMS1	, const char *filename, int line
#define RACE_CHECK_VERBOSE_PARMS2	, __FILE__, __LINE__
#else
#define RACE_CHECK_VERBOSE_PARMS1
#define RACE_CHECK_VERBOSE_PARMS2
#endif	/* RACE_CHECK_VERBOSE */


extern void race_check_dma(volatile void *start, unsigned int size, unsigned int cmd, unsigned int tag  RACE_CHECK_VERBOSE_PARMS1);
extern void race_check_dma_list(volatile void *start, volatile void *list, unsigned int size, unsigned int cmd, unsigned int tag  RACE_CHECK_VERBOSE_PARMS1);
extern void race_check_access(void *start, unsigned int size, enum access_types access_type  RACE_CHECK_VERBOSE_PARMS1);
extern void race_check_tag_status(unsigned int tag_status);
extern void race_check_tag_update(unsigned int update);
extern void race_check_barrier(unsigned int tag);
extern void race_check_tag_specific_barrier(unsigned int tag);
extern void race_check_atomic_status();
extern void race_check_list_stall_ack(unsigned int tag);
extern void race_check_list_stall_notify(unsigned int status);




#define RACE_CHECK_ACCESS(_start, _size, _access_type)				\
  race_check_access((void *)_start, _size, _access_type  RACE_CHECK_VERBOSE_PARMS2)


/* Race check error numbers when non-verbose output is used.
 */
enum race_check_errors {
  RACE_CHECK_DATA_BASE_OVERFLOW,	/* Race check database overflowed */
  RACE_CHECK_DMA_ERROR,			/* Two DMA local store target race condition */
  RACE_CHECK_DMA_LIST_ERROR,		/* Race condition involving the list array */
  RACE_CHECK_DMAL_LIST_OVERWRITE,	/* DMA list overwrites its own element list array */
  RACE_CHECK_DMAL_ERROR,		/* Two DMA local store target race condition */
  RACE_CHECK_DMAL_LIST_ERROR,		/* Race condition involving the list array */
  RACE_CHECK_ACCESS_ERROR,		/* An access occurred to a DMA target in flight */
  RACE_CHECK_ACCESS_LIST_ERROR,		/* An access occurred to a DMA list array in flight */
  RACE_CHECK_DMAL_STALLABLE_ERROR	/* Two stallable, unordered DMA lists issued against same tag */
};

#endif /* _RACE_CHECK_H_ */
