/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <spu_intrinsics.h>
#include "mpm_macros.h"

#ifndef _MPM_ADD2_H_
#define _MPM_ADD2_H_	1


/* mpm_add2
 * --------
 * Generic routine that adds two large numbers pointed to by <a> and <b> of 
 * <asize> and <bsize> quadwords respectively. The result is stored in 
 * memory pointed to by <s> and return the size of the result (in quadwords).
 *
 *	<s> = <a> + <b>
 */
static __inline int _mpm_add2(vector unsigned int *s, const vector unsigned int *a, int asize, const vector unsigned int *b, int bsize)
{
  int i, j;
  int minsize, maxsize, delta;
  vector unsigned int *pmin, *pmax;
  vector unsigned int cin, cout;
  vector unsigned int selector;

  /* Identify which of the inputs is larger.
   */
  selector = spu_cmpgt(spu_promote(asize, 0), spu_promote(bsize, 0));
  pmin = MPM_SELECT(a, b, selector, vector unsigned int *);
  pmax = MPM_SELECT(b, a, selector, vector unsigned int *);
  minsize = MPM_SELECT(asize, bsize, selector, int);
  maxsize = MPM_SELECT(bsize, asize, selector, int);

  cin = spu_splats((unsigned int)0);
  delta = maxsize - minsize;
  for (i=minsize-1; i>=0; i--) {
    j = delta + i;
    MPM_ADD_FULL(s[j], cout, pmin[i], pmax[j], cin)
    cin = spu_rlmaskqwbyte(cout, -12);
  }

  /* Propogate the carry out through the remaining quadwords.
   */
  for (i=delta-1; i>=0; i--) {
    MPM_ADD_CARRY_PROPOGATE(s[i], cout, pmax[i], cin);
    cin = spu_rlmaskqwbyte(cout, -12);
  }

  if (spu_extract(cout, 0)) {
    /* The sum overflowed, open space in the return buffer to
     * place the carry out.
     */
    for (i=maxsize; i>=0; i--) s[i+1] = s[i];
    maxsize++;
    s[0] = cin;
  }
  return (maxsize);
}

#endif /* _MPM_ADD2_H_ */
