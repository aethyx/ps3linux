/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef _MPM_GCD_H_
#define _MPM_GCD_H_	1

#include <spu_intrinsics.h>
#include "mpm_defines.h"
#include "mpm_macros.h"
#include "mpm_sub.h"
#include "mpm_cmpge.h"
#include "mpm_cmpgt.h"

/* mpm_gcd
 * -------
 * Routine that computes the greatest common divisor of two large
 * unsigned numbers <a> and <b> of size <asize> and <bsize> quadwords,
 * respectively. The resulting gcd is of <bsize> quadwords.
 *
 * This implementation incorporates 2 algorithms to achieve optimal 
 * performance over a large range inputs. The two algorithms are:
 *
 * Input: two positive integers A and B
 *        A = An An-1 An-2 ... A1 A0  and  
 *        B = Bm Bm-1 Bm-2 ... B1 B0  having n+1 and m+1 words, respectively 
 *        such that An != 0, bm != 0, n > 0, and m > 0.  
 * Output:the greatest common divisor G
 *        G = Gm Gm-1 Gm-2 ... G1 G0  with up to m+1 words such that  g = GCD(a, b)
 *        where  g >= 1.
 *
 *
 * Algorithm 1 	GCD(A,B) = GCD(B, (A mod B))
 * ===========
 * 1.   while B != 0
 *       1.1  r = A mod B
 *       1.2  A = B
 *       1.3  B = r
 *      endwhile
 * 2.   G = A
 * 3.   return G
 *
 * Note: mod is the remainder of A divided by B.
 *
 *
 * Algorithm 2
 * ===========
 *  1.  If B > A then swap A with B.
 *  2.  d = 0
 *  3.  while the least significant bit of both A and B are zero do
 * 	 3.1  shift a to the right by one bit.
 *	 3.2  shift b to the right by one bit.
 *	 3.3  d = d + 1
 *      endwhile
 *  4.  while A != 0 do
 *	 4.1  while the least significant bit of A is zero, shift A to the 
 *            right by one bit.
 *	 4.2  while the least significant bit of B is zero, shift B to the 
 *            right by one bit.
 *	 4.3  if  A >= B  then
 *		4.3.1  A = A - B
 *		4.3.2  shift A to the right by one bit.
 *	        else
 *		4.3.3  B = B - A
 *		4.3.4  shift B to the right by one bit.
 *	        endif
 *      endwhile
 *  5.  if d > 0 then
 *	 shift B to the left by d bits.
 *      endif
 *  6.  G = B
 *  7.  return G
 *
 *
 * This implementation utilizes these algorithms in the following manner.
 *  - When the size of <a> and <b> differ significantly, then perform a single
 *    iteration of algorithm 1 so that the relative size of <a> and <b> are
 *    similar (if not the same).
 *  - Utilize algorithm 2 to produce a final result. The size of the numbers is
 *    constantly refined so that loop iterations are minimized.
 */


static __inline void _mpm_gcd(vector unsigned int *g, const vector unsigned int *a, int asize, const vector unsigned int *b, int bsize)
{
  int i, j;
  int d;
  int delta, idx, min;
  int abits, bbits;
  int acnt,  bcnt;
  int ashift, shift;
  int awords, bwords, qwords;
  int askip,  bskip, gskip;
  int gsize,  size;
  unsigned int tmp, swap, zero;  
  vector unsigned int *ptmp, *pa, *pb, *p;
  vector unsigned int qw, msq;
  vector unsigned int a0, a1, ai, b0, b1, p0, p1, s0, s1;
  vector unsigned int borrow;
  vector unsigned int *src, *dst;
  vector unsigned int aa[MPM_MAX_SIZE+1];
  vector unsigned int bb[MPM_MAX_SIZE+1];
  vector unsigned int qb[MPM_MAX_SIZE];
  vector unsigned int *gg;
  vector unsigned int cmp;
  vector unsigned int align, addend;
  vector unsigned int msb = ((vector unsigned int) { 0x80000000, 0x0, 0x0, 0x0});

  gsize = bsize;

  /* Count leading zeros in <a> and <b>
   */
  MPM_COUNT_LEADING_ZEROS(acnt, a, asize);
  MPM_COUNT_LEADING_ZEROS(bcnt, b, bsize);

  askip = acnt >> 7;
  bskip = bcnt >> 7;

  acnt &= 127;
  bcnt &= 127;

  pa = (vector unsigned int *)(a + askip);
  pb = (vector unsigned int *)(b + bskip);

  asize -= askip;
  bsize -= bskip;

  abits = 128*asize - acnt;
  bbits = 128*bsize - bcnt;
  
  delta = abits-bbits;

  if (abits == bbits) {
    swap = _mpm_cmpge(a, b, asize);
  } else {
    swap = (bbits > abits);
  }

  /* If <b> is larger than <a>, then swap the inputs.
   */
  if (swap) {
    delta = -delta;
    MPM_SWAP(pa, pb, ptmp);
    MPM_SWAP(acnt, bcnt, tmp);
    MPM_SWAP(asize, bsize, tmp);
  }

  gskip = gsize-bsize;
  gg = &g[gskip];
  for (i=0; i<gskip; i++) g[i] = spu_splats((unsigned int)0);
  gsize = bsize;

  if (delta > 32) {
    /* The size of <a> and <b> differ by more than 32 bits,
     * use algorithm 1 for one iteration so that we more 
     * quickly reach a solution.
     */

    /* Create local copies of <a> and <b> such that
     * <b> is left justified (ie, normalized with no 
     * leading 0 bits) and <a> is at least 2 words 
     * and <b> is less then the most significant bsize 
     * words of <a>. The local copies are aa and bb.
     */
    
    /* Copy the input arrays removing leading zeros and normalizing
     * the divisor <b> so that the first (msb) bit of the first word
     * is non-zero.
     */
    bwords = 4*bsize - (bcnt>>5);	/* number of words in normalized divisor */

    src  = (vector unsigned int *)(&b[bskip]);
    MPM_SHL_BITS_LARGE(bb, pb, bsize, bcnt, *pb)

    awords = 4 * asize - (acnt>>5);	/* number of words in normalized dividend */
    if ((acnt & 31) < (bcnt & 31)) awords += 1;
    if (awords < 2) awords = 2;
    askip  = (4*asize-awords)>>2;	/* number of qwords to skip when shifting */

    ashift = 32*(-awords&3) + (bcnt & 31);/* number of bits to shift when normalizing */

    pa += askip;
    asize -= askip;
    a0 = spu_and(*pa, spu_maskw(spu_extract(spu_cmpgt(spu_promote(askip, 0), -1), 0)));
    MPM_SHL_BITS_LARGE(aa, pa, asize, ashift, a0)

    min = (asize > bsize) ? bsize : asize;
    if (!_mpm_cmpgt(bb, aa, min)) {
      /* Insert a 0 word into the front of aa so that the
       * most significant word of aa is less than the most
       * significant word of bb.
       */
      if ((awords & 3) == 0) aa[asize++] = spu_splats((unsigned int)0);
      MPM_SHR_BYTES(aa, aa, asize, spu_splats((unsigned int)0), 4)
      awords += 1;
      ashift = (96 + ashift) & 127;
    }

    qwords = awords - bwords;

    /* Repeatedly compute words of the qoutient.
     */
    b0 = bb[0];
    addend = spu_splats((unsigned int)0);
				   
    for (i=0; i<qwords; i++) {
      /* Compute quotient word.
       */
      idx = i>>2;
      a0 = aa[idx];
      a1 = aa[idx+1];

      /* Move the quadword word being processed into the left (most significant)
       * part of ai.
       */
      align = spu_add(addend, ((vector unsigned int) { 0x0010203, 0x04050607, 0x08090A0B, 0x0C0D0E0F}));
      ai = spu_shuffle(a0, a1, (vector unsigned char)(align));

      if (spu_extract(spu_cmpeq(ai, b0), 0)) {
	qw = spu_splats((unsigned int)-1);
      } else {
	/* We must first estimate the quotient byte dividing the 
	 * most significant 2 words of aa byte the most significant
	 * word of bb.
	 */
	vector unsigned int a0a1;
	a0a1 = spu_and(ai, ((vector unsigned int) { -1, -1, 0, 0}));
	MPM_DIV_ESTIMATE(qw, a0a1, b0)
      }

      /* Correct for over estimated quotient.
       */
      do {
	/* Compute the product of the word estimate (element 0 of qw) 
	 * and the 2 most significant words of b. If the product is 
	 * greater than the most significant 3 words of a, then 
	 * decrement the quotient word and test again.
	 */
	vector unsigned int gt, lt, p;

	MPM_MUL_1_2(p, qw, b0)
	gt = spu_and(spu_gather(spu_cmpgt(p, ai)), 0xE);
	lt = spu_and(spu_gather(spu_cmpgt(ai, p)), 0xE);

	cmp = spu_cmpgt(gt, lt);

	qw = spu_add(qw, cmp);
      } while (spu_extract(cmp, 0));

      /* Compute the product of the quotient word and the divisor
       * and subtract from the dividend (a).
       */
      shift = (3 - (i & 3)) << 2;
      MPM_MUL_N_1(qb, bb, bsize, qw, shift)

      _mpm_sub(&aa[idx], &aa[idx], qb, bsize+1);


      /* If the quotient still was too large, adjust by 1 a final
       * time and correct the remainder (aa).
       */
      if ((signed int)(spu_extract(aa[idx], 0)) < 0) {
	vector unsigned int b0, b1, b, mask, carry;
	
	mask  = spu_slqwbyte(spu_splats((unsigned int)-1), shift);
	b1 = spu_splats((unsigned int)0);
	carry = spu_splats((unsigned int)0);
	for (j=bsize-1; j>=0; j--) {
	  b0 = spu_rlqwbyte(bb[j], shift);
	  b  = spu_sel(b1, b0, mask);
	  MPM_ADD_FULL(aa[idx+j+1], carry, aa[idx+j+1], b, carry)
	  carry = spu_rlmaskqwbyte(carry, -12);
	  b1 = b0;
	}
      
	b1 = spu_andc(b1, mask);
	MPM_ADD_FULL(aa[idx], carry, aa[idx], b1, carry);
      }
      addend = (vector unsigned int)spu_and((vector unsigned char)spu_add((vector unsigned short)(addend), 
									  0x0404), 15);
    }

    /* If whats left in aa is zero, then return the original <b> as the
     * gcd. Otherwise, right shift whats left of aa into bb and copy the 
     * original <b> into aa.
     */
    for (i=1, a0 = aa[0]; i<asize; i++) a0 = spu_or(a0, aa[i]);
    if (spu_extract(spu_gather(spu_cmpeq(a0, 0)), 0) == 15) {
      /* Return the original <b> as the GCD.
       */
      for (i=0; i<gsize; i++) gg[i] = b[i];
      return;
    }

    idx = asize-bsize;
    src = &aa[idx];
    msq = (idx) ? *(src-1) : ((vector unsigned int)spu_splats((unsigned int)0));
    MPM_SHR_BITS_LARGE(bb, src, bsize, msq, ashift)

    for (i=0; i<bsize; i++) aa[i] = pb[i];
    asize = bsize;

  } else {
    /* Copy both input arrays into local array buffers so that
     * both numbers are the same length (asize quadwords). This
     * logic assumes that the input asize and bsize are either the
     * same or asize is one larger than bsize.
     */
    aa[0] = pa[0];
    bb[0] = spu_splats((unsigned int)0);
    delta = asize - bsize;

    for (i=delta; i<asize; i++) {
      aa[i] = pa[i];
      bb[i] = pb[i-delta];
    }
  }

  /* Continue with computation using algorithm 2. From now on, both
   * numbers are of the same size (asize). Array aa is known to be larger
   * than bb.
   */
  size = asize;

  d = 0;
  a0 = aa[size-1];
  b0 = bb[size-1];
  while (spu_extract(spu_and(spu_or(a0, b0), 1), 3) == 0) {
    /* Shift <aa> and <bb> 1 bit to the right.
     */
    a0 = b0 = spu_splats((unsigned int)0);
    for (i=0; i<size; i++) {
      a1 = spu_rlqw(spu_rlqwbyte(aa[i], 15), 7);
      b1 = spu_rlqw(spu_rlqwbyte(bb[i], 15), 7);
      aa[i] = spu_sel(a1, a0, msb);
      bb[i] = spu_sel(b1, b0, msb);
      a0 = a1;
      b0 = b1;
    }
    d++;
  }
  
  a0 = aa[size-1];
  while (spu_extract(spu_and(a0, 1), 3) == 0) {
    a0 = spu_splats((unsigned int)0);
    for (i=0; i<size; i++) {
      a1 = spu_rlqw(spu_rlqwbyte(aa[i], 15), 7);
      aa[i] = spu_sel(a1, a0, msb);
      a0 = a1;
    }
  }

  pa = aa;
  p = pb = bb;

  while (1) {
    /* Right shift least significant zeros out of array pointed
     * to by p. This array is either aa or bb (which every
     * array was last adjusted.
     */
    p0 = p[size-1];
    while (spu_extract(spu_and(p0, 1), 3) == 0) {
      p0 = spu_splats((unsigned int)0);
      for (i=0; i<size; i++) {
	p1 = spu_rlqw(spu_rlqwbyte(p[i], 15), 7);
	p[i] = spu_sel(p1, p0, msb);
	p0 = p1;
      }
    }

    borrow = spu_splats((unsigned int)1);
    if (_mpm_cmpge(pa, pb, size)) {
      /* aa >= bb 
       *
       * Shrink the array sizes if the leading quadword of aa is zero.
       */
      zero = spu_extract(spu_cmpeq(spu_gather(spu_cmpeq(*pa, 0)), 15), 0);
      pa -= zero;
      pb -= zero;
      size += zero;
      
      /* aa = (aa - bb) >> 1
       */
      MPM_SUB_FULL(s0, borrow, pa[size-1], pb[size-1], borrow);
      s0 = spu_rlqw(spu_rlqwbyte(s0, 15), 7);
      for (i=size-2; i>=0; i--) {
	MPM_SUB_FULL(s1, borrow, pa[i], pb[i], borrow);
	s1 = spu_rlqw(spu_rlqwbyte(s1, 15), 7);
	pa[i+1] = spu_sel(s0, s1, msb);
	s0 = s1;
      }
      pa[0] = spu_andc(s0, msb);

      p = pa;

      /* If <aa> is zero, then terminate while loop.
       */
      for (i=1, a0=pa[0]; i<size; i++) a0 = spu_or(a0, pa[i]);
      if (spu_extract(spu_gather(spu_cmpeq(a0, 0)), 0) == 15) break;

    } else {
      /* bb > aa
       *
       * Shrink the array sizes if the leading quadword of bb is zero.
       */
      zero = spu_extract(spu_cmpeq(spu_gather(spu_cmpeq(*pb, 0)), 15), 0);
      pa -= zero;
      pb -= zero;
      size += zero;

      /* bb = (bb - aa) >> 1
       */
      MPM_SUB_FULL(s0, borrow, pb[size-1], pa[size-1], borrow);
      s0 = spu_rlqw(spu_rlqwbyte(s0, 15), 7);
      for (i=size-2; i>=0; i--) {
	MPM_SUB_FULL(s1, borrow, pb[i], pa[i], borrow);
	s1 = spu_rlqw(spu_rlqwbyte(s1, 15), 7);
	pb[i+1] = spu_sel(s0, s1, msb);
	s0 = s1;
      }
      pb[0] = spu_andc(s0, msb);

      p = pb;
    }
  }
  
  /* Copy whats left of <bb> into <g> left shifted by d bits.
   */
  for (i=0; i<gsize; i++) gg[i] = spu_splats((unsigned int)0);

  dst = gg + (gsize - size - (d >> 7));
  d &= 127;

  if (d) {
    if (size < gsize) {
      pb -= 1;
      dst--;
      size++;
      b0 = spu_splats((unsigned int)0);
    } else {
      b0 = *pb;
    }
    MPM_SHL_BITS_LARGE(dst, pb, size, d, b0)
  } else {
    for (i=0; i<size; i++) dst[i] = pb[i];
  }

  return;
}

#endif /* _MPM_GCD_H_ */
