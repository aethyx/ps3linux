/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef _LIB_MPM_H_
#define _LIB_MPM_H_	1

#ifdef __cplusplus
extern "C" {
#endif

extern void mpm_swap_endian(vector unsigned int *a, int size);
extern int mpm_sizeof(const vector unsigned int *a, int size);

extern unsigned int mpm_cmpeq(const vector unsigned int *a, const vector unsigned int *b, int size);
extern unsigned int mpm_cmpeq2(const vector unsigned int *a, int asize, 
			       const vector unsigned int *b, int bsize);
extern unsigned int mpm_cmpgt(const vector unsigned int *a, const vector unsigned int *b, int size);
extern unsigned int mpm_cmpgt2(const vector unsigned int *a, int asize,
			       const vector unsigned int *b, int bsize);
extern unsigned int mpm_cmpge(const vector unsigned int *a, const vector unsigned int *b, int size);
extern unsigned int mpm_cmpge2(const vector unsigned int *a, int asize, 
			       const vector unsigned int *b, int bsize);

extern void mpm_abs(vector unsigned int *a, int size);
extern void mpm_neg(vector unsigned int *n, const vector unsigned int *a, int size);

extern vector unsigned int mpm_add(vector unsigned int *s, 
				   const vector unsigned int *a, 
				   const vector unsigned int *b, int size);
extern int mpm_add2(vector unsigned int *s, 
		    const vector unsigned int *a, int asize,
		    const vector unsigned int *b, int bsize);
extern void mpm_add3(vector unsigned int *s, int ssize,
		     const vector unsigned int *a, int asize,
		     const vector unsigned int *b, int bsize);
extern void mpm_add_partial(vector unsigned int *s, 
			    const vector unsigned int *a, 
			    const vector unsigned int *b, 
			    vector unsigned int *c, int size);
extern vector unsigned int mpm_sub(vector unsigned int *s, 
				   const vector unsigned int *a, 
				   const vector unsigned int *b, int size);
extern void mpm_sub2(vector unsigned int *s, 
		     const vector unsigned int *a, 
		     int asize,
		     const vector unsigned int *b, 
		     int bsize);

extern void mpm_square(vector unsigned int *d, 
		       const vector unsigned int *a, int size);

extern void mpm_mul(vector unsigned int *d, 
		    const vector unsigned int *a, int asize,
		    const vector unsigned int *b, int bsize);
extern void mpm_div(vector unsigned int *q, 
		    vector unsigned int *r, 
		    const vector unsigned int *a, int asize, 
		    const vector unsigned int *b, int bsize);
extern void mpm_div2(vector unsigned int *q, 
		     const vector unsigned int *a, int asize, 
		     const vector unsigned int *b, int bsize);

extern void mpm_madd(vector unsigned int *d, 
		     const vector unsigned int *a, int asize,
		     const vector unsigned int *b, int bsize,
		     const vector unsigned int *c, int csize);

extern void mpm_mod(vector unsigned int *m, 
		    const vector unsigned int *a, int asize, 
		    const vector unsigned int *b, int bsize);

extern void mpm_gcd(vector unsigned int *g, 
		    const vector unsigned int *a, int asize,
		    const vector unsigned int *b, int bsize);


extern int mpm_mul_inv(vector unsigned int *mi, 
		       const vector unsigned int *a,
		       const vector unsigned int *b, int size);

extern int mpm_mul_inv2(vector unsigned int *mi, 
		       const vector unsigned int *a, int asize, 
		       const vector unsigned int *b, int bsize);

extern int mpm_mul_inv3(vector unsigned int *mi, 
		       const vector unsigned int *a, int asize, 
		       const vector unsigned int *b, int bsize);

extern void mpm_fixed_mod_reduction(vector unsigned int *r, const vector unsigned int *a, const vector unsigned int *m, const vector unsigned int *u, int n);

extern void mpm_mod_exp(vector unsigned int *c, const vector unsigned int *b, const vector unsigned int *e, int esize, const vector unsigned int *m, int msize, int k);

extern void mpm_mod_exp2(vector unsigned int *c, const vector unsigned int *b, const vector unsigned int *e, int esize, const vector unsigned int *m, int msize, int k, const vector unsigned int *u);

extern void mpm_mod_exp3(vector unsigned int *c, const vector unsigned int *b, int bsize, const vector unsigned int *e, int esize, const vector unsigned int *m, int msize, const vector unsigned int *u);

extern void mpm_mont_mod_mul(vector unsigned int *c, const vector unsigned int *a, const vector unsigned int *b, const vector unsigned int *m, int size, vector unsigned int p);

extern void mpm_mont_mod_exp(vector unsigned int *c, const vector unsigned int *b, const vector unsigned int *e, int esize, const vector unsigned int *m, int msize, int k);

extern void mpm_mont_mod_exp2(vector unsigned int *c, const vector unsigned int *b, const vector unsigned int *e, int esize, const vector unsigned int *m, int msize, int k, vector unsigned int p, vector unsigned int *a, vector unsigned int *u);

extern void mpm_mont_mod_exp3(vector unsigned int *c, const vector unsigned int *b, int bsize, const vector unsigned int *e, int esize, const vector unsigned int *m, int msize);

#ifdef __cplusplus
}
#endif

#endif /* _LIB_MPM_H_ */
