/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef _SPU_EXT_H_
#define _SPU_EXT_H_

#undef AB
#undef ABI
#undef MPYAH
#undef ROTB
#undef ROTBI
#undef ROTBM
#undef ROTBMI
#undef ROTMAB
#undef ROTMABI
#undef SFB
#undef SFBI
#undef SHLB
#undef SHLBI
#undef DFCEQ
#undef DFCMEQ
#undef DFCGT
#undef DFCMGT
#undef AD
#undef ADI
#undef CDFLTS
#undef CDFLTU
#undef CEQD
#undef CEQDI
#undef CGTD
#undef CGTDI
#undef CLGTD
#undef CLGTDI
#undef CSDFLT
#undef CUDFLT
#undef FSMD
#undef GBD
#undef MPYD
#undef ROTD
#undef ROTDI
#undef ROTDM
#undef ROTDMI
#undef ROTMAD
#undef ROTMADI
#undef SFD
#undef SFDI
#undef SHLD
#undef SHLDI

#include <vec_types.h>

/* The SPU instruction set is not orthogonally complete. That is,
 * not all operations are support for all data types. For example, 
 * there is no byte shifts. 
 *
 * This file includes a set of macros that attempt make the SPU 
 * instruction set more orthogonal.
 * 
 * Summary of supported macros:
 *
 * Byte Macros
 * -----------
 * AB		add byte
 * ABI		add byte immediate
 * MPYAH	multiply bytes and add short
 * ROTB		rotate bytes left
 * ROTBI	rotate bytes left immediate
 * ROTBM	rotate bytes left with mask
 * ROTBMI	rotate bytes left with mask immediate
 * ROTMAB	rotate arthimetic bytes left with mask
 * ROTMABI	rotate arthimetic bytes left with mask immediate
 * SFB		subtract from byte
 * SFBI		subtract from byte immediate
 * SHLB		shift bytes left
 * SHLBI	shift bytes left immediate
 *
 *
 * Double Word Macros
 * ------------------
 * AD		add long long
 * ADI		add long long immediate
 * CDFLTS	convert double floating-point to signed long long
 * CDFLTU	convert double floating-point to unsigned long long
 * CEQD		compare long long equal
 * CEQDI	compare long long equal immediate
 * CGTD		compare long long greater than
 * CGTDI	compare long long greater than immediate
 * CLGTD	compare long long greater than
 * CLGTDI	compare long long greater than immediate
 * CSDFLT	convert signed long long to double floating-point.
 * CUDFLT	convert unsigned long long to double floating-point.
 * FSMD		form select double word mask
 * GBD		gather bits from long long
 * MPYD		multiply integers
 * ROTD		rotate double word left
 * ROTDI	rotate double word left immediate
 * ROTDM	rotate double word left with mask
 * ROTDMI	rotate double word left with mask immediate
 * ROTMAD	rotate arthimetic double word left with mask 
 * ROTMADI	rotate arthimetic double word left with mask immediate
 * SFD		subtract from long long
 * SFDI		subtract from long long immediate
 * SHLD		shift double word left
 * SHLDI	shift double word left immediate
 *
 *
 * Double Floating-Point Macros 
 * ----------------------------
 * DFCEQ	double floating compare equal
 * DFCGT	double floating compare greater 
 * DFCMEQ	double floating compare absolute equal
 * DFCMGT	double floating compare absolute greater
 *
 */


/* Byte Macros
 * =====================================
 */

/* AB - Add Bytes
 *
 * For each of the 16 byte slots:
 *    The operand from _ra is added to the operand from _rb and the 
 *    8-bit result is placed in _rt.  Overflow and carry-outs are not
 *    detected.
 *
 * Inputs:
 *    _ra = vector unsigned char
 *    _rb = vector unsigned char
 * Outputs:
 *    _rt = vector unsigned char
 */

#define AB(_rt, _ra, _rb) {							\
  vec_ushort8 lo, hi;								\
										\
  lo = spu_add((vec_ushort8)(_ra), (vec_ushort8)(_rb));				\
  hi = spu_add((vec_ushort8)(_ra), spu_and((vec_ushort8)(_rb), -256));		\
  _rt = (vec_uchar16)spu_sel(lo, hi, spu_splats((unsigned short)0xFF00));	\
}


/* ABI - Add Bytes Immediate
 *
 * For each of the 16 byte slots:
 *    The operand from _ra is added to the immediate value _i10 and the 
 *    8-bit result is placed in _rt.  Overflow and carry-outs are not
 *    detected.
 *
 * Inputs:
 *    _ra  = vector unsigned char
 *    _i10 = immediate signed 10-bit value
 * Outputs:
 *    _rt = vector unsigned char
 */

#define ABI(_rt, _ra, _i10) {								\
  vec_ushort8 lo, hi;									\
											\
  lo = spu_add((vec_ushort8)(_ra), _i10);						\
  hi = spu_add(spu_rlmask((vec_ushort8)(_ra), -8), _i10);				\
											\
  _rt = (vec_uchar16)spu_shuffle(lo, hi, ((vec_uchar16) {				\
						     17, 1, 19,  3, 21,  5, 23, 7,	\
						     25, 9, 27, 11, 29, 13, 31, 15}));	\
}


/* MPYAH - Multiply and Add Halfword
 *
 * For each of the 8 halfword slots:
 *    The value in _ra is treated as a 8-bit signed integer
 *    and multiplied by the 8-bit value in _rb. The resulting
 *    product is added to the value in _rc and placed in _rt.
 *
 * Inputs:
 *    _ra = vector signed char
 *    _rb = vector signed char
 *    _rc = vector signed short
 * Outputs:
 *    _rt = vector signed short
 */

#define MPYAH(_rt, _ra, _rb, _rc) {							\
  vec_short8 a_lo, a_hi, b_lo, b_hi;							\
  vec_int4  lo, hi;									\
											\
  a_lo = spu_extend(_ra);								\
  b_lo = spu_extend(_rb);								\
  a_hi = spu_extend(spu_rlqwbyte(_ra, 14));						\
  b_hi = spu_extend(spu_rlqwbyte(_rb, 14));						\
  lo = spu_madd(a_lo, b_lo, spu_extend(_rc));						\
  hi = spu_madd(a_hi, b_hi, spu_extend(spu_rlqwbyte(_rc, 14)));				\
											\
  _rt = (vec_short8)spu_shuffle(lo, hi, ((vec_uchar16) { 				\
						    18, 19,  2,  3, 22, 23,  6,  7,	\
						    26, 27, 10, 11, 30, 31, 14, 15}));	\
}


/* ROTB - Rotate Bytes Left
 *
 * For each of the 16 byte slots:
 *    The contents of _ra are rotated left according to the count
 *    in bits 5 to 7 of _rb.. The result is placed in _rt.
 *
 * Inputs:
 *    _ra = vector unsigned char
 *    _rb = vector unsigned char
 * Outputs:
 *    _rt = vector unsigned char
 */

#define ROTB(_rt, _ra, _rb) {											\
  vec_ushort8 r1, r2;												\
														\
  r1 = spu_rl(spu_and((vec_ushort8)(_ra), 0xFF), (vec_short8)spu_and((vec_ushort8)(_rb), 7));			\
  r2 = spu_rl(spu_and((vec_ushort8)(_ra), -256), (vec_short8)spu_and(spu_rlmask((vec_ushort8)(_rb), -8), 7));	\
  _rt = (vec_uchar16)(spu_sel(spu_or(r2, spu_sl(r2, 8)), spu_or(r1, spu_rlmask(r1, -8)), 			\
			      ((vec_ushort8) { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF})));		\
}


/* ROTBI - Rotate Bytes Left Immediate
 *
 * For each of the 16 byte slots:
 *    The contents of _ra are rotated left according to the 3 least 
 *    significant bits of _i7. The result is placed in _rt.
 *
 * Inputs:
 *    _ra = vector unsigned char
 *    _i7 = 7 bit unsigned immediate count
 * Outputs:
 *    _rt = vector unsigned char
 */

#define ROTBI(_rt, _ra, _i7) {									\
  vec_ushort8 r1, r2;										\
												\
  r1 = spu_rl(spu_and((vec_ushort8)(_ra), 0xFF), (_i7 & 7));					\
  r2 = spu_rl(spu_and((vec_ushort8)(_ra), -256), (_i7 & 7));					\
  _rt = (vec_uchar16)(spu_sel(spu_or(r2, spu_sl(r2, 8)), spu_or(r1, spu_rlmask(r1, -8)),	\
			      ((vec_ushort8) { 							\
					  0xFF, 0xFF, 0xFF, 0xFF,				\
					  0xFF, 0xFF, 0xFF, 0xFF})));				\
}

/* ROTBM - Rotate and Mask Bytes Left
 *
 * For each of the 16 byte slots:
 *    The rotate count is bits 5 to 7 of _rb. The contents of _ra are rotated 
 *    according to the  rotate count; the result is masked and placed in _rt. 
 *    Masking consists of logically ANDing the mask with the rotated immediate 
 *    result.
 *
 *    The mask count is bits 4 to 7 of _rb. If a mask count is zero a mask of 
 *    all ones is used. Otherwise uf the mask count is less than 8 a mask of all
 *    zeros is used. Finally if the mask count is greater than 7, a mask is 
 *    formed consisting of rotate count rightmost ones with all zeros to the
 *    left.
 *
 *    Bits rotated out at the left are shifted in at the right.
 *
 * Inputs:
 *    _ra = vector unsigned char
 *    _rb = vector signed char
 * Outputs:
 *    _rt = vector unsigned char
 */

#define ROTBM(_rt, _ra, _rb) {									\
  vec_uchar16 count;										\
  vec_uchar16 pattern = ((vec_uchar16) {							\
				    0, 16,  2, 18,  4, 20,  6, 22,				\
				    8, 24, 10, 26, 12, 28, 14, 30});				\
  vec_ushort8 r1, r2;										\
												\
  /* replicate bit 4 into bit 3 of rotate count (_rb) */					\
  count = (vec_uchar16)spu_sl((vec_ushort8)_rb, 1);						\
  count = spu_sel((vec_uchar16)_rb, count, spu_splats((unsigned char)0x10));			\
												\
  r1 = spu_rlmask((vec_ushort8)(_ra), (vec_short8)spu_rlmask((vec_ushort8)(count), -8));	\
  r2 = spu_rlmask(spu_sl((vec_ushort8)(_ra), 8), (vec_short8)(count));				\
												\
  _rt = (vec_uchar16)spu_shuffle(r1, r2, pattern);						\
}


/* ROTBMI - Rotate and Mask Bytes Left Immediate
 *
 * For each of the 16 byte slots:
 *    The rotate count is the 3 least significant bits of _i7. The contents of _ra
 *    are rotated according to the  rotate count; the result is masked and placed in _rt. 
 *    Masking consists of logically ANDing the mask with the rotated immediate 
 *    result.
 *
 *    The mask count is the 4 least significant bits _i7. If a mask count is zero 
 *    a mask of all ones is used. Otherwise uf the mask count is less than 8 a mask 
 *    of all zeros is used. Finally if the mask count is greater than 7, a mask is 
 *    formed consisting of rotate count rightmost ones with all zeros to the
 *    left.
 *
 *    Bits rotated out at the left are shifted in at the right.
 *
 * Inputs:
 *    _ra = vector unsigned char
 *    _i7 = signed 7-bit immediate value
 * Outputs:
 *    _rt = vector unsigned char
 */

#define ROTBMI(_rt, _ra, _i7) {									\
  vec_uchar16 pattern = ((vec_uchar16) {							\
				    0, 16,  2, 18,  4, 20,  6, 22,				\
				    8, 24, 10, 26, 12, 28, 14, 30});				\
  vec_ushort8 r1, r2;										\
												\
  r1 = spu_rlmask((vec_ushort8)(_ra), ((_i7 << 1) & 0x10) | (_i7 & 0xF));			\
  r2 = spu_rlmask(spu_sl((vec_ushort8)(_ra), 8), ((_i7 << 1) & 0x10) | (_i7 & 0xF));		\
												\
  _rt = (vec_uchar16)spu_shuffle(r1, r2, pattern);						\
}


/* ROTMAB - Rotate and Mask Algebraic Bytes Left
 *
 * For each of the 16 byte slots:
 *    The rotate count is bits 5 to 7 of _rb. The contents of _ra are rotated 
 *    according to the  rotate count; the result is masked and placed in _rt. 
 *    Masking consists of selecting the sign bit of _ra when the mask bit is 0
 *    and selecting the bit from the rotated immediate result when the mask bit
 *    is 1.
 *
 *    The mask count is bits 4 to 7 of _rb. If a mask count is zero a mask of 
 *    all ones is used. Otherwise uf the mask count is less than 8 a mask of all
 *    zeros is used. Finally if the mask count is greater than 7, a mask is 
 *    formed consisting of rotate count rightmost ones with all zeros to the
 *    left.
 *
 *    Bits rotated out at the left are shifted in at the right.
 *
 * Inputs:
 *    _ra = vector signed char
 *    _rb = vector signed char
 * Outputs:
 *    _rt = vector signed char
 */

#define ROTMAB(_rt, _ra, _rb) {									\
  vec_uchar16 count;										\
  vec_uchar16 pattern = ((vec_uchar16) { 							\
				    0, 16,  2, 18,  4, 20,  6, 22,				\
				    8, 24, 10, 26, 12, 28, 14, 30});				\
  vec_short8 r1, r2;										\
												\
  /* replicate bit 4 into bit 3 of rotate count (_rb) */					\
  count = (vec_uchar16)spu_sl((vec_ushort8)_rb, 1);						\
  count = spu_sel((vec_uchar16)_rb, count, spu_splats((unsigned char)0x10));			\
												\
  r1 = spu_rlmaska((vec_short8)(_ra), (vec_short8)spu_rlmask((vec_ushort8)(count), -8));	\
  r2 = spu_rlmaska(spu_sl((vec_short8)(_ra), 8), (vec_short8)(count));				\
												\
  _rt = (vec_char16)spu_shuffle(r1, r2, pattern);						\
}


/* ROTMABI - Rotate and Mask Algebraic Bytes Left Immediate
 *
 * For each of the 16 byte slots:
 *    The rotate count is the 3 least significant bits of _i7. The contents of _ra are 
 *    rotated according to the  rotate count; the result is masked and placed in _rt. 
 *    Masking consists of selecting the sign bit of _ra when the mask bit is 0
 *    and selecting the bit from the rotated immediate result when the mask bit
 *    is 1.
 *
 *    The mask count is the 4 least significant bit of _i7. If a mask count is zero a 
 *    mask of all ones is used. Otherwise uf the mask count is less than 8 a mask of all
 *    zeros is used. Finally if the mask count is greater than 7, a mask is 
 *    formed consisting of rotate count rightmost ones with all zeros to the
 *    left.
 *
 *    Bits rotated out at the left are shifted in at the right.
 *
 * Inputs:
 *    _ra = vector signed char
 *    _i7 = 7-bit immediate
 * Outputs:
 *    _rt = vector signed char
 */

#define ROTMABI(_rt, _ra, _i7) {								\
  vec_uchar16 pattern = ((vec_uchar16) {							\
				    0, 16,  2, 18,  4, 20,  6, 22,				\
				    8, 24, 10, 26, 12, 28, 14, 30});				\
  vec_short8 r1, r2;										\
												\
  r1 = spu_rlmaska((vec_short8)(_ra), ((_i7 << 1) & 0x10) | (_i7 & 0xF));		       	\
  r2 = spu_rlmaska(spu_sl((vec_short8)(_ra), 8), ((_i7 << 1) & 0x10) | (_i7 & 0xF));		\
												\
  _rt = (vec_char16)spu_shuffle(r1, r2, pattern);						\
}


/* SFB - Subtract From Bytes
 *
 * For each of the 16 byte slots:
 *    The operand from _ra is subtracted from _rb and the 8-bit result 
 *    is placed in _rt.  Underflow and borrow-ins are not detected.
 *
 * Inputs:
 *    _ra = vector signed char
 *    _rb = vector signed char
 * Outputs:
 *    _rt = vector signed char
 */

#define SFB(_rt, _ra, _rb) {							\
  vec_ushort8 lo, hi;								\
										\
  lo = spu_sub((vec_ushort8)(_rb), (vec_ushort8)(_ra));				\
  hi = spu_sub((vec_ushort8)(_rb), spu_and((vec_ushort8)(_ra), -256));		\
  _rt = (vec_char16)spu_sel(lo, hi, spu_splats((unsigned short)0xFF00));	\
}

/* SFBI - Subtract From Bytes Immediate
 *
 * For each of the 16 byte slots:
 *    The operand from _ra is subtracted from _I10 and the 8-bit result 
 *    is placed in _rt.  Underflow and borrow-ins are not detected.
 *
 * Inputs:
 *    _ra  = vector signed char
 *    _i10 = immediate signed 10-bit value
 * Outputs:
 *    _rt = vector signed char
 */

#define SFBI(_rt, _ra, _i10) {								\
  vec_ushort8 lo, hi;									\
											\
  lo = spu_sub(_i10, (vec_ushort8)(_ra));						\
  hi = spu_sub(_i10, spu_rlmask((vec_ushort8)(_ra), -8));				\
  _rt = (vec_char16)spu_shuffle(lo, hi, ((vec_uchar16) {				\
						    17, 1, 19,  3, 21,  5, 23, 7,	\
						    25, 9, 27, 11, 29, 13, 31, 15}));	\
}


/* SHLB - Shift Left Bytes
 *
 * For each of the 16 byte slots:
 *    The contents of _ra are shifted left according to the count
 *    in bits 4 to 7 of _rb. Bits shifted out of the left are discarded;
 *    zeros are shifted in at the right.
 *
 * Inputs:
 *    _ra = vector unsigned char
 *    _rb = vector unsigned char
 * Outputs:
 *    _rt = vector unsigned char
 */

#define SHLB(_rt, _ra, _rb) {									\
  vec_ushort8 hi, lo;										\
  vec_uchar16 cnt;										\
												\
  cnt = spu_and(_rb, 0xF);									\
  lo = spu_sl((vec_ushort8)(_ra), (vec_ushort8)(cnt));						\
  hi = spu_sl((vec_ushort8)(spu_rlqwbyte(_ra, 15)), (vec_ushort8)(spu_rlqwbyte(cnt, 15)));	\
												\
  _rt = (vec_uchar16)spu_shuffle(lo, hi, ((vec_uchar16) {					\
						     17, 1, 19,  3, 21,  5, 23, 7,		\
						     25, 9, 27, 11, 29, 13, 31, 15}));		\
}


/* SHLBI - Shift Left Bytes Immediate
 *
 * For each of the 16 byte slots:
 *    The contents of _ra are shifted left according to the 4 least 
 *    significant bits of _I7. Bits shifted out of the left are discarded;
 *    zeros are shifted in at the right.
 *
 * Inputs:
 *    _ra = vector unsigned char
 *    _I7 = 7 bit immediate field
 * Outputs:
 *    _rt = vector unsigned char
 */

#define SHLBI(_rt, _ra, _i7) {									\
  vec_ushort8 hi, lo;										\
												\
  lo = spu_sl((vec_ushort8)(_ra), (_i7 & 0xF));							\
  hi = spu_sl((vec_ushort8)(spu_rlqwbyte(_ra, 15)), (_i7 & 0xF));				\
												\
  _rt = (vec_uchar16)spu_shuffle(lo, hi, ((vec_uchar16) {					\
						     17, 1, 19,  3, 21,  5, 23, 7,		\
						     25, 9, 27, 11, 29, 13, 31, 15}));		\
}


/* Byte Macros
 * =====================================
 */

/* AD - Add Doublewords
 *
 * For each of the 2 double word slots:
 *    The operand from _ra is added to the operand from _rb and the 
 *    64-bit result is placed in _rt.  Overflow and carry-outs are not
 *    detected.
 *
 * Inputs:
 *    _ra = vector unsigned long long 
 *    _rb = vector unsigned long long
 * Outputs:
 *    _rt = vector unsigned long long
 */

#define AD(_rt, _ra, _rb) {								\
  vec_uint4 carry; 									\
											\
  carry = spu_genc((vec_uint4)(_ra), (vec_uint4)(_rb));					\
  carry = spu_shuffle(carry, carry, ((vec_uchar16) {					\
						4, 5, 6, 7, 128, 128, 128, 128,		\
						12, 13, 14, 15, 128, 128, 128, 128}));	\
  _rt   = (vec_ullong2)spu_addx((vec_uint4)(_ra), (vec_uint4)(_rb), carry);		\
}


/* ADI - Add Doublewords Immediate
 *
 * For each of the 2 double word slots:
 *    The operand from _ra is added to the immediate 10-bit value _i10 and 
 *    the 64-bit result is placed in _rt.  Overflow and carry-outs are not
 *    detected.
 *
 * Inputs:
 *    _ra  = vector unsigned long long 
 *    _i10 = 10-bit signed constant
 * Outputs:
 *    _rt = vector unsigned long long
 */

#define ADI(_rt, _ra, _i10) {								\
  vec_ullong2 rb;									\
  vec_uint4 carry;									\
											\
  rb = spu_splats((unsigned long long)_i10);						\
  carry = spu_genc((vec_uint4)(_ra), (vec_uint4)(rb));					\
  carry = spu_shuffle(carry, carry, ((vec_uchar16) { 					\
						4, 5, 6, 7, 128, 128, 128, 128,		\
						12, 13, 14, 15, 128, 128, 128, 128}));	\
  _rt   = (vec_ullong2)spu_addx((vec_uint4)(_ra), (vec_uint4)(rb), carry);		\
}


/* CDFLTS - Convert Double to Signed Doubleword 
 *
 * For each of the 2 double word slots:
 *    The double precision float in _ra is multiplied by 2**_i8. The
 *    product is converted to a signed 64-bit integer. If the 
 *    intermediate result is greater than (2**63-1), it saturates to
 *    2**63-1. If it is less than -2**63, it saturates to -2**63.
 *
 *    The immediate value, _i8, is unbiased and must be in the range 
 *    0-127.
 *
 * Inputs:
 *    _ra  = vector double
 *    _i8 = 8-bit signed immediate scale value
 * Outputs:
 *    _rt = vector signed long long
 */

#define CDFLTS(_rt, _ra, _i8) {								\
  vec_uint4 exp, sign, result, max, borrow;						\
  vec_uint4 man0, man1, man, over;							\
  vec_uint4 zero = spu_splats((unsigned int)0);						\
  int cnt0, cnt1;									\
											\
  vec_uchar16 splat_high = ((vec_uchar16) { 0,1,2,3,0,1,2,3,8,9,10,11,8,9,10,11});	\
											\
  /* Replicate and extract exponent and sign */						\
  exp  = spu_shuffle((vec_uint4)(_ra), (vec_uint4)(_ra), splat_high);			\
  sign = (vec_uint4)spu_rlmaska((vec_int4)(exp), -31);					\
  exp  = spu_rlmask(spu_sl(exp, 1), -21);						\
											\
  /* Adjust exponent scale factor (_i8) and bias */					\
  exp = spu_add(exp, (_i8) - 1023 - 62);						\
											\
  /* Reconstruct the mantissa by inserting the implied 1 and				\
   * aligning it to the signed msb (bit 1).						\
   */											\
  man = spu_or(spu_and((vec_uint4)(_ra), ((vec_uint4) {					\
						     0xFFFFF, 0xFFFFFFFF,		\
						     0xFFFFF, 0xFFFFFFFF})),		\
	       ((vec_uint4) { 0x100000, 0, 0x100000, 0}));				\
  man = spu_rlqw(spu_rlqwbyte(man, 1), 2);						\
											\
  /* Detect overflow */									\
  over = spu_cmpgt((vec_int4)(exp), 0);							\
											\
  /* Rotate the matissa bits to the correct locations */				\
  cnt0 = (int)spu_extract(exp, 0);							\
  cnt1 = (int)spu_extract(exp, 2);							\
											\
  man0 = spu_rlmaskqwbyte(spu_rlmaskqw(man, cnt0), (cnt0+7) >> 3);			\
  man1 = spu_rlmaskqwbyte(spu_rlmaskqw(spu_rlqwbyte(man, 8), cnt1), (cnt1+7) >> 3);	\
											\
  result = spu_shuffle(man0, man1, ((vec_uchar16) { 					\
					       0, 1, 2, 3, 4, 5, 6, 7,			\
					       16,17,18,19,20,21,22,23}));		\
											\
  /* Handle underflow */								\
  result = spu_and(result, spu_cmpgt((vec_int4)(exp), -63));				\
											\
  /* Correct the resulting sign */							\
  borrow = spu_genb(zero, result);							\
  borrow = spu_shuffle(borrow, borrow, ((vec_uchar16) {					\
						   4,5,6,7,     192,192,192,192,	\
						   12,13,14,15, 192,192,192,192}));	\
  result = spu_sel(result, spu_subx(zero, result, borrow), sign);			\
											\
  /* Handle out-of-range results */							\
  max = spu_sel(((vec_uint4) { 0x7FFFFFFF, 0xFFFFFFFF, 0x7FFFFFFF, 0xFFFFFFFF}),	\
		((vec_uint4) { 0x80000000, 0x00000000, 0x80000000, 0x00000000}),	\
                sign);									\
											\
  result = spu_sel(result, max, over);							\
  _rt = (vec_llong2)(result);								\
}


/* CDFLTU - Convert Double to Unsigned Doubleword 
 *
 * For each of the 2 double word slots:
 *    The double precision float in _ra is multiplied by 2**_i8. The
 *    product is converted to a unsigned 64-bit integer. If the 
 *    intermediate result is greater than (2**64-1), it saturates to
 *    2**64-1. If it is less than 0, it saturates to 0.
 *
 *    The immediate value, _i8, is unbiased and must be in the range 
 *    0-127.
 *
 * Inputs:
 *    _ra  = vector double
 *    _i8 = 8-bit signed immediate scale value
 * Outputs:
 *    _rt = vector unsigned long long
 */

#define CDFLTU(_rt, _ra, _i8) {								\
  vec_uint4 exp, sign, result;								\
  vec_uint4 man0, man1, man, over;							\
  int cnt0, cnt1;									\
											\
  vec_uchar16 splat_high = ((vec_uchar16) { 						\
				       0,1,2,3,   0,1,2,3,				\
				       8,9,10,11, 8,9,10,11});				\
											\
  /* Replicate and extract exponent and sign */						\
  exp  = spu_shuffle((vec_uint4)(_ra), (vec_uint4)(_ra), splat_high);			\
  sign = (vec_uint4)spu_rlmaska((vec_int4)(exp), -31);					\
  exp  = spu_rlmask(spu_sl(exp, 1), -21);						\
											\
  /* Adjust exponent scale factor (_i8) and bias */					\
  exp = spu_add(exp, (_i8) - 1023 - 63);						\
											\
  /* Reconstruct the mantissa by inserting the implied 1 and				\
   * aligning it to the signed msb (bit 1).						\
   */											\
  man = spu_or(spu_and((vec_uint4)(_ra), ((vec_uint4) { 0xFFFFF, 0xFFFFFFFF,		\
						     0xFFFFF, 0xFFFFFFFF})),		\
	       ((vec_uint4) { 0x100000, 0, 0x100000, 0}));				\
  man = spu_rlqw(spu_rlqwbyte(man, 1), 3);						\
											\
  /* Detect overflow */									\
  over = spu_cmpgt((vec_int4)(exp), 0);							\
											\
  /* Rotate the matissa bits to the correct locations */				\
  cnt0 = (int)spu_extract(exp, 0);							\
  cnt1 = (int)spu_extract(exp, 2);							\
											\
  man0 = spu_rlmaskqwbyte(spu_rlmaskqw(man, cnt0), (cnt0+7) >> 3);			\
  man1 = spu_rlmaskqwbyte(spu_rlmaskqw(spu_rlqwbyte(man, 8), cnt1), (cnt1+7) >> 3);	\
											\
  result = spu_shuffle(man0, man1, ((vec_uchar16) {					\
					       0, 1, 2, 3, 4, 5, 6, 7,			\
					       16,17,18,19,20,21,22,23}));		\
											\
  /* Handle underflow */								\
  result = spu_and(result, spu_cmpgt((vec_int4)(exp), -64));				\
											\
  /* Handle out-of-range result */							\
  result = spu_andc(spu_or(result, over), sign);					\
  _rt = (vec_ullong2)(result);								\
}


/* CEQD - Doubleword Compare Equal
 *
 * For each of the 2 double word slots:
 *    The value from _ra is compared with the value from _rb. If the values 
 *    are equal, a result of all ones is produced in _rt. Otherwise a 
 *    result of 0 is produced in _rt.
 *
 * Inputs:
 *    _ra = vector unsigned long long
 *    _rb = vector unsigned long long
 * Outputs:
 *    _rt = vector unsigned long long
 */

#define CEQD(_rt, _ra, _rb) {									\
  vec_ullong2 equal;										\
  vec_uchar16 swap = ((vec_uchar16) { 4,5,6,7, 0,1,2,3, 12,13,14,15, 8,9,10,11});		\
												\
  equal = (vec_ullong2)spu_cmpeq((vec_uint4)(_ra), (vec_uint4)(_rb));				\
  _rt   = spu_and(equal, spu_shuffle(equal, equal, swap));					\
}


/* CEQDI - Doubleword Compare Equal Immediate
 *
 * For each of the 2 double word slots:
 *    The value from _ra is compared with the 10-bit signed immediate 
 *    value _i10. If the values are equal, a result of all ones is 
 *    produced in _rt. Otherwise a result of 0 is produced in _rt.
 *
 * Inputs:
 *    _ra  = vector unsigned long long
 *    _i10 = 10-bit signed immediate value
 * Outputs:
 *    _rt = vector unsigned long long
 */

#define CEQDI(_rt, _ra, _i10) {					\
  vec_uint4 eq_hi, eq_lo;					\
  vec_ullong2 equal;						\
  vec_uchar16 splat_high = ((vec_uchar16) {			\
				      0,1,2,3,   0,1,2,3,	\
				      8,9,10,11, 8,9,10,11});	\
								\
  eq_hi = spu_cmpeq((vec_int4)(_ra), (_i10 >> 9));		\
  eq_lo = spu_cmpeq((vec_int4)(_ra), _i10);			\
  equal = (vec_ullong2)spu_and(eq_hi, spu_rlqwbyte(eq_lo, 4)); 	\
  _rt   = spu_shuffle(equal, equal, splat_high);		\
}


/* CGTD - Doubleword Compare Greater Than
 *
 * For each of the 2 double word slots:
 *    The value from _ra is compared with the value from _rb. If _ra is 
 *    greater than _rb, a result of all ones is produced in _rt. Otherwise a 
 *    result of 0 is produced in _rt.
 *
 * Inputs:
 *    _ra = vector signed long long
 *    _rb = vector signed long long
 * Outputs:
 *    _rt = vector unsigned long long
 */

#define CGTD(_rt, _ra, _rb) {					\
  vec_uint4 gt, lgt, eq;					\
  vec_uchar16 splat_high = ((vec_uchar16) {			\
				       0,1,2,3,   0,1,2,3,	\
				       8,9,10,11, 8,9,10,11});	\
								\
  eq  = spu_cmpeq((vec_uint4)(_ra), (vec_uint4)(_rb)); 		\
  gt  = spu_cmpgt((vec_int4)(_ra),  (vec_int4)(_rb));		\
  lgt = spu_cmpgt((vec_uint4)(_ra), (vec_uint4)(_rb));		\
  gt = spu_or(gt, spu_and(eq, spu_rlqwbyte(lgt, 4)));		\
  _rt= (vec_ullong2)(spu_shuffle(gt, gt, splat_high));		\
}


/* CGTDI - Doubleword Compare Greater Than Immediate
 *
 * For each of the 2 double word slots:
 *    The value from _ra is compared with the 10-bit signed 
 *    immediate value _i10. If _ra is greater than _rb, a result 
 *    of all ones is produced in _rt. Otherwise a result of 0 is 
 *    produced in _rt.
 *
 * Inputs:
 *    _ra  = vector signed long long
 *    _i10 = 10-bit signed immediate value
 * Outputs:
 *    _rt = vector unsigned long long
 */

#define CGTDI(_rt, _ra, _i10) {					\
  vec_uint4 gt, lgt, eq;					\
  vec_uchar16 splat_high = ((vec_uchar16) {			\
				       0,1,2,3,   0,1,2,3,	\
				       8,9,10,11, 8,9,10,11});	\
								\
  eq  = spu_cmpeq((vec_uint4)(_ra), (_i10 >> 9));		\
  gt  = spu_cmpgt((vec_int4)(_ra),  (_i10 >> 9));		\
  lgt = spu_cmpgt((vec_uint4)(_ra), _i10);			\
  gt = spu_or(gt, spu_and(eq, spu_rlqwbyte(lgt, 4)));		\
  _rt= (vec_ullong2)(spu_shuffle(gt, gt, splat_high));		\
}


/* CLGTD - Doubleword Logical Compare Greater Than
 *
 * For each of the 2 double word slots:
 *    The value from _ra is compared with the value from _rb. If _ra is 
 *    logically greater than _rb, a result of all ones is produced 
 *    in _rt. Otherwise a result of 0 is produced in _rt.
 *
 * Inputs:
 *    _ra = vector signed long long
 *    _rb = vector signed long long
 * Outputs:
 *    _rt = vector unsigned long long
 */

#define CLGTD(_rt, _ra, _rb) {					\
  vec_uint4 gt, eq;						\
  vec_uchar16 splat_high = ((vec_uchar16) {			\
				       0,1,2,3,   0,1,2,3,	\
				       8,9,10,11, 8,9,10,11});	\
								\
  eq = spu_cmpeq((vec_uint4)(_ra), (vec_uint4)(_rb)); 		\
  gt = spu_cmpgt((vec_uint4)(_ra), (vec_uint4)(_rb));		\
  gt = spu_or(gt, spu_and(eq, spu_rlqwbyte(gt, 4)));		\
  _rt= (vec_ullong2)(spu_shuffle(gt, gt, splat_high));		\
}


/* CLGTDI - Doubleword Logical Compare Greater Than Immediate
 *
 * For each of the 2 double word slots:
 *    The value from _ra is compared with the 10-bit signed 
 *    immediate value _i10. If _ra is logically greater than _rb, a
 *    result of all ones is produced in _rt. Otherwise a result of 0 is 
 *    produced in _rt.
 *
 * Inputs:
 *    _ra  = vector signed long long
 *    _i10 = 10-bit signed immediate value
 * Outputs:
 *    _rt = vector unsigned long long
 */

#define CLGTDI(_rt, _ra, _i10) {				\
  vec_uint4 gt, lgt, eq;					\
  vec_uchar16 splat_high = ((vec_uchar16) {			\
				       0,1,2,3,   0,1,2,3,	\
				       8,9,10,11, 8,9,10,11});	\
								\
  eq  = spu_cmpeq((vec_uint4)(_ra), (unsigned)(_i10 >> 9));	\
  gt  = spu_cmpgt((vec_uint4)(_ra), (unsigned)(_i10 >> 9));	\
  lgt = spu_cmpgt((vec_uint4)(_ra), (unsigned)_i10);		\
  gt = spu_or(gt, spu_and(eq, spu_rlqwbyte(lgt, 4)));		\
  _rt= (vec_ullong2)(spu_shuffle(gt, gt, splat_high));		\
}


/* CSDFLT - Convert Signed Doubleword to Double
 *
 * For each of the 2 double word slots:
 *    The signed 64-bit value in _ra is converted to a double
 *    precision floating-point value. The floating-point result
 *    is divided by the scale factor 2**(_i8) and returned 
 *    in _rt. The immediate value, _i8, is unbiased and must be 
 *    in the range 0-127.
 *
 *    The result is truncated instead of rounded.
 *
 * Inputs:
 *    _ra  = vector signed long long
 *    _i8 = 8-bit signed immediate scale value
 * Outputs:
 *    _rt = vector double
 */

#define CSDFLT(_rt, _ra, _i8) {								\
  unsigned int shift_hi, shift_lo;							\
  vec_uint4 abs_a, sign, zeros, shift, borrow;						\
  vec_uint4 hi, lo, man, exp, result;							\
  vec_uint4 zero = spu_splats((unsigned int)0);						\
  vec_uchar16 shift_borrow = ((vec_uchar16) {						\
					 4,5,6,7, 192,192,192,192,			\
					 12,13,14,15, 192,192,192,192});		\
  vec_uchar16 splat_high = ((vec_uchar16) {						\
				       0,1,2,3,   0,1,2,3,				\
				       8,9,10,11, 8,9,10,11});				\
  /* compute abs(_ra) */								\
  sign = (vec_uint4)spu_rlmaska((vec_int4)(_ra), -31);					\
  sign = spu_shuffle(sign, sign, splat_high);						\
											\
  borrow = spu_genb(zero, (vec_uint4)(_ra));						\
  borrow = spu_shuffle(borrow, borrow, shift_borrow);					\
  abs_a = spu_sel((vec_uint4)(_ra), spu_subx(zero, (vec_uint4)(_ra), borrow), sign);	\
											\
  /* Count the number of leading zeros for normalization */				\
  zeros = spu_cntlz(abs_a);								\
  zeros = spu_sel(zeros, spu_add(zeros, spu_rlqwbyte(zeros, 4)),			\
		  spu_cmpeq(zeros, 32));						\
											\
  /* Normalize the high and low double words to their correct				\
   * double float bit positions.							\
   */											\
  hi = spu_rlmaskqwbyte(abs_a, -8);							\
  lo = spu_rlmaskqwbyte(spu_rlqwbyte(abs_a, 8), -8);					\
											\
  shift = spu_add(zeros, 53);								\
  shift_hi = spu_extract(shift, 0);							\
  shift_lo = spu_extract(shift, 2);							\
											\
  hi = spu_rlqw(spu_rlqwbytebc(hi, shift_hi), shift_hi);				\
  lo = spu_rlqw(spu_rlqwbytebc(lo, shift_lo), shift_lo);				\
  man = spu_or(spu_rlmaskqwbyte(lo, -8), hi);						\
											\
  /* Compute the correct exponents */							\
  exp = spu_sl(spu_add(spu_sub(1023+63, zeros), -(_i8)), 20);				\
											\
  /* Combine the sign, exponent and mantissa */						\
  result = spu_sel(exp, sign, ((vec_uint4) { 0x80000000, 0,0x80000000, 0}));		\
  result = spu_sel(man, result, ((vec_uint4) { 0xFFF00000, 0,0xFFF00000, 0}));		\
											\
  /* Special case handle zero */							\
  result = spu_andc(result, spu_cmpeq(spu_shuffle(zeros, zeros, splat_high), 64));	\
											\
  _rt = (vec_double2)(result);								\
}


/* CUDFLT - Convert Unsigned Doubleword to Double
 *
 * For each of the 2 double word slots:
 *    The unsigned 64-bit value in _ra is converted to a double
 *    precision floating-point value. The floating-point result
 *    is divided by the scale factor 2**(_i8) and returned 
 *    in _rt. The immediate value, _i8, is unbiased and must be 
 *    in the range 0-127.
 *
 *    The result is truncated instead of rounded.
 *
 * Inputs:
 *    _ra  = vector unsigned long long
 *    _i8 = 8-bit signed immediate scale value
 * Outputs:
 *    _rt = vector double
 */

#define CUDFLT(_rt, _ra, _i8) {								\
  unsigned int shift_hi, shift_lo;							\
  vec_uint4 zeros, shift;								\
  vec_uint4 hi, lo, man, exp, result;							\
  vec_uchar16 splat_high = ((vec_uchar16) { 						\
				       0,1,2,3,   0,1,2,3, 				\
				       8,9,10,11, 8,9,10,11});				\
											\
  /* Count the number of leading zeros for normalization */				\
  zeros = spu_cntlz((vec_uint4)(_ra));							\
  zeros = spu_sel(zeros, spu_add(zeros, spu_rlqwbyte(zeros, 4)), 			\
		  spu_cmpeq(zeros, 32));						\
  											\
  /* Normalize the high and low double words to their correct				\
   * double float bit positions.							\
   */											\
  hi = spu_rlmaskqwbyte((vec_uint4)(_ra), -8);						\
  lo = spu_rlmaskqwbyte(spu_rlqwbyte((vec_uint4)(_ra), 8), -8);				\
											\
  shift = spu_add(zeros, 53);								\
  shift_hi = spu_extract(shift, 0);  							\
  shift_lo = spu_extract(shift, 2);							\
											\
  hi = spu_rlqw(spu_rlqwbytebc(hi, shift_hi), shift_hi);				\
  lo = spu_rlqw(spu_rlqwbytebc(lo, shift_lo), shift_lo);				\
  man = spu_or(spu_rlmaskqwbyte(lo, -8), hi);						\
											\
  /* Compute the correct exponents */							\
  exp = spu_sl(spu_add(spu_sub(1023+63, zeros), -(_i8)), 20);				\
											\
  /* Combine the exponent and mantissa */						\
  result = spu_sel(man, exp, ((vec_uint4) { 0xFFF00000, 0, 0xFFF00000, 0}));		\
											\
  /* Special case handle zero */							\
  result = spu_andc(result, spu_cmpeq(spu_shuffle(zeros, zeros, splat_high), 64));	\
											\
  _rt = (vec_double2)(result);								\
}


/* FSMD - Form Select Mask for Doublewords
 *
 * The rightmost 4 bits of the perferred slot of _ra are used to create
 * a mask in _rt by replicating each bit 64 times. Bits in the operand
 * are related to the doubleword in the result, in a left to right 
 * correspondence.
 *
 * Inputs:
 *    _ra = unsigned int
 * Outputs:
 *    _rt = vector unsigned long long
 */

#define FSMD(_rt, _ra) {								\
  vec_int4 _a;										\
											\
  _a = (vec_int4)spu_splats(_ra);							\
  _rt = (vec_ullong2)spu_rlmaska(spu_sl(_a, ((vec_uint4) { 30,30,31,31})), -31);	\
}



/* GBD - Gather Bits Doublewords
 *
 * A 2-bit quantity is formed  in the rightmost 2 bits of the preferred
 * slot of _rt by concatentating the rightmost bit in each doubleword of
 * register _ra. The leftmost 30 bits of register _rt are set to 0, as
 * are the remaining slots of register _rt.
 *
 * Inputs:
 *    _ra = vector unsigned long long 
 * Outputs:
 *    _rt = vector unsigned int
 */

#define GBD(_rt, _ra) {								\
  vec_uchar16 pattern = ((vec_uchar16) {					\
				    128, 128, 128, 128, 128, 128, 128, 128,	\
				    128, 128, 128,   7, 128, 128, 128,  15});	\
  _rt = spu_gather((vec_uint4)spu_shuffle(_ra, _ra, pattern));			\
}


/* MPYD - Multiply Doubleword
 *
 * For each of the 2 doubleword slots:
 *    The value in _ra is treated as a 32-bit signed integer
 *    and multiplied by the 32-bit value in _rb. The resulting
 *    product is added to the value in _rc and placed in _rt.
 *
 * Inputs:
 *    _ra = vector signed int
 *    _rb = vector signed int
 * Outputs:
 *    _rt = vector signed long long
 */
#define MPYD(_rt, _ra, _rb) {									\
  vec_int4 sign_a, sign_b;									\
  vec_uint4 abs_a, abs_b, abs_ah, abs_bh;							\
  vec_uint4 pll, plh, phl, phh;									\
  vec_uint4 borrow;										\
  vec_uint4 zero = spu_splats((unsigned int)0);							\
  vec_uint4 mask = ((vec_uint4) { 0x0, 0xFFFFFFFF, 0x0, 0xFFFFFFFF});				\
  vec_uint4 sign;										\
  vec_ullong2 s0, s1, sum;									\
												\
  /* Compute the absolute value of each of the operands */					\
  sign_a = spu_rlmaska(_ra, -31);								\
  sign_b = spu_rlmaska(_rb, -31);								\
  abs_a  = (vec_uint4)spu_sub(spu_xor(_ra, sign_a), sign_a);					\
  abs_b  = (vec_uint4)spu_sub(spu_xor(_rb, sign_b), sign_b);					\
												\
  abs_ah = (vec_uint4)spu_rlmask(abs_a, -16);							\
  abs_bh = (vec_uint4)spu_rlmask(abs_b, -16);							\
												\
  /* Compute each of the partial product terms and place					\
   * them into their correct slots								\
   */												\
  pll = spu_and(spu_mulo((vec_ushort8)(abs_a), (vec_ushort8)(abs_b)), mask);			\
  plh = spu_slqwbyte(spu_and(spu_mulo((vec_ushort8)(abs_a),					\
				      (vec_ushort8)(abs_bh)), mask), 2);			\
  phl = spu_slqwbyte(spu_and(spu_mulo((vec_ushort8)(abs_ah),					\
				      (vec_ushort8)(abs_b)), mask), 2);				\
  phh = spu_slqwbyte(spu_and(spu_mulo((vec_ushort8)(abs_ah),					\
				      (vec_ushort8)(abs_bh)), mask), 4);			\
												\
  /* Sum the product terms */									\
  AD(s0, pll, plh)										\
  AD(s1, phl, phh)										\
  AD(sum, s0, s1)										\
												\
  /* Adjust the sum of product terms for the correct						\
   * sign.											\
   */												\
  sign = (vec_uint4)spu_xor(sign_a, sign_b);							\
  sign = spu_shuffle(sign, sign, ((vec_uchar16) {						\
					     7, 7, 7, 7, 7, 7, 7, 7,				\
					     15,15,15,15,15,15,15,15}));			\
  borrow = spu_genb(zero, (vec_uint4)(sum));							\
  borrow = spu_shuffle(borrow, borrow, ((vec_uchar16) {						\
						   4,   5,  6,  7, 192, 192, 192, 192,		\
						   12, 13, 14, 15, 192, 192, 192, 192}));	\
  _rt = (vec_llong2)spu_sel((vec_uint4)(sum), spu_subx(zero, (vec_uint4)(sum), borrow), sign);	\
}

/* SFD - Subtract Doublewords
 *
 * For each of the 2 double word slots:
 *    The operand from _ra is subtracted from the operand from _rb and 
 *    the 64-bit result is placed in _rt.  Overflow and carry-outs are not
 *    detected.
 *
 * Inputs:
 *    _ra = vector signed long long 
 *    _rb = vector signed long long
 * Outputs:
 *    _rt = vector signed long long
 */

#define SFD(_rt, _ra, _rb) {								\
  vec_int4 borrow;									\
											\
  borrow = spu_genb((vec_int4)(_rb), (vec_int4)(_ra));					\
  borrow = spu_shuffle(borrow, borrow, ((vec_uchar16) {					\
						   4, 5, 6, 7, 192, 192, 192, 192,	\
						   12, 13, 14, 15, 192, 192, 192, 192}));\
  _rt   = (vec_llong2)spu_subx((vec_uint4)(_rb), (vec_uint4)(_ra), (vec_uint4)(borrow));\
}


/* SFDI - Subtract Doublewords Immediate
 *
 * For each of the 2 double word slots:
 *    The operand from _ra is subtracted to the immediate 10-bit value _i10 
 *    and the 64-bit result is placed in _rt.  Overflow and borrow-outs are not
 *    detected.
 *
 * Inputs:
 *    _ra  = vector signed long long 
 *    _i10 = 10-bit signed constant
 * Outputs:
 *    _rt = vector signed long long
 */

#define SFDI(_rt, _ra, _i10) {								\
  vec_llong2 rb;									\
  vec_int4 borrow;									\
											\
  rb = spu_splats((signed long long)_i10);						\
  borrow = spu_genb((vec_int4)(rb), (vec_int4)(_ra));					\
  borrow = spu_shuffle(borrow, borrow, ((vec_uchar16) {					\
						   4, 5, 6, 7, 192, 192, 192, 192,	\
						   12, 13, 14, 15, 192, 192, 192, 192}));\
  _rt   = (vec_llong2)spu_subx((vec_uint4)(rb), (vec_uint4)(_ra), (vec_uint4)(borrow));	\
}


/* ROTD - Rotate Left Doublewords
 *
 * For each of the 2 double word slots:
 *    The contents of _ra are rotated to the left according to the count
 *    bits 58-63 of _ra. The result is placed in _rt. Bits rotated out
 *    of the left doubleword are rotated in at the right.
 *
 * Inputs:
 *    _ra  = vector unsigned long long 
 *    _rb  = vector unsigned long long
 * Outputs:
 *    _rt = vector unsigned long long
 */

#define ROTD(_rt, _ra, _rb) {							\
  vec_uint4 cnt;								\
  vec_ullong2 mask = ((vec_ullong2) { 0xFFFFFFFFFFFFFFFFULL, 0ULL});		\
  vec_ullong2 a0, a1;								\
  unsigned int cnt0l, cnt0h;							\
  unsigned int cnt1l, cnt1h;							\
										\
  cnt   = spu_and((vec_uint4)(_rb), 0x3F);					\
  cnt0h = spu_extract(cnt, 1);							\
  cnt0l = cnt0h | 64;								\
  cnt1h = spu_extract(cnt, 3);							\
  cnt1l = cnt1h | 64;								\
										\
  a0 = spu_rlqw(spu_and(_ra, mask), cnt0h);					\
  a0 = spu_or(spu_rlqwbytebc(a0, cnt0h), spu_rlqwbytebc(a0, cnt0l));		\
										\
  a1 = spu_rlqw(spu_andc(_ra, mask), cnt1h);					\
  a1 = spu_or(spu_rlqwbytebc(a1, cnt1h), spu_rlqwbytebc(a1, cnt1l));		\
										\
  _rt = spu_sel(a1, a0, mask);							\
}


/* ROTDI - Rotate Left Doublewords immediate
 *
 * For each of the 2 double word slots:
 *    The contents of _ra are rotated to the left according to the 6 
 *    least significant bits of the immediate count _i7. The result is 
 *    placed in _rt. Bits rotated out of the left doubleword are 
 *    rotated in at the right.
 *
 * Inputs:
 *    _ra  = vector unsigned long long 
 *    _i7  = 7-bit immedate
 * Outputs:
 *    _rt = vector unsigned long long
 */

#define ROTDI(_rt, _ra, _i7) {							\
  vec_ullong2 mask = ((vec_ullong2) { 0xFFFFFFFFFFFFFFFFULL, 0ULL});		\
  vec_ullong2 a0, a1;								\
										\
  a0 = spu_rlqw(spu_and(_ra, mask), (_i7 & 0x3F));				\
  a0 = spu_or(spu_rlqwbytebc(a0, (_i7 & 0x3F)),					\
	      spu_rlqwbytebc(a0, (_i7 | 64)));					\
										\
  a1 = spu_rlqw(spu_andc(_ra, mask), (_i7 & 0x3F));				\
  a1 = spu_or(spu_rlqwbytebc(a1, (_i7 & 0x3F)),					\
	      spu_rlqwbytebc(a1, (_i7 | 64)));					\
										\
  _rt = spu_sel(a1, a0, mask);							\
}


/* ROTDM - Rotate Doubleword Left With Mask
 *
 * For each of the 2 double word slots:
 *    The rotate count is bits 58-63 of _rb. The contents of _ra are rotate 
 *    to the left according to the rotate count; the result is masked and 
 *    placed into _rt. Masking consists of logically ANDing the mask with
 *    rotated intermediate result.
 *
 *    The mask count is bits 57-63 of _rb. If the mask count is zero a mask 
 *    of all ones is used. Otherwise, if the mask count is less than 64 a
 *    mask of all zeros is used. Finally, if the mask count is greater than
 *    63, a mask is formed consisting of "rotate count" rightmost ones with 
 *    zeros to the left.
 *
 *    Bits rotate out at the left are shifted in at the right.
 *
 * Inputs:
 *    _ra  = vector unsigned long long 
 *    _rb  = vector signed long long
 * Outputs:
 *    _rt = vector unsigned long long
 */

#define ROTDM(_rt, _ra, _rb) {						\
  vec_uint4 cnt;							\
  vec_ullong2 a0, a1;							\
  signed int cnt0, cnt1;						\
									\
  cnt  = (vec_uint4)spu_rlmaska(spu_sl((vec_int4)(_rb), 25), -25);	\
  cnt0 = spu_extract(cnt, 1);						\
  cnt1 = spu_extract(cnt, 3);						\
  a0 = spu_rlmaskqwbyte(spu_rlmaskqw(_ra, cnt0), (cnt0+7) >> 3);	\
  a1 = spu_rlmaskqwbyte(spu_rlmaskqw(spu_rlqwbyte(_ra, 8), 		\
				     cnt1), (cnt1+7) >> 3);		\
									\
  _rt = spu_shuffle(a0, a1, ((vec_uchar16) {				\
					0, 1, 2, 3, 4, 5, 6, 7,		\
					16,17,18,19,20,21,22,23}));	\
}


/* ROTDMI - Rotate Doubleword Left With Mask Immediate
 *
 * For each of the 2 double word slots:
 *    The rotate count is bits 26-31 of _i7. The contents of _ra are rotate 
 *    to the left according to the rotate count; the result is masked and 
 *    placed into _rt. Masking consists of logically ANDing the mask with
 *    rotated intermediate result.
 *
 *    The mask count is bits 25-63 of _i7. If the mask count is zero a mask 
 *    of all ones is used. Otherwise, if the mask count is less than 64 a
 *    mask of all zeros is used. Finally, if the mask count is greater than
 *    63, a mask is formed consisting of "rotate count" rightmost ones with 
 *    zeros to the left.
 *
 *    Bits rotate out at the left are shifted in at the right.
 *
 * Inputs:
 *    _ra  = vector unsigned long long 
 *    _i7  = signed immediate integer
 * Outputs:
 *    _rt = vector unsigned long long
 */

#define ROTDMI(_rt, _ra, _i7) {						\
  vec_ullong2 a0, a1;							\
									\
  a0 = spu_rlmaskqwbyte(spu_rlmaskqw(_ra, _i7), ((_i7+7) >> 3));	\
  a1 = spu_rlmaskqwbyte(spu_rlmaskqw(spu_rlqwbyte(_ra, 8), _i7), 	\
			((_i7+7) >> 3));				\
									\
  _rt = spu_shuffle(a0, a1, ((vec_uchar16) { 				\
					0, 1, 2, 3, 4, 5, 6, 7,		\
					16,17,18,19,20,21,22,23}));	\
}


/* ROTMAD - Rotate Doubleword Algebraic Left With Mask
 *
 * For each of the 2 double word slots:
 *    The rotate count is bits 58-63 of _rb. The contents of _ra are rotate 
 *    to the left according to the rotate count; the result is masked and 
 *    placed into _rt. Masking consists of selecting the sign bit of _ra
 *    when the mask bit is 0 and selecting the bit from rotated intermediate
 *    result when the mask bit is 1.
 *
 *    The mask count is bits 57-63 of _rb. If the mask count is zero a mask 
 *    of all ones is used. Otherwise, if the mask count is less than 64 a
 *    mask of all zeros is used. Finally, if the mask count is greater than
 *    63, a mask is formed consisting of "rotate count" rightmost ones with 
 *    zeros to the left.
 *
 *    Bits rotate out at the left are shifted in at the right.
 *
 * Inputs:
 *    _ra  = vector signed long long 
 *    _rb  = vector signed long long
 * Outputs:
 *    _rt = vector signed long long
 */

#define ROTMAD(_rt, _ra, _rb) {							\
  vec_uint4 cnt;								\
  signed int cnt0, cnt1;							\
  vec_llong2 a0, a1, sign;							\
  vec_ullong2 mask = ((vec_ullong2) { 0xFFFFFFFFFFFFFFFFULL, 0ULL});		\
										\
  sign = spu_shuffle(_ra, _ra, ((vec_uchar16) { 0,0,0,0,0,0,0,0,		\
					                8,0,0,0,8,0,0,0}));	\
  sign = (vec_llong2)spu_rlmaska((vec_int4)sign, -31);				\
										\
  /* sign extend count */							\
  cnt  = (vec_uint4)spu_rlmaska(spu_sl((vec_int4)(_rb), 25), -25);		\
  /* if (0<cnt<64) cnt = -64; */						\
  cnt  = spu_sel(cnt, spu_splats((unsigned int)0xFFFFFFC0), 			\
		 spu_cmpgt((vec_int4)(cnt), 0));				\
  cnt0 = spu_extract((vec_int4)cnt, 1);						\
  cnt1 = spu_extract((vec_int4)cnt, 3);						\
										\
  a0 = spu_sel(spu_rlqwbyte(_ra,  8), sign, mask);				\
  a1 = spu_sel(_ra, spu_rlqwbyte(sign, 8), mask);				\
										\
  a0 = spu_rlmaskqwbyte(spu_rlmaskqw(a0, cnt0), (cnt0+7) >> 3);			\
  a1 = spu_rlmaskqwbyte(spu_rlmaskqw(a1, cnt1), (cnt1+7) >> 3);			\
										\
  _rt = spu_shuffle(a0, a1, ((vec_uchar16) {					\
					8, 9,10,11,12,13,14,15,			\
					24,25,26,27,28,29,30,31}));		\
}


/* ROTMADI - Rotate Doubleword Algebraic Left Immediate With Mask 
 *
 * For each of the 2 double word slots:
 *    The rotate count is bits 26-31 of _i7. The contents of _ra are rotate 
 *    to the left according to the rotate count; the result is masked and 
 *    placed into _rt. Masking consists of selecting the sign bit of _ra
 *    when the mask bit is 0 and selecting the bit from rotated intermediate
 *    result when the mask bit is 1.
 *
 *    The mask count is bits 25-31 of _i7. If the mask count is zero a mask 
 *    of all ones is used. Otherwise, if the mask count is less than 64 a
 *    mask of all zeros is used. Finally, if the mask count is greater than
 *    63, a mask is formed consisting of "rotate count" rightmost ones with 
 *    zeros to the left.
 *
 *    Bits rotate out at the left are shifted in at the right.
 *
 * Inputs:
 *    _ra  = vector signed long long 
 *    _i7  = immediate signed literal
 * Outputs:
 *    _rt = vector signed long long
 */

#define ROTMADI(_rt, _ra, _i7) {						\
  vec_llong2 a0, a1, sign;							\
  vec_ullong2 mask = ((vec_ullong2) { 0xFFFFFFFFFFFFFFFFULL, 0ULL});		\
										\
  sign = spu_shuffle(_ra, _ra, ((vec_uchar16) { 				\
					   0,0,0,0,0,0,0,0,			\
					   8,0,0,0,8,0,0,0}));			\
  sign = (vec_llong2)spu_rlmaska((vec_int4)sign, -31);				\
										\
  a0 = spu_sel(spu_rlqwbyte(_ra,  8), sign, mask);				\
  a0 = spu_rlmaskqw(a0, ((_i7 > 0) ? -64 : _i7));				\
  a0 = spu_rlmaskqwbyte(a0, ((((_i7 > 0) ? -64 : _i7) + 7) >> 3));		\
  a1 = spu_sel(_ra, spu_rlqwbyte(sign, 8), mask);				\
  a1 = spu_rlmaskqw(a1, ((_i7 > 0) ? -64 : _i7));				\
  a1 = spu_rlmaskqwbyte(a1, ((((_i7 > 0) ? -64 : _i7) + 7) >> 3));		\
										\
  _rt = spu_shuffle(a0, a1, ((vec_uchar16) {					\
					8, 9,10,11,12,13,14,15,			\
					24,25,26,27,28,29,30,31}));		\
}


/* SHLD - Shift Left Doublewords
 *
 * For each of the 2 double word slots:
 *    The operand from _ra is shifted left according to the count in bits
 *    57-63 of _rb. A count is greater then 63, the result is 0.
 *
 * Inputs:
 *    _ra  = vector unsigned long long 
 *    _rb  = vector unsigned long long
 * Outputs:
 *    _rt = vector unsigned long long
 */

#define SHLD(_rt, _ra, _rb) {						\
  vec_uint4 cnt;							\
  vec_ullong2 a0, a1;							\
  unsigned int cnt0, cnt1;						\
									\
  cnt  = spu_and((vec_uint4)(_rb), 0x7F);				\
  cnt0 = spu_extract(cnt, 1);						\
  cnt1 = spu_extract(cnt, 3);						\
  a0 = spu_slqwbytebc(spu_slqw(spu_rlqwbyte(_ra, 8), cnt0), cnt0);	\
  a1 = spu_slqwbytebc(spu_slqw(_ra, cnt1), cnt1);			\
									\
  _rt = spu_shuffle(a0, a1, ((vec_uchar16) {				\
					8, 9,10,11,12,13,14,15,		\
					24,25,26,27,28,29,30,31}));	\
}

/* SHLDI - Shift Left Doublewords Immediate
 *
 * For each of the 2 double word slots:
 *    The operand from _ra is shifted left according to the count in 
 *    the 7 least significant bits of _i7. A count is greater then 63,
 *    the result is 0.
 *
 * Inputs:
 *    _ra  = vector unsigned long long 
 *    _i7  = 7-bit immediate literal
 * Outputs:
 *    _rt = vector unsigned long long
 */

#define SHLDI(_rt, _ra, _i7) {						\
  vec_ullong2 a0, a1;							\
									\
  a0 = spu_slqwbytebc(spu_slqw(spu_rlqwbyte(_ra, 8), _i7), _i7);	\
  a1 = spu_slqwbytebc(spu_slqw(_ra, _i7), _i7);				\
									\
  _rt = spu_shuffle(a0, a1, ((vec_uchar16) {				\
					8, 9,10,11,12,13,14,15,		\
					24,25,26,27,28,29,30,31}));	\
}


/* Double Precision Floating-Point Macros
 * ======================================
 */

/* DFCEQ - Double Floating Compare Equal
 *
 * For each of the 2 double word slots:
 *    The double floating-point value from _ra is compared with
 *    the double floating-point value from _rb. If the values are equal,
 *    a result of all ones is produced in _rt. Otherwise a result of 0
 *    is produced in _rt.
 *
 * According to ANSI/IEEE 754:
 *    a) NaNs should never compare equal
 *    b) Zeros compare equal reguardless of their sign.
 *
 * Three version of the DFCEQ instruction is provided.
 *    1) If DOUBLE_X86 is defined, then DFCEQ behaves like it does on
 *       Intel x86 system. In this mode, neither special conditions (a)
 *       or (b) are supported. 
 *    2) If DOUBLE_ZERO is defined, then DFCEQ supports only the zero
 *	 IEEE special condition (b).
 *    3) Otherwise, both IEEE special conditions are supported.
 *
 *
 * Inputs:
 *    _ra = vector double
 *    _rb = vector double
 * Outputs:
 *    _rt = vector unsigned long long
 */

#ifdef DOUBLE_X86

#define DFCEQ(_rt, _ra, _rb) {								\
  vec_uint4 equal;									\
  vec_uchar16 swap = ((vec_uchar16) { 4,5,6,7, 0,1,2,3, 12,13,14,15, 8,9,10,11});	\
											\
  equal    = spu_cmpeq((vec_uint4)(_ra), (vec_uint4)(_rb));				\
  equal    = spu_and(equal, spu_shuffle(equal, equal, swap));				\
											\
  _rt      = (vec_ullong2)(equal);							\
}

#else 
#ifdef DOUBLE_ZERO

#define DFCEQ(_rt, _ra, _rb) {									\
  vec_uint4 abs_AorB, equal, zequal;								\
  vec_uint4 sign_mask = ((vec_uint4) { 0x7FFFFFFF, 0xFFFFFFFF, 0x7FFFFFFF, 0xFFFFFFFF});	\
  vec_uint4 zero      = spu_splats((unsigned int)0x0);						\
  vec_uchar16 swap    = ((vec_uchar16) { 4,5,6,7, 0,1,2,3, 12,13,14,15, 8,9,10,11});		\
												\
  abs_AorB = spu_and(spu_or((vec_uint4)(_ra), (vec_uint4)(_rb)), sign_mask);			\
  zequal   = spu_cmpeq(abs_AorB, zero);								\
  zequal   = spu_and(zequal, spu_shuffle(zequal, zequal, swap));				\
												\
  equal    = spu_cmpeq((vec_uint4)(_ra), (vec_uint4)(_rb));					\
  equal    = spu_and(equal, spu_shuffle(equal, equal, swap));					\
												\
  _rt      = (vec_ullong2)(spu_or(equal, zequal));						\
}

#else /* DOUBLE_IEEE */

#define DFCEQ(_rt, _ra, _rb) {									\
  vec_uint4 abs_AorB, equal, zequal;								\
  vec_uint4 tmp, nan, exponent, mantissa;							\
  vec_uint4 sign_mask = ((vec_uint4) { 0x7FFFFFFF, 0xFFFFFFFF, 0x7FFFFFFF, 0xFFFFFFFF});	\
  vec_uint4 exp_mask  = ((vec_uint4) { 0x7FF00000, 0x0, 0x7FF00000, 0x0});			\
  vec_uint4 zero      = spu_splats((unsigned int)0x0);						\
  vec_uchar16 swap    = ((vec_uchar16) { 4,5,6,7, 0,1,2,3, 12,13,14,15, 8,9,10,11});		\
												\
  abs_AorB = spu_and(spu_or((vec_uint4)(_ra), (vec_uint4)(_rb)), sign_mask);			\
  zequal   = spu_cmpeq(abs_AorB, zero);								\
  zequal   = spu_and(zequal, spu_shuffle(zequal, zequal, swap));				\
												\
  equal    = spu_cmpeq((vec_uint4)(_ra), (vec_uint4)(_rb));					\
  equal    = spu_and(equal, spu_shuffle(equal, equal, swap));					\
												\
  tmp      = spu_and(abs_AorB, equal);								\
  exponent = spu_cmpeq(spu_and(tmp, exp_mask), exp_mask);					\
  mantissa = spu_cmpeq(spu_andc(tmp, exp_mask), zero);						\
  mantissa = spu_and(mantissa, spu_shuffle(mantissa, mantissa, swap));				\
  nan      = spu_andc(exponent, mantissa);							\
  nan      = spu_and(nan, spu_shuffle(nan, nan, swap));						\
												\
  _rt      = (vec_ullong2)(spu_andc(spu_or(equal, zequal), nan));				\
}
#endif /* DOUBLE_ZERO */
#endif /* DOUBLE_X86  */


/* DFCGT - Double Floating Compare Greater Than
 *
 * For each of the 2 double word slots:
 *    The double floating-point value is from _ra is compared with the 
 *    double floating-point value from _rb. If _ra is greater than _rb,
 *    a result of all ones is produced in _rt. Otherwise a result
 *    of 0 is produced in _rt.
 *
 * According to ANSI/IEEE 754:
 *    a) NaNs should never compare greater than
 *
 * Two version of the DFCGT instruction is provided.
 *    1) If DOUBLE_X86 is defined, then DFCGT behaves like it does on
 *       Intel x86 system. In this mode special condition NaN (a)
 *       is not supported. 
 *    2) Otherwise, IEEE special condition NaN is supported. For this
 *       case, we only need to test for _ra being a NaN because, if
 *	 _rb is a NAN and _ra isn't, then _ra will never compare greater
 *	 than _rb.
 *
 * Inputs:
 *    _ra = vector double
 *    _rb = vector double
 * Outputs:
 *    _rt = vector unsigned long long
 *
 * The basic logic implemented by function is as follows:
 *
 *  GT = A(high) > B(high) | ((A(high) == B(high) & (A(low) > B(low))
 *  result = ~(A == B) & (GT ^ (sign(A) | sign(B));
 *
 *  Note: A == B must test be computed such that -0 equal 0.
 */

#ifdef DOUBLE_X86

#define DFCGT(_rt, _ra, _rb) {								\
  vec_uint4 aorb, equal, sign, zero, gt, eq, result;					\
  vec_uint4 sign_bit = ((vec_uint4) { 0x80000000, 0x0, 0x80000000, 0x0});		\
  vec_uchar16 splat_high = ((vec_uchar16) {						\
				       0,1,2,3,   0,1,2,3,				\
				       8,9,10,11, 8,9,10,11});				\
											\
  aorb  = spu_or((vec_uint4)(_ra), (vec_uint4)(_rb));					\
  gt    = spu_cmpgt((vec_uint4)(_ra), (vec_uint4)(_rb));				\
  equal = spu_cmpeq((vec_uint4)(_ra), (vec_uint4)(_rb));				\
  sign  = spu_rlmaska(aorb, -31);							\
											\
  gt    = spu_or(gt, spu_and(equal, spu_rlqwbyte(gt, 4)));				\
  zero  = spu_andc(aorb, sign_bit);							\
  zero  = spu_cmpeq(spu_or(zero, spu_rlqwbyte(zero, 4)), 0);				\
  eq    = spu_and(equal, spu_rlqwbyte(equal, 4));					\
											\
  result= spu_andc(spu_xor(gt, sign), spu_or(eq, zero));				\
  _rt   = (vec_ullong2)(spu_shuffle(result, result, splat_high));			\
}

#else /* DOUBLE_IEEE */

#define DFCGT(_rt, _ra, _rb) {								\
  vec_uint4 aorb, equal, sign, zero, gt, eq, result;					\
  vec_uint4 abs_a, abs_b, nan, nan_gta, nan_gtb, nan_eqa, nan_eqb;			\
  vec_uint4 infinity = ((vec_uint4) { 0x7FF00000, 0x0, 0x7FF00000, 0x0});		\
  vec_uint4 sign_bit = ((vec_uint4) { 0x80000000, 0x0, 0x80000000, 0x0});		\
  vec_uchar16 splat_high = ((vec_uchar16) {						\
				       0,1,2,3,   0,1,2,3,				\
				       8,9,10,11, 8,9,10,11});				\
											\
  aorb   = spu_or((vec_uint4)(_ra), (vec_uint4)(_rb));					\
  gt     = spu_cmpgt((vec_uint4)(_ra), (vec_uint4)(_rb));				\
  equal  = spu_cmpeq((vec_uint4)(_ra), (vec_uint4)(_rb));				\
  sign   = spu_rlmaska(aorb, -31);							\
											\
  gt     = spu_or(gt, spu_and(equal, spu_rlqwbyte(gt, 4)));				\
  zero   = spu_andc(aorb, sign_bit);							\
  zero   = spu_cmpeq(spu_or(zero, spu_rlqwbyte(zero, 4)), 0);				\
  eq     = spu_and(equal, spu_rlqwbyte(equal, 4));					\
											\
  abs_a  = spu_andc((vec_uint4)(_ra), sign_bit);					\
  abs_b  = spu_andc((vec_uint4)(_rb), sign_bit);					\
  nan_gta= spu_cmpgt(abs_a, infinity);							\
  nan_gtb= spu_cmpgt(abs_b, infinity);							\
  nan_eqa= spu_cmpeq(abs_a, infinity);							\
  nan_eqb= spu_cmpeq(abs_b, infinity);							\
  nan    = spu_or(nan_gta, nan_gtb);							\
  nan    = spu_or(nan, spu_and(nan_eqa, spu_rlqwbyte(nan_gta, 4)));			\
  nan    = spu_or(nan, spu_and(nan_eqb, spu_rlqwbyte(nan_gtb, 4)));			\
											\
  result= spu_andc(spu_andc(spu_xor(gt, sign), spu_or(eq, zero)), nan);			\
  _rt   = (vec_ullong2)(spu_shuffle(result, result, splat_high));			\
}

#endif /* DOUBLE_IEEE */


/* DFCMEQ - Double Floating Compare Absolute Equal
 *
 * For each of the 2 double word slots:
 *    The absolute value of the double floating-point value from _ra is
 *    compared with the absolute value of the the double floating-point 
 *    value from _rb. If the values are equal, a result of all ones is 
 *    produced in _rt. Otherwise a result of 0 is produced in _rt.
 *
 * According to ANSI/IEEE 754:
 *    a) NaNs should never compare equal
 *
 * Three version of the DFCEQ instruction is provided.
 *    1) If DOUBLE_X86 is defined, then DFCMEQ behaves like it does on
 *       Intel x86 system. In this mode, special condition (a) is 
 *	 supported. 
 *    2) Otherwise, both IEEE special conditions are supported.
 *
 *
 * Inputs:
 *    _ra = vector double
 *    _rb = vector double
 * Outputs:
 *    _rt = vector unsigned long long
 */

#ifdef DOUBLE_X86

#define DFCMEQ(_rt, _ra, _rb) {								\
  vec_uint4 abs_a, abs_b, equal;							\
  vec_uint4 sign_bit = ((vec_uint4) { 0x80000000, 0x0, 0x80000000, 0x0});		\
  vec_uchar16 swap = ((vec_uchar16) { 4,5,6,7, 0,1,2,3, 12,13,14,15, 8,9,10,11});	\
											\
  abs_a    = spu_andc((vec_uint4)(_ra), sign_bit);					\
  abs_b    = spu_andc((vec_uint4)(_rb), sign_bit);					\
  equal    = spu_cmpeq(abs_a, abs_b);							\
  equal    = spu_and(equal, spu_shuffle(equal, equal, swap));				\
											\
  _rt      = (vec_ullong2)(equal);							\
}

#else /* DOUBLE_IEEE */

#define DFCMEQ(_rt, _ra, _rb) {								\
  vec_uint4 abs_a, abs_b, equal;							\
  vec_uint4 nan, nan_gt, nan_eq;							\
  vec_uint4 sign_bit = ((vec_uint4) { 0x80000000, 0x0, 0x80000000, 0x0});		\
  vec_uint4 infinity = ((vec_uint4) { 0x7FF00000, 0x0, 0x7FF00000, 0x0});		\
  vec_uchar16 splat_high = ((vec_uchar16) { 						\
				       0,1,2,3,   0,1,2,3,				\
				       8,9,10,11, 8,9,10,11});				\
											\
  abs_a    = spu_andc((vec_uint4)(_ra), sign_bit);					\
  abs_b    = spu_andc((vec_uint4)(_rb), sign_bit);					\
  equal    = spu_cmpeq(abs_a, abs_b);							\
  equal    = spu_and(equal, spu_rlqwbyte(equal, 4));					\
											\
  nan_gt   = spu_cmpgt(abs_a, infinity);						\
  nan_eq   = spu_cmpeq(abs_a, infinity);						\
  nan      = spu_or(nan_gt, spu_and(nan_eq, spu_rlqwbyte(nan_gt, 4)));			\
											\
  equal    = spu_andc(equal, nan);							\
  _rt      = (vec_ullong2)(spu_shuffle(equal, equal, splat_high));			\
}

#endif /* DOUBLE_IEEE */


/* DFCMGT - Double Floating Aboslute Compare Greater Than
 *
 * For each of the 2 double word slots:
 *    The absolute value of the double floating-point value from _ra 
 *    is compared with the absolute value of the double floating-point 
 *    value from _rb. If _ra is greater than _rb, a result of all ones 
 *    is produced in _rt. Otherwise a result of 0 is produced in _rt.
 *
 * According to ANSI/IEEE 754:
 *    a) NaNs should never compare greater than
 *
 * Two version of the DFCMGT instruction is provided.
 *    1) If DOUBLE_X86 is defined, then DFCMGT behaves like it does on
 *       Intel x86 system. In this mode special condition NaN (a)
 *       is not supported. 
 *    2) Otherwise, IEEE special condition NaN is supported. For this
 *       case, we only need to test for _ra being a NaN because, if
 *	 _rb is a NAN and _ra isn't, then _ra will never compare greater
 *	 than _rb.
 *
 *
 * Inputs:
 *    _ra = vector double
 *    _rb = vector double
 * Outputs:
 *    _rt = vector unsigned long long
 *
 * The basic logic implemented by function is as follows:
 *
 *  result = abs(A(high)) > abs(B(high)) ||
 *	     ((abs(A(high)) == abs(B(high))) & (A(low) > B(low))
 */

#ifdef DOUBLE_X86

#define DFCMGT(_rt, _ra, _rb) {								\
  vec_uint4 abs_a, abs_b, gt, eq;							\
  vec_uint4 sign_bit = ((vec_uint4) { 0x80000000, 0x0, 0x80000000, 0x0});		\
  vec_uchar16 splat_high = ((vec_uchar16) { 						\
				       0,1,2,3,   0,1,2,3,				\
				       8,9,10,11, 8,9,10,11});				\
  abs_a  = spu_andc((vec_uint4)(_ra), sign_bit);					\
  abs_b  = spu_andc((vec_uint4)(_rb), sign_bit);					\
  gt     = spu_cmpgt(abs_a, abs_b);							\
  eq     = spu_cmpeq(abs_a, abs_b);							\
  gt     = spu_or(gt, spu_and(eq, spu_rlqwbyte(gt, 4)));				\
											\
  _rt   = (vec_ullong2)(spu_shuffle(gt, gt, splat_high));				\
}

#else /* DOUBLE_IEEE */

#define DFCMGT(_rt, _ra, _rb) {								\
  vec_uint4 abs_a, abs_b, gt, eq, result;						\
  vec_uint4 nan, nan_gta, nan_gtb, nan_eqa, nan_eqb;					\
  vec_uint4 infinity = ((vec_uint4) { 0x7FF00000, 0x0, 0x7FF00000, 0x0});		\
  vec_uint4 sign_bit = ((vec_uint4) { 0x80000000, 0x0, 0x80000000, 0x0});		\
  vec_uchar16 splat_high = ((vec_uchar16) {						\
				       0,1,2,3,   0,1,2,3,				\
				       8,9,10,11, 8,9,10,11});				\
  abs_a  = spu_andc((vec_uint4)(_ra), sign_bit);					\
  abs_b  = spu_andc((vec_uint4)(_rb), sign_bit);					\
  gt     = spu_cmpgt(abs_a, abs_b);							\
  eq     = spu_cmpeq(abs_a, abs_b);							\
  gt     = spu_or(gt, spu_and(eq, spu_rlqwbyte(gt, 4)));				\
											\
  nan_gta= spu_cmpgt(abs_a, infinity);							\
  nan_gtb= spu_cmpgt(abs_b, infinity);							\
  nan_eqa= spu_cmpeq(abs_a, infinity);							\
  nan_eqb= spu_cmpeq(abs_b, infinity);							\
  nan    = spu_or(nan_gta, nan_gtb);							\
  nan    = spu_or(nan, spu_and(nan_eqa, spu_rlqwbyte(nan_gta, 4)));			\
  nan    = spu_or(nan, spu_and(nan_eqb, spu_rlqwbyte(nan_gtb, 4)));			\
											\
  result= spu_andc(gt, nan);								\
  _rt   = (vec_ullong2)(spu_shuffle(result, result, splat_high));			\
}

#endif /* DOUBLE_IEEE */

#endif /* _SPU_EXT_H_ */
