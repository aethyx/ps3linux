/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _MPM_MUL_INV2_H_
#define _MPM_MUL_INV2_H_	1

#include <spu_intrinsics.h>
#include "mpm_defines.h"
#include "mpm_macros.h"
#include "mpm_add2.h"
#include "mpm_cmpgt.h"
#include "mpm_sub.h"
#include "mpm_sub2.h"
#include "mpm_mul.h"


/* mpm_mul_inv
 * -----------
 * Routine that computes the multiplicative inverse of large numbers 
 * <a> and <b> of size <asize> and <bsize> quadwords respectively. The
 * multiplicative inverse is the value <mi> of <asize> quadwords such that
 *
 *	(mi * b) % a = 1
 *
 * If the multiplicative inverse does not exit than 0 is returned. Otherwise,
 * 1 is returns and the large number pointed to by <mi> is filled with the
 * result.
 *
 * This function assumes that a > b > 0.
 *
 * The basic algorithn is:
 *
 * 1. If the lsb of both a and b are 0, then return 0.
 * 2. t = a
 * 3. g = 0
 * 4. s = 1
 * 5. while b != 0 do
 *    5.1  compute q and r as the quotient and remainder of a/b
 *    5.2  a = b
 *    5.3  b = r
 *    5.4  d = g - (q * s)
 *    5.5  g = s
 *    5.6  s = d
 * 6. if a == 1 then
 *    6.1  if g is negative then
 *         6.1.1  mi = g + t
 *         else
 *         6.1.2  mi = g
 *    6.2  return 1
 *    else
 *    6.3  return 0
 */

static __inline int _mpm_mul_inv2(vector unsigned int *mi, const vector unsigned int *a, int asize, const vector unsigned int *b, int bsize)
{
  int i, j;
  int tmp, min, idx, delta;
  int cnt, acnt, bcnt;
  int qsize, qssize;
  int ashift, shift;
  int awords, bwords, qwords;
  int askip,  bskip,  qskip;
  int a1size;
  vector unsigned int amask, bmask;
  vector unsigned int qw, msq;
  vector unsigned int *src;
  vector unsigned int vtmp;
  vector unsigned int align, addend;
  vector unsigned int a_0, a_1, a_i, b_0, b_1;
  vector unsigned int *asrc, *bsrc;
  vector unsigned int *pa1, *pa2, *pb1, *pb2;
  vector unsigned int *ptmp;
  vector unsigned int q[MPM_MAX_SIZE];
  vector unsigned int qb[MPM_MAX_SIZE];
  vector unsigned int qs[MPM_MAX_SIZE+1];
  vector unsigned int a1[MPM_MAX_SIZE+1];
  vector unsigned int a2[MPM_MAX_SIZE+1];
  vector unsigned int b1[MPM_MAX_SIZE+1];
  vector unsigned int b2[MPM_MAX_SIZE+1];
  vector unsigned int g1[MPM_MAX_SIZE+1];
  vector unsigned int g2[MPM_MAX_SIZE+1];
  vector unsigned int g3[MPM_MAX_SIZE+1];
  unsigned int sneg, gneg;
  int gsize, ssize, dsize, tsize;
  vector unsigned int *pt, *pd, *ps, *pg, *pqs;

  pa1 = a1;
  pa2 = a2;
  pb1 = b1;
  pb2 = b2;

  pd = g1;
  ps = g2;
  pg = g3;

  /* 1. If the least significant bits of both a and b are 0, then return 0
   * indicating that the multiplication inverse does not exist.
   */
  if (spu_extract(spu_and(spu_or(a[asize-1], b[bsize-1]), 1), 3) == 0) {
    return 0;
  }

  /* 2. t = a
   */
  pt = (vector unsigned int *)(a);
  tsize = asize;
  
  /* 3. g = 0
   */
  gneg = 0;
  gsize = 1;
  pg[0] = spu_splats((unsigned int)0);

  /* 4. s = 1
   */
  sneg = 0;
  ssize = 1;
  ps[0] = ((vector unsigned int) { 0, 0, 0, 1});

  /* 5. while b != 0 
   */
  asrc = (vector unsigned int *)(a);
  MPM_COUNT_LEADING_ZEROS(acnt, a, asize);

  bsrc = (vector unsigned int *)(b);
  MPM_COUNT_LEADING_ZEROS(bcnt, b, bsize);

  while (bcnt != 128*bsize) {
    delta = 128*(asize - bsize) - (acnt - bcnt);

    bskip  = bcnt >> 7;			/* number of qwords to skip when shifting */
    bsrc += bskip;
    bsize -= bskip;
    bcnt &= 0x7F;

    if (__builtin_expect((delta == 1), 0)) {
      /* Normalize the leading qwords of both a and b. If b is greater than
       * a, then the quotient (a/b) is 1.
       */
      askip = acnt >> 7;
      cnt = acnt & 127;
      a_0 = asrc[askip];

      a_1 = spu_and(asrc[askip+1], spu_maskw(spu_extract(spu_cmpgt(spu_promote(asize, 0),
								   spu_promote(askip, 0)), 0)));

      amask = spu_slqwbytebc(spu_slqw(spu_splats((unsigned int)-1), cnt), cnt);
      
      a_0 = spu_rlqwbytebc(spu_rlqw(a_0, (int)cnt), (int)cnt);
      a_1 = spu_rlqwbytebc(spu_rlqw(a_1, (int)cnt), (int)cnt);
      a_0 = spu_sel(a_1, a_0, amask);

      b_0 = *bsrc;
      b_1 = spu_and(*(bsrc+1), spu_maskw(spu_extract(spu_cmpgt(spu_promote(bsize, 0), 1), 0)));
      
      bmask = spu_slqwbytebc(spu_slqw(spu_splats((unsigned int)-1), bcnt), bcnt);
      
      b_0 = spu_rlqwbytebc(spu_rlqw(b_0, (int)bcnt), (int)bcnt);
      b_1 = spu_rlqwbytebc(spu_rlqw(b_1, (int)bcnt), (int)bcnt);
      b_0 = spu_sel(b_1, b_0, bmask);

      delta = delta & ~(spu_extract(spu_cmpgt(b_0, a_0), 0));
    }

    if (delta) {
      /* a/b is not equal to 1. Perform the full algorithm.
       *
       * 5.1 Compute the quotient and remainder of a (asrc) divided by b (bsrc). 
       * Computation is performed using working arrays pointed to by pa1 and pb1.
       */
      /* Copy the input arrays removing leading zeros and normalizing
       * the divisor <b> so that the first (msb) bit of the first word
       * is non-zero.
       */
      MPM_SHL_BITS_LARGE(pb1, bsrc, bsize, bcnt, bsrc[0])
      
      bwords = 4 * bsize - (bcnt>>5);	/* number of words in normalized divisor */
      awords = 4 * asize - (acnt>>5);	/* number of words in normalized dividend */
      if ((acnt & 31) < (bcnt & 31)) awords += 1;
      if (awords < 2) awords = 2;
      askip  = (4*asize-awords)>>2;	/* number of qwords to skip when shifting */

      ashift = 32*(-awords&3) + (bcnt & 31);	/* number of bits to shift when normalizing */
      asrc += askip;
      a1size = asize - askip;

      a_0 = spu_and(asrc[0], spu_maskw(spu_extract(spu_cmpgt(spu_promote(askip, 0), -1), 0)));
      MPM_SHL_BITS_LARGE(pa1, asrc, a1size, ashift, a_0)

      min = (a1size > bsize) ? bsize : a1size;
      if (!_mpm_cmpgt(pb1, pa1, min)) {
	/* Insert a 0 word into the front of pa1 so that the
	 * most significant word of pa1 is less than the most
	 * significant word of pb1.
	 */
	if ((awords & 3) == 0) pa1[a1size++] = spu_splats((unsigned int)0);
	MPM_SHR_BYTES(pa1, pa1, a1size, spu_splats((unsigned int)0), 4)
	awords += 1;
	ashift = (96 + ashift) & 127;
      }

      /* Zero out the leading words of q that we won't be computing.
       */
      qwords = awords - bwords;
      q[0] = spu_splats((unsigned int)0);
      qskip = (-qwords) & 3;
      qsize = (qwords + 3) >> 2;

      /* Repeatedly compute words of the qoutient.
       */
      b_0 = pb1[0];
      addend = spu_splats((unsigned int)0);
				   
      for (i=0; i<qwords; i++) {
	/* Compute quotient word.
	 */
	idx = i>>2;
	a_0 = pa1[idx];
	a_1 = pa1[idx+1];
	
	/* Move the quadword word being processed into the left (most significant)
	 * part of a_i.
	 */
	align = spu_add(addend, ((vector unsigned int) { 0x0010203, 0x04050607, 0x08090A0B, 0x0C0D0E0F}));
	a_i = spu_shuffle(a_0, a_1, (vector unsigned char)(align));
      
	if (spu_extract(spu_cmpeq(a_i, b_0), 0)) {
	  qw = spu_splats((unsigned int)-1);
	} else {
	  /* We must first estimate the quotient byte dividing the 
	   * most significant 2 words of pa1 byte the most significant
	   * word of pb1.
	   */
	  vector unsigned int a_0_a_1;
	  a_0_a_1 = spu_and(a_i, ((vector unsigned int) { -1, -1, 0, 0}));
	  MPM_DIV_ESTIMATE(qw, a_0_a_1, b_0)
	}

	/* Compute the product of the quotient word and the divisor
	 * and subtract from the dividend (a).
	 */
	shift = (3 - (i & 3)) << 2;
	MPM_MUL_N_1(qb, pb1, bsize, qw, shift)
	_mpm_sub(&pa1[idx], &pa1[idx], qb, bsize+1);
      
	/* If the quotient still was too large, repeatedly adjust by 
	 * 1 until the remainder is positive.
	 */
	while ((signed int)(spu_extract(pa1[idx], 0)) < 0) {
	  vector unsigned int b_0, b_1, b, mask, carry;
	  
	  qw = spu_add(qw, -1);
	  mask  = spu_slqwbyte(spu_splats((unsigned int)-1), shift);
	  b_1 = spu_splats((unsigned int)0);
	  carry = spu_splats((unsigned int)0);
	  for (j=bsize-1; j>=0; j--) {
	    b_0 = spu_rlqwbyte(pb1[j], shift);
	    b  = spu_sel(b_1, b_0, mask);
	    MPM_ADD_FULL(pa1[idx+j+1], carry, pa1[idx+j+1], b, carry)
	    carry = spu_rlmaskqwbyte(carry, -12);
	    b_1 = b_0;
	  }
	  
	  b_1 = spu_andc(b_1, mask);
	  MPM_ADD_FULL(pa1[idx], carry, pa1[idx], b_1, carry);
	}

	q[(qskip+i)>>2] = spu_insert(spu_extract(qw, 0), q[(qskip+i)>>2], qskip+i);

	addend = (vector unsigned int)spu_and((vector unsigned char)spu_add((vector unsigned short)(addend), 
									    0x0404), 15);
      }

      /* Realign (right shift) pa1 back. Result is the remainder of pa1 divided 
       * by pb1 and is of bsize.
       */
      idx = a1size - bsize;
      if (idx < 0) idx = 0;
      src = &pa1[idx];
      msq = spu_andc(pa1[idx-1], spu_maskw(spu_extract(spu_cmpeq(spu_promote(idx, 0), 0), 0)));

      MPM_SHR_BITS_LARGE(pa1, src, bsize, msq, ashift)
	
      /* 5.2 a = b
       * 5.3 b = r
       */
      asrc = bsrc;
      asize = bsize;
      acnt = bcnt;

      /* 5.4 d = g - (q * s)
       */
      if ((qsize & spu_extract(spu_cmpgt(spu_gather(spu_cmpeq((vector unsigned short)(q[0]), 0)), 253), 0)) == 1) {
	/* Perform halfword multiply. Ie, multi-precision number (s) times a halfword (q).
	 */
	MPM_MUL_N_1H(qs, ps, ssize, q[0])
      } else {
	/* Perform full quadword multiply.
	 */
	_mpm_mul(qs, q, qsize, ps, ssize);
      }

      qssize = qsize + ssize;

      pqs = qs;

      delta = spu_extract(spu_cmpeq(spu_gather(spu_cmpeq(qs[0], 0)), 15), 0);
      qssize += delta;
      pqs -= delta;
    } else {
      /* Special case: q == 1.
       *
       * 5.2 a = b
       * 5.3 b = a - b
       */
      if (pa1 != asrc) {
	for (i=0; i<asize; i++)  pa1[i] = asrc[i];
      }

      _mpm_sub2(pa1, pa1, asize, bsrc, bsize);

      asrc = bsrc;
      acnt = bcnt;

      MPM_SWAP(asize, bsize, tmp)


      /* 5.4 d = g - s
       */
      qssize = ssize;
      pqs = ps;
    }

    /* Compute d equal to g + q*s, invert sign
     */
    dsize = _mpm_add2(pd, pg, gsize, pqs, qssize);

    /* 5.5 g = s
     */
    ptmp = pg;
    pg = ps; gsize = ssize; gneg = sneg;

    /* 5.6 s = d
     */
    ps = pd; ssize = dsize; sneg = ~sneg;
    pd = ptmp;

    /* Setup for the next loop iteration.
     */
    bsrc = pa1;

    MPM_SWAP(pa1, pa2, ptmp);
    MPM_SWAP(pb1, pb2, ptmp);

    MPM_COUNT_LEADING_ZEROS(bcnt, bsrc, bsize);
  }

  /* 6. If a != 1 then
   * 6.3               return 0.
   */
  vtmp = spu_xor(asrc[asize-1], ((vector unsigned int) { 0, 0, 0, 1}));
  for (i=asize-2; i>0; i--) vtmp = spu_or(vtmp, asrc[i]);
  if (spu_extract(spu_gather(spu_cmpeq(vtmp, 0)), 0) != 0xF) return 0;

  /* 6.1 if g is negative then
   * 6.1.1	                mi = g + t
   *                      else 
   *                            mi = g
   */
  if (gneg) {
    _mpm_sub2(mi, pt, tsize, pg, gsize);
  } else {
    /* Copy g into mi.
     */
    delta = tsize-gsize;
    i = 0;
    if (delta > 0) {
      for (; i<delta; i++) mi[i] = spu_splats((unsigned int)0);
    } else {
      pg -= delta;
    }
    for (pg -=i; i<tsize; i++) mi[i] = pg[i];
  }

  return (1);
}


#endif /* _MPM_MUL_INV2_H_ */
