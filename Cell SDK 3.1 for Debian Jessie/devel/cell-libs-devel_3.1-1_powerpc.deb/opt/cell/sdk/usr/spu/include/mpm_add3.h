/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#include <spu_intrinsics.h>
#include "mpm_macros.h"

#ifndef _MPM_ADD3_H_
#define _MPM_ADD3_H_	1

/* mpm_add3
 * --------
 * Generic routine that adds two large numbers pointed to by <a> and <b> of 
 * <asize> and <bsize> quadwords respectively. The result is stored in 
 * memory pointed to by <s> of <ssize> quadwords.
 *
 *	<s> = <a> + <b>
 */
static __inline void _mpm_add3(vector unsigned int *s, int ssize, const vector unsigned int *a, int asize, const vector unsigned int *b, int bsize)
{
  int i;
  int min, max, abmax;
  vector unsigned int *pmax;
  vector unsigned int cin, cout;
  vector unsigned int selector;

  selector = spu_cmpgt(spu_promote(asize, 0), spu_promote(bsize, 0));
  pmax  = MPM_SELECT(b, a, selector, vector unsigned int *);
  abmax = MPM_SELECT(bsize, asize, selector, int);
  min   = MPM_SELECT(asize, bsize, selector, int);

  min   = MPM_SELECT(min, ssize, spu_cmpgt(spu_promote(min, 0), spu_promote(ssize, 0)), int);
  max   = MPM_SELECT(abmax, ssize, spu_cmpgt(spu_promote(abmax, 0), spu_promote(ssize, 0)), int);

  cin = spu_splats((unsigned int)0);
  for (i=1; i<=min; i++) {
    MPM_ADD_FULL(s[ssize-i], cout, a[asize-i], b[bsize-i], cin);
    cin = spu_rlmaskqwbyte(cout, -12);
  } 

  for (;i<=max; i++) {
    MPM_ADD_CARRY_PROPOGATE(s[ssize-i], cout, pmax[abmax-i], cin);
    cin = spu_rlqwbyte(cout, 4);
  }

  /* Propogate and Zero fill any remaining s quadwords.
   */
  for (i=ssize-i; i>=0; i--) {
    s[i] = cin;
    cin = spu_splats((unsigned int)0);
  }
}

#endif /* _MPM_ADD3_H_ */
