/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef _FFT_2D_H_
#define _FFT_2D_H_

#ifdef __SPU__
#include <spu_intrinsics.h>

#define gen_sub spu_sub
#define gen_add spu_add
#define gen_madd spu_madd
#define gen_nmsub spu_nmsub
#define gen_mul(a, b) spu_mul(a, b)
#define gen_and spu_and
#define gen_splats(a, b) a = spu_splats(b)
#else /* not __SPU__ */
#include <altivec.h>
#define gen_sub vec_sub
#define gen_add vec_add
#define gen_madd vec_madd
#define gen_nmsub vec_nmsub
#define gen_mul(a, b) vec_madd(a, b, fzero)
#define gen_and vec_and
#define gen_splats(a, b) {         \
   union {                         \
      vector float vi;             \
      float va[4];                 \
   } u;                            \
   u.va[0] = b;                    \
   a = vec_splat(u.vi, 0);         \
}
#endif

#include <math.h>
#include <transpose_matrix4x4.h>

vector float swizbufR[4], swizbufI[4];

static int ar[11][1024], br[11][1024];
static int nl2, _n, n, vn, vn2, vn3, p[2048];
static float cr[1024], sr[1024];
static vector float fninv;

static __inline void _init_fft_2d(int nl2init) 
{
   int i, nr1;
   float fracpi;

   nl2 = nl2init;
   _n = 1 << nl2;
   vn = _n >> 2;
   nr1 = _n >> 1;
   for (i=0; i<_n; ++i) {
      int j, w;
      w = i; 
      p[i] = (w&1);
      for (j=0; j<nl2-1; ++j) {
         p[i] <<=1;
         w >>= 1;
         p[i] |= (w&1);
      }
   }
   vn2 = vn + vn;
   for (i=0; i<nl2; ++i) {
      int j, k, index, offset;
      index = 0;
      offset = 1 << i;
      for (j=0; j<offset; ++j) for (k=j; k<_n; k+=2*offset) {
         ar[i][index] = k;
         br[i][index] = k + offset;
         ++index;
      }
   }
   vn3 = vn2 + vn;
   fracpi = M_PI/((float) nr1);
   for (i=0; i<nr1; ++i) {
      cr[i] = cosf(i*fracpi);
      sr[i] = sinf(i*fracpi);
   }
   gen_splats(fninv, 1.0f / (float) _n);
}

static __inline void _fft_2d(vector float *INr, vector float *INi, vector float *rv, vector float *iv, int fwd_flag) 
{

   int i;
   int count, *arptr, *brptr;
   vector float c1, c2, c3, c4, c5, c6, c7, c8;
   vector float s1, s2, s3, s4, s5, s6, s7, s8;
   vector float tr1, tr2, tr3, tr4, tr5, tr6, tr7, tr8;
   vector float ti1, ti2, ti3, ti4, ti5, ti6, ti7, ti8;
#ifdef __SPU__
   vector float fneg_one = spu_splats((float) -1.0f);
   vector float fzero    = spu_splats((float)  0.0f);
#else
   vector float fneg_one = ((vector float) {-1.0f,-1.0f,-1.0f,-1.0f});
   vector float fzero    = ((vector float)  {0.0f, 0.0f, 0.0f, 0.0f});
#endif

   n = _n;

   for (i=0; i<vn; ++i) {
      int i4, iv1, iv2, iv3;
      int p0, p1, p2, p3;
      iv1 = i + vn;
      iv2 = i + vn2;
      iv3 = i + vn3;
      i4 = i<<2;

      swizbufR[0] = INr[i  ];
      swizbufR[1] = INr[iv1];
      swizbufR[2] = INr[iv2];
      swizbufR[3] = INr[iv3];
      p0 = p[i4];
      p1 = p[i4+1];
      p2 = p[i4+2];
      p3 = p[i4+3];
      swizbufI[0] = INi[i  ];
      swizbufI[1] = INi[iv1];
      swizbufI[2] = INi[iv2];
      swizbufI[3] = INi[iv3];

      _transpose_matrix4x4(swizbufR, swizbufR);
      _transpose_matrix4x4(swizbufI, swizbufI);

      rv[p0] = swizbufR[0];
      rv[p1] = swizbufR[1];
      rv[p2] = swizbufR[2];
      rv[p3] = swizbufR[3];
      iv[p0] = swizbufI[0];
      iv[p1] = swizbufI[1];
      iv[p2] = swizbufI[2];
      iv[p3] = swizbufI[3];
   }

   if (fwd_flag) for (i=0; i<n; i+=8) {
      iv[i  ] = gen_mul(iv[i  ], fneg_one);
      iv[i+1] = gen_mul(iv[i+1], fneg_one);
      iv[i+2] = gen_mul(iv[i+2], fneg_one);
      iv[i+3] = gen_mul(iv[i+3], fneg_one);
      iv[i+4] = gen_mul(iv[i+4], fneg_one);
      iv[i+5] = gen_mul(iv[i+5], fneg_one);
      iv[i+6] = gen_mul(iv[i+6], fneg_one);
      iv[i+7] = gen_mul(iv[i+7], fneg_one);
   }

   for (i=0; i<nl2; ++i) {
      int mask;
      int a0, a1, a2, a3, a4, a5, a6, a7;
      int b0, b1, b2, b3, b4, b5, b6, b7;
      mask = -(1<<((nl2-1)-i));
      arptr = ar[i];
      brptr = br[i];
      for (count = 0; count < (n>>1); count+=8) {
         vector float ar1, br1, ai1, bi1;
         vector float ar2, br2, ai2, bi2;
         vector float ar3, br3, ai3, bi3;
         vector float ar4, br4, ai4, bi4;
         vector float ar5, br5, ai5, bi5;
         vector float ar6, br6, ai6, bi6;
         vector float ar7, br7, ai7, bi7;
         vector float ar8, br8, ai8, bi8;
         gen_splats(c1, cr[(count  )&mask]);
         gen_splats(c2, cr[(count+1)&mask]);
         gen_splats(c3, cr[(count+2)&mask]);
         gen_splats(c4, cr[(count+3)&mask]);
         gen_splats(c5, cr[(count+4)&mask]);
         gen_splats(c6, cr[(count+5)&mask]);
         gen_splats(c7, cr[(count+6)&mask]);
         gen_splats(c8, cr[(count+7)&mask]);
         a0 = arptr[0];
         a1 = arptr[1];
         a2 = arptr[2];
         a3 = arptr[3];
         a4 = arptr[4];
         a5 = arptr[5];
         a6 = arptr[6];
         a7 = arptr[7];
         b0 = brptr[0];
         b1 = brptr[1];
         b2 = brptr[2];
         b3 = brptr[3];
         b4 = brptr[4];
         b5 = brptr[5];
         b6 = brptr[6];
         b7 = brptr[7];
         gen_splats(s1, sr[(count  )&mask]);
         gen_splats(s2, sr[(count+1)&mask]);
         gen_splats(s3, sr[(count+2)&mask]);
         gen_splats(s4, sr[(count+3)&mask]);
         gen_splats(s5, sr[(count+4)&mask]);
         gen_splats(s6, sr[(count+5)&mask]);
         gen_splats(s7, sr[(count+6)&mask]);
         gen_splats(s8, sr[(count+7)&mask]);
         ar1 = rv[a0];
         ar2 = rv[a1];
         ar3 = rv[a2];
         ar4 = rv[a3];
         ar5 = rv[a4];
         ar6 = rv[a5];
         ar7 = rv[a6];
         ar8 = rv[a7];
         br1 = rv[b0];
         br2 = rv[b1];
         br3 = rv[b2];
         br4 = rv[b3];
         br5 = rv[b4];
         br6 = rv[b5];
         br7 = rv[b6];
         br8 = rv[b7];
         ai1 = iv[a0];
         ai2 = iv[a1];
         ai3 = iv[a2];
         ai4 = iv[a3];
         ai5 = iv[a4];
         ai6 = iv[a5];
         ai7 = iv[a6];
         ai8 = iv[a7];
         bi1 = iv[b0];
         bi2 = iv[b1];
         bi3 = iv[b2];
         bi4 = iv[b3];
         bi5 = iv[b4];
         bi6 = iv[b5];
         bi7 = iv[b6];
         bi8 = iv[b7];

         tr1 = gen_mul(br1, c1);
         tr2 = gen_mul(br2, c2);
         tr3 = gen_mul(br3, c3);
         tr4 = gen_mul(br4, c4);
         tr5 = gen_mul(br5, c5);
         tr6 = gen_mul(br6, c6);
         tr7 = gen_mul(br7, c7);
         tr8 = gen_mul(br8, c8);

         ti1 = gen_mul(br1, s1);
         ti2 = gen_mul(br2, s2);
         ti3 = gen_mul(br3, s3);
         ti4 = gen_mul(br4, s4);
         ti5 = gen_mul(br5, s5);
         ti6 = gen_mul(br6, s6);
         ti7 = gen_mul(br7, s7);
         ti8 = gen_mul(br8, s8);

         tr1 = gen_nmsub(bi1, s1, tr1);
         tr2 = gen_nmsub(bi2, s2, tr2);
         tr3 = gen_nmsub(bi3, s3, tr3);
         tr4 = gen_nmsub(bi4, s4, tr4);
         tr5 = gen_nmsub(bi5, s5, tr5);
         tr6 = gen_nmsub(bi6, s6, tr6);
         tr7 = gen_nmsub(bi7, s7, tr7);
         tr8 = gen_nmsub(bi8, s8, tr8);

         ti1 =  gen_madd(bi1, c1, ti1);
         ti2 =  gen_madd(bi2, c2, ti2);
         ti3 =  gen_madd(bi3, c3, ti3);
         ti4 =  gen_madd(bi4, c4, ti4);
         ti5 =  gen_madd(bi5, c5, ti5);
         ti6 =  gen_madd(bi6, c6, ti6);
         ti7 =  gen_madd(bi7, c7, ti7);
         ti8 =  gen_madd(bi8, c8, ti8);

         br1 = gen_sub(ar1, tr1);
         br2 = gen_sub(ar2, tr2);
         br3 = gen_sub(ar3, tr3);
         br4 = gen_sub(ar4, tr4);
         br5 = gen_sub(ar5, tr5);
         br6 = gen_sub(ar6, tr6);
         br7 = gen_sub(ar7, tr7);
         br8 = gen_sub(ar8, tr8);

         bi1 = gen_sub(ai1, ti1);
         bi2 = gen_sub(ai2, ti2);
         bi3 = gen_sub(ai3, ti3);
         bi4 = gen_sub(ai4, ti4);
         bi5 = gen_sub(ai5, ti5);
         bi6 = gen_sub(ai6, ti6);
         bi7 = gen_sub(ai7, ti7);
         bi8 = gen_sub(ai8, ti8);

         ar1 = gen_add(ar1, tr1);
         ar2 = gen_add(ar2, tr2);
         ar3 = gen_add(ar3, tr3);
         ar4 = gen_add(ar4, tr4);
         ar5 = gen_add(ar5, tr5);
         ar6 = gen_add(ar6, tr6);
         ar7 = gen_add(ar7, tr7);
         ar8 = gen_add(ar8, tr8);

         ai1 = gen_add(ai1, ti1);
         ai2 = gen_add(ai2, ti2);
         ai3 = gen_add(ai3, ti3);
         ai4 = gen_add(ai4, ti4);
         ai5 = gen_add(ai5, ti5);
         ai6 = gen_add(ai6, ti6);
         ai7 = gen_add(ai7, ti7);
         ai8 = gen_add(ai8, ti8);

         rv[a0] = ar1;
         rv[a1] = ar2;
         rv[a2] = ar3;
         rv[a3] = ar4;
         rv[a4] = ar5;
         rv[a5] = ar6;
         rv[a6] = ar7;
         rv[a7] = ar8;
         rv[b0] = br1;
         rv[b1] = br2;
         rv[b2] = br3;
         rv[b3] = br4;
         rv[b4] = br5;
         rv[b5] = br6;
         rv[b6] = br7;
         rv[b7] = br8;
         iv[a0] = ai1;
         iv[a1] = ai2;
         iv[a2] = ai3;
         iv[a3] = ai4;
         iv[a4] = ai5;
         iv[a5] = ai6;
         iv[a6] = ai7;
         iv[a7] = ai8;
         iv[b0] = bi1;
         iv[b1] = bi2;
         iv[b2] = bi3;
         iv[b3] = bi4;
         iv[b4] = bi5;
         iv[b5] = bi6;
         iv[b6] = bi7;
         iv[b7] = bi8;

         arptr+=8;
         brptr+=8;
      }
   }

   if (fwd_flag) {
      for (i=0; i<n; i+=8) {
         iv[i  ] = gen_sub(fzero, iv[i  ]);
         iv[i+1] = gen_sub(fzero, iv[i+1]);
         iv[i+2] = gen_sub(fzero, iv[i+2]);
         iv[i+3] = gen_sub(fzero, iv[i+3]);
         iv[i+4] = gen_sub(fzero, iv[i+4]);
         iv[i+5] = gen_sub(fzero, iv[i+5]);
         iv[i+6] = gen_sub(fzero, iv[i+6]);
         iv[i+7] = gen_sub(fzero, iv[i+7]);
      }
   }
   else {
      for (i=0; i<n; i+=8) {
         rv[i  ] = gen_mul(fninv, rv[i  ]);
         rv[i+1] = gen_mul(fninv, rv[i+1]);
         rv[i+2] = gen_mul(fninv, rv[i+2]);
         rv[i+3] = gen_mul(fninv, rv[i+3]);
         rv[i+4] = gen_mul(fninv, rv[i+4]);
         rv[i+5] = gen_mul(fninv, rv[i+5]);
         rv[i+6] = gen_mul(fninv, rv[i+6]);
         rv[i+7] = gen_mul(fninv, rv[i+7]);
         iv[i  ] = gen_mul(fninv, iv[i  ]);
         iv[i+1] = gen_mul(fninv, iv[i+1]);
         iv[i+2] = gen_mul(fninv, iv[i+2]);
         iv[i+3] = gen_mul(fninv, iv[i+3]);
         iv[i+4] = gen_mul(fninv, iv[i+4]);
         iv[i+5] = gen_mul(fninv, iv[i+5]);
         iv[i+6] = gen_mul(fninv, iv[i+6]);
         iv[i+7] = gen_mul(fninv, iv[i+7]);
      }
   }
}

#endif /* _FFT_2D_H_ */
