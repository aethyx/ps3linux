/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _CROSS_PRODUCT3_H_
#define _CROSS_PRODUCT3_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif


/*
 * FUNCTION
 * 	vector float _cross_product3(vector float v1, vector float v2)
 * 
 * DESCRIPTION
 * 	_cross_product3 computes the cross product of the two 3 component
 *	input vectors - v1 cross v2. The 3 component inputs are packed into
 *	128-bit 4-component floating point vector, v1 and v2. The 4th input
 *	components are not used, however, computation is performed in such 
 *	a manner that the resulting 4th component is 0.0.
 *           _______________________________
 *          |___X___|___Y___|___Z___|___-___|
 *        
 *	out.x = (v1.y * v2.z) - (v1.z * v2.y)
 *	out.y = (v1.z * v2.x) - (v1.x * v2.z)
 *	out.z = (v1.x * v2.y) - (v1.y * v2.x)
 *	out.w = 0.0;
 */

static __inline vector float _cross_product3(vector float v1, vector float v2)
{
  vector float yzxw1, yzxw2;
  vector float result;
  vector unsigned char shuffle_yzxw = ((vector unsigned char) {
						  0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B,
						  0x00, 0x01, 0x02, 0x03, 0x0C, 0x0D, 0x0E, 0x0F});
#ifdef __SPU__
  yzxw1  = spu_shuffle(v1, v1, shuffle_yzxw);
  yzxw2  = spu_shuffle(v2, v2, shuffle_yzxw);
  result = spu_mul(v1, yzxw2);
  result = spu_nmsub(v2, yzxw1, result);
  result = spu_shuffle(result, result, shuffle_yzxw);
#else
  yzxw1  = vec_perm(v1, v1, shuffle_yzxw);
  yzxw2  = vec_perm(v2, v2, shuffle_yzxw);
  result = vec_madd(v1, yzxw2, ((vector float) {0.0,0.0,0.0,0.0}));
  result = vec_nmsub(v2, yzxw1, result);
  result = vec_perm(result, result, shuffle_yzxw);
#endif
  return (result);
}


#endif /* _CROSS_PRODUCT3_H_ */
