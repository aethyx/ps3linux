/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _intersect_ray_triangle_h_
#define _intersect_ray_triangle_h_

/* function:    _intersect_ray_triangle (ro, rd, h, p0, p1, p2, id)
 *
 * parameters:
 *   vector float ro,           // AoS (XYZW) ray origin
 *   vector float rd,           // AoS (XYZW) ray direction
 *   vector float h,            // accumulated hit record
 *   const vector float p[3],   // AoS (XYZW) triangle coordiantes
 *   int id                     // triangle id
 *
 * Determine if a ray intersects a given triangle.  If so, return
 * the triangle's paramaterized (u, v) intersection coordinates.
 *
 * This routine is not optimized for performance, but is instead
 * provided as a reference implementation of the published material.
 *
 * See also:
 *
 *   Ray Tracing on Programmable Graphics Hardware
 *   Purcell, Buck, Mark, Hanrahan
 *   Proceedings of ACM SIGGRAPH, 2002
 */

#include <cross_product3.h>
#include <dot_product3.h>
#include <load_vec_float4.h>


static __inline vector float _intersect_ray_triangle (vector float ro, vector float rd, vector float h, const vector float p[3], float id)
{
  vector float edge1, edge2;
  vector float pvec, tvec, qvec;
  unsigned int validhit;
  float det, inv_det;
  float u, v, t;

#ifdef __SPU__

  edge1   = spu_sub (p[1], p[0]);
  edge2   = spu_sub (p[2], p[0]);
  pvec    = _cross_product3 (rd, edge2);
  det     = _dot_product3 (edge1, pvec);
  inv_det = 1.0f / det;
  tvec    = spu_sub (ro, p[0]);
  u       = _dot_product3 (tvec, pvec) * inv_det;
  qvec    = _cross_product3 (tvec, edge1);
  v       = _dot_product3 (rd, qvec) * inv_det;
  t       = _dot_product3 (edge2, qvec) * inv_det;

  validhit = (u >= 0.0f) ?  1 : 0;
  validhit = (v >= 0.0f) ? validhit :  0;
  validhit = ((u+v)<= 1.0f) ? validhit :  0;
  validhit = (t < spu_extract(h, 0)) ? validhit : 0;
  validhit = (t >= 0.0f) ? validhit : 0;

  t  = (validhit) ? t  : spu_extract (h, 0);
  u  = (validhit) ? u  : spu_extract (h, 1);
  v  = (validhit) ? v  : spu_extract (h, 2);
  id = (validhit) ? id : spu_extract (h, 3);

#else /* !__SPU__ */
  union {
    vector float v;
    float f[4];
  } data;

  data.v = h;

  edge1   = vec_sub (p[1], p[0]);
  edge2   = vec_sub (p[2], p[0]);
  pvec    = _cross_product3 (rd, edge2);
  det     = _dot_product3 (edge1, pvec);
  inv_det = 1.0f / det;
  tvec    = vec_sub (ro, p[0]);
  u       = _dot_product3 (tvec, pvec) * inv_det;
  qvec    = _cross_product3 (tvec, edge1);
  v       = _dot_product3 (rd, qvec) * inv_det;
  t       = _dot_product3 (edge2, qvec) * inv_det;

  validhit = (u >= 0.0f) ?  1 : 0;
  validhit = (v >= 0.0f) ? validhit :  0;
  validhit = ((u+v)<= 1.0f) ? validhit :  0;
  validhit = (t < data.f[0]) ? validhit : 0;
  validhit = (t >= 0.0f) ? validhit : 0;

  t  = (validhit) ? t  : data.f[0];
  u  = (validhit) ? u  : data.f[1];
  v  = (validhit) ? v  : data.f[2];
  id = (validhit) ? id : data.f[3];

#endif /* __SPU__ */

  return _load_vec_float4 (t, u, v, id);
}

#endif /* _intersect_ray_triangle_h_ */
