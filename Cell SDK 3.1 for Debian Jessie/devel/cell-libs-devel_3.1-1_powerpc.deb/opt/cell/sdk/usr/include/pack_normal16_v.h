/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _PACK_NORMAL16_V_H_
#define _PACK_NORMAL16_V_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

#include "normal16.h"

/*
 * FUNCTION
 *	double _pack_normal16_v(vector float normal)
 * 
 * DESCRIPTION
 *      _pack_normal16_v takes a vector of floating point normals nominally 
 *	in the range -1.0 to 1.0 and packs it into a signed fixed point 
 *	16-bit value. This is done for the purposes of saving data storage
 *	or SPU local store.
 */

static __inline double _pack_normal16_v(vector float normal)
{

#ifdef __SPU__
  vector float work;

  /* Convert from -1 to 1 range to fixed point range.
   */
  work = spu_madd(normal, VECTOR_PACK_NORMAL_SCALE, VECTOR_PACK_NORMAL_BIAS);
  
  /* Pack the 4 shorts into a double word.
   */
  work = spu_shuffle(work, work, ((vector unsigned char) { 
					     0x02, 0x03, 0x06, 0x07, 0x0A, 0x0B, 0x0E, 0x0F,
					     0x02, 0x03, 0x06, 0x07, 0x0A, 0x0B, 0x0E, 0x0F}));
  return (spu_extract((vector double)(work), 0));


#else
  union {
    vector unsigned int ui;
    vector float f;
    double d[2];
  } work;


  /* Convert from -1 to 1 range to fixed point range.
   */
  work.f = vec_madd(normal, VECTOR_PACK_NORMAL_SCALE, VECTOR_PACK_NORMAL_BIAS);
  
  /* Pack the 4 shorts into a double word.
   */
  work.ui = vec_perm(work.ui, work.ui, ((vector unsigned char) {
  						0x02, 0x03, 0x06, 0x07, 0x0A, 0x0B, 0x0E, 0x0F,
						0x02, 0x03, 0x06, 0x07, 0x0A, 0x0B, 0x0E, 0x0F}));
  return (work.d[0]);
#endif
}

#endif /* _PACK_NORMAL16_V_H_ */
