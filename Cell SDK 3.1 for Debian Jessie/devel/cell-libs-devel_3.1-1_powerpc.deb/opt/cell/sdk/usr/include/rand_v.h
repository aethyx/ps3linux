/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _RAND_V_H_
#define _RAND_V_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

#include "rand_util.h"
#include <libmisc.h>

/*
 * FUNCTION
 *	vector signed int _rand_v(void)
 *
 * DESCRIPTION
 *	_rand_v generates a random vector word containing 4 31-bit 
 *      integer random values. The seed is implicitly updated such 
 *	that the next call to rand_v returns another random set of 
 *	values. This function is uniformily cyclic.
 *
 *	Algorithm: X(n+1) = 48271 * X(n) mod (2^31 - 1)
 */
static __inline vector signed int _rand_v()
{
  vector unsigned int hi, lo, tmp, p01, p23, q0123, p0123, result;
  vector unsigned int q0, q1, q2, q3;
  vector unsigned int p0, p1, p2, p3;
  vector unsigned short multiplier;
  vector unsigned short seed;

  /* Multiply the 4 32-bit seed values by the 16-bit constant to
   * generate 4 48-bit values. The 48-bit values are split across
   * the two word vectors where the 16 msb's are in the 'hi' vector
   * and the 32 lsb's are in the 'lo' vector.
   */
  seed = (vector unsigned short)rand_seed;

#ifdef __SPU__
  multiplier = spu_splats((unsigned short)48271);
  lo = spu_mulo(seed, multiplier);
  hi = spu_mule(seed, multiplier);
  
  tmp = spu_sl(hi, 16);
  hi  = spu_add(spu_rlmask(hi, -16), spu_genc(tmp, lo));
  lo  = spu_add(tmp, lo);

  /* Compute the modulo of the 48-bit product and 0x7FFFFFFF.
   * This is done by first computing the quotient (q) of 
   * the product (hi,lo) and the modulus (0x7FFFFFFF), then 
   * computing the modulo by subtracting the resulting quotient
   * times the modulus from the product. This is further 
   * optimized by observing that q * 0x7FFFFFFF is
   * equivalent to (q << 31) - q;
   */
  p01 = spu_shuffle(hi, lo, ((vector unsigned char) { 
					0, 1, 2, 3, 16, 17, 18, 19, 
					4, 5, 6, 7, 20, 21, 22, 23}));
  p23 = spu_shuffle(hi, lo, ((vector unsigned char) {
					8, 9,10,11, 24, 25, 26, 27, 
					12,13,14,15, 28, 29, 30, 31}));
						  
  p0 = p01;
  p1 = spu_slqwbyte(p01, 8);
  p2 = p23;
  p3 = spu_slqwbyte(p23, 8);

  /* To compute the quotient, we multiply the product by
   * 0x80000001 00000004 and right shift by 96 bits.
   */
  q0 = _div_7FFFFFFF(p0);
  q1 = _div_7FFFFFFF(p1);
  q2 = _div_7FFFFFFF(p2);
  q3 = _div_7FFFFFFF(p3);

  q0123 = spu_or(spu_shuffle(q0, q1, ((vector unsigned char) { 
						 0,    1,  2,  3,  16, 17, 18, 19,
						 128,128,128,128, 128,128,128,128})),
		 spu_shuffle(q2, q3, ((vector unsigned char) {
						 128,128,128,128, 128,128,128,128,
						 0,    1,  2,  3,  16, 17, 18, 19})));
  /* p0123 is it packed 32 least significant bits of the each of the 48 bit product terms.
   */
  p0123 = spu_shuffle(p01, p23, ((vector unsigned char) {
					    4, 5, 6, 7,  12,13,14,15,
					    20,21,22,23,  28,29,30,31}));

  result = spu_sub(p0123, spu_sub(spu_sl(q0123, 31), q0123));

#else /* !__SPU__ */
  multiplier = ((vector unsigned short) {48271,48271,48271,48271,48271,48271,48271,48271});
  vector unsigned int zero = ((vector unsigned int) {0,0,0,0});
  vector unsigned int sixteen = ((vector unsigned int) {16,16,16,16});

  lo = vec_mulo(seed, multiplier);
  hi = vec_mule(seed, multiplier);
  
  tmp = vec_sl(hi, sixteen);
  hi  = vec_add(vec_sr(hi, sixteen), vec_addc(tmp, lo));
  lo  = vec_add(tmp, lo);

  /* Compute the modulo of the 48-bit product and 0x7FFFFFFF.
   * This is done by first computing the quotient (q) of 
   * the product (hi,lo) and the modulus (0x7FFFFFFF), then 
   * computing the modulo by subtracting the resulting quotient
   * times the modulus from the product. This is further 
   * optimized by observing that q * 0x7FFFFFFF is
   * equivalent to (q << 31) - q;
   */
  p01 = vec_perm(hi, lo, ((vector unsigned char) { 
				     0, 1, 2, 3, 16, 17, 18, 19, 
				     4, 5, 6, 7, 20, 21, 22, 23}));
  p23 = vec_perm(hi, lo, ((vector unsigned char) {
				     8, 9,10,11, 24, 25, 26, 27, 
				     12,13,14,15, 28, 29, 30, 31}));
						  
  p0 = p01;
  p1 = vec_sld(p01, zero, 8);
  p2 = p23;
  p3 = vec_sld(p23, zero, 8);

  /* To compute the quotient, we multiply the product by
   * 0x80000001 00000004 and right shift by 96 bits.
   */
  q0 = _div_7FFFFFFF(p0);
  q1 = _div_7FFFFFFF(p1);
  q2 = _div_7FFFFFFF(p2);
  q3 = _div_7FFFFFFF(p3);

  q0123 = vec_mergeh(vec_mergeh(q0, q2), vec_mergeh(q1, q3));

  /* p0123 is it packed 32 least significant bits of the each of the 48 bit product terms.
   */
  p0123 = vec_perm(p01, p23, ((vector unsigned char) {
					 4, 5, 6, 7,  12,13,14,15,
					 20,21,22,23,  28,29,30,31}));

  result = vec_sub(p0123, vec_sub(vec_sl(q0123, ((vector unsigned int) {31,31,31,31})), q0123));

#endif /* __SPU__ */


  rand_seed = result;

  return ((vector signed int)result);
}

#endif /* _RAND_V_H_ */
