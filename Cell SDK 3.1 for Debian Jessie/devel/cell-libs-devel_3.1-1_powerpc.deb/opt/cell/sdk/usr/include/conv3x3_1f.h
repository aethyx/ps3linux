/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
 
#ifndef _conv3x3_1f_h_
#define _conv3x3_1f_h_

#include <conv_defs.h>
#include <conv_shuf.h>

/* 
NAME
 	_conv3x3_1f - 3x3 convolution for single component float images

SYNOPSIS
	#include <conv3x3_1f.h>

 	void _conv3x3_1f(const float *in[3], float *out, 
			 const vec_float4 m[9], int w)

DESCRIPTION
	Compute output pixels as the weighted sum of the input images's 
 	3x3 neighborhood and the filter mask 'm'.

	The image format is single component floating point.  The filter
	mask 'm' represents an arbitrary 3x3 kernel, where each entry has 
	been replicated from 'float' to 'vec_float4' form.

	Border pixels require a policy for defining values outside the
	image.  Three compile time options are supported.  The default 
	behaviour is to use _BORDER_COLOR_F (pre-defined to 0) for all 
	values beyond the left or right edges of the input image.  For
	values above or below the image, the caller is responsible for
	supplying scanlines cleared to the appropriate value.
	
	When _WRAP_CONV is defined, the input values are periodically 
	repeated --in other words, the input wraps from left to right 
	(and visa-versa).  The caller is responsible for managing the 
	input scanlines to support wrapping from top to bottom.

	When _CLAMP_CONV is defined, the input values are clamped to the 
	border --in other words, the right most value is repeated for 
	values beyond the right edge of the image; the left most value 
	is repeated for values beyond the left edge of the image.  The
	caller is responsible for managing the input scanlines to support
	clamping from top to bottom.

RESTRICTIONS
 	The input and output scanlines must be quad-word aligned.  The 
	scanline width 'w' must be a multiple of 16 pixels.  Neither the
	input nor the output values are clamped or scaled to a fixed range.
 */
static __inline void _conv3x3_1f (const float *in[3], float *out, const vec_float4 m[9], int w)
{
  const vec_float4 *in0  = (const vec_float4 *)in[0];
  const vec_float4 *in1  = (const vec_float4 *)in[1];
  const vec_float4 *in2  = (const vec_float4 *)in[2];
  vec_float4 *vout = (vec_float4 *)out;
  vec_float4 p0, p1, p2;
  vec_float4 prev, prevu, prevuu, prevuuu;
  vec_float4 curr, curru, curruu, curruuu;
  vec_float4 next, nextu, nextuu, nextuuu;
  vec_float4 left, leftu, leftuu, leftuuu;
  vec_float4 right, rightu, rightuu, rightuuu;
  vec_float4 res, resu, resuu, resuuu;
  vec_float4 m00, m01, m02, m03;
  vec_float4 m04, m05, m06, m07, m08;
  int i0, i1, i2, i3, i4;

  m00 = m[0]; m01 = m[1]; m02 = m[2];
  m03 = m[3]; m04 = m[4]; m05 = m[5];
  m06 = m[6]; m07 = m[7]; m08 = m[8];

#ifdef _WRAP_CONV
  p0 = in0[(w>>2)-1];
  p1 = in1[(w>>2)-1];
  p2 = in2[(w>>2)-1];
#elif defined(_CLAMP_CONV)
  p0 = in0[0];
  p1 = in1[0];
  p2 = in2[0];
#else
  p0 = _BORDER_COLOR_F;
  p1 = _BORDER_COLOR_F;
  p2 = _BORDER_COLOR_F;
#endif /* _WRAP_CONV */

#define _CONV3_1f(_m0, _m1, _m2)			\
  _GET_x4(prev, curr, left, left_shuf);			\
  _GET_x4(curr, next, right, right_shuf);		\
  _CALC_PIXELS_1f_x4(left, _m0, res);			\
  _CALC_PIXELS_1f_x4(curr, _m1, res);			\
  _CALC_PIXELS_1f_x4(right, _m2, res)

  for (i0=0, i1=1, i2=2, i3=3, i4=4; i0<(w>>2)-4; i0+=4, i1+=4, i2+=4, i3+=4, i4+=4)
  {
#ifdef __SPU__
    res = resu = resuu = resuuu = spu_splats((float)0.0f);
#else /* !__SPU__ */
    res = resu = resuu = resuuu = ((vector float) {0.0f,0.0f,0.0f,0.0f});
#endif /* __SPU__ */
    
    _GET_SCANLINE_x4(p0, in0[i0], in0[i1], in0[i2], in0[i3], in0[i4]);
    _CONV3_1f(m00, m01, m02);

    _GET_SCANLINE_x4(p1, in1[i0], in1[i1], in1[i2], in1[i3], in1[i4]);
    _CONV3_1f(m03, m04, m05);

    _GET_SCANLINE_x4(p2, in2[i0], in2[i1], in2[i2], in2[i3], in2[i4]);
    _CONV3_1f(m06, m07, m08);

    vout[i0] = res;
    vout[i1] = resu;
    vout[i2] = resuu;
    vout[i3] = resuuu;
  }
#ifdef __SPU__
  res = resu = resuu = resuuu = spu_splats((float)0.0f);
#else /* !__SPU__ */
  res = resu = resuu = resuuu = ((vector float) {0.0f,0.0f,0.0f,0.0f});
#endif /* __SPU__ */

#ifdef _WRAP_CONV
  _GET_SCANLINE_x4(p0, in0[i0], in0[i1], in0[i2], in0[i3], in0[0]);
  _CONV3_1f(m00, m01, m02);

  _GET_SCANLINE_x4(p1, in1[i0], in1[i1], in1[i2], in1[i3], in1[0]);
  _CONV3_1f(m03, m04, m05);

  _GET_SCANLINE_x4(p2, in2[i0], in2[i1], in2[i2], in2[i3], in2[0]);
  _CONV3_1f(m06, m07, m08);

#elif defined(_CLAMP_CONV)
  _GET_SCANLINE_x4(p0, in0[i0], in0[i1], in0[i2], in0[i3], in0[i3]);
  _CONV3_1f(m00, m01, m02);

  _GET_SCANLINE_x4(p1, in1[i0], in1[i1], in1[i2], in1[i3], in1[i3]);
  _CONV3_1f(m03, m04, m05);

  _GET_SCANLINE_x4(p2, in2[i0], in2[i1], in2[i2], in2[i3], in2[i3]);
  _CONV3_1f(m06, m07, m08);

#else
  _GET_SCANLINE_x4(p0, in0[i0], in0[i1], in0[i2], in0[i3], _BORDER_COLOR_F);
  _CONV3_1f(m00, m01, m02);

  _GET_SCANLINE_x4(p1, in1[i0], in1[i1], in1[i2], in1[i3], _BORDER_COLOR_F);
  _CONV3_1f(m03, m04, m05);

  _GET_SCANLINE_x4(p2, in2[i0], in2[i1], in2[i2], in2[i3], _BORDER_COLOR_F);
  _CONV3_1f(m06, m07, m08);

#endif /* _WRAP_CONV */

  vout[i0] = res;
  vout[i1] = resu;
  vout[i2] = resuu;
  vout[i3] = resuuu;
}

#endif /* _conv3x3_1f_h_ */
