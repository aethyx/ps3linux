/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _DOT_PRODUCT3_V_H_
#define _DOT_PRODUCT3_V_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif
/*
 * FUNCTION
 * 	vector float _dot_product3_v(vector float x1, vector float y1, vector float z1,
 *				     vector float x2, vector float y2, vector float z2);
 * 
 * DESCRIPTION
 * 	_dot_product3_v computes 4 simultaneous dot products of the two 
 *	SIMD input vectors. The input vectors are expressed in parallel array
 *	format and are defined by input parameters (x1, y1, z1) and (x2, y2, z2).
 *
 *	This routine contains dependent fma's and must be interleaved with other 
 *	processing to achieve optimal performance.
 */

static __inline vector float _dot_product3_v(vector float x1, vector float y1, vector float z1, vector float x2, vector float y2, vector float z2)
{
  vector float result;
#ifdef __SPU__
  result = spu_mul(x1, x2);
  result = spu_madd(y1, y2, result);
  result = spu_madd(z1, z2, result);
#else
  result = vec_madd(x1, x2, ((vector float) {0.0,0.0,0.0,0.0}));
  result = vec_madd(y1, y2, result);
  result = vec_madd(z1, z2, result);
#endif
  return (result);
}


#endif /* _DOT_PRODUCT3_V_H_ */
