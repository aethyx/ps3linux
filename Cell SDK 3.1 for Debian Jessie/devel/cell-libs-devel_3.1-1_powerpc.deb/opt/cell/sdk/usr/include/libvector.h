/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _LIB_VECTOR_H_
#define _LIB_VECTOR_H_	1

#define CLIP_CODE_RIGHT		0x80
#define CLIP_CODE_LEFT		0x40
#define CLIP_CODE_TOP		0x20
#define CLIP_CODE_BOTTOM	0x10
#define CLIP_CODE_FAR		0x08
#define CLIP_CODE_NEAR		0x04

#define CLIP_CODE_EYE		0x01


extern unsigned int clipcode_ndc(vector float v);
extern vector unsigned int clipcode_ndc_v(vector float x, vector float y, vector float z, vector float w);
extern vector float clip_ray(vector float v1, vector float v2, vector float plane);
extern vector float cross_product3(vector float v1, vector float v2);
extern void cross_product3_v(vector float *xout, vector float *yout, vector float *zout, vector float x1, vector float y1, vector float z1, vector float x2, vector float y2, vector float z2);
extern vector float cross_product4(vector float v1, vector float v2);
extern float dot_product3(vector float v1, vector float v2);
extern vector float dot_product3_v(vector float x1, vector float y1, vector float z1, vector float x2, vector float y2, vector float z2);
extern float dot_product4(vector float v1, vector float v2);
extern vector float dot_product4_v(vector float x1, vector float y1, vector float z1, vector float w1, vector float x2, vector float y2, vector float z2, vector float w2);
extern vector float intersect_ray_triangle(vector float ro, vector float rd, vector float h, const vector float p[3], float id);
extern void intersect_ray_triangle_v(vector float h[4], vector float rox, vector float roy, vector float roz, vector float rdx, vector float rdy, vector float rdz, vector float p0x, vector float p0y, vector float p0z, vector float p1x, vector float p1y, vector float p1z, vector float p2x, vector float p2y, vector float p2z, vector float id);
extern void intersect_ray1_triangle8_v(vector float h[8], vector float rox, vector float roy, vector float roz, vector float rdx, vector float rdy, vector float rdz, const vector float p0x[2], const vector float p0y[2], const vector float p0z[2], const vector float p1x[2], const vector float p1y[2], const vector float p1z[2], const vector float p2x[2], const vector float p2y[2], const vector float p2z[2], const vector float id[2]);
extern void intersect_ray8_triangle1_v(vector float hit_t[2], vector float hit_u[2], vector float hit_v[2], vector unsigned int hit_id[2], const vector float rox[2], const vector float roy[2], const vector float roz[2], const vector float rdx[2], const vector float rdy[2], const vector float rdz[2], const vector float ex[2], const vector float ey[2], const vector float ez[2], vector float p0x, vector float p0y, vector float p0z, vector unsigned int ids[2]);
extern float inv_length_vec3(vector float v);
extern vector float inv_length_vec3_v(vector float x, vector float y, vector float z);
extern float length_vec3(vector float v);
extern vector float length_vec3_v(vector float x, vector float y, vector float z);
extern void lerp_vec2_v(vector float *xout, vector float *yout, vector float x1, vector float y1, vector float x2, vector float y2, vector float t);
extern void lerp_vec3_v(vector float *xout, vector float *yout, vector float *zout, vector float x1, vector float y1, vector float z1, vector float x2, vector float y2, vector float z2, vector float t);
extern vector float lerp_vec4(vector float v1, vector float v2, vector float t);
extern void lerp_vec4_v(vector float *xout, vector float *yout, vector float *zout, vector float *wout, vector float x1, vector float y1, vector float z1, vector float w1, vector float x2, vector float y2, vector float z2, vector float w2, vector float t);
extern vector float load_vec_float4(float f1, float f2, float f3, float f4);
extern vector signed int load_vec_int4(signed int i1, signed int i2, signed int i3, signed int i4);
extern vector float normalize3(vector float in);
extern vector float normalize4(vector float in);
extern void normalize3_v(vector float *xout, vector float *yout, vector float *zout, vector float  xIn,  vector float  yIn,  vector float  zIn);
extern vector float reflect_vec3(vector float v, vector float n);
extern void reflect_vec3_v(vector float *rx, vector float *ry, vector float *rz, vector float vx, vector float vy, vector float vz, vector float nx, vector float ny, vector float nz);
extern vector float splat_dot_product3(vector float v1, vector float v2);
extern float sum_across_float3(vector float v);
extern float sum_across_float4(vector float v);

extern vector float xform_norm3(vector float vec, const vector float *m);
extern void xform_norm3_v(vector float *xout, vector float *yout, vector float *zout, vector float xin, vector float yin, vector float zin, const vector float *m); 
extern vector float xform_vec3(vector float vec, const vector float *m);
extern void xform_vec3_v(vector float *xout, vector float *yout, vector float *zout, vector float *wout, vector float xin, vector float yin, vector float zin, const vector float *m); 
extern vector float xform_vec4(vector float vec, const vector float *m);
extern void xform_vec4_v(vector float *xout, vector float *yout, vector float *zout, vector float *wout, vector float xin, vector float yin, vector float zin, vector float win, const vector float *m);

/* Aliased functions */
extern vector float lerp_vec1_v(vector float v1, vector float v2, vector float t);

#endif /* _LIB_VECTOR_H_ */


