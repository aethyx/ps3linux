/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _TRANSPOSE_MATRIX_4X4_H_
#define _TRANSPOSE_MATRIX_4X4_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else
#include <altivec.h>
#endif

/*
 * FUNCTION
 * 	void  _transpose_matrix4x4(vector float *mOut, vector float *mIn)
 * 
 * DESCRIPTION
 *	_transpose_matrix4x4 performs a transpose on the 4x4 input matrix
 *	placing the results in the output matrix. Matrix entries and 
 *	local variable names are labeled as follows:
 *
 *		 input			 output
 *		-------			-------
 *		a b c d			a e i m
 *		e f g h 		b f j n
 *		i j k l			c g k o
 *		m n o p			d h l p
 *
 *	This routine assumes the vector pointers are aligned to 128-bit 
 *	boundaries. However, because mIn is not declared constant, 
 *	this routine is capable of performing the transpose in place.
 */

static __inline void _transpose_matrix4x4(vector float *mOut, vector float *mIn)
{
  vector float abcd, efgh, ijkl, mnop;	/* input vectors */
  vector float aeim, bfjn, cgko, dhlp;	/* output vectors */
  vector float aibj, ckdl, emfn, gohp;	/* intermediate vectors */
#ifdef __SPU__
  vector unsigned char shufflehi = ((vector unsigned char) {
					       0x00, 0x01, 0x02, 0x03,
					       0x10, 0x11, 0x12, 0x13,
					       0x04, 0x05, 0x06, 0x07,
					       0x14, 0x15, 0x16, 0x17});
  vector unsigned char shufflelo = ((vector unsigned char) {
					       0x08, 0x09, 0x0A, 0x0B,
					       0x18, 0x19, 0x1A, 0x1B,
					       0x0C, 0x0D, 0x0E, 0x0F,
					       0x1C, 0x1D, 0x1E, 0x1F});
  abcd = *(mIn+0);
  efgh = *(mIn+1);
  ijkl = *(mIn+2);
  mnop = *(mIn+3);

  aibj = spu_shuffle(abcd, ijkl, shufflehi);
  ckdl = spu_shuffle(abcd, ijkl, shufflelo);
  emfn = spu_shuffle(efgh, mnop, shufflehi);
  gohp = spu_shuffle(efgh, mnop, shufflelo);

  aeim = spu_shuffle(aibj, emfn, shufflehi);
  bfjn = spu_shuffle(aibj, emfn, shufflelo);
  cgko = spu_shuffle(ckdl, gohp, shufflehi);
  dhlp = spu_shuffle(ckdl, gohp, shufflelo);
#else
  abcd = *(mIn+0);
  efgh = *(mIn+1);
  ijkl = *(mIn+2);
  mnop = *(mIn+3);

  aibj = vec_mergeh(abcd, ijkl);
  ckdl = vec_mergel(abcd, ijkl);
  emfn = vec_mergeh(efgh, mnop);
  gohp = vec_mergel(efgh, mnop);

  aeim = vec_mergeh(aibj, emfn);
  bfjn = vec_mergel(aibj, emfn);
  cgko = vec_mergeh(ckdl, gohp);
  dhlp = vec_mergel(ckdl, gohp);
#endif

  *(mOut+0) = aeim;
  *(mOut+1) = bfjn;
  *(mOut+2) = cgko;
  *(mOut+3) = dhlp;
}

#endif /* _TRANSPOSE_MATRIX_4X4_H_ */
