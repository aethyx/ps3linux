/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _RAND_UTIL_H_
#define _RAND_UTIL_H_   1

#ifdef __SPU__
#include <stdlib.h>
#else
#include "libmisc.h"
#endif

/* To divide a 62-bit number by 0x7FFFFFFF, we multiply it by 
 * 0x80000001 00000004 and right shift by 96 bits. The 62-bit
 * input number is contained in elements 0 and 1 of the unsigned
 * integer vector in. The result is return in element 0 of the 
 * unsigned integer vector.
 */
static __inline vector unsigned int _div_7FFFFFFF(vector unsigned int in)
{
  vector unsigned int sum, carry, addend;
  vector unsigned int x, x2, x32, x63;

#ifdef __SPU__
  x = spu_rlmaskqwbyte(in, -8);

  x2 = spu_slqw(x, 2);
  x32 = spu_slqwbyte(x, 4);
  x63 = spu_slqwbyte(spu_slqw(x, 7), 7);

  sum = spu_add(x2, x32);
  carry = spu_add(spu_genc(x2, x32), spu_genc(sum, x63));
  sum = spu_add(sum, x63);

  addend = spu_slqwbyte(carry, 4);
  carry = spu_genc(sum, addend);
  sum = spu_add(sum, addend);

  addend = spu_slqwbyte(carry, 4);
  sum = spu_add(sum, addend);

  return (spu_slqw(sum, 2));
#else
  vector unsigned int zero = ((vector unsigned int) {0,0,0,0});
  vector unsigned int two = ((vector unsigned int) {0x02020202,0x02020202,0x02020202,0x02020202});
  vector unsigned int seven = ((vector unsigned int) {0x07070707,0x07070707,0x07070707,0x07070707});

  x = vec_sld(zero, in, 8);

  x2  = vec_sll(x, two);
  x32 = vec_sld(x, zero, 4);
  x63 = vec_sld(vec_sll(x, seven), zero, 7);

  sum = vec_add(x2, x32);
  carry = vec_add(vec_addc(x2, x32), vec_addc(sum, x63));
  sum = vec_add(sum, x63);

  addend = vec_sld(carry, zero, 4);
  carry = vec_addc(sum, addend);
  sum = vec_add(sum, addend);

  addend = vec_sld(carry, zero, 4);
  sum = vec_add(sum, addend);

  return (vec_sll(sum, two));

#endif /* __SPU__ */
}

#endif /* _RAND_UTIL_H_ */
