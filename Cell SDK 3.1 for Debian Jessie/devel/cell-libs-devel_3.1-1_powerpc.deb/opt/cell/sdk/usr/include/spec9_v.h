/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _SPEC9_V_H_
#define _SPEC9_V_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

#include "spec9_types.h"

/*
 * FUNCTION
 *	vector float spec9_v(vector float base, spec9Exponent *exp)
 *
 * DESCRIPTION
 *	spec9_v computes the power function of the form x^y for the limited 
 *	set of values traditionally used in specular lighting.
 *	spec exploits the shuffle byte instruction to compute
 *	the power function using a 8 segment piecewise quadratic 
 *	approximation. The exponent is an integer within the range 
 *	0-255 that has been reformated into a set of coeffients specified by
 *	exp parameter. The base (x) is a floating point value in the 
 *	range 0.0 to 1.0. Values below 0.0 produce 0.0 and above produce 1.0.
 *
 *      The coefficients for the quadratic equations are computed 
 *      by the set_spec_exponent9 subroutine and are passed to _spec9
 *	by the exp parameter.
 *
 *	spec9_v is accurate to at least 9 bits.
 */

static __inline vector float _spec9_v(vector float base, spec9Exponent *exp)
{
  vector unsigned int exponent;
  vector unsigned int idx;
  union { 
    vector signed int i;
    vector unsigned int ui;
    vector float f;
  } frac;
  vector float result;
  vector float a, b, c;
  vector float outOfRange;
  vector unsigned int selectUnderflow;
  vector unsigned int selectInRange;


#ifdef __SPU__
  /* Compute the spec power function using 8 piecewise quadratic
   * equations.
   */
  frac.f = spu_madd(base, exp->scale, exp->offset);

  idx = spu_rlmask(frac.ui, -18);
  idx = spu_and(idx, 0x1C);

  
  idx = spu_shuffle(idx, idx, ((vector unsigned char) { 
					  0x03, 0x03, 0x03, 0x03, 0x07, 0x07, 0x07, 0x07,
					  0x0b, 0x0b, 0x0b, 0x0b, 0x0f, 0x0f, 0x0f, 0x0f}));
  idx = spu_or(idx, spu_splats((unsigned int)0x00010203));

  a = spu_shuffle(exp->A[0], exp->A[1], (vector unsigned char)(idx));
  b = spu_shuffle(exp->B[0], exp->B[1], (vector unsigned char)(idx));
  c = spu_shuffle(exp->C[0], exp->C[1], (vector unsigned char)(idx));

  result = spu_madd(a, frac.f, b);
  result = spu_madd(result, frac.f, c);

  exponent = spu_rlmask(frac.ui, -23);
  selectInRange   = spu_cmpeq(exponent, 0x7F);
  selectUnderflow = spu_cmpgt(spu_splats((float)1.0), frac.f);

  outOfRange = spu_sel(spu_splats((float)1.0), spu_splats((float)0.0), selectUnderflow);

  result = spu_sel(outOfRange, result, selectInRange);
#else
  /* Compute the spec power function using 8 piecewise quadratic
   * equations.
   */
  frac.f = vec_madd(base, exp->scale, exp->offset);

  idx = vec_sr(frac.ui, ((vector unsigned int) {18,18,18,18}));
  idx = vec_and(idx, ((vector unsigned int) {0x1C,0x1C,0x1C,0x1C}));

  
  idx = vec_perm(idx, idx, ((vector unsigned char) { 
				       0x03, 0x03, 0x03, 0x03, 0x07, 0x07, 0x07, 0x07,
				       0x0b, 0x0b, 0x0b, 0x0b, 0x0f, 0x0f, 0x0f, 0x0f}));
  idx = vec_or(idx, ((vector unsigned int) {0x00010203,0x00010203,0x00010203,0x00010203}));

  a = (vector float)vec_perm((vector unsigned int)(exp->A[0]), (vector unsigned int)(exp->A[1]), 
			     (vector unsigned char)(idx));
  b = (vector float)vec_perm((vector unsigned int)(exp->B[0]), (vector unsigned int)(exp->B[1]), 
			     (vector unsigned char)(idx));
  c = (vector float)vec_perm((vector unsigned int)(exp->C[0]), (vector unsigned int)(exp->C[1]), 
			     (vector unsigned char)(idx));

  result = vec_madd(a, frac.f, b);
  result = vec_madd(result, frac.f, c);

  exponent = vec_sr(frac.ui, ((vector unsigned int) {23,23,23,23}));
  selectInRange   = (vector unsigned int)vec_cmpeq(exponent, ((vector unsigned int) {0x7F,0x7F,0x7F,0x7F}));
  selectUnderflow = (vector unsigned int)vec_cmpgt(((vector float) {1.0,1.0,1.0,1.0}), frac.f);

  outOfRange = (vector float)vec_sel((vector unsigned int)(((vector float) {1.0,1.0,1.0,1.0})),
				     (vector unsigned int)(((vector float) {0.0,0.0,0.0,0.0})),
				     selectUnderflow);

  result = (vector float)vec_sel((vector unsigned int)(outOfRange),
				 (vector unsigned int)(result),
				 selectInRange);

#endif
  return (result);
}

#endif /* _SPEC9_V_H_ */

