/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _PERSPECTIVE_MATRIX_4X4_H_
#define _PERSPECTIVE_MATRIX_4X4_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif
#include <simdmath/tanf4.h>
#include <simdmath/recipf4.h>

/*
 * FUNCTION
 * 	void  _perspective_matrix4x4(vector float *mOut,
 *			       	     float fovy, float aspect, float near, float far)
 *			       
 * 
 * DESCRIPTION
 *	The _perspecitve_matrix4x4 constructs a perspective projection 
 *	transformation matrix. The persective matrix matches that of OpenGL's 
 *	perspecitve function. The matrix is computed as follows:
 *
 *      cot(fovy/2)/aspect       0            0                     0
 *          0             cot(fovy/2)         0                     0
 *	    0                    0  (far+near)/(near-far) 2*far*near/(near-far)
 *          0                    0           -1                     0
 *
 *
 *	The resulting matrix is returned in mOut.
 */

static __inline void _perspective_matrix4x4(vector float *mOut, float fovy, float aspect, float near, float far)
{
#ifdef __SPU__
  vector float r0, r1, r2;
  vector float tmp1, tmp2, tmp3;

  tmp1 = _tanf4(spu_promote(0.5f * fovy, 0));	/* tmp1 = tan(0.5 * fovy) */
  tmp2 = spu_mul(tmp1, spu_promote(aspect, 0));	/* tmp2 = aspect*tan(0.5 * fovy) */
  tmp3 = spu_promote(near-far, 0);		/* tmp3 = near-far */

  tmp1 = _recipf4(spu_shuffle(tmp2, spu_shuffle(tmp1, tmp3, ((vector unsigned char) { 0,0,0,0, 0,1,2,3, 16,17,18,19, 16,17,18,19})),
			      ((vector unsigned char) { 0,1,2,3, 20,21,22,23, 24,25,26,27, 28,29,30,31})));


  r0 = spu_and(tmp1, (vector float)((vector unsigned int){-1,0,0,0}));
  r1 = spu_and(tmp1, (vector float)((vector unsigned int){0,-1,0,0}));
  r2 = spu_shuffle(spu_promote(far+near, 0), spu_promote(2.0f * far * near, 0),
		   ((vector unsigned char) { 0x80,0x80,0x80,0x80, 0x80,0x80,0x80,0x80, 0,1,2,3, 16,17,18,19}));
  r2 = spu_mul(r2, tmp1);

  *(mOut+0) = r0;
  *(mOut+1) = r1;
  *(mOut+2) = r2;
  *(mOut+3) = ((vector float) { 0.0, 0.0, -1.0, 0.0});

#else
  vector float r0, r1, r2;
  vector float zero = ((vector float) {0.0,0.0,0.0,0.0});
  static union {
    vector float fv;
    float f[4];
  } tmp1, tmp2, tmp3, tmp4;



  tmp1.f[0] = 0.5f*fovy;
  tmp1.fv = _tanf4(tmp1.fv);

  tmp2.f[0] = aspect;
  tmp2.fv = vec_madd(tmp2.fv, tmp1.fv, zero);

  tmp3.f[0] = near-far;

  tmp1.fv = _recipf4(vec_perm(tmp2.fv, vec_perm(tmp1.fv, tmp3.fv, ((vector unsigned char) { 0,0,0,0, 0,1,2,3, 16,17,18,19, 16,17,18,19})),
			      ((vector unsigned char) { 0,1,2,3, 20,21,22,23, 24,25,26,27, 28,29,30,31})));

  tmp4.f[0] = 0.0;
  tmp4.f[1] = 0.0;
  tmp4.f[2] = far+near;
  tmp4.f[3] = 2.0f*far*near;


  r0 = vec_and(tmp1.fv, (vector float)((vector unsigned int){-1,0,0,0}));
  r1 = vec_and(tmp1.fv, (vector float)((vector unsigned int){0,-1,0,0}));
  r2 = vec_madd(tmp4.fv, tmp1.fv, zero);


  *(mOut+0) = r0;
  *(mOut+1) = r1;
  *(mOut+2) = r2;
  *(mOut+3) = ((vector float) { 0.0, 0.0, -1.0, 0.0});

#endif
}

#endif /* _PERSPECTIVE_MATRIX_4X4_H_ */

