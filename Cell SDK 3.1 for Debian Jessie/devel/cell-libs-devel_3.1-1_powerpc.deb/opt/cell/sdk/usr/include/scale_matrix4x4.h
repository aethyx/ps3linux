/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _SCALE_MATRIX_4X4_H_
#define _SCALE_MATRIX_4X4_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 * 	void _scale_matrix4x4(vector float *mOut, vector float *mIn, vector float scales)
 * 
 * DESCRIPTION
 *	_scale_matrix4x4 multiplies input 4x4 matrix (mIn) by scale matrix 
 *	defined by the vector of scale factors. 
 *
 *		mOut = mIn x mScale
 *
 *	The scale vector, scales = [ Sx, Sy, Sz, Sw ], specifies a scale
 *	matrix of the form:
 *
 *			 | Sx    0    0    0 |
 *		mScale = |  0   Sy    0    0 |
 *			 |  0    0   Sz    0 |
 *			 |  0    0    0   Sw |
 */

static __inline void _scale_matrix4x4(vector float *mOut, vector float *mIn, vector float scales)
{
  vector float row0, row1, row2, row3;
#ifndef __SPU__
  vector float vzero = ((vector float) {0.0,0.0,0.0,0.0});
#endif
 
  row0 = *(mIn + 0);
  row1 = *(mIn + 1);
  row2 = *(mIn + 2);
  row3 = *(mIn + 3);

#ifdef __SPU__
  row0 = spu_mul(row0, scales);
  row1 = spu_mul(row1, scales);
  row2 = spu_mul(row2, scales);
  row3 = spu_mul(row3, scales);
#else
  row0 = vec_madd(row0, scales, vzero);
  row1 = vec_madd(row1, scales, vzero);
  row2 = vec_madd(row2, scales, vzero);
  row3 = vec_madd(row3, scales, vzero);
#endif

  *(mOut + 0) = row0;
  *(mOut + 1) = row1;
  *(mOut + 2) = row2;
  *(mOut + 3) = row3;
}

#endif /* _SCALE_MATRIX_4X4_H_ */
