/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _DOT_PRODUCT4_H_
#define _DOT_PRODUCT4_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#include "sum_across_float4.h"
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 * 	float _dot_product4(vector float v1, vector float v2)
 * 
 * DESCRIPTION
 * 	_dot_product4 computes the 4 component dot product of the two 
 *	input vectors -	v1 dot v2. The inputs v1 and v2 are 4 component
 *	vectors:
 *           _______________________________
 *          |___X___|___Y___|___Z___|___W___|
 *        
 *	result = v1.x * v2.x + v1.y * v2.y + v1.z * v2.z + v1.w * v2.w;
 */

static __inline float _dot_product4(vector float v1, vector float v2)
{
  vector float product;
#ifdef __SPU__
  product = spu_mul(v1, v2);
  return (_sum_across_float4(product));
#else
  union {
    float f[4];
    vector float fv;
  } result;
  vector float c2, c3, c4, c12, c34;

#ifdef __SPU__
  product = vec_madd(v1, v2, spu_splats((float)0.0));
#else /* !__SPU__ */
  product = vec_madd(v1, v2, ((vector float) {0.0,0.0,0.0,0.0}));
#endif /* __SPU__ */
  c2 = vec_splat(product, 1);
  c3 = vec_splat(product, 2);
  c4 = vec_splat(product, 3);

  c12 = vec_add(product,  c2);
  c34 = vec_add(c3, c4);

  result.fv = vec_add(c12, c34);
  return (result.f[0]);
#endif
}


#endif /* _DOT_PRODUCT4_H_ */




