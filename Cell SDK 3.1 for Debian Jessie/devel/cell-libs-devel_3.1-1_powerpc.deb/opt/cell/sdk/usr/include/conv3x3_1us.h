/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef _conv3x3_1us_h_
#define _conv3x3_1us_h_

#include <conv_defs.h>
#include <conv_shuf_us.h>

/* 
NAME
 	_conv3x3_1us - 3x3 convolution for one component unsigned short images

SYNOPSIS
	#include <conv3x3_1us.h>

	void _conv3x3_1us (const unsigned short *in[3], 
			   unsigned short *out, 
			   const vec_float4 m[9], int w)

DESCRIPTION
	Compute output pixels as the weighted sum of the input images's 
 	3x3 neighborhood and the filter mask 'm'.

	The image format is one component unsigned short.  The filter mask 
	'm' represents an arbitrary 3x3 kernel, where each entry has been 
	converted to 'float' and replicated to 'vec_float' form.

	Border pixels require a policy for defining values outside the
	image.  Three compile time options are supported.  The default 
	behaviour is to use _BORDER_COLOR_US (pre-defined to 0) for all 
	values beyond the left or right edges of the input image.  For
	values above or below the image, the caller is responsible for
	supplying scanlines cleared to the appropriate value.
	
	When _WRAP_CONV is defined, the input values are periodically 
	repeated --in other words, the input wraps from left to right 
	(and visa-versa).  The caller is responsible for managing the 
	input scanlines to support wrapping from top to bottom.

	When _CLAMP_CONV is defined, the input values are clamped to the 
	border --in other words, the right most value is repeated for 
	values beyond the right edge of the image; the left most value 
	is repeated for values beyond the left edge of the image.  The
	caller is responsible for managing the input scanlines to support
	clamping from top to bottom.

RESTRICTIONS
 	The input and output scanlines must be quad-word aligned.  The 
	scanline width 'w' must be a multiple of 8 pixels.  

 */
static __inline void _conv3x3_1us (const unsigned short *in[3], unsigned short *out, const vec_float4 m[9], int w)
{
  const vec_ushort8 *in0 = (const vec_ushort8 *)in[0];
  const vec_ushort8 *in1 = (const vec_ushort8 *)in[1];
  const vec_ushort8 *in2 = (const vec_ushort8 *)in[2];
  vec_ushort8 *vout = (vec_ushort8 *)out;
  vec_ushort8 p0, p1, p2;
  vec_ushort8 prev, curr, next;
  vec_ushort8 prevu, curru, nextu;
  vec_ushort8 left, right;
  vec_ushort8 leftu, rightu;
  vec_float4 left_hi, left_lo;
  vec_float4 leftu_hi, leftu_lo;
  vec_float4 curr_hi, curr_lo;
  vec_float4 curru_hi, curru_lo;
  vec_float4 right_hi, right_lo;
  vec_float4 rightu_hi, rightu_lo;
  vec_float4 res_hi, res_lo;
  vec_float4 resu_hi, resu_lo;
  vec_ushort8 res_hilo, resu_hilo;
  vec_float4 m00, m01, m02, m03, m04;
  vec_float4 m05, m06, m07, m08;
  int i0, i1, i2;

  m00 = m[0]; m01 = m[1]; m02 = m[2]; m03 = m[3]; m04 = m[4];
  m05 = m[5]; m06 = m[6]; m07 = m[7]; m08 = m[8];

#ifdef _WRAP_CONV
  p0 = in0[(w>>2)-1];
  p1 = in1[(w>>2)-1];
  p2 = in2[(w>>2)-1];
#elif defined(_CLAMP_CONV)
  p0 = in0[0];
  p1 = in1[0];
  p2 = in2[0];
#else
  p0 = _BORDER_COLOR_US;
  p1 = _BORDER_COLOR_US;
  p2 = _BORDER_COLOR_US;
#endif /* _WRAP_CONV */

#define _CONV3_1us(_m0, _m1, _m2)				\
  left = (vec_ushort8)vec_perm(prev, curr, left_shuf_1us);	\
  leftu = (vec_ushort8)vec_perm(prevu, curru, left_shuf_1us);	\
  right = (vec_ushort8)vec_perm(curr, next, right_shuf_1us);	\
  rightu = (vec_ushort8)vec_perm(curru, nextu, right_shuf_1us);	\
  _GET_PIXELS_1us(left);					\
  _GET_PIXELS_1us(leftu);					\
  _GET_PIXELS_1us(curr);					\
  _GET_PIXELS_1us(curru);					\
  _GET_PIXELS_1us(right);					\
  _GET_PIXELS_1us(rightu);					\
  _CONVERT_PIXELS_TO_FLOAT(left);				\
  _CONVERT_PIXELS_TO_FLOAT(leftu);				\
  _CONVERT_PIXELS_TO_FLOAT(curr);				\
  _CONVERT_PIXELS_TO_FLOAT(curru);				\
  _CONVERT_PIXELS_TO_FLOAT(right);				\
  _CONVERT_PIXELS_TO_FLOAT(rightu);				\
  _CALC_PIXELS_1us(left, _m0, res);				\
  _CALC_PIXELS_1us(leftu, _m0, resu);				\
  _CALC_PIXELS_1us(curr, _m1, res);				\
  _CALC_PIXELS_1us(curru, _m1, resu);				\
  _CALC_PIXELS_1us(right, _m2, res);				\
  _CALC_PIXELS_1us(rightu, _m2, resu)
  
  for (i0=0, i1=1, i2=2; i0<(w>>3)-2; i0+=2, i1+=2, i2+=2)
  {
#ifdef __SPU__
    res_hi = res_lo = spu_splats((float)0.0f);
    resu_hi = resu_lo = spu_splats((float)0.0f);
#else /* !__SPU__ */
    res_hi = res_lo = ((vector float) {0.0f,0.0f,0.0f,0.0f});
    resu_hi = resu_lo = ((vector float) {0.0f,0.0f,0.0f,0.0f});
#endif /* __SPU__ */

    _GET_SCANLINE_x2(p0, in0[i0], in0[i1], in0[i2]);
    _CONV3_1us(m00, m01, m02);

    _GET_SCANLINE_x2(p1, in1[i0], in1[i1], in1[i2]);
    _CONV3_1us(m03, m04, m05);

    _GET_SCANLINE_x2(p2, in2[i0], in2[i1], in2[i2]);
    _CONV3_1us(m06, m07, m08);

    _CONVERT_PIXELS_TO_USHORT(res);
    _CONVERT_PIXELS_TO_USHORT(resu);
    _PACK_PIXELS_1us(res);
    _PACK_PIXELS_1us(resu);
    vout[i0] = res_hilo;
    vout[i1] = resu_hilo;
  }
#ifdef __SPU__
  res_hi = res_lo = spu_splats((float)0.0f);
  resu_hi = resu_lo = spu_splats((float)0.0f);
#else /* !__SPU__ */
  res_hi = res_lo = ((vector float) {0.0f,0.0f,0.0f,0.0f});
  resu_hi = resu_lo = ((vector float) {0.0f,0.0f,0.0f,0.0f});
#endif /* __SPU__ */

#ifdef _WRAP_CONV
  _GET_SCANLINE_x2(p0, in0[i0], in0[i1], in0[0]);
  _CONV3_1us(m00, m01, m02);
 
  _GET_SCANLINE_x2(p1, in1[i0], in1[i1], in1[0]);
  _CONV3_1us(m03, m04, m05);
 
  _GET_SCANLINE_x2(p2, in2[i0], in2[i1], in2[0]);
  _CONV3_1us(m06, m07, m08);

#elif defined(_CLAMP_CONV)
  _GET_SCANLINE_x2(p0, in0[i0], in0[i1], in0[i1]);
  _CONV3_1us(m00, m01, m02);

  _GET_SCANLINE_x2(p1, in1[i0], in1[i1], in1[i1]);
  _CONV3_1us(m03, m04, m05);

  _GET_SCANLINE_x2(p2, in2[i0], in2[i1], in2[i1]);
  _CONV3_1us(m06, m07, m08);

#else
  _GET_SCANLINE_x2(p0, in0[i0], in0[i1], _BORDER_COLOR_US);
  _CONV3_1us(m00, m01, m02);
 
  _GET_SCANLINE_x2(p1, in1[i0], in1[i1], _BORDER_COLOR_US);
  _CONV3_1us(m03, m04, m05);
 
  _GET_SCANLINE_x2(p2, in2[i0], in2[i1], _BORDER_COLOR_US);
  _CONV3_1us(m06, m07, m08);

#endif /* _WRAP_CONV */

  _CONVERT_PIXELS_TO_USHORT(res);
  _CONVERT_PIXELS_TO_USHORT(resu);
  _PACK_PIXELS_1us(res);
  _PACK_PIXELS_1us(resu);
  vout[i0] = res_hilo;
  vout[i1] = resu_hilo;
}

#endif /* _con3x3_1us_h_ */
