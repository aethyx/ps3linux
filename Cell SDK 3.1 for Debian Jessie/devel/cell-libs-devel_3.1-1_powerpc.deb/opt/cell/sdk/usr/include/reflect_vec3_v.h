/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _REFLECT_VEC3_V_H_
#define _REFLECT_VEC3_V_H_	1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif

/*
 * FUNCTION
 * 	void _reflect_vec3_v(vector float *rx, vector float *ry, vector float *rz,
 *			     vector float  vx, vector float  vy, vector float  vz,
 *			     vector float  nx, vector float  ny, vector float  nz)
 * 
 * DESCRIPTION
 * 	_reflect_vec3_v computes 4 reflection vectors for normalized light 
 *	directions specified by vx, vy, vz reflecting off surfaces whose 
 *	normalized normals are nx, ny, nz. The resulting reflection vectors 
 *	are returned in rx, ry, and rz.
 *
 *	The reflection vector are computed as follows:
 *		r = v - 2(v dot n) * n
 */

static __inline void _reflect_vec3_v(vector float *rx, vector float *ry, vector float *rz, vector float vx, vector float vy, vector float vz, vector float nx, vector float ny, vector float nz)
{
  vector float dot;
  vector float nx2, ny2, nz2;
  
#ifdef __SPU__
  vector float two = spu_splats((float)2.0);

  dot = spu_mul(vx, nx);
  dot = spu_madd(vy, ny, dot);
  dot = spu_madd(vz, nz, dot);
  nx2 = spu_mul(two, nx);
  ny2 = spu_mul(two, ny);
  nz2 = spu_mul(two, nz);
  *rx = spu_nmsub(dot, nx2, vx);
  *ry = spu_nmsub(dot, ny2, vy);
  *rz = spu_nmsub(dot, nz2, vz);
#else
  vector float vzero = ((vector float) {0.0f,0.0f,0.0f,0.0f});
  vector float two = ((vector float) {2.0f,2.0f,2.0f,2.0f});

  dot = vec_madd(vx, nx, vzero);
  dot = vec_madd(vy, ny, dot);
  dot = vec_madd(vz, nz, dot);
  nx2 = vec_madd(two, nx, vzero);
  ny2 = vec_madd(two, ny, vzero);
  nz2 = vec_madd(two, nz, vzero);
  *rx = vec_nmsub(dot, nx2, vx);
  *ry = vec_nmsub(dot, ny2, vy);
  *rz = vec_nmsub(dot, nz2, vz);
#endif

}

#endif /* _REFLECT_VEC3_V_H_ */
