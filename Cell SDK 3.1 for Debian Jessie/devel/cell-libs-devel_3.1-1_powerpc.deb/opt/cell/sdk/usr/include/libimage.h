/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _libimage_h_
#define _libimage_h_

#ifdef __cplusplus
extern "C" {
#endif

#include <vec_types.h>

extern void conv3x3_1f (const float *in[3], float *out, const vec_float4 m[9], int w);
extern void conv3x3_1us (const unsigned short *in[3], unsigned short *out, const vec_float4 m[9], int w);
extern void conv3x3_4ub (const unsigned int *in[3], unsigned int *out, const vec_int4 m[9], int w, unsigned short scale, unsigned int shift);
extern void conv5x5_1f (const float *in[5], float *out, const vec_float4 m[25], int w);
extern void conv5x5_1us (const unsigned short *in[5], unsigned short *out, const vec_float4 m[25], int w);
extern void conv5x5_4ub (const unsigned int *in[5], unsigned int *out, const vec_int4 m[25], int w, unsigned short scale, unsigned int shift);
extern void conv7x7_1f (const float *in[7], float *out, const vec_float4 m[49], int w);
extern void conv7x7_1us (const unsigned short *in[7], unsigned short *out, const vec_float4 m[49], int w);
extern void conv7x7_4ub (const unsigned int *in[7], unsigned int *out, const vec_int4 m[49], int w, unsigned short scale, unsigned int shift);
extern void conv9x9_1f (const float *in[9], float *out, const vec_float4 m[81], int w);
extern void conv9x9_1us (const unsigned short *in[9], unsigned short *out, const vec_float4 m[81], int w);
extern void conv9x9_4ub (const unsigned int *in[9], unsigned int *out, const vec_int4 m[81], int w, unsigned short scale, unsigned int shift);

extern void histogram_ub(unsigned int *counts, unsigned char *data, int size);

#ifdef __cplusplus
}
#endif

#endif /* _libimage_h_ */
