/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef _conv_shuf_us_h_
#define _conv_shuf_us_h_

#include <vec_types.h>

/* Shuffle patterns for 'spreading' and 'packing' pixels to and
 * from vec_uint4 and vec_ushort8 form. 
 */

/* get left neighbor from vec_ushort8 */
static vec_uchar16 left_shuf_1us = (vec_uchar16) {
					       14, 15, 16, 17,
					       18, 19, 20, 21,
					       22, 23, 24, 25, 
					       26, 27, 28, 29};

/* get left2 neighbor from vec_ushort8 */
static vec_uchar16 left2_shuf_1us = (vec_uchar16) {
						12, 13, 14, 15,
						16, 17, 18, 19,
						20, 21, 22, 23,
						24, 25, 26, 27};

/* get left3 neighbor from vec_ushort8 */
static vec_uchar16 left3_shuf_1us = (vec_uchar16) {
						8,  9, 10, 11,
						12, 13, 14, 15,
						16, 17, 18, 19,
						20, 21, 22, 23};

/* get right neighbor from vec_ushort8 */
static vec_uchar16 right_shuf_1us = (vec_uchar16) {
						2,  3,  4,  5,  
						6,  7,  8,  9, 
						10, 11, 12, 13, 
						14, 15, 16, 17};

/* get right2 neighbor from vec_ushort8 */
static vec_uchar16 right2_shuf_1us = (vec_uchar16) {
						 4,  5,  6,  7,
						 8,  9, 10, 11,
						 12, 13, 14, 15,
						 16, 17, 18, 19};

/* get right3 neighbor from vec_ushort8 */
static vec_uchar16 right3_shuf_1us = (vec_uchar16) {
						 8,  9, 10, 11,
						 12, 13, 14, 15,
						 16, 17, 18, 19,
						 20, 21, 22, 23};

/* put hi 16 bytes from vec_ushort8 to vec_uint4 */
static vec_uchar16 hi_shuf =  (vec_uchar16) {
					  16, 17,  0,  1,
					  16, 17,  4,  5, 
					  16, 17,  8,  9,
					  16, 17, 12, 13};

/* put lo 16 bytes from vec_ushort8 to vec_uint4 */
static vec_uchar16 lo_shuf =  (vec_uchar16) {
					  16, 17,  2,  3,
					  16, 17,  6,  7, 
					  16, 17, 10, 11, 
					  16, 17, 14, 15};

/* pack clamped floats to vec_ushort8 */
static vec_uchar16 shuf_hilo =  (vec_uchar16) {
					    0,  1, 16, 17,
					    4,  5, 20, 21,
					    8,  9, 24, 25,
					    12, 13, 28, 29};

#endif /* _conv_shuf_us_h_ */
