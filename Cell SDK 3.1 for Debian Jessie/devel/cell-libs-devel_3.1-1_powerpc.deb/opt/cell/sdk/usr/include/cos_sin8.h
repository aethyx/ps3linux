/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2006,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _COS_SIN8_H_
#define _COS_SIN8_H_	1

#ifndef M_1_2PI
#define M_1_2PI		0.1591549430919f	/* 1/(2*pi) */ 
#endif /* M_1_2PI */

/*
 * FUNCTION
 *	float _cos_sin8(float angle)
 *
 * DESCRIPTION
 *	_cos_sin8 computes the cosine of "angle" (expressed in normalized 
 *      radians) to an accuracy of at least 8 bits for angle of 0.0 to 
 *	1.0. Angles outside this range are less accurate. Normalized 
 *	radians mean that an angle of 1.0 corresponds to 2*PI radians. 
 *      The cosine is computed using an 8 segment piecewise, quadratic  
 *      approximation over the interval [0, 1) normalized radians.
 *      The quadratic evaluation is of the form 
 *		A*x*x + B*x + C, 
 *	where x is the 1.0 plus the fractional input angle.
 */

/* Precomputed quadratic coefficients */
static float cos8_A[8] = {
  -18.00349, -7.457291,  7.457291, 18.00349,
   18.00349,  7.457291, -7.457291,-18.00349 };
static float cos8_B[8] = {
   35.91427, 12.05421, -25.23224, -54.10319,
  -53.91777,-19.51150,  32.68953,  72.10668 }; 
static float cos8_C[8] = {
  -16.91078, -3.41575,  19.88829,  39.64692,
   39.36879, 11.30717, -34.36873, -71.19939 };


static __inline float _cos_sin8(float angle)
{
  unsigned int idx;
  float work2, ab;
  union {
    float f;
    unsigned int ui;
  } frac, work1;
  
  work1.f = angle;
  work1.ui &= 0x7ffffffe; 
  work2 = (float)((int)(work1.f));	/* work2 = INT(work1) */
  frac.f = 1.0f + (work1.f - work2);	/* frac = 1.0 + FRAC(work1) */

  idx = (frac.ui >> 20) & 0x7;
  ab  = cos8_A[idx] * frac.f + cos8_B[idx];
  return (ab * frac.f + cos8_C[idx]);
}

#endif /* _COS_SIN8_H_ */
