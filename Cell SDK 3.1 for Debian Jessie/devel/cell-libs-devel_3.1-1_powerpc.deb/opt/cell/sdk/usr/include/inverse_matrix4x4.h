/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _INVERSE_MATRIX_4X4_H_
#define _INVERSE_MATRIX_4X4_H_		1

#ifdef __SPU__
#include <spu_intrinsics.h>
#else /* not __SPU__ */
#include <altivec.h>
#endif
#include <simdmath/recipf4.h>



/*
 * FUNCTION
 * 	int _inverse_matrix4x4(vector float *mOut, const vector float *mIn)
 * 
 * DESCRIPTION
 *	The _inverse_matrix4x4 generates the inverse of the input matrix
 *	pointed to by mIn and stores in the result in the matrix pointed
 *	to by mOut and zero is returned. The inverse is computed using 
 *	Kramer's rule and exploit SIMD to achieve significant performance
 *	improvements over simple scalar code.
 *
 *	If the matrix is determined to be singular, the inverse is not
 *	computed and a non-zero value is returned. 
 */


static __inline int _inverse_matrix4x4(vector float *mOut, const vector float *mIn)
{
#ifdef __SPU__
  vector float in0, in1, in2, in3;
  vector float result0, result1, result2, result3;
  vector float tmp0, tmp1, tmp2, tmp3;
  vector float cof0, cof1, cof2, cof3;
  vector float t0, t1, t2, t3;
  vector float t01, t02, t03, t12, t23;
  vector float t1r, t2r;
  vector float t01r, t02r, t03r, t12r, t23r;
  vector float t1r3, t1r3r;
  vector float det, det1, det2, det3, invdet;
  vector unsigned char shuffle0426 = ((vector unsigned char) {
						 0x00, 0x01, 0x02, 0x03,
						 0x10, 0x11, 0x12, 0x13,
						 0x08, 0x09, 0x0A, 0x0B,
						 0x18, 0x19, 0x1A, 0x1B});
  vector unsigned char shuffle0145 = ((vector unsigned char) {
						 0x00, 0x01, 0x02, 0x03,
						 0x04, 0x05, 0x06, 0x07,
						 0x10, 0x11, 0x12, 0x13,
						 0x14, 0x15, 0x16, 0x17});
  vector unsigned char shuffle1032 = ((vector unsigned char) {
						 0x04, 0x05, 0x06, 0x07,
						 0x00, 0x01, 0x02, 0x03,
						 0x0C, 0x0D, 0x0E, 0x0F,
						 0x08, 0x09, 0x0A, 0x0B});
  vector unsigned char shuffle1537, shuffle2367;

  in0 = *(mIn+0);
  in1 = *(mIn+1);
  in2 = *(mIn+2);
  in3 = *(mIn+3);

  /* Perform transform of the input matrix of the form:
   *	A B C D
   *    E F G H
   *    I J K L
   *    M N O P
   *
   * The pseudo transpose of the input matrix is trans:
   *	A E I M
   *	J N B F
   *	C G K O
   *	L P D H
   */
  shuffle1537 = spu_or(shuffle0426, 0x4);
  shuffle2367 = spu_or(shuffle0145, 0x8);

  tmp0 = spu_shuffle(in0, in1, shuffle0426);	/* A E C G */
  tmp1 = spu_shuffle(in2, in3, shuffle0426);	/* I M K O */
  tmp2 = spu_shuffle(in0, in1, shuffle1537);	/* B F D H */
  tmp3 = spu_shuffle(in2, in3, shuffle1537);	/* J N L P */

  t0 = spu_shuffle(tmp0, tmp1, shuffle0145);	/* A E I M */
  t1 = spu_shuffle(tmp3, tmp2, shuffle0145);	/* J N B F */
  t2 = spu_shuffle(tmp0, tmp1, shuffle2367);	/* C G K O */
  t3 = spu_shuffle(tmp3, tmp2, shuffle2367);	/* L P D H */

  /* Generate a cofactor matrix. The computed cofactors reside in
   * cof0, cof1, cof2, cof3.
   */
  t23 = spu_mul(t2, t3);			/* CL GP KD OH */
  t23 = spu_shuffle(t23, t23, shuffle1032);	/* GP CL OH KD */
  cof0 = spu_mul(t1, t23);			/* JGP NCL BOH FKD */
  cof1 = spu_mul(t0, t23);			/* AGP ECL IOH MKD */
  t23r = spu_rlqwbyte(t23, 8);			/* OH KD GP CL */
  cof0 = spu_msub(t1, t23r, cof0);		/* JOH NKD BGP FCL  - cof0 */
  cof1 = spu_msub(t0, t23r, cof1);		/* AOH EKD IGP MCL  - cof1 */
  cof1 = spu_rlqwbyte(cof1, 8);			/* IGP MCL AOH EKD - IOH MKD AGP ECL */

  t12 = spu_mul(t1, t2);			/* JC NG BK FO */
  t12 = spu_shuffle(t12, t12, shuffle1032);	/* NG JC FO BK */
  cof0 = spu_madd(t3, t12, cof0);		/* LNG PJC DFO HBK + cof0 */
  cof3 = spu_mul(t0, t12);			/* ANG EJC IFO MBK */
  t12r = spu_rlqwbyte(t12, 8);			/* FO BK NG JC */
  cof0 = spu_nmsub(t3, t12r, cof0);		/* cof0 - LFO PBK DNG HJC */
  cof3 = spu_msub(t0, t12r, cof3);		/* AFO EBK ING MJC - cof3 */
  cof3 = spu_rlqwbyte(cof3, 8);			/* ING MJC AFO EBK - IFO MBK ANG EJC */

  t1r = spu_rlqwbyte(t1, 8);			/* B F J N */
  t2r = spu_rlqwbyte(t2, 8);			/* K O C G */
  t1r3 = spu_mul(t1r, t3);			/* BL FP JD NH */
  t1r3 = spu_shuffle(t1r3, t1r3, shuffle1032);	/* FP BL NH JD */
  cof0 = spu_madd(t2r, t1r3, cof0);		/* KFP OBL CNH GJD + cof0 */
  cof2 = spu_mul(t0, t1r3);			/* AFP EBL INH MJD */
  t1r3r = spu_rlqwbyte(t1r3, 8);		/* NH JD FP BL */
  cof0 = spu_nmsub(t2r, t1r3r, cof0);		/* cof0 - KNH OJD CFP GBL*/
  cof2 = spu_msub(t0, t1r3r, cof2);		/* ANH EJD IFP MBL - cof2 */
  cof2 = spu_rlqwbyte(cof2, 8);			/* IFP MBL ANH EJD - INH MJD AFP EBL */

  t01 = spu_mul(t0, t1);				/* AJ EN IB MF */
  t01 = spu_shuffle(t01, t01, shuffle1032);	/* EN AJ MF IB */
  cof2 = spu_madd(t3, t01, cof2);		/* LEN PAJ DMF HIB + cof2 */
  cof3 = spu_msub(t2r, t01, cof3);		/* KEN OAJ CMF GIB - cof3 */ 
  t01r = spu_rlqwbyte(t01, 8);			/* MF IB EN AJ */
  cof2 = spu_msub(t3, t01r, cof2);		/* LMF PIB DEN HAJ - cof2 */
  cof3 = spu_nmsub(t2r, t01r, cof3);		/* cof3 - KMF OIB CEN GAJ */

  t03 = spu_mul(t0, t3);				/* AL EP ID MH */
  t03 = spu_shuffle(t03, t03, shuffle1032);	/* EP AL MH ID */
  cof1 = spu_nmsub(t2r, t03, cof1);		/* cof1 - KEP OAL CMH GID */
  cof2 = spu_madd(t1, t03, cof2);		/* JEP NAL BMH FID + cof2 */
  t03r = spu_rlqwbyte(t03, 8);			/* MH ID EP AL */
  cof1 = spu_madd(t2r, t03r, cof1);		/* KMH OID CEP GAL + cof1 */
  cof2 = spu_nmsub(t1, t03r, cof2);		/* cof2 - JMH NID BEP FAL */ 

  t02 = spu_mul(t0, t2r);			/* AK EO IC MG */
  t02 = spu_shuffle(t02, t02, shuffle1032);	/* E0 AK MG IC */
  cof1 = spu_madd(t3, t02, cof1);		/* LEO PAK DMG HIC + cof1 */
  cof3 = spu_nmsub(t1, t02, cof3);		/* cof3 - JEO NAK BMG FIC */
  t02r = spu_rlqwbyte(t02, 8);			/* MG IC EO AK */
  cof1 = spu_nmsub(t3, t02r, cof1);		/* cof1 - LMG PIC DEO HAK */
  cof3 = spu_madd(t1, t02r, cof3);		/* JMG NIC BEO FAK + cof3 */

  /* Compute the determinant of the matrix 
   *
   * det = sum_across(t0 * cof0);
   *
   * We perform a sum across the entire vector so that 
   * we don't have to splat the result when multiplying the
   * cofactors by the inverse of the determinant.
   */
  det  = spu_mul(t0, cof0);
  det1 = spu_rlqwbyte(det, 4);
  det2 = spu_rlqwbyte(det, 8);
  det3 = spu_rlqwbyte(det, 12);
  det  = spu_add(det, det1);
  det2 = spu_add(det2, det3);
  det  = spu_add(det, det2);

  if (spu_extract(det, 0) == 0.0) return 1;

  /* Compute the reciprocal of the determinant.
   */
  invdet = _recipf4(det);

  /* Multiply the cofactors by the reciprocal of the determinant.
   */ 
  result0 = spu_mul(cof0, invdet);
  result1 = spu_mul(cof1, invdet);
  result2 = spu_mul(cof2, invdet);
  result3 = spu_mul(cof3, invdet);

  *(mOut+0) = result0;
  *(mOut+1) = result1;
  *(mOut+2) = result2;
  *(mOut+3) = result3;

#else
  vector float in0, in1, in2, in3;
  vector float result0, result1, result2, result3;
  vector float tmp0, tmp1, tmp2, tmp3;
  vector float cof0, cof1, cof2, cof3;
  vector float t0, t1, t2, t3;
  vector float t01, t02, t03, t12, t23;
  vector float t1r, t2r;
  vector float t01r, t02r, t03r, t12r, t23r;
  vector float t1r3, t1r3r;
  vector float det, det0, det1, det2, det3, invdet;
  vector unsigned char shuffle0426 = ((vector unsigned char) {
						 0x00, 0x01, 0x02, 0x03,
						 0x10, 0x11, 0x12, 0x13,
						 0x08, 0x09, 0x0A, 0x0B,
						 0x18, 0x19, 0x1A, 0x1B});
  vector unsigned char shuffle0145 = ((vector unsigned char) {
						 0x00, 0x01, 0x02, 0x03,
						 0x04, 0x05, 0x06, 0x07,
						 0x10, 0x11, 0x12, 0x13,
						 0x14, 0x15, 0x16, 0x17});
  vector unsigned char shuffle1032 = ((vector unsigned char) {
						 0x04, 0x05, 0x06, 0x07,
						 0x00, 0x01, 0x02, 0x03,
						 0x0C, 0x0D, 0x0E, 0x0F,
						 0x08, 0x09, 0x0A, 0x0B});
  vector unsigned char shuffle1537, shuffle2367;
  vector float vzero = ((vector float) {0.0,0.0,0.0,0.0});

  in0 = *(mIn+0);
  in1 = *(mIn+1);
  in2 = *(mIn+2);
  in3 = *(mIn+3);

  /* Perform transform of the input matrix of the form:
   *	A B C D
   *    E F G H
   *    I J K L
   *    M N O P
   *
   * The pseudo transpose of the input matrix is trans:
   *	A E I M
   *	J N B F
   *	C G K O
   *	L P D H
   */
  shuffle1537 = vec_or(shuffle0426, ((vector unsigned char) {0x4,0x4,0x4,0x4,0x4,0x4,0x4,0x4,0x4,0x4,0x4,0x4,0x4,0x4,0x4,0x4}));
  shuffle2367 = vec_or(shuffle0145, ((vector unsigned char) {0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8}));

  tmp0 = vec_perm(in0, in1, shuffle0426);	/* A E C G */
  tmp1 = vec_perm(in2, in3, shuffle0426);	/* I M K O */
  tmp2 = vec_perm(in0, in1, shuffle1537);	/* B F D H */
  tmp3 = vec_perm(in2, in3, shuffle1537);	/* J N L P */

  t0 = vec_perm(tmp0, tmp1, shuffle0145);	/* A E I M */
  t1 = vec_perm(tmp3, tmp2, shuffle0145);	/* J N B F */
  t2 = vec_perm(tmp0, tmp1, shuffle2367);	/* C G K O */
  t3 = vec_perm(tmp3, tmp2, shuffle2367);	/* L P D H */

  /* Generate a cofactor matrix. The computed cofactors reside in
   * cof0, cof1, cof2, cof3.
   */
  t23 = vec_madd(t2, t3, vzero);		/* CL GP KD OH */
  t23 = vec_perm(t23, t23, shuffle1032);	/* GP CL OH KD */
  cof0 = vec_nmsub(t1, t23, vzero);		/* -(JGP NCL FOH BKD) */
  cof1 = vec_nmsub(t0, t23, vzero);		/* -(AGP ECL IOH MKD) */
  t23r = vec_sld(t23, t23, 8);			/* OH KD GP CL */
  cof0 = vec_madd(t1, t23r, cof0);		/* JOH NKD BGP FCL + cof0 */
  cof1 = vec_madd(t0, t23r, cof1);		/* AOH EKD IGP MCL + cof1 */
  cof1 = vec_sld(cof1, cof1, 8);		/* IGP MCL AOH EKD - IOH MKD AGP ECL */

  t12 = vec_madd(t1, t2, vzero);		/* JC NG BK FO */
  t12 = vec_perm(t12, t12, shuffle1032);	/* NG JC FO BK */
  cof0 = vec_madd(t3, t12, cof0);		/* LNG PJC DFO HBK + cof0 */
  cof3 = vec_madd(t0, t12, vzero);		/* ANG EJC IFO MBK */
  t12r = vec_sld(t12, t12, 8);			/* FO BK NG JC */
  cof0 = vec_nmsub(t3, t12r, cof0);		/* cof0 - LFO PBK DNG HJC */
  cof3 = vec_nmsub(t0, t12r, cof3);		/* cof3 - AFO EBK ING MJC */
  cof3 = vec_sld(cof3, cof3, 8);		/* ING MJC AFO EBK - IFO MBK ANG EJC */

  t1r = vec_sld(t1, t1, 8);			/* B F J N */
  t2r = vec_sld(t2, t2, 8);			/* K O C G */
  t1r3 = vec_madd(t1r, t3, vzero);		/* BL FP JD NH */
  t1r3 = vec_perm(t1r3, t1r3, shuffle1032);	/* FP BL NH JD */
  cof0 = vec_madd(t2r, t1r3, cof0);		/* KFP OBL CNH GJD + cof0 */
  cof2 = vec_madd(t0, t1r3, vzero);		/* AFP EBL INH MJD */
  t1r3r = vec_sld(t1r3, t1r3, 8);		/* NH JD FP BL */
  cof0 = vec_nmsub(t2r, t1r3r, cof0);		/* cof0 - KNH OJD CFP GBL */
  cof2 = vec_nmsub(t0, t1r3r, cof2);		/* cof2 - ANH EJD IFP MBL */
  cof2 = vec_sld(cof2, cof2, 8);		/* IFP MBL ANH EJD - INH MJD AFP EBL */

  t01 = vec_madd(t0, t1, vzero);		/* AJ EN IB MF */
  t01 = vec_perm(t01, t01, shuffle1032);	/* EN AJ MF IB */
  cof2 = vec_nmsub(t3, t01, cof2);		/* cof2 - LEN PAJ DMF HIB */
  cof3 = vec_madd(t2r, t01, cof3);		/* KEN OAJ CMF GIB + cof3 */ 
  t01r = vec_sld(t01, t01, 8);			/* MF IB EN AJ */
  cof2 = vec_madd(t3, t01r, cof2);		/* LMF PIB DEN HAJ + cof2 */
  cof3 = vec_nmsub(t2r, t01r, cof3);		/* cof3 - KMF OIB CEN GAJ */

  t03 = vec_madd(t0, t3, vzero);		/* AL EP ID MH */
  t03 = vec_perm(t03, t03, shuffle1032);	/* EP AL MH ID */
  cof1 = vec_nmsub(t2r, t03, cof1);		/* cof1 - KEP OAL CMH GID */
  cof2 = vec_madd(t1, t03, cof2);		/* JEP NAL BMH FID + cof2 */
  t03r = vec_sld(t03, t03, 8);			/* MH ID EP AL */
  cof1 = vec_madd(t2r, t03r, cof1);		/* KMH OID CEP GAL + cof1 */
  cof2 = vec_nmsub(t1, t03r, cof2);		/* cof2 - JMH NID BEP FAL */ 

  t02 = vec_madd(t0, t2r, vzero);		/* AK EO IC MG */
  t02 = vec_perm(t02, t02, shuffle1032);	/* E0 AK MG IC */
  cof1 = vec_madd(t3, t02, cof1);		/* LEO PAK DMG HIC + cof1 */
  cof3 = vec_nmsub(t1, t02, cof3);		/* cof3 - JEO NAK BMG FIC */
  t02r = vec_sld(t02, t02, 8);			/* MG IC EO AK */
  cof1 = vec_nmsub(t3, t02r, cof1);		/* cof1 - LMG PIC DEO HAK */
  cof3 = vec_madd(t1, t02r, cof3);		/* JMG NIC BEO FAK + cof3 */

  /* Compute the determinant of the matrix 
   *
   * det = sum_across(t0 * cof0);
   *
   * We perform a sum across the entire vector so that 
   * we don't have to splat the result when multiplying the
   * cofactors by the inverse of the determinant.
   */
  det  = vec_madd(t0, cof0, vzero);
  det0 = vec_splat(det, 0);
  det1 = vec_splat(det, 1);
  det2 = vec_splat(det, 2);
  det3 = vec_splat(det, 3);

  det  = vec_add(det0, det1);
  det2 = vec_add(det2, det3);
  det  = vec_add(det, det2);

  if (vec_all_eq(det, vzero)) return 1;

  /* Compute the reciprocal of the determinant.
   */
  invdet = _recipf4(det);

  /* Multiply the cofactors by the reciprocal of the determinant.
   */ 
  result0 = vec_madd(cof0, invdet, vzero);
  result1 = vec_madd(cof1, invdet, vzero);
  result2 = vec_madd(cof2, invdet, vzero);
  result3 = vec_madd(cof3, invdet, vzero);

  *(mOut+0) = result0;
  *(mOut+1) = result1;
  *(mOut+2) = result2;
  *(mOut+3) = result3;
#endif

  return (0);
}

#endif /* _INVERSE_MATRIX_4X4_H_ */
