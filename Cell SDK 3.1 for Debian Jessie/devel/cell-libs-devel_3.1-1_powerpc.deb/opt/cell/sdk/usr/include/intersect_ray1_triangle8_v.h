/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _intersect_ray1_triangle8_v_h_
#define _intersect_ray1_triangle8_v_h_


#ifdef __SPU__
#include <spu_intrinsics.h>
#include <simdmath/recipf4_fast.h>
#else /* not __SPU__ */
#include <altivec.h>
#include <simdmath/recipf4.h>
#endif

#include "dot_product3_v.h"

/* function:    _intersect_ray1_triangle8_v 
 *
 * parameters:
 *   vector float h[8],                    // accumulated hit records
 *   vector float rox, roy, roz,           // ray origin, SoA form
 *   vector float rdx, rdy, rdz,           // ray direction, SoA form
 *   vector float p0x[2], p0y[2], p0z[2],  // triangle p0, SoA form
 *   vector float p1x[2], p1y[2], p1z[2],  // triangle p1, SoA form
 *   vector float p2x[2], p2y[2], p2z[2],  // triangle p2, SoA form
 *   vector float id[2]                    // triangle ids
 *
 * Determine if a ray intersects a set of 8 triangles.  If so, 
 * return each triangle's paramaterized (u, v) intersection 
 * coordinates.
 *
 * The 8 hit records must ultimately be merged to determine the 
 * nearest intersection for the ray.  This merge step can be 
 * performed after all of the ray-triangle intersections are 
 * complete.
 *
 * See also:
 *
 *   Ray Tracing on Programmable Graphics Hardware
 *   Purcell, Buck, Mark, Hanrahan
 *   Proceedings of ACM SIGGRAPH, 2002
 */

static __inline void _intersect_ray1_triangle8_v (vector float h[8], vector float rox, vector float roy, vector float roz, vector float rdx, vector float rdy, vector float rdz, const vector float p0x[2], const vector float p0y[2], const vector float p0z[2], const vector float p1x[2], const vector float p1y[2], const vector float p1z[2], const vector float p2x[2], const vector float p2y[2], const vector float p2z[2], const vector float id[2])
{
  vector float _vzero = ((vector float) {0.0f,0.0f,0.0f,0.0f});
  vector float _vone = ((vector float) {1.0f,1.0f,1.0f,1.0f});
  vector float edge1x, edge2x;
  vector float edge1y, edge2y;
  vector float edge1z, edge2z;
  vector float edge1xu, edge2xu;
  vector float edge1yu, edge2yu;
  vector float edge1zu, edge2zu;
  vector float pvecx, tvecx, qvecx;
  vector float pvecy, tvecy, qvecy;
  vector float pvecz, tvecz, qvecz;
  vector float pvecxu, tvecxu, qvecxu;
  vector float pvecyu, tvecyu, qvecyu;
  vector float pveczu, tveczu, qveczu;
  vector float det, inv_det;
  vector float detu, inv_detu;
  vector float u, v, t;
  vector float uu, vu, tu;
  vector unsigned int u_ge_0, v_ge_0;
  vector unsigned int u_ge_0u, v_ge_0u;
  vector unsigned int uv_le_1;
  vector unsigned int uv_le_1u;
  vector unsigned int t_lt_h0;
  vector unsigned int t_lt_h0u;
  vector unsigned int t_ge_0;
  vector unsigned int t_ge_0u;
  vector unsigned int vha, vhb;
  vector unsigned int vhau, vhbu;
  vector unsigned int validhit;
  vector unsigned int validhitu;
  vector float h0, h1, h2, h3;
  vector float h0u, h1u, h2u, h3u;

  h0 = h[0];
  h1 = h[1];
  h2 = h[2];
  h3 = h[3];

  h0u = h[4];
  h1u = h[5];
  h2u = h[6];
  h3u = h[7];

#ifdef __SPU__

  edge1x = spu_sub (p1x[0], p0x[0]);
  edge1xu = spu_sub (p1x[1], p0x[1]);

  edge1y = spu_sub (p1y[0], p0y[0]);
  edge1yu = spu_sub (p1y[1], p0y[1]);

  edge1z = spu_sub (p1z[0], p0z[0]);
  edge1zu = spu_sub (p1z[1], p0z[1]);

  edge2x = spu_sub (p2x[0], p0x[0]);
  edge2xu = spu_sub (p2x[1], p0x[1]);

  edge2y = spu_sub (p2y[0], p0y[0]);
  edge2yu = spu_sub (p2y[1], p0y[1]);

  edge2z = spu_sub (p2z[0], p0z[0]);
  edge2zu = spu_sub (p2z[1], p0z[1]);

  /* pvec = rd CROSS edge2 
   * pvecu = rd CROSS edge2u 
   */
  pvecx = spu_nmsub(rdz, edge2y, spu_mul(rdy, edge2z));
  pvecy = spu_nmsub(rdx, edge2z, spu_mul(rdz, edge2x));
  pvecz = spu_nmsub(rdy, edge2x, spu_mul(rdx, edge2y));

  pvecxu = spu_nmsub(rdz, edge2yu, spu_mul(rdy, edge2zu));
  pvecyu = spu_nmsub(rdx, edge2zu, spu_mul(rdz, edge2xu));
  pveczu = spu_nmsub(rdy, edge2xu, spu_mul(rdx, edge2yu));

  det = _dot_product3_v (edge1x, edge1y, edge1z, pvecx, pvecy, pvecz);
  detu = _dot_product3_v (edge1xu, edge1yu, edge1zu, pvecxu, pvecyu, pveczu);

  inv_det = _recipf4_fast(det);
  inv_detu = _recipf4_fast(detu);

  tvecx = spu_sub (rox, p0x[0]);
  tvecxu = spu_sub (rox, p0x[1]);

  tvecy = spu_sub (roy, p0y[0]);
  tvecyu = spu_sub (roy, p0y[1]);

  tvecz = spu_sub (roz, p0z[0]);
  tveczu = spu_sub (roz, p0z[1]);

  u = spu_mul (_dot_product3_v (tvecx, tvecy, tvecz, pvecx, pvecy, pvecz), inv_det);
  uu = spu_mul (_dot_product3_v (tvecxu, tvecyu, tveczu, pvecxu, pvecyu, pveczu), inv_detu);

  /* qvec = tvec CROSS edge1 
   * qvecu = tvecu CROSS edge1u 
   */
  qvecx = spu_nmsub(tvecz, edge1y, spu_mul(tvecy, edge1z));
  qvecy = spu_nmsub(tvecx, edge1z, spu_mul(tvecz, edge1x));
  qvecz = spu_nmsub(tvecy, edge1x, spu_mul(tvecx, edge1y));

  qvecxu = spu_nmsub(tveczu, edge1yu, spu_mul(tvecyu, edge1zu));
  qvecyu = spu_nmsub(tvecxu, edge1zu, spu_mul(tveczu, edge1xu));
  qveczu = spu_nmsub(tvecyu, edge1xu, spu_mul(tvecxu, edge1yu));

  v = spu_mul (_dot_product3_v (rdx, rdy, rdz, qvecx, qvecy, qvecz), inv_det);
  vu = spu_mul (_dot_product3_v (rdx, rdy, rdz, qvecxu, qvecyu, qveczu), inv_detu);

  t = spu_mul (_dot_product3_v (edge2x, edge2y, edge2z, qvecx, qvecy, qvecz), inv_det);
  tu = spu_mul (_dot_product3_v (edge2xu, edge2yu, edge2zu, qvecxu, qvecyu, qveczu), inv_detu);

  u_ge_0  = (vector unsigned int)spu_xor(spu_cmpgt (_vzero, u), -1);
  u_ge_0u  = (vector unsigned int)spu_xor(spu_cmpgt (_vzero, uu), -1);

  v_ge_0  = (vector unsigned int)spu_xor(spu_cmpgt (_vzero, v), -1);
  v_ge_0u  = (vector unsigned int)spu_xor(spu_cmpgt (_vzero, vu), -1);

  uv_le_1 = (vector unsigned int)spu_xor(spu_cmpgt (spu_add(u, v), _vone), -1);
  uv_le_1u = (vector unsigned int)spu_xor(spu_cmpgt (spu_add(uu, vu), _vone), -1);

  t_lt_h0 = (vector unsigned int)spu_cmpgt (h0, t);
  t_lt_h0u = (vector unsigned int)spu_cmpgt (h0u, tu);

  t_ge_0  = (vector unsigned int)spu_xor(spu_cmpgt (_vzero, t), -1);
  t_ge_0u  = (vector unsigned int)spu_xor(spu_cmpgt (_vzero, tu), -1);

  vha = spu_and (u_ge_0, v_ge_0);
  vhau = spu_and (u_ge_0u, v_ge_0u);

  vhb = spu_and (uv_le_1, t_lt_h0);
  vhbu = spu_and (uv_le_1u, t_lt_h0u);

  validhit = spu_and (spu_and (vha, vhb), t_ge_0);
  validhitu = spu_and (spu_and (vhau, vhbu), t_ge_0u);

  h[0] = spu_sel (h0, t, validhit);
  h[1] = spu_sel (h1, u, validhit);
  h[2] = spu_sel (h2, v, validhit);
  h[3] = spu_sel (h3, id[0], validhit);

  h[4] = spu_sel (h0u, tu, validhitu);
  h[5] = spu_sel (h1u, uu, validhitu);
  h[6] = spu_sel (h2u, vu, validhitu);
  h[7] = spu_sel (h3u, id[1], validhitu);

#else /* !__SPU__ */

  edge1x = vec_sub (p1x[0], p0x[0]);
  edge1xu = vec_sub (p1x[1], p0x[1]);

  edge1y = vec_sub (p1y[0], p0y[0]);
  edge1yu = vec_sub (p1y[1], p0y[1]);

  edge1z = vec_sub (p1z[0], p0z[0]);
  edge1zu = vec_sub (p1z[1], p0z[1]);

  edge2x = vec_sub (p2x[0], p0x[0]);
  edge2xu = vec_sub (p2x[1], p0x[1]);

  edge2y = vec_sub (p2y[0], p0y[0]);
  edge2yu = vec_sub (p2y[1], p0y[1]);

  edge2z = vec_sub (p2z[0], p0z[0]);
  edge2zu = vec_sub (p2z[1], p0z[1]);

  /* pvec = rd CROSS edge2 
   * pvecu = rd CROSS edge2u 
   */
  pvecx = vec_nmsub(rdz, edge2y, vec_madd(rdy, edge2z, _vzero));
  pvecy = vec_nmsub(rdx, edge2z, vec_madd(rdz, edge2x, _vzero));
  pvecz = vec_nmsub(rdy, edge2x, vec_madd(rdx, edge2y, _vzero));

  pvecxu = vec_nmsub(rdz, edge2yu, vec_madd(rdy, edge2zu, _vzero));
  pvecyu = vec_nmsub(rdx, edge2zu, vec_madd(rdz, edge2xu, _vzero));
  pveczu = vec_nmsub(rdy, edge2xu, vec_madd(rdx, edge2yu, _vzero));

  det = _dot_product3_v (edge1x, edge1y, edge1z, pvecx, pvecy, pvecz);
  detu = _dot_product3_v (edge1xu, edge1yu, edge1zu, pvecxu, pvecyu, pveczu);

  inv_det = _recipf4(det);
  inv_detu = _recipf4(detu);

  tvecx = vec_sub (rox, p0x[0]);
  tvecxu = vec_sub (rox, p0x[1]);

  tvecy = vec_sub (roy, p0y[0]);
  tvecyu = vec_sub (roy, p0y[1]);

  tvecz = vec_sub (roz, p0z[0]);
  tveczu = vec_sub (roz, p0z[1]);

  u = vec_madd (_dot_product3_v (tvecx, tvecy, tvecz, pvecx, pvecy, pvecz), inv_det, _vzero);
  uu = vec_madd (_dot_product3_v (tvecxu, tvecyu, tveczu, pvecxu, pvecyu, pveczu), inv_detu, _vzero);

  /* qvec = tvec CROSS edge1 
   * qvecu = tvecu CROSS edge1u 
   */
  qvecx = vec_nmsub(tvecz, edge1y, vec_madd(tvecy, edge1z, _vzero));
  qvecy = vec_nmsub(tvecx, edge1z, vec_madd(tvecz, edge1x, _vzero));
  qvecz = vec_nmsub(tvecy, edge1x, vec_madd(tvecx, edge1y, _vzero));

  qvecxu = vec_nmsub(tveczu, edge1yu, vec_madd(tvecyu, edge1zu, _vzero));
  qvecyu = vec_nmsub(tvecxu, edge1zu, vec_madd(tveczu, edge1xu, _vzero));
  qveczu = vec_nmsub(tvecyu, edge1xu, vec_madd(tvecxu, edge1yu, _vzero));

  v = vec_madd (_dot_product3_v (rdx, rdy, rdz, qvecx, qvecy, qvecz), inv_det, _vzero);
  vu = vec_madd (_dot_product3_v (rdx, rdy, rdz, qvecxu, qvecyu, qveczu), inv_detu, _vzero);

  t = vec_madd (_dot_product3_v (edge2x, edge2y, edge2z, qvecx, qvecy, qvecz), inv_det, _vzero);
  tu = vec_madd (_dot_product3_v (edge2xu, edge2yu, edge2zu, qvecxu, qvecyu, qveczu), inv_detu, _vzero);

  u_ge_0  = (vector unsigned int)vec_cmpge (u, _vzero);
  u_ge_0u  = (vector unsigned int)vec_cmpge (uu, _vzero);

  v_ge_0  = (vector unsigned int)vec_cmpge (v, _vzero);
  v_ge_0u  = (vector unsigned int)vec_cmpge (vu, _vzero);

  uv_le_1 = (vector unsigned int)vec_cmple (vec_add(u, v), _vone);
  uv_le_1u = (vector unsigned int)vec_cmple (vec_add(uu, vu), _vone);

  t_lt_h0 = (vector unsigned int)vec_cmplt (t, h0);
  t_lt_h0u = (vector unsigned int)vec_cmplt (tu, h0u);

  t_ge_0  = (vector unsigned int)vec_cmpge (t, _vzero);
  t_ge_0u  = (vector unsigned int)vec_cmpge (tu, _vzero);

  vha = vec_and (u_ge_0, v_ge_0);
  vhau = vec_and (u_ge_0u, v_ge_0u);

  vhb = vec_and (uv_le_1, t_lt_h0);
  vhbu = vec_and (uv_le_1u, t_lt_h0u);

  validhit = vec_and (vec_and (vha, vhb), t_ge_0);
  validhitu = vec_and (vec_and (vhau, vhbu), t_ge_0u);

  h[0] = vec_sel (h0, t, validhit);
  h[1] = vec_sel (h1, u, validhit);
  h[2] = vec_sel (h2, v, validhit);
  h[3] = vec_sel (h3, id[0], validhit);

  h[4] = vec_sel (h0u, tu, validhitu);
  h[5] = vec_sel (h1u, uu, validhitu);
  h[6] = vec_sel (h2u, vu, validhitu);
  h[7] = vec_sel (h3u, id[1], validhitu);
#endif /* __SPU__ */

}

#endif /* _intersect_ray1_triangle8_v_h_ */
