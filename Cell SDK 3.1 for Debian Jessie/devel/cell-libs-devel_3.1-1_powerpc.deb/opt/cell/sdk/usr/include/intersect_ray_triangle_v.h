/* --------------------------------------------------------------  */
/* (C)Copyright 2001,2007,                                         */
/* International Business Machines Corporation,                    */
/* Sony Computer Entertainment, Incorporated,                      */
/* Toshiba Corporation,                                            */
/*                                                                 */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */
#ifndef _intersect_ray_triangle_v_h_
#define _intersect_ray_triangle_v_h_

#ifdef __SPU__
#include <spu_intrinsics.h>
#include <simdmath/recipf4_fast.h>
#else /* not __SPU__ */
#include <altivec.h>
#include <simdmath/recipf4.h>
#endif

#include "dot_product3_v.h"


/* function:    _intersect_ray_triangle_v 
 *		_intersect_ray1_triangle4_v
 *		_intersect_ray4_triangle1_v
 *
 * parameters:
 *   vector float h[4],                 // accumulated hit record
 *   vector float rox, roy, roz,        // ray origin, SoA form
 *   vector float rdx, rdy, rdz,        // ray direction, SoA form
 *   vector float p0x, p0y, p0z,        // triangle p0, SoA form
 *   vector float p1x, p1y, p1z,        // triangle p1, SoA form
 *   vector float p2x, p2y, p2z,        // triangle p2, SoA form
 *   vector float id                    // triangle id
 *
 * Use SoA form to determine if ray(s) intersect with triangle(s).  
 * If so, return the triangle's paramaterized (u, v) intersection 
 * coordinates in the accumulated hit record.
 *
 * This function can be used in two different ways.  The first
 * intersects 1 ray against 4 triangles.  In this case the 4 hit
 * records must ultimately be merged to determine the nearest
 * ray-triangle intersection.  This merge step can be performed
 * after all of the ray-triangle intersections are complete.  
 *
 * The second usage intersects 4 rays against 1 triangle.  Again,
 * 4 hit records are accumulated, 1 for each ray.  Since the rays
 * are independent, it is not necessary to merge the hit records.
 *
 * See also:
 *
 *   Ray Tracing on Programmable Graphics Hardware
 *   Purcell, Buck, Mark, Hanrahan
 *   Proceedings of ACM SIGGRAPH, 2002
 */

#define _intersect_ray1_triangle4_v	_intersect_ray_triangle_v
#define _intersect_ray4_triangle1_v	_intersect_ray_triangle_v


static __inline void _intersect_ray_triangle_v (vector float h[4], vector float rox, vector float roy, vector float roz, vector float rdx, vector float rdy, vector float rdz, vector float p0x, vector float p0y, vector float p0z, vector float p1x, vector float p1y, vector float p1z, vector float p2x, vector float p2y, vector float p2z, vector float id)
{
  vector float _vzero = ((vector float) {0.0f,0.0f,0.0f,0.0f});
  vector float _vone = ((vector float) {1.0f,1.0f,1.0f,1.0f});
  vector float edge1x, edge2x;
  vector float edge1y, edge2y;
  vector float edge1z, edge2z;
  vector float pvecx, tvecx, qvecx;
  vector float pvecy, tvecy, qvecy;
  vector float pvecz, tvecz, qvecz;
  vector float det, inv_det;
  vector float u, v, t;
  vector unsigned int u_ge_0, v_ge_0;
  vector unsigned int uv_le_1;
  vector unsigned int t_lt_h0;
  vector unsigned int t_ge_0;
  vector unsigned int vha, vhb, validhit;
  vector float h0, h1, h2, h3;

  h0 = h[0];
  h1 = h[1];
  h2 = h[2];
  h3 = h[3];

#ifdef __SPU__

  edge1x = spu_sub (p1x, p0x);
  edge1y = spu_sub (p1y, p0y);
  edge1z = spu_sub (p1z, p0z);

  edge2x = spu_sub (p2x, p0x);
  edge2y = spu_sub (p2y, p0y);
  edge2z = spu_sub (p2z, p0z);

  /* pvec = rdx CROSS edge2 */
  pvecx = spu_nmsub(rdz, edge2y, spu_mul(rdy, edge2z));
  pvecy = spu_nmsub(rdx, edge2z, spu_mul(rdz, edge2x));
  pvecz = spu_nmsub(rdy, edge2x, spu_mul(rdx, edge2y));

  det = _dot_product3_v (edge1x, edge1y, edge1z, pvecx, pvecy, pvecz);

  inv_det = _recipf4_fast(det);

  tvecx = spu_sub (rox, p0x);
  tvecy = spu_sub (roy, p0y);
  tvecz = spu_sub (roz, p0z);

  u = spu_mul (_dot_product3_v (tvecx, tvecy, tvecz, pvecx, pvecy, pvecz), inv_det);

  /* qvec = tvec CROSS edge1 */
  qvecx = spu_nmsub(tvecz, edge1y, spu_mul(tvecy, edge1z));
  qvecy = spu_nmsub(tvecx, edge1z, spu_mul(tvecz, edge1x));
  qvecz = spu_nmsub(tvecy, edge1x, spu_mul(tvecx, edge1y));

  v = spu_mul (_dot_product3_v (rdx, rdy, rdz, qvecx, qvecy, qvecz), inv_det);
  t = spu_mul (_dot_product3_v (edge2x, edge2y, edge2z, qvecx, qvecy, qvecz), inv_det);

  u_ge_0  = (vector unsigned int)spu_xor(spu_cmpgt (_vzero, u), -1);
  v_ge_0  = (vector unsigned int)spu_xor(spu_cmpgt (_vzero, v), -1);
  uv_le_1 = (vector unsigned int)spu_xor(spu_cmpgt(spu_add(u, v), _vone), -1);
  t_lt_h0 = (vector unsigned int)spu_cmpgt (h0, t);
  t_ge_0  = (vector unsigned int)spu_xor(spu_cmpgt (_vzero, t), -1);

  vha = spu_and (u_ge_0, v_ge_0);
  vhb = spu_and (uv_le_1, t_lt_h0);
  validhit = spu_and (spu_and (vha, vhb), t_ge_0);

  h[0] = spu_sel (h0, t, validhit);
  h[1] = spu_sel (h1, u, validhit);
  h[2] = spu_sel (h2, v, validhit);
  h[3] = spu_sel (h3, id, validhit);

#else

  edge1x = vec_sub (p1x, p0x);
  edge1y = vec_sub (p1y, p0y);
  edge1z = vec_sub (p1z, p0z);

  edge2x = vec_sub (p2x, p0x);
  edge2y = vec_sub (p2y, p0y);
  edge2z = vec_sub (p2z, p0z);

  /* pvec = rdx CROSS edge2 */
  pvecx = vec_nmsub(rdz, edge2y, vec_madd(rdy, edge2z, _vzero));
  pvecy = vec_nmsub(rdx, edge2z, vec_madd(rdz, edge2x, _vzero));
  pvecz = vec_nmsub(rdy, edge2x, vec_madd(rdx, edge2y, _vzero));

  det = _dot_product3_v (edge1x, edge1y, edge1z, pvecx, pvecy, pvecz);
  inv_det = _recipf4(det);

  tvecx = vec_sub (rox, p0x);
  tvecy = vec_sub (roy, p0y);
  tvecz = vec_sub (roz, p0z);

  u = vec_madd (_dot_product3_v (tvecx, tvecy, tvecz, pvecx, pvecy, pvecz), inv_det, _vzero);

  /* qvec = tvec CROSS edge1 */
  qvecx = vec_nmsub(tvecz, edge1y, vec_madd(tvecy, edge1z, _vzero));
  qvecy = vec_nmsub(tvecx, edge1z, vec_madd(tvecz, edge1x, _vzero));
  qvecz = vec_nmsub(tvecy, edge1x, vec_madd(tvecx, edge1y, _vzero));

  v = vec_madd (_dot_product3_v (rdx, rdy, rdz, qvecx, qvecy, qvecz), inv_det, _vzero);
  t = vec_madd (_dot_product3_v (edge2x, edge2y, edge2z, qvecx, qvecy, qvecz), inv_det, _vzero);

  u_ge_0  = (vector unsigned int)vec_cmpge (u, _vzero);
  v_ge_0  = (vector unsigned int)vec_cmpge (v, _vzero);
  uv_le_1 = (vector unsigned int)vec_cmple (vec_add(u, v), _vone);
  t_lt_h0 = (vector unsigned int)vec_cmplt (t, h0);
  t_ge_0  = (vector unsigned int)vec_cmpge (t, _vzero);

  vha = vec_and (u_ge_0, v_ge_0);
  vhb = vec_and (uv_le_1, t_lt_h0);
  validhit = vec_and (vec_and (vha, vhb), t_ge_0);

  h[0] = vec_sel (h0, t, validhit);
  h[1] = vec_sel (h1, u, validhit);
  h[2] = vec_sel (h2, v, validhit);
  h[3] = vec_sel (h3, id, validhit);
#endif
}

#endif /* _intersect_ray_triangle_v_h_ */
