/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2008       All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

#ifndef HEADER_RSA_H
#define HEADER_RSA_H

#ifdef __cplusplus
extern "C" {
#endif

#define RSA_PUBLIC_KEY 1
#define RSA_PRIVATE_KEY 2

struct rsa_key_st {
	vector unsigned int *n;			/* public modulus
									   size: m quadwords */
	vector unsigned int *e;			/* public exponent
									   size: m quadwords */
	vector unsigned int *d;			/* private exponent
									   size: m quadwords */
	vector unsigned int *p;			/* secret prime factor
									   size: m/2 quadwords */
	vector unsigned int *q;			/* secret prime factor
									   size: m/2 quadwords */
	vector unsigned int *dmp1;		/* d mod (p-1)
									   size: m/2 quadwords */
	vector unsigned int *dmq1;		/* d mod (q-1)
									   size: m/2 quadwords */
	vector unsigned int *iqmp;		/* q^-1 mod p
									   size: m/2 quadwords */
	vector unsigned int *internal[8];
} __attribute__ ((aligned(16)));
typedef struct rsa_key_st RSA;

/*
 * The RSA structure is a fixed size, but contains pointers to a buffer area
 * that contains variable length values, depending on the type and size of key.
 * Use RSA_buffer_size to calculate the number of bytes (aligned on a quadword
 * boundary) that are needed to store the values associated with a particular type
 * and size of key.
 */
extern int RSA_buffer_size(int type, int bits);

/*
 * Associate a memory buffer with the RSA structure to hold the key values. The
 * size of the buffer must be at least RSA_buffer_size(type,bits) bytes and
 * quadword aligned, e.g.,
 *     vector unsigned char buffer[RSA_buffer_size(type,bits)/sizeof(vector unsigned char)
 * or
 *     unsigned char buffer[RSA_buffer_size(type,bits)] __attribute__ ((aligned(16)))
 * buffer_size is the size of the buffer in bytes.
 */
extern int RSA_buffer(RSA *rsa, void *buffer, int buffer_size);

/*
 * Return the modulus size in bytes. The answer can be used to determine how much
 * memory must be allocated for a value to be encrypted using this RSA key.
 */
extern int RSA_size(const RSA *rsa);

/*
 * Parse the DER representation of an RSA key. Returns 0 if success and -1 if failure.
 * The caller must have previously associated a buffer with the RSA structure by
 * calling RSA_buffer. The buffer must be large enough to hold the key being read (see
 * RSA_buffer_size(type,bits)).
 * 
 * If successful, the pointer to the buffer and size (remaining bytes in the buffer)
 * are updated to point to the byte immediately following the DER representation of
 * the key.
 * 
 * DER_read_RSAPublicKey is similar to the following code:
 *      { RSA *result;
 *        result = d2i_RSA_PUBKEY(rsa,buffer,(long)*buffer_size);
 *        if (result == NULL)
 *            result = d2i_RSAPublicKey(rsa,buffer,(long)*buffer_size);
 *        result;
 *      }
 * It will thus read an RSA Public Key in either
 *    SubjectPublicKeyInfo (certificate public key) format
 * or
 *    PKCS #1 RSAPublicKey format.
 * 
 * DER_read_RSA_PrivateKey is similar to the OPENSSL interface of d2i_RSAPrivateKey
 * and will read an RSA Private Key in PKCS #1 RSAPrivateKey format.
 */
extern int DER_read_RSAPublicKey(RSA *rsa, unsigned char **buffer, int *buffer_size);
extern int DER_read_RSAPrivateKey(RSA *rsa, unsigned char **buffer, int *buffer_size);

/*
 * DER_write_RSAPublicKey writes the RSA key in PKCS #1 RSAPublicKey format.
 * DER_write_RSAPrivateKey writes the RSA key in PKCS #1 RSAPrivateKey format. The
 * RSA key must contain a private key.
 */
extern int DER_write_RSAPublicKey(RSA *rsa, unsigned char **buffer, int *buffer_size);
extern int DER_write_RSAPrivateKey(RSA *rsa, unsigned char **buffer, int *buffer_size);

/*
 * Encrypt/decrypt. The RSA key structure must have been initialized using RSA_buffer and the
 * the key value created/read.
 * 
 * The only allowed value for padding is RSA_NO_PADDING.
 */
#define RSA_NO_PADDING		3
extern int RSA_public_encrypt(int flen, unsigned char *from, unsigned char *to, RSA *rsa, int padding);
extern int RSA_private_decrypt(int flen, unsigned char *from, unsigned char *to, RSA *rsa, int padding);
extern int RSA_private_encrypt(int flen, unsigned char *from, unsigned char *to, RSA *rsa, int padding);
extern int RSA_public_decrypt(int flen, unsigned char *from, unsigned char *to, RSA *rsa, int padding);

extern int is_prime(vector unsigned int *m, int size, int confidence, vector unsigned int *search);

#ifdef __cplusplus
}
#endif

#endif /* HEADER_RSA_H */
