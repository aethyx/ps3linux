/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2008       All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

#ifndef HEADER_MD5_H
#define HEADER_MD5_H

#ifdef __cplusplus
extern "C" {
#endif

#define MD5_DIGEST_LENGTH 16

struct hash_md5_st {
	unsigned char internal[96] __attribute__ ((aligned(16)));
};
typedef struct hash_md5_st MD5_CTX;

extern int MD5_Init(MD5_CTX *c);

extern unsigned char *MD5(const unsigned char *data, size_t n, unsigned char *md);
extern int MD5_Update(MD5_CTX *c, const void *data, size_t len);
extern unsigned char *MD5_fast(const vector unsigned char *data, size_t n, unsigned char *md);
extern int MD5_Update_fast(MD5_CTX *c, const vector unsigned char *data, size_t len);

extern int MD5_Final(unsigned char *md, const MD5_CTX *c);

#ifdef __cplusplus
}
#endif

#endif /* HEADER_MD5_H */
