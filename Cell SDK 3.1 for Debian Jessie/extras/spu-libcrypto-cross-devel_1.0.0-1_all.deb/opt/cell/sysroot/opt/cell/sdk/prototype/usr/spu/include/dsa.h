/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2008       All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

#ifndef HEADER_DSA_H
#define HEADER_DSA_H

#include "sha.h"

#ifdef __cplusplus
extern "C" {
#endif

#define DSA_PUBLIC_KEY 1
#define DSA_PRIVATE_KEY 2

struct dsa_key_st {
	vector unsigned int p[9];			/* prime number (public) */
	vector unsigned int q[2];			/* 160-bit subprime (public) */
	vector unsigned int g[9];			/* generator of subgroup (public) */
	vector unsigned int priv_key[2];	/* private key x */
	vector unsigned int pub_key[9];		/* public key y = g ^ x */
	vector unsigned int internal;
} __attribute__ ((aligned(16)));
typedef struct dsa_key_st DSA;

/*
 * Return the size of an ASN.1 encoded DSA signature in bytes. This is the size
 * of buffer that must be allocated for the result of DSA_sign.
 */
extern int DSA_size(const DSA *dsa);

/*
 * Parse the DER representation of an DSA key. Returns 0 if success and -1 if failure.
 * The caller must have previously associated a buffer with the DSA structure by
 * calling DSA_buffer. The buffer must be large enough to hold the key being read (see
 * DSA_buffer_size(type,bits)).
 * 
 * If successful, the pointer to the buffer and size (remaining bytes in the buffer)
 * are updated to point to the byte immediately following the DER representation of
 * the key.
 * 
 * DER_read_DSAPublicKey is similar to the following code:
 *      { DSA *result;
 *        result = d2i_DSA_PUBKEY(dsa,buffer,(long)*buffer_size);
 *        if (result == NULL)
 *            result = d2i_DSAPublicKey(dsa,buffer,(long)*buffer_size);
 *        result;
 *      }
 * It will thus read an DSA Public Key in either
 *    SubjectPublicKeyInfo (certificate public key) format
 * or
 *    DSAPublicKey format.
 * 
 * DER_read_DSA_PrivateKey is similar to the OPENSSL interface of d2i_DSAPrivateKey
 * and will read an DSA Private Key in DSAPrivateKey format.
 */
extern int DER_read_DSAPublicKey(DSA *dsa, unsigned char **buffer, int *buffer_size);
extern int DER_read_DSAPrivateKey(DSA *dsa, unsigned char **buffer, int *buffer_size);

/*
 * DER_write_DSAPublicKey writes the DSA key in DSAPublicKey format.
 * DER_write_DSAPrivateKey writes the DSA key in DSAPrivateKey format. The
 * DSA key must contain a private key.
 */
extern int DER_write_DSAPublicKey(DSA *dsa, unsigned char **buffer, int *buffer_size);
extern int DER_write_DSAPrivateKey(DSA *dsa, unsigned char **buffer, int *buffer_size);

/*
 * DSA_sign computes the digital signature on the len byte message digest, dgst,
 * using the private key, dsa, and writes the result, as an ASN.1 encoding of
 * the signature, to the buffer, sigret. The length of the signature is returned
 * in siglen. the buffer, sigret, must be at least DSA_size(dsa) bytes.
 * 
 * The first parameter, type, is ignored.
 * 
 * For this implementation, the size of the digest, len, must be 20 bytes
 * (length of a SHA1 hash).
 */
extern int DSA_sign(int type, const unsigned char *dgst, int len,
		unsigned char *sigret, unsigned int *siglen, DSA *dsa);
/*
 * DSA_verify reads the ASN.1 encoding of the signature and verifies against the
 * message digest, dgst, using the public key from dsa. The signature is siglen
 * bytes in length.
 * 
 * The first parameter, type, is ignored.
 * 
 * For this implementation, the size of the digest, len, must be 20 bytes
 * (length of a SHA1 hash).
 */
extern int DSA_verify(int type, const unsigned char *dgst, int len,
		unsigned char *sigbuf, int siglen, DSA *dsa);

#ifdef __cplusplus
}
#endif

#endif /* HEADER_DSA_H */
