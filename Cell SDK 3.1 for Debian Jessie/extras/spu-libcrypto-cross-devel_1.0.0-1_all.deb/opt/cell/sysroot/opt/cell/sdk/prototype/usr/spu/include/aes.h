/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2008       All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

#ifndef HEADER_AES_H
#define HEADER_AES_H

#define AES_ENCRYPT 1
#define AES_DECRYPT 0

#define AES_MAXNR 14
#define AES_BLOCK_SIZE 16

#ifdef __cplusplus
extern "C" {
#endif

struct aes_key_st {
	unsigned char internal[AES_BLOCK_SIZE*(AES_MAXNR+2)] __attribute__ ((aligned (16)));
};
typedef struct aes_key_st AES_KEY;

/* return codes:
 * 	 0 - normal
 * 	-1 - userkey or key is NULL
 * 	-2 - bits is not one of 128, 192, or 256
 */
#define AES_set_decrypt_key(userKey,bits,key) AES_set_encrypt_key((userKey),(bits),(key))
extern int AES_set_encrypt_key(const unsigned char *userKey, const int bits,
	AES_KEY *key);
extern int AES_set_encrypt_key_fast(const vector unsigned char *userKey,
	const int bits, AES_KEY *key);
#define AES_set_decrypt_key_fast(userKey,bits,key) AES_set_encrypt_key_fast((userKey),(bits),(key))

/* encrypt/decrypt a single block (AES_BLOCK_SIZE bytes). in and out can overlap */
#define AES_encrypt(in,out,key) AES_ecb_encrypt((in),(out),(key),AES_ENCRYPT)
#define AES_decrypt(in,out,key) AES_ecb_encrypt((in),(out),(key),AES_DECRYPT)

/* encrypt/decrypt a single block (AES_BLOCK_SIZE bytes), in and out can overlap */
/* Equivalent to AES_encrypt or AES_decrypt */
extern void AES_ecb_encrypt(const unsigned char *in, unsigned char *out,
		const AES_KEY *key, const int enc);
/* encrypt/decrypt length bytes (must be multiple of AES_BLOCK_SIZE bytes). */
extern void AES_ecb_encrypt_fast(const vector unsigned char *in,
	vector unsigned char *out, const unsigned long length,
	const AES_KEY *key, const int enc);

/* encrypt/decrypt length bytes (must be multiple of AES_BLOCK_SIZE bytes),
 * in and out can overlap
 */
extern void AES_cbc_encrypt(const unsigned char *in, unsigned char *out,
	const unsigned long length, const AES_KEY *key, unsigned char *ivec,
	const int enc);
extern void AES_cbc_encrypt_fast(const vector unsigned char *in,
	vector unsigned char *out, const unsigned long length,
	const AES_KEY *key, vector unsigned char *ivec, const int enc);

/* encrypt/decrypt length bytes (must be multiple of AES_BLOCK_SIZE bytes),
 * in and out can overlap
 */
extern void AES_ctr_encrypt(const unsigned char *in, unsigned char *out,
	const unsigned long length, const AES_KEY *key, unsigned char *ctr,
	const int enc);
extern void AES_ctr_encrypt_fast(const vector unsigned char *in,
	vector unsigned char *out, const unsigned long length,
	const AES_KEY *key, vector unsigned char *ctr, const int enc);

/*
 * Helper functions based on AES encrypt/decrypt. These are used by the key
 * generation process for DSA and RSA keys, and SHOULD be replaced by user
 * supplied functions for secure applications.
 *
 * The random number algorithms utilize the 128-bit key and a 128-bit time
 * value.
 *
 * The key can be from the content of some memory locations or registers
 * that change frequently, No history about this key should be kept anywhere. 
 * The key should be erased immediately after it is used. 
 *
 * The time has no specific domain, but must be an ever increasing value.
 */
extern vector unsigned char fetch_aes_rand_key();
extern vector unsigned char fetch_aes_rand_time();

/* set the seed for AES random number generation */
extern void aes_srand(vector unsigned char seed);
/* generate a random number of with size quadwords */
extern void aes_rand(vector unsigned char *r, int size);

extern int aes_prime_rand(vector unsigned char *r, int size, int confidence, vector unsigned int msb, vector unsigned int mask);

#ifdef __cplusplus
}
#endif

#endif /* HEADER_AES_H */
