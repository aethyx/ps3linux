/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2008       All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

#ifndef HEADER_SHA_H
#define HEADER_SHA_H

#ifdef __cplusplus
extern "C" {
#endif

#define SHA_DIGEST_LENGTH 20

struct hash_sha_st {
	unsigned char internal[112] __attribute__ ((aligned(16)));
};
typedef struct hash_sha_st SHA_CTX;

extern int SHA1_Init(SHA_CTX *c);

extern unsigned char *SHA1(const unsigned char *data, size_t n, unsigned char *md);
extern int SHA1_Update(SHA_CTX *c, const void *data, size_t len);
extern unsigned char *SHA1_fast(const vector unsigned char *data, size_t n, unsigned char *md);
extern int SHA1_Update_fast(SHA_CTX *c, const vector unsigned char *data, size_t len);

extern int SHA1_Final(unsigned char *md, const SHA_CTX *c);


#define SHA256_DIGEST_LENGTH 32

struct hash_sha256_st {
	unsigned char internal[112] __attribute__ ((aligned(16)));
};
typedef struct hash_sha256_st SHA256_CTX;

extern int SHA256_Init(SHA256_CTX *c);

extern unsigned char *SHA256(const unsigned char *data, size_t n, unsigned char *md);
extern int SHA256_Update(SHA256_CTX *c, const void *data, size_t len);
extern unsigned char *SHA256_fast(const vector unsigned char *data, size_t n, unsigned char *md);
extern int SHA256_Update_fast(SHA256_CTX *c, const vector unsigned char *data, size_t len);

extern int SHA256_Final(unsigned char *md, const SHA256_CTX *c);

#ifdef __cplusplus
}
#endif

#endif /* HEADER_SHA_H */
