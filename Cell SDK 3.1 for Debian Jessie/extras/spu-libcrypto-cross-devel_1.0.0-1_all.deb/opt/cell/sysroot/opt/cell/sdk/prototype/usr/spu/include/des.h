/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2008       All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

#ifndef HEADER_DES_H
#define HEADER_DES_H

#define DES_ENCRYPT 1
#define DES_DECRYPT 0

#define DES_BLOCK_SIZE 8

#ifdef __cplusplus
extern "C" {
#endif

typedef unsigned char DES_cblock[8];
typedef DES_cblock const_DES_cblock;

struct des_key_st {
	unsigned char internal[1024] __attribute__ ((aligned (16)));
};
typedef struct des_key_st DES_key_schedule;

#define DES_KEY_SCHEDULE_SZ (sizeof(DES_cblock))
#define DES_SCHEDULE_SZ (sizeof(DES_key_schedule))

#define DES_ENCRYPT	1
#define DES_DECRYPT	0

#define DES_CBC_MODE	0

#define DES_set_key(key,schedule) { DES_set_key_unchecked((key),(schedule)); 0; }
#define DES_key_sched(key,schedule) { DES_set_key_unchecked((key),(schedule)); 0; }
#define DES_set_key_checked(key,schedule) { DES_set_key_unchecked((key),(schedule)); 0; }
extern void DES_set_key_unchecked(const_DES_cblock *key, DES_key_schedule *schedule);
extern void DES_set_key_unchecked_fast(unsigned long long key, DES_key_schedule *schedule);

/* encrypt/decrypt a single block (DES_BLOCK_SIZE bytes), in and out can overlap */
extern void DES_ecb_encrypt(const unsigned char *in, unsigned char *out,
	const DES_key_schedule *schedule, const int enc);
#define DES_ecb2_encrypt(in,out,schedule1,schedule2,enc) DES_ecb3_encrypt((in),(out),(schedule1),(schedule2),(schedule1),(enc))
extern void DES_ecb3_encrypt(const unsigned char *in, unsigned char *out,
	const DES_key_schedule *schedule1, const DES_key_schedule *schedule2,
	const DES_key_schedule *schedule3, const int enc);
/* encrypt/decrypt lenght bytes (must be multiple of DES_BLOCK_SIZE bytes). */
extern void DES_ecb_encrypt_fast(const vector unsigned char *in,
	vector unsigned char *out, const unsigned long length,
	const DES_key_schedule *schedule, const int enc);
extern void DES_ecb3_encrypt_fast(const vector unsigned char *in,
	vector unsigned char *out, const unsigned long length,
	const DES_key_schedule *schedule1, const DES_key_schedule *schedule2,
	const DES_key_schedule *schedule3, const int enc);

/* encrypt/decrypt length bytes (must be multiple of DES_BLOCK_SIZE bytes),
 * in and out can overlap
 */
/* DES_cbc_encrypt does not update the IV!  Use DES_ncbc_encrypt instead. */
extern void DES_cbc_encrypt(const unsigned char *in, unsigned char *out,
	const unsigned long length, const DES_key_schedule *schedule, unsigned char *ivec,
	const int enc);
extern void DES_ncbc_encrypt(const unsigned char *in, unsigned char *out,
	const unsigned long length, const DES_key_schedule *schedule, unsigned char *ivec,
	const int enc);
#define DES_ede2_cbc_encrypt(in,out,length,schedule1,schedule2,ivec,enc) DES_ede3_cbc_encrypt((in),(out),(length),(schedule1),(schedule2),(schedule3),(ivec),(enc))
extern void DES_ede3_cbc_encrypt(const unsigned char *in, unsigned char *out,
	const unsigned long length, const DES_key_schedule *schedule1,
	const DES_key_schedule *schedule2, const DES_key_schedule *schedule3,
	unsigned char *ivec, const int enc);
extern void DES_cbc_encrypt_fast(const vector unsigned char *in,
	vector unsigned char *out, const unsigned long length,
	const DES_key_schedule *schedule, unsigned long long *ivec, const int enc);
extern void DES_ncbc_encrypt_fast(const vector unsigned char *in,
	vector unsigned char *out, const unsigned long length,
	const DES_key_schedule *schedule, unsigned long long *ivec, const int enc);
extern void DES_ede3_cbc_encrypt_fast(const vector unsigned char *in,
	vector unsigned char *out, const unsigned long length,
	const DES_key_schedule *schedule1, const DES_key_schedule *schedule2,
	const DES_key_schedule *schedule3, unsigned long long *ivec, const int enc);

#ifdef __cplusplus
}
#endif

#endif /* HEADER_DES_H */
