/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2008       All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */
#ifndef _LIB_FFT3D_H_
#define _LIB_FFT3D_H_	1

/*
 * Input Data Formats
 *   This version only supports complex tiled data.
 */
#define FFT_TILED               0x008

/* 
 * Return Codes
 */
#define FFT_RC_SUCCESS        0     /* Call succeeded */
#define FFT_RC_NO_SPUS       -1     /* Insufficient accelerators (spus) are available */
#define FFT_RC_BAD_DIMENSION -2     /* Invalid size of input 3d array */
#define FFT_RC_BAD_PARM      -3     /* Invalid input parameter */
#define FFT_RC_FAILED        -4     /* Generic internal error occured */


/*
 * Dimension limits
 */
#define FFT_3D_MIN_DIM_X_SP  16
#define FFT_3D_MIN_DIM_Y_SP  16
#define FFT_3D_MIN_DIM_Z_SP  16
#define FFT_3D_MAX_DIM_X_SP  2048
#define FFT_3D_MAX_DIM_Y_SP  2048
#define FFT_3D_MAX_DIM_Z_SP  512

#define FFT_3D_MIN_DIM_X_DP  16
#define FFT_3D_MIN_DIM_Y_DP  16
#define FFT_3D_MIN_DIM_Z_DP  16
#define FFT_3D_MAX_DIM_X_DP  1024
#define FFT_3D_MAX_DIM_Y_DP  1024
#define FFT_3D_MAX_DIM_Z_DP  1024

/*
 * Data Structures
 */
typedef void *fft_3d_handle_t;

/*
 * Single Precision Interface
 */
int fft_3d_sp_initialize(fft_3d_handle_t *handle, 
        unsigned int nspus);

int fft_3d_sp_perform(fft_3d_handle_t handle, 
        void *src_addr, 
        unsigned int dim_x, 
        unsigned int dim_y, 
        unsigned int dim_z, 
        unsigned int inverse_flag, 
        unsigned int format_flag);

int fft_3d_sp_terminate(fft_3d_handle_t handle);

/*
 * Double Precision Interface
 */
int fft_3d_dp_initialize(fft_3d_handle_t *handle, 
        unsigned int nspus);

int fft_3d_dp_perform(fft_3d_handle_t handle, 
        void *src_addr, 
        unsigned int dim_x, 
        unsigned int dim_y, 
        unsigned int dim_z, 
        unsigned int inverse_flag, 
        unsigned int format_flag);

int fft_3d_dp_terminate(fft_3d_handle_t handle);

#endif /* _LIB_FFT3D_H_ */
