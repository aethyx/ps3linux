/* --------------------------------------------------------------- */
/* (C) Copyright 2006,2008,                                        */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* THIS PROGRAM IS PROVIDED UNDER THE TERMS OF THE COMMON PUBLIC   */
/* LICENSE VERSION 1 ("AGREEMENT"). ANY USE, REPRODUCTION OR       */
/* DISTRIBUTION OF THE PROGRAM CONSTITUTES RECIPIENT'S ACCEPTANCE  */
/* OF THIS AGREEMENT.                                              */
/*                                                                 */
/* A copy of the Agreement accompanies this distribution, or see   */
/* <http://www.ibm.com/developerworks/library/os-cpl.html>.        */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

/*********************************************************************
*                                                                    *
* Read the existing SPE ELF executable                               *
*                                                                    *
*********************************************************************/

#include <stddef.h>		 // NULL, other ANSI-C types
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

#include "buildSecureApp.h"

INLINE void* aligned_ptr(void* value)
{
	long x;
	long rem;
	x = (long) value;
	rem = x % 8;
	if (rem != 0) {
		x += 8 - rem;
	}
	return (void*) x;
}

int readElf(int fd, Elf** elf, MyElf32_Ehdr* myEhdr, MyElf32_Phdr*** myPhdr, MyElf32_Shdr*** myShdr)
{
	Elf32_Ehdr*		ehdr;
	Elf*			localElf;
	int				elfErrno;
	MyElf32_Shdr**	localMyShdr;
	MyElf32_Phdr**	localMyPhdr;
	Elf32_Phdr*		phdr;
	int				rc = 0;
	Elf_Scn*		scn;
	int				scnCount;
	Elf32_Shdr*		shdr;
	size_t			strndx;

	*elf = NULL;
	memset(myEhdr,0,sizeof(MyElf32_Ehdr));
	*myPhdr = NULL;
	*myShdr = NULL;

	/* Now start processing the ELF header */
	elf_version(EV_CURRENT);
	if ((localElf=elf_begin(fd,ELF_C_READ,NULL)) == NULL) {
		elfErrno = elf_errno();
		PRINTF(("Failure: elf_begin returned %d (0x%X).\n",elfErrno,elfErrno));
		PRINTF(("%s\n",elf_errmsg(elfErrno)));
		rc = -201;
		goto err01;
	}

	/* Make sure we process only ELF executables */
	if (elf_kind(localElf) != ELF_K_ELF) {
		PRINTF(("Failure: file is not an ELF executable.\n"));
		rc = -202;
		goto err02;
	}

	/* Process the ELF header */
	if ((ehdr=elf32_getehdr(localElf)) == NULL) {
		elfErrno = elf_errno();
		PRINTF(("Failure: elf32_getehdr returned %d (0x%X).\n",elfErrno,elfErrno));
		PRINTF(("%s\n",elf_errmsg(elfErrno)));
		rc = -203;
		goto err02;
	}
	if ((ehdr->e_ident[EI_MAG0] != ELFMAG0) ||
		(ehdr->e_ident[EI_MAG1] != ELFMAG1) ||
		(ehdr->e_ident[EI_MAG2] != ELFMAG2) ||
		(ehdr->e_ident[EI_MAG3] != ELFMAG3) ||
		(ehdr->e_ident[EI_CLASS] != ELFCLASS32) ||
		(ehdr->e_ident[EI_DATA] != ELFDATA2MSB) ||
		(ehdr->e_ident[EI_VERSION] != EV_CURRENT) ||
		(ehdr->e_type != ET_EXEC) ||
		(ehdr->e_machine != EM_CELLSPU) ||  /* CELL SPU */
		(ehdr->e_version != EV_CURRENT) ||
		(ehdr->e_flags != NONE)) {
		PRINTF(("Failure: File is not a supported SPE executable.\n"));
#if defined(DEBUG)
		if (ehdr->e_ident[EI_MAG0] != ELFMAG0)
			DEBUGP(("Failure: ehdr->e_ident[EI_MAG0] (0x%s) != ELFMAG0.\n",hexchars[ehdr->e_ident[EI_MAG0]]));
		if (ehdr->e_ident[EI_MAG1] != ELFMAG1)
			DEBUGP(("Failure: ehdr->e_ident[EI_MAG1] (0x%s) != ELFMAG1.\n",hexchars[ehdr->e_ident[EI_MAG1]]));
		if (ehdr->e_ident[EI_MAG2] != ELFMAG2)
			DEBUGP(("Failure: ehdr->e_ident[EI_MAG2] (0x%s) != ELFMAG2.\n",hexchars[ehdr->e_ident[EI_MAG2]]));
		if (ehdr->e_ident[EI_MAG3] != ELFMAG3)
			DEBUGP(("Failure: ehdr->e_ident[EI_MAG3] (0x%s) != ELFMAG3.\n",hexchars[ehdr->e_ident[EI_MAG3]]));
		if (ehdr->e_ident[EI_CLASS] != ELFCLASS32)
			DEBUGP(("Failure: ehdr->e_ident[EI_CLASS] (%d) != ELFCLASS32.\n",(int) ehdr->e_ident[EI_CLASS]));
		if (ehdr->e_ident[EI_DATA] != ELFDATA2MSB)
			DEBUGP(("Failure: ehdr->e_ident[EI_DATA] (%d) != ELFDATA2MSB.\n",(int) ehdr->e_ident[EI_DATA]));
		if (ehdr->e_ident[EI_VERSION] != EV_CURRENT)
			DEBUGP(("Failure: ehdr->e_ident[EI_VERSION] (%d) != EV_CURRENT.\n",(int) ehdr->e_ident[EI_VERSION]));
		if (ehdr->e_type != ET_EXEC)
			DEBUGP(("Failure: ehdr->e_type (0x%hX) != ET_EXEC.\n",ehdr->e_type));
		if (ehdr->e_machine != EM_CELLSPU)
			DEBUGP(("Failure: ehdr->e_machine (%d) != EM_CELLSPU.\n",(int) ehdr->e_machine));
		if (ehdr->e_version != EV_CURRENT)
			DEBUGP(("Failure: ehdr->e_version (%d) != EV_CURRENT.\n",ehdr->e_version));
		if (ehdr->e_flags != NONE)
			DEBUGP(("Failure: ehdr->e_flags (0x%X) != NONE (0x%X).\n",ehdr->e_flags,(int) NONE));
#endif // DEBUG
#if !defined(DEBUG)
		rc = -204;
		goto err02;
#endif // DEBUG
	}

	/* copy phdr's - alloc size for pointers, structures, and padding */
	if ((phdr = elf32_getphdr(localElf)) == NULL) {
		elfErrno = elf_errno();
		PRINTF(("Failure: elf_getphdr returned NULL\n"));
		PRINTF(("%s\n",elf_errmsg(elfErrno)));
		rc = -205;
		goto err02;
	}
	{
		int i;
		int noPhdrs = ehdr->e_phnum;
		size_t requestSize;
		MyElf32_Phdr* tmpPhdr;
		/*************************************************************
		*                                                            *
		* The space will be allocated as follows:                    *
		*     array of pointers (MyElf32_Phdr*) - 1 for each Program *
		*         Header                                             *
		*     NULL                                                   *
		*     array of Program Headers (MyElf32_Phdr)                *
		*                                                            *
		*************************************************************/
		/* Allocate space for pointers */
		requestSize = (noPhdrs +1)*sizeof(MyElf32_Phdr*);
		/* Allocate space for MyElf32_Phdr structures */
		requestSize += noPhdrs*sizeof(MyElf32_Phdr);
		/* Allocate space for padding for alignment */
		requestSize += noPhdrs*7;
		if ((localMyPhdr = malloc(requestSize)) == NULL) {
			PRINTF(("Failure: malloc failed on request for %d bytes.\n",(int) requestSize));
			rc = -206;
			goto err02;
		}
		memset(localMyPhdr,0,requestSize);
		tmpPhdr = (MyElf32_Phdr*) aligned_ptr(&localMyPhdr[noPhdrs+1]);
		for (i=0; i<noPhdrs; i++) {
			localMyPhdr[i] = tmpPhdr;
			COPY_ELF_PHDR(phdr,tmpPhdr);
			phdr++;
			tmpPhdr++;
		}
	}

	/* Process the sections */
	strndx = ehdr->e_shstrndx;
	scnCount = ehdr->e_shnum;

	/* copy shdr's - alloc size for pointers, structures, and padding */
	{
		int i;
		int noShdr;
		size_t requestSize;
		Elf_Data* elfData;
		MyElf_Data* tmpData;
		MyElf32_Shdr* tmpShdrp;
		/*************************************************************
		*                                                            *
		* The space will be allocated as follows:                    *
		*     array of pointers (MyElf32_Shdr*) - 1 for each Section *
		*         Header in original ELF program                     *
		*     NULL                                                   *
		*     array of Section Headers (MyElf32_Shdr)                *
		*     Data blocks (Elf_Data) for sections, where required    *
		*                                                            *
		*************************************************************/
		/* Calculate number of MyElf32_Shdr needed - we do not need */
		/* one for section 0 - NULL section.                        */
		noShdr = scnCount - 1;
		/* Allocate space for pointers */
		requestSize = (noShdr+1)*sizeof(MyElf32_Shdr*);
		/* Allocate space for MyElf32_Shdr structure for each section */
		requestSize += (noShdr)*sizeof(MyElf32_Shdr);
		/* Allocate space for MyElf_Data structure for each section */
		requestSize += (noShdr)*sizeof(MyElf_Data);
		/* Allocate space for padding for alignment */
		requestSize += (noShdr)*14;
		if ((localMyShdr = malloc(requestSize)) == NULL) {
			PRINTF(("Failure: malloc failed on request for %d bytes.\n",(int) requestSize));
			rc = -207;
			goto err03;
		}
		memset(localMyShdr,0,requestSize);
		tmpShdrp = (MyElf32_Shdr*) aligned_ptr(&localMyShdr[noShdr+1]);
		tmpData = (MyElf_Data*) aligned_ptr(&tmpShdrp[noShdr]);
		for (i=0; i<noShdr; i++) {
			localMyShdr[i] = tmpShdrp;
			if ((scn = elf_getscn(localElf,i+1)) == NULL) {
				elfErrno = elf_errno();
				PRINTF(("Failure: elf_getscn returned NULL for section %d\n",i+1));
				PRINTF(("%s\n",elf_errmsg(elfErrno)));
				rc = -208;
				goto err04;
			}
			if ((shdr=elf32_getshdr(scn)) == NULL) {
				elfErrno = elf_errno();
				PRINTF(("Failure: elf32_getshdr for section %d returned %d (0x%X).\n",i+1,elfErrno,elfErrno));
				PRINTF(("%s\n",elf_errmsg(elfErrno)));
				rc = -209;
				goto err04;
			}
			if ((shdr->sh_type == SHT_REL) || (shdr->sh_type == SHT_RELA)) {
				PRINTF(("Warning: section %d is a relocation section, but this is not supported by the secure loader.\n",i+1));
			}
			else if (shdr->sh_type == SHT_DYNSYM) {
				PRINTF(("Warning: section %d is a symbol table for dynamic linking, but this is not supported by the secure loader.\n",i+1));
			}
			else if (shdr->sh_type == SHT_HASH) {
				PRINTF(("Warning: section %d is a symbol hash table for dynamic linking, but this is not supported by the secure loader.\n",i+1));
			}
			else if (shdr->sh_type == SHT_DYNAMIC) {
				PRINTF(("Warning: section %d is for dynamic linking, but this is not supported by the secure loader.\n",i+1));
			}
			COPY_ELF_SHDR(shdr,tmpShdrp);
			if ((tmpShdrp->sh_nameStr = elf_strptr(localElf,strndx,shdr->sh_name)) == NULL) {
				elfErrno = elf_errno();
				PRINTF(("Failure: section name can not be resolved for section %d.\n",i+1));
				PRINTF(("%s\n",elf_errmsg(elfErrno)));
				rc = -210;
				goto err04;
			}
			elfData = elf_getdata(scn,NULL);
			if (elfData == NULL) {
				tmpShdrp->sh_data = NULL;
			}
			else {
				tmpShdrp->sh_data = tmpData;
				COPY_ELF_DATA(elfData,tmpData);
			}
			tmpShdrp++;
			tmpData++;
		}
		localMyShdr[noShdr] = NULL;
	}
	*elf = localElf;
	COPY_ELF_EHDR(ehdr,myEhdr)
	*myPhdr = localMyPhdr;
	*myShdr = localMyShdr;

err04:
	/* Error after localMyShdr = malloc(requestSize) */
	if (rc != 0)
		free(localMyShdr);
err03:
	/* Error after localMyPhdr = malloc(requestSize) */
	if (rc != 0)
		free(localMyPhdr);
err02:
	/* Error after elf_begin(fd,ELF_C_READ,NULL)*/
	if (rc != 0)
		elf_end(localElf);
err01:
	/* Error after call - fd will be closed by caller */
	return rc;
}
