/* --------------------------------------------------------------- */
/* (C) Copyright 2006,2008,                                        */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* THIS PROGRAM IS PROVIDED UNDER THE TERMS OF THE COMMON PUBLIC   */
/* LICENSE VERSION 1 ("AGREEMENT"). ANY USE, REPRODUCTION OR       */
/* DISTRIBUTION OF THE PROGRAM CONSTITUTES RECIPIENT'S ACCEPTANCE  */
/* OF THIS AGREEMENT.                                              */
/*                                                                 */
/* A copy of the Agreement accompanies this distribution, or see   */
/* <http://www.ibm.com/developerworks/library/os-cpl.html>.        */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

#ifndef BUILDSECUREAPP_H_
#define BUILDSECUREAPP_H_

#define INLINE __inline__

#define ENCRYPTION_KEY_SIZE_BITS 128
#define ENCRYPTION_KEY_SIZE 16
#define SIZE_SIGNATURE 1024

// One version of libelf.h uses the type off64_t, but it is not
// defined unless USE_LARGEFILE64 is also defined. This may not
// be defined for some 32-bit compiles. Newer versions of the
// libelf.h use the type loff_t. Avoid compilation errors by using
// the following typedef.
#ifndef __off64_t_defined
typedef loff_t off64_t;
#endif

#include <elf.h>
#include <libelf.h>

#include "debug.h"
#include "myElf.h"
#include "memoryImage.h"

#define NONE 0

typedef struct
{
	uint32_t		encryptOffset;
	uint32_t		encryptSize;
	unsigned char*	encryptKey;
	uint32_t		encryptKeySize;
	unsigned char*	encryptedKey;
	uint32_t		encryptedKeySize;
	void*			kernelPublicKey;
	uint32_t		kernelPublicKeySize;
	void*			userPublicCert;
	uint32_t		userPublicCertSize;
} EncryptInfo;

typedef struct
{
	unsigned char*	signature;
	uint32_t		signatureSize;
	void*			privateKey;
	uint32_t		privateKeySize;
	void*			publicCert;
	uint32_t		publicCertSize;
	uint32_t		startOffset;
	uint32_t		length;
	uint32_t		storeOffset;
} SignatureInfo;

extern int addSectionNames(MyElf32_Shdr** myShdr, Elf32_Half shstrndx, void** strData);
extern int addSignature(unsigned char* memoryImage, int memoryImageSize, SignatureInfo* signatureInfo);
extern int buildMemoryImage(unsigned char* nonce, MyElf32_Ehdr* myEhdr, MyElf32_Phdr** myPhdr, MyElf32_Shdr* textShdr, MyElf32_Shdr* bssShdr, EncryptInfo* encryptInfo, SignatureInfo* signatureInfo,          unsigned char** memoryImage, int* memoryImageSize);
extern int combineSections(MyElf32_Ehdr* myEhdr, MyElf32_Phdr** myPhdr, MyElf32_Shdr** myShdr, MyElf32_Shdr** newTextShdr, char** newTextDataBuf, Elf32_Word* newTextDataSize, MyElf32_Shdr** bssShdr);
extern int encryptSection(MyElf32_Shdr* encryptShdr, unsigned char* data, Elf32_Word size, EncryptInfo* encryptInfo);
extern int findSection(MyElf32_Shdr** myShdr, char* sectionName, MyElf32_Shdr** sectionShdr);
extern int pem2der(void* source, int sourceLen, void* target, int targetLen, char* header, int headerLen, char* trailer, int trailerLen);
extern int prepareSignature(SignatureInfo* signatureInfo);
extern int readElf(int fd, Elf** elf, MyElf32_Ehdr* myEhdr, MyElf32_Phdr*** myPhdr, MyElf32_Shdr*** myShdr);
extern int readfile(const char* filename, void** contents, int* size);
extern int updatePgmHdr(Elf* elf);
extern int writeElf(const int filedesc, MyElf32_Ehdr* myEhdr, MyElf32_Phdr** myPhdr, MyElf32_Shdr** myShdr);

#endif /*BUILDSECUREAPP_H_*/
