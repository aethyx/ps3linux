/* --------------------------------------------------------------- */
/* (C) Copyright 2006,2008,                                        */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* THIS PROGRAM IS PROVIDED UNDER THE TERMS OF THE COMMON PUBLIC   */
/* LICENSE VERSION 1 ("AGREEMENT"). ANY USE, REPRODUCTION OR       */
/* DISTRIBUTION OF THE PROGRAM CONSTITUTES RECIPIENT'S ACCEPTANCE  */
/* OF THIS AGREEMENT.                                              */
/*                                                                 */
/* A copy of the Agreement accompanies this distribution, or see   */
/* <http://www.ibm.com/developerworks/library/os-cpl.html>.        */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

#ifndef MEMORYIMAGE_H_
#define MEMORYIMAGE_H_

/*********************************************************************
* Macros for defining address alignment. ROUND_DOWN is to align to   *
* the boundary at or before the given address (X), while ROUND_UP is *
* to align to the boundary at or after the given address (X).        *
*********************************************************************/
#define ROUND_DOWN(X,N) (X - (X % N))
#define PADDING(X,N) ((X % N) == 0 ? 0 : (N - (X % N)))
#define ROUND_UP(X,N) (X + PADDING(X,N))

/*********************************************************************
* The best performance for DMA's to the SPE occur if the data is     *
* aligned on a 128-byte boundary, but we will use a 128-bit          *
* (16-byte) boundary.                                                *
*********************************************************************/
#define DMA_PAD_SIZE 16
/*********************************************************************
* SHA1 hashing requires 512-bit (64-byte) blocks.                    *
*********************************************************************/
#define MIN_SHA1_PAD_SIZE 9
#define SHA1_PAD_SIZE 64

/*********************************************************************
* All integer values in the memory image are saved using big endian  *
* format.                                                            *
*********************************************************************/
#define SAVE_BIG_ENDIAN(X,P) { \
	P[0] = (X >> 24) & 0x07f; \
	P[1] = (X >> 16) & 0x0ff; \
	P[2] = (X >> 8) & 0x0ff; \
	P[3] = X & 0x0ff; \
}
#define READ_BIG_ENDIAN(X,P) { \
	X = (P[0]<<24) | (P[1]<<16) | (P[2]<<8) | P[3]; \
}

/*********************************************************************
*                                                                    *
* The correct memory map is given in the specification.              *
*                                                                    *
*********************************************************************/

#define MAIN_HEADER_OFFSET 0
#define NONCE_OFFSET (MAIN_HEADER_OFFSET+0)
#define SECURE_SPE_APP_ID_OFFSET (MAIN_HEADER_OFFSET+8)
#define VERSION_OFFSET (MAIN_HEADER_OFFSET+10)
#define MEMORY_IMAGE_SIZE_OFFSET (MAIN_HEADER_OFFSET+12)
#define EXECUTION_IMAGE_SIZE_OFFSET (MAIN_HEADER_OFFSET+16)
#define ENTRY_POINT_OFFSET (MAIN_HEADER_OFFSET+20)
#define ENCRYPTION_INFO_OFFSET (MAIN_HEADER_OFFSET+24)
#define SIGNATURE_INFO_OFFSET (MAIN_HEADER_OFFSET+28)
#define TEXT_SECTION_OFFSET (MAIN_HEADER_OFFSET+32)
#define MAIN_HEADER_SIZE (TEXT_SECTION_OFFSET-MAIN_HEADER_OFFSET)

#define MIN_CODE_ADDR 0x80
#define LOAD_ADDR (MIN_CODE_ADDR - MAIN_HEADER_SIZE)

/*********************************************************************
* Add the size of the .text section to the following offsets.        *
*********************************************************************/
#define ENCRYPTED_KEY_HEADER_OFFSET (MAIN_HEADER_OFFSET+MAIN_HEADER_SIZE)
#define OFFSET_ENCRYPTED_SECTION_OFFSET (ENCRYPTED_KEY_HEADER_OFFSET+0)
#define SIZE_ENCRYPTED_SECTION_OFFSET (ENCRYPTED_KEY_HEADER_OFFSET+4)
#define SIZE_ENCRYPTED_KEY_OFFSET (ENCRYPTED_KEY_HEADER_OFFSET+8)
#define SIZE_ENCRYPTED_KEY_SECTION_OFFSET (ENCRYPTED_KEY_HEADER_OFFSET+12)
#define ENCRYPTED_KEY_SECTION_OFFSET (ENCRYPTED_KEY_HEADER_OFFSET+16)
#define ENCRYPTED_KEY_HEADER_SIZE (ENCRYPTED_KEY_SECTION_OFFSET-ENCRYPTED_KEY_HEADER_OFFSET)

/*********************************************************************
* Add the sizes of the .text section and the encrypted key to the    *
* following offsets.                                                 *
*********************************************************************/
#define DIGITAL_SIGNATURE_HEADER_OFFSET (ENCRYPTED_KEY_HEADER_OFFSET+ENCRYPTED_KEY_HEADER_SIZE)
#define OFFSET_DIGITAL_SIGNATURE_OFFSET (DIGITAL_SIGNATURE_HEADER_OFFSET+0)
#define SIZE_DIGITAL_SIGNATURE_OFFSET (DIGITAL_SIGNATURE_HEADER_OFFSET+4)
#define OFFSET_PUBLIC_KEY_CERTIFICATE_OFFSET (DIGITAL_SIGNATURE_HEADER_OFFSET+8)
#define SIZE_PUBLIC_KEY_CERTIFICATE_OFFSET (DIGITAL_SIGNATURE_HEADER_OFFSET+12)
#define DIGITAL_SIGNATURE_HEADER_SIZE 16

#define SIZE_OF_HEADERS (MAIN_HEADER_SIZE+ENCRYPTED_KEY_HEADER_SIZE+DIGITAL_SIGNATURE_HEADER_SIZE)

#endif /*MEMORYIMAGE_H_*/
