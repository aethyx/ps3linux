/* --------------------------------------------------------------- */
/* (C) Copyright 2006,2008,                                        */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* THIS PROGRAM IS PROVIDED UNDER THE TERMS OF THE COMMON PUBLIC   */
/* LICENSE VERSION 1 ("AGREEMENT"). ANY USE, REPRODUCTION OR       */
/* DISTRIBUTION OF THE PROGRAM CONSTITUTES RECIPIENT'S ACCEPTANCE  */
/* OF THIS AGREEMENT.                                              */
/*                                                                 */
/* A copy of the Agreement accompanies this distribution, or see   */
/* <http://www.ibm.com/developerworks/library/os-cpl.html>.        */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

/*********************************************************************
*                                                                    *
* Find a named section header                                        *
*                                                                    *
*********************************************************************/

#include <stddef.h>		 // NULL, other ANSI-C types
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

#include "buildSecureApp.h"

int findSection(MyElf32_Shdr** myShdr, char* sectionName, MyElf32_Shdr** sectionShdr)
{
	MyElf32_Shdr**	localShdr;
	int				rc = 0;

	*sectionShdr = NULL;

	localShdr = myShdr;
	while (*localShdr != NULL) {
		if ((*localShdr)->sh_nameStr != NULL) {
			if (strcmp((*localShdr)->sh_nameStr,sectionName) == 0) {
				*sectionShdr = *localShdr;
				goto err01;
			}
		}
		localShdr++;
	}
	PRINTF(("Failure: section, %s, not found\n",sectionName));
	rc = -601;

err01:
	return rc;
}

