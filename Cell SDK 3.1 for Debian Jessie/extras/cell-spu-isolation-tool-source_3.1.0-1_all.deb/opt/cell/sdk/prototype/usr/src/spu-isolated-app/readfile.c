/* --------------------------------------------------------------- */
/* (C) Copyright 2006,2008,                                        */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* THIS PROGRAM IS PROVIDED UNDER THE TERMS OF THE COMMON PUBLIC   */
/* LICENSE VERSION 1 ("AGREEMENT"). ANY USE, REPRODUCTION OR       */
/* DISTRIBUTION OF THE PROGRAM CONSTITUTES RECIPIENT'S ACCEPTANCE  */
/* OF THIS AGREEMENT.                                              */
/*                                                                 */
/* A copy of the Agreement accompanies this distribution, or see   */
/* <http://www.ibm.com/developerworks/library/os-cpl.html>.        */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

/*********************************************************************
*                                                                    *
* Read contents of file into new buffer                              *
*                                                                    *
*********************************************************************/

#include <stddef.h>         // NULL, other ANSI-C types
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

#include "buildSecureApp.h"

int readfile(const char* filename, void** contents, int* size)
{
	FILE*		file;
	void*		mycontents;
	int			mysize;
	int			rc = 0;
	struct stat	stat;

	*contents = NULL;
	*size = 0;
	if ((file = fopen(filename, "r")) == NULL) {
        PRINTF(("Failure: open returned %d (0x%X) for file %s.\n",errno,errno,filename));
        PRINTF(("%s\n",strerror(errno)));
        rc = -101;
        goto err01;
	}
	if (fstat(fileno(file),&stat) == -1) {
		PRINTF(("Failure: fstat returned %d (0x%X) for file %s.\n",errno,errno,filename));
		PRINTF(("%s\n",strerror(errno)));
		rc = -102;
		goto err02;
	}
	mysize = stat.st_size;
	if ((mycontents = malloc(mysize)) == NULL) {
		PRINTF(("Failure: malloc returned error.\n"));
		rc = -103;
		goto err02;
	}
	if (fread(mycontents,1,mysize,file) != mysize) {
		PRINTF(("Failure: error reading file %s.\n",filename));
		if (ferror(file) != 0)
			PRINTF(("%s\n",strerror(errno)));
		rc = -104;
		goto err03;
	}

	*contents = mycontents;
	*size = mysize;

err03:
	if (rc != 0)
		free(mycontents);
err02:
	fclose(file);
err01:
	return rc;	
}
