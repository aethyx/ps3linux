/* --------------------------------------------------------------- */
/* (C) Copyright 2006,2008,                                        */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* THIS PROGRAM IS PROVIDED UNDER THE TERMS OF THE COMMON PUBLIC   */
/* LICENSE VERSION 1 ("AGREEMENT"). ANY USE, REPRODUCTION OR       */
/* DISTRIBUTION OF THE PROGRAM CONSTITUTES RECIPIENT'S ACCEPTANCE  */
/* OF THIS AGREEMENT.                                              */
/*                                                                 */
/* A copy of the Agreement accompanies this distribution, or see   */
/* <http://www.ibm.com/developerworks/library/os-cpl.html>.        */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

/*********************************************************************
*                                                                    *
* Compute the digital signature.                                     *
*                                                                    *
*********************************************************************/

#include <stddef.h>		 // NULL, other ANSI-C types
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

#include "buildSecureApp.h"

#include <openssl/err.h>
#include <openssl/objects.h>
#include <openssl/rsa.h>
#include <openssl/sha.h>

/*********************************************************************
*                                                                    *
* prepareSignature is called before building the memory image. It    *
* will allocate the required space for the digital signature which   *
* is required to build the memory image, but dependent upon the size *
* of the private key for signing and signing algorithm.              *
*                                                                    *
*********************************************************************/
int prepareSignature(SignatureInfo* signatureInfo)
{
	int				localSize;
	void*			localSpace;
	int				rc = 0;

	signatureInfo->signature = NULL;
	signatureInfo->signatureSize = 0;
	if (signatureInfo->privateKey == NULL) {
		PRINTF(("Failure: internal error - missing signing key\n"));
		rc = -1101;
		goto err01;
	}
	if (signatureInfo->publicCert == NULL) {
		PRINTF(("Failure: internal error - missing verification key\n"));
		rc = -1102;
		goto err01;
	}
	localSize = RSA_size(signatureInfo->privateKey);
	if ((localSpace = malloc(localSize)) == NULL) {
		PRINTF(("Failure: Unable to malloc %d bytes\n", localSize));
		rc = -1103;
		goto err01;
	}
	memset(localSpace,0,localSize);

	signatureInfo->signature = localSpace;
	signatureInfo->signatureSize = localSize;

err01:
	return rc;
}

int addSignature(unsigned char* memoryImage, int memoryImageSize, SignatureInfo* signatureInfo)
{
	unsigned char	md[SHA_DIGEST_LENGTH];
	int				rc = 0;
	unsigned int	siglen;
	unsigned long	errSsl;
	char			errString[120];

	/*****************************************************************
	*                                                                *
	* This routine will sign the memory image that is to be loaded   *
	* into the SPU for execution. Thus, the loading and signing are  *
	* simplified and the SPU is verifying exactly what will be used. *
	*                                                                *
	*****************************************************************/

	/* Sign up to the first byte of the digital signature */
	if (SHA1(memoryImage+signatureInfo->startOffset,signatureInfo->length,md) == NULL) {
		PRINTF(("Failure: unable to compute SHA1 hash for memory image\n"));
		while ((errSsl = ERR_get_error()) != 0) {
			PRINTF(("SHA1() -> %s\n",ERR_error_string(errSsl,errString)));
		}
		rc = -1104;
		goto err01;
	}
	if (RSA_sign(NID_sha1,md,SHA_DIGEST_LENGTH,signatureInfo->signature,&siglen,signatureInfo->privateKey) != 1) {
		PRINTF(("Failure: unable to sign digest of memory image\n"));
		while ((errSsl = ERR_get_error()) != 0) {
			PRINTF(("RSA_sign() -> %s\n",ERR_error_string(errSsl,errString)));
		}
		rc = -1105;
		goto err01;
	}
	if (siglen != signatureInfo->signatureSize) {
		PRINTF(("Failure: signature is unexpected length (%d)\n",siglen));
		rc = -1106;
		goto err01;
	}
	/* Now replace the placeholder value in the memory image with the real signature */
	memcpy(memoryImage+signatureInfo->storeOffset,signatureInfo->signature,signatureInfo->signatureSize);

err01:
	if (rc != 0) {
		free(signatureInfo->signature);
		signatureInfo->signature = NULL;
		signatureInfo->signatureSize = 0;
	}
	return rc;
}
