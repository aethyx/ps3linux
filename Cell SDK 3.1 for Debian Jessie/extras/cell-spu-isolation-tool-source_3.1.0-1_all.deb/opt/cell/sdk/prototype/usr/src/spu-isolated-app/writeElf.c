/* --------------------------------------------------------------- */
/* (C) Copyright 2006,2008,                                        */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* THIS PROGRAM IS PROVIDED UNDER THE TERMS OF THE COMMON PUBLIC   */
/* LICENSE VERSION 1 ("AGREEMENT"). ANY USE, REPRODUCTION OR       */
/* DISTRIBUTION OF THE PROGRAM CONSTITUTES RECIPIENT'S ACCEPTANCE  */
/* OF THIS AGREEMENT.                                              */
/*                                                                 */
/* A copy of the Agreement accompanies this distribution, or see   */
/* <http://www.ibm.com/developerworks/library/os-cpl.html>.        */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

/*********************************************************************
*                                                                    *
* Write the generated an ELF file                                    *
*                                                                    *
*********************************************************************/

#include <stddef.h>		 // NULL, other ANSI-C types
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

#include "buildSecureApp.h"

int writeElf(int fd, MyElf32_Ehdr* myEhdr, MyElf32_Phdr** myPhdr, MyElf32_Shdr** myShdr)
{
	Elf_Data*		data;
	Elf32_Ehdr*		ehdr;
	Elf*			elf;
	int				elfErrno;
	int				noScn;
	Elf32_Phdr*		phdr;
	int				rc = 0;
	Elf_Scn*		scn;
	Elf32_Shdr*		shdr;
	MyElf32_Phdr*	tMyPhdr;
	MyElf32_Shdr**	tMyShdr;
	Elf32_Phdr* 	tPhdr;

	int				i;

	/* Now start building the ELF contents */
	elf_version(EV_CURRENT);
	if ((elf=elf_begin(fd,ELF_C_WRITE,NULL)) == NULL) {
		elfErrno = elf_errno();
		PRINTF(("Failure: elf_begin returned %d (0x%X).\n",elfErrno,elfErrno));
		PRINTF(("%s\n",elf_errmsg(elfErrno)));
		rc = -301;
		goto err01;
	}

	/* Create the ELF header */
	if ((ehdr = elf32_newehdr(elf)) == 0) {
		elfErrno = elf_errno();
		PRINTF(("Failure: could not generate the ELF header.\n"));
		PRINTF(("%s\n",elf_errmsg(elfErrno)));
		rc = -302;
		goto err01;
	}
	/* Set ehdr->e_shstrndx to correct section index later */
	COPY_ELF_EHDR(myEhdr,ehdr);
	ehdr->e_phnum = 0;
	ehdr->e_shnum = 0;
	// ehdr->e_shstrndx = 0;
	if ((elf_update(elf,ELF_C_NULL)) == -1) {
		elfErrno = elf_errno();
		PRINTF(("Failure: unable to update ELF header.\n"));
		PRINTF(("%s\n",elf_errmsg(elfErrno)));
		rc = -303;
		goto err01;
	}

	/* Create new ELF sections */
	noScn = 0;
	tMyShdr = myShdr;
	while (*tMyShdr != NULL) {
		noScn++;
		if ((scn = elf_newscn(elf)) == 0) {
			elfErrno = elf_errno();
			PRINTF(("Failure: could not generate new ELF section %d.\n",noScn));
			PRINTF(("%s\n",elf_errmsg(elfErrno)));
			rc = -304;
			goto err01;
		}
		if ((shdr = elf32_getshdr(scn)) == 0) {
			elfErrno = elf_errno();
			PRINTF(("Failure: could not generate section header for section %d\n",noScn));
			PRINTF(("%s\n",elf_errmsg(elfErrno)));
			rc = -305;
			goto err01;
		}
		COPY_ELF_SHDR((*tMyShdr),shdr);
		/* Create data section, if needed */
		if ((*tMyShdr)->sh_data != NULL) {
			if ((data = elf_newdata(scn)) == 0) {
				elfErrno = elf_errno();
				PRINTF(("Failure: could not generate data descriptor for section %d\n",noScn));
				PRINTF(("%s\n",elf_errmsg(elfErrno)));
				rc = -306;
				goto err01;
			}
			COPY_ELF_DATA(((*tMyShdr)->sh_data),data);
		}
		tMyShdr++;
	}

	/* Create the ELF program headers */
	if ((phdr = elf32_newphdr(elf,myEhdr->e_phnum)) == 0) {
		elfErrno = elf_errno();
		PRINTF(("Failure: could not generate the ELF program headers.\n"));
		PRINTF(("%s\n",elf_errmsg(elfErrno)));
		rc = -307;
		goto err01;
	}
	tMyPhdr = *myPhdr;
	tPhdr = phdr;
	for (i=0; i<myEhdr->e_phnum; i++) {
		COPY_ELF_PHDR(tMyPhdr,tPhdr);
		tMyPhdr++;
		tPhdr++;
	}
	if ((elf_update(elf,ELF_C_NULL)) == -1) {
		elfErrno = elf_errno();
		PRINTF(("Failure: unable to update ELF program header.\n"));
		PRINTF(("%s\n",elf_errmsg(elfErrno)));
		rc = -308;
		goto err01;
	}

	/* Finally, update the Program Headers to reflect any changes */
	if ((rc = updatePgmHdr(elf)) != 0) {
		goto err01;
	}

	/* Update the file */
	if ((elf_update(elf,ELF_C_WRITE)) == -1) {
		elfErrno = elf_errno();
		PRINTF(("Failure: unable to update the ELF file.\n"));
		PRINTF(("%s\n",elf_errmsg(elfErrno)));
		rc = -309;
		// goto err01;
	}

err01:
	elf_end(elf);
	return rc;
}
