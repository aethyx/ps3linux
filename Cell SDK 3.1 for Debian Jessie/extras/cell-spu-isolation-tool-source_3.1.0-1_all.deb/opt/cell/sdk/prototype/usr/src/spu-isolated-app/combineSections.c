/* --------------------------------------------------------------- */
/* (C) Copyright 2006,2008,                                        */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* THIS PROGRAM IS PROVIDED UNDER THE TERMS OF THE COMMON PUBLIC   */
/* LICENSE VERSION 1 ("AGREEMENT"). ANY USE, REPRODUCTION OR       */
/* DISTRIBUTION OF THE PROGRAM CONSTITUTES RECIPIENT'S ACCEPTANCE  */
/* OF THIS AGREEMENT.                                              */
/*                                                                 */
/* A copy of the Agreement accompanies this distribution, or see   */
/* <http://www.ibm.com/developerworks/library/os-cpl.html>.        */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

/*********************************************************************
*                                                                    *
* Combine the existing ALLOC sections into a single section (that    *
* can be encrypted and signed)                                       *
*                                                                    *
*********************************************************************/

#include <stddef.h>		 // NULL, other ANSI-C types
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

#include "buildSecureApp.h"

static MyElf32_Phdr	newPhdr;
static char*		textname = ".text";

int combineSections(MyElf32_Ehdr* myEhdr, MyElf32_Phdr** myPhdr, MyElf32_Shdr** myShdr, MyElf32_Shdr** newTextShdr, char** newTextDataBuf, Elf32_Word* newTextDataSize, MyElf32_Shdr** bssShdr)
{
	Elf32_Word		fileSize;
	Elf32_Word		firstAddr = 0x00;
	int				firstAlloc = 1;
	Elf32_Word		lastAddr = 0x00;
	int				lastAlloc = 0;
	Elf32_Word		lastCodeAddr = 0x00;
	MyElf32_Shdr**	localShdr;
	Elf32_Word		memSize;
	int				noShdr;
	int				rc = 0;
	char*			textDataBuf;
	MyElf32_Shdr*	textShdr;

	int				i,j,k;

	*newTextShdr = NULL;
	*newTextDataBuf = NULL;
	*bssShdr = NULL;

	/* Determine the size of the combined text section */
	noShdr = 0;
	localShdr = myShdr;
	while (*localShdr != NULL) {
		noShdr++;
		if (((*localShdr)->sh_flags & SHF_ALLOC) != 0) {
			/* Allocated section */
			if (firstAlloc > lastAlloc) {
				firstAlloc = noShdr;
				firstAddr = (*localShdr)->sh_addr;
			}
			else {
				/* Not first ALLOC section */
				if ((*localShdr)->sh_addr < lastAddr) {
					PRINTF(("Failure: address for section %d overlaps previous sections\n",noShdr));
					rc = -701;
				}
				if (noShdr != lastAlloc+1) {
					PRINTF(("Failure: non-ALLOCed section before ALLOC section %d\n",noShdr));
					rc = -703;
				}
			}
			lastAlloc = noShdr;
			lastAddr = (*localShdr)->sh_addr + (*localShdr)->sh_size;
			if ((*localShdr)->sh_type == SHT_PROGBITS) {
				lastCodeAddr = lastAddr;
			}
			else if ((*localShdr)->sh_type == SHT_NOBITS) {
				*bssShdr = *localShdr;
			}
		}
		localShdr++;
	}
	if (firstAlloc > lastAlloc) {
		PRINTF(("Failure: unable to find code and data sections\n"));
		rc = -704;
		goto err01;
	}
	if ((myEhdr->e_shstrndx >= firstAlloc) && (myEhdr->e_shstrndx <= lastAlloc)) {
		PRINTF(("Failure: shared string section is one of the ALLOC sections\n"));
		rc = -705;
		goto err01;
	}
	if (firstAddr < MIN_CODE_ADDR) {
		PRINTF(("Failure: virtual address for loading program does not allow memory for headers\n"));
		rc = -706;
		goto err01;
	}
	firstAddr = MIN_CODE_ADDR;

	/* Generate new Program Header */
	*myPhdr = &newPhdr;
	memset((void *)&newPhdr,0,sizeof(newPhdr));
	*(myPhdr+1) = NULL;
	newPhdr.p_type = PT_LOAD;
	newPhdr.p_vaddr = firstAddr;
	newPhdr.p_paddr = firstAddr;
	fileSize = lastCodeAddr - firstAddr;
 	/* We must ROUND_UP for the memory image, but also because the   *
	*  padding may be needed for the encryption (16 byte blocks)    */
	fileSize = ROUND_UP(fileSize,16);
	newPhdr.p_filesz = fileSize;
	memSize = lastAddr - firstAddr;
	newPhdr.p_memsz = memSize;
	newPhdr.p_flags = PF_X | PF_W | PF_R;
	newPhdr.p_align = 0x10;			/* MIN_CODE_ADDR yields 0x80 alignment for start of .text */

	/* Correct ELF header */
	myEhdr->e_phnum = 1;

	/* Generate new combined section header */
	if ((textDataBuf = malloc(fileSize)) == NULL) {
		PRINTF(("Failure: malloc failed on request for %d bytes.\n",fileSize));
		rc = -707;
		goto err01;
	}
	memset(textDataBuf,0,fileSize);
	for (i=firstAlloc-1; i<lastAlloc; i++) {
		if ((myShdr[i]->sh_type == SHT_PROGBITS) && (myShdr[i]->sh_data != NULL) && (myShdr[i]->sh_data->d_buf != NULL)) {
			memcpy(textDataBuf+myShdr[i]->sh_addr-firstAddr,myShdr[i]->sh_data->d_buf,myShdr[i]->sh_data->d_size);
		}
	}
	textShdr = myShdr[firstAlloc-1];
	if (strcmp(textShdr->sh_nameStr,textname) != 0) {
		/* Substitute .text as new section name */
		textShdr->sh_nameStr = textname;
		textShdr->sh_name = 0;
	}
	textShdr->sh_addr = newPhdr.p_vaddr;
	textShdr->sh_size = fileSize;
	textShdr->sh_addralign = newPhdr.p_align;
	textShdr->sh_entsize = 0x01;
	textShdr->sh_data->d_buf = textDataBuf;
	textShdr->sh_data->d_size = fileSize;
	textShdr->sh_data->d_align = newPhdr.p_align;

	/* Remove the extra section headers */
	j = firstAlloc;
	k = lastAlloc;
	while (1==1) {
		myShdr[j] = myShdr[k];
		if (myShdr[k] == NULL)
			break;
		if (myShdr[j]->sh_type == SHT_SYMTAB) {
			if (myShdr[j]->sh_link > lastAlloc) {
				/* The string table follows the code sections - as expected */
				myShdr[j]->sh_link -= lastAlloc - firstAlloc;
			}
			/* Reset the symbol table!! */
			if (myShdr[j]->sh_type == SHT_SYMTAB) {
				Elf32_Sym* symtab;
				Elf32_Sym* firstPlus = NULL;
				int i;
				Elf32_Addr* endAddr = myShdr[j]->sh_data->d_buf + myShdr[j]->sh_size;
				unsigned char st_bind;
				unsigned char st_type;
				for (symtab = (Elf32_Sym*)(myShdr[j]->sh_data->d_buf), i=0; symtab < (Elf32_Sym*)endAddr; symtab++, i++) {
					st_bind = ELF32_ST_BIND(symtab->st_info);
					st_type = ELF32_ST_TYPE(symtab->st_info);
					if (st_type == STT_SECTION) {
						if (symtab->st_shndx < firstAlloc) {
							/* do nothing */
						}
						else if (symtab->st_shndx == firstAlloc) {
							firstPlus = symtab+1;
							symtab->st_value = newPhdr.p_vaddr;
						}
						else {
							if (symtab->st_shndx > lastAlloc) {
								/* Move section symbols down to be adjacent */
								firstPlus->st_name = symtab->st_name;
								firstPlus->st_value = symtab->st_value;
								firstPlus->st_size = symtab->st_size;
								firstPlus->st_info = symtab->st_info;
								firstPlus->st_shndx = symtab->st_shndx - lastAlloc + firstAlloc;
								firstPlus++;
							}
							symtab->st_name = 0;
							symtab->st_value = 0;
							symtab->st_size = 0;
							symtab->st_info = ELF32_ST_INFO(STB_LOCAL,STT_NOTYPE);
							symtab->st_other = 0;
							symtab->st_shndx = 0;
						}
					}
					else {
						if (symtab->st_shndx < SHN_LORESERVE) {
							if (symtab->st_shndx > lastAlloc) {
								symtab->st_shndx -= lastAlloc - firstAlloc;
							}
							else if (symtab->st_shndx > firstAlloc) {
								symtab->st_shndx = firstAlloc;
							}
						}
					}
				}
			}
		}
		j++;
		k++;
	}
	if (myEhdr->e_shstrndx > lastAlloc) {
		/* Adjust shared strings section index */
		myEhdr->e_shstrndx -= lastAlloc - firstAlloc;
	}
	/* Have library recompute the number of section headers */
	myEhdr->e_shnum = 0;

	*newTextShdr = textShdr;
	*newTextDataBuf = textDataBuf;
	*newTextDataSize = fileSize;

// err02:
	/* Error after textDataBuf = malloc(fileSize) */
	if (rc != 0)
		free(textDataBuf);
err01:
	return rc;
}
