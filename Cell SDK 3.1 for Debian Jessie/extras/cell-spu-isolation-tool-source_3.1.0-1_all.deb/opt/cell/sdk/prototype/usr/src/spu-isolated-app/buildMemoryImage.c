/* --------------------------------------------------------------- */
/* (C) Copyright 2006,2008,                                        */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* THIS PROGRAM IS PROVIDED UNDER THE TERMS OF THE COMMON PUBLIC   */
/* LICENSE VERSION 1 ("AGREEMENT"). ANY USE, REPRODUCTION OR       */
/* DISTRIBUTION OF THE PROGRAM CONSTITUTES RECIPIENT'S ACCEPTANCE  */
/* OF THIS AGREEMENT.                                              */
/*                                                                 */
/* A copy of the Agreement accompanies this distribution, or see   */
/* <http://www.ibm.com/developerworks/library/os-cpl.html>.        */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

/*********************************************************************
*                                                                    *
* Read the memory image for an SPE ELF executable                    *
*                                                                    *
*********************************************************************/

#include <stddef.h>		 // NULL, other ANSI-C types
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

#include "buildSecureApp.h"

int buildMemoryImage(unsigned char* nonce, MyElf32_Ehdr* myEhdr, MyElf32_Phdr** myPhdr, MyElf32_Shdr* textShdr, MyElf32_Shdr* bssShdr, EncryptInfo* encryptInfo, SignatureInfo* signatureInfo, unsigned char** memoryImage, int* memoryImageSize)
{
	unsigned char*	fillPtr;
	int				fillValue;
	int				localImageSize = 0;
	unsigned char*	localMemoryImage = NULL;
	int				rc = 0;
	MyElf_Data*		textData;

	int				l;
	int				m;
	int				n = 0;
	int				p,p1p,p2,p3;

	localImageSize = 0;
	if (textShdr == NULL) {
		PRINTF(("Failure: internal error\n"));
		rc = -201;
		goto err01;
	}
	localImageSize = l = MAIN_HEADER_SIZE;
	textData = textShdr->sh_data;
	m = ROUND_UP((textShdr->sh_size),DMA_PAD_SIZE);
	localImageSize += m;
	m += l - MAIN_HEADER_SIZE;	/* Correct for any alignment padding */
	localImageSize += ENCRYPTED_KEY_HEADER_SIZE;
	n = 0;
	if (encryptInfo->encryptSize != 0) {
		n = encryptInfo->encryptedKeySize;
	}
	n = ROUND_UP(n,DMA_PAD_SIZE);
	localImageSize += n;
	localImageSize += DIGITAL_SIGNATURE_HEADER_SIZE;
	/*******************************************************************************
	*                                                                              *
	* The digital signature over the memory image is calculated over the data to   *
	* this point. However, the spe SHA-1 hash calculation code requires that the   *
	* calling program provide the additional space required for the SHA-1 padding  *
	* (a '1' bit followed by zeros, and ending with the 64-bit value of the        *
	* original length of the data, all ending on a 64-byte boundary). So p will    *
	* represent the additional space required for the SHA-1 padding. This will be  *
	* a minimum of 9 bytes and a maximum of 64 bytes.                              *
	*                                                                              *
	********************************************************************************/
	p = ROUND_UP((localImageSize + MIN_SHA1_PAD_SIZE),SHA1_PAD_SIZE) - localImageSize;
	localImageSize += p;
	p1p = localImageSize + signatureInfo->signatureSize;
	p1p = ROUND_UP(p1p,DMA_PAD_SIZE) - localImageSize;
	p2 = signatureInfo->publicCertSize;
	localImageSize += p1p + p2;
	p3 = ROUND_UP((localImageSize + MIN_SHA1_PAD_SIZE),SHA1_PAD_SIZE) - localImageSize;
	localImageSize += p3;
	if ((localMemoryImage = malloc(localImageSize)) == NULL) {
		PRINTF(("Failure: malloc failed on request for %d bytes.\n",localImageSize));
		rc = -203;
		goto err01;
	}
	memset(localMemoryImage,0,localImageSize);

	/* Now that we have the memory, fill the memory image */
	fillPtr = localMemoryImage + NONCE_OFFSET;
	memcpy(fillPtr,nonce,8);
	fillPtr = localMemoryImage + SECURE_SPE_APP_ID_OFFSET;
	memcpy(fillPtr,"\x00\x17",2);
	fillPtr = localMemoryImage + VERSION_OFFSET;
	memcpy(fillPtr,"\x00\x01",2);
	fillPtr = localMemoryImage + MEMORY_IMAGE_SIZE_OFFSET;
	SAVE_BIG_ENDIAN(localImageSize,fillPtr);
	if (bssShdr == NULL)
		fillValue = textShdr->sh_size;
	else {
		if (bssShdr->sh_addr < textShdr->sh_addr) {
			PRINTF(("Failure: .bss section not expected to be allocated before .text section.\n"));
			rc = -204;
			goto err02;
		}
		fillValue = bssShdr->sh_addr + bssShdr->sh_size - textShdr->sh_addr;
	}
	fillValue += l; /* Add in OUR overhead */
	fillPtr = localMemoryImage + EXECUTION_IMAGE_SIZE_OFFSET;
	SAVE_BIG_ENDIAN(fillValue,fillPtr);
	/* Calculate offset (from byte 0) to entry point */
	fillValue = myEhdr->e_entry - textShdr->sh_addr + MAIN_HEADER_SIZE;
	fillPtr = localMemoryImage + ENTRY_POINT_OFFSET;
	SAVE_BIG_ENDIAN(fillValue,fillPtr);
	/* Calculate offset to encryption block */
	fillValue = m + ENCRYPTED_KEY_HEADER_OFFSET;
	fillPtr = localMemoryImage + ENCRYPTION_INFO_OFFSET;
	SAVE_BIG_ENDIAN(fillValue,fillPtr);
	/* Calculate offset to signature block */
	fillValue = m + n + DIGITAL_SIGNATURE_HEADER_OFFSET;
	fillPtr = localMemoryImage + SIGNATURE_INFO_OFFSET;
	SAVE_BIG_ENDIAN(fillValue,fillPtr);
	/* Copy the .text section to the memory image */
	fillPtr = localMemoryImage + l;
	memcpy(fillPtr,textData->d_buf,textShdr->sh_size);

	/* Create the encryption block */
	if (encryptInfo->encryptSize != 0) {
		/* Save new offset to encrypted section */
		fillValue = encryptInfo->encryptOffset + l;
		fillPtr = localMemoryImage + m + OFFSET_ENCRYPTED_SECTION_OFFSET;
		SAVE_BIG_ENDIAN(fillValue,fillPtr);
		/* Save size of encrypted section */
		fillPtr = localMemoryImage + m + SIZE_ENCRYPTED_SECTION_OFFSET;
		SAVE_BIG_ENDIAN(encryptInfo->encryptSize,fillPtr);
		/* Save size of encrypted key */
		fillPtr = localMemoryImage + m + SIZE_ENCRYPTED_KEY_OFFSET;
		SAVE_BIG_ENDIAN(encryptInfo->encryptedKeySize,fillPtr);
		/* Save size of encryption block */
		fillValue = n;
		fillPtr = localMemoryImage + m + SIZE_ENCRYPTED_KEY_SECTION_OFFSET;
		SAVE_BIG_ENDIAN(fillValue,fillPtr);
		/* Save encrypted key */
		fillPtr = localMemoryImage + m + ENCRYPTED_KEY_SECTION_OFFSET;
		memcpy(fillPtr,encryptInfo->encryptedKey,encryptInfo->encryptedKeySize);
	}
	else {
		/* Save 0's in first 4 items */
		fillPtr = localMemoryImage + m + ENCRYPTED_KEY_HEADER_OFFSET;
		memset(fillPtr,0,16);
	}

	/* Create the signature block */
	fillValue = m + n + p + SIZE_OF_HEADERS;
	fillPtr = localMemoryImage + m + n + OFFSET_DIGITAL_SIGNATURE_OFFSET;
	SAVE_BIG_ENDIAN(fillValue,fillPtr);
	fillPtr = localMemoryImage + m + n + SIZE_DIGITAL_SIGNATURE_OFFSET;
	SAVE_BIG_ENDIAN(signatureInfo->signatureSize,fillPtr);
	fillValue = m + n + p + p1p + SIZE_OF_HEADERS;
	fillPtr = localMemoryImage + m + n + OFFSET_PUBLIC_KEY_CERTIFICATE_OFFSET;
	SAVE_BIG_ENDIAN(fillValue,fillPtr);
	fillPtr = localMemoryImage + m + n + SIZE_PUBLIC_KEY_CERTIFICATE_OFFSET;
	SAVE_BIG_ENDIAN(signatureInfo->publicCertSize,fillPtr);
	fillPtr = localMemoryImage + m + n + p + SIZE_OF_HEADERS;
	memcpy(fillPtr,signatureInfo->signature,signatureInfo->signatureSize);
	fillPtr = localMemoryImage + m + n + p + p1p + SIZE_OF_HEADERS;
	memcpy(fillPtr,signatureInfo->publicCert,signatureInfo->publicCertSize);

	signatureInfo->startOffset = 0;
	signatureInfo->length = m+n+SIZE_OF_HEADERS;
	signatureInfo->storeOffset = m+n+p+SIZE_OF_HEADERS;

	*memoryImage = localMemoryImage;
	*memoryImageSize = localImageSize;
	
	/* Update .text section for SPE Memory Image */
	textShdr->sh_addr = LOAD_ADDR;
	textShdr->sh_size = localImageSize;
	textShdr->sh_data->d_buf = localMemoryImage;
	textShdr->sh_data->d_size = localImageSize;
	
	/* Update Program Header for SPE Memory Image */
	(*myPhdr)->p_vaddr = LOAD_ADDR;
	(*myPhdr)->p_paddr = LOAD_ADDR;
	(*myPhdr)->p_filesz = localImageSize;
	(*myPhdr)->p_memsz = localImageSize;

err02:
	/* Error after localMemoryImage = malloc(localImageSize) */
	if (rc != 0)
		free(localMemoryImage);
err01:
	return rc;
}
