/* --------------------------------------------------------------- */
/* (C) Copyright 2006,2007,                                        */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* THIS PROGRAM IS PROVIDED UNDER THE TERMS OF THE COMMON PUBLIC   */
/* LICENSE VERSION 1 ("AGREEMENT"). ANY USE, REPRODUCTION OR       */
/* DISTRIBUTION OF THE PROGRAM CONSTITUTES RECIPIENT'S ACCEPTANCE  */
/* OF THIS AGREEMENT.                                              */
/*                                                                 */
/* A copy of the Agreement accompanies this distribution, or see   */
/* <http://www.ibm.com/developerworks/library/os-cpl.html>.        */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

/*********************************************************************
*                                                                    *
* Build the memory image for an SPU application.                     *
*                                                                    *
*********************************************************************/

#include <stddef.h>         // NULL, other ANSI-C types
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "buildSecureApp.h"

#define ALL_SECTIONS "ALL"

#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rand.h>
#include <openssl/rsa.h>
#include <openssl/x509.h>

#if defined(DEBUG)
char* hexchars[256] = {
	"00", "01", "02", "03", "04", "05", "06", "07",
	"08", "09", "0a", "0b", "0c", "0d", "0e", "0f",
	"10", "11", "12", "13", "14", "15", "16", "17",
	"18", "19", "1a", "1b", "1c", "1d", "1e", "1f",
	"20", "21", "22", "23", "24", "25", "26", "27",
	"28", "29", "2a", "2b", "2c", "2d", "2e", "2f",
	"30", "31", "32", "33", "34", "35", "36", "37",
	"38", "39", "3a", "3b", "3c", "3d", "3e", "3f",
	"40", "41", "42", "43", "44", "45", "46", "47",
	"48", "49", "4a", "4b", "4c", "4d", "4e", "4f",
	"50", "51", "52", "53", "54", "55", "56", "57",
	"58", "59", "5a", "5b", "5c", "5d", "5e", "5f",
	"60", "61", "62", "63", "64", "65", "66", "67",
	"68", "69", "6a", "6b", "6c", "6d", "6e", "6f",
	"70", "71", "72", "73", "74", "75", "76", "77",
	"78", "79", "7a", "7b", "7c", "7d", "7e", "7f",
	"80", "81", "82", "83", "84", "85", "86", "87",
	"88", "89", "8a", "8b", "8c", "8d", "8e", "8f",
	"90", "91", "92", "93", "94", "95", "96", "97",
	"98", "99", "9a", "9b", "9c", "9d", "9e", "9f",
	"a0", "a1", "a2", "a3", "a4", "a5", "a6", "a7",
	"a8", "a9", "aa", "ab", "ac", "ad", "ae", "af",
	"b0", "b1", "b2", "b3", "b4", "b5", "b6", "b7",
	"b8", "b9", "ba", "bb", "bc", "bd", "be", "bf",
	"c0", "c1", "c2", "c3", "c4", "c5", "c6", "c7",
	"c8", "c9", "ca", "cb", "cc", "cd", "ce", "cf",
	"d0", "d1", "d2", "d3", "d4", "d5", "d6", "d7",
	"d8", "d9", "da", "db", "dc", "dd", "de", "df",
	"e0", "e1", "e2", "e3", "e4", "e5", "e6", "e7",
	"e8", "e9", "ea", "eb", "ec", "ed", "ee", "ef",
	"f0", "f1", "f2", "f3", "f4", "f5", "f6", "f7",
	"f8", "f9", "fa", "fb", "fc", "fd", "fe", "ff"
};
char* hexstring(const void * argbytes, const int argsize) {
	unsigned char* argchars = (unsigned char *) argbytes;
	unsigned char * buffer;
	unsigned char * bufptr;
	int i,j,k;
	if (argsize<0) {
		PRINTF(("Failure: hexstring - argsize = %d\n",argsize));
		return NULL;
	}
	if (argbytes == NULL) {
		PRINTF(("Failure: hexstring - argbytes is NULL\n"));
		return NULL;
	}
	if ((buffer = (unsigned char*)malloc(argsize*3+1)) == NULL) {
		PRINTF(("Failure: hexstring - malloc returned NULL\n"));
		return "";
	}
	bufptr = buffer;
	j = 0;
	k = 0;
	for (i=0; i<argsize; i++) {
		*bufptr = (hexchars[*argchars])[0];
		bufptr++;
		*bufptr = (hexchars[*argchars])[1];
		bufptr++;
		argchars++;
		j++;
		if (j==4) {
			k++;
			if (k==5) {
				*bufptr++ = '\n';
				k = 0;
			}
			else {
				*bufptr++ = ' ';
			}
			j = 0;
		}
	}
	*bufptr = '\0';
	return (char*)buffer;
}
#endif // DEBUG

int help(const char* name)
{
	PRINTF(("Usage: %s <infile> <outfile> <signKey> <signCert> [<encryptSec> <kernelKey>]\n",name));
	PRINTF(("where\n"));
	PRINTF(("    infile       is the name of the input file (SPE ELF executable)\n"));
	PRINTF(("    outfile      is the name of the output file (secure SPE ELF executable)\n"));
	PRINTF(("    signKey      is the name of the file containing the user private key for signing\n"));
	PRINTF(("    signCert     is the name of the file containing the signed X.509 public key certificate\n"));
	PRINTF(("                  for certifying the digital signature of the file\n"));
	PRINTF(("    encryptSec   is the name of the section to encrypt or ALL if all\n"));
	PRINTF(("    kernelKey    is the name of the file containing the kernel public key for encryption\n"));
	return 1;
}

char* rsaPrivateKeyHeader = "-----BEGIN RSA PRIVATE KEY-----";
int rsaPrivateKeyHeaderLen = 31; /* strlen(rsaPrivateKeyHeader) */
char* rsaPrivateKeyTrailer = "-----END RSA PRIVATE KEY-----";
int rsaPrivateKeyTrailerLen = 29; /* strlen(rsaPrivateKeyTrailer) */
char* rsaPublicCertHeader = "-----BEGIN CERTIFICATE-----";
int rsaPublicCertHeaderLen = 27; /* strlen(rsaPublicCertHeader) */
char* rsaPublicCertTrailer = "-----END CERTIFICATE-----";
int rsaPublicCertTrailerLen = 25; /* strlen(rsaPublicCertTrailer) */
char* rsaPublicKeyHeader = "-----BEGIN PUBLIC KEY-----";
int rsaPublicKeyHeaderLen = 26; /* strlen(rsaPublicKeyHeader) */
char* rsaPublicKeyTrailer = "-----END PUBLIC KEY-----";
int rsaPublicKeyTrailerLen = 24; /* strlen(rsaPublicKeyTrailer) */

int main (int argc, const char** argv)
{
	MyElf32_Shdr*	bssShdr = NULL;
	const char*		certFilename = NULL;
	unsigned char	encryptKey[ENCRYPTION_KEY_SIZE] =
		{'\0','\0','\0','\0','\0','\0','\0','\0',
		 '\0','\0','\0','\0','\0','\0','\0','\0'};
	EncryptInfo		encryptSectionInfo = {0, 0, encryptKey, ENCRYPTION_KEY_SIZE, NULL, 0, NULL, 0, NULL, 0};
	const char*		encryptSectionName = NULL;
	MyElf32_Shdr*	encryptShdr = NULL;
	const char*		inFilename = NULL;
	const char*		kernelKeyFilename = NULL;
	int             kernelPublicKeySize = 0;
	unsigned char*	memoryImage = NULL;
	int				memoryImageSize = 0;
	int				newFile = 0;
	void*			newStrtab = NULL;
	unsigned char	nonce[8] =
		{'\0','\0','\0','\0','\0','\0','\0','\0'};
	int				oldFile = 0;
	const char*		outFilename = NULL;
	int				rc = 0;
    int             rsaPrivateSignSize = 0;
	SignatureInfo	signatureInfo = {NULL, 0, NULL, 0, NULL, 0, 0, 0, 0};
	const char*		signingKeyFilename = NULL;

	unsigned long	errSsl;
	char			errString[120];
	RSA*			kernelPublicKey = NULL;
	RSA*			rsaPrivateSign = NULL;
	void*			userPublicCert = NULL;

	/* This is the significant data from the current SPE ELF executable */
	Elf*			elf = NULL;
	MyElf32_Ehdr	myEhdr;
	MyElf32_Phdr**	myPhdr;
	MyElf32_Shdr**	myShdr = NULL;
	MyElf32_Shdr*	newTextShdr = NULL;
	char*			newTextDataBuf = NULL;
	Elf32_Word		newTextDataSize = 0;

	if ((argc != 5) && (argc != 7)) {
		rc = help(argv[0]);
		goto err01;
	}
	inFilename = argv[1];
	outFilename = argv[2];
	signingKeyFilename = argv[3];
	certFilename = argv[4];
	if (argc > 5) {
		encryptSectionName = argv[5];
		kernelKeyFilename = argv[6];
	}
	else {
		encryptSectionName = NULL;
		kernelKeyFilename = NULL;
	}

	/* Initialize crypto package */
	/* Load openssl error strings */
	ERR_load_crypto_strings();

	/* Generate encryption key */
	if (RAND_bytes(encryptKey,ENCRYPTION_KEY_SIZE) != 1) {
		PRINTF(("Failure: unable to generate random encryption key\n"));
		while ((errSsl = ERR_get_error()) != 0) {
			PRINTF(("RAND_bytes(16) -> %s\n",ERR_error_string(errSsl,errString)));
		}
		rc = -1;
		goto err01;
	}

	/* Generate nonce */
	if (RAND_bytes(nonce,8) != 1) {
		PRINTF(("Failure: unable to generate nonce\n"));
		while ((errSsl = ERR_get_error()) != 0) {
			PRINTF(("RAND_bytes(8) -> %s\n",ERR_error_string(errSsl,errString)));
		}
		rc = -2;
		goto err01;
	}

	/* Open the existing ELF file */
	if ((oldFile = open(inFilename, O_RDONLY)) == -1) {
		PRINTF(("Failure: open returned %d (0x%X) for file %s.\n",errno,errno,inFilename));
		PRINTF(("%s\n",strerror(errno)));
		help(argv[0]);
		rc = -3;
		goto err01;
	}

	/* Read user private RSA signing key */
	{
		unsigned char*	keyBuffer;
		int				keyBufferSize;
		if ((rc = readfile(signingKeyFilename,(void**)(&keyBuffer),&keyBufferSize)) != 0) {
			goto err02;
		}
		keyBufferSize = pem2der(keyBuffer,keyBufferSize,keyBuffer,keyBufferSize,rsaPrivateKeyHeader,rsaPrivateKeyHeaderLen,rsaPrivateKeyTrailer,rsaPrivateKeyTrailerLen);
		if (keyBufferSize < 0) {
			PRINTF(("Failure: unable to read RSA private key %d (0x%X)\n",keyBufferSize,keyBufferSize));
			rc = -4;
		}
		{
			unsigned char* buffer = keyBuffer;
			rsaPrivateSign = d2i_RSAPrivateKey(&rsaPrivateSign,(const unsigned char**)&buffer,keyBufferSize);
			if (!rsaPrivateSign) {
				PRINTF(("Failure: unable to read RSA private key\n"));
				while ((errSsl = ERR_get_error()) != 0) {
					PRINTF(("d2i_RSAPrivateKey() -> %s\n",ERR_error_string(errSsl,errString)));
				}
				rc = -5;
			}
		}
		free(keyBuffer);
		if (rc != 0)
			goto err02;
	}
	signatureInfo.privateKey = rsaPrivateSign;
	signatureInfo.privateKeySize = rsaPrivateSignSize;

	/* Read user x.509 certificate for verifying the digital signature */
	{
		unsigned char*	keyBuffer;
		int				keyBufferSize;
		if ((rc = readfile(certFilename,(void**)&keyBuffer,&keyBufferSize)) != 0) {
			goto err03;
		}
		signatureInfo.publicCert = keyBuffer;
		signatureInfo.publicCertSize = keyBufferSize;
		signatureInfo.publicCertSize = pem2der(keyBuffer,keyBufferSize,keyBuffer,keyBufferSize,rsaPublicCertHeader,rsaPublicCertHeaderLen,rsaPublicCertTrailer,rsaPublicCertTrailerLen);
		if (keyBufferSize < 0) {
			PRINTF(("Failure: unable to read RSA public key certificate\n"));
			rc = -6;
			goto err04;
		}
		/* Verify that we did read an X.509 certificate */
		if((userPublicCert = (void*)d2i_X509((X509**)&userPublicCert,(const unsigned char**)(&keyBuffer),keyBufferSize)) < 0) {
			PRINTF(("Failure: unable to read RSA public key certificate\n"));
			rc = -7;
			goto err04;
		}
		free(userPublicCert);
		userPublicCert = NULL;
	}

	/* Read kernel public RSA encryption key */
	if (kernelKeyFilename != NULL) {
		{
			unsigned char*	keyBuffer;
			int				keyBufferSize;
			if ((rc = readfile(kernelKeyFilename,(void**)&keyBuffer,&keyBufferSize)) != 0) {
				goto err04;
			}
			keyBufferSize = pem2der(keyBuffer,keyBufferSize,keyBuffer,keyBufferSize,rsaPublicKeyHeader,rsaPublicKeyHeaderLen,rsaPublicKeyTrailer,rsaPublicKeyTrailerLen);
			if (keyBufferSize < 0) {
				PRINTF(("Failure: unable to read kernel public key\n"));
				rc = -6;
				goto err04;
			}
			{
				unsigned char* buffer = keyBuffer;
				kernelPublicKey = d2i_RSA_PUBKEY(&kernelPublicKey,(const unsigned char**)&buffer,keyBufferSize);
				if (!kernelPublicKey) {
					PRINTF(("Failure: unable to read kernel public key\n"));
					while ((errSsl = ERR_get_error()) != 0) {
						PRINTF(("d2i_RSAPublicKey() -> %s\n",ERR_error_string(errSsl,errString)));
					}
					rc = -7;
				}
			}
		}
		encryptSectionInfo.kernelPublicKey = kernelPublicKey;
		encryptSectionInfo.kernelPublicKeySize = kernelPublicKeySize;
		encryptSectionInfo.userPublicCert = signatureInfo.publicCert;
		encryptSectionInfo.userPublicCertSize = signatureInfo.publicCertSize;
	}

	/* Read the existing SPE ELF executable */
	if ((rc = readElf(oldFile,&elf,&myEhdr,&myPhdr,&myShdr)) != 0) {
		goto err05;
	}

	/* Create the structures for the secure SPE ELF executable */
	/* If a particular section is specified for encryption, find the start and size */
	if ((encryptSectionName != NULL) && (strcmp(encryptSectionName,ALL_SECTIONS) != 0)) {
		if ((rc = findSection(myShdr,(char*)encryptSectionName,&encryptShdr)) != 0) {
			goto err06;
		}
		if ((encryptShdr->sh_flags & SHF_ALLOC) == 0) {
			PRINTF(("Failure: specified section, %s, is not an ALLOC'ed section\n",encryptSectionName));
			rc = -13;
			goto err06;
		}
		if ((encryptShdr->sh_data == NULL) || (encryptShdr->sh_data->d_buf == NULL)) {
			PRINTF(("Failure: specified section, %s, does not have any associated code or initialized data\n",encryptSectionName));
			rc = -14;
			goto err06;
		}
		encryptSectionInfo.encryptOffset = encryptShdr->sh_addr;
		encryptSectionInfo.encryptSize = encryptShdr->sh_size;
	}

	/* Combine all allocatable (except .bss) sections into a single .text section */
	if ((rc = combineSections(&myEhdr,myPhdr,myShdr,&newTextShdr,&newTextDataBuf,&newTextDataSize,&bssShdr)) != 0) {
		goto err06;
	}

	/* If a particular section is specified for encryption, find the start and size */
	if ((encryptSectionName != NULL) && (strcmp(encryptSectionName,ALL_SECTIONS) == 0)) {
		encryptSectionName = ".text";
		if ((rc = findSection(myShdr,(char*)encryptSectionName,&encryptShdr)) != 0) {
			goto err07;
		}
		if ((encryptShdr->sh_flags & SHF_ALLOC) == 0) {
			PRINTF(("Failure: specified section, %s, is not an ALLOC'ed section\n",encryptSectionName));
			rc = -15;
			goto err07;
		}
		if ((encryptShdr->sh_data == NULL) || (encryptShdr->sh_data->d_buf == NULL)) {
			PRINTF(("Failure: specified section, %s, does not have any associated code or initialized data\n",encryptSectionName));
			rc = -16;
			goto err07;
		}
		encryptSectionInfo.encryptOffset = encryptShdr->sh_addr;
		encryptSectionInfo.encryptSize = encryptShdr->sh_size;
	}

	/* Encrypt the specified section (if requested) */
	if (encryptSectionInfo.encryptSize > 0) {
		if ((rc = encryptSection(newTextShdr,(unsigned char*) newTextDataBuf,newTextDataSize,&encryptSectionInfo)) != 0) {
			goto err07;
		}
	}

	if ((rc = prepareSignature(&signatureInfo)) != 0) {
		goto err07a;
	}

	if ((rc = buildMemoryImage(nonce,&myEhdr,myPhdr,newTextShdr,bssShdr,&encryptSectionInfo,&signatureInfo,&memoryImage,&memoryImageSize)) != 0) {
		goto err08;
	}

	/* Add digital signature over code */
	if ((rc = addSignature(memoryImage,memoryImageSize,&signatureInfo)) != 0) {
		goto err09;
	}

	if ((rc = addSectionNames(myShdr,myEhdr.e_shstrndx,&newStrtab)) != 0) {
		goto err09;
	}

	/* Create the new file for the secure SPE ELF executable */
	if ((newFile = open(outFilename, O_WRONLY|O_CREAT|O_TRUNC)) == -1) {
		PRINTF(("Failure: open returned %d (0x%X) for file %s.\n",errno,errno,outFilename));
		PRINTF(("%s\n",strerror(errno)));
		help(argv[0]);
		rc = -17;
		goto err10;
	}
	if (chmod(outFilename,(mode_t) (S_IRWXU|S_IRWXG)) != 0) {
		PRINTF(("Failure: could not change permissions on file, %d (0x%X)\n",errno,errno));
		PRINTF(("%s\n",strerror(errno)));
		rc = -19;
		goto err11;
	}

	/* Finally, write out the new secure SPE ELF executable */
	rc = writeElf(newFile,&myEhdr,myPhdr,myShdr);

#if defined(DEBUG)
	if (rc == 0) {
		PRINTF(("Done!\n"));
	}
#endif // DEBUG

err11:
	/* Error after open(outFilename, O_WRONLY|O_CREAT|O_TRUNC) */
	close(newFile);
err10:
	/* Error after addSectionNames(myShdr,&newStrtab) */
	if (newStrtab != NULL)
		free(newStrtab);
err09:
	/* Error after buildMemoryImage(...) */
	if (memoryImage != NULL)
		free(memoryImage);
err08:
	/* Error after prepareSignature(&signatureInfo) */
	if (signatureInfo.signature != NULL)
		free(signatureInfo.signature);
err07a:
	/* Error after encryptSection(newTextShdr,(unsigned char*) newTextDataBuf,newTextDataSize,&encryptSectionInfo) */
	if (encryptSectionInfo.encryptedKey != NULL)
		free(encryptSectionInfo.encryptedKey);
err07:
	/* Error after combineSections(...) */
	if (newTextDataBuf != NULL)
		free(newTextDataBuf);
err06:
	/* Error after readElf(oldFile,&elf,&myEhdr,&myPhdr,&myShdr) */
	if (elf != NULL)
		elf_end(elf);
	if (myPhdr != NULL)
		free(myPhdr);
	if (myShdr != NULL)
		free(myShdr);
err05:
	/* Error after kernelPublicKey = PEM_read_RSAPublicKey(file,NULL,NULL,NULL) */
	if (kernelPublicKey != NULL) {
		RSA_free(kernelPublicKey);
	}
err04:
	/* Error after signatureInfo.publicCert = malloc(signatureInfo.publicCertSize) */
	if (signatureInfo.publicCert != NULL)
		free(signatureInfo.publicCert);
err03:
	/* Error after rsaPrivateSign = PEM_read_PrivateKey(file,NULL,NULL,NULL) */
	if (rsaPrivateSign != NULL) {
		RSA_free(rsaPrivateSign);
	}
err02:
	/* Error after open(inFilename, O_RDONLY) */
	close(oldFile);
err01:
	if (rc != 0) {
		PRINTF(("Failure: return code = %d\n",rc));
	}
	return rc;
}
