/* --------------------------------------------------------------- */
/* (C) Copyright 2006,2008,                                        */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* THIS PROGRAM IS PROVIDED UNDER THE TERMS OF THE COMMON PUBLIC   */
/* LICENSE VERSION 1 ("AGREEMENT"). ANY USE, REPRODUCTION OR       */
/* DISTRIBUTION OF THE PROGRAM CONSTITUTES RECIPIENT'S ACCEPTANCE  */
/* OF THIS AGREEMENT.                                              */
/*                                                                 */
/* A copy of the Agreement accompanies this distribution, or see   */
/* <http://www.ibm.com/developerworks/library/os-cpl.html>.        */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

#ifndef DEBUG_H_
#define DEBUG_H_

/* #define PRINTF(x) (printf x, fflush(stdout)) */
#define PRINTF(x) printf x

#if defined(DEBUG)
#define DEBUGP(x) PRINTF(x)
extern char* hexchars[];
extern char* hexstring(const void * argbytes, const int argsize);
#else // DEBUG
#define DEBUGP(x)
#endif // DEBUG

#endif /*DEBUG_H_*/
