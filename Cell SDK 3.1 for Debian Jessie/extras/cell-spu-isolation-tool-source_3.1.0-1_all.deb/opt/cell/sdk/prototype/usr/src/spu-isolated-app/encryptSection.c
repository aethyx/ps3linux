/* --------------------------------------------------------------- */
/* (C) Copyright 2006,2008,                                        */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* THIS PROGRAM IS PROVIDED UNDER THE TERMS OF THE COMMON PUBLIC   */
/* LICENSE VERSION 1 ("AGREEMENT"). ANY USE, REPRODUCTION OR       */
/* DISTRIBUTION OF THE PROGRAM CONSTITUTES RECIPIENT'S ACCEPTANCE  */
/* OF THIS AGREEMENT.                                              */
/*                                                                 */
/* A copy of the Agreement accompanies this distribution, or see   */
/* <http://www.ibm.com/developerworks/library/os-cpl.html>.        */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

/*********************************************************************
*                                                                    *
* Encrypt the .text section, starting at the specified offset and    *
* with the specified size. Correct the offset and size for the       *
* required cipher block size.                                        *
*                                                                    *
*********************************************************************/

#include <stddef.h>		 // NULL, other ANSI-C types
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

#include "buildSecureApp.h"

#include <openssl/aes.h>
#include <openssl/err.h>
#include <openssl/x509.h>

int encryptSection(MyElf32_Shdr* encryptShdr, unsigned char* data, Elf32_Word size, EncryptInfo* encryptInfo)
{
	unsigned char*	encryptedKey = NULL;
	int				encryptedKeySize = 0;
	Elf32_Off		endOffset;
	unsigned char	hash[SHA_DIGEST_LENGTH];
	int				i;
	unsigned char	ivec[AES_BLOCK_SIZE];
	unsigned char*	modKey = NULL;
	Elf32_Off		offset;
	int				rc = 0;
	Elf32_Off		startOffset;
	AES_KEY			aesKey;
	unsigned long	errSsl;
	char			errString[120];

	if (encryptInfo->encryptKeySize != ENCRYPTION_KEY_SIZE) {
		PRINTF(("Failure: internal error\n"));
		rc = -901;
		goto err01;
	}
	offset = encryptInfo->encryptOffset - encryptShdr->sh_addr;
	startOffset = ROUND_DOWN(offset,AES_BLOCK_SIZE);
	endOffset = offset + encryptInfo->encryptSize;
	endOffset = ROUND_UP(endOffset,AES_BLOCK_SIZE);
	if ((startOffset < 0) || (endOffset > size)) {
		PRINTF(("Failure: internal error\n"));
		rc = -902;
		goto err01;
	}

	if ((rc = AES_set_encrypt_key(encryptInfo->encryptKey,ENCRYPTION_KEY_SIZE_BITS,&aesKey)) != 0) {
		PRINTF(("Failure: unable to set AES encryption key\n"));
		while ((errSsl = ERR_get_error()) != 0) {
			PRINTF(("AES_set_encrypt_key -> %s\n",ERR_error_string(errSsl,errString)));
		}
		rc = -905;
		goto err01;
	}
	memset(ivec,0,AES_BLOCK_SIZE);
	AES_cbc_encrypt(data+startOffset,data+startOffset,endOffset-startOffset,&aesKey,ivec,AES_ENCRYPT);
	if (ERR_peek_error() != 0) {
		PRINTF(("Failure: error while encrypting requested section\n"));
		while ((errSsl = ERR_get_error()) != 0) {
			PRINTF(("AES_cbc_encrypt(E) -> %s\n",ERR_error_string(errSsl,errString)));
		}
		rc = -906;
		goto err02;
	}

	/* Encrypt the code encryption key */
	/* modKey = key XOR hash[0..15] XOR (0...0 || hash[16..19]) */
	if (SHA1(encryptInfo->userPublicCert,encryptInfo->userPublicCertSize,hash) == NULL) {
		PRINTF(("Failure: internal error in SHA-1 hash computation\n"));
		while ((errSsl = ERR_get_error()) != 0) {
			PRINTF(("SHA1() -> %s\n",ERR_error_string(errSsl,errString)));
		}
		rc = -909;
		goto err02;
	}
	if ((modKey = malloc(encryptInfo->encryptKeySize)) == NULL) {
		PRINTF(("Failure: unable to malloc %d bytes\n",encryptInfo->encryptKeySize));
		rc = -910;
		goto err02;
	}
	memcpy(modKey,encryptInfo->encryptKey,encryptInfo->encryptKeySize);
	if ((encryptInfo->encryptKeySize != ENCRYPTION_KEY_SIZE) || (ENCRYPTION_KEY_SIZE != 16) || (SHA_DIGEST_LENGTH != 20)) {
		PRINTF(("Failure: internal error\n"));
		rc = -911;
		goto err03;
	}
	/* The sizes of the data are verified above */
	for (i=0; i<16; i++) {
		modKey[i] ^= hash[i];
	}
	for (i=12; i<16; i++) {
		modKey[i] ^= hash[i+4];
	}
	encryptedKeySize = RSA_size(encryptInfo->kernelPublicKey);
	if ((encryptedKey = malloc(encryptedKeySize)) == NULL) {
		PRINTF(("Failure: unable to malloc %d bytes\n",encryptedKeySize));
		rc = -912;
		goto err03;
	}
	memset(encryptedKey,0,encryptedKeySize);
	if ((encryptedKeySize = RSA_public_encrypt(encryptInfo->encryptKeySize,modKey,encryptedKey,(RSA*)encryptInfo->kernelPublicKey,RSA_PKCS1_PADDING)) < 0) {
		PRINTF(("Failure: unable to sign digest of memory image\n"));
		while ((errSsl = ERR_get_error()) != 0) {
			PRINTF(("RSA_sign() -> %s\n",ERR_error_string(errSsl,errString)));
		}
		rc = -914;
		goto err04;
	}
	encryptInfo->encryptedKey = encryptedKey;
	encryptInfo->encryptedKeySize = encryptedKeySize;

	encryptInfo->encryptOffset = startOffset;
	encryptInfo->encryptSize = endOffset - startOffset;

err04:
	if ((rc != 0) && (encryptedKey != NULL))
		free(encryptedKey);
err03:
	if (modKey != NULL)
		free(modKey);
err02:
err01:
	return rc;
}
