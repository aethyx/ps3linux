/* --------------------------------------------------------------- */
/* (C) Copyright 2006,2008,                                        */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* THIS PROGRAM IS PROVIDED UNDER THE TERMS OF THE COMMON PUBLIC   */
/* LICENSE VERSION 1 ("AGREEMENT"). ANY USE, REPRODUCTION OR       */
/* DISTRIBUTION OF THE PROGRAM CONSTITUTES RECIPIENT'S ACCEPTANCE  */
/* OF THIS AGREEMENT.                                              */
/*                                                                 */
/* A copy of the Agreement accompanies this distribution, or see   */
/* <http://www.ibm.com/developerworks/library/os-cpl.html>.        */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

#ifndef MYELF_H_
#define MYELF_H_

typedef struct
{
	unsigned char	e_ident[EI_NIDENT];
	Elf32_Half		e_type;			/* Object file type */
	Elf32_Half		e_machine;		/* Architecture */
	Elf32_Word		e_version;		/* Object file version */
	Elf32_Addr		e_entry;		/* Entry point virtual address */
//	Elf32_Off		e_phoff;		/* Program header table file offset */
//	Elf32_Off		e_shoff;		/* Section header table file offset */
	Elf32_Word		e_flags;		/* Processor-specific flags */
//	Elf32_Half		e_ehsize;		/* ELF header size in bytes */
//	Elf32_Half		e_phentsize;	/* Program header table entry size */
	Elf32_Half		e_phnum;		/* Program header table entry count */
//	Elf32_Half		e_shentsize;	/* Section header table entry size */
	Elf32_Half		e_shnum;		/* Section header table entry count */
	Elf32_Half		e_shstrndx;		/* Section header string table index */
} MyElf32_Ehdr;
#define COPY_ELF_EHDR(A,B) { \
	memcpy(B->e_ident,A->e_ident,EI_NIDENT); \
	B->e_type = A->e_type; \
	B->e_machine = A->e_machine; \
	B->e_version = A->e_version; \
	B->e_entry = A->e_entry; \
	B->e_flags = A->e_flags; \
	B->e_phnum = A->e_phnum; \
	B->e_shnum = A->e_shnum; \
	B->e_shstrndx = A->e_shstrndx; \
}
#define DUMP_MYEHDR(A) { \
	PRINTF(("myEhdr\n")); \
	PRINTF(("\te_ident = 0x%s\n",hexstring(A->e_ident,EI_NIDENT))); \
	PRINTF(("\te_type = %d (0x%X)\n",A->e_type,A->e_type)); \
	PRINTF(("\te_machine = %d (0x%X)\n",A->e_machine,A->e_machine)); \
	PRINTF(("\te_version = %d (0X%X)\n",A->e_version,A->e_version)); \
	PRINTF(("\te_entry = 0x%X\n",A->e_entry)); \
	PRINTF(("\te_flags = 0x%X\n",A->e_flags)); \
	PRINTF(("\te_phnum = %d\n",A->e_phnum)); \
	PRINTF(("\te_shnum = %d\n",A->e_shnum)); \
	PRINTF(("\te_shstrndx = %d\n",A->e_shstrndx)); \
}

/* Additional e_machine values */
#define EM_CELLSPU	23

typedef struct
{
	Elf32_Word		p_type;			/* Segment type */
	Elf32_Off		p_offset;		/* Segment file offset */
	Elf32_Addr		p_vaddr;		/* Segment virtual address */
	Elf32_Addr		p_paddr;		/* Segment physical address */
	Elf32_Word		p_filesz;		/* Segment size in file */
	Elf32_Word		p_memsz;		/* Segment size in memory */
	Elf32_Word		p_flags;		/* Segment flags */
	Elf32_Word		p_align;		/* Segment alignment */
} MyElf32_Phdr;
#define COPY_ELF_PHDR(A,B) { \
	B->p_type = A->p_type; \
	B->p_offset = A->p_offset; \
	B->p_vaddr = A->p_vaddr; \
	B->p_paddr = A->p_paddr; \
	B->p_filesz = A->p_filesz; \
	B->p_memsz = A->p_memsz; \
	B->p_flags = A->p_flags; \
	B->p_align = A->p_align; \
}
#define DUMP_MYPHDR(A) { \
	PRINTF(("myPhdr\n")); \
	PRINTF(("\tp_type = 0x%X\n",A->p_type)); \
	PRINTF(("\tp_offset = 0x%X\n",(int)A->p_offset)); \
	PRINTF(("\tp_vaddr = 0x%X\n",A->p_vaddr)); \
	PRINTF(("\tp_paddr = 0x%X\n",A->p_paddr)); \
	PRINTF(("\tp_filesz = 0x%X\n",A->p_filesz)); \
	PRINTF(("\tp_memsz = 0x%X\n",A->p_memsz)); \
	PRINTF(("\tp_flags = 0x%X\n",A->p_flags)); \
	PRINTF(("\tp_align = 0x%X\n",A->p_align)); \
}

typedef struct
{
	void*			d_buf;			/* Data buffer */
	Elf_Type		d_type;			/* Type of data in buffer */
	unsigned int	d_version;		/* Version number */
	size_t			d_size;			/* Size, in bytes, of data in buffer */
	off_t			d_off;			/* Offset into section.  */
	size_t			d_align;		/* Required alignment of buffer */
} MyElf_Data;
#define COPY_ELF_DATA(A,B) { \
	B->d_buf = A->d_buf; \
	B->d_type = A->d_type; \
	B->d_version = A->d_version; \
	B->d_size = A->d_size; \
	B->d_off = A->d_off; \
	B->d_align = A->d_align; \
}
#define DUMP_MYDATA(A) { \
	PRINTF(("myData\n")); \
	if (A->d_buf == NULL) { \
		PRINTF(("\td_buf = NULL\n"))); \
	} \
	else { \
		PRINTF(("\td_buf = 0x%X\n",A->d_buf)); \
	} \
	PRINTF(("\td_type = %d (0x%X)\n",A->d_type,A->d_type)); \
	PRINTF(("\td_version = %d (0x%X)\n",A->d_version,A->d_version)); \
	PRINTF(("\td_size = %d (0x%X)\n",A->d_size,A->d_size)); \
	PRINTF(("\td_off = %d (0x%X)\n",(int)A->d_off,(int)A->d_off)); \
	PRINTF(("\td_align = %d (0x%X)\n",A->d_align,A->d_align)); \
}

typedef struct
{
	char*			sh_nameStr;		/* Section name - NOT string table index!! */
	Elf32_Word		sh_name;		/* Section name (string tbl index) */
	Elf32_Word		sh_type;		/* Section type */
	Elf32_Word		sh_flags;		/* Section flags */
	Elf32_Addr		sh_addr;		/* Section virtual addr at execution */
//	Elf32_Off		sh_offset;		/* Section file offset */
	Elf32_Word		sh_size;		/* Section size in bytes */
	Elf32_Word		sh_link;		/* Link to another section */
	Elf32_Word		sh_info;		/* Additional section information */
	Elf32_Word		sh_addralign;	/* Section alignment */
	Elf32_Word		sh_entsize;		/* Entry size if section holds table */
	MyElf_Data*		sh_data;		/* Section data (if it is non-NULL) */
} MyElf32_Shdr;
#define COPY_ELF_SHDR(A,B) { \
	B->sh_name = A->sh_name; \
	B->sh_type = A->sh_type; \
	B->sh_flags = A->sh_flags; \
	B->sh_addr = A->sh_addr; \
	B->sh_size = A->sh_size; \
	B->sh_link = A->sh_link; \
	B->sh_info = A->sh_info; \
	B->sh_addralign = A->sh_addralign; \
	B->sh_entsize = A->sh_entsize; \
}
#define DUMP_MYSHDR(A) { \
	PRINTF(("myShdr\n")); \
	if (A->sh_nameStr == NULL) { \
		PRINTF(("\tsh_nameStr = NULL\n")); \
	} \
	else { \
		PRINTF(("\tsh_nameStr = %s\n",A->sh_nameStr)); \
	} \
	PRINTF(("\tsh_name = %d (0x%X)\n",A->sh_name,A->sh_name)); \
	PRINTF(("\tsh_type = %d (0x%X)\n",A->sh_type,A->sh_type)); \
	PRINTF(("\tsh_flags = %d (0x%X)\n",A->sh_flags,A->sh_flags)); \
	PRINTF(("\tsh_addr = 0x%X\n",A->sh_addr)); \
	PRINTF(("\tsh_size = %d (0x%X)\n",A->sh_size,A->sh_size)); \
	PRINTF(("\tsh_link = %d (0x%X)\n",A->sh_link,A->sh_link)); \
	PRINTF(("\tsh_info = %d (0x%X)\n",A->sh_info,A->sh_info)); \
	PRINTF(("\tsh_addralign = %d (0x%X)\n",A->sh_addralign,A->sh_addralign)); \
	PRINTF(("\tsh_entsize = %d (0x%X)\n",A->sh_entsize,A->sh_entsize)); \
	if (A->sh_data == NULL) { \
		PRINTF(("\tsh_data = NULL\n"));\
	} \
	else { \
		PRINTF(("\tsh_data = 0x%X\n",(unsigned int) A->sh_data)); \
		if (A->sh_data->d_buf == NULL) { \
			PRINTF(("\t\td_buf = NULL\n")); \
		} \
		else { \
			PRINTF(("\t\td_buf = 0x%X\n",(unsigned int) A->sh_data->d_buf)); \
		} \
		PRINTF(("\t\td_type = %d (0x%X)\n",A->sh_data->d_type,A->sh_data->d_type)); \
		PRINTF(("\t\td_version = %d (0x%X)\n",A->sh_data->d_version,A->sh_data->d_version)); \
		PRINTF(("\t\td_size = %d (0x%X)\n",A->sh_data->d_size,A->sh_data->d_size)); \
		PRINTF(("\t\td_off = %d (0x%X)\n",(int)A->sh_data->d_off,(int)A->sh_data->d_off)); \
		PRINTF(("\t\td_align = %d (0x%X)\n",A->sh_data->d_align,A->sh_data->d_align)); \
	} \
}

/* Additional sh_type values */
#define SHT_CELL_SIGN (SHT_LOPROC | 0x01)
#define SHT_CELL_KEY (SHT_LOPROC | 0x02)

#endif /*MYELF_H_*/
