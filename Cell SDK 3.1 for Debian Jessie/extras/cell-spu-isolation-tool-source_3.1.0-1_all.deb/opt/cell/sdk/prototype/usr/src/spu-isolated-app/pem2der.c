/* --------------------------------------------------------------- */
/* (C) Copyright 2006,2008,                                        */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* THIS PROGRAM IS PROVIDED UNDER THE TERMS OF THE COMMON PUBLIC   */
/* LICENSE VERSION 1 ("AGREEMENT"). ANY USE, REPRODUCTION OR       */
/* DISTRIBUTION OF THE PROGRAM CONSTITUTES RECIPIENT'S ACCEPTANCE  */
/* OF THIS AGREEMENT.                                              */
/*                                                                 */
/* A copy of the Agreement accompanies this distribution, or see   */
/* <http://www.ibm.com/developerworks/library/os-cpl.html>.        */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

/*********************************************************************
*                                                                    *
* Convert a PEM encoded key to DER format                            *
*                                                                    *
*********************************************************************/

#include <stddef.h>         // NULL, other ANSI-C types
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "buildSecureApp.h"

int decodeDigit(int digit)
{
	if ((digit >= 'A') && (digit <= 'Z')) {
		return (digit - 'A');
	}
	if ((digit >= 'a') && (digit <= 'z')) {
		return (digit - 'a' + 26);
	}
	if ((digit >= '0') && (digit <= '9')) {
		return (digit - '0' + 52);
	}
	if (digit == '+')
		return 62;
	if (digit == '/')
		return 63;
	return 0x0ff;
}

/* Base 64 encoding is specified in RFC 1521 */
int base64decode(void* source, int sourceLen, void* target, int targetLen)
{
	unsigned int	allBits;
	int				chunks;
	int				i;
	int				j;
	int				lastDataByte;
	unsigned char*	localSource = (unsigned char*)source;
	unsigned char*	localTarget = (unsigned char*)target;
	int				padBytes;
	int				rc = 0;

	if ((sourceLen % 4) != 0) {
		PRINTF(("Failure: data for base64decode was not a multiple of 4 bytes (%d)\n",sourceLen));
		DEBUGP(("pem2der: source = %s\n",hexstring(source,sourceLen)));
		rc = -1201;
		goto err01;
	}
	/* skip over the required padding at the end */
	lastDataByte = sourceLen - 1;
	while (*(localSource+lastDataByte) == '=') {
		lastDataByte--;
	}
	padBytes = sourceLen - 1 - lastDataByte;
	if (targetLen < (sourceLen*6)/8 - padBytes) {
		PRINTF(("Failure: internal error\n"));
		rc = -1202;
		goto err01;
	}

	/* Each 4 bytes of input will result in 3 bytes of output */
	chunks = (lastDataByte + 1) / 4;
	for (i=0; i<chunks; i++) {
		allBits = 0;
		/* Loop 4 times for the input data (4 * 6 bits = 24 bits) */
		for (j=0; j<4; j++) {
			allBits = (allBits << 6) | decodeDigit(*localSource);
			localSource++;
		}
		/* Loop 3 times for the output data (3 * 8 bits = 24 bits), starting with last byte */
		for (j=2; j>=0; j--) {
			*(localTarget+j) = (unsigned char)(allBits & 0x0ff);
			allBits >>= 8;
		}
		localTarget += 3;
	}

	/* Now, deal with the pad characters */
	switch(padBytes) {
		case 1:
			/* 1 pad byte means 3 more real bytes (last 2 bits are not used) */
			allBits = 0;
			for (j=0; j<3; j++) {
				allBits = (allBits << 6) | decodeDigit(*localSource);
				localSource++;
			}
			allBits >>= 2;
			for (j=1; j>=0; j--) {
				*(localTarget+j) = (unsigned char)(allBits & 0x0ff);
				allBits >>= 8;
			}
			localTarget += 2;
			break;
		case 2:
			/* 2 pad bytes means 2 more real bytes (last 4 bits are not used) */
			allBits = 0;
			for (j=0; j<2; j++) {
				allBits = (allBits << 6) | decodeDigit(*localSource);
				localSource++;
			}
			allBits >>= 4;
			*localTarget = (unsigned char)(allBits & 0x0ff);
			localTarget++;
			break;
	}
	rc = localTarget - (unsigned char*)target;
	
err01:
	return rc;
}

int removeWhiteSpace(char* source, int sourceLen, char** target, int* targetLen)
{
	int		i;
	char*	localBuffer;
	char*	localSource;
	char*	localTarget;
	int		localTargetLen;
	int		rc = 0;

	*target = NULL;
	*targetLen = 0;
	localSource = source;
	localTargetLen = sourceLen;
	if ((localBuffer = malloc(sourceLen)) == NULL) {
		PRINTF(("Failure: unable to malloc %d bytes\n",sourceLen));
		rc = -1210;
		goto err01;
	}
	localTarget = localBuffer;
	for (i=0; i<sourceLen; i++) {
		if ((*localSource != '\n') && (*localSource != '\r') && (*localSource != ' ')) {
			/* Copy the significant character */
			*localTarget = *localSource;
			localTarget++;
		}
		localSource++;
	}
	localTargetLen = localTarget - localBuffer;
	if (localTargetLen <= 0) {
		PRINTF(("Failure: no information from PEM representation of key\n"));
		rc = -1211;
		goto err01;
	}
	*target = localBuffer;
	*targetLen = localTargetLen;

err01:
	return rc;
}

char* strnstr(char* haystack, char* needle, int len)
{
	char*			localHaystack = haystack;
	char*			localHaystackSubStr;
	char*			localNeedleSubStr;
	char			startNeedle;

	if ((haystack == NULL) || (needle == NULL))
		return NULL;
	startNeedle = *needle;
	if (startNeedle == '\0')
		return NULL;
	for (localHaystack=haystack; localHaystack<haystack+len; localHaystack++) {
		if (*localHaystack == startNeedle) {
			localHaystackSubStr=localHaystack+1;
			localNeedleSubStr=needle+1;
			while (1) {
				if (*localNeedleSubStr == '\0')
					goto result;
				if (*localHaystackSubStr != *localNeedleSubStr)
					break;
				localHaystackSubStr++;
				localNeedleSubStr++;
			}
		}
	}
	return NULL;

result:
	return localHaystack;
}

int convert2der(char* source, int sourceLen, char** target, int* targetLen, char* header, int headerLen, char* trailer, int trailerLen)
{
	char*	localIndex;
	char*	localSource;
	int		localSourceLen;
	char*	localTarget = NULL;
	int		localTargetLen = 0;
	int		rc = 0;

	if (sourceLen < headerLen) {
		PRINTF(("Failure: internal error\n"));
		rc = -1221;
		goto err01;
	}
	if ((localIndex = strnstr((char*)source,header,sourceLen)) == NULL) {
		PRINTF(("Failure: internal error\n"));
		rc = -1222;
		goto err01;
	}
	localSource = localIndex + headerLen;
	localSourceLen = sourceLen - (localSource - source);
	if ((localIndex = strnstr(localSource,trailer,localSourceLen)) == NULL) {
		PRINTF(("Failure: malformed PEM key\n"));
		rc = -1223;
		goto err01;
	}
	localSourceLen = localIndex - localSource;
	if ((rc = removeWhiteSpace(localSource,localSourceLen,&localTarget,&localTargetLen)) != 0) {
		goto err01;
	}
	if ((rc = base64decode(localTarget,localTargetLen,localTarget,localTargetLen)) > 0) {
		*target = localTarget;
		*targetLen = rc;
		rc = 0;
	}
	

// err02:
	if ((rc != 0) && (localTarget != NULL))
		free(localTarget);
err01:
	return rc;
}

int pem2der(void* source, int sourceLen, void* target, int targetLen, char* header, int headerLen, char* trailer, int trailerLen)
{
	char*	localTarget = NULL;
	int		localTargetLen = 0;
	int		rc = 0;

	if (strnstr((char*)source,header,sourceLen) != NULL) {
		if ((rc = convert2der((char*)source,sourceLen,&localTarget,&localTargetLen,header,headerLen,trailer,trailerLen)) != 0) {
			goto err01;
		}
		if (localTargetLen > targetLen) {
			PRINTF(("Failure: internal error\n"));
			rc = -1231;
			goto err02;
		}
		memcpy(target,localTarget,localTargetLen);
		rc = localTargetLen;
	}
	else {
		if (sourceLen > targetLen) {
			PRINTF(("Failure: internal error\n"));
			rc = -1232;
			goto err01;
		}
		memmove(target,source,sourceLen);
		rc = sourceLen;
	}

err02:
	if (localTarget != NULL)
		free(localTarget);
err01:
	return rc;
}
