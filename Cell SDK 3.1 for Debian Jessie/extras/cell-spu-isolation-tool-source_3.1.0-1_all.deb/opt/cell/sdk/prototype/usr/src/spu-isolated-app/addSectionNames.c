/* --------------------------------------------------------------- */
/* (C) Copyright 2006,2008,                                        */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* THIS PROGRAM IS PROVIDED UNDER THE TERMS OF THE COMMON PUBLIC   */
/* LICENSE VERSION 1 ("AGREEMENT"). ANY USE, REPRODUCTION OR       */
/* DISTRIBUTION OF THE PROGRAM CONSTITUTES RECIPIENT'S ACCEPTANCE  */
/* OF THIS AGREEMENT.                                              */
/*                                                                 */
/* A copy of the Agreement accompanies this distribution, or see   */
/* <http://www.ibm.com/developerworks/library/os-cpl.html>.        */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

/*********************************************************************
*                                                                    *
* Create a new STRTAB to hold any new section names                  *
*                                                                    *
*********************************************************************/

#include <stddef.h>		 // NULL, other ANSI-C types
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

#include "buildSecureApp.h"

int addSectionNames(MyElf32_Shdr** myShdr, Elf32_Half shstrndx, void** newStrData)
{
	MyElf32_Shdr**	localShdr;
	char*			newData = NULL;
	int				newStrSize = 0;
	int				rc = 0;
	MyElf_Data*		strData = NULL;
	char*			strDataBuf = NULL;
	int				strDataBufSize = 0;
	MyElf32_Shdr*	strShdr = NULL;

	*newStrData = NULL;

	if (shstrndx == 0) {
		/* STRTAB (section for string table) not found - this is not an error */
		goto err01;
	}
	strShdr = myShdr[shstrndx-1];

	localShdr = myShdr;
	while (*localShdr != NULL) {
		if ((*localShdr)->sh_name == 0) {
			/* This section name is not indexed in STRTAB */
			if ((*localShdr)->sh_nameStr != NULL) {
				newStrSize += strlen((*localShdr)->sh_nameStr)+1;
			}
		}
		localShdr++;
	}
	if (newStrSize <= 0) {
		/* No new section names to add */
		goto err01;
	}
	strData = strShdr->sh_data;
	if (strData == NULL) {
		PRINTF(("Failure: internal error\n"));
		rc = -501;
		goto err01;
	}
	strDataBufSize = strData->d_size + newStrSize;
	if ((strDataBuf = malloc(strDataBufSize)) == NULL) {
		PRINTF(("Failure: malloc failed on request for %d bytes.\n",strDataBufSize));
		rc = -502;
		goto err01;
	}
	memcpy(strDataBuf,strData->d_buf,strData->d_size);
	newData = strDataBuf + strData->d_size;

	localShdr = myShdr;
	while (*localShdr != NULL) {
		if ((*localShdr)->sh_name == 0) {
			/* This section name is not indexed in STRTAB */
			if ((*localShdr)->sh_nameStr != NULL) {
				newStrSize = strlen((*localShdr)->sh_nameStr)+1;
				memcpy(newData,(*localShdr)->sh_nameStr,newStrSize);
				(*localShdr)->sh_name = newData - strDataBuf;
				newData += newStrSize;
			}
		}
		localShdr++;
	}

	*newStrData = strDataBuf;
	strData->d_buf = strDataBuf;
	strData->d_size = strDataBufSize;
	strShdr->sh_size = strDataBufSize;
	
	/* Error after strDataBuf = malloc(strDataBufSize) */
	if (rc != 0)
		free(strDataBuf);
err01:
	return rc;
}
