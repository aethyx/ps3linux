/* --------------------------------------------------------------- */
/* (C) Copyright 2006,2008,                                        */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* THIS PROGRAM IS PROVIDED UNDER THE TERMS OF THE COMMON PUBLIC   */
/* LICENSE VERSION 1 ("AGREEMENT"). ANY USE, REPRODUCTION OR       */
/* DISTRIBUTION OF THE PROGRAM CONSTITUTES RECIPIENT'S ACCEPTANCE  */
/* OF THIS AGREEMENT.                                              */
/*                                                                 */
/* A copy of the Agreement accompanies this distribution, or see   */
/* <http://www.ibm.com/developerworks/library/os-cpl.html>.        */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

/*********************************************************************
*                                                                    *
* Update the offset field of the Program Headers to reflect any      *
* changes in the file												 *
*                                                                    *
*********************************************************************/

#include <stddef.h>		 // NULL, other ANSI-C types
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

#include "buildSecureApp.h"

int updatePgmHdr(Elf* elf)
{
	Elf32_Ehdr*		ehdr;
	int				elfErrno;
	int				noPhdr;
	int				noShdr;
	Elf32_Phdr*		phdr;
	Elf32_Word		phdrAddr;
	int				rc = 0;
	Elf_Scn*		scn;
	Elf32_Shdr*		shdr;

	int				i;
	int				j;

	/* Process the ELF header */
	if ((ehdr=elf32_getehdr(elf)) == NULL) {
		elfErrno = elf_errno();
		PRINTF(("Failure: elf32_getehdr returned %d (0x%X).\n",elfErrno,elfErrno));
		PRINTF(("%s\n",elf_errmsg(elfErrno)));
		rc = -801;
		goto err01;
	}
	noPhdr = ehdr->e_phnum;
	noShdr = ehdr->e_shnum;

	/* Process the program headers */
	if ((phdr = elf32_getphdr(elf)) == NULL) {
		elfErrno = elf_errno();
		PRINTF(("Failure: elf_getphdr returned NULL\n"));
		PRINTF(("%s\n",elf_errmsg(elfErrno)));
		rc = -802;
		goto err01;
	}
	for (i=0; i<noPhdr; i++) {
		phdrAddr = phdr[i].p_vaddr;
		for (j=1; j<noShdr; j++) {
			if ((scn = elf_getscn(elf,j)) == NULL) {
				elfErrno = elf_errno();
				PRINTF(("Failure: elf_getscn returned NULL for section %d\n",j));
				PRINTF(("%s\n",elf_errmsg(elfErrno)));
				rc = -803;
				goto err01;
			}
			if ((shdr=elf32_getshdr(scn)) == NULL) {
				elfErrno = elf_errno();
				PRINTF(("Failure: elf32_getshdr for section %d returned %d (0x%X).\n",j,elfErrno,elfErrno));
				PRINTF(("%s\n",elf_errmsg(elfErrno)));
				rc = -804;
				goto err01;
			}
			if (shdr->sh_addr == phdrAddr) {
				phdr->p_offset = shdr->sh_offset;
				break;
			}
		}
	}

err01:
	return rc;
}
