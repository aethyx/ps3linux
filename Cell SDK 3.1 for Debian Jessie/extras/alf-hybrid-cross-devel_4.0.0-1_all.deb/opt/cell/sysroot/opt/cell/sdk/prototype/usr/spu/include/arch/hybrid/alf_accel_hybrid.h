/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2007,2008, All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

#ifndef __ALF_ACCEL_HYBRID_H_INC__
#define __ALF_ACCEL_HYBRID_H_INC__

#define ALF_ACCEL_EXPORT_API_LIST_BEGIN             \
extern int _ALF_LINKAGE_SYMBOL_HYBRID;              \
int *p_linkage_symbol = &_ALF_LINKAGE_SYMBOL_HYBRID;

#define ALF_ACCEL_EXPORT_API_LIST_END   
#define ALF_ACCEL_EXPORT_API(_str_, _func_) extern __typeof__ (_func_) _SPUEAR_##_func_  __attribute__ ((alias (#_func_)));

void ALF_ACCEL_DTL_CBEA_DMA_LIST_BUFFER_GET(void *p_dtl, void **pp_dma_list_buffer, unsigned int *p_max_entries);
void ALF_ACCEL_DTL_CBEA_DMA_LIST_BUFFER_UPDATE(void *p_dtl, unsigned int num_entries);
void ALF_ACCEL_DTL_CBEA_DMA_LIST_BUFFER_COMPLETE(void *p_dtl, unsigned int num_entries, alf_data_addr64_t base_ea);

int alf_accel_host_addr_translate(alf_data_addr64_t host_addr, unsigned long long host_size,
                                  ALF_DATASET_ACCESS_MODE_T host_access_mode, alf_data_addr64_t *trans_host_addr);


#endif                          // __ALF_ACCEL_HYBRID_H_INC__
