/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2008       All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

#ifndef _ALFXDS_H_
#define _ALFXDS_H_

// These parameters are compile time limits on the storage used for
// internal XDS structures.  The EBLOCK_PER_GENSET is also affected
// by the ALF limitation on the number of DTL lists per work block
// because each EBLOCK is currently created using a separate DTL.
#define ALFXDS_MAX_ELMSETS              10
#define ALFXDS_MAX_EBLOCKS              20
#define ALFXDS_MAX_GENSETS              10
#define ALFXDS_MAX_EBLOCK_PER_GENSET    8
#define ALFXDS_NUM_DIMS                 3

// The XDS framework currently requires a minimum element size of 16 bytes
#if !defined(ELEM_SIZE)
#define ELEM_SIZE           16
#endif

#define MIN_BYTES_PER_ELEM      ((ELEM_SIZE + (int)sizeof(char) - 1)   / (int)sizeof(char))
#define MIN_INTS_PER_ELEM       ((ELEM_SIZE + (int)sizeof(int) - 1)    / (int)sizeof(int))
#define MIN_LONGS_PER_ELEM      ((ELEM_SIZE + (int)sizeof(long) - 1)   / (int)sizeof(long))
#define MIN_FLOATS_PER_ELEM     ((ELEM_SIZE + (int)sizeof(float) - 1)  / (int)sizeof(float))
#define MIN_DOUBLES_PER_ELEM    ((ELEM_SIZE + (int)sizeof(double) - 1) / (int)sizeof(double))

#define ALFXDS_DIMX 0
#define ALFXDS_DIMY 1
#define ALFXDS_DIMZ 2

#define ALFXDS_STATUS_STEP_CROSS_BASE   (0x01)
#define ALFXDS_STATUS_STEP_CROSS_X      (ALFXDS_STATUS_STEP_CROSS_BASE << ALFXDS_DIMX)
#define ALFXDS_STATUS_STEP_CROSS_Y      (ALFXDS_STATUS_STEP_CROSS_BASE << ALFXDS_DIMY)
#define ALFXDS_STATUS_STEP_CROSS_Z      (ALFXDS_STATUS_STEP_CROSS_BASE << ALFXDS_DIMZ)
#define ALFXDS_STATUS_STEP_END          (ALFXDS_STATUS_STEP_CROSS_X \
										| ALFXDS_STATUS_STEP_CROSS_Y \
										| ALFXDS_STATUS_STEP_CROSS_Z)

#define ALFXDS_STATUS_TRUNCATE_BASE     (0x10)
#define ALFXDS_STATUS_TRUNCATE_X        (ALFXDS_STATUS_TRUNCATE_BASE << ALFXDS_DIMX)
#define ALFXDS_STATUS_TRUNCATE_Y        (ALFXDS_STATUS_TRUNCATE_BASE << ALFXDS_DIMY)
#define ALFXDS_STATUS_TRUNCATE_Z        (ALFXDS_STATUS_TRUNCATE_BASE << ALFXDS_DIMZ)

typedef unsigned long long  alfxds_elem_t;
typedef struct _alfxds_elmset   *alfxds_handle_t;
typedef struct _alfxds_eblock   *alfxds_ebhandle_t;
typedef struct _alfxds_genset   *alfxds_ghandle_t;
typedef void    *(*alfxds_pfunction_t)(void *tlist);

typedef enum    _alfxds_eblock_transfer_t
{   ALFXDS_EBLOCK_TRANSFER_IN = 0x10,
	ALFXDS_EBLOCK_TRANSFER_OUT = 0x11,
	ALFXDS_EBLOCK_TRANSFER_INOUT = 0x12,
	ALFXDS_EBLOCK_TRANSFER_IN_DELTA = 0x20,
	ALFXDS_EBLOCK_TRANSFER_OUT_DELTA = 0x21,
	ALFXDS_EBLOCK_TRANSFER_INOUT_DELTA = 0x22,
} alfxds_eblock_transfer_t;

typedef enum    _alfxds_error_codes_t
{   ALFXDS_ERR_NONE = 0,
	ALFXDS_ERR_GENERAL = 1,
	ALFXDS_ERR_RANGE = 2,
	ALFXDS_ERR_INVALID_HANDLE = 3,
	ALFXDS_ERR_INVALID_ELEMENT = 4,
	ALFXDS_ERR_INVALID_ALIGNMENT = 5,
	ALFXDS_ERR_INVALID_STEP_ORDER = 6,
	ALFXDS_ERR_INVALID_XFER_ORDER = 7,
	ALFXDS_ERR_ELEMENT_SET_IN_USE = 8,
	ALFXDS_ERR_OUT_OF_RESOURCES = 9,
	ALFXDS_ERR_INVALID_TRANSFER_TYPE = 10,
} alfxds_error_codes_t;

/*
 ************************************************************
 * ALF XDS API
 ************************************************************
 */
#ifdef __cplusplus
extern "C" {
#endif                        /* __cplusplus */

/************************** ELMSET *************************/

int alfxds_elmset_set(
		alfxds_elem_t   origin,
		alfxds_handle_t *xds_handle,
		unsigned int    num_x,
		unsigned int    num_y,
		unsigned int    num_z,
		unsigned int    elem_size);

int alfxds_elmset_set_gapped(
		alfxds_elem_t   origin,
		alfxds_handle_t *xds_handle,
		unsigned int    num_x,
		unsigned int    num_y,
		unsigned int    num_z,
		alfxds_elem_t   nmarker_x,
		alfxds_elem_t   nmarker_y,
		alfxds_elem_t   nmarker_z);

int alfxds_elmset_get(
		alfxds_handle_t xds_handle,
		alfxds_elem_t   *origin,
		unsigned int    *num_x,
		unsigned int    *num_y,
		unsigned int    *num_z,
		unsigned int    *elem_size,
		alfxds_elem_t   *nmarker_x,
		alfxds_elem_t   *nmarker_y,
		alfxds_elem_t   *nmarker_z);

int alfxds_elmset_duplicate(
		alfxds_elem_t   origin,
		alfxds_handle_t xds_original_set_handle,
		alfxds_handle_t *xds_new_set_handle);

int alfxds_elmset_release(alfxds_handle_t   xds_handle);

int alfxds_elmset_set_region(
		alfxds_handle_t xds_handle,
		unsigned int    x0,
		unsigned int    nx,
		unsigned int    y0,
		unsigned int    ny,
		unsigned int    z0,
		unsigned int    nz);

int alfxds_elmset_get_region(
		alfxds_handle_t xds_handle,
		unsigned int    *x0,
		unsigned int    *nx,
		unsigned int    *y0,
		unsigned int    *ny,
		unsigned int    *z0,
		unsigned int    *nz);

/************************** EBLOCK *************************/

int alfxds_eblock_set_extent(
		alfxds_handle_t xds_handle,
		alfxds_ebhandle_t   *xds_ebhandle,
		unsigned int    nx0,
		unsigned int    nx,
		unsigned int    nx1,
		unsigned int    ny0,
		unsigned int    ny,
		unsigned int    ny1,
		unsigned int    nz0,
		unsigned int    nz,
		unsigned int    nz1);

int alfxds_eblock_get_extent(
		alfxds_ebhandle_t   xds_ebhandle,
		unsigned int    *nx0,
		unsigned int    *nx,
		unsigned int    *nx1,
		unsigned int    *ny0,
		unsigned int    *ny,
		unsigned int    *ny1,
		unsigned int    *nz0,
		unsigned int    *nz,
		unsigned int    *nz1);

int alfxds_eblock_set_extent_nb(
		alfxds_handle_t xds_handle,
		alfxds_ebhandle_t   *xds_ebhandle,
		unsigned int    nx,
		unsigned int    ny,
		unsigned int    nz);

int alfxds_eblock_get_extent_nb(
		alfxds_ebhandle_t   xds_ebhandle,
		unsigned int    *nx,
		unsigned int    *ny,
		unsigned int    *nz);

int alfxds_eblock_duplicate(
		alfxds_handle_t xds_new_set_handle,
		alfxds_ebhandle_t   xds_original_ebhandle,
		alfxds_ebhandle_t   *xds_new_ebhandle);

int alfxds_eblock_release(alfxds_ebhandle_t xds_ebhandle);

int alfxds_eblock_set_position_start(
		alfxds_ebhandle_t   xds_ebhandle,
		unsigned int    x,
		unsigned int    y,
		unsigned int    z);

int alfxds_eblock_set_position_current(
		alfxds_ebhandle_t   xds_ebhandle,
		unsigned int    x,
		unsigned int    y,
		unsigned int    z);

int alfxds_eblock_get_position_start(
		alfxds_ebhandle_t   xds_ebhandle,
		unsigned int    *x,
		unsigned int    *y,
		unsigned int    *z);

int alfxds_eblock_get_position_current(
		alfxds_ebhandle_t   xds_ebhandle,
		unsigned int    *x,
		unsigned int    *y,
		unsigned int    *z);

int alfxds_eblock_set_step(
		alfxds_ebhandle_t   xds_ebhandle,
		int order_x,
		int num_x,
		int order_y,
		int num_y,
		int order_z,
		int num_z);

int alfxds_eblock_get_step(
		alfxds_ebhandle_t   xds_ebhandle,
		int *order_x,
		int *num_x,
		int *order_y,
		int *num_y,
		int *order_z,
		int *num_z);

int alfxds_eblock_set_type(
		alfxds_ebhandle_t   xds_ebhandle,
		alfxds_eblock_transfer_t    transfer_type);

int alfxds_eblock_get_type(
		alfxds_ebhandle_t   xds_ebhandle,
		alfxds_eblock_transfer_t    *transfer_type);

int alfxds_eblock_set_order(
		alfxds_ebhandle_t   xds_ebhandle,
		int order_x,
		int order_y,
		int order_z);

int alfxds_eblock_get_order(
		alfxds_ebhandle_t   xds_ebhandle,
		int *order_x,
		int *order_y,
		int *order_z);



int alfxds_genset_set(
		alfxds_ghandle_t    *xds_ghandle,
		unsigned int        *last_step_taken,
		unsigned int        *is_truncated,
		alfxds_pfunction_t  print_fcn,
		unsigned int        num_eblocks, ...);

int alfxds_genset_get(
		alfxds_ghandle_t    xds_ghandle,
		unsigned int        **last_step_taken,
		unsigned int        **is_truncated,
		alfxds_pfunction_t  *print_fcn,
		unsigned int        *num_eblocks,
		alfxds_ebhandle_t   *xds_ebhandle);

int alfxds_genset_release(alfxds_ghandle_t  xds_ghandle);

/************************** GENSET *************************/

int alfxds_eblock_gen_dtl(
		alfxds_ghandle_t    xds_ghandle,
		void    *dtl_target);

int alfxds_eblock_get_info(
		alfxds_ebhandle_t   xds_ebhandle,
		unsigned int    *status,
		unsigned int    *x,
		unsigned int    *nx,
		unsigned int    *y,
		unsigned int    *ny,
		unsigned int    *z,
		unsigned int    *nz);

int alfxds_genset_step_once(
	alfxds_ghandle_t    xds_ghandle,
	unsigned int        *last_step_taken);

int alfxds_eblock_step_once(
		alfxds_ebhandle_t   xds_ebhandle,
		unsigned int        *step_status);

#ifdef __cplusplus
}
#endif                        /* __cplusplus */

#endif /*_ALFXDS_H_*/
