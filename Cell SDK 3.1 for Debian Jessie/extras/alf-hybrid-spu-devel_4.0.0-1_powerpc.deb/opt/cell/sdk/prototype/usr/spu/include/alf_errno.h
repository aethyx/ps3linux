/* --------------------------------------------------------------  */
/* (C)Copyright 2007,2008,                                         */
/* International Business Machines Corporation                     */
/* All Rights Reserved.                                            */
/*                                                                 */
/* Redistribution and use in source and binary forms, with or      */
/* without modification, are permitted provided that the           */
/* following conditions are met:                                   */
/*                                                                 */
/* - Redistributions of source code must retain the above copyright*/
/*   notice, this list of conditions and the following disclaimer. */
/*                                                                 */
/* - Redistributions in binary form must reproduce the above       */
/*   copyright notice, this list of conditions and the following   */
/*   disclaimer in the documentation and/or other materials        */
/*   provided with the distribution.                               */
/*                                                                 */
/* - Neither the name of IBM Corporation nor the names of its      */
/*   contributors may be used to endorse or promote products       */
/*   derived from this software without specific prior written     */
/*   permission.                                                   */
/*                                                                 */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
/* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
/* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
/* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
/* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
/* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
/* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
/* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
/* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
/* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
/* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/* --------------------------------------------------------------  */
/* PROLOG END TAG zYx                                              */

#ifndef __ALF_ERRNO_H_INC__
#define __ALF_ERRNO_H_INC__

/*
 ************************************************************
 * ALF API Error Codes
 ************************************************************
 */

/* The values are defined accordingly to the correspondent standard error codes of Linux */

#define ALF_ERR_PERM      1         // No permission, in cases where further operations are forbidden, e.g., add a parameter to an already enqueued wb
#define ALF_ERR_SRCH      3         // No such task, in cases where the task is not created
#define ALF_ERR_2BIG      7         // I/O request out of scope, in cases where I/O buffer requests are out of range
#define ALF_ERR_NOEXEC    8         // Execution error, in cases where task description info is invalid
#define ALF_ERR_BADF      9         // Bad handle, in cases where the ALF handle is invalid and in cases you get a bad handle
#define ALF_ERR_AGAIN     11        // Try again, you need to try again, for example alf_init with policy other than PERSIST
#define ALF_ERR_NOMEM     12        // Out of memory, anytime memory allocation failed
#define ALF_ERR_FAULT     14        // Invalid address, any invalid address is given
#define ALF_ERR_BUSY      16        // Resource busy, in cases where you want to kill occupied resources
#define ALF_ERR_INVAL     22        // Invalid argument, this should be the most often one
#define ALF_ERR_RANGE     34        // Numerical result or arguments out of defined range, if we can capture this, usually a floating point exception or so
#define ALF_ERR_NOSYS     38        // Function or features not implemented
#define ALF_ERR_BADR      53        // Generic internal error
#define ALF_ERR_NODATA    61        // No more data available
#define ALF_ERR_TIME      62        // Time out 
#define ALF_ERR_COMM      70        // Generic communication error
#define ALF_ERR_PROTO     71        // Internal protocol error
#define ALF_ERR_BADMSG    74        // Internal protocol error
#define ALF_ERR_OVERFLOW  75        // Value out of range when converting, if we can capture this
#define ALF_ERR_INCOMPAT  76        // Accelerator incompatibility
#define ALF_ERR_NOBUFS    105       // No buffer space available, use as is
#define ALF_ERR_GENERIC   1000      // Generic internal error
#define ALF_ERR_ACCEL     2000      // Generic accelerator error, for example, SPE "bus errors"

#endif /* __ALF_ERRNO_H_INC__ */
