!* --------------------------------------------------------------  */
!* (C)Copyright 2006,2008,                                         */
!* International Business Machines Corporation                     */
!* All Rights Reserved.                                            */
!*                                                                 */
!* Redistribution and use in source and binary forms, with or      */
!* without modification, are permitted provided that the           */
!* following conditions are met:                                   */
!*                                                                 */
!* - Redistributions of source code must retain the above copyright*/
!*   notice, this list of conditions and the following disclaimer. */
!*                                                                 */
!* - Redistributions in binary form must reproduce the above       */
!*   copyright notice, this list of conditions and the following   */
!*   disclaimer in the documentation and/or other materials        */
!*   provided with the distribution.                               */
!*                                                                 */
!* - Neither the name of IBM Corporation nor the names of its      */
!*   contributors may be used to endorse or promote products       */
!*   derived from this software without specific prior written     */
!*   permission.                                                   */
!*                                                                 */
!* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND          */
!* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,     */
!* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF        */
!* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE        */
!* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR            */
!* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,    */
!* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT    */
!* NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;    */
!* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)        */
!* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN       */
!* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR    */
!* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,  */
!* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
!* --------------------------------------------------------------  */
!* PROLOG END TAG zYx                                              */
!
!*---------------------------------------------------------------------------------------------------------------------------------
!*  DaCS Fortran Binding Include file
!*  Based on the DaCS APIs defined in the C header file dacs.h  release dacs version 1.40
!*  Contains kind types, constants and type definitions used to access the DaCS APIs from Fortran
!*---------------------------------------------------------------------------------------------------------------------------------

!*---------------------------------------------------------------------------------------------------------------------------------
!*  This include file is compatible with both Fortran fixed and free source forms
!*    - code must be within cols 7 - 132 inclusive
!*    - code must not contain line continuation characters
!*    - comment character is exclamation mark (!) in column 1 or following code
!*    - comments must not exceed column 132
!*---------------------------------------------------------------------------------------------------------------------------------
!*  Compile options for fixed and free form
!*  GNU: -ffree-form  or -ffixed-line-length-0
!*  PATHSCALE: -freeform or -fixedform -extend-source
!*  XLF: -qfree=f90 or -qfixed=132
!*---------------------------------------------------------------------------------------------------------------------------------

!*---------------------------------------------------------------------------------------------------------------------------------
!*  Kind Types
!*---------------------------------------------------------------------------------------------------------------------------------

      integer, parameter :: dacs_int32_t = 4

      integer, parameter :: dacs_int64_t = 8

      integer, parameter :: dacs_de_id_t = dacs_int32_t

      integer, parameter :: dacs_process_id_t = dacs_int64_t

      integer, parameter :: dacs_remote_mem_t = dacs_int64_t

      integer, parameter :: dacs_wid_t = dacs_int32_t

      integer, parameter :: dacs_group_t = dacs_int64_t

      integer, parameter :: dacs_mutex_t = dacs_int64_t

      integer, parameter :: dacs_pvoid_t = dacs_int64_t !used to hold void * pointers, see helper function makevoid

      integer, parameter :: dacs_addr_64_t = dacs_int64_t !64-bit address, aligned on 128-bit boundaries

      integer, parameter :: dacs_mem_t = dacs_int64_t ! Memory region handle

!*---------------------------------------------------------------------------------------------------------------------------------
!*  Constants
!*---------------------------------------------------------------------------------------------------------------------------------

      integer(kind=dacs_int32_t), parameter :: DACS_VERSION_MAJOR = 4 !Source major version number

      integer(kind=dacs_int32_t), parameter :: DACS_VERSION_MINOR = 0   !Source minor version number


      integer(kind=dacs_int32_t), parameter :: DACS_MAX_ERRSTR_LEN = 32 !Value should be a multiple of 16

      integer(kind=dacs_int32_t), parameter :: DACS_NULL_GROUP = 0   !Invalid group #, used to initialize vars

      integer(kind=dacs_int64_t), parameter :: DACS_PROCESS_ALL = -1  !all running processes on a node (Z'FFFFFFFFFFFFFFFF')

      integer(kind=dacs_int32_t), parameter :: DACS_NULL_DE_ID =  0  !invalid de_id

      integer(kind=dacs_int32_t), parameter :: DACS_DE_SELF = -1  !in dacs.h DACS_DE_SELF is -1U

      integer(kind=dacs_int64_t), parameter :: DACS_PID_SELF = -1

      integer(kind=dacs_int32_t), parameter :: DACS_NUM_SPES_PER_CBE = 8

      integer(kind=dacs_int32_t), parameter :: DACS_NUM_SPES_PER_BLADE = (2*DACS_NUM_SPES_PER_CBE)

      integer(kind=dacs_int32_t), parameter :: DACS_MAX_PROCESSES_PER_DE = 1 !Number of Processes allowed to run on a DE

      integer(kind=dacs_int32_t), parameter :: DACS_DE_PARENT = -2  !in dacs.h DACS_DE_PARENT is -2U

      integer(kind=dacs_int64_t), parameter :: DACS_PID_PARENT = -2

      integer(kind=dacs_int32_t), parameter :: DACS_MAX_PPE_PEERS = 2 !Number of PPEs that a PPE can talk to directly

      integer(kind=dacs_int32_t), parameter :: DACS_INVALID_WID = -624566611  !in dacs.h value is Z'DAC5DEAD'

      character (len =0), dimension(1:0) :: DACS_NULL_STRINGLIST  !zero element array of strings for argv envv in dacs_de_start

!*---------------------------------------------------------------------------------------------------------------------------------
!*  Kind types and constants which map to the dacs.h enumeration types used in DaCS APIs
!*---------------------------------------------------------------------------------------------------------------------------------
!  Stream type for send receive
      integer(kind = dacs_int32_t), parameter :: dacs_stream_t = dacs_int32_t
      integer(kind=dacs_stream_t), parameter   :: DACS_STREAM_ALL = -1 ! in dacs.h Z'ffffffff'
      integer(kind=dacs_stream_t), parameter   :: DACS_STREAM_UB  = -256  ! in dacs.h Z'ffffff00'

!  Byte-swap flags
      integer(kind = dacs_int32_t), parameter :: dacs_byte_swap_t = dacs_int32_t
      integer(kind = dacs_byte_swap_t), parameter :: DACS_BYTE_SWAP_DISABLE      = 0  ! no byte-swapping
      integer(kind = dacs_byte_swap_t), parameter :: DACS_BYTE_SWAP_HALF_WORD    = 1  ! swap halfword: 2 byte value
      integer(kind = dacs_byte_swap_t), parameter :: DACS_BYTE_SWAP_WORD         = 2  ! swap word: 4 byte value
      integer(kind = dacs_byte_swap_t), parameter :: DACS_BYTE_SWAP_DOUBLE_WORD  = 3  ! swap doubleword: 8 byte value

!  dacs_memory_access_mode_t specifies remote memory access modes for dacs_shared_mem_t types
      integer(kind = dacs_int32_t), parameter :: dacs_memory_access_mode_t = dacs_int32_t
      integer(kind = dacs_memory_access_mode_t), parameter :: DACS_READ_ONLY  = z'20'
      integer(kind = dacs_memory_access_mode_t), parameter :: DACS_WRITE_ONLY = z'40'
      integer(kind = dacs_memory_access_mode_t), parameter :: DACS_READ_WRITE = z'60'

!  dacs_mem_access_mode_t used when creating a dacs_mem_t memory region for both remote and local access
      integer(kind = dacs_int32_t), parameter :: dacs_mem_access_mode_t = dacs_int32_t
      integer(kind = dacs_mem_access_mode_t), parameter :: DACS_MEM_READ_ONLY  = Z'20'
      integer(kind = dacs_mem_access_mode_t), parameter :: DACS_MEM_WRITE_ONLY = Z'40'
      integer(kind = dacs_mem_access_mode_t), parameter :: DACS_MEM_READ_WRITE = Z'60'
      integer(kind = dacs_mem_access_mode_t), parameter :: DACS_MEM_NONE       = Z'00'

!  dacs_remote_mem_attr_t specifies the attributes that can be read from a dacs_remote_mem_t
      integer(kind = dacs_int32_t), parameter :: dacs_remote_mem_attr_t = dacs_int32_t
      integer(kind = dacs_remote_mem_attr_t), parameter :: DACS_REMOTE_MEM_ADDR = 0
      integer(kind = dacs_remote_mem_attr_t), parameter :: DACS_REMOTE_MEM_SIZE = 1
      integer(kind = dacs_remote_mem_attr_t), parameter :: DACS_REMOTE_MEM_PERM = 2

!  dacs_mem_attr_t  specifies the attributes that can be read from a dacs_mem_t
      integer(kind = dacs_int32_t), parameter :: dacs_mem_attr_t = dacs_int32_t
      integer(kind = dacs_mem_attr_t), parameter :: DACS_MEM_ADDR     = 0
      integer(kind = dacs_mem_attr_t), parameter :: DACS_MEM_SIZE     = 1
      integer(kind = dacs_mem_attr_t), parameter :: DACS_RMT_MEM_PERM = 2
      integer(kind = dacs_mem_attr_t), parameter :: DACS_LCL_MEM_PERM = 3

!  dacs_mem_limits_t are values that can queried to find the limits of resources available for memory regions
      integer(kind = dacs_int32_t), parameter :: dacs_mem_limits_t = dacs_int32_t
      integer(kind = dacs_mem_limits_t), parameter :: DACS_MEM_REGION_MAX_NUM  = 1
      integer(kind = dacs_mem_limits_t), parameter :: DACS_MEM_REGION_MAX_SIZE = 2
      integer(kind = dacs_mem_limits_t), parameter :: DACS_MEM_REGION_AVAIL    = 3

!  dacs_order_attr_t describes the memory ordering for put, get, and list operations
      integer(kind = dacs_int32_t), parameter :: dacs_order_attr_t = dacs_int32_t
      integer(kind = dacs_order_attr_t), parameter :: DACS_ORDER_ATTR_NONE    = 0
      integer(kind = dacs_order_attr_t), parameter :: DACS_ORDER_ATTR_BARRIER = 1
      integer(kind = dacs_order_attr_t), parameter :: DACS_ORDER_ATTR_FENCE   = 2

!  Types of DEs in the topology
      integer(kind = dacs_int32_t), parameter :: dacs_de_type_t = dacs_int32_t
      integer(kind = dacs_de_type_t), parameter :: DACS_DE_INVALID    = 0    ! INVALID TYPE
      integer(kind = dacs_de_type_t), parameter :: DACS_DE_SYSTEMX    = 1    ! Opteron - supervises 4 Cell Blades
      integer(kind = dacs_de_type_t), parameter :: DACS_DE_CELL_BLADE = 2    ! Cell Blade - contains 2 CBE's
      integer(kind = dacs_de_type_t), parameter :: DACS_DE_CBE        = 3    ! Cell Broadband Engine
      integer(kind = dacs_de_type_t), parameter :: DACS_DE_SPE        = 4    ! Cell SPE
      integer(kind = dacs_de_type_t), parameter :: DACS_DE_MAX_TYPE   = 5    ! Always last - max DE type

!  DACS error code convention:
!  - All DACS error codes will start with DACS_ERR prefix.
!  - Positive DACS "error" codes are actually status returned from API's.
!  - All DACS codes indicating true errors will be negative numbers.
      integer(kind = dacs_int32_t), parameter :: dacs_err_t = dacs_int32_t
      integer(kind=dacs_err_t), parameter  :: DACS_SUCCESS           = 0
      integer(kind=dacs_err_t), parameter  :: DACS_WID_READY         = 0
      integer(kind=dacs_err_t), parameter  :: DACS_WID_BUSY          = 1
      integer(kind=dacs_err_t), parameter  :: DACS_STS_PROC_RUNNING  = 2
      integer(kind=dacs_err_t), parameter  :: DACS_STS_PROC_FINISHED = 3
      integer(kind=dacs_err_t), parameter  :: DACS_STS_PROC_FAILED   = 4
      integer(kind=dacs_err_t), parameter  :: DACS_STS_PROC_ABORTED  = 5
      integer(kind=dacs_err_t), parameter  :: DACS_STS_PROC_KILLED   = 6
      integer(kind=dacs_err_t), parameter  :: DACS_LAST_STATUS       = 7

!  errcodes should start at -35000 and count UP from there.
!  therefore DACS_FIRST_ERROR will be the most negative #
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_FIRST_ERROR       = -35000  ! first errorcode
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_INTERNAL          = -34999
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_SYSTEM            = -34998
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_INVALID_ARGV      = -34997
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_INVALID_ENV       = -34996
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_INVALID_HANDLE    = -34995
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_INVALID_ADDR      = -34994
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_INVALID_ATTR      = -34993
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_INVALID_DE        = -34992
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_INVALID_PID       = -34991
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_INVALID_TARGET    = -34990
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_BUF_OVERFLOW      = -34989
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_NOT_ALIGNED       = -34988
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_INVALID_SIZE      = -34987
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_BYTESWAP_MISMATCH = -34986
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_NO_RESOURCE       = -34985
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_PROC_LIMIT        = -34984
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_NO_PERM           = -34983
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_OWNER             = -34982
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_NOT_OWNER         = -34981
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_RESOURCE_BUSY     = -34980
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_GROUP_CLOSED      = -34979
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_GROUP_OPEN        = -34978
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_GROUP_DUPLICATE   = -34977
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_INVALID_WID       = -34976
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_INVALID_STREAM    = -34975
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_NO_WIDS           = -34974
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_WID_ACTIVE        = -34973
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_WID_NOT_ACTIVE    = -34972
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_INITIALIZED       = -34971
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_NOT_INITIALIZED   = -34970
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_MUTEX_BUSY        = -34969
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_NOT_SUPPORTED_YET = -34968
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_VERSION_MISMATCH  = -34967
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_DACSD_FAILURE     = -34966
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_INVALID_PROG      = -34965
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_ARCH_MISMATCH     = -34964
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_INVALID_USERNAME  = -34963
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_INVALID_CWD       = -34962
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_NOT_FOUND         = -34961
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_TOO_LONG          = -34960
      integer(kind=dacs_err_t), parameter  :: DACS_ERR_DE_TERM           = -34959

!  Flags to test read or write mailbox
      integer(kind = dacs_int32_t), parameter :: dacs_test_mailbox_t = dacs_int32_t
      integer(kind = dacs_test_mailbox_t), parameter :: DACS_TEST_MAILBOX_READ   = 0
      integer(kind = dacs_test_mailbox_t), parameter :: DACS_TEST_MAILBOX_WRITE  = 1

!  Flags for dacs_de_kill types
      integer(kind = dacs_int32_t), parameter :: dacs_kill_type_t = dacs_int32_t
      integer(kind = dacs_kill_type_t), parameter :: DACS_KILL_TYPE_ASYNC   = 0

!  Implementation-specific flag that influences process creation.
!
!       DACS_PROC_LOCAL_FILE -  the local file format:
!                               A fully-qualified POSIX-compliant pathname of
!                               the executable file that can be accessed from
!                               the local file system.
!       DACS_PROC_LOCAL_FILE_LIST - the local file list format:
!                               A fully-qualified POSIX-compliant pathname of a
!                               text file that can be accessed from the local
!                               file system.  This file contains a (text) list
!                               of the executable file and all dependant
!                               libraries. The file and all the libraries is
!                               loaded onto the accelerator and executed.
!                               The executable file must be the first thing in
!                               the list.
!       DACS_PROC_REMOTE_FILE - the remote file format:
!                               A fully-qualified POSIX-compliant pathname of
!                               the executable file that can be accessed from
!                               the remote accelerator.
!       DACS_PROC_EMBEDDED is the embedded image format:
!                               A pointer to an executable image that is
!                               embedded in the executable image.
      integer(kind = dacs_int32_t), parameter :: dacs_proc_creation_flag_t = dacs_int32_t
      integer(kind = dacs_proc_creation_flag_t), parameter :: DACS_PROC_LOCAL_FILE      = 0
      integer(kind = dacs_proc_creation_flag_t), parameter :: DACS_PROC_LOCAL_FILE_LIST = 1
      integer(kind = dacs_proc_creation_flag_t), parameter :: DACS_PROC_REMOTE_FILE     = 2
      integer(kind = dacs_proc_creation_flag_t), parameter :: DACS_PROC_EMBEDDED        = 3

!  Flags for dacs_init bit-significant configuration
      integer(kind = dacs_int32_t), parameter :: dacs_init_flag_t = dacs_int32_t
      integer(kind = dacs_init_flag_t), parameter :: DACS_INIT_FLAGS_NONE      = 0
      integer(kind = dacs_init_flag_t), parameter :: DACS_INIT_SINGLE_THREADED = Z'1'

!*---------------------------------------------------------------------------------------------------------------------------------
!* Type definitions
!*---------------------------------------------------------------------------------------------------------------------------------

!  dacs_dma_list_t is a dma_list_element in 64 bit addressing mode
      type dacs_dma_list_t
          sequence
          integer(kind = dacs_addr_64_t) :: offset   ! address of the buffer on DE memory
          integer(kind = dacs_int64_t) :: count      ! byte count to be transfered
      end type dacs_dma_list_t
