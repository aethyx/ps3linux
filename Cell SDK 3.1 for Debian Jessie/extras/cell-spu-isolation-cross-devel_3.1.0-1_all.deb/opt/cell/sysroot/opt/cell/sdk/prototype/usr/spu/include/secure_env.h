/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2006,2008, All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

#ifndef _SECURE_ENV_H_
#define _SECURE_ENV_H_

typedef struct {

	// application secret values specific to this node
	vector unsigned char app_set_shared_key; // points to 128-bit value (quadword-aligned), which represents the secret
						 // specific to this node and application manufacturer
	vector unsigned char app_version_specific_key;  // points to 128-bit value (quadword-aligned), which represents the secret
						 // specific to this node, application manufacturer, and this version of this
						 // application
} secure_env_t;

#endif // _SECURE_ENV_H_

