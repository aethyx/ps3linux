/* --------------------------------------------------------------- */
/* Licensed Materials - Property of IBM                            */
/* 5724-S84                                                        */
/* (C) Copyright IBM Corp. 2006,2008, All Rights Reserved          */
/* US Government Users Restricted Rights - Use, duplication or     */
/* disclosure restricted by GSA ADP Schedule Contract with         */
/* IBM Corp.                                                       */
/* --------------------------------------------------------------- */
/* PROLOG END TAG zYx                                              */

#ifndef LIBISOLATION_H_
#define LIBISOLATION_H_

#include <stdint.h>
#include <stddef.h>

/* copyin/copyout functions */
int copyin(uint64_t ea, void *ls, uint32_t size);
int copyout(uint64_t ea, void *ls, uint32_t size);

/* overlay function */
void overlay();

/* encrypt-out function */
int encrypt_out(const uint64_t ea, void *src_ls, const unsigned int message_size, const vector unsigned char shared_key);
/* decrypt-in function */
int decrypt_in(void *dst_ls, const uint64_t ea, const unsigned int message_size, const vector unsigned char shared_key);

/* open area alloc function */
void *oalloc(size_t size);
/* open area free function */
void ofree(void *ptr);
/* returns free open area size */
size_t oquery();

typedef struct _SFS_FILE SFS_FILE;

SFS_FILE *sfs_fopen(const char *path, char *mode, const vector unsigned char key);
int sfs_fclose(SFS_FILE *fp);

size_t sfs_fread(void *ptr, size_t size, size_t nmemb, SFS_FILE *stream);
size_t sfs_fwrite(const void *ptr, size_t size, size_t nmemb, SFS_FILE *stream);

void sfs_clearerr(SFS_FILE *stream);
int sfs_feof(SFS_FILE *stream);
int sfs_ferror(SFS_FILE *stream);

int sfs_fseek(SFS_FILE *stream, long int offset, int whence);
long sfs_ftell(SFS_FILE *stream);
void sfs_rewind(SFS_FILE *stream);

/*
 This function allows user to change the buffer used by PPE-assisted functions when running on isolated SPU.

 Buffer is located at the beginning of the open area of local store, by convention.
 Buffer length can be changed by user. New length must be between 80 and 8192 bytes (inclusively).

 Function returns 0 on success, -1 on failure.
 */
int change_ppuassist_buf_len(unsigned int new_len);

/*
 * New encrypt/decrypt functions
 */
typedef enum cipher_scheme {
    AES_CBC_MODE = 0,
    AES_ECB_MODE,
} cipher_scheme_t;

typedef enum aes_key_type {
    AES_128_KEY = 10,
    AES_192_KEY = 12,
    AES_256_KEY = 14,
} aes_key_type_t;

typedef struct aes_common {
    vector unsigned char *key;
    vector unsigned char expkey[AES_128_KEY+1];
    aes_key_type_t key_type;   
} aes_common_t;

typedef struct aes_cbc_params {
    aes_common_t aes_common;
    vector unsigned char iv;
} aes_cbc_params_t;

typedef struct aes_ecb_params {
    aes_common_t aes_common;
} aes_ecb_params_t;


typedef struct cipher_ctx {
    cipher_scheme_t scheme;
    void *params;
    void *cipher_text;
    void *plain_text;
    unsigned int msg_len;
} cipher_ctx_t;

/* create cipher context */
cipher_ctx_t* create_cipher_ctx(cipher_scheme_t scheme);
/* destroy cipher context */
void destroy_cipher_ctx(cipher_ctx_t *params);
/* initialize cipher context */
int init_cipher(cipher_ctx_t *params);
/* new encrypt function */
int encrypt(vector unsigned char *cipher, vector unsigned char *plain, const unsigned int len, cipher_ctx_t *params);
/* new decrypt function */
int decrypt(vector unsigned char *plain, vector unsigned char *cipher, const unsigned int len, cipher_ctx_t *params);

#endif /* LIBISOLATION_H_ */
