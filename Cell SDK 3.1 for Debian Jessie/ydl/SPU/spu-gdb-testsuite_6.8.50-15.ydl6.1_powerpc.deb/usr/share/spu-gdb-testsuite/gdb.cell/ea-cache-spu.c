#include <stdio.h>
#include <spu_mfcio.h>


__ea int *ppe_int_ptr;

int main(unsigned long long speid, unsigned long long argp,
         unsigned long long envp)
{
  printf ("spe.c | argp = 0x%llx\n", argp);

#ifdef __EA32__
  ppe_int_ptr = (__ea int *)(unsigned long)argp;
#else
  ppe_int_ptr = (__ea int *)argp;
#endif
  printf ("spe.c | value = %d\n", *ppe_int_ptr);
  *ppe_int_ptr = 42; /* Marker SPUEA */
  printf ("spe.c | value = %d\n", *ppe_int_ptr);

  return 0;
}
