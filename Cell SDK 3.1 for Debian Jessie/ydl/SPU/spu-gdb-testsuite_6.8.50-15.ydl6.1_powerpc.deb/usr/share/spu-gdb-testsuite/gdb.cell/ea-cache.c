/*  Simple combined applications for testing ea pointers on Cell
    Broadband Engine.  */
#include <stdio.h>
#include <libspe2.h>
#include <pthread.h>
#include <sys/wait.h>

extern spe_program_handle_t ea_cache_spu;
int int_var = 23;

void * spe_thread(void * arg)
{
  int flags = 0;
  unsigned int entry = SPE_DEFAULT_ENTRY;
  spe_context_ptr_t * ctx = (spe_context_ptr_t *) arg;

  spe_program_load (*ctx, &ea_cache_spu);
  spe_context_run
    (*ctx, &entry, flags, &int_var, NULL, NULL);

  pthread_exit(NULL);
}

int main ()
{
  spe_context_ptr_t ctx;
  pthread_t pts;
  int thread_id;

  printf ("ppe.c | int_var vor %d | adr int_var %p\n", int_var, &int_var);

  /* Create SPE context and pthread.  */
  ctx = spe_context_create (0, NULL);
  thread_id = pthread_create (&pts, NULL, &spe_thread, &ctx);

  /* Join the pthread.  */
  pthread_join (pts, NULL);

  /* Destroy the SPE context.  */
  spe_context_destroy (ctx);

  printf ("ppe.c | int_var nach %d\n", int_var);

  return 0;
}



