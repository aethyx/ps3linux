#include "hang.H"

struct B
{
  int member_of_B;
};

int var_in_b = 1729;
