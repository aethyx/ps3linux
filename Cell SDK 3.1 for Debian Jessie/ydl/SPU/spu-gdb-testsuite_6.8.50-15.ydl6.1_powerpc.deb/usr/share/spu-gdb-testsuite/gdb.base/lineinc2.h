#undef FOO
#define FOO 2
