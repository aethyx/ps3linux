#undef FOO
#define FOO 3
