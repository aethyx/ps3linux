typedef char foo;

foo charfoo (afoo)
{
  return (afoo * 2);
}
