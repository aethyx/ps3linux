static int grbxx = 'g' + 'r' + 'b' + 'x';

int grbx (int x)
{
  if (x)
    return grbxx;
  else
    return 0;
}

