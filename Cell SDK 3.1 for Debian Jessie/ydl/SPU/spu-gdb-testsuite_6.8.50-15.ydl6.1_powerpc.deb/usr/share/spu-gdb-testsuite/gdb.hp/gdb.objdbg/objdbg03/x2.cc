#include <stdio.h>

int common10;
int common11;

int data10 = 10;
int data11 = 11;
