#include "x.h"

template class Adder<int>;
