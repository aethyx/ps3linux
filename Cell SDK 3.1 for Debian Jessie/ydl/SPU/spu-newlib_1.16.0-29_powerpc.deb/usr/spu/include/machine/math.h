#ifndef _MACHMATH_H_
#define _MACHMATH_H_

#include <_ansi.h>

_BEGIN_STD_C

/* This header allows platforms to add math.h extensions.  */

#ifdef __SPU__
extern long long int llrintl _PARAMS((long double));
extern long long int llroundl _PARAMS((long double));
#endif  /* __SPU__ */

_END_STD_C

#endif  /* _MACHMATH_H_ */

