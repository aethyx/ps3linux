// { dg-do run  }
class dummy                             { public: void operator++(void) {}
                     };
class dummy_000 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_001 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_002 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_003 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_004 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_005 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_006 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_007 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_008 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_009 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_010 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_011 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_012 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_013 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_014 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_015 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_016 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_017 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_018 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_019 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_020 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_021 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_022 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_023 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_024 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_025 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_026 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_027 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_028 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_029 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_030 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_031 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_032 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_033 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_034 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_035 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_036 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_037 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_038 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_039 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_040 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_041 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_042 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_043 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_044 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_045 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_046 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_047 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_048 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };
class dummy_049 : private virtual dummy { public: void operator++(void) {
dummy::operator++(); } };

class super :
  private dummy_000, private dummy_001, private dummy_002, private
dummy_003, private dummy_004,
  private dummy_005, private dummy_006, private dummy_007, private
dummy_008, private dummy_009,
  private dummy_010, private dummy_011, private dummy_012, private
dummy_013, private dummy_014,
  private dummy_015, private dummy_016, private dummy_017, private
dummy_018, private dummy_019,
  private dummy_020, private dummy_021, private dummy_022, private
dummy_023, private dummy_024,
  private dummy_025, private dummy_026, private dummy_027, private
dummy_028, private dummy_029,
  private dummy_030, private dummy_031, private dummy_032, private
dummy_033, private dummy_034,
  private dummy_035, private dummy_036, private dummy_037, private
dummy_038, private dummy_039,
  private dummy_040, private dummy_041, private dummy_042, private
dummy_043, private dummy_044,
  private dummy_045, private dummy_046, private dummy_047, private
dummy_048, private dummy_049
{
public:
  void operator++(void);
};

void super::operator++(void)
{
  dummy_000::operator++();
  dummy_001::operator++();
  dummy_002::operator++();
  dummy_003::operator++();
  dummy_004::operator++();
  dummy_005::operator++();
  dummy_006::operator++();
  dummy_007::operator++();
  dummy_008::operator++();
  dummy_009::operator++();
  dummy_010::operator++();
  dummy_011::operator++();
  dummy_012::operator++();
  dummy_013::operator++();
  dummy_014::operator++();
  dummy_015::operator++();
  dummy_016::operator++();
  dummy_017::operator++();
  dummy_018::operator++();
  dummy_019::operator++();
  dummy_020::operator++();
  dummy_021::operator++();
  dummy_022::operator++();
  dummy_023::operator++();
  dummy_024::operator++();
  dummy_025::operator++();
  dummy_026::operator++();
  dummy_027::operator++();
  dummy_028::operator++();
  dummy_029::operator++();
  dummy_030::operator++();
  dummy_031::operator++();
  dummy_032::operator++();
  dummy_033::operator++();
  dummy_034::operator++();
  dummy_035::operator++();
  dummy_036::operator++();
  dummy_037::operator++();
  dummy_038::operator++();
  dummy_039::operator++();
  dummy_040::operator++();
  dummy_041::operator++();
  dummy_042::operator++();
  dummy_043::operator++();
  dummy_044::operator++();
  dummy_045::operator++();
  dummy_046::operator++();
  dummy_047::operator++();
  dummy_048::operator++();
  dummy_049::operator++();
}


int main(void)
{
}
