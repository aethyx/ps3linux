// { dg-do assemble  }
// GROUPS uncaught
int a;// { dg-error "" } .*
int a;// { dg-error "" } .*
