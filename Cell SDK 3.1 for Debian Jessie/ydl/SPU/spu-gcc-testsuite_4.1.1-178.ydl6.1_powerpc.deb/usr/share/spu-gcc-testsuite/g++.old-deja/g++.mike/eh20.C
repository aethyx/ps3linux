// { dg-do assemble  }
// { dg-options "-fexceptions -Wall" }

int
main() {
  throw 1;
}
