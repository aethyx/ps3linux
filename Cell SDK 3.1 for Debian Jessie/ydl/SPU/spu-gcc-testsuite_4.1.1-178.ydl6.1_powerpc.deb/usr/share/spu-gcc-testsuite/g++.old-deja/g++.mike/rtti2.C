// { dg-do run  }
#include <typeinfo>

int main() {
  typeid(bool);
}
