// { dg-do assemble  }
// { dg-options "-fexceptions" }

void foo() {
  throw 1;
}
