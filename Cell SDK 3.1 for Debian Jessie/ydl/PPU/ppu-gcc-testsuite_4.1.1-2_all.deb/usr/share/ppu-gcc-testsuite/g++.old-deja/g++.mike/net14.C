// { dg-do assemble  }
// this probably does not have correct debugging info generated.

typedef struct Thing {
                Thing();
        int     x;
} Thing;
