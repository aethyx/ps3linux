// { dg-do assemble  }

namespace N {
  struct C {
    C();
  };
}

namespace M {
  struct C {
    C();
  };
}
