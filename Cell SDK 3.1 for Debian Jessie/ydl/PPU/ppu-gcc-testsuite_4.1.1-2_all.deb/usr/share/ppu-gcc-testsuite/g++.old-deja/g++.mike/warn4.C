// { dg-do assemble  }
void foo (int a, int a) { }	// { dg-error "" } 
