// { dg-do assemble  }

#include <typeinfo>
#include <iostream>
