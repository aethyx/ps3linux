// { dg-do run { xfail arm-*-pe } }
// { dg-options "-fexceptions" }

#include <string>

main() { }
