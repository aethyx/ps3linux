// { dg-do run  }
int main() {
  int i = ~ false;
}
