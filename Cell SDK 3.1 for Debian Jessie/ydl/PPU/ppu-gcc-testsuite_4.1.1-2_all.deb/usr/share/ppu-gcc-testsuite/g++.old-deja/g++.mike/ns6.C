// { dg-do assemble  }

namespace A {
  int i = 1;
}

namespace A {
  int j = i;
}
