// { dg-do assemble { target native } }
// { dg-options "-fexceptions -fPIC -S" }

main() { throw 1; }
