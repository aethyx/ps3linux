// { dg-do run  }
// prms-id: 5611

int main(void)
{
  struct B
    {
      virtual void b1() { };
    };

  return 0;
}
