// { dg-do run  }
namespace Foo {
  int bar() {
    return 0;
  }
}

int main() {
  return Foo::bar();
}
