// { dg-do assemble  }

void foo(bool arg = (1==0)) {}
