// { dg-do assemble  }
int i;		// { dg-error "" } 

namespace i {	// { dg-error "" } 
}
