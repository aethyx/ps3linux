// { dg-do assemble  }
// prms-id: 6901

void green() {
  for (int i = 0; i < 10; i++) {}
  for (int i = 0; i < 10; i++) {}
}
