// { dg-do assemble  }
// { dg-options "" }

// This should compile.

int foo (signed char *);
int foo (char *);
