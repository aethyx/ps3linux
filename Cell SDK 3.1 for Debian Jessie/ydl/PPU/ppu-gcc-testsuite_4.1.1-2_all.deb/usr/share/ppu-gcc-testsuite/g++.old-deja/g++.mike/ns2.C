// { dg-do run  }
namespace N {
  int i;
}

using namespace N;

int main() {
  return i;
}
