// { dg-do assemble  }

class path {
public:
        path (const path& r)
            { "\"";
	      '\'';
            }
};
