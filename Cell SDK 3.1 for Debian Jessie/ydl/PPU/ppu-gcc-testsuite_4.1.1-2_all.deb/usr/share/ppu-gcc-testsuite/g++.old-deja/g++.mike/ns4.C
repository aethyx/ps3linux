// { dg-do assemble  }

namespace i {
}
namespace i {
}
