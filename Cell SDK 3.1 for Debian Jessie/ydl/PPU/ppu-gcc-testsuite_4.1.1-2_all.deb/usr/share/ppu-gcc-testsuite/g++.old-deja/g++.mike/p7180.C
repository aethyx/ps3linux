// { dg-do run  }
// prms-id: 7180

class String {
public:
   String(const char*);
   ~String();
};
 
String::String(const char* str = "") {
}
 
String::~String(void) {
}
 
int main() {
   const String array[] = {"3"};
}
