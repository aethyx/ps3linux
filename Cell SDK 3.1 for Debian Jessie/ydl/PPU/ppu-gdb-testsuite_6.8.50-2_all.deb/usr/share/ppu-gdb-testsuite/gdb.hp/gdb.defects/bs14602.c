/* Test file for bs14602.exp */

double      v_double = 0;
long double v_long_double = 12345.67890;

int main () {
  v_double = 0;
  v_long_double = 12345.67890;
}
