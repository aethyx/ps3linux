main()
{
	function_from_primary();
	function_from_secondary();
}

