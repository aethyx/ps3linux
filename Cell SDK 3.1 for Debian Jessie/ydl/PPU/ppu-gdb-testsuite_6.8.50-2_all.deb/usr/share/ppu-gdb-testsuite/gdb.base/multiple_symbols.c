#include <stdio.h>
void foo ();

int main ()
{
  foo ();
  return 0;
}

void
foo ()
{
  return;
}
