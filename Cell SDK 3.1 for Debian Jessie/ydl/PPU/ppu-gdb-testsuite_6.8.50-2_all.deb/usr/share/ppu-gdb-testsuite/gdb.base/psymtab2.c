extern int zzz;

int zzz = 123;
