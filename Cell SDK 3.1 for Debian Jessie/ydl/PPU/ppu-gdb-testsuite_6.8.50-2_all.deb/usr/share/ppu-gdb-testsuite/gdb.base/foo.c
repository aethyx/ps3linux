static int foox = 'f' + 'o' + 'o';

int foo (int x)
{
  if (x)
    return foox;
  else
    return 0;
}
