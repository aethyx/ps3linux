static void
foo ()
{
  return;
}
