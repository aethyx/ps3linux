#include "hang.H"

const struct B *const_B_ptr;
int var_in_hang3 = 42;
