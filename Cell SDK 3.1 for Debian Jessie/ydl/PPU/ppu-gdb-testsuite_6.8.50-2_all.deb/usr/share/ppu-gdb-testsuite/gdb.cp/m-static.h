// 2002-08-16

class gnu_obj_4
{
 public:
  static const int elsewhere;
  static const int nowhere;
  // At some point, perhaps:
  // static const int everywhere = 317;

  // try to ensure test4 is actually allocated
  int dummy;
};

