// 2002-08-16

#include "m-static.h"

const int gnu_obj_4::elsewhere = 221;
