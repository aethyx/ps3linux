public class jmain
{
  public static void main (String[] args)
    {
	return;
    }
}
