#include "../../../../test/hcall_console.c"
