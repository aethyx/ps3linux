
#define hprintf_nlk hprintf
#include "../../../../test/gdbstub.c"
